@KotlinBuildScript("https://tools.kotlin.build/")
@file:WithArtifact("kompile:build-kotlin-jvm:0.0.33")
@file:WithRepository("https://kotlin.directory/")
@file:WithRepository("https://repo1.maven.org/maven2/")
@file:WithRepository("https://dl.cloudsmith.io/public/libp2p/jvm-libp2p/maven/")
@file:WithRepository("https://artifacts.consensys.net/public/maven/maven/")
@file:WithRepository("https://jitpack.io")
package foundation.url.protocol

import build.kotlin.withartifact.WithArtifact
import build.kotlin.withartifact.WithRepository
import java.io.File
import build.kotlin.jvm.*
import build.kotlin.annotations.MavenArtifactCoordinates

val dependencies = resolveDependencies2(
    // Kotlin stdlib
    MavenPrebuilt2("org.jetbrains.kotlin:kotlin-stdlib:1.8.22"),
    MavenPrebuilt2("org.jetbrains.kotlin:kotlin-stdlib-common:1.8.22"),
    MavenPrebuilt2("org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.22"),
    MavenPrebuilt2("org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.22"),
    MavenPrebuilt2("org.jetbrains.kotlin:kotlin-reflect:1.8.22"),

    // Coroutines for async operations (JVM-specific)
    MavenPrebuilt2("org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm:1.7.3"),

    // JSON parsing (org.json)
    MavenPrebuilt2("org.json:json:20231013"),

    // Filesystem operations (okio)
    MavenPrebuilt2("com.squareup.okio:okio-jvm:3.4.0"),

    // Clock abstraction for testable time-dependent logic
    // Cancelled RPC idle timers must release their closed channel callbacks immediately.
    MavenPrebuilt2("community.kotlin.clocks.simple:community-kotlin-clocks-simple:0.0.16"),

    // Algebraic effects for caller-observable non-fatal warnings
    MavenPrebuilt2("algebraic.effects.v1.runtime:algebraic-effects-v1-runtime:0.0.6"),
    MavenPrebuilt2("community.kotlin.logging:community-kotlin-logging:0.0.1"),

    // libp2p for P2P networking
    // snapshot-25 carries: yamux O(n^2) ArrayDeque fix (snapshot-12), off-event-loop
    // Noise handshake crypto (snapshot-13), idempotent multistream Negotiator cleanup
    // under the close-race (snapshot-15), remote-wait-scoped Noise read-timeout
    // (snapshot-17), pending peer-connect deduplication (snapshot-18), and
    // connection-wide child-write reservation (snapshot-19). The reservation prevents
    // stalled Yamux peers from retaining unbounded flow-control ByteBufs.
    // snapshot-20 moves default key generation, Noise, TLS, and secio setup onto a non-blocking
    // random source; upstream: https://github.com/CodexCoder21Organization/jvm-libp2p/pull/22.
    // snapshot-21 filters terminal entries from established-connection lookups so a new stream
    // dials a fresh connection once the old close future completes; upstream:
    // https://github.com/CodexCoder21Organization/jvm-libp2p/pull/33.
    // snapshot-25 makes child-channel teardown unconditional and installs the negotiation
    // pipeline before arming parent-close propagation, so an early close always completes the
    // stream negotiation controller; upstream:
    // https://github.com/CodexCoder21Organization/jvm-libp2p/pull/36.
    MavenPrebuilt2("community.kotlin.libp2p:jvm-libp2p:1.3.0-codexcoder21-snapshot-25"),

    // Netty for network I/O (directly used by Libp2pHostFactory)
    MavenPrebuilt2("io.netty:netty-buffer:4.2.10.2-codexcoder21"),
    MavenPrebuilt2("io.netty:netty-common:4.2.10.2-codexcoder21"),
    MavenPrebuilt2("io.netty:netty-transport:4.2.10.2-codexcoder21"),
    MavenPrebuilt2("io.netty:netty-handler:4.2.10.2-codexcoder21"),
    MavenPrebuilt2("io.netty:netty-codec:4.2.10.2-codexcoder21"),

    // RPC Protocol (transport-agnostic)
    MavenPrebuilt2("community.kotlin.rpc:protocol-api:0.0.2"),
    MavenPrebuilt2("community.kotlin.rpc:protocol-impl:0.0.11"),

    // VPN URL Registrar API client
    MavenPrebuilt2("VpnUrlRegistrarApiClient:vpn-url-registrar-client:0.0.1"),
    MavenPrebuilt2("VpnUrlRegistrarApi:vpn-url-registrar-api:0.0.1"),

    // OkHttp (required by VpnUrlRegistrarApiClient)
    MavenPrebuilt2("com.squareup.okhttp3:okhttp:4.11.0"),

    // Protobuf (required by libp2p crypto)
    MavenPrebuilt2("com.google.protobuf:protobuf-java:3.24.0"),

    // BouncyCastle (required by libp2p for Ed25519 keys)
    MavenPrebuilt2("org.bouncycastle:bcprov-jdk18on:1.77"),

    // SLF4J logging (required by libp2p)
    MavenPrebuilt2("org.slf4j:slf4j-api:1.7.36"),
    MavenPrebuilt2("org.slf4j:slf4j-simple:1.7.36"),

    // Noise protocol (required by libp2p security)
    MavenPrebuilt2("tech.pegasys:noise-java:22.1.0"),

    // Guava (required by libp2p multiaddr)
    MavenPrebuilt2("com.google.guava:guava:32.1.2-jre")

    // Note: SJVM and ASM dependencies have been moved to foundation.url:resolver
    // which provides sandboxed execution and type materialization on top of UrlProtocol
)

@MavenArtifactCoordinates("foundation.url:protocol:")
fun buildMaven(): File {
    return buildSimpleKotlinMavenArtifact(
        // 0.0.332: additive RpcResponse.metadata channel (reunifies the 0.0.329 metadata line with
        //          main's 0.0.330 fixes). Originally published as 0.0.329 off a branch that predated
        //          the #335 stale-announcement fix and the #336 yamux guards; re-landed here on top of
        //          main so a single line carries both the metadata channel and those fixes. Adds an
        //          additive, backward-compatible response-metadata channel to
        //          Libp2pRpcProtocol.RpcResponse — a generic optional `metadata: Map<String,String>`
        //          mirroring the long-standing RpcRequest.metadata. It is the wire substrate for the
        //          HierarchicalClock ambient contract: a serving clock stamps its response with
        //          entries such as `clock-timestamp` and ships coverage receipts as `clock-receipts`
        //          (consumed by UrlResolver). Purely additive, no protocol-version negotiation:
        //          - Serialized as an optional JSON object under "metadata"; toJson OMITS it when the
        //            map is empty, so the wire form stays byte-identical to the pre-metadata format for
        //            the common case and a re-serializing relay never introduces a spurious field.
        //          - fromJson / fromJsonRaw tolerate its absence (missing field -> empty map), so a
        //            new reader parses an old writer's response and org.json ignores the unknown field
        //            for an old reader parsing a new writer's response.
        //          - RELAY PRESERVATION: a relay carries the RpcResponse as an opaque Base64 payload
        //            inside RelayProtocol.RelayResponse (parsed/re-serialized at the envelope level
        //            only, payload verbatim), so metadata inside the serialized response survives the
        //            relay re-encode path that a past incident dropped newer fields on. Guarded by an
        //            end-to-end isolated in-process relay test.
        //          The shared metadata decode is a single package-level helper (parseMetadataMap) used
        //          by both RpcRequest and RpcResponse so the two can never drift.
        //          Tests: tests/testRpcResponseMetadataRoundTrip.kts,
        //            tests/testRpcResponseFromJsonLegacyWithoutMetadata.kts,
        //            tests/testRpcResponseToJsonOmitsEmptyMetadata.kts,
        //            tests/testRpcResponseOldReaderToleratesMetadataField.kts,
        //            tests/testRpcResponseMetadataSurvivesRelayReEncode.kts.
        // 0.0.328: Add a per-connection server->client push channel exposed to services, so a
        //          registered service can send unsolicited frames to one specific connected client
        //          and learn when that client's connection dies — the transport primitive the
        //          UrlResolver live-projection lease needs to drop its 10s re-SUBSCRIBE heartbeat
        //          (PlanRepository workstreams/Observables.md, connection-scoped lease). Additive
        //          and backward compatible:
        //          - New ServiceClientConnection (connectionId / isOpen / push(JSONObject) /
        //            onClose(() -> Unit)) and the optional ConnectionAwareServiceHandler extension of
        //            ServiceHandler. Old three-arg handlers are unchanged and never see a connection;
        //            a handler opts in by implementing the four-arg handleRequest.
        //          - The per-connection EffectPropagator handed to ServiceRoutingHandler
        //            (ControllerEffectPropagator on the libp2p NIO path, TcpServer's per-connection
        //            propagator on the localhost.tcp path) now ALSO implements ServiceClientConnection.
        //            ServiceRoutingHandler downcasts it and passes it to a ConnectionAwareServiceHandler;
        //            a plain EffectPropagator (old transport / test stub) yields no connection, so
        //            dispatch is unchanged. No RpcRequestHandler / EffectPropagator signature change.
        //            ControllerEffectPropagator's new ctor params are defaulted AND the constructor is
        //            @JvmOverloads, so the legacy single-arg <init>(Function1) JVM descriptor is
        //            preserved — external callers compiled against 0.0.325 stay source AND binary
        //            compatible (0.0.328 adds parameters only; it removes nothing).
        //          - push() writes a frame verbatim over the same backpressure-gated path as an
        //            awaited RPC response and FAILS LOUDLY with ServicePushException when the
        //            connection is closed/reset/unwritable (never silently drops — the throw-on-drop
        //            convention of the 0.0.306/0.0.308 awaited-write fixes), so a downstream lease can
        //            reap on push failure. push() first validates the frame's "type": a missing/empty
        //            type or one of Libp2pRpcProtocol.RESERVED_MESSAGE_TYPES (response/error/ping/...)
        //            is rejected with IllegalArgumentException before any write, so a push can never
        //            spoof an in-flight RPC response/control frame at the client. Per-transport deadline:
        //            the libp2p path is bounded by the backpressure delivery window; the localhost.tcp
        //            path (blocking java.net.Socket, no SO_SNDTIMEO) is bounded by a watchdog that
        //            closes the socket after WRITE_BACKPRESSURE_DELIVERY_WAIT_MS so a non-reading client
        //            cannot park the write forever. Server-initiated push requires a direct (or
        //            transport-level circuit-relay) connection: the app-level RelayService correlates
        //            exactly one response per forwarded request and has no unsolicited-frame path, so
        //            pushes do not traverse it (documented on push() and in the README).
        //          - onClose fires exactly once on connection death (channelInactive / exceptionCaught
        //            on libp2p; read-loop end on TCP), covering both graceful close and abrupt reset;
        //            a late registration on an already-dead connection fires immediately. Listeners run
        //            on a dedicated daemon dispatcher, NOT the Netty event loop, so a slow listener
        //            cannot stall the loop and freeze other connections. connectionId correlates the
        //            captured sender with its lifecycle callback and is unique per LIVE connection (the
        //            connection-less "detached" sentinel is never open) so a stale sender captured
        //            before a reconnect can never alias the new connection.
        //          Tests: tests/testConnectionAwareHandlerReceivesPushSenderThroughRouting.kts,
        //            tests/testServicePushFailsLoudlyOnUnwritableConnection.kts,
        //            tests/testServicePushRejectsReservedFrameTypes.kts,
        //            tests/testPushFrameReachesClientOverWire.kts,
        //            tests/testConnectionCloseListenerFiresOnAbruptClientKill.kts,
        //            tests/testSlowCloseListenerRunsOffEventLoop.kts,
        //            tests/testPushOnDeadConnectionThrowsOverWire.kts,
        //            tests/testTcpPushIsBoundedWhenClientStopsReading.kts,
        //            tests/testConcurrentPushesFromMultipleThreadsAllDelivered.kts,
        //            tests/testReconnectOldSenderFailsAndDoesNotWriteToNewConnection.kts.
        // 0.0.303: Replace the inbound-substream counter cap (#294/0.0.302) with TCP
        //          autoRead backpressure. The counter cap bounded the COUNT of
        //          admitted substreams but NOT the heap: jvm-libp2p builds the
        //          MuxChannel + pipeline + Negotiator scaffolding before the
        //          streamPreHandler hook, and reset() cannot reclaim it faster than
        //          a saturated event loop creates more — a production dump showed
        //          35,783 live MuxChannels OOMing a 128MB heap *despite* the cap
        //          (ContainerNursery #459). InboundSubstreamAdmissionControl now
        //          pauses autoRead on the connection's parent channel at the
        //          per-connection (256) and global (1024) caps, so the remote stops
        //          sending new mplex NEW_STREAM frames (creation throttled at the
        //          kernel/TCP layer, below the saturated loop), resuming below a
        //          low-water mark. reset() is kept only as a race fallback. See
        //          tests/stressTestInboundSubstreamsAreBoundedPerConnection.kts.
        // 0.0.302: Add inbound substream admission control (#294, PR #299) — the
        //          counter-cap first attempt; superseded by 0.0.303 above.
        // 0.0.300: Add a coarse outbound-fan-out safety net,
        //          stressTestRelayGossipForwardingSurvivesStalledPeerFanoutWithConstrainedHeap: a child
        //          relay JVM (-Xmx128m) fans sustained ServiceAnnouncement gossip out to several
        //          registered peers whose TCP reads are stalled, and must survive. Guards
        //          RelayService.forwardGossipToRegisteredPeers against a regression that reintroduces
        //          unbounded outbound accumulation (the broadcast-machinery OOM class from the
        //          2026-06-10 heap dump). NOT a guard for the effectiveIsWritable() parent-chain fix —
        //          that stays covered by testWriteFramedBufferBoundsParentConnectionWhenStalled. No
        //          production-code change; coordinate bump forces recompilation so the reused
        //          testing/RelayLeakOomReproChild is present in the artifact the test resolves.
        // 0.0.298: Keep relay discovery fresh so NAT'd nodes can fail over. announceAsRelay()
        //          now returns early unless this node is actually relaying (isRelaying) and not
        //          closed, and start() schedules a periodic re-announce every
        //          relayAnnounceIntervalMs (default 30s) so a relay that comes up after a NAT'd
        //          node already gossiped stays discoverable. Without this, knownRelays could go
        //          permanently stale and alternativeRelaySelector had nothing to fail over to.
        //          Tests: testRelayPeriodicallyReAnnouncesItself,
        //          testRelayIncapableNodeDoesNotAnnounceAsRelay.
        // 0.0.294: Apply outbound write backpressure on the PARENT connection chain, not just the
        //          mux substream. writeFramedBufferWithBackpressure gated only on the substream's
        //          isWritable; since substream writes flow straight through to the underlying TCP
        //          connection, the substream stayed writable while the connection's outbound buffer
        //          grew without bound when a peer stalled at the TCP layer. Production heap dump
        //          (kotlin-build-ci OOM, 2026-06-10): one NioSocketChannel held 310,898
        //          flushed-but-undrained outbound entries (~33 MB) + ~470K promise objects while
        //          every substream reported writable. New effectiveIsWritable() walks channel.parent()
        //          so backpressure engages on the stalled connection. See
        //          tests/testWriteFramedBufferBoundsParentConnectionWhenStalled.kts.
        // 0.0.293: Fix RelayService.unregisterFromRelay() silently undoing itself.
        //          unregisterFromRelay() closed the relay stream and nulled relayConnection
        //          but did NOT cancel the background reconnection task (which by design
        //          "NEVER gives up") nor clear registeredRelayPeerId / requestHandler. So
        //          ~baseReconnectDelayMs (5s) after registering, the reconnection task fired,
        //          saw relayConnection == null with the registration state still populated,
        //          and called doRegisterWithRelay() — RE-REGISTERING the peer that was just
        //          intentionally unregistered. The fix cancels the reconnection task and
        //          clears the registration state in unregisterFromRelay() (mirroring close()'s
        //          teardown, but leaving the executor running so the service stays reusable).
        //          Test: testUnregisterFromRelayStopsReconnectionAndDoesNotResurrect
        //          (two real libp2p hosts; RED before, GREEN after). Also corrects
        //          testRelayAutoReconnectionUsesAlternativeSelector, which had used
        //          unregisterFromRelay() to fake a connection loss.
        // 0.0.292: Stream the service-provider OPTIMIZED bytecode-serve response
        //          instead of materializing it ~5x in heap. The
        //          supportsSandboxedExecution() branch of
        //          ServiceRoutingHandler.handleBytecodeRequest previously called
        //          BytecodeProtocol.createResponse(jarBytes) (base64 String +
        //          inner JSON String) then RpcResponse.success(...).toJson()
        //          .toString().toByteArray() (outer JSON String + encoded byte[]),
        //          holding ~15-25 MB transient per in-flight serve for a 1.7-2.4 MB
        //          JAR. On a -Xmx128m ContainerNursery-launched service JVM
        //          (production-health-server.jar, docker-run-server.jar) this OOM'd
        //          under concurrent load so the serve could not finish inside the
        //          client's 30 s bytecode-request bound (client read 0 bytes /
        //          timed out). The serve path now returns a StreamingBytecodeResponse
        //          marker that the stream-write sites (TcpServer,
        //          Libp2pHostFactory.writeStreamingBytecodeMessage) recognise and
        //          stream to the transport via BytecodeResponseStreamer with bounded
        //          base64 chunks — peak heap ~jarBytes.size + a fixed buffer. The
        //          wire format is byte-compatible with the existing
        //          BytecodeProtocol.parseResponse + RpcResponse.fromJson client path.
        //          Test: testBytecodeServeUnderConstrainedHeapDoesNotOom (serves a
        //          2.4 MB JAR to 20 concurrent clients in a -Xmx128m child JVM;
        //          pre-fix the child reliably OOMs, post-fix it survives and serves
        //          every request byte-exact).
        // 0.0.291: Make connectToRelay's TCP reachability probe non-blocking.
        //          0.0.290 introduced a short reachability probe to fail fast on
        //          unreachable relays, but implemented it as a blocking
        //          java.net.Socket.connect on ForkJoinPool.commonPool — which parks a
        //          commonPool worker (and the caller) for up to the 2s reachability
        //          window on an unreachable address. probeReachableAsync now uses an
        //          AsynchronousSocketChannel: the connect result arrives as an OS event
        //          and the timeout is a scheduled CompletableFuture completion
        //          (completeOnTimeout), so no thread is parked during the probe. The
        //          probe and handshake are composed into one non-blocking per-address
        //          pipeline; the only blocking wait left anywhere in connectToRelay is
        //          the single resultReady.get() on the caller's own thread. Behaviour is
        //          unchanged: unreachable relays still fail fast (~2s, when the last
        //          probe times out), slow-but-good handshakes still complete under the
        //          generous budget, and addresses still race in parallel.
        //          Tests: testRelaySlowHandshakeRegistrationSucceeds,
        //          testConnectToRelayTimeoutIsTwoSeconds (both from 0.0.290) still pass.
        // 0.0.290: Fix the flaky 2s relay cold-dial TimeoutException
        //          (stressTestRelayRejectsLateAnnouncementFromDisconnectedPeer,
        //          buildtest 61b3b6a9). RelayService.connectToRelay's slow path used
        //          to open the relay stream by BLOCKING a thread of the class's
        //          2-thread executor (shared with keepalive/reconnect/routing) on
        //          streamFuture.controller.get(...) AND blocking the caller on a queue
        //          poll — two pool threads per dial. To keep keepalive alive the
        //          per-attempt budget had been driven down to 2s (#109/#189), which is
        //          too tight for a cold libp2p Noise handshake on a CPU-saturated host
        //          or a laggy path, so a healthy connection got abandoned and
        //          registerWithRelay threw TimeoutException. The dial is now split into
        //          a short (2s) TCP reachability probe — so a genuinely unreachable
        //          relay still fails fast and failover stays quick — followed by a
        //          future-composed handshake (completed on libp2p's Netty event loop,
        //          parking no pool thread) under a generous 30s budget, so a slow but
        //          successful handshake simply completes. Addresses still race in
        //          parallel. Tests:
        //            testRelaySlowHandshakeRegistrationSucceeds (new — a latency proxy
        //              delays the handshake ~3.5s past the old 2s budget; RED before,
        //              GREEN after)
        //            testConnectToRelayTimeoutIsTwoSeconds (unreachable relay still
        //              fails in ~2s via the reachability probe)
        // 0.0.282: Enforce JSON structural caps on inbound messages to close
        //          the Libp2pRpcProtocol.readMessage OOM/DoS reported in #268.
        //          Every readMessage path (Libp2pRpcProtocol, NettyStreamController,
        //          RelayStreamController) now runs Libp2pRpcProtocol.parseValidatedJsonBody,
        //          which fails fast with an IOException when a 10 MB-framed body
        //          would otherwise blow up org.json's recursive parser:
        //            MAX_JSON_NESTING_DEPTH=64        — prevents [[[…1M…]]] stack/heap blowup
        //            MAX_JSON_STRING_LENGTH=8 MB      — prevents {"k":"<10M A's>"} grow-buffer doubling
        //                                              while leaving room for legitimate base64-encoded
        //                                              ByteArray RPC payloads up to ~6 MB
        //            MAX_JSON_ELEMENT_COUNT=1 000 000 — prevents [1,1,1,…] boxed-Integer flood
        //          Validator is a single byte-level pass over the body, so it
        //          adds ~constant overhead on legitimate traffic but rejects
        //          adversarial payloads before any heavyweight allocation.
        //          Tests:
        //            testReadMessageRejectsDeeplyNestedJson
        //            testReadMessageRejectsHugeStringField
        //            testReadMessageRejectsTooManyElements
        //            testReadMessageRejectsUnterminatedHugeString
        //            testReadMessageAllowsDepthAtLimit
        //            testReadMessageAllowsStringAtLimit
        //            testReadMessageAllowsWellFormedRpc
        //            testReadMessageStringWithStructuralCharsNotCountedAsDepth
        // 0.0.276: Republish of 0.0.275 with PR #253 included.
        //          The 0.0.275 jar published to kotlin.directory was built from PR #252's
        //          branch and predates the merge of PR #253, so the cached 0.0.275 artifact
        //          does not contain the PeerRegistry global cap fix. Bumping to 0.0.276
        //          forces buildSimpleKotlinMavenArtifact to recompile from current main
        //          source, which includes both fixes.
        //          - PR #253: Cap PeerRegistry size at 1000 peers with longevity+recency
        //                     eviction. Fixes ~6/12h ContainerNursery OOMs caused by
        //                     unbounded peer-set growth (each peer holding up to 20
        //                     ~157-byte multiaddr strings).
        //          - PR #252: Per-stream pending-processing queue cap (already noted below).
        // 0.0.275: Bound RelayServerMessageHandler per-stream pending-processing queue.
        //          Fixes the inbound message-processing queue leak that surfaced as
        //          repeating ~200 MB JVM heap dumps and OOM crashes on the BuildTest WUI
        //          on 2026-05-03 (and across other UrlProtocol-linked processes on the
        //          same host). Root cause: forwardRequestToRegistered blocks on
        //          `future.get(30s)` waiting for the registered target peer's response.
        //          While that single coroutine holds the limitedParallelism(1) dispatcher
        //          slot, every subsequent inbound message on the same stream was queued
        //          at scope.launch with no per-stream inbound backpressure — the queue
        //          grew unbounded and pinned heap until OOM (~30 000 pending coroutines
        //          × ~5 KB each ≈ 150 MB in the production heap dump).
        //          Fix: at scope.launch time, if the per-stream pending-processing queue
        //          is already at the pause threshold (100), drop the inbound message and
        //          pause Netty's autoRead. Drop is the correct overload-shedding behaviour
        //          for relay traffic — RelayRequest senders time out and retry, gossip
        //          is re-announced periodically, RelayResponse loss converts to a caller
        //          timeout, and dropping is strictly preferable to OOMing the whole
        //          process and tearing down every concurrent stream. The autoRead pause
        //          propagates TCP-level flow control to the peer's send-side once
        //          already-decoded frames in the Netty pipeline have drained. When the
        //          queue subsequently falls back below the resume threshold (50) the
        //          handler re-enables autoRead on the channel's event loop.
        //          Adds three end-to-end tests:
        //            stressTestRelayInboundQueueIsBoundedWhenForwardTargetHangs,
        //            stressTestRelayInboundBackpressureResumesAfterQueueDrains,
        //            stressTestRelayProcessSurvivesOomFloodWithConstrainedHeap (high-
        //              level OOM reproducer: child JVM with -Xmx128m survives the same
        //              flood that took down the production WUI).
        // 0.0.227: Implement sendServiceRpcRequest with cached streams and fine-grained locking
        //          - sendServiceRpcRequest now uses a cached RpcStream per service URL
        //          - Multiple concurrent callers share a single stream with fine-grained
        //            synchronized(output) locking inside RpcStream.sendRequest(), maximizing
        //            concurrency without application-level locks
        //          - Per-service stream creation lock prevents duplicate connections under
        //            contention (20+ threads)
        //          - Automatic reconnection when a cached stream is closed or broken
        //          - Fix: TcpRpcStream and Libp2pRpcStream reader loops now set closed=true
        //            on exit, so isOpen correctly reports broken connections
        // 0.0.118: Fix relay registration cleanup bug
        //          - Bug: When a peer opens multiple streams to relay (e.g., reconnection),
        //            closing an EARLIER stream would remove the registration that belongs
        //            to a LATER stream, causing "Target peer not registered" errors
        //          - Fix: Check if closing stream's controller matches current registration
        //            before removing from registeredPeers map
        // 0.0.117: (duplicate publish - skipped)
        // 0.0.116: Add sendServiceRpcRequest() for sandbox RPC support
        //          - Public method for sending RPC requests to url:// services
        //          - Used by foundation.url:resolver's RpcAwareSandboxedConnection
        //          - Enables client code in SJVM sandbox to make RPC calls to servers
        // 0.0.111: Fix connection/stream leak in gossip, relay, and ping paths
        //          - Add cleanupStreamFuture() to close leaked NioSocketChannel/ConnectionBuilder
        //          - Fix sendGossipToPeer, connectWithRelayFallback, pingDirectSecure cleanup
        //          - Cancel all futures on broadcastGossipMessage timeout
        //          - Prevents OOM from accumulated CompletableFuture/NioSocketChannel instances
        // 0.0.110: Fix observation log persistence and peer protection bugs
        //          - Fix: observation log persistence now preserves full history on reload
        //            (counts, firstSeenMs, consecutiveFailures, failure-only peers)
        //          - Fix: findMostRecentPeers excludes never-contacted peers from protection
        // 0.0.109: Remove SJVM/ASM dependencies - sandbox execution moved to foundation.url:resolver
        //          - Deleted SandboxedConnection, SandboxedProxyGenerator, TypeMarshaling
        //          - Deleted sandbox/testing/* (SjvmTestHelper, TestBytecodeGenerator, etc.)
        //          - Made requestBytecodeFromPeer() public, added requestBytecodeFromService()
        //          - Removed openSandboxedConnection() and resolveSandboxedInterface() from UrlResolver
        //          - BytecodeProtocol, BytecodeRequest/Response, JsonSerialization remain
        // 0.0.109: Add peer scoring, intelligent pruning with exponential backoff
        //          - PeerScorer: reliability scores based on longevity, reliability, recency, consistency
        //          - PeerPruner: protected peers (top 10 recent + top 10 stable), grace periods
        //          - PeerObservationLog: tracks per-peer contact history with self-online awareness
        //          - PeerRegistry.pruneWithScoring(): replaces simple age-based pruning
        //          - Exponential backoff for check intervals (5min to 6h)
        // 0.0.108: Merge UrlResolver into UrlProtocol
        //          - All UrlResolver source code moved into foundation.url.protocol package
        //          - Includes UrlResolver, RemoteAiCliPty, ServiceRegistration, sandbox support
        //          - No behavioral changes, only package consolidation
        // 0.0.107: (stale - published before merge was complete)
        // 0.0.106: (stale - published before merge was complete)
        // 0.0.105: All nodes act as relays by default - no standalone relay service
        //          - Removed standalone relay server from Main.kt
        //          - RelayService.isRelaying no longer requires public IP
        //          - All UrlProtocol instances participate in gossip and relay
        //          - Even NAT-ed nodes announce as relays and accept relay registrations
        // 0.0.104: Relay cache API for gossip handler integration (late-joiner fix)
        // 0.0.103: Cache and replay ServiceAnnouncements to late-joining relay peers
        // 0.0.102: Fix WASMSERVER_BOOTSTRAP_SEED, add HCF daemon bootstrap peer
        // 0.0.101: Add HCF daemon bootstrap peer (wrong CN seed)
        // 0.0.100: Fix stream initiator detection in multiplexed connections
        // 0.0.137: Prioritize bootstrap relays when selecting from circuit addresses
        //          - Adds isBootstrapRelayAddress() to identify known reliable relays
        //          - Relay selection now prioritizes: bootstrap relays > public IPs > others
        //          - Fixes issue where NAT'd peer IPs (valid public IPs but unreachable from
        //            outside the NAT) were being selected over known reliable relays
        // 0.0.136: Fix circuit address relay extraction to prefer public relays
        //          - When extracting relays from circuit addresses (fallback path), now prefers
        //            relays with public IPs over NAT'd peers
        //          - Previously, the code picked the first circuit address without checking
        //            if the relay was publicly reachable, often selecting unreachable NAT'd peers
        //          - Added isPublicMultiaddress() helper to check if address has public IP
        //          - Collects all potential relays and sorts by public IP preference
        // 0.0.135: Fix relay selection to prefer publicly reachable relays
        //          - Add getPubliclyReachableRelays() to filter relays with public IP addresses
        //          - selectBestRelay() now prefers relays with public IPs over NAT'd relays
        //          - Filters out relays that only have private/local IPs or circuit addresses
        //          - Prevents nodes from trying to connect to unreachable NAT'd peers as relays
        //          - Added isPublicAddress() and isPublicIpv4() helper functions
        // 0.0.129: Prioritize bootstrap peers for relay registration
        //          - When registering with relays, try bootstrap peers (ContainerNursery,
        //            HardwareFabricDaemon) before other peers in the registry
        //          - Stale/unreachable peers in the registry would cause registration failures
        //            because they were tried before the reliable bootstrap relays
        //          - Added getBootstrapPeerIds() helper function
        //          - Sorting: bootstrap peers (score 2) > direct public IPs (score 1) > others (0)
        // 0.0.128: Always include circuit relay addresses in announcements (v2)
        //          Previously, nodes with STUN-discovered public IPs would NOT include
        //          circuit relay addresses, assuming they were directly reachable.
        //          However, many NAT configurations (symmetric NAT, firewalls) block
        //          incoming connections even when STUN reports a public IP.
        //          Now circuit relay addresses are ALWAYS added as fallback when
        //          publicly routable relay peers are known.
        // 0.0.127: (skipped - published without fix)
        // 0.0.126: (skipped - published without fix)
        // 0.0.133: More reliable relay connection management
        //          - Require 2 consecutive keepalive failures before marking connection dead
        //            (previously a single timeout would mark connection dead)
        //          - Increase pong timeout from 1/3 to 2/3 of keepalive interval (10s -> 10s for 15s interval)
        //          - Reduce default keepalive interval from 30s to 15s to catch NAT timeouts earlier
        //          - These changes prevent false positives from network hiccups while still
        //            detecting dead connections within a reasonable time frame
        // 0.0.132: Fast-path resolution for services with peer ID in identifier
        //          - Skip 5-second relay registration wait when service identifier contains
        //            a peer ID (e.g., w3wallet.daemon.12D3KooWxxx)
        //          - In this case, circuit addresses can be built directly from bootstrap peers
        //          - Significantly reduces join time for new UrlResolver instances when
        //            connecting to services with known peer IDs
        // 0.0.125: Fix NAT timeout detection - use bidirectional ping/pong for keepalives
        //          instead of unidirectional keepalive messages. This detects dead connections
        //          even when TCP send succeeds but the relay never receives the message.
        //          Also fix registration timeout bug where RegisteredPeer used default timeout.
        // 0.0.139: Distance vector routing for multi-hop relay forwarding
        //          - Add RoutingTable class implementing Bellman-Ford distance vector algorithm
        //          - RelayService broadcasts distance vector updates every 30 seconds
        //          - Relay requests can now be forwarded through intermediate nodes
        //          - Split horizon prevents routing loops
        //          - Routes expire after 5 minutes of no updates (stale route pruning)
        //          - All nodes automatically participate as routers
        // 0.0.138: Fix ConcurrentLinkedQueue<Byte> memory leak causing OOM
        //          - RelayStreamController and NettyStreamController were using
        //            ConcurrentLinkedQueue<Byte> for read buffers, creating one Node
        //            object (24 bytes overhead) per byte of incoming data
        //          - With 7.7 million bytes transferred, this created 185 MB of Node objects
        //            that eventually exhausted the heap (242 MB default)
        //          - Changed to ArrayDeque<ByteArray> which buffers chunks instead of
        //            individual bytes, reducing memory overhead from ~24x to negligible
        // 0.0.141: Fix IPv6 loopback addresses (::1) being announced to external peers
        //          - Root cause fix for intermittent relay connection failures
        //          - recordObservedAddress(): Added /::1/ filter to prevent IPv6 loopback
        //            from being recorded and later announced via gossip
        //          - getEffectiveAddresses(): Rewrote to filter loopback addresses from
        //            announcements and return null for wildcards when no public IP is known
        //          - Fixes failures like "Failed to connect to relay /ip6/::1/tcp/44077/p2p/..."
        //            where peers would announce their loopback address to external peers
        // 0.0.140: Auto-join network for sendServiceRpcRequest and findPeersForService
        //          - Fix: sendServiceRpcRequest() and findPeersForService() now automatically
        //            call ensureNetworkJoined() before attempting to find peers
        //          - Previously only resolve() auto-joined, causing API inconsistency
        //          - Clients no longer need to manually call joinNetwork() or discoverPeers()
        // 0.0.142: Fix immediate gossip sharing for new peers joining via PeerExchange
        //          - Add RelayService.getCachedServiceAnnouncements() to expose cached announcements
        //          - sendDiscoveredServiceAnnouncementsToPeer() now combines discoveredServices
        //            AND RelayService's cached announcements for immediate delivery
        //          - New peers receive ALL service announcements within milliseconds, not 30-60 seconds
        //          - Add comprehensive e2e tests for immediate gossip sharing
        // 0.0.137: Prioritize bootstrap relays for relay registration
        //          - Known reliable relays (ContainerNursery, HCF daemon) are tried first
        //          - Fixes issue where NAT'd peers were tried before reliable bootstrap relays
        // 0.0.144: Parallel relay address connection - fixes 10+ second delay on first request
        //          when one relay address (e.g., HCF daemon on port 44605) doesn't support relay
        //          protocol. Now all addresses are tried in parallel, using first success.
        // 0.0.145: Parallel relay PEER registration - fixes sequential timeout issue where
        //          the daemon would waste 5+ seconds timing out on HCF daemon before trying
        //          the markdown relay. Now tries multiple relay peers in parallel.
        // 0.0.150: Fix RoutingTable.addNeighbor clearing existing services
        //          - Bug: When addNeighbor() is called for a peer that already has a route
        //            with services (from distance vector), the services were incorrectly
        //            cleared from the service index because addNeighbor passed empty services
        //          - Impact: Peers discovered via distance vector that then register directly
        //            would lose their service advertisements, becoming undiscoverable
        //          - Fix: Preserve existing services when updating route in addNeighbor()
        //          - Added e2e test: testRoutingTableAddNeighborPreservesExistingServices
        // 0.0.149: Fix executor thread leak in async processing
        //          - Bug: Code was creating new SingleThreadExecutor instances at:
        //            * processInitialMessages(): Executors.newSingleThreadExecutor().execute { ... }
        //            * connectToRelayParallel(): CompletableFuture.supplyAsync({...}, Executors.newSingleThreadExecutor())
        //          - These executors were never shut down, leaking ~2 threads per registration cycle
        //          - Fix: Reuse the class-level `executor` field which is properly shut down in close()
        //          - Added e2e test: testRelayServiceNoExecutorThreadLeakOnReconnection
        // 0.0.148: Fix: Always wait for relay registration before resolution
        //          - Removed the "fast-path" optimization that skipped waitForRelayRegistration()
        //            when the service identifier contained a peer ID (like w3wallet.daemon.12D3KooW...)
        //          - This optimization was fundamentally flawed because:
        //            1. queryRelayForPeer() checks local state, not relay state
        //            2. buildCircuitAddressesForPeer() requires publicly routable addresses
        //            3. The relay must send cached service announcements before resolution can work
        //          - Fixes "No resolver registered for service" errors in production
        // 0.0.146: Async initial message processing - fixes 5+ second delay caused by
        //          processInitialMessages() blocking synchronously. Previously, the relay
        //          would send 40+ cached service announcements after ACK, and processing
        //          them synchronously (200ms timeout per message) would take 8+ seconds.
        //          This caused waitForRelayRegistration() to timeout before
        //          registeredWithRelay.set(true) was called. Now processInitialMessages()
        //          runs asynchronously in a background thread, allowing registration to
        //          complete immediately after ACK.
        // 0.0.152: Fix executor thread leak in connectWithRelayFallback and guard registration
        //          - Bug: Code created new SingleThreadExecutor instances per parallel operation
        //            via CompletableFuture.supplyAsync({...}, Executors.newSingleThreadExecutor())
        //            but never shut them down, leaking threads over time
        //          - Fixed locations:
        //            * connectWithRelayFallback(): parallel connection attempts (~line 1580)
        //            * tryRegistrationAsGuardNodeForCircuitRelay(): parallel relay registration (~line 2326)
        //          - Fix: Use shared FixedThreadPool with proper finally{} shutdown
        //          - Added e2e test: testExecutorPoolShutdownInConnectWithRelayFallback
        // 0.0.151: Deprecate discoverPeers() - users should not call this method directly
        //          - Peer discovery is fully automatic via gossip protocol
        //          - openConnection() automatically joins the network and waits for service
        //            announcements if called before discovery is complete
        //          - Updated class and method documentation to explain automatic discovery
        //          - Removed discoverPeers() and joinNetwork() from README API reference
        // 0.0.153: Move UrlResolver to foundation.url:resolver module
        //          - UrlResolver, UrlResolutionException, ConnectedPeer, PeerCircuitBreaker
        //            now live in foundation.url:resolver
        //          - Make ServiceBroadcaster, ServiceRegistrationImpl, LocalServiceRegistry,
        //            ServiceRoutingHandler, RpcStreamConnection public for external use
        //          - UrlProtocol now contains only low-level P2P protocol functionality
        //          - No SJVM knowledge in UrlProtocol
        // 0.0.160: Fix relay request handling when target is self
        //          - When a peer receives a relay request where IT is the target, handle locally
        //          - Previously, the peer would try to route to itself and fail with "No route to target peer"
        //          - This is critical for NAT-ed peers receiving requests via relay
        //          - Added setRequestHandler() for relay peers that also provide services
        //          - Added setAlternativeRelaySelector() for relay failover
        // 0.0.158: Alternative relay selection for failover
        //          - When current relay fails repeatedly (3+ consecutive failures), try alternative relays
        //          - Added setAlternativeRelaySelector() callback for custom relay selection
        //          - UrlProtocol automatically uses RelayDiscovery to find publicly reachable alternatives
        //          - Fixes issue where daemon keeps retrying dead relay with exponential backoff
        //            instead of finding a working alternative
        //          - Faster recovery when relay peers go offline or become unreachable
        // 0.0.165: Add pingPeer() method for peer reachability testing
        //          - Public fun pingPeer(peerId, timeoutMs): Long? returns latency or null
        //          - Tries direct connection first, then relay if enabled
        //          - Add constructor accepting existing PeerRegistry for UrlResolver delegation
        //          - Helper methods: pingDirectSecure, pingPeerViaRelay, extractRelayFromCircuitAddress
        // 0.0.164: (stale - republished without code changes)
        // 0.0.163: Add getBootstrapPeerIds() to companion object
        //          - Returns the peer IDs of default bootstrap peers
        //          - Allows UrlResolver to delegate to UrlProtocol for bootstrap peer ID lookup
        // 0.0.175: Fix RpcStreamHandlerPool preventing concurrent RPC request handling
        //          - Bug: LinkedBlockingQueue(100) with corePoolSize=4 meant only 4 handler
        //            threads would ever run concurrently, because new threads beyond core size
        //            are only created when the queue is FULL (104 pending tasks). Since each
        //            handleStream() loop occupies a thread for the connection's lifetime, the
        //            5th+ concurrent RPC streams would queue behind occupied threads instead
        //            of being handled in parallel.
        //          - Fix: Replace LinkedBlockingQueue with SynchronousQueue for direct handoff.
        //            Each incoming stream now immediately gets its own handler thread (up to
        //            maxPoolSize=64), ensuring concurrent request handling.
        // 0.0.174: Version bump
        // 0.0.214: Fix two concurrency bugs:
        //          1. PeerRegistry.addPeer: non-atomic getOrPut on serviceIndex caused peer
        //             IDs to be silently lost. Changed to computeIfAbsent (atomic on CHM).
        //          2. GossipMessageTracker.recordMessage: stale-read race on expired entries
        //             allowed duplicate message processing. Changed to atomic CAS via replace().
        // 0.0.212: Fix non-atomic _requestCount++ race in ServiceRegistrationImpl.
        //          Changed _requestCount from plain Long to AtomicLong, added @Volatile
        //          to _isActive, _announcedToPeerCount, and _multiaddresses.
        // 0.0.213: Transparent ByteArray encoding in RPC layer
        //          - ByteArray values in params/results automatically encoded as {"__type":"bytes","__value":"<base64>"}
        //          - Encoding/decoding happens in RpcRequest.toJson/fromJson and RpcResponse.toJson/fromJson
        //          - Makes ByteArray support transparent to ServiceHandler implementations and RPC callers
        // 0.0.220: Fix race condition where buffered gossip data is dropped when stream closes
        //          - readBytesWithDeadline checked closed.get() in while condition, causing it
        //            to exit without reading buffered data when the sender closes the stream
        //            before the receiver's pool thread starts reading
        //          - Both handleStream() methods checked isClosed() before attempting to read,
        //            skipping buffered messages when channelInactive fires before the loop starts
        //          - Fix: Check closed state AFTER checking buffer, and remove isClosed() from
        //            handleStream loop condition so readMessage() can drain buffered data first
        // 0.0.219: Add idle timeout to RPC stream handlers to prevent thread pool saturation
        //          - NettyStreamController.readMessage(timeout, unit) for deadline-based reads
        //          - Both handleStream() methods now use 120s idle timeout (configurable)
        //          - Idle streams are closed automatically, reclaiming pool threads
        //          - Root cause: handleStream() blocked indefinitely on readMessage() with no timeout,
        //            holding a pool thread for the entire connection lifetime even when peer was gone
        // 0.0.218: Remove verbose PeerRegistry logging in findPeersForService
        //          - Removed per-call logging that dumped entire serviceIndex.keys and peers.keys
        //          - With many services, these logs produced gigabytes of output causing CI timeout
        //          - Reduced addPeer log to show count instead of all service keys
        // 0.0.217: Fix concurrent relay registration race condition
        //          - Added @Synchronized to registerWithRelay() to prevent concurrent
        //            relay registration calls from interfering with each other
        //          - Bug: When multiple relay registrations ran in parallel,
        //            cleanupListenerAndKeepalive() in the second registration would kill
        //            the first registration's listener mid-delivery of service announcements,
        //            causing incomplete service discovery (e.g., receiving 1 of 10 announcements)
        //          - Fix: Synchronize registerWithRelay() so registrations are serialized
        // 0.0.223: Gossip handler exception isolation - handler crashes no longer kill P2P connections
        //          - All 7 gossip handler branches wrapped in try-catch in both handleStream methods
        //          - Fire-and-forget handlers (ServiceAnnouncement, ServiceWithdrawal, PeerAnnouncement,
        //            RelayAnnouncement, RelayWithdrawal): exception logged, connection continues
        //          - Response-expecting handlers (ServiceQuery, PeerExchange): exception logged,
        //            empty response sent back to querying peer, connection continues
        // 0.0.222: Robust error handling in handleStream - survive malformed messages and handler crashes
        //          - Catch JSONException from readMessage() for syntactically invalid JSON (connection survives)
        //          - Catch JSONException from parseMessage() for missing "type" field (connection survives)
        //          - Catch exceptions from requestHandler.handleRequest(), send error response to client
        //            instead of killing the connection (subsequent requests continue working)
        // 0.0.221: Fix resource leak on pool rejection + unknown message type forward compatibility
        //          - RpcStreamHandlerPool.submit() now closes controller on RejectedExecutionException
        //          - handleStream() catches IllegalArgumentException from parseMessage() and continues
        //            instead of terminating the connection on unknown message types
        // 0.0.223: (see above)
        // 0.0.226: Replace thread pool + runBlocking with coroutine dispatch for RPC requests
        //          - rpcRequestExecutor (CachedThreadPool) replaced with per-stream CoroutineScope
        //            using Dispatchers.Default, so thread count stays bounded (~availableProcessors)
        //            instead of one OS thread per concurrent request
        //          - In-flight handlers are cancelled via scope cancellation when stream closes,
        //            so cooperative suspend handlers (using delay/yield/ensureActive) are promptly
        //            cancelled instead of running to completion with no external cancellation
        //          - SupervisorJob ensures one failed handler doesn't cancel others
        //          - CancellationException is caught separately to avoid sending error responses
        //            for handlers that were intentionally cancelled on stream close
        //          - UnifiedRpcProtocol updated
        // 0.0.225: Parallel RPC request processing within a single P2P stream
        //          - handleStream now dispatches RPC requests to a thread pool instead
        //            of processing them sequentially in the reader loop
        //          - A slow RPC handler no longer blocks subsequent requests on the same
        //            connection from being processed and returning results
        //          - All writes to the output stream are synchronized to prevent interleaving
        //          - Reader loop waits up to 10s for in-flight requests before closing stream
        //          - UnifiedRpcProtocol updated
        // 0.0.224: Fix ByteArray serialization in JsonSerialization for SJVM sandbox boundary
        //          - Bug: ByteArray fell through to generic object serializer in toJsonValue(),
        //            producing {"__type":"[B"} without __value, losing the actual byte data
        //          - Fix: Add explicit ByteArray handling in serialize(), toJsonValue(),
        //            deserialize(), and deserializeElement() using Base64 encoding
        //          - ByteArray is now encoded as {"__type":"bytes","__value":"<base64>"},
        //            consistent with Libp2pRpcProtocol.encodeValueForJson()
        // 0.0.229: Add direct reachability tracking to PeerRegistry
        //          - PeerRegistry now tracks which peers were directly reachable (without relay)
        //          - New methods: recordDirectReachability(), isDirectlyReachable(),
        //            getLastDirectConnectionMs()
        //          - Direct reachability is a per-observer property: each node tracks which
        //            peers it can reach directly vs only via relay
        //          - pingPeer() automatically records direct reachability when pingDirectSecure()
        //            succeeds
        //          - connectToPeer() records direct reachability for non-circuit-relay connections
        //          - Data persists to disk as direct-reachability.json alongside peer files
        //          - Reachability expires after 10 minutes without a new direct connection
        //          - removePeer() cleans up associated reachability data
        // 0.0.237: Remove STUN — use Identify protocol for public IP discovery
        //          - Removed all STUN code (STUN_SERVERS, discoverPublicIpViaStun,
        //            queryStunServer, parseStunResponse, startBackgroundStunDiscovery)
        //          - getMostObservedIp() now returns: explicit IP > Identify observation
        //          - Public IP is discovered via libp2p Identify (/ipfs/id/1.0.0) which
        //            reports observed address after each peer connection
        //          - No external STUN server dependencies required
        // 0.0.234: Fix PeerExchange handler responding after blocking onPeersReceived
        //          - PeerExchange handler now sends response BEFORE calling onPeersReceived()
        //          - onPeersReceived() triggers broadcastGossipMessage() and
        //            sendServiceAnnouncementsToPeer() which block for seconds when
        //            peers are behind NAT (1s timeout per address attempt)
        //          - The requesting peer's 2-second read timeout would expire before
        //            receiving the response, silently failing the synchronous pull path
        //          - Fix applied to both handleStream() locations (Netty and unified)
        // 0.0.235: Fix slow initial relay connection (~5 seconds -> ~5ms)
        //          - Add existing-connection fast path to connectToRelay(): checks
        //            host.network.connections for an existing TCP connection to the relay
        //            peer (established during bootstrap) and opens a new Mplex stream on
        //            it (~5ms) instead of establishing a new TCP connection from scratch
        //          - Replace 10ms polling loop in slow path with CompletableFuture.anyOf()
        //            for immediate notification when first address succeeds
        //          - Add [RELAY-TIMING] instrumentation to sendViaRelay() measuring
        //            connect, send, wait, and total time for production diagnostics
        // 0.0.239: Filter circuit relay addresses in connectToRelay() slow path
        //          - /p2p-circuit/ addresses can't be used with host.newStream() directly
        //            and waste time failing with NothingToCompleteException
        //          - Reduce slow path connection timeout from 5s to 2s (bootstrap peers
        //            respond in <100ms, 5s just delays failure on stale peers)
        // 0.0.246: Fix Dispatchers.Default thread starvation for RPC request handlers
        //          - Changed rpcRequestDispatcher from Dispatchers.Default to Dispatchers.IO
        //          - Dispatchers.Default is a shared global dispatcher; when blocking handlers
        //            (e.g., Thread.sleep, blocking I/O) occupied all Default threads, subsequent
        //            RPC requests could not be dispatched, causing sequential processing
        //          - Dispatchers.IO is designed for blocking operations and has a separate,
        //            larger thread pool (64 threads by default)
        // 0.0.247: Fix stale peer propagation in onPeerExchangeRequest()
        //          - Peers must now have at least one successful observation before being
        //            shared via gossip (snapshot != null && lastSuccessMs > 0)
        //          - Previously, peers with null snapshots (never verified) were shared,
        //            causing gossip-discovered but never-pinged peers to propagate
        //            indefinitely across the network
        // 0.0.248: Record peer liveness on direct contact and async onPeersReceived
        //          - onServiceAnnouncement/onPeerAnnouncement now call recordSuccess()
        //            since receiving these means the peer directly connected to us
        //          - onDirectPeerContact callback in Libp2pHostFactory for recording
        //            liveness when any peer opens a stream
        //          - onPeersReceived dispatched asynchronously via coroutines to avoid
        //            blocking the message loop when the handler is slow
        // 0.0.249: Fix Dispatchers.IO thread starvation for RPC request handlers
        //          - Replaced shared Dispatchers.IO with a dedicated cached thread pool
        //            (rpcRequestDispatcher) for RPC request coroutines
        //          - Prevents thread starvation when Dispatchers.IO is saturated by leaked
        //            coroutines from unclosed UrlProtocol2 instances or other IO operations
        //          - Fixes flaky testParallelRpcRequestsCompleteConcurrently: under load,
        //            all 64 Dispatchers.IO threads were occupied, causing RPC handlers to
        //            queue and execute sequentially (completion order: [slow, medium, fast])
        // 0.0.255: Replace unconditional debug println with debugLog behind system property
        //          -Dfoundation.url.protocol.debug=true to enable
        // 0.0.257: Replace pingPeer() with pingPeerDirect() — direct-only ping
        //          - Removes dead relay fallback code (relayService was always null when
        //            called via UrlProtocol2, which manages its own RelayService)
        //          - Removes pingPeerViaRelay() and extractRelayFromCircuitAddress()
        //          - UrlProtocol2 now handles relay ping exclusively through its own service
        // 0.0.260: Fix race condition in RelayServerMessageHandler on peer disconnect
        //          - registeredPeerId was a plain var written by Dispatchers.IO coroutine
        //            and read by Netty event loop thread in channelInactive/exceptionCaught.
        //            Without @Volatile, the JMM does not guarantee the write is visible,
        //            causing cleanupStreamRegistration to be skipped (registeredPeerId
        //            appears null) and cached service announcements to never be removed.
        //          - Added @Volatile to registeredPeerId for cross-thread visibility
        //          - Added stream.remotePeerId() fallback in channelInactive/exceptionCaught
        //            so cleanup runs even if the registration coroutine was cancelled before
        //            setting registeredPeerId
        // 0.0.261: Fix remaining race in RelayServerMessageHandler disconnect cleanup
        //          - The 0.0.260 fix was incomplete: scope.cancel() cannot interrupt a
        //            running non-suspend coroutine (processIncomingMessage). An in-flight
        //            gossip coroutine could write to cachedServiceAnnouncements AFTER
        //            cleanupStreamRegistration had already removed the entry.
        //          - Cleanup is now dispatched to the same limitedParallelism(1) dispatcher,
        //            serializing it with message processing so it runs AFTER any in-flight
        //            coroutine completes.
        //          - exceptionCaught now delegates cleanup to channelInactive (via ctx.close())
        //            instead of duplicating cleanup logic.
        //          - Added channelClosed flag to prevent new coroutines after disconnect.
        // 0.0.266: Share SecureRandom across random Ed25519 host-identity generation.
        //          - libp2p's default `random(KeyType.ED25519)` path invokes
        //            `generateKeyPair(KeyType.ED25519)`, which in turn constructs a
        //            fresh `new SecureRandom()` per call. On a cold JVM that pays
        //            a one-time NativePRNG seeding cost (~10+ ms); on entropy-starved
        //            CI containers or freshly-booted VMs it can block on
        //            `/dev/random` for several seconds, spiking the first host's
        //            `start()` latency.
        //          - Libp2pHostFactory now pre-materializes a random Ed25519 key
        //            via `generateKeyPair(KeyType.ED25519, 0, sharedKeyGenSecureRandom)`
        //            in every `identity { ... }` block where no caller key was
        //            supplied, reusing a single lazily-seeded SecureRandom across
        //            all hosts in the process. SecureRandom is documented as
        //            thread-safe, so no external synchronization is needed.
        //          - First-host creation is now as cheap as subsequent hosts, and
        //            entropy-starved environments no longer pay the seeding tax
        //            at every host startup.
        // 0.0.267: cleanupStreamRegistration no longer synthesizes ServiceWithdrawal
        //          messages for the departing peer's services. Stream close is a
        //          connectivity event, not an authoritative "the peer no longer
        //          provides these services" signal — the peer itself may reconnect
        //          and re-register within milliseconds. Broadcasting synthetic
        //          withdrawals on every stream close was the root cause of the
        //          recurring stressTestPeerExchangeResponseServiceDiscovery flake
        //          observed in UrlResolver: the withdrawals cleared the provider's
        //          advertisedServices throughout the network, and nothing restored
        //          them until the provider's 5-minute re-announce job fired. During
        //          that window every PeerExchange response carried the provider with
        //          an empty service list, so late-joining clients could not populate
        //          discoveredServices via the sync pull path (which the stress test
        //          is explicitly exercising).
        //          The relay's LOCAL bookkeeping for the departing peer —
        //          cachedServiceAnnouncements entries keyed to it — is still cleared
        //          on stream close, since the relay cannot replay those announcements
        //          through a closed stream. The peer will re-send them on reconnect
        //          via the usual gossip path.
        //          Genuine "peer is gone" paths — explicit handleRelayUnregister
        //          and cleanupExpiredRegistrations — still synthesize withdrawals;
        //          those signals ARE authoritative. Testing: new
        //          testStreamCloseDoesNotSynthesizeServiceWithdrawals regression
        //          test drives cleanupStreamRegistration for a registered peer with
        //          services and asserts no ServiceWithdrawal is delivered to the
        //          GossipHandler. Existing coverage for the genuine paths is
        //          preserved (testRelayUnregisterBroadcastsServiceWithdrawals and
        //          related tests).
        // 0.0.268: Track per-(serviceId, providerPeerId) ServiceWithdrawal timestamps in the
        //          relay's cache and reject ServiceAnnouncement writes that are not strictly
        //          newer. Closes a race observed as the rotating
        //          testRelayBroadcastsWithdrawalWhenPeerDisconnects flake in UrlResolver
        //          (issue #489): when withdrawServicesForPeer cleaned the cache for a
        //          departing peer on its stream's serialized scope, a delayed gossip
        //          rebroadcast of the original ServiceAnnouncement — forwarded by another
        //          registered peer that had received the announcement before the withdrawal
        //          — could land on a different stream's scope and unconditionally repopulate
        //          cachedServiceAnnouncements with the stale entry. The relay then replayed
        //          the stale announcement to future late joiners.
        //          New public API: recordServiceWithdrawal(serviceId, providerPeerId,
        //          timestamp). Internal callers (processIncomingMessage's ServiceWithdrawal
        //          branch and withdrawServicesForPeer) now invoke it BEFORE notifying handlers
        //          / forwarding, so any externally-observable handler signal implies the
        //          withdrawal is already recorded for cache-rejection purposes. The merge
        //          uses maxOf so an out-of-order older withdrawal cannot downgrade a newer
        //          recorded value. Genuine re-registrations (announcements with timestamps
        //          strictly greater than the recorded withdrawal) are still accepted.
        //          Regression coverage:
        //          testRelayCacheRejectsStaleAnnouncementAfterRecordedWithdrawal exercises
        //          the new contract directly via the public API.
        // 0.0.269: Close server-side libp2p substream after handling each
        //          gossip message (ServiceAnnouncement, ServiceWithdrawal,
        //          ServiceQuery, PeerExchange, PeerAnnouncement,
        //          RelayAnnouncement, RelayWithdrawal). Mplex requires both
        //          sides to close their write halves before the MuxChannel
        //          is reclaimed; the server previously relied on the 120s
        //          ReadTimeoutHandler to fire, which under sustained gossip
        //          load (~200 substreams/sec across the production peer set)
        //          built up a steady-state of ~24 K MuxChannels and ~50 MB+
        //          of Netty pipeline state, OOMing the 128 MB ContainerNursery
        //          heap 20+ times in 24h on 2026-04-26. RpcServerMessageHandler
        //          now closes the substream at the end of each gossip branch
        //          in channelRead0. RPC streams are intentionally NOT closed
        //          — public callers (and the existing test suite) reuse one
        //          controller for back-to-back RpcRequests. Also removes the
        //          runBlocking { join children } wait from cleanup(), which
        //          parked the Netty event loop for up to 10 s under cleanup
        //          load and would have starved every channel sharing the
        //          loop once the new close-after-gossip behavior kicks in.
        //          Regression coverage:
        //          testGossipSubstreamsClosedAfterHandling asserts that the
        //          client observes EOF on its half of the substream within
        //          5 s of sending a ServiceAnnouncement (the bug would have
        //          left it open until the 30 s idle timeout). Three pre-existing
        //          gossip-handler-survives-exception tests are updated to use
        //          a fresh substream per message, matching production usage
        //          in UrlResolver.sendGossipToPeer and friends.
        // 0.0.271: Gate every libp2p stream writeAndFlush on channel.isWritable
        //          so the producer can no longer enqueue unbounded WriteTask
        //          objects on the Netty event loop's MpscUnboundedArrayQueue.
        //          Root cause of the production OOM that took down ContainerNursery
        //          (and therefore kotlin.directory) on 2026-04-27 03:03:33 UTC.
        //          Forensic heap dump showed two NioEventLoop task queues holding
        //          982 pending AbstractChannelHandlerContext$WriteTask instances each,
        //          eating 55% of CN's 128MB heap, with the shortest path going
        //          through MplexHandler.onChildWrite/UrlProtocol2 lambdas.
        //          New helper writeFramedBufferWithBackpressure(channel, buf) gates
        //          on isWritable, drops on event-loop thread, otherwise poll-waits
        //          up to 5s for writability. New configureWriteBackpressure(stream)
        //          sets WriteBufferWaterMark(low=32KB, high=64KB) on each mux substream
        //          so isWritable trips at predictable thresholds. Applied at every
        //          stream init site (UnifiedRpcProtocol.initChannel,
        //          NettyStreamController.init). All four pre-existing writeAndFlush
        //          call sites delegate to the new helper: writeRpcMessage,
        //          NettyOutputStream.write(int|byte[]), RelayMessageSender.sendMessage
        //          (both impls).
        //          (0.0.270 was published from an earlier branch without source bump;
        //          skipping that coordinate to avoid collision.)
        // 0.0.272: Add flush-on-close to RelayMessageSender / RelayStreamController /
        //          RelayConnection. Both server-side StreamRelayMessageSender.sendMessage
        //          and client-side RelayStreamController.sendMessage queue bytes onto the
        //          libp2p stream asynchronously (writeFramedBufferWithBackpressure since
        //          0.0.271, stream.writeAndFlush before that), but the matching close()
        //          previously called stream.close() inline on the calling thread, racing
        //          the in-flight write. Under CPU contention (CI 2-vCPU droplets) the
        //          close routinely tore the channel down before queued bytes actually
        //          drained, dropping the last-queued message. The most visible victim
        //          was RelayService.unregisterFromRelay -- its trailing connection.close()
        //          dropped the RelayUnregister bytes, the relay never broadcast a
        //          ServiceWithdrawal, and downstream peers' service registries went stale
        //          until the 5-minute cleanupExpiredRegistrations sweep fired.
        //          UrlResolver 0.0.498 worked around this by manually pre-sending the
        //          unregister via sendGossipToRelay + Thread.sleep(200) before the close
        //          path, but the underlying primitive was still broken for any other
        //          caller.
        //          Fix: RelayMessageSender adds an interface-level
        //          close(flushTimeoutMs: Long): Boolean. AutoCloseable.close() defaults
        //          to flushTimeoutMs = 1000, so all existing call sites pick up the
        //          flush behavior automatically. StreamRelayMessageSender and
        //          RelayStreamController override it to await
        //          io.libp2p.core.Stream.closeWrite() with the caller-supplied timeout.
        //          closeWrite returns a CompletableFuture<Unit> that completes once every
        //          queued write on the stream has actually drained onto the wire and the
        //          write side is half-closed; Netty preserves write ordering on a single
        //          channel, so awaiting closeWrite is sufficient to guarantee every prior
        //          sendMessage call has been delivered. (libp2p's Stream.writeAndFlush
        //          returns void -- the underlying Netty ChannelFuture isn't exposed --
        //          so closeWrite is the right barrier rather than tracking individual
        //          write futures.) Writes themselves remain async; only the close path
        //          pays the synchronization cost. RelayConnection.close gains a matching
        //          close(flushTimeoutMs) overload that forwards through.
        //          unregisterFromRelay's signature gains an optional flushTimeoutMs
        //          parameter (default 1 s, comfortably above the libp2p stream-flush
        //          latency observed on a loaded 2-vCPU CI core, ~10-50 ms) and threads
        //          it through to connection.close.
        //          Regression coverage:
        //          testRelayConnectionCloseFlushesPendingWrites runs 10 sequential
        //          register-then-unregister cycles against a single relay node with the
        //          default 1 s flush window and asserts that every iteration's unregister
        //          delivers a ServiceWithdrawal to the relay's GossipHandler. Without
        //          flush-on-close this fails consistently on slow CI cores; with it,
        //          delivery is deterministic.
        // 0.0.273: AutoCloseable.close() on RelayMessageSender / RelayConnection no
        //          longer waits for flush by default; flush is opt-in via the explicit
        //          close(flushTimeoutMs) overload that 0.0.272 added.
        //          Background: 0.0.272 made the no-arg AutoCloseable.close default to
        //          a 1 s flush ceiling so callers picking up the AutoCloseable contract
        //          would get the new flush-on-close behavior automatically. That choice
        //          turned out to be wrong: several teardown paths
        //          (RelayService.close itself, registered-peer cleanup on shutdown,
        //          listener-thread cleanup) call close on N senders / connections in
        //          sequence -- defaulting each to a 1 s flush ceiling pushed per-instance
        //          close latency from O(ms) into O(1 s) per relay link, multiplied across
        //          registered peers. UrlResolver stress tests that churn many short-lived
        //          UrlProtocol2 instances (stressTestCloseDoesNotExhaustDispatchersIO,
        //          stressTestEagerJoinDoesNotRaceWithExplicitJoinNetwork,
        //          testCloseDoesNotLeakDispatchersIoThreads, etc. -- 12 total) saw their
        //          30 s and 120 s test budgets blown by the new default in the
        //          UrlResolver bump PR (#500).
        //          Fix: the no-arg close() now calls close(0L) -- no flush, fast tear-
        //          down, matches pre-0.0.272 behavior. Callers that need flush
        //          (notably unregisterFromRelay's `connection.close(flushTimeoutMs)`
        //          forward) explicitly opt in via the parameterized overload, which is
        //          unchanged. The flush-on-close primitive itself is still correct and
        //          still tested by testRelayConnectionCloseFlushesPendingWrites; this
        //          is purely a default-value change.
        // 0.0.277: Drop ALL service-identifier prefix matching in
        //          PeerRegistry.findPeersForService and BootstrapPeer.canRoute (Libp2pPeer,
        //          TestPeer, SimulatedPeer). Previously, both directions were allowed:
        //              serviceIdentifier.startsWith(service) || service.startsWith(serviceIdentifier)
        //          which silently routed cross-service requests in either direction.
        //          A peer advertising "tasks" was treated as a router for any "tasks-*"
        //          service it never registered (reverse direction); a peer advertising
        //          "com.example.api" was also returned for an ancestor-namespace query of
        //          "com.example" (forward direction). Both were undocumented (the kdoc
        //          only ever gave a hand-wavy "e.g., 'com.example' matches 'com.example.api'"
        //          example), and the existing testFindPeersForServicePrefixMatchingPrecision
        //          even called out the reverse case as suspect without asserting against it.
        //          Match is now exact only: a query for "X" returns peers that advertise
        //          exactly "X" — never ancestors, never descendants, never wildcards.
        //          UrlProtocol.queryServices kdoc updated — the "supports prefix matching"
        //          promise is gone.
        //          Tests updated: testFindPeersForServiceHierarchicalMatching,
        //          testFindPeersForServicePrefixMatchingPrecision,
        //          testLibp2pPeerCanRoutePrefixMatch, testCanRoutePositiveMatch,
        //          testPeerRegistryPrefixMatching, testPeerCanRoute.
        // 0.0.283: PeerRegistry.addPeer interns every multiaddr String and lowers
        //          MAX_MULTIADDRESSES_PER_PEER from 20 → 8. Root cause of the
        //          2026-05-27 ContainerNursery OOM on 198.199.106.165 (heap dump
        //          java_pid648304.hprof, -Xmx128m JVM, port 443 unbound for 6+ h):
        //          every gossip event for a known peer unioned a new circuit-
        //          relay multiaddr into the stored peer's list, AND every
        //          downstream reader (relay-debug log lines, gossip-outbound
        //          serialization, retry loops) snapshotted the bloated list into
        //          fresh String allocations that piled up in the retained log-
        //          capture buffers. The hprof showed 9–43 LIVE String copies of
        //          every multiaddr text (same bytes, distinct objects). Interning
        //          collapses equal-content copies to one canonical reference in
        //          the JVM string pool; lowering the per-peer cap from 20 → 8
        //          tightens the absolute upper bound (production was operating
        //          at ~9 multiaddrs per peer at OOM time — 8 is the smallest cap
        //          that leaves headroom for loopback + droplet-public + 1-2
        //          circuit-relay routes per peer, the shape a healthy libp2p
        //          mesh needs).
        //          Witness test in ContainerNursery's tree:
        //          tests/testUrlResolverPeerRegistryBoundsMultiaddrsPerPeer.kts
        //          (initially failed at storedAddrCount=20 against 0.0.281; now
        //          passes at storedAddrCount=8 against 0.0.283).
        // 0.0.284: ServiceBroadcaster.broadcastAnnouncementAtTimestamp and
        //          broadcastWithdrawalAtTimestamp made abstract (#275).
        // 0.0.285-0.0.287: development intermediates published while iterating on the
        //          fix below (and before this branch was rebased onto #275). Superseded
        //          by 0.0.288 — do not consume.
        // 0.0.288: Two-part fix for empty service provider addresses through a relay. A
        //          peer that binds to a wildcard/loopback interface with no discovered
        //          public IP would advertise an EMPTY multiaddress list, poisoning every
        //          sink that recorded it (the relay's discoveredServices via the gossip
        //          handler, peerRegistry, peer-exchange re-shares, and forwarded
        //          ServiceAnnouncements) with address-less, unusable entries observable
        //          before the non-empty gossip ServiceAnnouncement arrived. Root cause of
        //          UrlResolver's flaky stressTestReannounceNeverOverwritesWithEmptyAddresses
        //          (buildtest run 2d7e8f12).
        //          (1) SOURCE: registerWithRelay no longer sends the raw
        //              PublicAddressDiscovery.getEffectiveAddresses result (which filters
        //              out both 0.0.0.0 and 127.0.0.1, hence often empty). It falls back to
        //              loopback-derived addresses when that is empty — the same localhost
        //              fallback UrlResolver.getAnnounceAddresses applies to gossip
        //              announcements (ownRegistrationMultiaddresses() helper). The
        //              registration request is therefore never address-less, so no empty
        //              addresses enter any downstream sink.
        //          (2) EXTERNAL REACHABILITY: handleRegister augments the registering
        //              peer's addresses with the CIRCUIT-RELAY address through this relay
        //              (circuitRelayAddress() helper) — the SAME address it already
        //              broadcasts to every other registered peer — before writing them to
        //              peerRegistry and notifying GossipHandler.onPeerRegisteredWithRelay,
        //              so external consumers can reach a NAT'd/loopback provider.
        //          Witness tests:
        //          tests/testRelayRegistrationNotifiesGossipHandlerWithReachableAddresses.kts
        //          here, and UrlResolver's
        //          tests/stressTestRelayRegistrationNeverPublishesEmptyAddresses.kts.
        // 0.0.299: Relay large-RESPONSE chunking that survives an OLDER relay. A large url:// result
        //          (e.g. a ~700 KB–2 MB generated image / its hex) never returned over a relay before;
        //          the target now buffers it and serves it chunk-by-chunk (128 KiB) as the requester
        //          fetches, endpoint-to-endpoint (the relay-forwarding core is unchanged). Crucially the
        //          chunk metadata rides INSIDE the opaque payload as a self-describing "RCNK1" envelope
        //          ("RCNK1\n<transferId>\n<seq>\n<total>\n"+rawChunk, base64'd into RelayResponse.payload),
        //          NOT in new RelayResponse fields: a relay on an OLDER protocol re-serialises a
        //          RelayResponse and DROPS fields it doesn't know, so metadata in new fields was lost
        //          crossing the relay and the requester silently truncated to chunk 0 (1 MiB → 128 KiB).
        //          The payload is preserved verbatim by every relay version, so chunking is incrementally
        //          deployable (upgrade endpoints, not the relay). The target only chunks when the
        //          requester advertised __relay_supports_response_chunking__, so a new target never
        //          truncates an OLD requester; RelayResponse keeps its original (pre-chunking) constructor
        //          shape (binary-compatible). Combines with 0.0.298's relay-discovery re-announce.
        //          Witnesses: tests/testLargeResponsePayloadTraversesRelay.kts,
        //          tests/testRelayMessageWireBackwardCompatibility.kts, and a live cross-version interop
        //          test routing 1 MiB through a published-0.0.288 relay in a child JVM. (Originally
        //          published standalone as 0.0.297; 0.0.299 is that envelope rebased onto main.)
        // 0.0.300: Coordinate bump for a fresh published artifact that bundles the libp2p gossip
        //          outbound-buffer backpressure fix (effectiveIsWritable, #288/#289 — gossip writes now
        //          honor the whole parent connection chain's writability instead of queuing unboundedly
        //          to a backed-up/non-draining peer, which had filled the heap and made nodes unreachable
        //          at the libp2p handshake level) together with the 0.0.299 relay response chunking on a
        //          single coordinate. 0.0.299 was never published; the gossip fix shipped standalone as
        //          0.0.298, so 0.0.300 is the first published version carrying both. No source change vs
        //          0.0.299 — the implementation already lives on main.
        // 0.0.301: STREAM large relay responses. sendViaRelay's response-chunk reassembly used to PULL each
        //          128 KiB chunk in its own blocking round-trip (sendMessage(fetch) then readMessage), so an
        //          N-chunk response cost N sequential relay round-trips. In-process (≈0 latency) that is
        //          fast, but over a real relay it is N×RTT: a ~1 MB result from a NAT'd service crawled and a
        //          multi-MB result effectively hung — the public PhotoGenerationManager Wui never received a
        //          generated image. Now the fetches are PIPELINED: every chunk-fetch request is sent up front
        //          over the one dedicated connection, then the responses are read and placed by the chunk seq
        //          carried in the RCNK1 envelope (out-of-order safe). The relay/target serve the buffered
        //          chunks concurrently (thread-per-request), so an N-chunk response collapses from ~N RTT to
        //          ~1 RTT. Witness: tests/testLargeRelayResponseIsStreamedNotSerialized.kts routes an 8 MiB
        //          (64-chunk) response through an in-process requester->relay->target and asserts it
        //          completes in well under N round-trips and arrives intact (SHA-256). Pure receiver-side
        //          change; wire format and RelayResponse shape are unchanged (interoperates with any relay).
        // 0.0.302: Close abandoned relay-dial streams client-side (complements #299's inbound-substream
        //          admission cap). connectToRelay races dial attempts but chained only off
        //          newStream(...).controller, which resolves only AFTER multistream negotiation — so a dial
        //          whose negotiation stalled (controller hangs forever) was abandoned WITHOUT closing the
        //          opened stream, leaking an inbound mux substream on the relay (the ContainerNursery OOM,
        //          issue #294). Now connectToRelay tracks each attempt's StreamPromise.stream (resolves at
        //          stream-open) and closes it for every losing/abandoned/timed-out attempt, keeping only the
        //          winner. #299's per-connection+global cap is the safety net; this stops abandoned dials from
        //          churning against it. Pure client-side change; no wire/format change.
        // 0.0.303: Make inbound-substream admission control bound the HEAP, not just the COUNT (#294). The
        //          0.0.302 counter cap reset() the excess, but jvm-libp2p builds the MuxChannel + pipeline +
        //          multistream Negotiator scaffolding BEFORE the streamPreHandler hook can refuse it, and
        //          reset() runs on the same event loop that is busy creating more — so under a reconnect/
        //          brownout herd creates outpace reclaims and the scaffolding piles up until OOM (a follow-up
        //          prod dump showed 35,783 live MuxChannels OOMing a 128MB heap DESPITE the cap; another
        //          showed 32,218). InboundSubstreamAdmissionControl now pauses autoRead on the connection's
        //          PARENT channel at the per-connection (256) and global (1024) caps, so the OS receive
        //          buffer fills, the remote's writes block, and it stops sending mplex NEW_STREAM frames — the
        //          scaffolding is never built, regardless of event-loop saturation. Reads resume below a 3/4
        //          low-water mark; reset() is kept only as a race fallback. Proven by
        //          tests/stressTestInboundSubstreamsAreBoundedPerConnection.kts, which floods one connection
        //          past the cap and asserts the connection's reads get paused and the live count stays bounded
        //          — it FAILS (pausedConnectionCount=0) without the autoRead backpressure. Pure receiver-side
        //          change; no wire/format change.
        // 0.0.306: Surface a dropped AWAITED request/response write as an IOException instead of swallowing
        //          it silently (NettyOutputStream.write). writeFramedBufferWithBackpressure drops the buffer
        //          (returns false) when the stream/connection is unwritable through the 200ms backpressure
        //          wait — correct for best-effort gossip, but for an AWAITED request a silent drop left the
        //          caller blocked for its full invocation timeout (the kotlin-build-ci uploadChunk 120s
        //          "Build infrastructure error" phantom hang) waiting for a response to a request that was
        //          never sent. Both Libp2pRpcStream.sendRequest and UrlResolver.PersistentRpcConnection.
        //          sendRequest already catch IOException from the write and fast-fail; they were just never
        //          handed the exception. Best-effort writes (writeRpcMessage / gossip) still drop silently;
        //          the OOM-bounding from #247 is unchanged. Proven by tests/testRpcRequestWriteSurfacesDrop
        //          WhenUnwritable.kts (write throws on drop, still delivers when writable) and tests/
        //          testSendRequestFastFailsWhenConnectionUnwritable.kts (sendRequest returns INTERNAL_ERROR
        //          promptly instead of hanging its full latch) — both FAIL without this change.
        // 0.0.307: Resolve a /ip4/0.0.0.0/ wildcard announce address against this node's own routable
        //          local-interface IPv4 as a lowest-priority fallback (below explicit IP and Identify),
        //          in PublicAddressDiscovery.getEffectiveAddresses. Fixes the netlab-hosted provisioning
        //          RACE: a register-and-wait provider on a host with a routable IP directly on its NIC
        //          (a cloud droplet) previously advertised ONLY relay-circuit addresses whenever a peer
        //          health-checked it before an outbound dial had populated the Identify observation — the
        //          wildcard was dropped entirely, leaving it relay-only, and the cross-host manager's
        //          relay dials failed (NothingToCompleteException) → intermittent WAITING_FOR_HEALTH
        //          FAILED. Now such a node advertises a direct reachable address from its first
        //          announcement; no new IP channel, just removing the dependency on the racy
        //          Identify-after-outbound-dial signal. A NAT'd node (private NIC only) still gets null
        //          and correctly stays relay-only. Injectable routableLocalIpv4Provider for hermetic
        //          tests. Proven by tests/testWildcardResolvesToRoutableLocalInterfaceWhenNoPublicIpKnown
        //          .kts (FAILS — Advertised:[] — with the one-line fallback reverted; PASSES with it).
        // 0.0.308: Close the AWAITED-RESPONSE silent drop — the server-side analog of the 0.0.306
        //          request-direction fix (which fixed only the SENDER side and explicitly left
        //          "best-effort writes (writeRpcMessage / gossip) still drop silently"). When a
        //          server RPC handler's AWAITED response write is dropped by
        //          writeFramedBufferWithBackpressure because the connection is unwritable, the
        //          RpcRequest branch of the server message handler used to discard that drop, so the
        //          requesting peer blocked for its FULL invocation timeout — for a sandboxed
        //          url://buildtest/ RPC that is the UrlResolver 30s SJVM watchdog, surfacing as a
        //          misattributed terminal "Build infrastructure error: ... SJVM host-side RPC
        //          interrupted during method=createUploadSession ..." even though the server handled
        //          the request and the build never started (kotlin-build-ci PR #152, check 82452389256).
        //          Error semantics distinguish it from the 0.0.306 request drop: a dropped request
        //          fast-fails ("Failed to send request"); a 30s HANG means the request was delivered
        //          and the RESPONSE was lost. Fix: writeRpcMessage / writeStreamingBytecodeMessage gain
        //          internal *ReturningDelivered variants (public Unit signatures unchanged →
        //          binary-compatible); on a dropped awaited response the handler closeStreamQuietly()s
        //          so the peer's reader loop completes the pending request with an immediate,
        //          recoverable "Stream closed" error (Libp2pRpcStream.runReaderLoop) instead of
        //          hanging. Best-effort gossip writes are unchanged. Proven by tests/
        //          testRpcOversizedResponseReturnsOutboxFullAndKeepsStreamOpen.kts (the current
        //          bounded-outbox contract returns an explicit OUTBOX_FULL result without closing
        //          the reusable logical stream).
        // 0.0.309: Forward the __bytecode_request metadata (resourcePath) through the PROXY fallback in
        //          ServiceRoutingHandler.handleBytecodeRequest. For a path-based URL like
        //          url://lambdaserver/functions/{id} the resolver attaches resourcePath to the request
        //          metadata so the provider serves the per-resource client impl (e.g.
        //          FunctionDefinitionClientImpl) rather than the generic service client. A direct
        //          url-bind provider reads request.metadata itself (LambdaServer #56), but the proxy
        //          fallback (used by ContainerNursery's UrlFacade, which holds no bytecode locally)
        //          called service.handleRequest(__bytecode_request, emptyMap(), emptyMap()) — dropping
        //          the metadata. ContainerNursery therefore forwarded EMPTY metadata to lambda-server,
        //          which served the generic LambdaServiceClientImpl, and every GithubWatchman ->
        //          url://lambdaserver/functions/{id} callback threw NoSuchMethodError
        //          (LambdaServiceClientImpl.invoke(List)Object) in the sandbox. Fix forwards
        //          request.metadata. Proven by tests/testProxyBytecodeRequestForwardsResourcePath
        //          Metadata.kts (FAILS — received metadata {} — with this change reverted).
        // 0.0.310: Send ByteArray RPC params/results as out-of-band BINARY ATTACHMENTS in the wire
        //          frame (a `{"__type":"binary_ref","__index":N}` stub in the JSON body + the raw
        //          bytes appended after the frame) instead of inline base64. Inline base64 in
        //          JSONObject.toString() grew a ~3 MB StringBuffer per in-flight bytecode response,
        //          OOMing small (-Xmx128m) services under concurrent load (the LambdaServer
        //          __bytecode_request crash loop, LambdaServer #51). toJson()/encodeMessage() gain an
        //          optional attachments list; encodeValueForJson collects ByteArrays into it (falling
        //          back to inline base64 when no list is supplied — wire backward compatible), the
        //          read path reassembles them, and BytecodeProtocol.parseResponseFromResult consumes
        //          the binary Map form. The optimized self-bytecode path still uses
        //          StreamingBytecodeResponse (unchanged); this covers the fallback/proxy and multi-impl
        //          (FunctionDefinition) paths that return a Map<String, ByteArray>. Proven by
        //          tests/testBinaryAttachment*.kts and tests/testBinaryBytecodeProtocolRoundTrip.kts.
        // 0.0.311: Restore BINARY COMPATIBILITY of the methods 0.0.310 widened. 0.0.310 added an
        //          `attachments` parameter to RpcRequest/RpcResponse.toJson(), .fromJson(),
        //          encodeMessage(), writeMessage(), encodeValueForJson(), decodeValueFromJson() via
        //          Kotlin default params with NO @JvmOverloads — which removes the old lower-arity JVM
        //          methods. Any consumer compiled against <=0.0.309 (e.g. published resolver 0.0.559,
        //          the deployed ContainerNursery) calling the old arities (toJson(), encodeMessage(json),
        //          writeMessage(out, json), fromJson(json)) would throw NoSuchMethodError at runtime
        //          against 0.0.310 — a fleet-wide break requiring a lockstep recompile. Adding
        //          @JvmOverloads regenerates the legacy arities (delegating to the no-attachments /
        //          inline-base64 path, i.e. the exact pre-0.0.310 behavior), so 0.0.311 is a
        //          drop-in for those consumers while new callers can still opt into binary attachments.
        //          Pure ABI restoration — no behavior change; the full suite (which calls every widened
        //          method via its legacy arity) stays green.
        // 0.0.312: Stop the relay-client listener from hot-spinning when the relay closes a client's
        //          registration substream. RelayStreamController.readMessage() returns null for BOTH a
        //          genuine 60s read-timeout AND a remotely-closed stream (channelInactive sets the
        //          controller's closed flag, so readBytes exits its wait immediately). The listener loop
        //          in startRequestListener did `readMessage(60, SECONDS) ?: continue` — unable to tell the
        //          two apart — so when a relay closed the substream (exactly what registration EXPIRY does)
        //          the RelayService-listener thread span at ~100% CPU and never exited (none of its loop-
        //          exit conditions — service-closed / stop-signal / relayConnection-changed / interrupt — is
        //          triggered by a remote close), and never nulled relayConnection so the never-give-up
        //          reconnection task (which only fires on relayConnection == null) never re-registered.
        //          Across the concurrent test suite these spinners starve CPU, which is how the unrelated
        //          teardown `host.stop().get(5)` budget intermittently blew in the merge queue
        //          (testRelayServiceRegistrationExpiresWithoutKeepalive, run 27869486072). Fix: on a null
        //          read, break out (dropping the connection so reconnection re-registers, mirroring the
        //          catch block) when connection.isClosed(); only `continue` on a true timeout. Adds
        //          RelayConnection.isClosed() delegating to the controller. Proven by tests/
        //          testRelayListenerExitsWhenRelayClosesSubstream.kts (the listener thread TERMINATES and
        //          consumes ~0 CPU after the relay closes the substream; FAILS — thread stays RUNNABLE and
        //          burns ~1000ms CPU per 1000ms wall clock — with this change reverted).
        // 0.0.313: Stop Libp2pHostFactory from LEAKING every host it builds. The factory (a singleton
        //          object) records each host it creates in a static `inboundAdmissionControls` map (keyed
        //          by Host, added by the #294 inbound-substream admission-control work) so
        //          inboundAdmissionControlFor() can look up a host's live-substream counters. That map
        //          used STRONG keys and was never cleaned on host.stop(), so every Host ever built — and
        //          transitively its whole netty event-loop-group / buffer graph — stayed reachable for the
        //          JVM lifetime. In a long-lived service that is a steady memory leak; in the shared-JVM
        //          test suite it accumulates ~0.5 MB/host (measured: retained heap climbs linearly, 4→67 MB
        //          over 60 create/stop cycles AFTER full GC) and the resulting GC pauses on a constrained
        //          CI runner intermittently blow tight teardown budgets — the root cause of the
        //          testMalformedJsonDoesNotKillConnection `clientHost.stop().get(2)` flake (host.stop() is
        //          itself <25 ms even at loadavg 30, so the timeout was GC pressure, not a slow stop). Fix:
        //          make the map weak-keyed (synchronized WeakHashMap); the admission-control value does not
        //          strong-reference its host (per-connection state is dropped on each connection's
        //          closeFuture), so a stopped+released host is collected promptly and the lookup still works
        //          while the host is alive. Proven by tests/testStoppedHostIsNotRetainedByFactory.kts (a
        //          stopped, dereferenced host must become GC-collectable; FAILS — host pinned by the static
        //          map — with this change reverted).
        // 0.0.314: Deliver awaited RPC writes that hit a TRANSIENT backpressure stall instead of
        //          dropping them at 200ms — THE systemic root cause of the prod 30s/120s RPC hangs
        //          (lambdaserver callback "Stream closed", netlab-hosted uploadFile/logs/apply 30s
        //          timeouts, buildtest uploadChunk 120s). writeFramedBufferWithBackpressure gained a
        //          3-arg overload taking a maxWaitMs; the awaited paths (writeRpcMessageReturning
        //          Delivered, writeStreamingBytecodeMessageReturningDelivered, the NettyOutputStream
        //          request path, and the effect-request path) now pass WRITE_BACKPRESSURE_DELIVERY_
        //          WAIT_MS (5s) so a connection that is momentarily unwritable while the peer drains a
        //          multi-MB transfer is ridden out and the message DELIVERED on recovery, rather than
        //          dropped after 200ms (which left the awaiting caller to hang its full invocation
        //          timeout, or — post-#308/#314 — fast-fail "Stream closed"). #308/#314 only SURFACED
        //          the drop; they never delivered the message. Memory stays bounded exactly as the
        //          200ms-drop design intended: writeAndFlush is still only called while writable (so
        //          the event-loop WriteTask queue never grows — the 2026-04-27/06-10 OOM root cause),
        //          and at most maxConcurrentParkedWritesPerConnection (16) writes park per connection
        //          (beyond that, drop fast). Best-effort gossip is unchanged (still the 200ms drop via
        //          the 2-arg overload). The 5s wait is kept under the awaited-write fast-fail contract
        //          (testSendRequestFastFailsWhenConnectionUnwritable: a dropped awaited write must
        //          surface within 8s). Proven by tests/testRpcWriteDeliveredAfterTransient
        //          Backpressure.kts (peer receives a message written during a >200ms transient stall
        //          that then recovers; FAILS — message lost — with this reverted),
        //          testParkedWritesBoundedPerConnectionUnderSustainedBackpressure.kts (the park budget
        //          bounds parked writes under a flood while still delivering the parked ones), and
        //          testAwaitedWriteFailsFastWhenConnectionStaysWedged.kts (the delivery wait is
        //          bounded — a wedged connection fails fast, no unbounded park).
        // 0.0.315: Prefer the Yamux stream muxer over mplex (additive migration). All four
        //          Libp2pHostFactory builders now advertise StreamMuxerProtocol.getYamux()
        //          as the preferred muxer with StreamMuxerProtocol.Mplex retained as a
        //          fallback. mplex has NO flow control — no per-stream receive window and no
        //          limit on un-acknowledged stream opens — so inbound substream data and
        //          NEW_STREAM frames buffer in heap with no protocol-level backpressure. That
        //          is the root cause behind the recurring ContainerNursery heap-exhaustion
        //          outages this codebase has been mitigating by hand (the LIBP2P_RPC_WRITE_
        //          WATER_MARK watermarks, the WRITE_BACKPRESSURE_WAIT_MS drop window, and the
        //          #294 inbound-substream admission control). libp2p deprecated mplex in
        //          favour of Yamux, whose credit/window flow control and ackBacklogLimit bound
        //          that growth at the protocol layer. The ordering is ADDITIVE on purpose:
        //          new<->new connections negotiate Yamux while new<->old connections fall back
        //          to mplex, so the live url:// network does not partition off the many
        //          already-deployed mplex-only nodes. Once the whole fleet advertises Yamux,
        //          mplex can be dropped. Proven by tests/testFactoryHostsNegotiateYamuxMuxer
        //          .kts (two production-configured hosts negotiate Yamux; FAILS — they
        //          negotiate mplex — with this reverted) and tests/testFactoryHostInteroperates
        //          WithMplexOnlyLegacyPeer.kts (a legacy mplex-only peer still negotiates the
        //          mplex fallback and completes a real RPC round-trip — the partition-safety
        //          guard).
        // 0.0.316–0.0.324: Published as coordinate/intermediate releases carrying the post-0.0.315
        //          merges (raw-binary-attachment request params, jvm-libp2p snapshot-8, the relay
        //          reply-forwarding fix) ahead of the committed coordinate. The build.kts changelog
        //          was not updated for those publishes, so main's coordinate stayed at 0.0.315 while
        //          the Maven line advanced to 0.0.324.
        // 0.0.325: Reconcile the committed coordinate with the published line by building current
        //          main HEAD as a fresh, monotonic release (> the published 0.0.324). Captures every
        //          merged change through #330, notably: #329 — relay reply-forwarding no longer
        //          silently drops an AWAITED RPC reply when the relay->client substream is momentarily
        //          unwritable (the client previously hung its full 30s invocation timeout), the
        //          reply-direction analog of the 0.0.306/0.0.308 awaited-write drop fixes; and #330 —
        //          jvm-libp2p snapshot-8 -> snapshot-9, restoring the daemon event-loop and shared
        //          worker group. This is the protocol version UrlResolver upgrades onto for the
        //          fleet-wide dependency refresh.
        // 0.0.330: RelayService.handleRegister no longer replays STALE cached service
        //          announcements to newly-registered peers. The late-joiner catch-up replay was
        //          unconditional: a provider that crashed without a ServiceWithdrawal kept being
        //          replayed to every late registrant until the relay happened to process the
        //          provider's stream close (which purges its cache entries) — a load-dependent
        //          timing race that handed dead services to late joiners and repeatedly defeated
        //          the downstream resolver's vouching gates (the replay bypasses them). A cached
        //          announcement is now replayed only while its provider holds a live (unexpired,
        //          keepalive-refreshed) relay registration OR the announcement's own timestamp is
        //          within CACHED_ANNOUNCEMENT_REPLAY_MAX_AGE_MS (5 min, matching the resolver's
        //          verification window). Reproduced end-to-end by UrlResolver's
        //          testStaleServiceAnnouncementsNotForwardedToLateJoiners; guarded here by
        //          testRelayDoesNotReplayStaleCachedAnnouncementToLateRegistrant (fail-first).
        // 0.0.333: Stream the bytecode serve on the url-bind/TcpServer path, and forward an
        //          already-streamed backend response through the proxy fallback unchanged — so a
        //          ContainerNursery-launched provider reached via CN's UrlFacade proxy (the NetLab
        //          manager) never Base64-materializes its own jar to serve __bytecode_request.
        //          (Originally published as 0.0.321 off a branch that predated the 0.0.325–0.0.332
        //          line; re-landed here on top of main so a single monotonic coordinate carries the
        //          Yamux migration, the 0.0.329 relay reply-forwarding fix, the 0.0.330 stale-
        //          announcement fix, and the 0.0.332 metadata channel together with this fix.)
        //          (1) New bind(url, handler, implementationJar, implementationClassName) overload:
        //          the framework answers __bytecode_request for a TcpServer-bound service with a
        //          StreamingBytecodeResponse (the url-bind analogue of ServiceRoutingHandler's
        //          optimized supportsSandboxedExecution branch), streaming the framed wire bytes with
        //          peak heap ~= jar size. The bound handler no longer hand-rolls __bytecode_request by
        //          encoding its whole multi-MB jar per (re)connect — the OOM-crash-loop on -Xmx128m
        //          providers. See BytecodeResponseStreamer.
        //          (2) translateBackendBytecodeResponse now passes an ALREADY-FINAL BytecodeProtocol
        //          response (keys jarBytes/implClassName, or a notModified frame) through unchanged
        //          rather than demanding the legacy {jar,className} backend keys — so a proxy can
        //          forward a streaming backend's response. Additive + binary-compatible with 0.0.332
        //          (new overload; legacy {jar,className} translation unchanged). Proven by
        //          tests/testBindStreamsServiceOwnBytecodeRequest.kts and
        //          tests/testProxyForwardsStreamedBytecodeResponseUnchanged.kts (the latter fails
        //          against the legacy-only translation with JSONObject["jar"] not found).
        // 0.0.334: Add the negotiation contract constants for the streamed-bytecode proxy hop —
        //          BytecodeProtocol.METADATA_KEY_BYTECODE_RESPONSE_FORMAT ("bytecodeResponseFormat")
        //          and BYTECODE_RESPONSE_FORMAT_STREAMED ("streamed"). A proxy that understands the
        //          streamed response (the 0.0.333 passthrough) sets this request-metadata key when
        //          forwarding __bytecode_request; a url-bind backend streams its bytecode ONLY when it
        //          sees the key, else answers the legacy {jar,className} form every proxy understands.
        //          Carried in the additive RPC metadata channel (not a new multistream version) since
        //          it negotiates an application-level response schema, not transport framing. A single
        //          source of truth so ContainerNursery and a backend (the NetLab manager) can never
        //          drift on the key/value. Purely additive over 0.0.333.
        // 0.0.335: Bound concurrent inbound JSON body materialization/parsing with a global
        //          heap-scaled byte budget in Libp2pRpcProtocol. A single frame was already
        //          capped, but concurrent readers could each allocate a multi-MB body and
        //          org.json parse graph at once; production dumps showed many
        //          TcpRpcStream-Reader threads parsing large frames concurrently on a 128 MB
        //          heap. Readers now reserve parse budget before allocating the body and
        //          release it in finally, applying backpressure instead of dropping replies or
        //          OOMing.
        // 0.0.336: Expose ServiceClientConnection.remotePeerId as the authenticated libp2p remote
        //          peer id observed by the accepted server stream. This gives connection-aware
        //          service handlers a stable caller principal across reconnects without trusting any
        //          client-supplied request metadata. The property is nullable: libp2p-backed
        //          connections receive stream.remotePeerId().toBase58(), while localhost.tcp and
        //          detached/in-process paths report null because they have no cryptographic peer
        //          identity. Tests: tests/testServiceClientConnectionRemotePeerIdStableAcrossReconnect.kts.
        // 0.0.338: Harden LAN multicast peer discovery. UDP beacons now prefer source-address dial
        //          hints, discovery startup is best-effort with typed warnings, unverified beacons are
        //          non-persistent, dial concurrency and address fanout are bounded, malformed beacons
        //          are counted, mDNS can be disabled independently for hermetic UDP-only tests, and
        //          recently verified peers are not redialed on every beacon.
        // 0.0.339: Harden hierarchical verified name resolution. Verified chains now fail closed
        //          when a child delegation is missing, descriptors carry signed monotonic versions
        //          with rollback rejection, verified TLDs are pinned in memory and persisted through
        //          the peer persistence directory, hard-coded pinned TLD descriptors can close the
        //          pre-propagation rollout window for critical names, descriptor stores are bounded,
        //          non-canonical dotted names never normalize into verified descriptors, and service
        //          query / peer exchange / gossip ingestion apply the same authorization gate as
        //          client resolution. Unknown/unpinned TLDs remain free-to-claim for legacy
        //          coexistence until a verified TLD descriptor is seen or shipped as a hard pin.
        // 0.0.340: Harden link-state relay routing for availability and correctness. Local LSAs are
        //          periodically re-originated before TTL expiry, relayed requests carry a hop limit,
        //          LSA storage is bounded with TTL/timestamp/sequence admission checks, SPF only uses
        //          reciprocally advertised edges, and directly observed link costs feed SPF. The
        //          distance-vector path remains the fallback while link-state converges.
        // 0.0.341: Prefer direct mesh paths before relay fallback. Relay candidates are consulted
        //          only after direct link-state/registered routes are exhausted, so a relay hop is
        //          taken only when both peers are NAT-bound; established relay paths migrate off the
        //          relay when a direct registration for the target appears. Tests:
        //          tests/testPublicNatPairUsesDirectRegisteredConnectionWithZeroRelayHops.kts,
        //          tests/testBothNatPairFallsBackToRelay.kts,
        //          tests/testRelayPathMigratesOffRelayWhenDirectRegistrationAppears.kts.
        // 0.0.342: Account inbound JSON parse reservations at the conservative 7x transient
        //          heap amplification instead of raw wire bytes. Frames whose worst-case parse
        //          footprint exceeds the heap-scaled global budget are rejected with a descriptive
        //          IOException before allocation/parsing instead of being clamped and admitted.
        //          The independent 10 MB wire cap remains; smaller heaps impose a tighter dynamic
        //          parser-safety bound. Tests cover exact rejection text, Long overflow safety,
        //          the 128 MB heap boundary, single-frame child-JVM survival, and concurrent
        //          admissible parses under constrained heap.
        // 0.0.343: Preserve the historical UrlProtocol(PeerRegistry, RelayConfig) JVM
        //          constructor used by foundation.url:resolver:0.0.600. The expanded
        //          constructor retains its newer defaults, while a Kotlin-hidden binary bridge
        //          prevents NoSuchMethodError in existing resolver consumers.
        // 0.0.344-0.0.349: Published out of band by active entropy, direct/relay racing,
        //          and jvm-libp2p snapshot branches; 0.0.349 is the latest live coordinate.
        // 0.0.350: Keep announcement timestamps strictly above every withdrawal previously
        //          broadcast for the same service/provider across registration objects. A
        //          registration also floors its own withdrawal at its last announcement so a
        //          frozen or backward-moving wall clock cannot invert same-registration order.
        // 0.0.351: Issue every per-registration lifecycle timestamp through one monotonic
        //          allocator that floors against wall-clock time, the registration high-water,
        //          and an optional broadcaster-wide history capability. The capability is a
        //          separate interface so ServiceBroadcaster binaries compiled against 0.0.349
        //          remain loadable. Interrupted relay registration now completes its pending
        //          result exceptionally and closes every in-flight or late-winning stream.
        // 0.0.352: sendViaRelay races the routable-direct attempt with the explicitly
        //          selected relay instead of blocking on it (bounded, cancellable, tracked
        //          dial tasks; closed-state guards; commit-before-send exactly-once), restoring
        //          bounded relay-fallback latency for callers that orchestrate their own race
        //          (fixes UrlResolver stressTestRelayFallbackRacesDirectConnectionForNonNatPeer).
        //          This is the first coordinate combining that race with 0.0.351's monotonic
        //          lifecycle timestamps and interruption-safe relay-registration cleanup.
        //          NOTE: the published 0.0.347 artifact declared reachabilityTimeoutMs as a
        //          RelayConfig primary-constructor parameter, regenerating the data class's
        //          synthetic default-arguments constructor and breaking binary compatibility
        //          with resolver <= 0.0.628 (the 0.0.343 bridge guarantee). Do not pin 0.0.347.
        // 0.0.348: Moves reachabilityTimeoutMs into the RelayConfig class body, restoring the
        //          pre-0.0.347 constructor surface (guarded by
        //          tests/testUrlResolver0600CanConstructAgainstCurrentProtocol.kts) while
        //          keeping the dial-reachability budget tunable.
        // 0.0.364: Add an optional requestedResponsePeerIds projection to PeerExchange requests,
        //          rebased on 0.0.360's PeerRegistry service-index scaling fix.
        //          Legacy requests still receive the full shareable view; acknowledgement-style
        //          requests can bound response construction and wire/application work to the peers
        //          they submitted, preventing concurrent recovery exchanges from becoming O(N²).
        // 0.0.367: Same protocol source, rebuilt on jvm-libp2p snapshot-18 (pending
        //          peer-connect deduplication — duplicate dials to one peer previously
        //          wedged downstream confirmed-exchange recovery rounds at 17-30s each
        //          under 52-way registration saturation).
        // 0.0.368: RelayStreamController.sendMessage surfaces transport admission failure
        //          (bounded RelayException) instead of silently dropping non-admitted frames;
        //          adds caller-supplied admission budgets for close paths, monotonic saturating
        //          deadlines, backpressure-vs-closure discrimination for awaited control
        //          messages, and propagation through unregisterFromRelay and chunk fetches.
        // 0.0.369: Re-release of the 0.0.368 changelog content. The 0.0.368 artifact on
        //          kotlin.directory was published concurrently from a parallel branch and does
        //          NOT contain the admission-failure surfacing (verified: no RelayService class
        //          in that jar carries the non-admission contract); 0.0.369 is built from merged
        //          main and is the first artifact that actually ships it.
        // 0.0.370: Upgrade jvm-libp2p to snapshot-19 so Yamux reserves queued child writes
        //          against its connection-wide outbound budget before flow-control buffering.
        //          This bounds retained ByteBufs when relay fanout includes stalled peers.
        // 0.0.371: Distinguish relay failures that are guaranteed to precede target dispatch
        //          from delivery-ambiguous failures such as target timeouts and dropped replies.
        //          A backward-compatible marker in RelayResponse.errorMessage survives older
        //          relay re-encoding and becomes RelayRequestNotDispatchedException at the
        //          requester, allowing consumers to retry only operations that provably did not
        //          execute. Plain RelayException remains ambiguous and non-retryable.
        // 0.0.372: Bound response-chunk fetches across every mux substream sharing one root relay
        //          connection. Four simultaneous large responses previously admitted 4 × 10 fetches
        //          against a connection-wide 16-write park budget; a transient stall dropped the
        //          overflow replies and truncated otherwise healthy transfers. A fair connection
        //          semaphore now preserves the ten-fetch single-transfer pipeline while keeping the
        //          aggregate within the shared transport budget, and releases every permit on success,
        //          malformed replies, stream closure, timeout, interruption, and send failure.
        // 0.0.373: Registered targets send handler replies with the bounded five-second awaited
        //          delivery budget instead of the 200 ms best-effort gossip budget. A transient
        //          target-to-relay stall previously killed the registration listener and stranded the
        //          requester even when the connection recovered after 750 ms; awaited multi-hop
        //          forwards now use the same concrete RelayStreamController delivery path. Yamux
        //          relay streams also use a 2 MiB child-channel high watermark so the bounded window
        //          of ten ~175 KiB response-chunk replies is admitted as soon as a stalled root
        //          connection recovers. Once a parked writer observes that recovery, sibling replies
        //          from the same stall may enter the bounded Yamux child queue even if Yamux's
        //          protocol flow-control bit remains false or the TCP parent fills again before every
        //          waiting thread runs, avoiding a dependency on peer WINDOW_UPDATE timing past the
        //          five-second delivery deadline. A root that never
        //          recovers still fast-fails at five seconds. Snapshot-19 caps all child queues at
        //          10 MiB per connection, and only frames up to 256 KiB use the recovery exception,
        //          bounding the 16 parked writers to 4 MiB before that transport reservation applies;
        //          legacy mplex streams retain the 64 KiB watermark and strict parent gating because
        //          mplex has no equivalent connection-wide budget.
        //          Root-connection bookkeeping now also stops at an accepted socket instead of
        //          walking into its shared listening ServerChannel; previously every inbound peer
        //          on one listener accidentally shared a parked-write semaphore, and recovery
        //          markers observed the listener rather than the stalled requester connection.
        // 0.0.377: Retain relay withdrawal tombstones through reconnect grace and remember
        //          withdrawals that arrive before their matching announcements. Fresh joins and
        //          replacement registrations therefore cannot resurrect a service from an older,
        //          reordered announcement after its provider has withdrawn it.
        // 0.0.379: Treat the heap-scaled parse budget as a concurrency bound instead of a
        //          hard per-frame estimate limit. A valid frame whose conservative 7x estimate
        //          fills or exceeds the pool now reserves the whole fair semaphore and parses
        //          exclusively, so explicitly requested multi-megabyte responses remain usable
        //          on 128 MiB consumers without restoring concurrent parse amplification. The
        //          independent 10,000,000-byte wire cap still rejects pathological frames and
        //          now reports the actual frame, cap, estimate, amplification, and pool sizes.
        //          Versions 0.0.374-0.0.378 were published/reserved by parallel transport work.
        // 0.0.380: A /aicli-rpc/1.1.0 server returns optimized bytecode responses as raw
        //          binary attachments instead of the legacy multi-megabyte base64 JSON frame.
        //          The selected protocol is carried on the inbound stream, so 1.0 peers retain
        //          the byte-identical streaming/base64 wire form. Adds attachment-aware parsing
        //          for conditional bytecode results. This keeps the JSON envelope small enough
        //          for the existing heap-scaled parse-memory guard on 128 MiB consumers.
        // 0.0.381: Modernize shared scheduler ownership for clocks-simple 0.0.11. RelayService
        //          now cancels only the scheduled tasks it owns when closing instead of shutting
        //          down the caller-owned Clock, preserving shared clocks for other components.
        // 0.0.382: Add acknowledged in-place relay-registration refresh. A client that adds a
        //          service after establishing its relay connection can update advertisedServices
        //          on that same stream; the relay applies the new registration before ACKing it.
        //          Expose the refresh as a CompletableFuture so high-concurrency consumers can
        //          await the ACK without parking their bounded registration/recovery worker pools.
        // 0.0.384: Emergency gossip containment. GossipMessageTracker now enforces maxSize with
        //          oldest-first eviction even while every entry is live inside the TTL window.
        //          Relay server ingress supplies optional sender/relay ownership metadata so an
        //          aware resolver suppresses its duplicate registered-client fan-out while the
        //          RelayService keeps the required full hub-to-leaf distribution.
        // 0.0.390: Bring RPC v1.1 binary-attachment decoding under the same memory-accounting
        //          pool as JSON parsing. Both the InputStream reader and the Netty 1.1.0 decoder
        //          now (1) require the declared attachment count to equal the envelope's
        //          binary-reference count AND those references' __index values to form an exact
        //          BIJECTION with 0..count-1 (strict integer parse — no coerced numeric strings,
        //          fractions, or Int-overflow), (2) enforce a heap-scaled per-frame aggregate cap
        //          (MAX_ATTACHMENT_AGGREGATE_BYTES = maxMemory/4, clamped [32 MiB, 100 MB]) at
        //          each length header before allocating any body, and (3) take a SINGLE
        //          whole-pool-exclusive lease (FrameAttachmentLease) before reading the first
        //          attachment body, held across the frame — one acquisition, never a growing
        //          hold-and-wait reservation (which deadlocked the fair semaphore). Attachment
        //          frames thus serialize through the pool (they are the memory-heavy inbound
        //          messages) while non-attachment frames are untouched; a peer can no longer
        //          declare unreferenced/duplicate-indexed/oversized attachments to OOM a
        //          small-heap consumer, and legitimate tens-of-MB JARs still transfer. The Netty
        //          decoder takes the lease non-blockingly (off-loop admission on a BOUNDED pool)
        //          so it never parks the event loop on the shared pool. The outbound attachment
        //          writer chunks frames above 4 MiB into bounded, backpressured writes so large
        //          valid responses stay admissible under the muxer's connection-wide write budget.
        //          Versions 0.0.383-0.0.389 were published/reserved by parallel work.
        // 0.0.391: Make the whole-pool attachment lease starvation-free and liveness-safe (two
        //          liveness defects the 0.0.390 suite did not cover). (1) FAIRNESS: the Netty
        //          event-loop fast path (FrameAttachmentLease.tryAcquire) now uses the timed
        //          tryAcquire(permits, 0, NANOSECONDS) overload, which honors the FAIR semaphore's
        //          queue, instead of the untimed tryAcquire(permits) overload, which barges — a
        //          reused/hot attachment stream could otherwise repeatedly re-acquire the pool
        //          ahead of an already-queued blocking acquirer and starve it. (2) STALL TEARDOWN:
        //          while a reader holds the whole-pool lease, a peer that sends a valid envelope +
        //          count (enough to acquire the pool) then stops mid-frame would pin the GLOBAL
        //          attachment pool forever (the 30 s request timeout returned an error without
        //          closing the stalled stream). A minimum-progress stall watchdog
        //          (ATTACHMENT_STALL_TIMEOUT_MS, reset by every inbound byte so a slow-but-
        //          progressing transfer is never aborted) now force-releases the lease and tears
        //          down the stalled stream on a genuine no-progress stall, on both the InputStream
        //          reader and the Netty decoder; Libp2p/TcpRpcStream.sendRequest additionally close
        //          the stream on timeout so the parked reader unwinds; and NettyInputStream.close()
        //          now wakes a blocked reader (EOF) instead of being a no-op so evicting the stream
        //          actually unblocks it.
        // 0.0.392: Close the byte-dribbling slow-loris the 0.0.391 stall watchdog left open. The
        //          stall watchdog and the 120 s ReadTimeoutHandler are BOTH minimum-progress timers
        //          reset by any inbound byte, so a single authenticated peer holding the whole-pool
        //          FrameAttachmentLease could dribble ~1 byte every 9.9 s and pin the ENTIRE shared
        //          attachment pool — starving every other attachment transfer in the JVM — for the
        //          effectively unbounded time it takes to deliver MAX_ATTACHMENT_AGGREGATE_BYTES.
        //          Fix (root cause, not a mitigation): in ADDITION to the per-byte stall watchdog,
        //          an ABSOLUTE per-frame lease deadline (attachmentLeaseDeadlineMs) derived from a
        //          floor throughput (MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC = 4 KiB/s, floored at
        //          ATTACHMENT_MIN_LEASE_DEADLINE_MS = 60 s) now bounds how long a frame may hold the
        //          whole pool: a 32 MiB frame gets ~2.3 h and a 100 MB frame ~7.1 h (so any
        //          legitimate large-JAR transfer over a genuinely slow-but-real link completes with
        //          huge margin), while a sub-floor dribble is force-released and its stream torn
        //          down (reusing the existing force-release + NettyInputStream EOF-signal path). All
        //          the attachment stall/deadline timing is now driven off an injectable Clock
        //          (Libp2pRpcProtocol.attachmentClock, default SystemClock; tests drive ManualClock)
        //          so the liveness behavior is deterministically unit-testable without wall-clock
        //          sleeps. Both decode paths (InputStream readMessageFrameFromStream and the Netty
        //          AttachmentRpcFrameDecoder) enforce the deadline, sized from the running DECLARED
        //          aggregate (already validated + capped before allocation). Tests:
        //            tests/testSlowLorisAttachmentFrameAbortedByAbsoluteDeadline.kts (dribbler
        //              aborted by the absolute deadline; whole-pool lease released; independent
        //              transfer then completes SHA-verified — FAILS pre-fix, PASSES post-fix),
        //            tests/testSlowButProgressingAttachmentTransferCompletes.kts (an honest transfer
        //              staying above the floor completes SHA-verified and is NOT aborted),
        //            tests/testAttachmentSingleLengthGuardRejectsNegativeLength.kts (G5: the exact
        //              "Invalid attachment length: -1" per-attachment guard text).
        // 0.0.393: UNIFIED release. Carries the 0.0.390/0.0.391/0.0.392 attachment-memory
        //          accounting fixes (above) AND the authoritative relay withdrawal-delivery /
        //          recovery fix (UrlProtocol PR #389, previously published in isolation as the
        //          divergent 0.0.385-0.0.390 line). One coherent version so both UrlResolver
        //          consumers (#737 withdrawal-delivery, #813 attachment/bytecode) can pin the
        //          same protocol build. The delivery fix (RelayService):
        //            - Deliver authoritative ServiceWithdrawal frames through a shared, bounded
        //              five-second relay fan-out budget (forwardAuthoritativeWithdrawalToRegistered
        //              Peers + WRITE_BACKPRESSURE_DELIVERY_WAIT_MS) instead of the 200 ms
        //              best-effort gossip writer, so a transiently backpressured observer receives
        //              the withdrawal after its stream recovers, while delivery failures stay
        //              visible to the identity publication gate for retry rather than being
        //              silently discarded.
        //            - Route received ServiceWithdrawal fan-out through the identity publication
        //              gate so an unrelated stalled observer cannot close the healthy source stream.
        //            - A client keeps its relay listener alive until the relay acknowledges its
        //              unregister was parsed and committed; identity publication attempts every
        //              service withdrawal after an individual fan-out failure, retaining only the
        //              failed ones for a later generation.
        //            - Ordinary registered-peer gossip fan-out uses bounded per-peer serial
        //              outboxes serviced by a shared worker pool (each lane bounded to eight
        //              messages / 12 MiB, all lanes to 24 MiB) so stalled transports cannot block
        //              the caller or starve healthy peers, while authoritative withdrawals retain
        //              their separate reliable delivery budget.
        //            - doRegisterWithRelay is @Synchronized and a stale controller's no-op
        //              unregister no longer supersedes a replacement registration snapshot waiting
        //              to be published (subsumes PR #392's serialize-recovery-transactions work).
        // 0.0.394: Prepare each ordinary registered-peer gossip frame once and share its immutable
        //          bytes across every recipient outbox. Preparation is lazy on an outbox worker so
        //          the relay ingress thread remains nonblocking for large messages; the first worker
        //          serializes and all other workers reuse the result. Per-recipient ByteBuf views
        //          retain independent reader indexes/reference counts, the existing eight-message /
        //          12 MiB per-peer and 24 MiB global bounds remain enforced, and the JSON wire format
        //          is byte-for-byte compatible with older peers.
        // 0.0.396: Republish of merged main (#394 gossip-serialization + #395 throughput-bound test).
        //          No source change over 0.0.394. Corrects an artifact-parity defect: the previously
        //          published 0.0.395 jar was built from the unmerged fix/bounded-relay-ingress-dedup
        //          branch and shipped RelayService ingress-dedup classes that are NOT on origin/main.
        //          0.0.396 is the byte-for-byte compile of the merged tip so consumers can pin a
        //          version that matches main.
        // 0.0.397: Bound relay-ingress service-announcement deduplication by authenticated origin
        //          and service, with immediate change/withdrawal propagation and a slow heartbeat
        //          (the change 0.0.395 leaked prematurely, now landed via review on main). First
        //          coherent release carrying relay-ingress dedup; supersedes contaminated 0.0.395.
        // 0.0.399: Pluggable NetworkProvider seam (libp2p default) + hardened lifecycle + the
        //          in-process InMemoryNetworkProvider with deterministic handler scheduling and
        //          bounded-buffer backpressure, for deterministic large-mesh gossip testing.
        //          First published release carrying the full UrlResolverPluggableNetworkLayer
        //          Phase 1+2 surface (0.0.398 was an unrelated concurrent lane's bump).
        // 0.0.402: First published version carrying the Phase 3b protocol APIs from PR #407:
        //          queryServices(pattern) and requestBytecodeConditionallyFromService, plus
        //          InMemory fabric determinism hardening. Versions 0.0.400-0.0.401 were published
        //          by parallel work without PR #407.
        // 0.0.402 -> 0.0.403: provider-aware peer-specific RPC + real
        // requestBytecodeFromPeer over the seam.
        // 0.0.403 -> 0.0.404: preserve pre-listen primary-address dial deadlines
        // while supporting deterministic multi-address tests.
        // 0.0.404 -> 0.0.405: honor caller-supplied exact-peer response budgets through
        // the real libp2p stream using the caller's Clock instead of a fixed wall-clock cap.
        // 0.0.405 -> 0.0.412: relay registration catalogs keep revisioned desired and committed
        //          snapshots so refresh churn cannot replay a stale authoritative provider
        //          snapshot; every registration path sends the latest desired revision and only
        //          the matching successful ACK advances committed state. Also removes the
        //          RelayService monitor from abandonUnacknowledgedRelayConnection, which
        //          previously let a same-relay recovery registration wait forever on its own
        //          ACK future: the waiter held the monitor inside doRegisterWithRelay while the
        //          timeout/rejection callback needed that same monitor to complete the future
        //          (PR #408). Versions 0.0.406-0.0.409 were published by a parallel lane;
        //          0.0.410 and 0.0.411 are unpublished but left free for it to consume.
        // 0.0.412 -> 0.0.413: a bounded PeerExchange projection may return the
        //          Noise-authenticated responder's own self record without requiring a fabricated
        //          submitted record; requests for unrelated third-party records remain constrained
        //          to the submitted IDs. This change was originally cut as 0.0.398 from this PR's
        //          pre-rebase branch state; that jar was published before the branch was rebased
        //          onto the NetworkProvider-seam work and is now an orphaned artifact that does
        //          not correspond to any merged tree (main's 0.0.399 note above records the same
        //          version as "an unrelated concurrent lane's bump"). 0.0.413 is the first free
        //          coordinate above main's 0.0.412: 0.0.406-0.0.409 are published, 0.0.410-0.0.411
        //          are reserved by the parallel relay-lifecycle lane, and 0.0.412 is main's own.
        // 0.0.413 -> 0.0.414: send the optimized own-implementation bytecode response over raw TCP
        //          as a small JSON envelope plus a raw binary attachment instead of a
        //          multi-megabyte base64 JSON string, so a constrained-heap service JVM no longer
        //          serializes the serve path through the shared JSON parse budget and no longer
        //          holds the payload several times over in heap. The raw-TCP attachment writer
        //          emits framing and the raw arrays directly rather than aggregate-copying the
        //          complete payload. A negotiated libp2p 1.0 stream retains its legacy streamed
        //          base64 wire format. This change was originally cut from this PR's pre-rebase
        //          branch as 0.0.398; that coordinate had already been published by an unrelated
        //          concurrent lane (see main's 0.0.399 note above) and is an orphaned artifact, so
        //          the rebase renumbers it. 0.0.414 is the first genuinely free coordinate:
        //          kotlin.directory publishes through 0.0.409 (maven-metadata + per-version POM
        //          probes: 0.0.406-0.0.409 return 200, 0.0.410 and above return 404), 0.0.410-0.0.411
        //          are reserved by the parallel relay-lifecycle lane (open PR #421 claims 0.0.411),
        //          0.0.412 was main's previous coordinate and 0.0.413 is main's current one,
        //          publishing now from the PR #400 merge.
        // 0.0.418 -> 0.0.419: generic ByteArray RPC responses on negotiated libp2p 1.1 streams
        //          use binary attachments instead of being materialized as Base64 JSON.
        // 0.0.419 -> 0.0.420: preserve one coherent peer-observation snapshot while preparing
        //          bootstrap rankings and exactly accelerate equal-score capacity eviction when
        //          IPv4 addresses repeat, avoiding quadratic churn under concurrent registration.
        // 0.0.420 -> 0.0.423: normalize fractional JSON values from org.json BigDecimal objects
        //          to JVM Double values before RPC handlers and sandbox consumers receive them.
        //          0.0.421 and 0.0.422 are reserved by concurrent development branches.
        // 0.0.423 -> 0.0.424: publish each peer's observation record before registry membership
        //          so concurrent readers never see a retained peer without score state.
        // 0.0.424 -> 0.0.425: start the in-memory fabric's callback worker when work is queued
        //          during an active drain, so runUntilIdle does not leave accepted work stranded.
        // 0.0.425 -> 0.0.427: publish one immutable peer-observation snapshot on actual mutation;
        //          unchanged snapshot() calls are O(1) volatile reads. 0.0.426 was already published
        //          by a concurrent lane without this snapshot-caching change.
        // 0.0.427 -> 0.0.428:
        //          - Bound outbound dialing, evict repeatedly-failing peers, and reject undialable
        //            learned addresses. Outbound dials now pass through a process-wide admission
        //            bound (Libp2pNetworkProvider.MAX_CONCURRENT_OUTBOUND_DIALS), so no number of
        //            gossip fan-outs can leave more than that many half-open sockets outstanding.
        //            PeerRegistry counts consecutive dial failures, evicts a peer after
        //            MAX_CONSECUTIVE_DIAL_FAILURES, and quarantines it for
        //            DIAL_FAILURE_QUARANTINE_MS so gossip cannot immediately re-add it.
        //          - Compose the revisioned desired/committed relay catalogs with the relay-state
        //            corrections: report the relay that acknowledged registration and reset
        //            same-relay reconnect failures only after acknowledged registration.
        //          - Maintain exact repeated- and distinct-IPv4 eviction-victim indexes, reuse the
        //            published registry-membership snapshot until mutation, and reserve the fair
        //            publication gate for completed over-capacity eviction batches. Publish
        //            observation snapshots and score shapes atomically, and keep same-peer
        //            membership generations ordered while unrelated below-capacity additions
        //            publish independently.
        // 0.0.428 -> 0.0.429: Retain awaited RPC responses under bounded connection
        //          backpressure, and pass canonical streamed bytecode proxy responses through
        //          without scanning their multi-megabyte base64 payload with JSONObject. Small
        //          control, compatibility, not-modified, and error frames retain JSON parsing.
        // 0.0.429 -> 0.0.430: normalize binary ByteArray and nested JSON bytes-marker bytecode
        //          responses at proxy boundaries to the public base64 response contract.
        // 0.0.429 -> 0.0.430: Stream attachment frames above 1 MiB through the bounded,
        //          connection-serialized writer so four concurrent 1 MiB responses do not
        //          exceed the 4 MiB awaited-response outbox through framing overhead.
        // 0.0.431 -> 0.0.432: Add the candidate registration lifecycle. Version 0.0.431 was
        //          already published from another branch before this change reached main.
        //          Compose the revisioned desired/committed relay catalogs with the
        //          relay-state corrections: report the relay that acknowledged registration and
        //          reset same-relay reconnect failures only after acknowledged registration.
        //          Acknowledged relay candidates can be prepared concurrently, then
        //          exactly one can be committed while losing candidates are canceled asynchronously.
        //          Tests: tests/testConcurrentRelayCandidatePreparesOverlap.kts,
        //          tests/testRelayCandidateCommitChoosesExactlyOneWinner.kts,
        //          tests/testLateRelayCandidateAcknowledgementCannotReplaceWinner.kts, and
        //          tests/testCancelInFlightRelayCandidateDoesNotBlockWinner.kts,
        //          tests/testRelayCandidatePreparationBudgetExpiresAndClosesStream.kts,
        //          tests/testPreparedRelayCandidateDoesNotAdvertiseServicesBeforeCommit.kts, and
        //          tests/testRelayCandidateCanCommitAfterUnregisteringPreviousWinner.kts, and
        //          tests/testRelayCandidateCommitReportsRejectedCatalogPublication.kts, and
        //          tests/testRelayCandidateCanCommitAfterSelectedConnectionDrops.kts, and
        //          tests/testOlderFailedCandidateCannotClearNewerSameRelayGeneration.kts,
        //          tests/testFailedOrdinaryRelayDialCannotClearCommittedCandidate.kts, and
        //          tests/testOrdinaryRelayDialCannotOverwriteCommittedCandidate.kts,
        //          tests/testConcurrentSameRelayPreparationCannotEraseCommittedRoute.kts, and
        //          tests/testStaleReconnectCannotRestoreFailuresAfterCandidateCommit.kts.
        // 0.0.432 -> 0.0.433: Preserve the relative order of surviving peers when a closed
        //          concurrent-add batch publishes after capacity eviction. The published snapshot
        //          now retains existing positions and appends new peers by visibility sequence
        //          instead of replacing public order with ConcurrentHashMap iteration order.
        // 0.0.432 -> 0.0.435: isolate local TCP request handlers so a group waiting on one
        //          dependency cannot consume the complete shared request dispatcher and prevent
        //          unrelated handlers from starting. Version 0.0.433 was already published from
        //          another branch before this change reached main. Version 0.0.434 exposed that
        //          historical GossipHandler binaries need explicit bridges for Kotlin defaults;
        //          0.0.435 preserves those declared defaults at every inbound-message call site.
        // 0.0.435 -> 0.0.436: add an ordered PeerRegistry lifetime signal so a consumer can
        //          finish old-lifetime cleanup before the same peer ID is admitted again.
        // 0.0.436 -> 0.0.437: dispatch lifetime callbacks outside registry locks while keeping
        //          the old-generation handoff ahead of a later re-add.
        // 0.0.437 -> 0.0.438: strengthen public callback re-entry and offline-pruner callback-order
        //          coverage after independent round-3 confirmation of the lifetime handoff.
        // 0.0.441 -> 0.0.442: Keep chunked relay payload assembly alive from the last chunk, inject its idle clock, and reject failed chunk acknowledgements.
        // 0.0.442 -> 0.0.443: reject peer-lifetime removal re-entry before registry mutations,
        //          prevent callback handoff cycles, and always finish every batch handoff.
        // 0.0.443 -> 0.0.444: run later captured lifetime callbacks before releasing their
        //          handoffs when an earlier removal ends a batch with a fatal failure.
        // 0.0.444 -> 0.0.445: finish callback and persistence cleanup for every victim even when
        //          callers reuse one Throwable or an earlier fatal batch failure aborts normal dispatch.
        // 0.0.442 -> 0.0.446: carry provider-authored service lifecycle timestamps in the
        //          additive PeerInfo catalog map. Missing maps and entries remain explicitly
        //          unknown for peers using the older catalog shape. Versions 0.0.443 and 0.0.444
        //          were published by another work lane, and 0.0.445 is reserved by its open PR.
        // 0.0.446 -> 0.0.455: preserve lifecycle timestamps through peer announcements and relay
        //          peer lists, and include immutable lifecycle snapshots in PeerInfo value operations.
        //          Version 0.0.448 was never published. Versions 0.0.450 and 0.0.451 belong to the
        //          relay flow-control lane; 0.0.449 and 0.0.452 through 0.0.454 are already occupied.
        //          This version adds propagation of that field through peer announcements and relay
        //          peer lists while retaining the legacy three-argument PeerInfo API and treating
        //          missing data as explicitly unknown. Version 0.0.455 is the peer-catalog
        //          lifecycle-timestamps release from
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/484.
        // 0.0.455 -> 0.0.456: Preserve completed RPC responses when a one-shot TCP or libp2p
        //          stream closes immediately after its response (compare-and-set in the stream
        //          cleanup paths). Originally prepared as 0.0.454; renumbered because versions
        //          through 0.0.455 were published by concurrent lanes before this fix reached main.
        // 0.0.456 -> 0.0.457: Run a registered peer's relayed request handler off the relay
        //          connection's reader thread. startRequestListener used to invoke the handler
        //          inline and write the reply before reading again, so a handler that took
        //          seconds stopped every later frame on that connection from being read —
        //          including the next chunk of an in-progress chunked upload, which then died on
        //          the caller's deadline. The reader now takes one of
        //          MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS permits, hands the handler call and
        //          the reply write to a virtual-thread executor, and returns to reading. This
        //          mirrors the asynchronous reply path the relay side of the same connection
        //          already uses (forwardRequestToRegistered). reassembleAndHandle now decides
        //          completeness and removes the assembly under one lock so concurrent chunks of
        //          one transfer cannot both invoke the handler. Threading only: no wire format
        //          change, no negotiation, and no new RelayConfig constructor parameter.
        // 0.0.457 -> 0.0.458: this branch carries the ordered peer-lifetime signal through callback, re-entry,
        //          observation-ordering, capacity-eviction, dial-failure, pruning, and persistence
        //          cleanup paths. The previous lifetime's callbacks and handoff complete before a
        //          replacement generation becomes visible, while later batch victims still finish
        //          their captured callbacks after an earlier fatal failure.
        // 0.0.458 -> 0.0.459: expose accepted PeerRegistry add operations through a synchronous
        //          listener so consumers can record mutation provenance directly instead of
        //          inferring it from post-merge object identity.
        // 0.0.459 -> 0.0.460: make add origin explicit at PeerRegistry's mutation boundary and
        //          retain caller authorship plus the latest accepted origin for each peer lifetime.
        //          UrlProtocol marks every catalog, discovery, relay, and persistence path. Ordered
        //          add events carry that state and lifetime, isolate listener failures, respect exact
        //          subscription close, and complete before the same lifetime's removal callbacks.
        // 0.0.460 -> 0.0.461: reject peer membership mutation from add-listener callbacks before
        //          state changes, order optional persistence inside each same-peer accepted-add
        //          completion so removal cannot be followed by a stale atomic move, propagate fatal
        //          listener errors, and bound retained ordinary listener-failure diagnostics.
        // 0.0.461 -> 0.0.462: remove the unconsumed PeerRegistry add-event/listener surface and its
        //          delivery, re-entry, ordering, and failure-diagnostic machinery while retaining
        //          queryable origin state. Coordinate every accepted-add and saveAll peer-file
        //          write with the exact lifetime so removal finishes the write before deleting the
        //          file, or makes a later stale write skip that lifetime.
        // 0.0.464 was published from a tree that also carried an unproven pooled-connection
        //          change; it is superseded by 0.0.465 and should not be depended on.
        // 0.0.462 -> 0.0.465: never refuse to DISPATCH a relayed request just because the eight
        //          bounded dial workers are busy. Racing the direct and relay paths is a latency
        //          optimization, so when no worker is free the two dials now run on the caller's
        //          own already-blocked thread instead of throwing RelayRequestNotDispatchedException
        //          before a byte is attempted. Also: a frame that sendMessage never admitted to the
        //          transport is reported as not-dispatched (retriable) rather than as an ambiguous
        //          delivery, and RelayService.dialCapacity() exposes dial saturation and inline
        //          dial fallbacks. 0.0.463 was published from the read-idle pause fix.
        // 0.0.465 -> 0.0.466: stop the awaited-response outbox drain from writing a queued response
        //          into the middle of a chunked attachment frame on the same substream. The drain
        //          runs on the connection event loop and is the one frame writer that cannot take
        //          the per-stream write lock, so a response still queued when a large attachment
        //          frame began was emitted between two 256 KiB body chunks; the receiver copies
        //          exactly the declared attachment length, so that frame's bytes became payload and
        //          its four-byte length prefix put a zero at the chunk boundary — a wrong byte at
        //          payload offset 262144 — and left the substream desynchronized for every later
        //          frame. A substream now carries an in-flight chunked-frame marker that the drain
        //          reads (never blocking the loop on a lock a parked writer holds), and the frame's
        //          completion schedules the deferred drain.
        // 0.0.466 -> 0.0.467: never commit a relayed request to a connection whose response leg
        //          cannot be observed. InboundSubstreamAdmissionControl pauses a connection's
        //          PARENT reads at the per-connection substream cap; a paused parent never takes a
        //          peer's FIN off the socket, so channelInactive never fires, pooled relay request
        //          streams report isClosed()==false forever, and a request written on one is
        //          delivered and executed with no path for its reply. That state never self-heals:
        //          the pause lifts only when live substreams drain, and they can only drain by
        //          reading. RelayStreamController.canCarryResponse now also requires that the root
        //          connection is not admission-paused, pool checkout/release use it and close what
        //          fails, and connectToRelay's fast path declines an admission-blind connection.
        // 0.0.466 -> 0.0.467: recheck the same response-read admission state at the actual Netty
        //          write handoff so a pause that begins after pool selection cannot admit a request.
        // 0.0.467 -> 0.0.468: combine the connection-ownership fix (PR #512, keep the owner of a
        //          dial the bounded pool accepted when it refuses the other) with the gossip
        //          fan-out fix (PR #514, do not evict healthy service providers on local
        //          send-fault gossip fan-outs) so a starved local host stops evicting healthy
        //          providers and failing 'No peer found' lookups under load.
        // 0.0.468 -> 0.0.469: give a relay its own correlation id for every request it forwards
        //          (restoring the requester's id on the reply), key chunk assemblies by source peer
        //          plus transfer id, and add a per-process nonce to both id generators. A request id
        //          minted as a timestamp plus a per-process counter is unique only within the
        //          process that minted it, so two clients that start together present the same id;
        //          the relay's single correlation map then let the second registration displace the
        //          first waiter, and the displaced client never received a reply.
        // 0.0.469 -> 0.0.470: keep a forwarded service announcement tied to the provider identity
        //          it names. Provider disconnect removes replay entries even when an observer stream
        //          last forwarded the copy, and the bounded disconnected-provider tombstone state
        //          rejects later copies during registration grace. A successful re-registration,
        //          tombstone expiry, or bounded eviction clears that admission marker.
        // 0.0.470 -> 0.0.477: avoid clock scheduling for immediately available in-memory I/O,
        //          bulk-copy ring-buffer spans, and only collect alternate registered addresses
        //          when reporting an invalid in-memory dial target.
        // 0.0.477 -> 0.0.482: converge main with the published 0.0.481 transport behavior by
        //          reusing bounded in-memory pipe storage and returning immediate dials after
        //          starting their sequenced handler. Coordinates 0.0.478, 0.0.479, and 0.0.481
        //          were already published from the transport-optimization branch.
        // 0.0.482 -> 0.0.484: keep ServiceQuery handling available while PeerExchange callbacks
        //          wait by scheduling it on the independent RPC dispatcher. Bound chunked relay
        //          request storage on disk and completed-request materialization in heap; keep a
        //          completed transfer's ownership marker through handler return, reject oversized
        //          Base64 chunks before decoding, cap materialization at half of small JVM heaps,
        //          and require exact signed-Int JSON chunk metadata. Coordinate 0.0.483 is reserved
        //          by https://github.com/CodexCoder21Organization/UrlProtocol/pull/527.
        // 0.0.484 -> 0.0.488: let a consumer read a bytecode response where it lies. A response
        //          that arrived as JSON — the ordinary case behind a relay, whose hop re-serializes
        //          the frame and drops its binary attachments — could only be turned into a
        //          BytecodeResponse by serializing it back to a string and parsing that, and for
        //          bytecode the string is the payload again. A 4 MB client JAR was therefore held
        //          four times over, which is how url://aiclisupervisormanager/ exhausted a 128 MB
        //          heap on a transfer it was only relaying through. parseResponse and
        //          parseConditionalResponse now accept a JSONObject, parseConditionalResponseFromResult
        //          accepts one too, and a Map carrying base64 jarBytes is decoded in place rather
        //          than rejected.
        //          Coordinates 0.0.485 through 0.0.487 are already published from other branches.
        // 0.0.488 -> 0.0.489: record a registering peer's direct-contact observation when its
        //          registration is accepted, before the acknowledgement is written, instead of
        //          only when the shared identity-publication worker later drains. That worker also
        //          performs blocking withdrawal writes for unrelated providers, so an acknowledged
        //          provider could stay absent from the observation log — and therefore from
        //          peer-exchange sharing and every other observation gate — for as long as the
        //          worker was busy.
        // 0.0.489 -> 0.0.498: integration of the eight reviewed flake-campaign fixes, landed
        //          together because each one's branch kept failing CI on a flake that a different
        //          unlanded branch cures, so none of them could go in one at a time under load.
        //          Six of the lanes each claimed their own coordinate (0.0.490 through 0.0.497);
        //          those claims are superseded by this one entry. 0.0.494 is published from an
        //          unrelated branch and 0.0.498 is the first free coordinate above every claim.
        //          PR #540 is tests-only and PR #548 touches no build script, so neither claimed a
        //          coordinate. The eight, in landing order:
        //
        //   * PR #537 (claimed 0.0.490): keep link-state fan-out off the shared virtual-thread scheduler
        //     keep a link-state re-flood's completion off the JVM-wide
        //     virtual-thread scheduler. The fan-out dispatched one task per destination to a
        //     virtual-thread executor and awaited the resulting futures with no deadline, so an
        //     advertisement completed only once every task had been scheduled. A virtual thread
        //     that blocks entering a contended synchronized block occupies its carrier and is
        //     never compensated for, so once availableProcessors() of them exist anywhere in the
        //     process no fan-out task runs at all and receiveLinkStateAdvertisement blocks
        //     indefinitely — far past the 200ms transport-admission budget that bounds the work
        //     itself. The fan-out now spends one shared budget on the calling thread, offering
        //     the frame to every still-pending destination through the existing non-blocking
        //     admission probe, so a re-flood still costs one bounded wait rather than one per
        //     recipient and no longer depends on another scheduler.
        //   * PR #538 (claimed 0.0.491): publish an inbound admission pause only once it is applied
        //     fix the order in which InboundSubstreamAdmissionControl publishes a
        //     connection's read state, in two places.
        //     (1) The one that affects request routing. applyReadState used to sample
        //     globalPaused BEFORE acquiring the parent's read-state monitor and then apply that
        //     stale answer inside it. A per-connection resume could therefore compute
        //     shouldRead=true, block on the monitor while pauseGlobal applied autoRead=false
        //     and recorded the parent as held, and then overwrite that record with its stale
        //     true — leaving inboundReadsPausedByAdmission reporting a globally held connection
        //     as readable. That is the answer RelayService consults before committing a request
        //     (RelayService.kt canCarryResponse / commitIfInboundReadsObservable), and a
        //     request committed to a connection that is not reading is executed one hop further
        //     on with no path for its response — the orphaned-session failure. globalPaused is
        //     now read under the monitor, so the last writer of the channel is also the last
        //     reader of the policy. The global pause POLICY was unchanged by that PR — visit()
        //     still read globalPaused so a connection first seen during an active global pause
        //     inherited it — but the path that applies it is no longer subject to that
        //     overwrite. (SUPERSEDED by 0.0.499 below: the aggregate cap no longer pauses reads
        //     at all, so there is no global term left to read under the monitor; the surviving
        //     per-connection term is now the one read there.)
        //     (2) The published diagnostic. pausedConnectionCount() is a public API with no
        //     in-tree production callers; downstream consumers read it and the tests assert on
        //     it. resumeConnection cleared its flag first and applied the resume afterwards, so
        //     the count reported a connection as free of its own admission pause while that
        //     pause was still on the channel. The flag and Netty's autoRead are two separate
        //     writes and no ordering makes both directions atomic to an unsynchronized reader,
        //     so the count is now conservative in one direction only: pauseConnection still
        //     publishes first (counting a connection slightly early costs a reader nothing),
        //     while resumeConnection restores the channel before clearing the flag. Both values
        //     are volatile, so a reader that sees a connection unpaused sees the already
        //     restored channel. The count deliberately does not answer "is this connection
        //     reading?" — a connection out of the count can still be held by the global pause;
        //     its KDoc now says so and points at isGloballyPaused().
        //     resumeConnection keeps a lock-free fast path on the flag, so an ordinary
        //     substream close still never acquires the read-state monitor on the Netty event
        //     loop. Proven by tests/stressTestInboundAdmissionPauseIsPublishedOnlyWhenApplied
        //     .kts (FAILS with 560 and 946 observations of the unsafe direction over two runs
        //     with the resume ordering reverted; 0 across three runs with it) and, at the time,
        //     tests/testPerConnectionResumeDoesNotLiftGlobalInboundPause.kts, which pinned the
        //     global/per-connection overlap (rewritten by 0.0.499 as
        //     tests/testAggregateCapSuspendsPerConnectionInboundPause.kts). 0.0.490 is skipped: it is claimed by the open
        //     link-state fan-out lane (PR #537).
        //     Coordinates 0.0.490 and 0.0.491 are claimed by other in-flight branches.
        //   * PR #539 (claimed 0.0.492): deliver inbound frames accepted before a TcpRpcStream close
        //     deliver the non-response frames TcpRpcStream already read off the
        //     wire even when the stream then closes. close() and the reader loop's EOF path
        //     both cleared the bounded inbound handoff, and the callback worker exited on
        //     `closed` without draining it, so a peer that pushed frames and immediately
        //     disconnected lost those frames while the response written behind them — which
        //     is correlated inline on the reader thread — was still delivered. The worker now
        //     drains what was accepted before the close and only then ends its lane.
        //   * PR #544 (claimed 0.0.493): pipeline relay request chunks within a bounded window
        //     pipeline sendViaRelay's request chunks within a bounded window instead
        //     of writing one 128 KiB chunk frame and blocking on its interim acknowledgement
        //     before writing the next. A chunked upload cost one relay round-trip per chunk
        //     (64 for an 8 MiB payload), so every scheduling delay was multiplied by the chunk
        //     count; it now costs about ceil(chunks / window) round-trips.
        //     Two properties of the window are NOT copied from the response direction, because
        //     the two directions put very different numbers of bytes on the wire per in-flight
        //     item (a request chunk is a ~175 KB frame; a response-chunk fetch is a few hundred
        //     bytes), and both were forced by measurement rather than chosen:
        //       - The window is bounded in BYTES, not frames. In-flight request-chunk bytes stay
        //         at or below the transport's 1 MiB write low-water mark (five frames, 874 KB),
        //         so a transfer never pushes its own channel into the unwritable range where its
        //         next frame fails admission outright.
        //       - The window opens at one frame and widens by one per acknowledgement, so senders
        //         that start together do not put a combined opening burst on a relay's ingress.
        //     Each direction keeps its OWN connection-wide budget sized by its own byte footprint
        //     (five request-chunk sends, ten response-chunk fetches, unchanged), so their sum
        //     respects both the write watermark and the connection's 16 parked-write permits.
        //     sendViaRelay also identifies each reply by content rather than by arrival order,
        //     since a relay answers forwarded chunks from an async completion and the protocol
        //     never guaranteed that reply i belongs to chunk i.
        //     Coordinates 0.0.490 through 0.0.492 are claimed by concurrent open branches.
        //   * PR #546 (claimed 0.0.496): cut PeerRegistry membership and eviction cost
        //     cut the per-operation cost of PeerRegistry membership publication and
        //     eviction victim selection. Publishing one completed add or one removal walked
        //     the whole published snapshot comparing peer IDs — which share a long common
        //     prefix — and re-added every member one element at a time; it now locates the
        //     affected position once and bulk-copies. The greedy eviction ranking resolved
        //     each candidate's score through a TreeMap and its insertion sequence through
        //     Map.getValue on every one of its O(n^2) comparisons; those inputs are now
        //     resolved once per candidate. The tied-score cold eviction path likewise reads
        //     each candidate's insertion sequence once instead of twice per comparison.
        //     Coordinates 0.0.490 through 0.0.495 are claimed by other open branches.
        //   * PR #547 (claimed 0.0.497): move relay JSON framing off org.json's per-character locking
        //     stop paying org.json's per-character monitor on relay and RPC frames.
        //     Serialization went through JSONObject.toString(), whose StringWriter wraps a
        //     synchronized StringBuffer, and parsing went through JSONObject(String), whose
        //     StringReader synchronizes read/mark/reset; both walk a string one character at a
        //     time, so every character of every frame took a lock. Both now drive the same
        //     org.json serializer and parser over unsynchronized buffers, which leaves the
        //     emitted bytes, the accepted values, and the parser's error offsets unchanged.
        //     This covers string VALUES: JSONObject.write emits each KEY through the one-
        //     argument quote(), which keeps its own private StringWriter, so key-dominated
        //     objects are unchanged (measured 0.95x) while the value-dominated frames this
        //     protocol carries are 2.1x-4.4x. It does not touch the StringBuilder JSONTokener
        //     grows internally while accumulating a token. One behavior change: a failed
        //     serialization now raises org.json's JSONException instead of JSONObject.
        //     toString() returning null and surfacing as a bare NullPointerException.
        //     Coordinates 0.0.490 through 0.0.496 are reserved by other open branches.
        //   * PR #548 (no coordinate claimed): close a relay registration's pending catalog
        //     acknowledgement when its stream closes. Pending catalog entries did not record the
        //     connection that owned them, so a closed registration stream left its acknowledgement
        //     future pending for the full ten-second clock instead of failing as soon as the
        //     owning connection went away. This is the cure for
        //     testOlderFailedCandidateCannotClearNewerSameRelayGeneration, the campaign's most
        //     frequent rotating victim. Carried here from another session's branch with
        //     attribution; reviewed separately.
        //   * PR #552 (0.0.499): the aggregate inbound-substream cap no longer stops any
        //     connection reading. It used to engage by disabling autoRead on every connection's
        //     parent channel, and applied that standing pause to each newly seen connection the
        //     first time an inbound substream arrived on it, including connections holding none
        //     of their own. A connection that does not read does not read its peer's FIN, so it
        //     is never closed and never released; and since the cap lifts only when an inbound
        //     substream closes — which itself needs a read — a cap reached against departed
        //     peers never lifted, every connection accepted afterwards was frozen on arrival,
        //     and the host accumulated one stranded live connection per dial until the heap was
        //     gone. Measured on ContainerNursery's churn reproducer: victim descriptors 238 ->
        //     14,611 in ~50s at exactly the peer's dial rate with zero releases while the peer's
        //     own count stayed flat at 325, 14,383 of those sockets in CLOSE_WAIT, and a heap
        //     with the aggregate count pinned at exactly maxGlobal and autoRead disabled on all
        //     but 6 of 15,055 retained channels.
        //     The cap now refuses the excess substream and SHEDS the connection that asked for
        //     it, which is also the only aggregate bound this class has: the muxer builds a
        //     substream's scaffolding before the stream pre-handler runs, and the muxer's own
        //     ceiling on that (jvm-libp2p maxInboundStreams, 512 by default, not configured
        //     here) is per connection, so across N connections it bounds N x 512 rather than the
        //     aggregate. Shedding bounds N. While the cap is engaged it also SUSPENDS
        //     per-connection read pauses, because such a pause can admit nothing at that point
        //     and can only hide a departure — which is what let departed peers pin the count and
        //     latch the cap permanently.
        //     applyReadState now samples pausedByConn under the read-state monitor: with the
        //     global term gone it was the only policy input left, and sampling it outside let a
        //     visit()/resumeConnection interleaving leave autoRead=false with pausedByConn=false,
        //     unrecoverable and the same stranding signature.
        //     tests/testGlobalInboundSubstreamPauseDoesNotStrandOtherConnections.kts (new),
        //     tests/testAggregateInboundCapRefusesSubstreamsBeyondTheCap.kts (new — the
        //     aggregate bound had no coverage at all before),
        //     tests/testAggregateInboundCapRecoversWhenPausedPeersDepart.kts (new — the cap
        //     cannot latch), and the two tests that pinned the withdrawn contract rewritten as
        //     tests/testNewConnectionKeepsReadingDuringActiveGlobalInboundCap.kts and
        //     tests/testAggregateCapSuspendsPerConnectionInboundPause.kts.
        //     Shedding carries the whole aggregate bound, so it is guarded directly rather than
        //     via the counters around it: deleting the shed leaves every counter assertion green
        //     while every refused connection stays up, which is the same gap one level up.
        //     tests/testAggregateInboundCapShedsRefusedConnections.kts requires a refused peer's
        //     connection to leave the transport AND the network connection table, the peer to see
        //     it closed from its own side, and the server's live connection count to stay at the
        //     holder alone while eight peers are refused.
        //     Two consequences are deliberate and pinned rather than left to be discovered.
        //     (a) While the aggregate cap is engaged, a peer at its OWN cap is shed rather than
        //     throttled, because suspension has resumed its reads and its next request is over
        //     both caps: under saturation the host can serve no inbound substream at all, so a
        //     connection both at its own cap and still asking is one of the largest holders of a
        //     pinned budget and is the right one to drop. It costs that peer its in-flight work.
        //     tests/testAggregateCapShedsAPeerThatIsAlsoAtItsOwnCap.kts.
        //     (b) Connections we DIALLED are never shed. A responder substream can arrive on an
        //     outbound connection, so shedding the asker unconditionally let a remote peer choose
        //     which of our outbound connections died and abort our own in-flight work on it. Our
        //     outbound set is bounded by our own dialling, so bounding the accepted set is enough.
        //     tests/testAggregateCapDoesNotShedAConnectionWeDialled.kts.
        //     Re-dial churn after a shed costs a full handshake per attempt; that is the
        //     backpressure signal and it is self-limiting, since each shed releases budget.
        //     Residual documented in the read decision: fewer than maxGlobal / maxPerConnection
        //     connections stranded by their own pause never aggregate to the cap, so nothing
        //     suspends their pauses; bounded (~3 x 256 x 5 KB) and self-healing the moment a
        //     fourth arrives.
        // 0.0.490: add the bounded relay request window and preserve queued reply delivery at
        //          transport teardown. The earlier flake-campaign claims on this coordinate were
        //          superseded by the published 0.0.498 aggregate; 0.0.499 is also already
        //          published from main, leaving 0.0.490 as the first unused coordinate for PR #541.
        //   * PR #551 (0.0.500, published 2026-08-31): selectBestRelay(targetPeerId) now removes
        //     the destination peer before choosing the public-relay tier or falling back to all
        //     relays. This prevents a service provider that also advertises relay capability from
        //     being selected as the relay used to reach itself, while preserving an eligible
        //     private fallback when the destination was the only public relay.
        // 0.0.501: integrate the target-aware relay selection and queued-reply teardown changes.
        // 0.0.502 and 0.0.503 were published after that integration.
        // 0.0.504 is claimed by an open TCP lifecycle branch.
        // 0.0.505: remove the bytecode child helper's probe-and-rebind gap by binding TcpServer(0)
        //          once and reading the established localPort API. Also publish in-memory handler
        //          starts atomically with successful stream opens, recheck TCP response-outbox
        //          backpressure after a blocking frame read, and directly select a unique
        //          representable zero-score peer for a single eviction.
        // 0.0.508: reject same-thread active-action removal before registry lock waits.
        // 0.0.509: add atomic PeerRegistry removal conditioned on the current PeerLifetime.
        // 0.0.510: complete unregister locally when a registration stream has already lost its
        //          response path, while retaining exact logical-generation cleanup ownership.
        // 0.0.514: preserve retained announcement timestamp order across relay-cache admission paths.
        // 0.0.516: refuse inbound overflow at either cap without closing work in either direction;
        //          serialize terminal registration, report retirement failures to the owner and
        //          transport, and recover the cap-report baseline after clock rollback. Restore
        //          readable parents and actual read demand on admission read failures; retain terminal read throttling
        //          across failed close attempts.
        // 0.0.517: preserve unregister generations, end ACK waits on departure, and clock reconnect intent.
        // 0.0.518: wait for active lifetime actions before taking the peer mutation lock for removal.
        // 0.0.520: release registry locks across active-action waits and preserve generation-ordered publication.
        // 0.0.523: expose a test-only committed relay registration gate guarded by the relay
        //          lifecycle lock, including exact open connection-generation validation.
        // 0.0.524: publish TCP connection-close state before interrupting request handlers.
        //          Versions 0.0.522 and 0.0.523 are reserved by parallel work.
        // 0.0.525: re-pin to current main after a staleness audit found six post-0.0.524 merges
        //          absent from the published artifact. The TCP close-publication work remains in
        //          0.0.524; this release carries the six named relay, admission, and verification
        //          merges:
        //          - merge #590 (https://github.com/CodexCoder21Organization/UrlProtocol/pull/590)
        //            waits for TCP admission to be released before disconnect recovery;
        //            testTcpServerDoesNotQueueHandlerErrorForDisconnectedCaller.
        //          - merge #591 (https://github.com/CodexCoder21Organization/UrlProtocol/pull/591)
        //            adds a committed relay-registration gate with exact generation checks;
        //            testCommittedRelayRegistrationGateExcludesLifecycleClear and
        //            testCommittedRelayRegistrationGateRejectsClosedStream.
        //          - merge #555 (https://github.com/CodexCoder21Organization/UrlProtocol/pull/555)
        //            completes pending relay refreshes when a blocked listener stream closes;
        //            testRelayRefreshCompletesWhenListenerWaitsForHandlerPermit and
        //            testRelayRefreshCloseRaceCompletesAllPendingOperations.
        //          - merge #595 (https://github.com/CodexCoder21Organization/UrlProtocol/pull/595)
        //            makes aggregate-refusal generation verification deterministic;
        //            testAggregateRefusalCannotThrottleAfterGenerationDrains.
        //          - merge #596 (https://github.com/CodexCoder21Organization/UrlProtocol/pull/596)
        //            makes admission-constructor compatibility verification deterministic;
        //            testInboundAdmission0503ConstructorBinaryCompatibility.
        //          - merge #587 (https://github.com/CodexCoder21Organization/UrlProtocol/pull/587)
        //            prepares relay prefixes before FIFO materialization so setup cannot consume
        //            the FIFO observation window;
        //            testRelayCompletedMaterializationsPreserveProcessWideFifo.
        //          Current main also contains the bounded requested-ID retained-size measurement
        //          work from merge #597
        //          (https://github.com/CodexCoder21Organization/UrlProtocol/pull/597), covered by
        //          testPeerExchangeEstimateCoversMeasuredRequestedIdSet.
        // 0.0.566: main 0.0.551 plus structured remote exception details
        //          (https://github.com/CodexCoder21Organization/UrlProtocol/pull/612): the error for
        //          a request handler's own exception carries its class name and message in
        //          RpcError.data (RemoteApplicationFailure) over libp2p and TCP; hosting failures
        //          (ServiceInfrastructureFailure, incl. ServicePushException), cancellations and
        //          interruptions carry none; proxies forward a backend's failure through
        //          ReportsRemoteApplicationFailure; SandboxException gains nullable
        //          remoteExceptionClassName/remoteExceptionMessage. 0.0.529-0.0.533 were
        //          prereleases of earlier revisions, published from the unmerged feature branch.
        // 0.0.591: drain public service sends on close (extraction from
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/578) in
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/604: encode TCP
        //          requests before locking frame output to allow close reentry; let joined relay
        //          receive callbacks return from nested protocol close; prepare libp2p JSON before
        //          output ownership; stream TCP attachment segments without queued frame copies and
        //          retain bounded libp2p attachment writes; add terminal frame admission and weak
        //          identity controller registries; release acquisition waiters on terminal close
        //          and retire forwarded handles once; retire retry-evicted streams, keep relay
        //          startup inside terminal lifecycle, preserve forwarded-transfer cancellation and
        //          compatibility cleanup failures; report a child transport failure to senders
        //          parked on frame admission and leave no canceled-wait interrupt behind.
        // 0.0.551: publish main with the attachment reservation, close records and timed
        //          parse-memory admission from https://github.com/CodexCoder21Organization/UrlProtocol/pull/619,
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/623 and
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/620.
        // 0.0.562: a raw org.json result (as a forwarder relays it with sendRequestRaw) sends its
        //          base64 byte-array markers as binary attachments to peers that accept them, leaves a
        //          marker whose value is not valid base64 unchanged, and converts nested markers in
        //          one traversal (https://github.com/CodexCoder21Organization/UrlProtocol/pull/613;
        //          earlier builds of this branch were published as 0.0.545-0.0.547). An unpublished
        //          coordinate so builds of this branch cannot resolve a published jar.
        // 0.0.527: preserve the legacy transport constructor with unknown admission order.
        // 0.0.526: expose immutable transport admission order before asynchronous dispatch.
        // 0.0.568: mark locally constructed RPC transport failures with RpcTransportFailure
        //          (https://github.com/CodexCoder21Organization/UrlProtocol/pull/606). An unpublished
        //          coordinate so builds of this branch cannot resolve the published 0.0.551 jar;
        //          0.0.552-0.0.560 are left for other open branches.
        // 0.0.569 (first claimed as 0.0.554): retain the first protocol root-close promise so callback-reentrant and later
        //          close callers receive its terminal result; extracted from
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/578.
        //          Keep protocol close ownership in the outbox across all handler removal:
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/605.
        //          Preserve forwarded physical closes, independent admission retirement, and
        //          retained results after event-loop termination:
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/605.
        //          Join pending results and dispatch completion after transport-loop shutdown:
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/605.
        //          Defer a claimed close through a full event-loop queue, settle it on loop
        //          termination, keep fatal JVM errors primary, and keep reconciliation work off
        //          the clock thread: https://github.com/CodexCoder21Organization/UrlProtocol/pull/605.
        // 0.0.591: see the close-drain note above (https://github.com/CodexCoder21Organization/UrlProtocol/pull/604),
        //          rebased onto main 0.0.569; 0.0.570-0.0.590 are claimed by or left for other open branches.
        // 0.0.595: reset relay recovery history and backoff in the accepted ACK transaction.
        //          Reproduces the main-branch registration recovery failure from
        //          https://github.com/CodexCoder21Organization/UrlProtocol/actions/runs/36753001122.
        // 0.0.604: close the captured registration transport after listener startup/read failure,
        // preserve the exact refresh cause and cleanup details, then rethrow fatal listener Errors.
        // The handoff requested 0.0.603, which is already published by another branch.
        // 0.0.605: main 0.0.598 plus StreamClosedBeforeWriteException, which certifies that a write to
        //          an already-closed stream admitted zero bytes, and the relay close-observer cause
        //          ordering fix (https://github.com/CodexCoder21Organization/UrlProtocol/pull/622;
        //          an earlier build of this branch was published as 0.0.550). An unpublished
        //          coordinate so builds of this branch cannot resolve a published jar.
        // 0.0.1419: emit observed-address debug output and parse the selected address outside
        //          the snapshot lock; 0.0.1403 is reserved by the separate TCP request deadline fix.
        //          Based on main's 0.0.1418 coordinate.
        // 0.0.1422: use an unpublished coordinate for main after the completed-response fix.
        //          0.0.1420 and 0.0.1421 are already published.
        // 0.0.1423: keep pending RPC handlers active for read-idle expiry and preserve
        //          protocol close results when idle bookkeeping races event-loop shutdown.
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/721
        // 0.0.1424: published from an earlier head of
        //          https://github.com/CodexCoder21Organization/UrlProtocol/pull/723 (typed
        //          RpcFrameNotAdmittedException). Never republish it with different code.
        // 0.0.1425: RpcFrameNotAdmittedException messages name the decline reason and the
        //          remote peer. https://github.com/CodexCoder21Organization/UrlProtocol/pull/723
        // 0.0.1426 and 0.0.1427 were published from older mains by other sessions; 1426 lacks #725
        // and both lack #739, so neither includes the relay stall fix.
        // 0.0.1428 carries #725 (one-way gossip callbacks off the network event loop), #739
        // (incremental capacity eviction index), and #745 (bounded root-link diagnostic
        // substream samples).
        // 0.0.1429 adds #738's registry removal candidate API (getPeerRemovalCandidate and
        //          removePeer(candidate)); caller preparation runs outside registry guards, and
        //          accepted addresses remain bounded.
        // 0.0.1433 includes caller-selected RPC response readers from
        // https://github.com/CodexCoder21Organization/UrlProtocol/pull/637.
        // 0.0.1430 through 0.0.1432 are already published; do not overwrite them.
        // 0.0.1434 publishes the response encoding owner callback and field paths from
        // https://github.com/CodexCoder21Organization/UrlProtocol/pull/841.
        // 0.0.1435 and 0.0.1436 were published from other branches; do not overwrite them.
        // 0.0.1437 publishes main with request-dial Clock failure preservation from
        // https://github.com/CodexCoder21Organization/UrlProtocol/pull/938, plus #928 and #934.
        // 0.0.1438 passes request-owned Clocks into host stream acquisition, including
        // reused parents, and preserves asynchronous Clock failure before host fallback.
        // 0.0.1439 adds the actual listening port on service bindings.
        coordinates = "foundation.url:protocol:0.0.1439",
        src = File("src"),
        compileDependencies = dependencies
    )
}

/** Compiles the child process owned only by testRetiredOwnedStreamsDoNotAccumulateAcrossRetries. */
fun buildRetiredOwnedStreamsDoNotAccumulateAcrossRetriesTestSupport(
    src: File = File("tests/testRetiredOwnedStreamsDoNotAccumulateAcrossRetries"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies,
)

/** Compiles the child process owned only by testTcpBlockedSendersDoNotRetainFrameCopies. */
fun buildTcpBlockedSendersDoNotRetainFrameCopiesTestSupport(
    src: File = File("tests/testTcpBlockedSendersDoNotRetainFrameCopies"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies,
)

/** Compiles the child process owned only by testNativeQueuedFramesSurviveConstrainedHeap. */
fun buildNativeQueuedFramesSurviveConstrainedHeapTestSupport(
    src: File = File("tests/testNativeQueuedFramesSurviveConstrainedHeap"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies,
)

/** Compiles the child process owned only by testRelayClosingServiceRemovesWaitingMaterialization. */
fun buildRelayClosingServiceRemovesWaitingMaterializationTestSupport(
    src: File = File("tests/testRelayClosingServiceRemovesWaitingMaterialization"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies,
)

/** Compiles the child process owned only by testRelayCompletedMaterializationsPreserveProcessWideFifo. */
fun buildRelayCompletedMaterializationsPreserveProcessWideFifoTestSupport(
    src: File = File("tests/testRelayCompletedMaterializationsPreserveProcessWideFifo"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies,
)

/** Compiles the child process owned only by testRelayFailedTemporaryFileCloseRetainsPathAndStorageCharge. */
fun buildRelayFailedTemporaryFileCloseRetainsPathAndStorageChargeTestSupport(
    src: File = File("tests/testRelayFailedTemporaryFileCloseRetainsPathAndStorageCharge"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies + resolveDependencies2(
        MavenPrebuilt2("com.squareup.okio:okio-fakefilesystem-jvm:3.4.0"),
        MavenPrebuilt2("org.jetbrains.kotlin:kotlin-test:1.8.22"),
    ),
)

/** Compiles the child process owned only by testRelayMaterializationBudgetNeverExceedsHalfOfSmallHeap. */
fun buildRelayMaterializationBudgetNeverExceedsHalfOfSmallHeapTestSupport(
    src: File = File("tests/testRelayMaterializationBudgetNeverExceedsHalfOfSmallHeap"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies,
)

fun buildSkinnyJar(): File {
    return buildMaven().jar
}

/** Compiles the diagnostic-output child owned by the mid-negotiation churn stress. */
fun buildChurnOutputTestSupport(
    src: File = File("tests/stressTestServerSurvivesMidNegotiationChurnDropWithConstrainedHeap"),
): File = BuildJavaJar(src, listOf(buildMaven()) + dependencies)

// Kompile keeps one version per Maven coordinate. A POM-less copy lets the binary-compatibility
// test keep the published old protocol JAR for javac while loading these current classes at runtime.
fun buildCompatibilityTestRuntimeJar(): File {
    return BuildJar(Manifest(), listOf(buildSkinnyJar()))
}

/** Makes the published prior reader available as nested files, without adding its classes to test compilation. */
fun buildPriorReaderCompatibilityRuntimeDirectory(): File {
    val resolvedPriorReaderDependencies = resolveDependencies2(
        MavenPrebuilt2(
            "foundation.url:protocol:0.0.1421",
            resolveTransitiveDependencies = true,
        ),
    )
    val priorProtocolJar = resolvedPriorReaderDependencies.singleOrNull {
        it.jar.name.contains("protocol-0.0.1421")
    }?.jar ?: throw IllegalStateException(
        "Could not resolve the published prior protocol jar foundation.url:protocol:0.0.1421",
    )
    check(priorProtocolJar.name.contains("protocol-0.0.1421")) {
        "Resolved prior protocol jar has an unexpected filename: ${priorProtocolJar.name}"
    }

    val resourceJar = File("build/prior-reader-compatibility-resources.jar")
    val outputDirectory = resourceJar.parentFile
    check(outputDirectory.mkdirs() || outputDirectory.isDirectory) {
        "Could not prepare compatibility resource output directory: $outputDirectory"
    }
    check(!resourceJar.exists() || resourceJar.delete()) {
        "Could not replace compatibility resource artifact: $resourceJar"
    }

    val orderedJars = listOf(priorProtocolJar) + resolvedPriorReaderDependencies
        .map { it.jar }
        .filterNot { it == priorProtocolJar }
    val classpathEntries = orderedJars.mapIndexed { index, jar ->
        val copiedName = "${index.toString().padStart(3, '0')}-${jar.name}"
        "lib/$copiedName"
    }
    check(classpathEntries.first().substringAfter("lib/").contains("protocol-0.0.1421")) {
        "Prior protocol jar has an unexpected resource filename: ${classpathEntries.first()}"
    }

    val bridgeSource = File("tests/compatibility/PriorReaderJvmBridge.java")
    check(bridgeSource.isFile) {
        "Prior reader Java bridge source was not found at ${bridgeSource.absolutePath}"
    }

    java.util.jar.JarOutputStream(resourceJar.outputStream().buffered()).use { jarOutput ->
        fun addFileEntry(resourcePath: String, file: File) {
            jarOutput.putNextEntry(java.util.jar.JarEntry(resourcePath))
            file.inputStream().use { input -> input.copyTo(jarOutput) }
            jarOutput.closeEntry()
        }

        addFileEntry("PriorReaderJvmBridge.java", bridgeSource)
        jarOutput.putNextEntry(java.util.jar.JarEntry("prior-reader-classpath.txt"))
        jarOutput.write(
            classpathEntries.joinToString(
                separator = System.lineSeparator(),
                postfix = System.lineSeparator(),
            ).toByteArray(Charsets.UTF_8),
        )
        jarOutput.closeEntry()
        orderedJars.forEachIndexed { index, jar ->
            addFileEntry(classpathEntries[index], jar)
        }
    }
    return resourceJar
}

fun buildFatJar(): File {
    val manifest = Manifest("foundation.url.protocol.MainKt")
    return BuildJar(manifest, dependencies.map { it.jar } + buildSkinnyJar())
}

/** Compiles the child owned by testPeerExchangeEstimateCoversUncompressedTreeRequestedIdSet. */
fun buildUncompressedTreeRequestedIdSetTestSupport(
    src: File = File("tests/testPeerExchangeEstimateCoversUncompressedTreeRequestedIdSet"),
): File = BuildKotlinJar(
    src = src,
    classpath = listOf(buildMaven()) + dependencies + resolveDependencies2(
        MavenPrebuilt2("org.openjdk.jol:jol-core:0.17"),
        MavenPrebuilt2("org.jetbrains.kotlin:kotlin-test:1.8.22"),
    ),
)

/** Compiles the child owned by testForwardedReplyStreamsBeyondReceiverHeap. */
fun buildForwardedReplyStreamsBeyondReceiverHeapTestSupport(
    src: File = File("tests/testForwardedReplyStreamsBeyondReceiverHeap"),
): File = BuildKotlinJar(src = src, classpath = listOf(buildMaven()) + dependencies)

private fun legacyForwardingArchive(version: String): File {
    val artifact = resolveDependencies2(
        MavenPrebuilt2("foundation.url:protocol:$version", resolveTransitiveDependencies = false)
    ).single().jar
    val archive = File.createTempFile("forwarding-compatibility-$version-", ".jar")
    java.util.jar.JarOutputStream(archive.outputStream()).use { output ->
        output.putNextEntry(java.util.jar.JarEntry("protocol-$version.jar"))
        artifact.inputStream().use { it.copyTo(output) }
        output.closeEntry()
    }
    return archive
}

fun buildPreFramingForwardingCompatibilityArchive(): File = legacyForwardingArchive("0.0.298")

fun buildLegacyFramingForwardingCompatibilityArchive(): File = legacyForwardingArchive("0.0.608")
