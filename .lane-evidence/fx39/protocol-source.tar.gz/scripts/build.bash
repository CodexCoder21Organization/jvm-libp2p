#!/bin/bash
# Build script for modules using kompile-cli.
# Requires a build rule as the first argument.

if [ -z "$1" ]; then
  echo "Builds must specify a buildrule as an argument." >&2
  echo "Usage: $(basename "$0") <build-rule> [output-file]" >&2
  exit 1
fi

SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$SCRIPT_PATH/../jars"
JAR_PATH="$SCRIPT_PATH/../jars/KompileCli.jar"

if [ ! -f "$JAR_PATH" ] || ! grep -Fq "/kompile-cli/0.0.125/" "$JAR_PATH"; then
  # Download kompile-cli from kotlin.directory
  COURSIER_PATH="$SCRIPT_PATH/../jars/coursier"
  if [ ! -f "$COURSIER_PATH" ]; then
    echo "Downloading coursier..."
    # Pin because moving master broke CI on 2026-09-20 with coursier 2.1.25; bump the commit deliberately after verification.
    curl -fLo "$COURSIER_PATH" "https://github.com/coursier/launchers/raw/15f36c167c30be237105f923151adaf177e7ee61/coursier"
    chmod +x "$COURSIER_PATH"
  fi

  echo "Fetching kompile.cli:kompile-cli:0.0.125 from https://kotlin.directory/..."
  CLASSPATH=$("$COURSIER_PATH" fetch --repository https://kotlin.directory/ --repository central kompile.cli:kompile-cli:0.0.125 --classpath)

  cat > "$JAR_PATH" <<'LAUNCHER_EOF'
#!/bin/bash
LAUNCHER_EOF
  echo "CLASSPATH='$CLASSPATH'" >> "$JAR_PATH"
  cat >> "$JAR_PATH" <<'LAUNCHER_EOF'
exec java $JAVA_OPTS -cp "$CLASSPATH" kompile.cli.CliKt "$@"
LAUNCHER_EOF
  chmod +x "$JAR_PATH"
fi

JAVA_PROXY_OPTS=""
if [ -n "$HTTP_PROXY" ]; then
  proxy_host=$(echo "$HTTP_PROXY" | sed -E 's#^[^/]*//([^/:@]+).*#\1#')
  proxy_port=$(echo "$HTTP_PROXY" | sed -nE 's#.*:([0-9]+).*#\1#p')
  JAVA_PROXY_OPTS="-Dhttp.proxyHost=$proxy_host -Dhttps.proxyHost=$proxy_host"
  if [ -n "$proxy_port" ]; then
    JAVA_PROXY_OPTS="$JAVA_PROXY_OPTS -Dhttp.proxyPort=$proxy_port -Dhttps.proxyPort=$proxy_port"
  else
    JAVA_PROXY_OPTS="$JAVA_PROXY_OPTS -Dhttp.proxyPort=80 -Dhttps.proxyPort=443"
  fi
fi

REPO_PATH=$(cd "$SCRIPT_PATH/.." && pwd)
CACHE_PATH="$HOME/.aibuildcaches/$(echo "$REPO_PATH" | sed 's|/|_|g')"
JAVA_OPTS="$JAVA_PROXY_OPTS" "$JAR_PATH" --cache-location "$CACHE_PATH" -w "$SCRIPT_PATH/.." "$@"
