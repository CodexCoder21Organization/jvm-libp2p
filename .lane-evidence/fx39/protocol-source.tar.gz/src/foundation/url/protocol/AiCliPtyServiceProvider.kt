package foundation.url.protocol

import io.libp2p.core.Host
import org.json.JSONArray
import org.json.JSONObject
import java.io.EOFException
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Service provider that registers an AiCliPty implementation with the UrlResolver network.
 *
 * This class:
 * - Creates a libp2p host that serves the AiCliPty service
 * - Registers with bootstrap peers so clients can discover it
 * - Handles incoming RPC requests and delegates to the actual AiCliPty implementation
 * - Propagates AlgebraicEffects and Observable notifications to clients
 *
 * ## Usage
 * ```kotlin
 * val provider = AiCliPtyServiceProvider(
 *     ptyFactory = { MyAiCliPtyImpl() },
 *     serviceUrl = "url://vpn.macvm-ai.aiptyapi/",
 *     listenAddresses = listOf("/ip4/0.0.0.0/tcp/4001")
 * )
 * provider.start()
 * // ... service is now available
 * provider.stop()
 * ```
 *
 * @property ptyFactory Factory function to create new AiCliPty instances
 * @property serviceUrl The URL this service will be available at
 * @property listenAddresses Multiaddresses to listen on
 * @property bootstrapPeers Optional bootstrap peers to register with
 */
class AiCliPtyServiceProvider(
    private val ptyFactory: () -> AiCliPtyAdapter,
    private val serviceUrl: String = "url://vpn.macvm-ai.aiptyapi/",
    private val listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
    private val bootstrapPeers: List<BootstrapPeer> = emptyList()
) : AutoCloseable {

    private var host: Host? = null
    private val running = AtomicBoolean(false)
    private val activePtys = ConcurrentHashMap<String, AiCliPtyAdapter>()
    private val subscriptions = ConcurrentHashMap<String, MutableSet<InvalidationSubscriber>>()

    private val serviceIdentifier: String = parseServiceIdentifier(serviceUrl)
        ?: throw IllegalArgumentException("Invalid service URL: $serviceUrl")

    /**
     * The peer ID of this service provider (available after start).
     */
    val peerId: String
        get() = host?.peerId?.toBase58() ?: throw IllegalStateException("Service not started")

    /**
     * The multiaddresses this service is listening on (available after start).
     */
    val listenMultiaddresses: List<String>
        get() = host?.listenAddresses()?.map { it.toString() } ?: emptyList()

    /**
     * Starts the service provider.
     */
    fun start() {
        if (running.getAndSet(true)) return

        // Create request handler
        val requestHandler = AiCliPtyRequestHandler()

        // Create and start the host
        host = Libp2pHostFactory.createServerHost(
            listenAddresses = listenAddresses,
            requestHandler = requestHandler
        )
        host!!.start().get(30, TimeUnit.SECONDS)

        // Register with bootstrap peers
        registerWithBootstrapPeers()
    }

    /**
     * Stops the service provider.
     */
    fun stop() {
        if (!running.getAndSet(false)) return

        // Close all active PTYs
        activePtys.values.forEach { pty ->
            try {
                pty.close()
            } catch (e: Exception) {
                // Ignore close errors
            }
        }
        activePtys.clear()
        subscriptions.clear()

        // Stop the host
        host?.let { h ->
            try {
                h.stop().get(5, TimeUnit.SECONDS)
            } catch (e: Exception) {
                // Ignore stop errors
            }
        }
        host = null
    }

    override fun close() {
        stop()
    }

    private fun registerWithBootstrapPeers() {
        val localPeer = Libp2pPeer.local(host!!, listOf(serviceIdentifier))

        for (peer in bootstrapPeers) {
            try {
                // In a full implementation, we would use a peer exchange protocol
                // to advertise our service to the bootstrap peer
                // For now, this is a placeholder
            } catch (e: Exception) {
                // Ignore registration errors
            }
        }
    }

    private fun parseServiceIdentifier(url: String): String? {
        if (!url.startsWith("url://")) return null
        val withoutScheme = url.removePrefix("url://")
        return withoutScheme.split("/").firstOrNull()?.takeIf { it.isNotBlank() }
    }

    /**
     * Request handler that processes RPC requests for AiCliPty methods.
     */
    private inner class AiCliPtyRequestHandler : RpcRequestHandler {
        override suspend fun handleRequest(
            request: Libp2pRpcProtocol.RpcRequest,
            effectHandler: EffectPropagator
        ): Libp2pRpcProtocol.RpcResponse {
            return try {
                val result = processRequest(request, effectHandler)
                Libp2pRpcProtocol.RpcResponse.success(request.id, result)
            } catch (e: Exception) {
                Libp2pRpcProtocol.RpcResponse.error(
                    request.id,
                    Libp2pRpcProtocol.ERROR_INTERNAL,
                    e.message ?: "Unknown error"
                )
            }
        }

        private suspend fun processRequest(
            request: Libp2pRpcProtocol.RpcRequest,
            effectHandler: EffectPropagator
        ): Any? {
            // Get or create PTY for this session
            val sessionId = request.metadata["sessionId"] ?: "default"
            val pty = activePtys.computeIfAbsent(sessionId) {
                val newPty = ptyFactory()
                // Set up invalidation handler
                newPty.setOnInvalidation {
                    broadcastInvalidation(sessionId)
                }
                newPty
            }

            return when (request.method) {
                "start" -> {
                    val columns = (request.params["columns"] as? Number)?.toInt() ?: 120
                    val rows = (request.params["rows"] as? Number)?.toInt() ?: 64
                    pty.start(columns, rows)
                    null
                }
                "isAlive" -> pty.isAlive()
                "renderScreen" -> {
                    val columns = (request.params["columns"] as? Number)?.toInt() ?: 120
                    val rows = (request.params["rows"] as? Number)?.toInt() ?: 64
                    pty.renderScreen(columns, rows)
                }
                "renderScreenWithCursor" -> {
                    val columns = (request.params["columns"] as? Number)?.toInt() ?: 120
                    val rows = (request.params["rows"] as? Number)?.toInt() ?: 64
                    val screen = pty.renderScreenWithCursor(columns, rows)
                    JSONObject().apply {
                        put("text", screen.text)
                        put("cursorX", screen.cursorX)
                        put("cursorY", screen.cursorY)
                        put("cursorVisible", screen.cursorVisible)
                    }
                }
                "resize" -> {
                    val columns = (request.params["columns"] as? Number)?.toInt() ?: 120
                    val rows = (request.params["rows"] as? Number)?.toInt() ?: 64
                    pty.resize(columns, rows)
                    null
                }
                "sendString" -> {
                    val s = request.params["s"] as? String ?: ""
                    pty.sendString(s)
                    null
                }
                "sendBytes" -> {
                    val base64 = request.params["bytesBase64"] as? String ?: ""
                    val bytes = Base64.getDecoder().decode(base64)
                    pty.sendBytes(bytes)
                    null
                }
                "sendEnter" -> { pty.sendEnter(); null }
                "sendBackspace" -> { pty.sendBackspace(); null }
                "sendTab" -> { pty.sendTab(); null }
                "sendCtrl" -> {
                    val char = (request.params["char"] as? String)?.firstOrNull() ?: 'c'
                    pty.sendCtrl(char)
                    null
                }
                "sendArrowUp" -> { pty.sendArrowUp(); null }
                "sendArrowDown" -> { pty.sendArrowDown(); null }
                "sendArrowRight" -> { pty.sendArrowRight(); null }
                "sendArrowLeft" -> { pty.sendArrowLeft(); null }
                "sendHome" -> { pty.sendHome(); null }
                "sendEnd" -> { pty.sendEnd(); null }
                "interrupt" -> { pty.interrupt(); null }
                "captureScreenFor" -> {
                    val durationMs = (request.params["durationMs"] as? Number)?.toLong() ?: 1000
                    val columns = (request.params["columns"] as? Number)?.toInt() ?: 120
                    val rows = (request.params["rows"] as? Number)?.toInt() ?: 64
                    val mirrorRaw = request.params["mirrorRaw"] as? Boolean ?: false
                    pty.captureScreenFor(durationMs, columns, rows, mirrorRaw)
                }
                "getStatus" -> pty.getStatus().name
                "sessionLogRecords" -> JSONArray(pty.sessionLogRecords())
                "getSessionId" -> pty.getSessionId()
                "commandPreview" -> pty.commandPreview()
                "persistSessionId" -> {
                    val sid = request.params["sessionId"] as? String ?: ""
                    pty.persistSessionId(sid)
                }
                "getStandaloneResponse" -> {
                    val prompt = request.params["prompt"] as? String ?: ""
                    pty.getStandaloneResponse(prompt)
                }
                "getIdleDetectionDebugInfo" -> JSONObject(pty.getIdleDetectionDebugInfo())
                "quotaStatus" -> pty.quotaStatus().toJson()
                "close" -> {
                    pty.close()
                    activePtys.remove(sessionId)
                    subscriptions.remove(sessionId)
                    null
                }
                else -> throw IllegalArgumentException("Unknown method: ${request.method}")
            }
        }
    }

    private fun broadcastInvalidation(sessionId: String) {
        val timestamp = System.currentTimeMillis()
        subscriptions[sessionId]?.forEach { subscriber ->
            try {
                subscriber.onInvalidation(timestamp)
            } catch (e: Exception) {
                // Ignore subscriber errors
            }
        }
    }

    /**
     * Subscriber for invalidation notifications.
     */
    interface InvalidationSubscriber {
        fun onInvalidation(timestamp: Long)
    }
}

/**
 * Adapter interface that matches the AiCliPty interface.
 * This avoids a direct dependency on the AiCliPty module.
 */
interface AiCliPtyAdapter : AutoCloseable {
    fun start(columns: Int = 120, rows: Int = 64)
    fun isAlive(): Boolean
    fun renderScreen(columns: Int, rows: Int): String
    fun renderScreenWithCursor(columns: Int, rows: Int): RenderedScreenData
    fun resize(columns: Int, rows: Int)
    fun sendString(s: String)
    fun sendBytes(bytes: ByteArray)
    fun sendEnter()
    fun sendBackspace()
    fun sendTab()
    fun sendCtrl(char: Char)
    fun sendArrowUp()
    fun sendArrowDown()
    fun sendArrowRight()
    fun sendArrowLeft()
    fun sendHome()
    fun sendEnd()
    fun interrupt()
    fun captureScreenFor(durationMs: Long, columns: Int, rows: Int, mirrorRaw: Boolean): String
    fun getStatus(): ExecutionStatus
    fun setOnInvalidation(handler: (() -> Unit)?)
    fun sessionLogRecords(): List<Any>
    fun getSessionId(): String?
    fun commandPreview(): String
    fun persistSessionId(sessionId: String): Boolean
    suspend fun getStandaloneResponse(prompt: String): String
    fun getIdleDetectionDebugInfo(): Map<String, Any>
    fun quotaStatus(): RemoteAiCliQuotaStatus = RemoteAiCliQuotaStatus(
        supported = false,
        metrics = emptyList(),
        fetchedAtEpochMillis = 0L,
        rawText = null,
        errorMessage = "Quota reporting is not implemented by this AiCliPtyAdapter",
    )
}

/**
 * Data class for rendered screen with cursor information.
 */
data class RenderedScreenData(
    val text: String,
    val cursorX: Int,
    val cursorY: Int,
    val cursorVisible: Boolean
)

/**
 * Execution status enum.
 */
enum class ExecutionStatus { BUSY, IDLE }

private fun RemoteAiCliQuotaStatus.toJson(): JSONObject {
    return JSONObject().apply {
        put("supported", supported)
        put("fetchedAtEpochMillis", fetchedAtEpochMillis)
        putNullable("rawText", rawText)
        putNullable("errorMessage", errorMessage)
        put("metrics", JSONArray(metrics.map { it.toJson() }))
    }
}

private fun RemoteAiCliQuotaMetric.toJson(): JSONObject {
    return JSONObject().apply {
        put("id", id)
        put("displayName", displayName)
        put("window", window.name)
        putNullable("model", model)
        put("unit", unit)
        putNullable("totalQuantity", totalQuantity)
        putNullable("usedQuantity", usedQuantity)
        putNullable("remainingQuantity", remainingQuantity)
        putNullable("resetsAtEpochMillis", resetsAtEpochMillis)
        putNullable("resetsDescription", resetsDescription)
    }
}

private fun JSONObject.putNullable(key: String, value: Any?) {
    put(key, value ?: JSONObject.NULL)
}
