package foundation.url.protocol

import java.util.concurrent.CompletableFuture

private class AnnouncementPeerMutation(
    val peerId: String,
    val connectionClosed: CompletableFuture<*>,
)

private val announcementPeerMutation = ThreadLocal<AnnouncementPeerMutation>()

/** Carries the authenticated connection through synchronous caller callbacks, without a lock. */
internal fun withAnnouncementPeerMutation(
    peerId: String,
    connectionClosed: CompletableFuture<*>,
    action: () -> Unit,
) {
    val previous = announcementPeerMutation.get()
    announcementPeerMutation.set(AnnouncementPeerMutation(peerId, connectionClosed))
    try {
        action()
    } finally {
        if (previous == null) announcementPeerMutation.remove()
        else announcementPeerMutation.set(previous)
    }
}

/** Check while holding the membership or observation owner that also serializes removal. */
internal fun isCurrentAnnouncementPeerMutation(peerId: String): Boolean {
    val context = announcementPeerMutation.get() ?: return true
    return context.peerId != peerId || !context.connectionClosed.isDone
}

internal fun hasCurrentAnnouncementPeerMutation(peerId: String): Boolean =
    announcementPeerMutation.get()?.peerId == peerId
