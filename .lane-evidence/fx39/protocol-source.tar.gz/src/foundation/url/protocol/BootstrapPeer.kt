package foundation.url.protocol

import org.json.JSONArray
import org.json.JSONObject

/**
 * Represents a peer that can be used for bootstrapping the peer-to-peer network.
 *
 * Bootstrap peers serve multiple purposes:
 * - Discovering additional peers in the network
 * - Introduction and rendezvous forwarding for NAT traversal
 * - Advertising which url:// services they provide
 * - Routing traffic to the correct service
 *
 * This interface is designed to be compatible with libp2p concepts while
 * remaining implementation-agnostic. Implementations may use libp2p, custom
 * protocols, or other P2P libraries.
 *
 * Implementations should be serializable to allow persistence to disk.
 */
interface BootstrapPeer {

    /**
     * Unique identifier for this peer.
     * This should be stable across sessions and network changes.
     *
     * For libp2p-based implementations, this is typically the base58-encoded
     * peer ID derived from the peer's public key.
     */
    val peerId: String

    /**
     * Multiaddresses where this peer can be reached.
     *
     * PeerRegistry owns an immutable snapshot at acceptance. Submit a new descriptor through
     * addPeer to change retained routes; changing an earlier caller-owned list does not update them.
     *
     * These follow the libp2p multiaddress format, e.g.:
     * - `/ip4/192.168.1.1/tcp/4001/p2p/QmPeerID`
     * - `/ip6/::1/tcp/4001/p2p/QmPeerID`
     * - `/dns4/bootstrap.example.com/tcp/4001/p2p/QmPeerID`
     *
     * @see <a href="https://docs.libp2p.io/concepts/addressing/">libp2p Addressing</a>
     */
    val multiaddresses: List<String>

    /**
     * The url:// service identifiers that this peer advertises.
     * For example: ["com.companyname.contactdb", "com.example.filesystem"]
     *
     * These are used for content-based routing to find peers that
     * provide specific services.
     */
    val advertisedServices: List<String>

    /**
     * Timestamp of when this peer was last seen online (epoch milliseconds).
     * Used to prioritize recently-active peers during bootstrap.
     */
    val lastSeenTimestamp: Long

    /**
     * Attempts to discover additional peers from this bootstrap peer.
     *
     * Uses peer exchange protocols (PX) or DHT queries to discover more peers.
     *
     * @param maxPeers Maximum number of peers to request.
     * @return List of discovered peers, may be empty if peer is offline or unreachable.
     */
    fun discoverPeers(maxPeers: Int = 10): List<BootstrapPeer>

    /**
     * Requests introduction/rendezvous forwarding through this peer.
     * Used for NAT traversal when direct connection is not possible.
     *
     * In libp2p terms, this uses Circuit Relay v2 for hole punching.
     *
     * @param targetPeerId The peer ID we want to be introduced to.
     * @return Connection information for the rendezvous, or null if unavailable.
     */
    fun requestIntroduction(targetPeerId: String): RendezvousInfo?

    /**
     * Checks if this peer can route requests for the given service.
     *
     * @param serviceIdentifier The url:// service identifier to check.
     * @return True if this peer can handle or route requests for this service.
     */
    fun canRoute(serviceIdentifier: String): Boolean

    /**
     * Pings this peer to check if it's still online.
     * Updates the lastSeenTimestamp if successful.
     *
     * Uses libp2p's Ping protocol for liveness checking.
     *
     * @param timeoutMs Maximum time to wait for response in milliseconds.
     * @return True if the peer responded, false otherwise.
     */
    fun ping(timeoutMs: Long = 5000): Boolean

    /**
     * Serializes this peer to a JSONObject for persistence.
     *
     * @return JSONObject representation of this peer.
     */
    fun toJson(): JSONObject
}

/**
 * Information for establishing a rendezvous connection through an intermediary peer.
 * Used for NAT traversal when direct peer-to-peer connection is not possible.
 *
 * This maps to libp2p's Circuit Relay v2 concepts.
 *
 * @see <a href="https://docs.libp2p.io/concepts/nat/circuit-relay/">Circuit Relay</a>
 */
data class RendezvousInfo(
    /**
     * The peer ID of the relay node providing the rendezvous service.
     */
    val relayPeerId: String,

    /**
     * The multiaddress of the relay.
     */
    val relayMultiaddress: String,

    /**
     * Session token/voucher for this specific rendezvous request.
     */
    val reservationVoucher: String,

    /**
     * Expiration timestamp for this rendezvous offer (epoch milliseconds).
     */
    val expiresAt: Long,

    /**
     * The full relay circuit address for connecting to the target peer.
     * Format: /p2p/<relay-peer-id>/p2p-circuit/p2p/<target-peer-id>
     */
    val circuitAddress: String
) {
    /**
     * Checks if this rendezvous info is still valid.
     */
    fun isValid(currentTimeMs: Long = System.currentTimeMillis()): Boolean = currentTimeMs < expiresAt

    /**
     * Serializes this rendezvous info to a JSONObject.
     */
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("relayPeerId", relayPeerId)
            put("relayMultiaddress", relayMultiaddress)
            put("reservationVoucher", reservationVoucher)
            put("expiresAt", expiresAt)
            put("circuitAddress", circuitAddress)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): RendezvousInfo {
            return RendezvousInfo(
                relayPeerId = json.getString("relayPeerId"),
                relayMultiaddress = json.getString("relayMultiaddress"),
                reservationVoucher = json.optString("reservationVoucher", ""),
                expiresAt = json.optLong("expiresAt", 0L),
                circuitAddress = json.optString("circuitAddress", "")
            )
        }
    }
}

/**
 * Well-known public STUN servers that can be used for NAT traversal.
 * These are Google's free public STUN servers and can be used with WebRTC
 * or other STUN-based NAT traversal mechanisms.
 */
object PublicStunServers {
    val GOOGLE_STUN_SERVERS = listOf(
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
        "stun:stun2.l.google.com:19302",
        "stun:stun3.l.google.com:19302",
        "stun:stun4.l.google.com:19302"
    )
}
