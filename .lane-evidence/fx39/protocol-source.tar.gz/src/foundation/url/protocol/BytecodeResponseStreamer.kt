package foundation.url.protocol

import foundation.url.protocol.sandbox.BytecodeProtocol
import java.io.IOException
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.Base64
import org.json.JSONObject

/**
 * Marker result carrier for the service-provider *optimized* bytecode serve path.
 *
 * When [ServiceRoutingHandler.handleBytecodeRequest] serves a service's OWN
 * implementation bytecode (the `supportsSandboxedExecution()` branch), it returns
 * an [Libp2pRpcProtocol.RpcResponse] whose `result` is one of these markers
 * instead of a fully-materialized JSON `String`. Attachment-capable stream-write
 * sites convert the marker with [toBinaryRpcResponse] and write the raw JAR as an
 * out-of-band attachment. A negotiated legacy libp2p stream uses
 * [writeStreamingBytecodeResponse] to retain its base64 wire format. Both paths
 * avoid the eager multi-copy JSON materialization described below.
 *
 * # Why this exists
 *
 * The previous serve path materialized the payload ~5× simultaneously for a
 * single in-flight serve:
 *  1. `BytecodeProtocol.createResponse(jarBytes)` base64-encodes the whole JAR
 *     into a `String` (~4/3 × JAR), then
 *  2. builds the inner bytecode-response JSON `String`, then
 *  3. wraps it as `RpcResponse.success(id, payload).toJson()` (outer JSONObject
 *     embedding the inner String), then
 *  4. `json.toString()` re-serializes the whole envelope to a fresh `String`,
 *     then
 *  5. `.toByteArray(UTF_8)` allocates the final wire `byte[]`.
 *
 * For a 1.7–2.4 MB production JAR that is ~15–25 MB of transient heap *per
 * serve*. Under concurrent load on a `-Xmx128m` ContainerNursery-launched
 * service JVM (production-health-server.jar, docker-run-server.jar) this OOMs
 * or GC-thrashes so the serve cannot complete inside the client's 30 s bytecode
 * request bound, and the client reads 0 bytes / times out.
 *
 * Legacy base64 streaming keeps peak heap at roughly
 * `jarBytes.size + STREAM_CHUNK_RAW_BYTES`; attachment writers keep the JAR out
 * of JSON and write its existing byte array directly.
 *
 * The wire format produced by [writeStreamingBytecodeResponse] is byte-for-byte
 * parseable by the existing client path: the outer envelope is
 * `{"type":"response","id":"<id>","result":"<inner>"}` (parsed by
 * [Libp2pRpcProtocol.RpcResponse.fromJson]) and the inner `result` string is
 * `{"success":true,"jarBytes":"<base64>","implClassName":"<name>"}` (parsed by
 * [foundation.url.protocol.sandbox.BytecodeProtocol.parseResponse]). Only the
 * JSON key *ordering* differs from `org.json`'s HashMap ordering, which is
 * irrelevant to any JSON parser.
 */
class StreamingBytecodeResponse(
    val requestId: String,
    val jarBytes: ByteArray,
    val implClassName: String,
    /**
     * Additive response-metadata channel, mirroring
     * [Libp2pRpcProtocol.RpcResponse.metadata]. Defaults to empty. The hand-built
     * streaming envelope emits a `"metadata"` field on the OUTER response object only
     * when this map is non-empty — the same omit-when-empty convention as
     * [Libp2pRpcProtocol.RpcResponse.toJson] — so the common (no-metadata) serve stays
     * byte-identical to the pre-metadata wire form, yet a future metadata-bearing
     * streaming serve can never be silently dropped by this hand-rolled envelope.
     */
    val metadata: Map<String, String> = emptyMap()
)

/**
 * Converts the transport-neutral optimized bytecode marker to the attachment-capable RPC form.
 * Keeping this conversion shared prevents the raw-TCP and negotiated libp2p writers from drifting
 * on bytecode fields or response metadata.
 */
internal fun StreamingBytecodeResponse.toBinaryRpcResponse(): Libp2pRpcProtocol.RpcResponse =
    Libp2pRpcProtocol.RpcResponse.success(
        requestId,
        BytecodeProtocol.createBinaryResponse(jarBytes, implClassName)
    ).copy(metadata = metadata)

/**
 * Raw JAR bytes consumed per base64 encode step. 48 KB raw → 64 KB base64,
 * keeping the per-serve encode buffer small and constant regardless of JAR size.
 * Chosen as a multiple of 3 so each chunk base64-encodes without padding except
 * the final chunk (correct streaming base64 requires 3-byte alignment per chunk).
 */
const val STREAM_CHUNK_RAW_BYTES: Int = 48 * 1024

/**
 * Fixed prefix of the inner response emitted by [writeStreamingBytecodeResponse].
 *
 * The streaming writer owns this byte order so a proxy can distinguish its already-final
 * response by examining only this small header. Other response producers may use arbitrary JSON
 * key order and therefore continue through the normal parser for backward compatibility.
 */
internal const val STREAMED_BYTECODE_RESPONSE_PREFIX = "{\"success\":true,\"jarBytes\":\""

/**
 * Computes the exact base64-encoded length (with padding) for [n] raw bytes,
 * matching `java.util.Base64.getEncoder()` output. This is deterministic:
 * `4 * ceil(n / 3)`.
 */
fun base64EncodedLength(n: Int): Long {
    return 4L * ((n.toLong() + 2L) / 3L)
}

/**
 * JSON-escapes [s] for embedding as a JSON string *value*, returning the escaped
 * UTF-8 bytes. Used for the implementation class name and for the structural
 * skeleton characters of the inner bytecode-response JSON when it is embedded as
 * the outer envelope's `result` string value.
 *
 * Handles the full set of characters that JSON requires escaping: `"`, `\`, and
 * the C0 control range, matching `org.json.JSONObject.quote` semantics (minus the
 * surrounding quotes, which callers add where needed).
 */
internal fun jsonEscapeToBytes(s: String): ByteArray {
    val sb = StringBuilder(s.length + 16)
    for (c in s) {
        when (c) {
            '"' -> sb.append("\\\"")
            '\\' -> sb.append("\\\\")
            '\n' -> sb.append("\\n")
            '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t")
            '\b' -> sb.append("\\b")
            else -> {
                if (c.code < 0x20) {
                    // Remaining C0 controls (including form-feed 0x0C) -> \\uXXXX.
                    sb.append("\\u")
                    val hex = Integer.toHexString(c.code)
                    for (k in hex.length until 4) sb.append('0')
                    sb.append(hex)
                } else {
                    sb.append(c)
                }
            }
        }
    }
    return sb.toString().toByteArray(StandardCharsets.UTF_8)
}

/**
 * Builds the two fixed skeleton byte segments that surround the streamed base64
 * in the wire body, already escaped for the outer `result` string value.
 *
 * The full body is:
 * ```
 * {"type":"response","id":"<id>","result":"<innerEscaped>"}
 * ```
 * (with an additional `,"metadata":{...}` inserted before the closing brace when
 * [metadata] is non-empty, mirroring [Libp2pRpcProtocol.RpcResponse.toJson]'s
 * omit-when-empty convention), where `<innerEscaped>` is the JSON-escaped form of:
 * ```
 * {"success":true,"jarBytes":"<base64>","implClassName":"<name>"}
 * ```
 *
 * Because base64 contains no characters that JSON-escapes, the base64 appears
 * verbatim in the body. The structural `"` characters of the inner JSON are
 * escaped to `\"` here. Returns (prefix, suffix) such that
 * `prefix + <base64> + suffix` is the exact body.
 */
internal fun buildBytecodeBodySkeleton(
    requestId: String,
    implClassName: String,
    metadata: Map<String, String> = emptyMap()
): Pair<ByteArray, ByteArray> {
    // Inner bytecode-response JSON, split around the streamed base64 value.
    // Inner (unescaped):  {"success":true,"jarBytes":"<base64>","implClassName":"<name>"}
    // When embedded as the OUTER envelope's `result` string value, every inner
    // `"` is escaped to `\"`. Base64 contains no escapable characters, so it
    // appears verbatim between the escaped prefix and suffix.
    val innerPrefixUnescaped = STREAMED_BYTECODE_RESPONSE_PREFIX
    val innerSuffixUnescaped = "\",\"implClassName\":\"$implClassName\"}"

    val escapedInnerPrefix = jsonEscapeToBytes(innerPrefixUnescaped)
    val escapedInnerSuffix = jsonEscapeToBytes(innerSuffixUnescaped)

    // The outer envelope's own quotes are real structural quotes of the OUTER
    // object — they are NOT escaped. Only the embedded inner content (the result
    // string value) is escaped above.
    val outerHeadBytes = buildOuterHead(requestId)
    // Close the outer `result` string, then (mirroring RpcResponse.toJson's
    // omit-when-empty convention for the additive metadata channel) append a
    // `"metadata":{...}` field to the OUTER envelope only when the map is non-empty,
    // before the outer object's closing brace. When empty, the tail is byte-identical
    // to the pre-metadata form (`"}`), so the common serve path is unchanged. This
    // guarantees a future metadata-bearing StreamingBytecodeResponse cannot be
    // silently dropped by this hand-built envelope. JSONObject(metadata).toString()
    // JSON-escapes the metadata keys/values.
    val outerTailBytes = if (metadata.isEmpty()) {
        "\"}".toByteArray(StandardCharsets.UTF_8)
    } else {
        ("\",\"metadata\":" + JSONObject(metadata).toString() + "}")
            .toByteArray(StandardCharsets.UTF_8)
    }

    val prefix = outerHeadBytes + escapedInnerPrefix
    val suffix = escapedInnerSuffix + outerTailBytes
    return prefix to suffix
}

/**
 * Builds the outer envelope head `{"type":"response","id":"<id>","result":"`
 * with the id JSON-escaped as a structural string value.
 */
private fun buildOuterHead(requestId: String): ByteArray {
    val sb = StringBuilder()
    sb.append("{\"type\":\"response\",\"id\":\"")
    sb.append(String(jsonEscapeToBytes(requestId), StandardCharsets.UTF_8))
    sb.append("\",\"result\":\"")
    return sb.toString().toByteArray(StandardCharsets.UTF_8)
}

/**
 * Computes the exact body length (in bytes) of the streamed wire message for the
 * given response, WITHOUT allocating the body. Used to write the 4-byte
 * length prefix up front so the body can then be streamed in bounded chunks.
 */
internal fun streamingBytecodeBodyLength(response: StreamingBytecodeResponse): Long {
    val (prefix, suffix) = buildBytecodeBodySkeleton(response.requestId, response.implClassName, response.metadata)
    return prefix.size.toLong() + base64EncodedLength(response.jarBytes.size) + suffix.size.toLong()
}

/**
 * Streams a [StreamingBytecodeResponse] to [output] as a single length-prefixed
 * RPC message, byte-compatible with [Libp2pRpcProtocol.readMessage] +
 * [Libp2pRpcProtocol.RpcResponse.fromJson] +
 * [foundation.url.protocol.sandbox.BytecodeProtocol.parseResponse].
 *
 * Peak heap during the write is approximately `jarBytes.size` (the caller already
 * holds it) plus a constant-size base64 encode buffer — it never materializes the
 * base64 String, the inner JSON String, the outer JSON String, or a re-encoded
 * `byte[]` of the whole frame.
 *
 * The total frame size (4 + body) is validated against
 * [Libp2pRpcProtocol.MAX_JSON_STRING_LENGTH] / the 10 MB framing cap so an
 * oversized JAR fails fast with a descriptive [java.io.IOException] rather than
 * producing a frame the peer would reject mid-stream.
 */
fun writeStreamingBytecodeResponse(output: OutputStream, response: StreamingBytecodeResponse) {
    val (prefix, suffix) = buildBytecodeBodySkeleton(response.requestId, response.implClassName, response.metadata)
    val base64Len = base64EncodedLength(response.jarBytes.size)
    val bodyLen = prefix.size.toLong() + base64Len + suffix.size.toLong()

    // The base64 jarBytes string occupies `base64Len` bytes within the frame.
    // Guard against exceeding the peer's per-string cap so we fail fast on the
    // sender rather than have the receiver reject the frame after transfer.
    if (base64Len > Libp2pRpcProtocol.MAX_JSON_STRING_LENGTH.toLong()) {
        throw IOException(
            "Bytecode JAR for implementation '${response.implClassName}' is too large to serve: " +
                "base64-encoded length $base64Len bytes exceeds " +
                "MAX_JSON_STRING_LENGTH=${Libp2pRpcProtocol.MAX_JSON_STRING_LENGTH} bytes " +
                "(raw JAR is ${response.jarBytes.size} bytes)"
        )
    }
    if (bodyLen <= 0L || bodyLen > MAX_RPC_FRAME_BODY_BYTES) {
        throw IOException(
            "Streaming bytecode response body length $bodyLen bytes for implementation " +
                "'${response.implClassName}' is outside the valid framing range " +
                "(1..$MAX_RPC_FRAME_BODY_BYTES). Raw JAR is ${response.jarBytes.size} bytes."
        )
    }

    // 4-byte big-endian length prefix.
    val lenPrefix = ByteArray(4)
    val bodyLenInt = bodyLen.toInt()
    lenPrefix[0] = (bodyLenInt ushr 24).toByte()
    lenPrefix[1] = (bodyLenInt ushr 16).toByte()
    lenPrefix[2] = (bodyLenInt ushr 8).toByte()
    lenPrefix[3] = bodyLenInt.toByte()
    output.write(lenPrefix)

    // Body: prefix → streamed base64 of jarBytes → suffix.
    output.write(prefix)
    streamBase64(output, response.jarBytes)
    output.write(suffix)
    output.flush()
}

/**
 * Encodes [data] to base64 and writes it to [output] in bounded chunks, never
 * allocating the full base64 String. Each chunk is a multiple of 3 raw bytes
 * (except the last) so streaming concatenation matches a single
 * `Base64.getEncoder().encodeToString(data)` call exactly.
 */
private fun streamBase64(output: OutputStream, data: ByteArray) {
    val encoder = Base64.getEncoder()
    var offset = 0
    val n = data.size
    while (offset < n) {
        val remaining = n - offset
        val chunk = if (remaining <= STREAM_CHUNK_RAW_BYTES) remaining else STREAM_CHUNK_RAW_BYTES
        val slice = if (offset == 0 && chunk == n) {
            data
        } else {
            data.copyOfRange(offset, offset + chunk)
        }
        // For non-final chunks `chunk` is a multiple of 3, so encode() emits no
        // padding and the streamed result is identical to encoding the whole
        // array at once. The final chunk carries any padding.
        val encoded = encoder.encode(slice)
        output.write(encoded)
        offset += chunk
    }
}

/**
 * Maximum RPC frame body size, mirroring the cap enforced by
 * [Libp2pRpcProtocol.readMessage] (`length > 10_000_000`).
 */
const val MAX_RPC_FRAME_BODY_BYTES: Long = 10_000_000L
