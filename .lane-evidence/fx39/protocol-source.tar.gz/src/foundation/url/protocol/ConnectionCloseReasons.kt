package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.logging.MessageSeverity
import io.libp2p.core.Connection
import io.libp2p.core.ConnectionHandler
import io.libp2p.transport.implementation.ConnectionOverNetty
import io.libp2p.transport.implementation.P2PChannelOverNetty
import io.netty.channel.Channel
import io.netty.channel.ChannelDuplexHandler
import io.netty.channel.ChannelFutureListener
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelPromise
import java.net.SocketAddress
import kotlinx.algebraiceffects.EffectHandlerRepository
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.`$effectHandlerRepository`
import kotlinx.algebraiceffects.toss

/**
 * What ended a root connection, as observed by the host that records the close.
 *
 * The classification is made from events this host saw on the connection's own Netty channel
 * before the channel closed. It never depends on what the peer later reports.
 */
enum class ConnectionCloseInitiator {
    /** Code in this process asked the channel to close (for example `Connection.close()`). */
    LOCAL_CLOSE,

    /** This process shut down the event loop that owned the channel, which closes every channel on it. */
    LOCAL_EVENT_LOOP_SHUTDOWN,

    /**
     * A read or write on the channel failed with an I/O error first, for example a connection
     * reset by the peer. The recorded cause names the failure.
     */
    TRANSPORT_ERROR,

    /**
     * Nothing local closed the channel and no I/O failure was observed before it closed; on a TCP
     * channel that is the peer ending the stream.
     */
    REMOTE_END_OF_STREAM,

    /** The channel had already closed when the connection was handed to the recorder. */
    CLOSED_BEFORE_OBSERVATION,
}

/**
 * Records one root connection close: who ended it, the connection's endpoints, and the cause.
 *
 * Emitted once per root connection by hosts built with [Libp2pHostFactory]. When a host was built
 * inside an effect scope, the effect is tossed into that scope; the record is always also written
 * to standard error as one `[ConnectionClosed]` line. The record is produced only after the
 * channel's close has completed, so it cannot prevent or delay that close. [closedBy] names the
 * first caller outside Netty and the libp2p channel wrapper that asked for a local close. It is
 * `unknown` for a close requested off the channel's event loop (for example from a worker thread or
 * a `CompletableFuture` callback), because Netty then queues the request and the caller is no
 * longer on the stack; it is `none` for closes this
 * host did not request. For [ConnectionCloseInitiator.TRANSPORT_ERROR] it names the handler that
 * closed in reaction to the failure, if one did.
 *
 * [cause] is the last exception that reached the head of the root channel's pipeline before the
 * close, or `none`: a transport read failure, an exception fired from the head of the pipeline
 * (`pipeline().fireExceptionCaught(...)`), or a failed write promise. An exception raised inside
 * another handler travels towards the tail of the pipeline, never passes the head, and is not
 * recorded here.
 */
class ConnectionClosedEffect(
    val connectionIdentity: String,
    val initiator: ConnectionCloseInitiator,
    val dialledByThisHost: Boolean,
    val localAddress: String,
    val remoteAddress: String,
    val remotePeerId: String,
    val closedBy: String,
    val cause: String,
    val rootLinkDiagnostics: RootLinkDiagnostics?,
) : NotificationEffect(
    "Connection $connectionIdentity closed: initiator=$initiator; " +
        "direction=${if (dialledByThisHost) "outbound" else "inbound"}; " +
        "localAddress=$localAddress; remoteAddress=$remoteAddress; remotePeerId=$remotePeerId; " +
        "closedBy=$closedBy; cause=$cause" + rootLinkDiagnostics.diagnosticSuffix(),
    MessageSeverity.INFO,
) {
    constructor(connectionIdentity: String, initiator: ConnectionCloseInitiator, dialledByThisHost: Boolean,
        localAddress: String, remoteAddress: String, remotePeerId: String, closedBy: String, cause: String
    ) : this(connectionIdentity, initiator, dialledByThisHost, localAddress, remoteAddress, remotePeerId, closedBy, cause, null)
}

/** The identity string used by every connection record, matching the admission messages. */
internal fun connectionRecordIdentity(connection: Connection): String =
    "connection@${System.identityHashCode(connection).toString(16)}"

/** Renders a transport cause for one record line; never includes a stack trace or payload. */
internal fun connectionRecordCause(cause: Throwable?): String =
    if (cause == null) "none" else "${cause.javaClass.name}: ${cause.message ?: "no message"}"

/**
 * Reads one connection attribute for a record. A connection whose session has not been set up
 * cannot answer, and the record says so instead of failing the close path it is describing.
 */
internal inline fun connectionRecordValue(read: () -> Any?): String =
    try {
        read()?.toString() ?: "unknown"
    } catch (failure: Exception) {
        "unavailable (${failure.javaClass.name})"
    }

internal fun connectionRecordRemotePeerId(connection: Connection): String =
    connectionRecordValue { connection.secureSession().remoteId.toBase58() }

/**
 * Tosses [effect] in [ownerRepository] when an owner scope exists. If it is null, no scope owns the
 * record, so the caller's stderr line is the report; do not toss it into the callback thread's
 * scope.
 *
 * Delivery holds the owner repository's monitor, exactly as the admission controller's existing
 * owner-scope delivery (`InboundSubstreamAdmissionControl.tossToOwner`) does, because one scope's
 * handler repository is shared by every host and controller built in it. Callers therefore run
 * this only after the action the record describes has finished.
 *
 * A missing handler in the captured owner scope is the ordinary case, so this effect's own
 * [UnhandledNotificationEffect] is not an error. Anything else a handler throws, including a
 * fatal JVM error, is returned to the caller, which decides how to report it: a diagnostic must
 * neither change the action it describes nor disappear.
 */
internal fun tossConnectionRecordToOwner(
    ownerRepository: EffectHandlerRepository?,
    effect: NotificationEffect,
): Throwable? {
    if (ownerRepository == null) return null

    fun tossHere() {
        try {
            toss(effect)
        } catch (unhandled: UnhandledNotificationEffect) {
            if (unhandled.effect !== effect) throw unhandled
            // Swallowed deliberately: no handler is installed for this record and the stderr line
            // already written is the durable report.
        }
    }
    return try {
        synchronized(ownerRepository) {
            val workerRepository = `$effectHandlerRepository`.get()
            `$effectHandlerRepository`.set(ownerRepository)
            try { tossHere() }
            finally { `$effectHandlerRepository`.set(workerRepository) }
        }
        null
    } catch (failure: Throwable) {
        failure
    }
}

/**
 * Builds one record with [produce], writes it to standard error as one line starting with [prefix],
 * and delivers it to [ownerRepository]'s scope when one exists. Without an owner scope, the stderr
 * line is the complete report.
 *
 * Nothing here is thrown to the caller. A failure while building the record (which then is neither
 * written nor delivered), a standard-error sink that rejects the line (the effect is still
 * delivered), and a handler failure are each passed to [reportFailure], in that order, fatal JVM
 * errors included; the caller decides whether to rethrow a fatal error once its own action is done.
 * Callers invoke this only after the close or reset the record describes, so no outcome of
 * producing or delivering a record can prevent, reorder or hold up that action.
 */
internal inline fun deliverConnectionRecord(
    ownerRepository: EffectHandlerRepository?,
    prefix: String,
    produce: () -> NotificationEffect,
    reportFailure: (Throwable) -> Unit,
) {
    val effect = try {
        produce()
    } catch (failure: Throwable) {
        reportFailure(failure)
        return
    }
    try {
        System.err.println("$prefix ${effect.message}")
    } catch (sinkFailure: Throwable) {
        reportFailure(sinkFailure)
    }
    tossConnectionRecordToOwner(ownerRepository, effect)?.let(reportFailure)
}

private val CLOSE_CALLER_SKIPPED_CLASS_PREFIXES = listOf(
    "io.netty.",
    "java.",
    "jdk.",
    "sun.",
    "kotlin.",
    "kotlinx.coroutines.",
    ConnectionCloseReasonRecorder::class.java.name,
    P2PChannelOverNetty::class.java.name,
    ConnectionOverNetty::class.java.name,
)

/** The first frame that is not Netty, the JDK, Kotlin, the libp2p channel wrapper or the recorder. */
private fun localCloseCaller(stack: Array<StackTraceElement>): String {
    val frame = stack.firstOrNull { element ->
        CLOSE_CALLER_SKIPPED_CLASS_PREFIXES.none { element.className.startsWith(it) }
    } ?: return "unknown"
    return "${frame.className}.${frame.methodName}"
}

private fun socketAddressText(address: SocketAddress?): String = address?.toString() ?: "unknown"

/**
 * Records why each root connection of a host closed.
 *
 * Installed as a host [ConnectionHandler] by every [Libp2pHostFactory] builder. For each
 * established connection it adds a pass-through handler at the head of the root channel's
 * pipeline, where every pipeline close request and every exception fired from the head passes, and
 * reports one [ConnectionClosedEffect] when the channel's close future completes. The pass-through
 * handler never changes, delays or consumes any event, and nothing is retained outside the
 * channel: the observer lives in the channel's pipeline and the listener on its close future.
 */
internal class ConnectionCloseReasonRecorder(
    private val ownerRepository: EffectHandlerRepository? = `$effectHandlerRepository`.get(),
    private val clock: Clock = SystemClock(),
) : ConnectionHandler {
    override fun handleConnection(connection: Connection) {
        val channel = (connection as? P2PChannelOverNetty)?.nettyChannel ?: return
        val observedFromOpen = channel.isOpen
        val state = installRootLinkState(connection, channel, if (observedFromOpen) clock.currentTimeMillis() else null)
        val observer = CloseObserver(state)
        if (observedFromOpen) {
            channel.pipeline().addFirst(CLOSE_OBSERVER_HANDLER_NAME, observer)
        }
        channel.closeFuture().addListener(ChannelFutureListener {
            report(connection, channel, observer, observedFromOpen)
        })
    }

    private fun report(
        connection: Connection,
        channel: Channel,
        observer: CloseObserver,
        observedFromOpen: Boolean,
    ) {
        // This listener runs only after the close future completed, so the close has already
        // happened. Netty's promise notification catches whatever a listener throws and only logs
        // it, so every failure producing or delivering the record, fatal errors included, is handed
        // to this thread's uncaught handler rather than thrown and lost.
        deliverConnectionRecord(
            ownerRepository,
            "[ConnectionClosed]",
            produce = {
                val localCloseStack = observer.localCloseStack
                val transportFailure = observer.transportFailure
                val initiator = when {
                    !observedFromOpen -> ConnectionCloseInitiator.CLOSED_BEFORE_OBSERVATION
                    // A close requested in reaction to an I/O failure (a handler closing on
                    // exceptionCaught) is attributed to that failure; closedBy still names the
                    // reacting caller.
                    localCloseStack != null && !observer.localCloseFollowedIoFailure ->
                        ConnectionCloseInitiator.LOCAL_CLOSE
                    localCloseStack == null && channel.eventLoop().isShuttingDown ->
                        ConnectionCloseInitiator.LOCAL_EVENT_LOOP_SHUTDOWN
                    transportFailure is java.io.IOException -> ConnectionCloseInitiator.TRANSPORT_ERROR
                    else -> ConnectionCloseInitiator.REMOTE_END_OF_STREAM
                }
                ConnectionClosedEffect(
                    connectionIdentity = connectionRecordIdentity(connection),
                    initiator = initiator,
                    dialledByThisHost = connection.isInitiator,
                    localAddress = connectionRecordValue { connection.localAddress() }
                        .takeUnless { it == "unknown" } ?: socketAddressText(channel.localAddress()),
                    remoteAddress = connectionRecordValue { connection.remoteAddress() }
                        .takeUnless { it == "unknown" } ?: socketAddressText(channel.remoteAddress()),
                    remotePeerId = connectionRecordRemotePeerId(connection),
                    closedBy = if (localCloseStack == null) "none" else localCloseCaller(localCloseStack),
                    cause = connectionRecordCause(transportFailure),
                    rootLinkDiagnostics = channel.rootLinkState()?.finish(connectionRecordCause(transportFailure), initiator.toString()),
                )
            },
            reportFailure = { failure ->
                Thread.currentThread().let { it.uncaughtExceptionHandler.uncaughtException(it, failure) }
            },
        )
    }

    /**
     * Pass-through head handler. Fields are written and read on the channel's event loop; the
     * close future completes there too, after the events that led to the close.
     */
    private class CloseObserver(private val state: RootLinkState) : ChannelDuplexHandler() {
        @Volatile var localCloseStack: Array<StackTraceElement>? = null
        @Volatile var transportFailure: Throwable? = null
        @Volatile var localCloseFollowedIoFailure: Boolean = false

        private val writeFailureListener = ChannelFutureListener { future ->
            if (!future.isSuccess && future.cause() != null) {
                transportFailure = future.cause()
                markRelayStreamClose(future.channel(), false, "error", future.cause())
            }
        }

        override fun close(ctx: ChannelHandlerContext, promise: ChannelPromise) {
            val observedPromise = observeCloseAttempt(ctx, promise)
            super.close(ctx, observedPromise)
        }

        override fun disconnect(ctx: ChannelHandlerContext, promise: ChannelPromise) {
            val observedPromise = observeCloseAttempt(ctx, promise)
            super.disconnect(ctx, observedPromise)
        }

        private val pendingCloseAttempts = mutableListOf<RootCloseAttempt>()

        private fun observeCloseAttempt(ctx: ChannelHandlerContext, promise: ChannelPromise): ChannelPromise {
            val relayObservation = beginRelayStreamCloseAttempt(
                ctx.channel(), if (ctx.channel().eventLoop().isShuttingDown) "shutdown" else "local-close"
            )
            val attempt = RootCloseAttempt(Throwable().stackTrace, transportFailure is java.io.IOException)
            pendingCloseAttempts.add(attempt)
            if (localCloseStack == null) selectCloseAttempt(attempt)
            promise.addListener(ChannelFutureListener { future ->
                pendingCloseAttempts.remove(attempt)
                if (!future.isSuccess) abandonRelayStreamCloseAttempt(ctx.channel(), relayObservation)
                if (!future.isSuccess && ctx.channel().isOpen && localCloseStack === attempt.stack) {
                    // Release only this failed attempt. A different outstanding close still owns
                    // its caller, and any copies issued before the failure remain unchanged.
                    state.abandonFailedClose()
                    localCloseStack = null
                    localCloseFollowedIoFailure = false
                    pendingCloseAttempts.firstOrNull()?.let { selectCloseAttempt(it) }
                }
            })
            return promise
        }

        private fun selectCloseAttempt(attempt: RootCloseAttempt) {
            localCloseStack = attempt.stack
            localCloseFollowedIoFailure = attempt.followedIoFailure
            state.freeze(connectionRecordCause(transportFailure), if (attempt.followedIoFailure) "TRANSPORT_ERROR" else "LOCAL_CLOSE")
        }

        override fun channelInactive(ctx: ChannelHandlerContext) {
            finishRelayStreamClose(ctx.channel())
            val initiator = when {
                localCloseStack != null && !localCloseFollowedIoFailure -> "LOCAL_CLOSE"
                transportFailure is java.io.IOException -> "TRANSPORT_ERROR"
                ctx.channel().eventLoop().isShuttingDown -> "LOCAL_EVENT_LOOP_SHUTDOWN"
                else -> "REMOTE_END_OF_STREAM"
            }
            state.finish(connectionRecordCause(transportFailure), initiator)
            super.channelInactive(ctx)
        }

        override fun write(ctx: ChannelHandlerContext, msg: Any?, promise: ChannelPromise) {
            // A failed write closes the channel inside Netty without passing this handler, so the
            // failure is only visible on the write's own promise. A void promise reports the same
            // failure through exceptionCaught instead.
            if (!promise.isVoid) promise.addListener(writeFailureListener)
            super.write(ctx, msg, promise)
        }

        @Suppress("OVERRIDE_DEPRECATION")
        override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
            transportFailure = cause
            markRelayStreamClose(ctx.channel(), false, "error", cause)
            super.exceptionCaught(ctx, cause)
        }
    }

    private companion object {
        const val CLOSE_OBSERVER_HANDLER_NAME = "foundation.url.protocol.connectionCloseReason"
    }
}

private class RootCloseAttempt(val stack: Array<StackTraceElement>, val followedIoFailure: Boolean)
