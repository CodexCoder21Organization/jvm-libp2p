package foundation.url.protocol

/**
 * Controls debug logging for the UrlProtocol library.
 *
 * Disabled by default. Enable via system property:
 *   -Dfoundation.url.protocol.debug=true
 */
val urlProtocolDebugLogging: Boolean =
    System.getProperty("foundation.url.protocol.debug")?.toBoolean() ?: false

internal inline fun debugLog(message: () -> String) {
    if (urlProtocolDebugLogging) {
        println(message())
    }
}

internal inline fun debugLogErr(message: () -> String) {
    if (urlProtocolDebugLogging) {
        System.err.println(message())
    }
}
