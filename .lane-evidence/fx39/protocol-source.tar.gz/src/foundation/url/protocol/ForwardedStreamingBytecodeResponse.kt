package foundation.url.protocol

import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.CountDownLatch
import org.json.JSONObject

/**
 * A bytecode response received by a forwarding RPC client after its JSON header has arrived but
 * before its one binary JAR attachment has finished arriving.
 *
 * This value is transport-owned. A routing handler may pass it through unchanged; the next RPC
 * writer consumes [jarInput] and closes this value when the attachment has been delivered. Keeping
 * the known wire length alongside the stream lets that writer emit the response header immediately
 * without buffering the JAR or changing the RPC 1.1 attachment format.
 */
class ForwardedStreamingBytecodeResponse internal constructor(
    internal val resultJson: org.json.JSONObject,
    val jarLength: Int,
    private val attachmentInput: FramedAttachmentInputStream,
) : AutoCloseable {
    val implClassName: String = resultJson.getString("implClassName")
    val jarInput: InputStream get() = attachmentInput
    internal fun claimWriter() = attachmentInput.claimWriter()
    internal fun releaseWriter() = attachmentInput.releaseWriter()
    internal fun observeWriterCancellation(listener: () -> Unit): AutoCloseable =
        attachmentInput.observeWriterCancellation(listener)

    /**
     * Registers an action to release resources owned by this response. Register before returning
     * this value to an RPC writer. Each registration runs once, on successful delivery, failure,
     * cancellation, or explicit close; registration after completion runs immediately.
     *
     * Once a writer claims the response, completion waits for that writer to exit, including its
     * last attachment write. Reading the backend's final byte alone does not complete a write.
     * Without a writer, the caller must close this value (or [jarInput]) to complete it. Closing
     * an unread response may leave its shared backend reader draining the discarded frame.
     *
     * Actions run synchronously on the completing or registering thread, outside library locks,
     * and may re-enter this API. They should return promptly. A failing action does not prevent
     * other registered actions from running: its failure propagates after cleanup and delivery
     * of the other actions, with additional failures suppressed.
     */
    fun onCompletion(listener: () -> Unit) = attachmentInput.onCompletion(listener)

    override fun close() {
        jarInput.close()
    }

    internal fun discardUnclaimed() = attachmentInput.discardUnclaimed()
}

/**
 * Exposes exactly one attachment body from a shared framed input stream. Reading the declared
 * length completes this stream without closing the shared input. Closing it early returns the
 * remaining declared frame to its reader for bounded draining; transport failures still close it.
 */
internal class FramedAttachmentInputStream(
    private val input: InputStream,
    private val length: Int,
    private val lease: ForwardedTransferLease,
    private val clock: community.kotlin.clocks.simple.Clock = Libp2pRpcProtocol.attachmentClock,
) : InputStream() {
    init {
        require(length >= 0) { "Forwarded bytecode attachment length must be non-negative, but was $length" }
    }

    private val finished = CountDownLatch(1)
    private var remaining = length
    private var closed = false
    @Volatile private var ownerTerminal: java.util.concurrent.atomic.AtomicBoolean? = null
    private var readActive = false
    private var readCompletion: CountDownLatch? = null
    private var writerOwned = false
    private var writerClaimed = false
    private var completionDelivered = false
    private val completionListeners = ArrayList<() -> Unit>()
    private var writerCancellationListener: (() -> Unit)? = null
    private var discardRequested = false
    private var failure: IOException? = null
    private val admittedAt = clock.currentTimeMillis()
    private var demandStartedAt = admittedAt
    private val watchdog = java.util.concurrent.atomic.AtomicReference<java.util.concurrent.ScheduledFuture<*>?>()

    init {
        val scheduled = Libp2pRpcProtocol.scheduleAttachmentStallWatchdog {
            val cause = synchronized(this) {
                val now = clock.currentTimeMillis()
                when {
                    closed && !discardRequested -> null
                    now - admittedAt > Libp2pRpcProtocol.attachmentLeaseDeadlineMs(length.toLong()) ->
                        IOException("Forwarded bytecode attachment exceeded its absolute lifetime of " +
                            "${Libp2pRpcProtocol.attachmentLeaseDeadlineMs(length.toLong())}ms")
                    readActive && now - demandStartedAt > Libp2pRpcProtocol.ATTACHMENT_STALL_TIMEOUT_MS ->
                        IOException("Forwarded bytecode attachment stalled with no read progress for " +
                            "${Libp2pRpcProtocol.ATTACHMENT_STALL_TIMEOUT_MS}ms while a reader requested bytes")
                    else -> null
                }
            }
            if (cause != null) cancel(cause)
        }
        watchdog.set(scheduled)
        synchronized(this) { if (closed) scheduled.cancel(false) }
    }

    init {
        if (length == 0) finished.countDown()
    }

    internal fun observeOwnerTerminalState(terminal: java.util.concurrent.atomic.AtomicBoolean) {
        ownerTerminal = terminal
    }

    internal val isAbandoned: Boolean get() = synchronized(this) { closed && discardRequested }

    fun claimWriter() = synchronized(this) {
        if (closed) throw failure ?: IOException("Forwarded bytecode attachment stream is closed")
        check(!writerClaimed) { "Forwarded bytecode response already has a writer" }
        writerClaimed = true
        writerOwned = true
    }

    fun releaseWriter() {
        withForwardedCompletion({
            try { close() } finally {
                val release = synchronized(this) {
                    writerOwned = false
                    !discardRequested
                }
                if (release) lease.close()
            }
        }, ::completeIfTerminal)
    }

    fun onCompletion(listener: () -> Unit) {
        val fireNow = synchronized(this) {
            if (completionDelivered) true else {
                completionListeners.add(listener)
                false
            }
        }
        if (fireNow) listener()
    }

    fun observeWriterCancellation(listener: () -> Unit): AutoCloseable {
        val cancelled = synchronized(this) {
            check(writerCancellationListener == null) { "Forwarded response already has a cancellation observer" }
            if (closed) true else {
                writerCancellationListener = listener
                false
            }
        }
        if (cancelled) listener()
        return AutoCloseable {
            synchronized(this) {
                if (writerCancellationListener === listener) writerCancellationListener = null
            }
        }
    }

    private fun completeIfTerminal() {
        val listeners = synchronized(this) {
            if (completionDelivered || !closed || writerOwned) return
            completionDelivered = true
            ArrayList(completionListeners).also { completionListeners.clear() }
        }
        var failure: Throwable? = null
        for (listener in listeners) {
            try { listener() } catch (next: Throwable) {
                failure = combineForwardedCompletionFailures(failure, next)
            }
        }
        failure?.let { throw it }
    }

    override fun read(): Int {
        val one = ByteArray(1)
        val count = read(one, 0, 1)
        return if (count < 0) -1 else one[0].toInt() and 0xff
    }

    override fun read(bytes: ByteArray, offset: Int, length: Int): Int =
        readBody(bytes, offset, length, draining = false)

    private fun readBody(bytes: ByteArray, offset: Int, length: Int, draining: Boolean): Int {
        require(offset >= 0 && length >= 0 && offset <= bytes.size - length) {
            "Invalid attachment read range: offset=$offset, length=$length, arraySize=${bytes.size}"
        }
        val completed = CountDownLatch(1)
        val requested = synchronized(this) {
            failure?.let { throw it }
            if (closed && !draining) throw IOException("Forwarded bytecode attachment stream is closed")
            if (length == 0) return 0
            if (remaining == 0) return -1
            check(!readActive) { "Forwarded bytecode attachment does not support concurrent reads" }
            readActive = true
            readCompletion = completed
            demandStartedAt = clock.currentTimeMillis()
            minOf(length, remaining, ATTACHMENT_WRITE_CHUNK_BYTES)
        }
        try {
            val read = try {
                input.read(bytes, offset, requested).also { count ->
                    if (count < 0) {
                        val unread = synchronized(this) { remaining }
                        throw EOFException("Forwarded bytecode attachment ended with $unread of its declared bytes unread")
                    }
                }
            } catch (cause: IOException) {
                cancel(cause)
                throw synchronized(this) { failure ?: cause }
            }
            return synchronized(this) {
                // Bytes already consumed still belong to this frame when close races a read.
                remaining -= read
                failure?.let { throw it }
                if (remaining == 0) finished.countDown()
                if (closed && !draining) throw IOException("Forwarded bytecode attachment stream was closed while reading")
                read
            }
        } finally {
            synchronized(this) { readActive = false }
            completed.countDown()
        }
    }

    override fun available(): Int = synchronized(this) {
        if (closed || remaining == 0) 0 else minOf(input.available(), remaining)
    }

    override fun close() = cancel(null)

    private fun cancel(cause: IOException?) {
        val (state, cancelledWriter) = synchronized(this) {
            val terminalOwner = ownerTerminal?.get() == true
            // Owner close interrupts its reader to wake it. Preserve the body's selected close,
            // while completing cleanup if a live discard was still waiting for an active read.
            val selectedCause = if (terminalOwner && (closed || cause?.cause is InterruptedException)) null else cause
            if (closed && (failure != null || !discardRequested || (selectedCause == null && !terminalOwner))) return
            closed = true
            failure = selectedCause
            discardRequested = selectedCause == null && !terminalOwner && remaining > 0
            finished.countDown()
            val listener = writerCancellationListener
            writerCancellationListener = null
            Triple((selectedCause != null || terminalOwner) && remaining > 0, !writerOwned && !discardRequested, discardRequested) to listener
        }
        if (!state.third) watchdog.get()?.cancel(false)
        withForwardedCompletion({
            try {
                // Only a genuine transport failure closes the shared input. A caller's close
                // returns a known frame boundary to the reader, which owns the existing bounds.
                if (state.first) input.close()
            } finally {
                if (state.second) lease.close()
            }
        }, {
            withForwardedCompletion({ cancelledWriter?.invoke() }, ::completeIfTerminal)
        })
    }

    // Only a caller that never received this source may return its ownership to the reader.
    fun discardUnclaimed() {
        synchronized(this) { if (writerClaimed) return }
        close()
    }

    fun awaitFinished() {
        try {
            finished.await()
            val activeRead = synchronized(this) {
                failure?.let { throw it }
                if (!discardRequested) return
                readCompletion
            }
            // A reader that was already inside input.read owns those bytes until it exits.
            // New public reads are refused after close, so no new read can race this handoff.
            activeRead?.await()
            try {
                val scratch = ByteArray(ATTACHMENT_WRITE_CHUNK_BYTES)
                while (readBody(scratch, 0, scratch.size, draining = true) >= 0) { }
            } finally {
                val release = synchronized(this) {
                    discardRequested = false
                    !writerOwned
                }
                watchdog.get()?.cancel(false)
                if (release) lease.close()
            }
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            cancel(IOException("Interrupted while waiting for a forwarded bytecode attachment to be consumed", interrupted))
            throw IOException("Interrupted while waiting for a forwarded bytecode attachment to be consumed", interrupted)
        }
    }
}

/** Run notifications after cleanup without replacing the original transport/cleanup failure. */
private inline fun withForwardedCompletion(cleanup: () -> Unit, complete: () -> Unit) {
    var failure: Throwable? = null
    try { cleanup() } catch (next: Throwable) { failure = next }
    try { complete() } catch (next: Throwable) {
        failure = combineForwardedCompletionFailures(failure, next)
    }
    failure?.let { throw it }
}

internal fun combineForwardedCompletionFailures(previous: Throwable?, next: Throwable): Throwable {
    if (previous == null || previous === next) return next
    if (isFatalJvmError(next) && !isFatalJvmError(previous)) {
        next.addSuppressed(previous)
        return next
    }
    previous.addSuppressed(next)
    return previous
}

/** One nonblocking process-wide reservation, independent of the materializing reader's pool. */
internal class ForwardedTransferLease private constructor(private val bytes: Long) : AutoCloseable {
    private val released = java.util.concurrent.atomic.AtomicBoolean(false)
    override fun close() {
        if (!released.compareAndSet(false, true)) return
        synchronized(forwardedMemoryLock) {
            forwardedRetainedBytes -= bytes
            forwardedTransfers--
        }
    }

    companion object {
        fun acquire(jsonBytes: Int): ForwardedTransferLease? {
            // Cover the retained model/metadata, its outbound encoding, four bounded chunk copies,
            // and fixed stream/lease bookkeeping. Transport queues retain their own existing caps.
            val bytes = jsonBytes.toLong() * 32L + 4L * ATTACHMENT_WRITE_CHUNK_BYTES + 8192L
            synchronized(forwardedMemoryLock) {
                if (forwardedTransfers >= 32 || bytes > forwardedByteLimit - forwardedRetainedBytes) {
                    return null
                }
                forwardedRetainedBytes += bytes
                forwardedTransfers++
            }
            return ForwardedTransferLease(bytes)
        }
    }
}

private val forwardedMemoryLock = Any()
private val forwardedByteLimit = (Runtime.getRuntime().maxMemory() / 16L)
    .coerceIn(8L * 1024 * 1024, 256L * 1024 * 1024)
private var forwardedRetainedBytes = 0L
private var forwardedTransfers = 0

/** Current admitted forwarding storage; unread body bytes are not retained heap storage. */
data class ForwardedTransferMemorySnapshot(
    val retainedBytes: Long,
    val byteLimit: Long,
    val activeTransfers: Int,
    val transferLimit: Int,
)

fun forwardedTransferMemorySnapshot(): ForwardedTransferMemorySnapshot = synchronized(forwardedMemoryLock) {
    ForwardedTransferMemorySnapshot(forwardedRetainedBytes, forwardedByteLimit, forwardedTransfers, 32)
}

internal fun interface SingleAttachmentStreamConsumer {
    fun accept(length: Int, input: FramedAttachmentInputStream)
}

internal fun ForwardedStreamingBytecodeResponse.toResponseJson(
    responseId: String,
    metadata: Map<String, String>,
): JSONObject = JSONObject().apply {
    put("type", Libp2pRpcProtocol.TYPE_RESPONSE)
    put("id", responseId)
    put("result", resultJson)
    if (metadata.isNotEmpty()) put("metadata", JSONObject(metadata))
}
