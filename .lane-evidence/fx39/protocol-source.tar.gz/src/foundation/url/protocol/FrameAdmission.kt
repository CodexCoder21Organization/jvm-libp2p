package foundation.url.protocol

import java.io.IOException
import java.io.InterruptedIOException
import java.lang.ref.ReferenceQueue
import java.lang.ref.WeakReference

/** A frame owns a turn, never a monitor while it calls the transport. */
internal class FrameAdmission {
    private val state = Object()
    @Volatile private var terminalFailure: IOException? = null
    private val permitWaiters = java.util.Collections.newSetFromMap(
        java.util.IdentityHashMap<FramePermitWait, Boolean>())
    private var owner: Thread? = null

    fun acquire() {
        synchronized(state) {
            while (terminalFailure == null && owner != null) {
                if (owner === Thread.currentThread()) {
                    throw IOException("Cannot start another frame from inside an active frame write")
                }
                try {
                    state.wait()
                } catch (interrupted: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw InterruptedIOException("Interrupted while waiting to write a frame").apply {
                        initCause(interrupted)
                    }
                }
            }
            terminalFailure?.let { throw it }
            owner = Thread.currentThread()
        }
    }

    fun tryAcquire(): Boolean = synchronized(state) {
        terminalFailure?.let { throw it }
        if (owner != null) false else {
            owner = Thread.currentThread()
            true
        }
    }

    fun release() {
        synchronized(state) {
            check(owner === Thread.currentThread())
            owner = null
            state.notifyAll()
        }
    }

    fun registerPermitWait(wait: FramePermitWait) {
        synchronized(state) {
            ensureOpen()
            permitWaiters.add(wait)
        }
    }

    fun unregisterPermitWait(wait: FramePermitWait) {
        synchronized(state) { permitWaiters.remove(wait) }
    }

    fun ensureOpen() {
        terminalFailure?.let { throw it }
    }

    fun close(cause: IOException = IOException("Stream closed")) {
        val waiting = synchronized(state) {
            if (terminalFailure == null) terminalFailure = cause
            state.notifyAll()
            permitWaiters.toList().also { permitWaiters.clear() }
        }
        // A waiting thread is canceled outside state ownership. Its handoff prevents this
        // interruption from reaching a frame that has started executing after the permit wait.
        var failure: Throwable? = null
        for (wait in waiting) {
            try {
                wait.cancel()
            } catch (next: Throwable) {
                if (failure == null) failure = next
                else if (failure !== next) failure.addSuppressed(next)
            }
        }
        failure?.let { throw it }
    }
}

internal inline fun <T> FrameAdmission.withFrame(action: () -> T): T {
    acquire()
    try {
        return action()
    } finally {
        release()
    }
}

/** Cancellation owns only a permit wait, never the subsequent supplied writer. */
internal class FramePermitWait(private val caller: Thread) {
    private val state = Object()
    private var finishing = false
    private var canceling = false
    private var canceled = false

    fun cancel() {
        synchronized(state) {
            if (finishing || canceling) return
            canceling = true
        }
        try {
            caller.interrupt()
        } finally {
            synchronized(state) {
                canceled = true
                state.notifyAll()
            }
        }
    }

    /**
     * Ends the wait. Returns true when a close canceled it: that close interrupted the caller only
     * to end the wait, and the admission's terminal failure then replaces the interrupt.
     */
    fun finish(): Boolean {
        var interrupted = false
        val wasCanceled = synchronized(state) {
            finishing = true
            while (canceling && !canceled) {
                try {
                    state.wait()
                } catch (_: InterruptedException) {
                    interrupted = true
                }
            }
            canceled
        }
        if (interrupted && !wasCanceled) Thread.currentThread().interrupt()
        return wasCanceled
    }
}

internal fun acquireFramePermit(admission: FrameAdmission, permit: java.util.concurrent.Semaphore) {
    val waiting = FramePermitWait(Thread.currentThread())
    admission.registerPermitWait(waiting)
    var acquired = false
    try {
        permit.acquire()
        acquired = true
    } finally {
        if (waiting.finish()) {
            // The cancel's interrupt may still be pending when the permit had already been
            // acquired, or when it arrived during finish(). The close that canceled this wait
            // becomes the caller's terminal IOException below; leaving the flag set would make
            // an unrelated later blocking call on this pooled thread fail.
            Thread.interrupted()
        }
        admission.unregisterPermitWait(waiting)
        try {
            admission.ensureOpen()
        } catch (closed: IOException) {
            if (acquired) permit.release()
            throw closed
        }
    }
}

/** Values must not strongly retain their keys. Factories here only create internal state. */
internal class WeakIdentityRegistry<K : Any, V> {
    private val collected = ReferenceQueue<K>()
    private val entries = HashMap<IdentityReference<K>, V>()

    @Synchronized operator fun get(key: K): V? {
        pruneIdentityReferences(collected, entries)
        return entries[IdentityReference(key)]
    }

    @Synchronized operator fun set(key: K, value: V) {
        pruneIdentityReferences(collected, entries)
        entries[IdentityReference(key, collected)] = value
    }

    @Synchronized fun getOrPut(key: K, create: () -> V): V {
        pruneIdentityReferences(collected, entries)
        val lookup = IdentityReference(key, collected)
        return entries[lookup] ?: create().also { entries[lookup] = it }
    }

}

private fun <K : Any, V> pruneIdentityReferences(
    collected: ReferenceQueue<K>,
    entries: MutableMap<IdentityReference<K>, V>,
) {
    while (true) entries.remove(collected.poll() ?: return)
}

private class IdentityReference<T : Any>(key: T, queue: ReferenceQueue<T>? = null) : WeakReference<T>(key, queue) {
    private val hash = System.identityHashCode(key)
    override fun hashCode(): Int = hash
    override fun equals(other: Any?): Boolean =
        this === other || (other is IdentityReference<*> && get()?.let { it === other.get() } == true)
}
