package foundation.url.protocol

import java.io.FilterInputStream
import java.io.InputStream

/**
 * A provider's gossip input and its format rule, applied to the decoded message before admission.
 *
 * The default [validator] accepts every identity format, for providers with opaque names. A
 * supplied validator may throw a descriptive exception to refuse a decoded message. Wrapping
 * another gossip input replaces its policy; ordinary provider/stream delegation preserves it.
 * Reads and close are delegated to [input]; this wrapper owns no additional resource.
 */
class GossipInputStream @JvmOverloads constructor(
    input: InputStream,
    private val validator: (Any) -> Unit = {},
) : FilterInputStream(input) {
    internal fun validateGossipMessage(message: Any) {
        validator(message)
    }
}

internal fun InputStream.readGossipMessage(): Any {
    val message = GossipProtocol.parseMessage(Libp2pRpcProtocol.readMessage(this))
    (this as? GossipInputStream)?.validateGossipMessage(message)
    return message
}
