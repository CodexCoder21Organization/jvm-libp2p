package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.util.Collections
import java.util.LinkedHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

/**
 * Gossip protocol for service advertisement across the P2P network.
 *
 * When a service is registered, this protocol broadcasts the announcement
 * to all connected peers, who then re-broadcast to their peers, until
 * every peer in the network is aware of the service.
 *
 * Features:
 * - Service announcements with TTL to prevent infinite loops
 * - Seen message tracking to prevent duplicate processing
 * - Support for STUN/TURN addresses for NAT traversal
 */
object GossipProtocol {
    const val PROTOCOL_ID = "/urlresolver-gossip/1.0.0"

    // Message types
    const val TYPE_SERVICE_ANNOUNCE = "service_announce"
    const val TYPE_SERVICE_WITHDRAW = "service_withdraw"
    const val TYPE_SERVICE_QUERY = "service_query"
    const val TYPE_SERVICE_QUERY_RESPONSE = "service_query_response"
    const val TYPE_PEER_EXCHANGE = "peer_exchange"
    const val TYPE_PEER_ANNOUNCE = "peer_announce"
    const val TYPE_RELAY_ANNOUNCE = "relay_announce"
    const val TYPE_RELAY_WITHDRAW = "relay_withdraw"
    const val TYPE_TLD_RESOLVER_ANNOUNCE = "tld_resolver_announce"
    const val TYPE_LINK_STATE_ADVERTISEMENT = "link_state_advertisement"

    // Default TTL for gossip messages
    const val DEFAULT_TTL = 7

    private val messageIdCounter = AtomicLong(0)

    /**
     * Distinguishes the ids minted by this process from those minted by every other process.
     *
     * A gossip message id is the key [GossipMessageTracker] deduplicates on, and that tracker sees
     * messages from every peer. A millisecond plus a counter that restarts at zero in every
     * process is unique only within one process, so two peers that start together mint the same
     * ids and the tracker silently discards the second peer's announcement as a duplicate of the
     * first's.
     */
    private val messageIdProcessNonce: String =
        java.lang.Long.toUnsignedString(java.security.SecureRandom().nextLong(), 36)

    /**
     * Generates a unique message ID for gossip messages. The id is unique across every process that
     * mints one, not only within this process.
     */
    fun nextMessageId(): String =
        "gossip-${System.currentTimeMillis()}-$messageIdProcessNonce-${messageIdCounter.incrementAndGet()}"

    /**
     * Represents a service announcement message.
     *
     * When a peer registers a new service, it broadcasts this announcement
     * to all its connected peers. Each peer decrements the TTL and
     * re-broadcasts to its own peers until TTL reaches 0.
     */
    class ServiceAnnouncement(
        val messageId: String,
        val serviceUrl: String,
        val serviceIdentifier: String,
        val providerPeerId: String,
        val providerMultiaddresses: List<String>,
        val stunAddresses: List<String> = emptyList(),
        val turnServers: List<TurnServerInfo> = emptyList(),
        val metadata: Map<String, String> = emptyMap(),
        val timestamp: Long = System.currentTimeMillis(),
        val ttl: Int = DEFAULT_TTL
    ) {
        private var _freshness: PeerFreshness? = null
        val freshness: PeerFreshness? get() = _freshness

        constructor(
            messageId: String,
            serviceUrl: String,
            serviceIdentifier: String,
            providerPeerId: String,
            providerMultiaddresses: List<String>,
            stunAddresses: List<String>,
            turnServers: List<TurnServerInfo>,
            metadata: Map<String, String>,
            timestamp: Long,
            ttl: Int,
            freshness: PeerFreshness?
        ) : this(messageId, serviceUrl, serviceIdentifier, providerPeerId, providerMultiaddresses, stunAddresses, turnServers, metadata, timestamp, ttl) {
            _freshness = freshness
        }

        fun withFreshness(freshness: PeerFreshness?): ServiceAnnouncement = copy().also { it._freshness = freshness }
        fun withFreshnessAgedBy(elapsedMillis: Long): ServiceAnnouncement = withFreshness(freshness?.agedBy(elapsedMillis))

        operator fun component1(): String = messageId
        operator fun component2(): String = serviceUrl
        operator fun component3(): String = serviceIdentifier
        operator fun component4(): String = providerPeerId
        operator fun component5(): List<String> = providerMultiaddresses
        operator fun component6(): List<String> = stunAddresses
        operator fun component7(): List<TurnServerInfo> = turnServers
        operator fun component8(): Map<String, String> = metadata
        operator fun component9(): Long = timestamp
        operator fun component10(): Int = ttl

        fun copy(
            messageId: String = this.messageId,
            serviceUrl: String = this.serviceUrl,
            serviceIdentifier: String = this.serviceIdentifier,
            providerPeerId: String = this.providerPeerId,
            providerMultiaddresses: List<String> = this.providerMultiaddresses,
            stunAddresses: List<String> = this.stunAddresses,
            turnServers: List<TurnServerInfo> = this.turnServers,
            metadata: Map<String, String> = this.metadata,
            timestamp: Long = this.timestamp,
            ttl: Int = this.ttl
        ): ServiceAnnouncement {
            val result = ServiceAnnouncement(messageId, serviceUrl, serviceIdentifier, providerPeerId, providerMultiaddresses, stunAddresses, turnServers, metadata, timestamp, ttl, if (providerPeerId == this.providerPeerId) freshness else null)
            return result
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is ServiceAnnouncement) return false
            return messageId == other.messageId &&
                serviceUrl == other.serviceUrl &&
                serviceIdentifier == other.serviceIdentifier &&
                providerPeerId == other.providerPeerId &&
                providerMultiaddresses == other.providerMultiaddresses &&
                stunAddresses == other.stunAddresses &&
                turnServers == other.turnServers &&
                metadata == other.metadata &&
                timestamp == other.timestamp &&
                ttl == other.ttl && freshness == other.freshness
        }

        override fun hashCode(): Int {
            val legacyHash = peerFreshnessDataClassHash(messageId, serviceUrl, serviceIdentifier, providerPeerId, providerMultiaddresses, stunAddresses, turnServers, metadata, timestamp, ttl)
            return if (freshness == null) legacyHash else 31 * legacyHash + freshness.hashCode()
        }

        override fun toString(): String {
            val legacy = "ServiceAnnouncement(" + listOf("messageId=$messageId", "serviceUrl=$serviceUrl", "serviceIdentifier=$serviceIdentifier", "providerPeerId=$providerPeerId", "providerMultiaddresses=$providerMultiaddresses", "stunAddresses=$stunAddresses", "turnServers=$turnServers", "metadata=$metadata", "timestamp=$timestamp", "ttl=$ttl").joinToString(", ") + ")"
            return if (freshness == null) legacy else legacy.substring(0, legacy.length - 1) + ", freshness=$freshness)"
        }


        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_SERVICE_ANNOUNCE)
                put("messageId", messageId)
                put("serviceUrl", serviceUrl)
                put("serviceIdentifier", serviceIdentifier)
                put("providerPeerId", providerPeerId)
                put("providerMultiaddresses", JSONArray(providerMultiaddresses))
                put("stunAddresses", JSONArray(stunAddresses))
                put("turnServers", JSONArray(turnServers.map { it.toJson() }))
                put("metadata", JSONObject(metadata))
                put("timestamp", timestamp)
                put("ttl", ttl)

                freshness?.let { put("freshness", it.toJson()) }
            }
        }

        /**
         * Creates a copy with decremented TTL for re-broadcasting.
         */
        fun withDecrementedTtl(): ServiceAnnouncement = copy(ttl = ttl - 1)

        /**
         * Returns true if this announcement should be re-broadcast.
         */
        fun shouldPropagate(): Boolean = ttl > 0

        companion object {
            fun fromJson(json: JSONObject): ServiceAnnouncement {
                val multiaddrs = mutableListOf<String>()
                val addrsArray = json.getJSONArray("providerMultiaddresses")
                for (i in 0 until addrsArray.length()) {
                    multiaddrs.add(addrsArray.getString(i))
                }

                val stunAddrs = mutableListOf<String>()
                val stunArray = json.optJSONArray("stunAddresses")
                if (stunArray != null) {
                    for (i in 0 until stunArray.length()) {
                        stunAddrs.add(stunArray.getString(i))
                    }
                }

                val turnServers = mutableListOf<TurnServerInfo>()
                val turnArray = json.optJSONArray("turnServers")
                if (turnArray != null) {
                    for (i in 0 until turnArray.length()) {
                        turnServers.add(TurnServerInfo.fromJson(turnArray.getJSONObject(i)))
                    }
                }

                val metadata = mutableMapOf<String, String>()
                val metadataObj = json.optJSONObject("metadata")
                if (metadataObj != null) {
                    for (key in metadataObj.keys()) {
                        metadata[key] = metadataObj.getString(key)
                    }
                }

                return ServiceAnnouncement(
                    messageId = json.getString("messageId"),
                    serviceUrl = json.getString("serviceUrl"),
                    serviceIdentifier = json.getString("serviceIdentifier"),
                    providerPeerId = json.getString("providerPeerId"),
                    providerMultiaddresses = multiaddrs,
                    stunAddresses = stunAddrs,
                    turnServers = turnServers,
                    metadata = metadata,
                    timestamp = json.getLong("timestamp"),
                    ttl = json.getInt("ttl"),
                    freshness = PeerFreshness.fromJson(json.optJSONObject("freshness")),
                )
            }
        }

        fun withDecrementedTtl(elapsedMillis: Long): ServiceAnnouncement =
            withDecrementedTtl().withFreshness(freshness?.agedBy(elapsedMillis))

    }

    /**
     * Represents a service withdrawal message.
     * Sent when a service is no longer available.
     */
    data class ServiceWithdrawal(
        val messageId: String,
        val serviceUrl: String,
        val serviceIdentifier: String,
        val providerPeerId: String,
        val timestamp: Long = System.currentTimeMillis(),
        val ttl: Int = DEFAULT_TTL
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_SERVICE_WITHDRAW)
                put("messageId", messageId)
                put("serviceUrl", serviceUrl)
                put("serviceIdentifier", serviceIdentifier)
                put("providerPeerId", providerPeerId)
                put("timestamp", timestamp)
                put("ttl", ttl)
            }
        }

        fun withDecrementedTtl(): ServiceWithdrawal = copy(ttl = ttl - 1)
        fun shouldPropagate(): Boolean = ttl > 0

        companion object {
            fun fromJson(json: JSONObject): ServiceWithdrawal {
                return ServiceWithdrawal(
                    messageId = json.getString("messageId"),
                    serviceUrl = json.getString("serviceUrl"),
                    serviceIdentifier = json.getString("serviceIdentifier"),
                    providerPeerId = json.getString("providerPeerId"),
                    timestamp = json.getLong("timestamp"),
                    ttl = json.getInt("ttl")
                )
            }
        }
    }

    /**
     * Query for services matching a pattern.
     */
    data class ServiceQuery(
        val id: String,
        val servicePattern: String,
        val maxResults: Int = 10
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_SERVICE_QUERY)
                put("id", id)
                put("servicePattern", servicePattern)
                put("maxResults", maxResults)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): ServiceQuery {
                return ServiceQuery(
                    id = json.getString("id"),
                    servicePattern = json.getString("servicePattern"),
                    maxResults = json.optInt("maxResults", 10)
                )
            }
        }
    }

    /**
     * Response to a service query.
     */
    data class ServiceQueryResponse(
        val id: String,
        val services: List<ServiceInfo>
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_SERVICE_QUERY_RESPONSE)
                put("id", id)
                put("services", JSONArray(services.map { it.toJson() }))
            }
        }

        companion object {
            fun fromJson(json: JSONObject): ServiceQueryResponse {
                val services = mutableListOf<ServiceInfo>()
                val servicesArray = json.getJSONArray("services")
                for (i in 0 until servicesArray.length()) {
                    services.add(ServiceInfo.fromJson(servicesArray.getJSONObject(i)))
                }
                return ServiceQueryResponse(
                    id = json.getString("id"),
                    services = services
                )
            }
        }
    }

    /**
     * Peer exchange message for sharing known peers.
     */
    data class PeerExchange(
        val id: String,
        val peers: List<PeerInfo>,
        val isRequest: Boolean
    ) {
        /**
         * Optional response projection for acknowledgement-style exchanges. When present on a
         * request, the responder returns only records whose IDs are both listed here and included
         * in [peers]. Missing preserves the legacy full-peer-view response.
         */
        var requestedResponsePeerIds: Set<String>? = null
            private set

        /**
         * Additive constructor for projected requests. The original three-argument primary
         * constructor and generated data-class methods remain byte-for-byte compatible with
         * clients compiled before response projections existed.
         */
        constructor(
            id: String,
            peers: List<PeerInfo>,
            isRequest: Boolean,
            requestedResponsePeerIds: Set<String>?
        ) : this(id, peers, isRequest) {
            this.requestedResponsePeerIds = requestedResponsePeerIds?.toSet()
        }

        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_PEER_EXCHANGE)
                put("id", id)
                put("peers", JSONArray(peers.map { it.toJson() }))
                put("isRequest", isRequest)
                requestedResponsePeerIds?.let {
                    put("requestedResponsePeerIds", JSONArray(it.sorted()))
                }
            }
        }

        companion object {
            fun fromJson(json: JSONObject): PeerExchange {
                val peers = mutableListOf<PeerInfo>()
                val peersArray = json.getJSONArray("peers")
                for (i in 0 until peersArray.length()) {
                    peers.add(PeerInfo.fromJson(peersArray.getJSONObject(i)))
                }
                val requestedResponsePeerIds = json.optJSONArray("requestedResponsePeerIds")?.let { array ->
                    buildSet {
                        for (i in 0 until array.length()) {
                            add(array.getString(i))
                        }
                    }
                }
                return PeerExchange(
                    id = json.getString("id"),
                    peers = peers,
                    isRequest = json.getBoolean("isRequest"),
                    requestedResponsePeerIds = requestedResponsePeerIds
                )
            }
        }
    }

    /**
     * Peer announcement message for broadcasting peer discovery.
     *
     * When a peer discovers a new peer (e.g., via relay registration),
     * it broadcasts this announcement to all connected peers. Each peer
     * decrements the TTL and re-broadcasts to its own peers until TTL reaches 0.
     *
     * This ensures peer information propagates across the entire network
     * regardless of which relay or bootstrap node peers connect to.
     *
     * The generated `copy()` does not carry `serviceLifecycleTimestamps`; use
     * [withDecrementedTtl] or the full secondary constructor when the map must be retained.
     */
    class PeerAnnouncement(
        val messageId: String,
        val peerId: String,
        val multiaddresses: List<String>,
        val advertisedServices: List<String>,
        val timestamp: Long = System.currentTimeMillis(),
        val ttl: Int = DEFAULT_TTL
    ) {
        private var _freshness: PeerFreshness? = null
        val freshness: PeerFreshness? get() = _freshness

        constructor(
            messageId: String,
            peerId: String,
            multiaddresses: List<String>,
            advertisedServices: List<String>,
            timestamp: Long,
            ttl: Int,
            serviceLifecycleTimestamps: Map<String, Long>? = null,
            freshness: PeerFreshness?
        ) : this(messageId, peerId, multiaddresses, advertisedServices, timestamp, ttl, serviceLifecycleTimestamps) {
            _freshness = freshness
        }

        fun withFreshness(freshness: PeerFreshness?): PeerAnnouncement = copy().also { it._freshness = freshness }
        fun withFreshnessAgedBy(elapsedMillis: Long): PeerAnnouncement = withFreshness(freshness?.agedBy(elapsedMillis))

        operator fun component1(): String = messageId
        operator fun component2(): String = peerId
        operator fun component3(): List<String> = multiaddresses
        operator fun component4(): List<String> = advertisedServices
        operator fun component5(): Long = timestamp
        operator fun component6(): Int = ttl

        fun copy(
            messageId: String = this.messageId,
            peerId: String = this.peerId,
            multiaddresses: List<String> = this.multiaddresses,
            advertisedServices: List<String> = this.advertisedServices,
            timestamp: Long = this.timestamp,
            ttl: Int = this.ttl
        ): PeerAnnouncement {
            val result = PeerAnnouncement(messageId, peerId, multiaddresses, advertisedServices, timestamp, ttl, serviceLifecycleTimestamps, if (peerId == this.peerId) freshness else null)
            result.serviceLifecycleTimestamps = serviceLifecycleTimestamps
            return result
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is PeerAnnouncement) return false
            return messageId == other.messageId &&
                peerId == other.peerId &&
                multiaddresses == other.multiaddresses &&
                advertisedServices == other.advertisedServices &&
                timestamp == other.timestamp &&
                ttl == other.ttl && freshness == other.freshness
        }

        override fun hashCode(): Int {
            val legacyHash = peerFreshnessDataClassHash(messageId, peerId, multiaddresses, advertisedServices, timestamp, ttl)
            return if (freshness == null) legacyHash else 31 * legacyHash + freshness.hashCode()
        }

        override fun toString(): String {
            val legacy = "PeerAnnouncement(" + listOf("messageId=$messageId", "peerId=$peerId", "multiaddresses=$multiaddresses", "advertisedServices=$advertisedServices", "timestamp=$timestamp", "ttl=$ttl").joinToString(", ") + ")"
            return if (freshness == null) legacy else legacy.substring(0, legacy.length - 1) + ", freshness=$freshness)"
        }


        var serviceLifecycleTimestamps: Map<String, Long>? = null
            private set

        constructor(
            messageId: String,
            peerId: String,
            multiaddresses: List<String>,
            advertisedServices: List<String>,
            timestamp: Long,
            ttl: Int,
            serviceLifecycleTimestamps: Map<String, Long>?
        ) : this(messageId, peerId, multiaddresses, advertisedServices, timestamp, ttl) {
            this.serviceLifecycleTimestamps =
                immutableServiceLifecycleTimestamps(serviceLifecycleTimestamps)
        }

        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_PEER_ANNOUNCE)
                put("messageId", messageId)
                put("peerId", peerId)
                put("multiaddresses", JSONArray(multiaddresses))
                put("advertisedServices", JSONArray(advertisedServices))
                put("timestamp", timestamp)
                put("ttl", ttl)
                serviceLifecycleTimestamps?.let { timestamps ->
                    put("serviceLifecycleTimestamps", serviceLifecycleTimestampsToJson(timestamps))
                }

                    freshness?.let { put("freshness", it.toJson()) }
                }
            }

        /**
         * Creates a copy with decremented TTL for re-broadcasting.
         */
        fun withDecrementedTtl(): PeerAnnouncement = PeerAnnouncement(
            messageId = messageId,
            peerId = peerId,
            multiaddresses = multiaddresses,
            advertisedServices = advertisedServices,
            timestamp = timestamp,
            ttl = ttl - 1,
            serviceLifecycleTimestamps = serviceLifecycleTimestamps
        ).withFreshness(freshness)

        /**
         * Returns true if this announcement should be re-broadcast.
         */
        fun shouldPropagate(): Boolean = ttl > 0

        /**
         * Converts to PeerInfo for storage in peer registry.
         */
        fun toPeerInfo(): PeerInfo = PeerInfo(
            peerId = peerId,
            multiaddresses = multiaddresses,
            advertisedServices = advertisedServices,
            serviceLifecycleTimestamps = serviceLifecycleTimestamps,
            freshness = freshness
        )

        companion object {
            fun fromJson(json: JSONObject): PeerAnnouncement {
                val multiaddrs = mutableListOf<String>()
                val addrsArray = json.getJSONArray("multiaddresses")
                for (i in 0 until addrsArray.length()) {
                    multiaddrs.add(addrsArray.getString(i))
                }

                val services = mutableListOf<String>()
                val servicesArray = json.optJSONArray("advertisedServices") ?: JSONArray()
                for (i in 0 until servicesArray.length()) {
                    services.add(servicesArray.getString(i))
                }

                return PeerAnnouncement(
                    messageId = json.getString("messageId"),
                    peerId = json.getString("peerId"),
                    multiaddresses = multiaddrs,
                    advertisedServices = services,
                    timestamp = json.getLong("timestamp"),
                    ttl = json.getInt("ttl"),
                    serviceLifecycleTimestamps = serviceLifecycleTimestampsFromJson(json),
                    freshness = PeerFreshness.fromJson(json.optJSONObject("freshness")),
                )
            }

            /**
             * Creates a PeerAnnouncement from PeerInfo.
             */
            fun fromPeerInfo(peerInfo: PeerInfo): PeerAnnouncement {
                return PeerAnnouncement(
                    messageId = nextMessageId(),
                    peerId = peerInfo.peerId,
                    multiaddresses = peerInfo.multiaddresses,
                    advertisedServices = peerInfo.advertisedServices,
                    timestamp = System.currentTimeMillis(),
                    ttl = DEFAULT_TTL,
                    serviceLifecycleTimestamps = peerInfo.serviceLifecycleTimestamps,
                    freshness = peerInfo.freshness
                )
            }
        }

        fun withDecrementedTtl(elapsedMillis: Long): PeerAnnouncement =
            withDecrementedTtl().withFreshness(freshness?.agedBy(elapsedMillis))

    }

    data class TldResolverAnnouncement(
        val messageId: String,
        val descriptor: SignedTldDescriptor,
        val timestamp: Long = System.currentTimeMillis(),
        val ttl: Int = DEFAULT_TTL
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_TLD_RESOLVER_ANNOUNCE)
                put("messageId", messageId)
                put("descriptor", descriptor.toJson())
                put("timestamp", timestamp)
                put("ttl", ttl)
            }
        }

        fun withDecrementedTtl(): TldResolverAnnouncement = copy(ttl = ttl - 1)

        fun shouldPropagate(): Boolean = ttl > 0

        companion object {
            fun fromDescriptor(descriptor: SignedTldDescriptor): TldResolverAnnouncement {
                return TldResolverAnnouncement(
                    messageId = nextMessageId(),
                    descriptor = descriptor
                )
            }

            fun fromJson(json: JSONObject): TldResolverAnnouncement {
                return TldResolverAnnouncement(
                    messageId = json.getString("messageId"),
                    descriptor = SignedTldDescriptor.fromJson(json.getJSONObject("descriptor")),
                    timestamp = json.getLong("timestamp"),
                    ttl = json.getInt("ttl")
                )
            }
        }
    }

    /**
     * Parses a gossip message from JSON.
     */
    fun parseMessage(json: JSONObject): Any {
        return when (val type = json.getString("type")) {
            TYPE_SERVICE_ANNOUNCE -> ServiceAnnouncement.fromJson(json)
            TYPE_SERVICE_WITHDRAW -> ServiceWithdrawal.fromJson(json)
            TYPE_SERVICE_QUERY -> ServiceQuery.fromJson(json)
            TYPE_SERVICE_QUERY_RESPONSE -> ServiceQueryResponse.fromJson(json)
            TYPE_PEER_EXCHANGE -> PeerExchange.fromJson(json)
            TYPE_PEER_ANNOUNCE -> PeerAnnouncement.fromJson(json)
            TYPE_RELAY_ANNOUNCE -> RelayProtocol.RelayAnnouncement.fromJson(json)
            TYPE_RELAY_WITHDRAW -> RelayProtocol.RelayWithdrawal.fromJson(json)
            TYPE_TLD_RESOLVER_ANNOUNCE -> TldResolverAnnouncement.fromJson(json)
            TYPE_LINK_STATE_ADVERTISEMENT -> LinkStateAdvertisement.fromJson(json)
            else -> throw IllegalArgumentException("Unknown gossip message type: $type")
        }
    }
}

/**
 * Information about a TURN server for NAT traversal.
 */
data class TurnServerInfo(
    val url: String,
    val username: String? = null,
    val credential: String? = null
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("url", url)
            username?.let { put("username", it) }
            credential?.let { put("credential", it) }
        }
    }

    companion object {
        fun fromJson(json: JSONObject): TurnServerInfo {
            return TurnServerInfo(
                url = json.getString("url"),
                username = json.optString("username", null),
                credential = json.optString("credential", null)
            )
        }
    }
}

/**
 * Compact service information for query responses.
 */
class ServiceInfo(
    val serviceUrl: String,
    val serviceIdentifier: String,
    val providerPeerId: String,
    val providerMultiaddresses: List<String>,
    val stunAddresses: List<String> = emptyList(),
    val turnServers: List<TurnServerInfo> = emptyList()
) {
    private var _freshness: PeerFreshness? = null
    val freshness: PeerFreshness? get() = _freshness

    constructor(
        serviceUrl: String,
        serviceIdentifier: String,
        providerPeerId: String,
        providerMultiaddresses: List<String>,
        stunAddresses: List<String>,
        turnServers: List<TurnServerInfo>,
        freshness: PeerFreshness?
    ) : this(serviceUrl, serviceIdentifier, providerPeerId, providerMultiaddresses, stunAddresses, turnServers) {
        _freshness = freshness
    }

    fun withFreshness(freshness: PeerFreshness?): ServiceInfo = copy().also { it._freshness = freshness }
    fun withFreshnessAgedBy(elapsedMillis: Long): ServiceInfo = withFreshness(freshness?.agedBy(elapsedMillis))

    operator fun component1(): String = serviceUrl
    operator fun component2(): String = serviceIdentifier
    operator fun component3(): String = providerPeerId
    operator fun component4(): List<String> = providerMultiaddresses
    operator fun component5(): List<String> = stunAddresses
    operator fun component6(): List<TurnServerInfo> = turnServers

    fun copy(
        serviceUrl: String = this.serviceUrl,
        serviceIdentifier: String = this.serviceIdentifier,
        providerPeerId: String = this.providerPeerId,
        providerMultiaddresses: List<String> = this.providerMultiaddresses,
        stunAddresses: List<String> = this.stunAddresses,
        turnServers: List<TurnServerInfo> = this.turnServers
    ): ServiceInfo {
        val result = ServiceInfo(serviceUrl, serviceIdentifier, providerPeerId, providerMultiaddresses, stunAddresses, turnServers, if (providerPeerId == this.providerPeerId) freshness else null)
        return result
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ServiceInfo) return false
        return serviceUrl == other.serviceUrl &&
            serviceIdentifier == other.serviceIdentifier &&
            providerPeerId == other.providerPeerId &&
            providerMultiaddresses == other.providerMultiaddresses &&
            stunAddresses == other.stunAddresses &&
            turnServers == other.turnServers && freshness == other.freshness
    }

    override fun hashCode(): Int {
        val legacyHash = peerFreshnessDataClassHash(serviceUrl, serviceIdentifier, providerPeerId, providerMultiaddresses, stunAddresses, turnServers)
        return if (freshness == null) legacyHash else 31 * legacyHash + freshness.hashCode()
    }

    override fun toString(): String {
        val legacy = "ServiceInfo(" + listOf("serviceUrl=$serviceUrl", "serviceIdentifier=$serviceIdentifier", "providerPeerId=$providerPeerId", "providerMultiaddresses=$providerMultiaddresses", "stunAddresses=$stunAddresses", "turnServers=$turnServers").joinToString(", ") + ")"
        return if (freshness == null) legacy else legacy.substring(0, legacy.length - 1) + ", freshness=$freshness)"
    }


    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("serviceUrl", serviceUrl)
            put("serviceIdentifier", serviceIdentifier)
            put("providerPeerId", providerPeerId)
            put("providerMultiaddresses", JSONArray(providerMultiaddresses))
            put("stunAddresses", JSONArray(stunAddresses))
            put("turnServers", JSONArray(turnServers.map { it.toJson() }))

            freshness?.let { put("freshness", it.toJson()) }
        }
    }

    companion object {
        fun fromJson(json: JSONObject): ServiceInfo {
            val multiaddrs = mutableListOf<String>()
            val addrsArray = json.getJSONArray("providerMultiaddresses")
            for (i in 0 until addrsArray.length()) {
                multiaddrs.add(addrsArray.getString(i))
            }

            val stunAddrs = mutableListOf<String>()
            val stunArray = json.optJSONArray("stunAddresses")
            if (stunArray != null) {
                for (i in 0 until stunArray.length()) {
                    stunAddrs.add(stunArray.getString(i))
                }
            }

            val turnServers = mutableListOf<TurnServerInfo>()
            val turnArray = json.optJSONArray("turnServers")
            if (turnArray != null) {
                for (i in 0 until turnArray.length()) {
                    turnServers.add(TurnServerInfo.fromJson(turnArray.getJSONObject(i)))
                }
            }

            return ServiceInfo(
                serviceUrl = json.getString("serviceUrl"),
                serviceIdentifier = json.getString("serviceIdentifier"),
                providerPeerId = json.getString("providerPeerId"),
                providerMultiaddresses = multiaddrs,
                stunAddresses = stunAddrs,
                turnServers = turnServers,
                freshness = PeerFreshness.fromJson(json.optJSONObject("freshness")),
                )
        }
    }
}

/**
 * Compact peer information for peer exchange.
 */
class PeerInfo(
    val peerId: String,
    val multiaddresses: List<String>,
    val advertisedServices: List<String>
) {
    /**
     * Provider-authored lifecycle timestamps for the services in [advertisedServices].
     *
     * `null` means the sending peer used the legacy catalog shape and supplied no lifecycle
     * information. A present map may omit individual services whose lifecycle is unknown. The
     * field remains outside the primary constructor because adding it there changes the
     * published three-argument `copy` and `copy$default` JVM methods even when `@JvmOverloads`
     * preserves the constructor. The value operations below are implemented explicitly so the
     * historical JVM methods remain available while the lifecycle map participates in copies,
     * equality, hashing, and destructuring.
     */
    var serviceLifecycleTimestamps: Map<String, Long>? = null
        private set

    constructor(
        peerId: String,
        multiaddresses: List<String>,
        advertisedServices: List<String>,
        serviceLifecycleTimestamps: Map<String, Long>?
    ) : this(peerId, multiaddresses, advertisedServices) {
        this.serviceLifecycleTimestamps =
            immutableServiceLifecycleTimestamps(serviceLifecycleTimestamps)
    }

    private var _freshness: PeerFreshness? = null

    val freshness: PeerFreshness?
        get() = _freshness

    constructor(
        peerId: String,
        multiaddresses: List<String>,
        advertisedServices: List<String>,
        serviceLifecycleTimestamps: Map<String, Long>? = null,
        freshness: PeerFreshness?
    ) : this(peerId, multiaddresses, advertisedServices, serviceLifecycleTimestamps) {
        this._freshness = freshness
    }

    fun withFreshness(freshness: PeerFreshness?): PeerInfo =
        PeerInfo(peerId, multiaddresses, advertisedServices, serviceLifecycleTimestamps, freshness)

    fun withFreshnessAgedBy(elapsedMillis: Long): PeerInfo =
        withFreshness(freshness?.agedBy(elapsedMillis))

    operator fun component1(): String = peerId

    operator fun component2(): List<String> = multiaddresses

    operator fun component3(): List<String> = advertisedServices

    operator fun component4(): Map<String, Long>? = serviceLifecycleTimestamps

    fun copy(
        peerId: String = this.peerId,
        multiaddresses: List<String> = this.multiaddresses,
        advertisedServices: List<String> = this.advertisedServices
    ): PeerInfo = PeerInfo(
        peerId = peerId,
        multiaddresses = multiaddresses,
        advertisedServices = advertisedServices,
        serviceLifecycleTimestamps = serviceLifecycleTimestamps,
        freshness = if (peerId == this.peerId) this.freshness else null
        )

    override fun equals(other: Any?): Boolean =
        this === other ||
            other is PeerInfo &&
            peerId == other.peerId &&
            multiaddresses == other.multiaddresses &&
            advertisedServices == other.advertisedServices &&
            serviceLifecycleTimestamps == other.serviceLifecycleTimestamps && freshness == other.freshness

    private fun legacyHashCode(): Int {
        var result = peerId.hashCode()
        result = 31 * result + multiaddresses.hashCode()
        result = 31 * result + advertisedServices.hashCode()
        result = 31 * result + (serviceLifecycleTimestamps?.hashCode() ?: 0)
        return result
    }

    private fun legacyToString(): String =
        "PeerInfo(peerId=$peerId, multiaddresses=$multiaddresses, " +
            "advertisedServices=$advertisedServices, " +
            "serviceLifecycleTimestamps=$serviceLifecycleTimestamps)"

    override fun hashCode(): Int {
        val legacyHash = legacyHashCode()
        val evidence = freshness
        return if (evidence == null) legacyHash else 31 * legacyHash + evidence.hashCode()
    }

    override fun toString(): String {
        val legacyText = legacyToString()
        return if (freshness == null) legacyText else legacyText.dropLast(1) + ", freshness=$freshness)"
    }

    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("peerId", peerId)
            put("multiaddresses", JSONArray(multiaddresses))
            put("advertisedServices", JSONArray(advertisedServices))
            freshness?.let { put("freshness", it.toJson()) }
            serviceLifecycleTimestamps?.let { timestamps ->
                put(
                    "serviceLifecycleTimestamps",
                    JSONObject().apply {
                        timestamps.toSortedMap().forEach { (serviceIdentifier, timestamp) ->
                            put(serviceIdentifier, timestamp)
                        }
                    }
                )
            }
        }
    }

    companion object {
        fun fromJson(json: JSONObject): PeerInfo {
            val multiaddrs = mutableListOf<String>()
            val addrsArray = json.getJSONArray("multiaddresses")
            for (i in 0 until addrsArray.length()) {
                multiaddrs.add(addrsArray.getString(i))
            }

            val services = mutableListOf<String>()
            val servicesArray = json.optJSONArray("advertisedServices") ?: JSONArray()
            for (i in 0 until servicesArray.length()) {
                services.add(servicesArray.getString(i))
            }

            val serviceLifecycleTimestamps =
                json.optJSONObject("serviceLifecycleTimestamps")?.let { timestampsJson ->
                    buildMap {
                        timestampsJson.keys().forEach { serviceIdentifier ->
                            put(serviceIdentifier, timestampsJson.getLong(serviceIdentifier))
                        }
                    }
                }

            return PeerInfo(
                peerId = json.getString("peerId"),
                multiaddresses = multiaddrs,
                advertisedServices = services,
                serviceLifecycleTimestamps = serviceLifecycleTimestamps,
                freshness = PeerFreshness.fromJson(json.optJSONObject("freshness"))
            )
        }
    }
}

internal fun immutableServiceLifecycleTimestamps(
    timestamps: Map<String, Long>?
): Map<String, Long>? = timestamps?.let {
    Collections.unmodifiableMap(LinkedHashMap(it))
}

internal fun serviceLifecycleTimestampsToJson(timestamps: Map<String, Long>): JSONObject =
    JSONObject().apply {
        timestamps.toSortedMap().forEach { (serviceIdentifier, timestamp) ->
            put(serviceIdentifier, timestamp)
        }
    }

internal fun serviceLifecycleTimestampsFromJson(json: JSONObject): Map<String, Long>? =
    json.optJSONObject("serviceLifecycleTimestamps")?.let { timestampsJson ->
        buildMap {
            timestampsJson.keys().forEach { serviceIdentifier ->
                put(serviceIdentifier, timestampsJson.getLong(serviceIdentifier))
            }
        }
    }

private const val PEER_EXCHANGE_RETAINED_OBJECT_BYTES = 64L
private const val PEER_EXCHANGE_RETAINED_COLLECTION_BYTES = 64L
private const val PEER_EXCHANGE_RETAINED_LIST_ENTRY_BYTES = 16L
// A tree entry needs up to 96 bytes with uncompressed references. Another 64 bytes per ID
// covers short-string alignment, shared headers, and collision-driven table growth to 64 slots
// before the load-factor estimate would select it (at most 48 extra eight-byte slots by the
// first 11-entry tree). Ordinary entries are smaller and therefore have still more headroom.
private const val PEER_EXCHANGE_RETAINED_HASH_ENTRY_BYTES = 160L
private const val PEER_EXCHANGE_RETAINED_HASH_TABLE_SLOT_BYTES = 8L
private const val PEER_EXCHANGE_RETAINED_STRING_OBJECT_BYTES = 40L
private const val PEER_EXCHANGE_RETAINED_LONG_OBJECT_BYTES = 24L

private fun saturatedRetainedByteAdd(left: Long, right: Long): Long =
    if (right >= Long.MAX_VALUE - left) Long.MAX_VALUE else left + right

private fun retainedStringBytes(value: String): Long =
    saturatedRetainedByteAdd(
        PEER_EXCHANGE_RETAINED_STRING_OBJECT_BYTES,
        value.length.toLong() * 2L
    )

private fun retainedStringListBytes(values: List<String>): Long {
    var bytes = saturatedRetainedByteAdd(
        PEER_EXCHANGE_RETAINED_COLLECTION_BYTES,
        values.size.toLong() * PEER_EXCHANGE_RETAINED_LIST_ENTRY_BYTES
    )
    values.forEach { value ->
        bytes = saturatedRetainedByteAdd(bytes, retainedStringBytes(value))
    }
    return bytes
}

private fun retainedStringSetStorageBytes(size: Int): Long {
    if (size <= 0) return PEER_EXCHANGE_RETAINED_COLLECTION_BYTES
    val requiredSlots = saturatedRetainedByteAdd(size.toLong() * 4L, 2L) / 3L
    var tableCapacity = 1L
    while (tableCapacity < requiredSlots && tableCapacity < (1L shl 30)) {
        tableCapacity = tableCapacity shl 1
    }
    var bytes = PEER_EXCHANGE_RETAINED_COLLECTION_BYTES
    bytes = saturatedRetainedByteAdd(
        bytes,
        size.toLong() * PEER_EXCHANGE_RETAINED_HASH_ENTRY_BYTES
    )
    return saturatedRetainedByteAdd(
        bytes,
        tableCapacity * PEER_EXCHANGE_RETAINED_HASH_TABLE_SLOT_BYTES
    )
}

private fun retainedStringLongMapBytes(values: Map<String, Long>): Long {
    var bytes = retainedStringSetStorageBytes(values.size)
    values.keys.forEach { key ->
        bytes = saturatedRetainedByteAdd(bytes, retainedStringBytes(key))
        bytes = saturatedRetainedByteAdd(bytes, PEER_EXCHANGE_RETAINED_LONG_OBJECT_BYTES)
    }
    return bytes
}

/**
 * Conservative estimate of the object graph retained by one parsed PeerExchange request.
 *
 * The wire frame and parser have independent per-frame limits. This estimate covers the Kotlin
 * data objects and UTF-16 strings that remain reachable while request-side apply is queued or
 * running; compact strings on newer JVMs therefore make this intentionally conservative.
 */
internal fun GossipProtocol.PeerExchange.estimatedRetainedBytes(): Int {
    var bytes = PEER_EXCHANGE_RETAINED_OBJECT_BYTES
    fun add(value: Long) {
        bytes = saturatedRetainedByteAdd(bytes, value)
    }

    add(retainedStringBytes(id))
    add(PEER_EXCHANGE_RETAINED_COLLECTION_BYTES)
    add(peers.size.toLong() * PEER_EXCHANGE_RETAINED_LIST_ENTRY_BYTES)
    peers.forEach { peer ->
        add(PEER_EXCHANGE_RETAINED_OBJECT_BYTES)
        add(retainedStringBytes(peer.peerId))
        add(retainedStringListBytes(peer.multiaddresses))
        add(retainedStringListBytes(peer.advertisedServices))
        peer.serviceLifecycleTimestamps?.let { timestamps ->
            add(retainedStringLongMapBytes(timestamps))
        }
        peer.freshness?.let { freshness ->
            add(PEER_EXCHANGE_RETAINED_OBJECT_BYTES)
            add(retainedStringBytes(freshness.observerPeerId))
            add(retainedStringBytes(freshness.observationId))
        }
    }
    requestedResponsePeerIds?.let { requestedIds ->
        add(retainedStringSetStorageBytes(requestedIds.size))
        requestedIds.forEach { requestedId -> add(retainedStringBytes(requestedId)) }
    }

    return bytes.coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()
}

/**
 * Tracks seen gossip messages to prevent duplicate processing and loops.
 *
 * Messages are considered "seen" for the duration of the TTL. After the TTL
 * expires, the message is no longer considered seen and can be re-recorded.
 * This prevents indefinite deduplication while still catching rapid duplicates.
 */
class GossipMessageTracker(
    private val maxSize: Int = 10000,
    private val ttlMs: Long = 5 * 60 * 1000, // 5 minutes
    private val clock: Clock = SystemClock()
) {
    private val seenMessages = LinkedHashMap<String, Long>()

    // Track when we last ran cleanup to avoid running it on every operation
    @Volatile
    private var lastCleanupTime = 0L
    private val cleanupIntervalMs = ttlMs / 2  // Run cleanup at half the TTL interval

    /**
     * Records a message as seen.
     * @return true if this is a new message (or expired), false if already seen within TTL
     */
    @Synchronized
    fun recordMessage(messageId: String): Boolean {
        val now = clock.currentTimeMillis()

        val existingTimestamp = seenMessages[messageId]
        if (existingTimestamp != null) {
            if (now - existingTimestamp < ttlMs) {
                return false
            }
            // Re-recording an expired ID makes it the newest entry for oldest-first eviction.
            seenMessages.remove(messageId)
        }

        seenMessages[messageId] = now
        maybeCleanup(now)
        return true
    }

    /**
     * Checks if a message has been seen within the TTL window.
     *
     * Returns true only if the message was recorded AND the recording
     * is still within the TTL window. Expired entries return false.
     */
    @Synchronized
    fun hasSeen(messageId: String): Boolean {
        val timestamp = seenMessages[messageId] ?: return false
        val now = clock.currentTimeMillis()

        if (now - timestamp >= ttlMs) {
            // Entry is expired - optionally clean it up and return false
            seenMessages.remove(messageId)
            return false
        }
        return true
    }

    /**
     * Run cleanup periodically based on time, not just size.
     * This ensures expired entries are removed even when the map is small.
     */
    private fun maybeCleanup(now: Long) {
        if (now - lastCleanupTime > cleanupIntervalMs) {
            cleanOldEntries(now)
            lastCleanupTime = now
        }
        while (seenMessages.size > maxSize) {
            val oldestMessageId = seenMessages.entries.firstOrNull()?.key ?: break
            seenMessages.remove(oldestMessageId)
        }
    }

    private fun cleanOldEntries(now: Long) {
        val cutoff = now - ttlMs
        seenMessages.entries.removeIf { it.value <= cutoff }
    }
}

/**
 * Handler interface for processing gossip protocol messages.
 */
interface GossipHandler {
    /**
     * Called when a service announcement is received.
     */
    fun onServiceAnnouncement(announcement: GossipProtocol.ServiceAnnouncement)

    /**
     * Called when a service withdrawal is received.
     */
    fun onServiceWithdrawal(withdrawal: GossipProtocol.ServiceWithdrawal)

    /**
     * Called when a service query is received.
     * @return List of matching services
     */
    fun onServiceQuery(query: GossipProtocol.ServiceQuery): List<ServiceInfo>

    /**
     * Called when peers should be exchanged.
     * @return List of known peers to share
     */
    fun onPeerExchangeRequest(): List<PeerInfo>

    /**
     * Called when new peers are received from peer exchange.
     */
    fun onPeersReceived(peers: List<PeerInfo>)

    fun onPeersReceived(peers: List<PeerInfo>, recommenderPeerId: String) {
        onPeersReceived(peers)
    }

    fun onAuthenticatedInteraction(peerId: String, severity: PeerInteractionSeverity) {}

    fun authenticatedInteractionSeverity(message: Any): PeerInteractionSeverity =
        PeerInteractionSeverity.CLEAN

    /**
     * Called when a peer has registered with the relay.
     * Unlike onPeersReceived, this should ALWAYS send local service announcements to the peer,
     * regardless of whether the peer is already in the registry. This is essential because
     * the peer may have been discovered through gossip before registering, but only after
     * registration can they reliably receive messages through the relay connection.
     */
    fun onPeerRegisteredWithRelay(peer: PeerInfo) {}

    /**
     * Called when the relay confirms a registered peer is still alive via a successful
     * keepalive ping/pong exchange. This fires each time the relay receives a keepalive
     * from a registered peer, typically every 15 seconds. The handler should call
     * recordSuccess() on the peer's observation log to keep the staleness filter fresh.
     */
    fun onPeerKeepaliveSuccess(peerId: String) {}

    /**
     * Called when a peer announcement is received.
     * The handler should add the peer to registry and re-broadcast if TTL > 0.
     */
    fun onPeerAnnouncement(announcement: GossipProtocol.PeerAnnouncement)

    /**
     * Called when a relay announcement is received.
     * Relays are peers with public IPs that can forward requests to NAT-ed peers.
     */
    fun onRelayAnnouncement(announcement: RelayProtocol.RelayAnnouncement) {}

    /**
     * Called when a relay withdrawal is received.
     */
    fun onRelayWithdrawal(withdrawal: RelayProtocol.RelayWithdrawal) {}

    fun onTldResolverAnnouncement(announcement: GossipProtocol.TldResolverAnnouncement) {}

    fun onTldResolverQuery(): List<GossipProtocol.TldResolverAnnouncement> = emptyList()

    /**
     * Called when a link-state advertisement is received.
     */
    fun onLinkStateAdvertisement(advertisement: LinkStateAdvertisement) {}

    /**
     * Broadcasts a best-effort gossip message to all known peers.
     * This allows components like RelayService to send gossip messages
     * through the network without needing direct access to peer connections.
     * A counted peer means that the frame was handed to a local stream write; this method does not
     * wait for remote parsing or acknowledgement. A one-way frame can therefore be lost if the
     * stream is closed immediately after the local handoff. Gossip is repairable by later
     * announcements or exchanges and callers must not treat the count as durable delivery.
     *
     * @param message The JSON message to broadcast
     * @return The number of peers the message was sent to
     */
    fun broadcastGossipMessage(message: JSONObject): Int = 0
}

private fun AbstractMethodError.isMissingGossipHandlerDefault(methodName: String): Boolean {
    val detail = message ?: return false
    return detail.contains("foundation.url.protocol.GossipHandler") &&
        detail.contains(" $methodName(")
}

// Kotlin's historical DefaultImpls mode emits interface defaults as abstract JVM methods plus
// static helpers. Implementations compiled before a default was added therefore need these three
// explicit bridges when they run with a newer protocol JAR.
internal fun GossipHandler.classifyAuthenticatedInteractionCompatible(
    message: Any,
): PeerInteractionSeverity = try {
    authenticatedInteractionSeverity(message)
} catch (failure: AbstractMethodError) {
    if (!failure.isMissingGossipHandlerDefault("authenticatedInteractionSeverity")) throw failure
    PeerInteractionSeverity.CLEAN
}

internal fun GossipHandler.recordAuthenticatedInteractionCompatible(
    peerId: String,
    severity: PeerInteractionSeverity,
) {
    try {
        onAuthenticatedInteraction(peerId, severity)
    } catch (failure: AbstractMethodError) {
        if (!failure.isMissingGossipHandlerDefault("onAuthenticatedInteraction")) throw failure
        // This method was added with an empty default. Historical handlers require no action.
    }
}

internal fun GossipHandler.receivePeersCompatible(
    peers: List<PeerInfo>,
    recommenderPeerId: String,
) {
    try {
        onPeersReceived(peers, recommenderPeerId)
    } catch (failure: AbstractMethodError) {
        if (!failure.isMissingGossipHandlerDefault("onPeersReceived")) throw failure
        onPeersReceived(peers)
    }
}

/**
 * Describes gossip delivered to a relay server by one of its registered clients.
 * [registeredClientFanoutOwnedByRelay] is true when RelayService owns the decision and transport
 * for registered-client fan-out, so an aware handler must not duplicate it. Ownership does not
 * promise delivery of a message that RelayService rejects after handler-side validation, such as
 * an unaccepted TLD resolver announcement.
 */
data class GossipIngressMetadata(
    val senderPeerId: String,
    val ingressRelayPeerId: String,
    val registeredClientFanoutOwnedByRelay: Boolean
)

/**
 * Optional capability for handlers that need relay-ingress ownership and exclusion metadata.
 * Keeping this separate from [GossipHandler] preserves source and binary compatibility.
 */
interface RelayIngressGossipHandler : GossipHandler {
    fun onServiceAnnouncement(
        announcement: GossipProtocol.ServiceAnnouncement,
        ingress: GossipIngressMetadata
    ) = onServiceAnnouncement(announcement)

    fun onServiceWithdrawal(
        withdrawal: GossipProtocol.ServiceWithdrawal,
        ingress: GossipIngressMetadata
    ) = onServiceWithdrawal(withdrawal)

    fun onPeerAnnouncement(
        announcement: GossipProtocol.PeerAnnouncement,
        ingress: GossipIngressMetadata
    ) = onPeerAnnouncement(announcement)

    fun onTldResolverAnnouncement(
        announcement: GossipProtocol.TldResolverAnnouncement,
        ingress: GossipIngressMetadata
    ) = onTldResolverAnnouncement(announcement)
}

/**
 * Optional [GossipHandler] capability for constructing a bounded peer-exchange response without
 * first materializing the full shareable peer view. Keeping this separate from [GossipHandler]
 * preserves binary compatibility for handlers compiled before response projections existed.
 */
interface ProjectedPeerExchangeHandler : GossipHandler {
    /**
     * @param requestedPeerIds peer records requested by the remote node and submitted in its
     * request, plus the Noise-authenticated responder's own peer ID when explicitly requested
     * @param requesterPeerId authenticated libp2p identity of the node that opened the request stream
     */
    fun onPeerExchangeRequest(requestedPeerIds: Set<String>, requesterPeerId: String): List<PeerInfo>
}
