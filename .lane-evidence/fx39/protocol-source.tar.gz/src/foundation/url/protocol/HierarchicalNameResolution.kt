package foundation.url.protocol

import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import org.json.JSONArray
import org.json.JSONObject
import okio.FileSystem
import okio.Path
import java.util.Base64

enum class NameDelegationMode {
    VERIFIED,
    FREE_TO_CLAIM
}

data class HierarchicalSigningKey(
    val publicKeyBase64: String,
    val privateSeedBase64: String
) {
    fun sign(payload: String): String {
        val seed = Base64.getDecoder().decode(privateSeedBase64)
        val signer = Ed25519Signer()
        signer.init(true, Ed25519PrivateKeyParameters(seed, 0))
        val bytes = payload.toByteArray(Charsets.UTF_8)
        signer.update(bytes, 0, bytes.size)
        return Base64.getEncoder().encodeToString(signer.generateSignature())
    }
}

object HierarchicalNameKeys {
    fun keyPair(seedText: String): HierarchicalSigningKey {
        val seed = java.security.MessageDigest.getInstance("SHA-256")
            .digest(seedText.toByteArray(Charsets.UTF_8))
        val privateKey = Ed25519PrivateKeyParameters(seed, 0)
        val publicKey = privateKey.generatePublicKey().encoded
        return HierarchicalSigningKey(
            publicKeyBase64 = Base64.getEncoder().encodeToString(publicKey),
            privateSeedBase64 = Base64.getEncoder().encodeToString(seed)
        )
    }

    fun peerId(seedText: String): String = UrlProtocol.peerIdFromSeed(seedText)
}

data class SignedTldDescriptor(
    val tld: String,
    val mode: NameDelegationMode,
    val childAuthorityPublicKeys: List<String> = emptyList(),
    val authorizedPeerIds: List<String> = emptyList(),
    val version: Long = 1,
    val signatureBase64: String
) {
    constructor(
        tld: String,
        mode: NameDelegationMode,
        childAuthorityPublicKeys: List<String> = emptyList(),
        authorizedPeerIds: List<String> = emptyList(),
        signatureBase64: String
    ) : this(tld, mode, childAuthorityPublicKeys, authorizedPeerIds, 1, signatureBase64)

    fun canonicalPayload(): String = canonicalTldPayload(tld, mode, childAuthorityPublicKeys, authorizedPeerIds, version)

    fun verifiesWith(publicKeyBase64: String): Boolean {
        return verifyEd25519(publicKeyBase64, canonicalPayload(), signatureBase64)
    }

    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("tld", tld)
            put("mode", mode.name)
            put("childAuthorityPublicKeys", JSONArray(childAuthorityPublicKeys))
            put("authorizedPeerIds", JSONArray(authorizedPeerIds))
            put("version", version)
            put("signatureBase64", signatureBase64)
        }
    }

    companion object {
        fun create(
            tld: String,
            mode: NameDelegationMode,
            childAuthorityPublicKeys: List<String> = emptyList(),
            authorizedPeerIds: List<String> = emptyList(),
            version: Long = 1,
            signer: HierarchicalSigningKey
        ): SignedTldDescriptor {
            val payload = canonicalTldPayload(tld, mode, childAuthorityPublicKeys, authorizedPeerIds, version)
            return SignedTldDescriptor(
                tld = tld,
                mode = mode,
                childAuthorityPublicKeys = childAuthorityPublicKeys,
                authorizedPeerIds = authorizedPeerIds,
                version = version,
                signatureBase64 = signer.sign(payload)
            )
        }

        fun fromJson(json: JSONObject): SignedTldDescriptor {
            return SignedTldDescriptor(
                tld = json.getString("tld"),
                mode = NameDelegationMode.valueOf(json.getString("mode")),
                childAuthorityPublicKeys = jsonArrayToStrings(json.optJSONArray("childAuthorityPublicKeys")),
                authorizedPeerIds = jsonArrayToStrings(json.optJSONArray("authorizedPeerIds")),
                version = json.optLong("version", 0),
                signatureBase64 = json.getString("signatureBase64")
            )
        }
    }
}

data class SignedNameDelegationDescriptor(
    val parentName: String,
    val childSegment: String,
    val mode: NameDelegationMode,
    val childAuthorityPublicKeys: List<String> = emptyList(),
    val authorizedPeerIds: List<String> = emptyList(),
    val version: Long = 1,
    val signatureBase64: String
) {
    constructor(
        parentName: String,
        childSegment: String,
        mode: NameDelegationMode,
        childAuthorityPublicKeys: List<String> = emptyList(),
        authorizedPeerIds: List<String> = emptyList(),
        signatureBase64: String
    ) : this(parentName, childSegment, mode, childAuthorityPublicKeys, authorizedPeerIds, 1, signatureBase64)

    val fullName: String
        get() = if (parentName.isBlank()) childSegment else "$parentName.$childSegment"

    fun canonicalPayload(): String = canonicalDelegationPayload(
        parentName,
        childSegment,
        mode,
        childAuthorityPublicKeys,
        authorizedPeerIds,
        version
    )

    fun verifiesWithAny(publicKeysBase64: Collection<String>): Boolean {
        return publicKeysBase64.any { verifyEd25519(it, canonicalPayload(), signatureBase64) }
    }

    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("parentName", parentName)
            put("childSegment", childSegment)
            put("mode", mode.name)
            put("childAuthorityPublicKeys", JSONArray(childAuthorityPublicKeys))
            put("authorizedPeerIds", JSONArray(authorizedPeerIds))
            put("version", version)
            put("signatureBase64", signatureBase64)
        }
    }

    companion object {
        fun create(
            parentName: String,
            childSegment: String,
            mode: NameDelegationMode,
            childAuthorityPublicKeys: List<String> = emptyList(),
            authorizedPeerIds: List<String> = emptyList(),
            version: Long = 1,
            signer: HierarchicalSigningKey
        ): SignedNameDelegationDescriptor {
            val payload = canonicalDelegationPayload(
                parentName,
                childSegment,
                mode,
                childAuthorityPublicKeys,
                authorizedPeerIds,
                version
            )
            return SignedNameDelegationDescriptor(
                parentName = parentName,
                childSegment = childSegment,
                mode = mode,
                childAuthorityPublicKeys = childAuthorityPublicKeys,
                authorizedPeerIds = authorizedPeerIds,
                version = version,
                signatureBase64 = signer.sign(payload)
            )
        }

        fun fromJson(json: JSONObject): SignedNameDelegationDescriptor {
            return SignedNameDelegationDescriptor(
                parentName = json.getString("parentName"),
                childSegment = json.getString("childSegment"),
                mode = NameDelegationMode.valueOf(json.getString("mode")),
                childAuthorityPublicKeys = jsonArrayToStrings(json.optJSONArray("childAuthorityPublicKeys")),
                authorizedPeerIds = jsonArrayToStrings(json.optJSONArray("authorizedPeerIds")),
                version = json.optLong("version", 0),
                signatureBase64 = json.getString("signatureBase64")
            )
        }
    }
}

data class NameAuthorizationDecision(
    val mode: NameDelegationMode,
    val authorizedPeerIds: List<String> = emptyList(),
    val name: String
) {
    fun accepts(peerId: String): Boolean = mode == NameDelegationMode.FREE_TO_CLAIM || peerId in authorizedPeerIds
}

interface HierarchicalNameResolver {
    fun resolve(serviceIdentifier: String): NameAuthorizationDecision
    fun addTldDescriptor(descriptor: SignedTldDescriptor): Boolean = false
    fun getTldDescriptors(): List<SignedTldDescriptor> = emptyList()
    fun addDelegationDescriptor(descriptor: SignedNameDelegationDescriptor): Boolean = false
    fun getDelegationDescriptors(): List<SignedNameDelegationDescriptor> = emptyList()
    fun attachTldPersistence(filesystem: FileSystem, directory: Path) {}
    fun saveTldDescriptors() {}
}

data class NameResolutionConfig(
    val rootPublicKey: String = PRODUCTION_TLD_ROOT_PUBLIC_KEY,
    val resolver: HierarchicalNameResolver = SignedDelegationResolver(rootPublicKey)
)

const val PRODUCTION_TLD_ROOT_PUBLIC_KEY: String = "jePrYpHqt/WkUEJ9BmUmOaaQ1YBvHgK33lgIO0wo9D4="

class SignedDelegationResolver(
    private val rootPublicKey: String = PRODUCTION_TLD_ROOT_PUBLIC_KEY,
    tldDescriptors: List<SignedTldDescriptor> = emptyList(),
    delegationDescriptors: List<SignedNameDelegationDescriptor> = emptyList(),
    hardCodedPinnedTldDescriptors: List<SignedTldDescriptor> = emptyList(),
    private val maxTldDescriptors: Int = 1024,
    private val maxDelegationDescriptors: Int = 4096
) : HierarchicalNameResolver {
    // Unknown TLDs intentionally remain FREE_TO_CLAIM for legacy coexistence.
    // Operators close the pre-propagation window for a verified TLD by shipping
    // it in hardCodedPinnedTldDescriptors or by relying on persistence after the
    // first valid root-signed VERIFIED descriptor is seen.
    private val lock = Any()
    private val tlds = linkedMapOf<String, SignedTldDescriptor>()
    private val delegations = linkedMapOf<String, SignedNameDelegationDescriptor>()
    private val hardPinnedTlds = mutableSetOf<String>()
    private var persistenceFilesystem: FileSystem? = null
    private var persistenceDirectory: Path? = null

    init {
        hardCodedPinnedTldDescriptors.forEach {
            if (addTldDescriptor(it)) hardPinnedTlds.add(it.tld)
        }
        tldDescriptors.forEach { addTldDescriptor(it) }
        delegationDescriptors.forEach { addDelegationDescriptor(it) }
    }

    override fun resolve(serviceIdentifier: String): NameAuthorizationDecision {
        val parsed = parseServiceIdentifierForResolution(serviceIdentifier)
        if (parsed.segments.isEmpty()) {
            return NameAuthorizationDecision(NameDelegationMode.FREE_TO_CLAIM, name = serviceIdentifier)
        }

        val tld = synchronized(lock) { tlds[tldLookupKey(parsed.segments.first())] }
            ?: return NameAuthorizationDecision(NameDelegationMode.FREE_TO_CLAIM, name = serviceIdentifier)

        if (!parsed.isCanonical) {
            return NameAuthorizationDecision(NameDelegationMode.VERIFIED, emptyList(), serviceIdentifier)
        }

        if (tld.mode == NameDelegationMode.FREE_TO_CLAIM) {
            return NameAuthorizationDecision(NameDelegationMode.FREE_TO_CLAIM, name = serviceIdentifier)
        }

        var currentName = tld.tld
        var authorityKeys = tld.childAuthorityPublicKeys
        var authorizedPeerIds = tld.authorizedPeerIds
        var mode = tld.mode

        for (i in 1 until parsed.segments.size) {
            if (mode == NameDelegationMode.FREE_TO_CLAIM) {
                return NameAuthorizationDecision(NameDelegationMode.FREE_TO_CLAIM, name = serviceIdentifier)
            }
            val childName = "$currentName.${parsed.segments[i]}"
            val descriptor = synchronized(lock) { delegations[childName] }
                ?: return NameAuthorizationDecision(NameDelegationMode.VERIFIED, emptyList(), serviceIdentifier)
            if (!descriptor.verifiesWithAny(authorityKeys)) {
                return NameAuthorizationDecision(NameDelegationMode.VERIFIED, emptyList(), serviceIdentifier)
            }
            mode = descriptor.mode
            authorityKeys = descriptor.childAuthorityPublicKeys
            authorizedPeerIds = descriptor.authorizedPeerIds
            currentName = childName
        }

        return NameAuthorizationDecision(mode, authorizedPeerIds, serviceIdentifier)
    }

    override fun addTldDescriptor(descriptor: SignedTldDescriptor): Boolean {
        synchronized(lock) {
            if (!isCanonicalSingleSegment(descriptor.tld) || descriptor.version <= 0 || !descriptor.verifiesWith(rootPublicKey)) {
                return false
            }
            val existing = tlds[descriptor.tld]
            if (existing != null) {
                if (descriptor.version <= existing.version) return false
                if (existing.mode == NameDelegationMode.VERIFIED && descriptor.mode == NameDelegationMode.FREE_TO_CLAIM) return false
            }
            tlds.remove(descriptor.tld)
            tlds[descriptor.tld] = descriptor
            evictTldsIfNeeded()
        }
        saveTldDescriptors()
        return true
    }

    override fun getTldDescriptors(): List<SignedTldDescriptor> = synchronized(lock) { tlds.values.sortedBy { it.tld } }

    override fun addDelegationDescriptor(descriptor: SignedNameDelegationDescriptor): Boolean {
        synchronized(lock) {
            if (!isCanonicalName(descriptor.parentName) || !isCanonicalSingleSegment(descriptor.childSegment) || descriptor.version <= 0) {
                return false
            }
            val existing = delegations[descriptor.fullName]
            if (existing != null && descriptor.version <= existing.version) return false
            delegations.remove(descriptor.fullName)
            delegations[descriptor.fullName] = descriptor
            evictDelegationsIfNeeded()
        }
        return true
    }

    override fun getDelegationDescriptors(): List<SignedNameDelegationDescriptor> = synchronized(lock) {
        delegations.values.sortedBy { it.fullName }
    }

    override fun attachTldPersistence(filesystem: FileSystem, directory: Path) {
        synchronized(lock) {
            persistenceFilesystem = filesystem
            persistenceDirectory = directory
        }
        loadPersistedTlds()
    }

    override fun saveTldDescriptors() {
        val filesystem = persistenceFilesystem ?: return
        val directory = persistenceDirectory ?: return
        val descriptors = getTldDescriptors()
        try {
            filesystem.createDirectories(directory)
            filesystem.write(directory / TLD_PERSISTENCE_FILE) {
                writeUtf8(JSONArray(descriptors.map { it.toJson() }).toString(2))
            }
        } catch (_: Exception) {
            // Persistence is best-effort; gossip pinning still holds in memory for this process.
        }
    }

    private fun loadPersistedTlds() {
        val filesystem = persistenceFilesystem ?: return
        val directory = persistenceDirectory ?: return
        val file = directory / TLD_PERSISTENCE_FILE
        try {
            if (!filesystem.exists(file)) return
            val array = JSONArray(filesystem.read(file) { readUtf8() })
            for (i in 0 until array.length()) {
                addTldDescriptor(SignedTldDescriptor.fromJson(array.getJSONObject(i)))
            }
        } catch (_: Exception) {
            // Malformed persisted pin files are ignored so resolver construction cannot crash callers.
        }
    }

    private fun evictTldsIfNeeded() {
        while (tlds.size > maxTldDescriptors) {
            val evictable = tlds.keys.firstOrNull { it !in hardPinnedTlds } ?: break
            tlds.remove(evictable)
        }
    }

    private fun evictDelegationsIfNeeded() {
        while (delegations.size > maxDelegationDescriptors) {
            delegations.remove(delegations.keys.first())
        }
    }

    private companion object {
        const val TLD_PERSISTENCE_FILE = "known-tld-descriptors.json"
    }
}

private fun canonicalTldPayload(
    tld: String,
    mode: NameDelegationMode,
    childAuthorityPublicKeys: List<String>,
    authorizedPeerIds: List<String>,
    version: Long
): String {
    return "tld=$tld\nmode=${mode.name}\nversion=$version\nchildAuthorityPublicKeys=${childAuthorityPublicKeys.sorted().joinToString(",")}\nauthorizedPeerIds=${authorizedPeerIds.sorted().joinToString(",")}"
}

private fun canonicalDelegationPayload(
    parentName: String,
    childSegment: String,
    mode: NameDelegationMode,
    childAuthorityPublicKeys: List<String>,
    authorizedPeerIds: List<String>,
    version: Long
): String {
    return "parentName=$parentName\nchildSegment=$childSegment\nmode=${mode.name}\nversion=$version\nchildAuthorityPublicKeys=${childAuthorityPublicKeys.sorted().joinToString(",")}\nauthorizedPeerIds=${authorizedPeerIds.sorted().joinToString(",")}"
}

private fun verifyEd25519(publicKeyBase64: String, payload: String, signatureBase64: String): Boolean {
    return try {
        val publicKeyBytes = Base64.getDecoder().decode(publicKeyBase64)
        val signature = Base64.getDecoder().decode(signatureBase64)
        val verifier = Ed25519Signer()
        verifier.init(false, Ed25519PublicKeyParameters(publicKeyBytes, 0))
        val payloadBytes = payload.toByteArray(Charsets.UTF_8)
        verifier.update(payloadBytes, 0, payloadBytes.size)
        verifier.verifySignature(signature)
    } catch (_: Exception) {
        false
    }
}

private fun jsonArrayToStrings(array: JSONArray?): List<String> {
    if (array == null) return emptyList()
    return (0 until array.length()).map { array.getString(it) }
}

private data class ParsedServiceIdentifier(val segments: List<String>, val isCanonical: Boolean)

private fun parseServiceIdentifierForResolution(serviceIdentifier: String): ParsedServiceIdentifier {
    val rawSegments = serviceIdentifier.split(".")
    val nonEmpty = rawSegments.filter { it.isNotBlank() }
    if (nonEmpty.isEmpty()) return ParsedServiceIdentifier(emptyList(), false)
    val canonical = nonEmpty.joinToString(".")
    return ParsedServiceIdentifier(
        segments = nonEmpty,
        isCanonical = serviceIdentifier == canonical && nonEmpty.all { isCanonicalSingleSegment(it) }
    )
}

private fun isCanonicalName(name: String): Boolean {
    if (name.isBlank()) return true
    val parsed = parseServiceIdentifierForResolution(name)
    return parsed.segments.isNotEmpty() && parsed.isCanonical
}

/**
 * Maps a top-level segment onto the key its TLD descriptor would be stored under.
 *
 * `addTldDescriptor` admits canonical segments only, so the descriptor store is keyed entirely by
 * canonical segments. Looking a top-level segment up verbatim therefore misses for every
 * non-canonical spelling of a known TLD, and the miss is answered as "unknown TLD" — which is
 * `FREE_TO_CLAIM` and authorizes every peer — before [SignedDelegationResolver.resolve] reaches the
 * guard that rejects non-canonical identifiers. Folding the two ways a segment can be spelled
 * non-canonically without changing which TLD it names, letter case and surrounding whitespace,
 * lets that guard run. Segments that differ from a known TLD in any other way, such as embedded
 * whitespace, name a different TLD and keep missing the store.
 *
 * This only ever turns a `FREE_TO_CLAIM` answer into a rejection: a segment that folds onto a
 * different string is not canonical, so [SignedDelegationResolver.resolve] rejects it on the very
 * next check, and a segment that folds onto itself resolves exactly as before.
 *
 * That first half holds because this fold and [isCanonicalSingleSegment] are built from the same
 * two primitives, not as a matter of definition. Kotlin's `String.trim()` strips exactly the
 * characters `Char.isWhitespace()` reports, and [isCanonicalSingleSegment] rejects any segment
 * containing a character that same predicate reports; `lowercase()` is
 * `toLowerCase(Locale.ROOT)` on both sides, so the case comparison is the identical, locale-
 * invariant call. Correctness depends on that agreement being preserved: changing either side to
 * a different primitive breaks it in one of two ways. A fold that stops covering some character
 * `Char.isWhitespace()` reports — `java.lang.String.trim()`, `String.strip()`, or `trim(' ')` —
 * lets that spelling miss the store again and be answered as a freely claimable unknown TLD. A
 * fold that starts stripping a character `Char.isWhitespace()` does not report — again
 * `java.lang.String.trim()`, which strips everything at or below U+0020 — is worse: the folded
 * segment would find a descriptor, still pass the canonicality check, and hand a distinct
 * identifier the authorized peer IDs of a name nobody delegated to it. Any edit to this function
 * or to [isCanonicalSingleSegment] must keep both using the same whitespace predicate and the
 * same locale-invariant case fold.
 */
private fun tldLookupKey(segment: String): String = segment.trim().lowercase()

private fun isCanonicalSingleSegment(segment: String): Boolean {
    return segment.isNotBlank() &&
        segment.length <= 63 &&
        segment.none { it == '.' || it.isWhitespace() } &&
        segment == segment.lowercase()
}
