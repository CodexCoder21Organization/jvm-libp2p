package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.Scheduled
import community.kotlin.clocks.simple.SystemClock
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.ArrayDeque
import java.util.Base64
import java.util.Collections
import java.util.IdentityHashMap
import java.util.LinkedHashMap
import java.util.LinkedHashSet
import java.util.PriorityQueue
import java.util.TreeMap
import java.util.TreeSet
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.Condition
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Result of draining every fabric task that can run at the current injected-clock time. */
sealed class FabricDrainResult {
    data object Idle : FabricDrainResult()

    data class WaitingForClock(val nextDeadlineMillis: Long) : FabricDrainResult()
}

/** One directed in-memory link that has accepted transport bytes. */
data class InMemoryNetworkLink(
    val sourceNodeId: String,
    val destinationNodeId: String
) : Comparable<InMemoryNetworkLink> {
    override fun compareTo(other: InMemoryNetworkLink): Int {
        val sourceComparison = sourceNodeId.compareTo(other.sourceNodeId)
        return if (sourceComparison != 0) {
            sourceComparison
        } else {
            destinationNodeId.compareTo(other.destinationNodeId)
        }
    }
}

/** Immutable, maintained-counter view of one [InMemoryNetworkFabric]. */
data class InMemoryNetworkSnapshot(
    val registeredNodeCount: Int,
    val liveNodeCount: Int,
    val killedNodeCount: Int,
    val closedNodeCount: Int,
    val activeStreamCount: Int,
    val peakActiveStreamCount: Int,
    val totalBufferedBytes: Long,
    val maximumBufferedBytesForOneDestination: Long,
    val totalAcceptedBytes: Long,
    val totalSuccessfulStreamOpens: Long,
    val acceptedBytesByProtocolId: Map<String, Long>,
    val successfulStreamOpensByProtocolId: Map<String, Long>,
    val acceptedBytesByNode: Map<String, Long>,
    val successfulStreamOpensByNode: Map<String, Long>,
    val acceptedBytesByLink: Map<InMemoryNetworkLink, Long>,
    val dialFailureCount: Long,
    val dialTimeoutCount: Long,
    val inboundHandlersStarted: Long,
    val inboundHandlersCompleted: Long,
    val peakPendingHandlerCount: Int,
    val pendingCallbackCount: Int,
    val pendingHandlerCount: Int
)

/**
 * Shared deterministic transport fabric for [InMemoryNetworkProvider] nodes.
 *
 * Every stream direction owns a fixed-size byte ring. Writes wait when that ring is full and are
 * released only by a real read, an injected-clock timeout, or link teardown. The fabric deliberately
 * adds no framing, retransmission, or congestion control above those socket-like byte semantics.
 *
 * Harness controls identify nodes by their provider peer ID (also exposed by [NetworkListenInfo]).
 */
class InMemoryNetworkFabric(
    val clock: Clock = SystemClock(),
    val bufferCapacityBytes: Int = DEFAULT_BUFFER_CAPACITY_BYTES,
    val writeTimeoutMs: Long = DEFAULT_WRITE_TIMEOUT_MS,
    val readerTickMs: Long = DEFAULT_READER_TICK_MS
) : AutoCloseable {
    private var inboundHandlerThreadFactory: (String, Runnable) -> Thread = { name, runnable ->
        Thread.ofVirtual().name(name).unstarted(runnable)
    }
    internal val stateLock = ReentrantLock()
    private val stateChanged = stateLock.newCondition()
    private val nodes = LinkedHashMap<String, InMemoryNodeState>()
    private val sortedNodeIds = TreeSet<String>()
    private val addresses = LinkedHashMap<String, InMemoryNodeState>()
    private val undialableAddresses = LinkedHashSet<String>()
    private val connections = LinkedHashSet<InMemoryConnection>()
    private val partitions = LinkedHashSet<InMemoryNodePair>()
    private val activeInboundHandlers = LinkedHashSet<InMemoryInboundHandlerTask>()
    private val readyInboundHandlers = TreeSet(InMemoryInboundHandlerTask.ORDERING)
    private val waitingInboundHandlers = TreeSet(InMemoryInboundHandlerTask.ORDERING)
    // Pipe and dial-attempt identities wake only handlers that can make progress.
    private val waitingInboundHandlersBySignalKey =
        IdentityHashMap<Any, TreeSet<InMemoryInboundHandlerTask>>()
    private var suspendedInboundHandlerCount = 0
    private val inboundHandlerFailures = ArrayDeque<Throwable>()
    private var nextInboundHandlerSequence = 0L
    private var nextInboundHandlerToStart = 0L
    private val canceledInboundHandlerStarts = TreeSet<Long>()
    private var runningInboundHandler: InMemoryInboundHandlerTask? = null
    private val pendingCallbacks = PriorityQueue(InMemoryCallbackTask.ORDERING)
    private val callbackFailures = ArrayDeque<Throwable>()
    private var nextConnectionSequence = 0L
    @Volatile
    private var workGeneration = 0L
    private var callbackWorkerRunning = false
    private var executingCallbackCount = 0
    private val drainLock = Object()
    private var activeDrain: InMemoryDrainCycle? = null
    private var lastFailedDrainGeneration = -1L
    private var lastFailedDrainFailure: Throwable? = null
    private val readerModes = LinkedHashMap<String, InMemoryReaderMode>()
    private val writtenBytesByLink = TreeMap<InMemoryNetworkLink, Long>()
    private val acceptedBytesByProtocolId = TreeMap<String, Long>()
    private val successfulStreamOpensByProtocolId = TreeMap<String, Long>()
    private val acceptedBytesByNode = TreeMap<String, Long>()
    private val successfulStreamOpensByNode = TreeMap<String, Long>()
    private val bufferedBytesByDestination = TreeMap<String, Long>()
    private val reusablePipeBuffers = ArrayDeque<ByteArray>()
    private var totalAcceptedBytes = 0L
    private var totalSuccessfulStreamOpens = 0L
    private var totalBufferedBytes = 0L
    private var peakActiveStreamCount = 0
    private var dialFailureCount = 0L
    private var dialTimeoutCount = 0L
    private var dialAddressDescriptionCandidatesInspectedCount = 0L
    private var pipeBufferAllocationCountValue = 0L
    private var inboundHandlersStarted = 0L
    private var inboundHandlersCompleted = 0L
    private var peakPendingHandlerCount = 0
    private val scheduledDeadlines = TreeSet(InMemoryFabricScheduledTask.ORDERING)
    private val blockingOperationDeadlines = TreeSet(InMemoryFabricScheduledTask.ORDERING)
    private var nextDeadlineSequence = 0L
    private var closed = false
    private var closedStateCleared = false

    init {
        require(bufferCapacityBytes > 0) {
            "In-memory stream buffer capacity must be positive, but was $bufferCapacityBytes bytes."
        }
        require(writeTimeoutMs > 0L) {
            "In-memory stream write timeout must be positive, but was $writeTimeoutMs ms."
        }
        require(readerTickMs > 0L) {
            "In-memory slow-reader tick must be positive, but was $readerTickMs ms."
        }
    }

    /**
     * Replaces inbound worker creation for deterministic failure-injection tests. This must be
     * configured before the fabric has successfully launched any inbound handler. The factory must
     * return a thread that has not been started.
     */
    internal fun configureInboundHandlerThreadFactory(factory: (String, Runnable) -> Thread) = stateLock.withLock {
        checkFabricOpenLocked()
        check(nextInboundHandlerSequence == 0L && activeInboundHandlers.isEmpty()) {
            "Cannot configure the in-memory inbound handler thread factory after handler startup began: " +
                "nextSequence=$nextInboundHandlerSequence activeHandlers=${activeInboundHandlers.size}."
        }
        inboundHandlerThreadFactory = factory
    }

    internal fun register(provider: InMemoryNetworkProvider): InMemoryNodeState = stateLock.withLock {
        checkFabricOpenLocked()
        val peerId = provider.peerId
        check(!nodes.containsKey(peerId)) {
            "Cannot register in-memory node '$peerId': a node with that deterministic identity is already registered in this fabric."
        }
        InMemoryNodeState(provider, peerId, "memory://$peerId").also {
            nodes[peerId] = it
            sortedNodeIds += peerId
        }
    }

    internal fun listen(node: InMemoryNodeState, port: Int): NetworkListenInfo = stateLock.withLock {
        checkFabricOpenLocked()
        require(port in 0..65535) {
            "Cannot listen on in-memory network port $port: the port must be between 0 and 65535 inclusive."
        }
        checkNodeUsableLocked(node, "listen")
        if (!node.listening) {
            node.listening = true
            addresses[node.address] = node
            signalFabricLocked()
        }
        NetworkListenInfo(node.peerId, listOf(node.address))
    }

    internal fun dial(
        source: InMemoryNodeState,
        peerId: String,
        address: String,
        protocolId: String,
        timeoutMs: Long
    ): RpcStream {
        require(peerId.isNotBlank()) { "Cannot dial a blank peer ID." }
        require(address.isNotBlank()) { "Cannot dial peer '$peerId' at a blank in-memory address." }
        require(protocolId.isNotBlank()) { "Cannot dial peer '$peerId' with a blank protocol ID." }
        require(timeoutMs > 0L) {
            "Cannot dial peer '$peerId' with timeoutMs=$timeoutMs: timeoutMs must be greater than 0."
        }
        val attempt = InMemoryDialAttempt()
        val deadlineMillis = clock.currentTimeMillis() + timeoutMs
        var scheduled: Scheduled? = null
        try {
            lateinit var outbound: InMemoryRpcStream
            stateLock.withLock {
                while (true) {
                    checkFabricOpenLocked()
                    checkNodeUsableLocked(source, "dial")
                    if (!source.listening) listen(source, 0)

                    if (attempt.state == InMemoryDialAttemptState.TIMED_OUT) {
                        throw dialTimeoutFailure(source, peerId, address, protocolId, timeoutMs)
                    }

                    val destination = nodes[peerId]
                        ?: throw IOException(
                            "Cannot dial in-memory peer '$peerId' at address '$address' from '${source.peerId}': " +
                                "no node with peer ID '$peerId' is registered in this fabric."
                        )
                    if (destination.killed) {
                        throw IOException(
                            "Cannot dial in-memory peer '$peerId' at address '$address' from '${source.peerId}': " +
                                "destination node '$peerId' was killed."
                        )
                    }
                    if (destination.closed) {
                        throw IOException(
                            "Cannot dial in-memory peer '$peerId' at address '$address' from '${source.peerId}': " +
                                "destination node '$peerId' is closed."
                        )
                    }
                    if (address != destination.address && addresses[address] !== destination) {
                        val registeredAddresses = buildList {
                            add(destination.address)
                            addresses.forEach { (candidateAddress, candidateNode) ->
                                dialAddressDescriptionCandidatesInspectedCount += 1L
                                if (candidateNode === destination && candidateAddress != destination.address) {
                                    add(candidateAddress)
                                }
                            }
                        }.distinct()
                        val registeredAddressDescription = if (registeredAddresses.size == 1) {
                            "the registered address for '$peerId' is '${registeredAddresses.single()}'."
                        } else {
                            "the registered addresses for '$peerId' are $registeredAddresses."
                        }
                        throw IOException(
                            "Cannot dial in-memory peer '$peerId' at address '$address' from '${source.peerId}': " +
                                registeredAddressDescription
                        )
                    }
                    val unavailable = !destination.listening ||
                        address in undialableAddresses ||
                        !destination.dialable ||
                        partitions.contains(InMemoryNodePair.of(source.peerId, destination.peerId)) ||
                        destination.handlers[protocolId] == null
                    if (unavailable) {
                        if (scheduled == null) {
                            scheduled = fabricDialTimeout(deadlineMillis, attempt)
                            if (attempt.state == InMemoryDialAttemptState.TIMED_OUT) continue
                        }
                        waitForStateSignalLocked(
                            attempt,
                            "Dial from '${source.peerId}' to '$peerId' at '$address' using protocol " +
                                "'$protocolId' was interrupted."
                        )
                        continue
                    }
                    val handler = destination.handlers.getValue(protocolId)
                    check(attempt.state == InMemoryDialAttemptState.PENDING) {
                        "In-memory dial from '${source.peerId}' to '$peerId' reached an invalid terminal state ${attempt.state}."
                    }
                    val sourceToDestination = InMemoryBoundedPipe(
                        this,
                        source.peerId,
                        destination.peerId,
                        protocolId
                    )
                    val destinationToSource = InMemoryBoundedPipe(
                        this,
                        destination.peerId,
                        source.peerId,
                        protocolId
                    )
                    val connection = InMemoryConnection(
                        sequence = nextConnectionSequence,
                        fabric = this,
                        first = source,
                        second = destination,
                        firstToSecond = sourceToDestination,
                        secondToFirst = destinationToSource
                    )
                    outbound = InMemoryRpcStream(
                        fabric = this,
                        connection = connection,
                        inputPipe = destinationToSource,
                        outputPipe = sourceToDestination,
                        remotePeerId = destination.peerId,
                        serviceIdentifier = protocolId
                    )
                    val inbound = InMemoryRpcStream(
                        fabric = this,
                        connection = connection,
                        inputPipe = sourceToDestination,
                        outputPipe = destinationToSource,
                        remotePeerId = source.peerId,
                        serviceIdentifier = protocolId
                    )
                    val admittedInbound = AdmittedRpcStream(inbound, nextServiceConnectionAdmissionOrder())
                    val inboundTask = createInboundHandlerTaskLocked(
                        onFailureLocked = { failure ->
                            closeConnectionLocked(
                                connection,
                                abrupt = true,
                                reason = "Inbound in-memory worker for protocol '$protocolId' from " +
                                    "'${source.peerId}' to '${destination.peerId}' failed: ${failure.message}",
                            )
                        },
                    ) {
                        if (!connection.abrupt) {
                            try {
                                handler(admittedInbound)
                            } catch (failure: Throwable) {
                                inbound.close()
                                if (connection.abrupt) return@createInboundHandlerTaskLocked
                                throw IllegalStateException(
                                    "Inbound in-memory protocol handler '$protocolId' on node '${destination.peerId}' " +
                                        "failed while handling peer '${source.peerId}': ${failure.message}",
                                    failure
                                )
                            }
                        }
                    }
                    try {
                        startInboundHandlerLocked(inboundTask)
                    } catch (failure: Throwable) {
                        val rollbackReason =
                            "Inbound in-memory worker startup failed for protocol '$protocolId' from " +
                                "'${source.peerId}' to '${destination.peerId}': ${failure.message}"
                        sourceToDestination.closeLocked(abrupt = true, reason = rollbackReason)
                        destinationToSource.closeLocked(abrupt = true, reason = rollbackReason)
                        throw failure
                    }

                    attempt.state = InMemoryDialAttemptState.SUCCEEDED
                    nextConnectionSequence += 1L
                    connections += connection
                    source.connections += connection
                    destination.connections += connection
                    totalSuccessfulStreamOpens += 1L
                    successfulStreamOpensByProtocolId.increment(protocolId, 1L)
                    successfulStreamOpensByNode.increment(source.peerId, 1L)
                    peakActiveStreamCount = maxOf(peakActiveStreamCount, connections.size)
                    connection.firstEndpoint = outbound
                    connection.secondEndpoint = inbound
                    publishEventLocked(connection, source, NetworkConnectionEvent.Connected(destination.peerId))
                    publishEventLocked(connection, destination, NetworkConnectionEvent.Connected(source.peerId))
                    publishInboundHandlerStartedLocked(inboundTask)
                    break
                }
            }
            return outbound
        } catch (failure: Throwable) {
            stateLock.withLock {
                dialFailureCount += 1L
                if (attempt.state == InMemoryDialAttemptState.TIMED_OUT) {
                    dialTimeoutCount += 1L
                }
            }
            throw failure
        } finally {
            scheduled?.let(::unscheduleDeadline)
        }
    }

    private fun fabricDialTimeout(deadlineMillis: Long, attempt: InMemoryDialAttempt): Scheduled {
        return scheduleDeadline(deadlineMillis, InMemoryDeadlineKind.BLOCKING_OPERATION) {
            stateLock.withLock {
                if (attempt.state == InMemoryDialAttemptState.PENDING) {
                    attempt.state = InMemoryDialAttemptState.TIMED_OUT
                    signalFabricLocked(attempt)
                }
            }
        }
    }

    private fun dialTimeoutFailure(
        source: InMemoryNodeState,
        peerId: String,
        address: String,
        protocolId: String,
        timeoutMs: Long
    ): IllegalStateException = IllegalStateException(
        "Timed out after $timeoutMs ms while dialing in-memory peer '$peerId' " +
            "at address '$address' from '${source.peerId}' using protocol '$protocolId'."
    )

    /** Waits for one shared deterministic drain cycle and surfaces all handler work before failing. */
    fun runUntilIdle() = withCallingHandlerSuspended {
        while (runWorkCycle(stopAtClockBoundary = false) != FabricDrainResult.Idle) Unit
    }

    /**
     * Runs every handler and callback that is ready now, then reports the next fabric-owned clock
     * deadline instead of polling or advancing the injected clock.
     */
    fun drainReadyWork(): FabricDrainResult = withCallingHandlerSuspended {
        runWorkCycle(stopAtClockBoundary = true)
    }

    private fun <T> withCallingHandlerSuspended(block: () -> T): T {
        val callingHandler = stateLock.withLock {
            checkFabricOpenLocked()
            inMemoryCurrentInboundHandler.get()?.also { task ->
                check(runningInboundHandler === task) {
                    "Inbound in-memory handler ${task.sequence} tried to drain without owning the deterministic fabric turn."
                }
                task.suspendedForDrain = true
                suspendedInboundHandlerCount += 1
                runningInboundHandler = null
                signalNextInboundHandlerTurnLocked()
                stateChanged.signalAll()
            }
        }
        try {
            return block()
        } finally {
            if (callingHandler != null) {
                stateLock.withLock {
                    callingHandler.suspendedForDrain = false
                    suspendedInboundHandlerCount -= 1
                    markInboundHandlerReadyLocked(callingHandler)
                    stateChanged.signalAll()
                    acquireInboundHandlerTurnLocked(callingHandler)
                }
            }
        }
    }

    private fun runWorkCycle(stopAtClockBoundary: Boolean): FabricDrainResult {
        while (true) {
            val cycle: InMemoryDrainCycle
            val leader: Boolean
            var upgradedToClockBoundary = false
            synchronized(drainLock) {
                val current = activeDrain
                if (current == null) {
                    if (lastFailedDrainGeneration == workGeneration) {
                        throw checkNotNull(lastFailedDrainFailure)
                    }
                    cycle = InMemoryDrainCycle(stopAtClockBoundary)
                    activeDrain = cycle
                    leader = true
                } else {
                    if (stopAtClockBoundary && !current.stopAtClockBoundary) {
                        current.stopAtClockBoundary = true
                        upgradedToClockBoundary = true
                    }
                    cycle = current
                    leader = false
                }
            }
            if (upgradedToClockBoundary) {
                stateLock.withLock {
                    stateChanged.signalAll()
                }
            }

            if (leader) {
                var drainFailure: Throwable? = null
                try {
                    startCallbackWorkerIfNeeded()
                    var failures: List<Throwable>? = null
                    while (failures == null && cycle.result == null) {
                        var callbackWorkerNeedsStart = false
                        stateLock.withLock {
                            val scheduledHandlerCount = scheduledInboundHandlerCountLocked()
                            val clockBoundaryRequested = cycle.stopAtClockBoundary
                            val idle = scheduledHandlerCount == 0 &&
                                pendingCallbacks.isEmpty() &&
                                executingCallbackCount == 0 &&
                                !callbackWorkerRunning &&
                                (!clockBoundaryRequested || blockingOperationDeadlines.isEmpty())
                            if (idle) {
                                failures = buildList {
                                    while (inboundHandlerFailures.isNotEmpty()) {
                                        add(inboundHandlerFailures.removeFirst())
                                    }
                                    while (callbackFailures.isNotEmpty()) {
                                        add(callbackFailures.removeFirst())
                                    }
                                }
                                cycle.resultUsesClockBoundaryMode = clockBoundaryRequested
                                cycle.result = FabricDrainResult.Idle
                            } else if (scheduledHandlerCount > waitingInboundHandlers.size) {
                                waitForStateSignalWithoutHandlerLocked(
                                    "In-memory fabric drain was interrupted while waiting for a running handler."
                                )
                            } else if (executingCallbackCount > 0) {
                                waitForStateSignalWithoutHandlerLocked(
                                    "In-memory fabric drain was interrupted while waiting for an executing callback."
                                )
                            } else if (
                                scheduledHandlerCount == 0 &&
                                pendingCallbacks.isNotEmpty()
                            ) {
                                if (callbackWorkerRunning) {
                                    waitForStateSignalWithoutHandlerLocked(
                                        "In-memory fabric drain was interrupted while waiting for runnable callbacks."
                                    )
                                } else {
                                    // A handler may have published these callbacks after the
                                    // worker check at the start of this drain cycle.
                                    callbackWorkerNeedsStart = true
                                }
                            } else if (
                                clockBoundaryRequested &&
                                scheduledHandlerCount > 0 &&
                                scheduledDeadlines.isNotEmpty()
                            ) {
                                cycle.resultUsesClockBoundaryMode = true
                                cycle.result = FabricDrainResult.WaitingForClock(
                                    scheduledDeadlines.first().deadlineMillis
                                )
                            } else if (
                                clockBoundaryRequested &&
                                scheduledHandlerCount == 0 &&
                                blockingOperationDeadlines.isNotEmpty()
                            ) {
                                cycle.resultUsesClockBoundaryMode = true
                                cycle.result = FabricDrainResult.WaitingForClock(
                                    blockingOperationDeadlines.first().deadlineMillis
                                )
                            } else {
                                waitForStateSignalWithoutHandlerLocked(
                                    "In-memory fabric drain was interrupted while waiting for scheduled handlers and callbacks."
                                )
                            }
                        }
                        if (callbackWorkerNeedsStart) startCallbackWorkerIfNeeded()
                    }
                    val completedFailures = failures
                    if (completedFailures != null && completedFailures.isNotEmpty()) {
                        drainFailure = completedFailures.first()
                        completedFailures.drop(1).forEach(drainFailure::addSuppressed)
                    }
                } catch (failure: Throwable) {
                    drainFailure = failure
                } finally {
                    synchronized(drainLock) {
                        cycle.failure = drainFailure
                        cycle.generation = workGeneration
                        if (drainFailure != null) {
                            lastFailedDrainGeneration = cycle.generation
                            lastFailedDrainFailure = drainFailure
                        }
                        cycle.completed = true
                        if (activeDrain === cycle) activeDrain = null
                        drainLock.notifyAll()
                    }
                }
            } else {
                synchronized(drainLock) {
                    while (!cycle.completed) {
                        waitOnMonitorLocked(
                            drainLock,
                            "Concurrent in-memory fabric drain was interrupted while joining the active drain."
                        )
                    }
                }
            }
            cycle.failure?.let { throw it }
            if (stopAtClockBoundary && !cycle.resultUsesClockBoundaryMode) {
                continue
            }
            return checkNotNull(cycle.result) {
                "In-memory fabric drain completed without an idle or clock-boundary result."
            }
        }
    }

    /** Stops [nodeId] from consuming bytes from any inbound stream. */
    fun stallReader(nodeId: String) = stateLock.withLock {
        val node = requireControllableNodeLocked(nodeId)
        cancelSlowScheduleLocked(readerModes.remove(node.peerId))
        readerModes[node.peerId] = InMemoryReaderMode.Stalled
        signalFabricLocked()
    }

    /** Allows [nodeId] to consume at most [bytesPerTick] bytes each [readerTickMs] interval. */
    fun slowReader(nodeId: String, bytesPerTick: Int) = stateLock.withLock {
        require(bytesPerTick > 0) {
            "Cannot configure in-memory node '$nodeId' with bytesPerTick=$bytesPerTick: bytesPerTick must be positive."
        }
        val node = requireControllableNodeLocked(nodeId)
        cancelSlowScheduleLocked(readerModes.remove(node.peerId))
        val mode = InMemoryReaderMode.Slow(bytesPerTick)
        readerModes[node.peerId] = mode
        scheduleSlowTickLocked(node.peerId, mode)
        signalFabricLocked()
    }

    /** Restores unrestricted inbound reads for [nodeId]. */
    fun resumeReader(nodeId: String) = stateLock.withLock {
        val node = requireControllableNodeLocked(nodeId)
        cancelSlowScheduleLocked(readerModes.remove(node.peerId))
        signalFabricLocked()
    }

    /** Abruptly terminates [nodeId], discarding its streams and making every later dial fail. */
    fun kill(nodeId: String) {
        stateLock.withLock {
            val node = requireControllableNodeLocked(nodeId)
            node.killed = true
            node.listening = false
            val nodeAddresses = addresses.filterValues { it === node }.keys.toList()
            nodeAddresses.forEach {
                addresses.remove(it)
                undialableAddresses.remove(it)
            }
            cancelSlowScheduleLocked(readerModes.remove(node.peerId))
            node.connections.toList().forEach {
                closeConnectionLocked(
                    it,
                    abrupt = true,
                    reason = "In-memory node '$nodeId' was killed; all stream buffers were dropped."
                )
            }
        }
        startCallbackWorkerIfNeeded()
    }

    /** Splits [nodeA] and [nodeB], dropping every active connection between the two nodes. */
    fun partition(nodeA: String, nodeB: String) {
        require(nodeA != nodeB) { "Cannot partition in-memory node '$nodeA' from itself." }
        val pair: InMemoryNodePair
        val toClose: List<InMemoryConnection>
        stateLock.withLock {
            requireControllableNodeLocked(nodeA)
            requireControllableNodeLocked(nodeB)
            pair = InMemoryNodePair.of(nodeA, nodeB)
            partitions += pair
            toClose = connections.filter { it.connects(pair.first, pair.second) }
        }
        toClose.forEach {
            closeConnection(
                it,
                abrupt = true,
                reason = "In-memory nodes '${pair.first}' and '${pair.second}' were partitioned; the stream was disconnected."
            )
        }
    }

    /** Removes the partition between [nodeA] and [nodeB]. Existing streams are not resurrected. */
    fun heal(nodeA: String, nodeB: String) = stateLock.withLock {
        requireControllableNodeLocked(nodeA)
        requireControllableNodeLocked(nodeB)
        partitions.remove(InMemoryNodePair.of(nodeA, nodeB))
        signalFabricLocked()
    }

    /** Controls whether other nodes may dial [nodeId]; the node may always initiate outbound dials. */
    fun setDialable(nodeId: String, dialable: Boolean) = stateLock.withLock {
        requireControllableNodeLocked(nodeId).dialable = dialable
        signalFabricLocked()
    }

    /** Registers another deterministic address for an already-listening [nodeId]. */
    fun addAddressAlias(nodeId: String, address: String) = stateLock.withLock {
        require(address.isNotBlank()) {
            "Cannot add a blank in-memory address alias for node '$nodeId'."
        }
        val node = requireControllableNodeLocked(nodeId)
        check(node.listening) {
            "Cannot add in-memory address alias '$address' for node '$nodeId': the node is not listening."
        }
        val existing = addresses[address]
        check(existing == null || existing === node) {
            "Cannot add in-memory address alias '$address' for node '$nodeId': it is already registered to node '${existing?.peerId}'."
        }
        addresses[address] = node
        signalFabricLocked()
    }

    /** Controls whether one registered [address] for [nodeId] may accept dials. */
    fun setAddressDialable(nodeId: String, address: String, dialable: Boolean) = stateLock.withLock {
        val node = requireControllableNodeLocked(nodeId)
        check(addresses[address] === node) {
            "Cannot configure in-memory address '$address' for node '$nodeId': the address is not registered to that node."
        }
        if (dialable) undialableAddresses.remove(address) else undialableAddresses.add(address)
        signalFabricLocked()
    }

    /** Returns bytes currently retained in bounded pipes whose destination is [nodeId]. */
    fun bufferedBytes(nodeId: String): Int = stateLock.withLock {
        requireKnownNodeLocked(nodeId)
        (bufferedBytesByDestination[nodeId] ?: 0L).toInt()
    }

    /** Returns the number of currently live streams in the fabric. */
    val activeStreamCount: Int
        get() = stateLock.withLock { connections.size }

    /** Returns address candidates visited only while describing invalid dial targets. */
    val dialAddressDescriptionCandidatesInspected: Long
        get() = stateLock.withLock { dialAddressDescriptionCandidatesInspectedCount }

    /** Returns the cumulative number of bounded pipe backing arrays allocated by this fabric. */
    val pipeBufferAllocationCount: Long
        get() = stateLock.withLock { pipeBufferAllocationCountValue }

    internal fun acquirePipeBufferLocked(): ByteArray {
        check(stateLock.isHeldByCurrentThread) {
            "In-memory pipe buffers must be acquired while holding the fabric state lock."
        }
        reusablePipeBuffers.pollFirst()?.let { return it }
        pipeBufferAllocationCountValue += 1L
        return ByteArray(bufferCapacityBytes)
    }

    internal fun releasePipeBufferLocked(buffer: ByteArray) {
        check(stateLock.isHeldByCurrentThread) {
            "In-memory pipe buffers must be released while holding the fabric state lock."
        }
        check(buffer.size == bufferCapacityBytes) {
            "Cannot reuse an in-memory pipe buffer with ${buffer.size} bytes in a fabric whose " +
                "pipe capacity is $bufferCapacityBytes bytes."
        }
        if (!closed && reusablePipeBuffers.size < MAX_RETAINED_PIPE_BUFFERS) {
            reusablePipeBuffers.addLast(buffer)
        }
    }

    /**
     * Returns an immutable view assembled only from maintained scalar counters and sparse link
     * state. Reading it does not run fabric work, inspect payloads, or advance [clock].
     */
    fun snapshot(): InMemoryNetworkSnapshot = stateLock.withLock {
        checkFabricOpenLocked()
        val nodeAcceptedBytes = sortedNodeIds.associateWith { nodeId ->
            acceptedBytesByNode[nodeId] ?: 0L
        }
        val nodeStreamOpens = sortedNodeIds.associateWith { nodeId ->
            successfulStreamOpensByNode[nodeId] ?: 0L
        }
        InMemoryNetworkSnapshot(
            registeredNodeCount = nodes.size,
            liveNodeCount = nodes.values.count { node -> !node.killed && !node.closed },
            killedNodeCount = nodes.values.count { node -> node.killed },
            closedNodeCount = nodes.values.count { node -> node.closed },
            activeStreamCount = connections.size,
            peakActiveStreamCount = peakActiveStreamCount,
            totalBufferedBytes = totalBufferedBytes,
            maximumBufferedBytesForOneDestination =
                bufferedBytesByDestination.values.maxOrNull() ?: 0L,
            totalAcceptedBytes = totalAcceptedBytes,
            totalSuccessfulStreamOpens = totalSuccessfulStreamOpens,
            acceptedBytesByProtocolId = immutableMapCopy(acceptedBytesByProtocolId),
            successfulStreamOpensByProtocolId =
                immutableMapCopy(successfulStreamOpensByProtocolId),
            acceptedBytesByNode = immutableMapCopy(nodeAcceptedBytes),
            successfulStreamOpensByNode = immutableMapCopy(nodeStreamOpens),
            acceptedBytesByLink = immutableMapCopy(writtenBytesByLink),
            dialFailureCount = dialFailureCount,
            dialTimeoutCount = dialTimeoutCount,
            inboundHandlersStarted = inboundHandlersStarted,
            inboundHandlersCompleted = inboundHandlersCompleted,
            peakPendingHandlerCount = peakPendingHandlerCount,
            pendingCallbackCount = pendingCallbacks.size,
            pendingHandlerCount = activeInboundHandlers.size
        )
    }

    /** Total transport bytes accepted on the directed [sourceNodeId] -> [destinationNodeId] link. */
    fun writtenBytes(sourceNodeId: String, destinationNodeId: String): Long =
        stateLock.withLock {
            requireKnownNodeLocked(sourceNodeId)
            requireKnownNodeLocked(destinationNodeId)
            writtenBytesByLink[InMemoryNetworkLink(sourceNodeId, destinationNodeId)] ?: 0L
        }

    internal fun recordWrittenBytesLocked(
        sourcePeerId: String,
        destinationPeerId: String,
        protocolId: String,
        count: Int
    ) {
        if (closedStateCleared) return
        val key = InMemoryNetworkLink(sourcePeerId, destinationPeerId)
        writtenBytesByLink[key] = (writtenBytesByLink[key] ?: 0L) + count
        totalAcceptedBytes += count.toLong()
        acceptedBytesByProtocolId.increment(protocolId, count.toLong())
        acceptedBytesByNode.increment(sourcePeerId, count.toLong())
    }

    internal fun adjustBufferedBytesLocked(destinationPeerId: String, delta: Int) {
        if (delta == 0 || closedStateCleared) return
        totalBufferedBytes += delta.toLong()
        check(totalBufferedBytes >= 0L) {
            "In-memory fabric buffered-byte accounting became negative: totalBufferedBytes=$totalBufferedBytes."
        }
        val destinationBytes = (bufferedBytesByDestination[destinationPeerId] ?: 0L) + delta
        check(destinationBytes >= 0L) {
            "In-memory fabric buffered-byte accounting for '$destinationPeerId' became negative: " +
                "bufferedBytes=$destinationBytes."
        }
        if (destinationBytes == 0L) {
            bufferedBytesByDestination.remove(destinationPeerId)
        } else {
            bufferedBytesByDestination[destinationPeerId] = destinationBytes
        }
    }

    internal fun readerAllowanceLocked(destinationPeerId: String, requestedBytes: Int): Int {
        return when (val mode = readerModes[destinationPeerId]) {
            null -> requestedBytes
            InMemoryReaderMode.Stalled -> 0
            is InMemoryReaderMode.Slow -> minOf(requestedBytes, mode.availableBytes)
        }
    }

    internal fun consumeReaderAllowanceLocked(destinationPeerId: String, consumedBytes: Int) {
        val mode = readerModes[destinationPeerId]
        if (mode is InMemoryReaderMode.Slow) mode.availableBytes -= consumedBytes
    }

    internal fun closeConnection(connection: InMemoryConnection, abrupt: Boolean, reason: String) {
        stateLock.withLock {
            if (!closeConnectionLocked(connection, abrupt, reason)) return
        }
    }

    internal fun closeEndpoint(
        connection: InMemoryConnection,
        endpoint: InMemoryRpcStream,
        reason: String
    ) {
        stateLock.withLock {
            if (connection.closed.get()) return
            connection.markEndpointAndPeerUnusable(endpoint)
            closeConnectionLocked(connection, abrupt = false, reason = reason)
        }
    }

    internal fun unregister(node: InMemoryNodeState) {
        val toClose: List<InMemoryConnection>
        stateLock.withLock {
            if (node.closed) return
            node.closed = true
            node.listening = false
            val nodeAddresses = addresses.filterValues { it === node }.keys.toList()
            nodeAddresses.forEach {
                addresses.remove(it)
                undialableAddresses.remove(it)
            }
            cancelSlowScheduleLocked(readerModes.remove(node.peerId))
            toClose = node.connections.toList()
            node.handlers.clear()
            node.listeners.clear()
            signalFabricLocked()
        }
        toClose.forEach {
            closeConnection(
                it,
                abrupt = false,
                reason = "In-memory node '${node.peerId}' closed gracefully."
            )
        }
    }

    override fun close() {
        val allConnections: List<InMemoryConnection>
        stateLock.withLock {
            if (closed) return
            closed = true
            allConnections = connections.toList()
            readerModes.values.forEach(::cancelSlowScheduleLocked)
            readerModes.clear()
            addresses.clear()
            undialableAddresses.clear()
            nodes.values.forEach {
                it.closed = true
                it.listening = false
                it.handlers.clear()
            }
            signalFabricLocked()
        }
        allConnections.forEach {
            closeConnection(it, abrupt = false, reason = "The in-memory network fabric closed gracefully.")
        }
        startCallbackWorkerIfNeeded()
        stateLock.withLock {
            clearClosedFabricStateIfQuiescentLocked()
        }
    }

    private fun scheduleSlowTickLocked(nodeId: String, mode: InMemoryReaderMode.Slow) {
        val deadline = clock.currentTimeMillis() + readerTickMs
        mode.scheduled = scheduleDeadline(deadline, InMemoryDeadlineKind.READER_TICK) {
            stateLock.withLock {
                if (closed || readerModes[nodeId] !== mode) return@withLock
                mode.availableBytes = mode.bytesPerTick
                signalFabricLocked()
                scheduleSlowTickLocked(nodeId, mode)
            }
        }
    }

    private fun cancelSlowScheduleLocked(mode: InMemoryReaderMode?) {
        if (mode is InMemoryReaderMode.Slow) {
            mode.scheduled?.let(::unscheduleDeadline)
            mode.scheduled = null
        }
    }

    internal fun scheduleDeadline(
        deadlineMillis: Long,
        kind: InMemoryDeadlineKind,
        callback: () -> Unit
    ): Scheduled {
        val task = stateLock.withLock {
            InMemoryFabricScheduledTask(
                sequence = nextDeadlineSequence++,
                deadlineMillis = deadlineMillis,
                kind = kind,
                fabric = this
            ).also { scheduled ->
                scheduledDeadlines += scheduled
                if (kind == InMemoryDeadlineKind.BLOCKING_OPERATION) {
                    blockingOperationDeadlines += scheduled
                }
            }
        }
        val delegate = clock.schedule(deadlineMillis) {
            val shouldRun = stateLock.withLock {
                if (!task.active || task.firing) {
                    false
                } else {
                    task.firing = true
                    true
                }
            }
            if (shouldRun) {
                try {
                    callback()
                } finally {
                    stateLock.withLock {
                        task.active = false
                        task.firing = false
                        scheduledDeadlines.remove(task)
                        blockingOperationDeadlines.remove(task)
                        clearClosedFabricStateIfQuiescentLocked()
                        stateChanged.signalAll()
                    }
                }
            }
        }
        val canceledBeforeDelegateWasStored = stateLock.withLock {
            task.delegate = delegate
            !task.active
        }
        if (canceledBeforeDelegateWasStored) clock.unschedule(delegate)
        return task
    }

    internal fun unscheduleDeadline(scheduled: Scheduled) {
        if (scheduled !is InMemoryFabricScheduledTask || scheduled.fabric !== this) {
            clock.unschedule(scheduled)
            return
        }
        val delegate = stateLock.withLock {
            if (scheduled.active) {
                scheduled.active = false
                if (!scheduled.firing) {
                    scheduledDeadlines.remove(scheduled)
                    blockingOperationDeadlines.remove(scheduled)
                    stateChanged.signalAll()
                }
            }
            scheduled.delegate
        }
        if (delegate != null) clock.unschedule(delegate)
        stateLock.withLock {
            clearClosedFabricStateIfQuiescentLocked()
        }
    }

    private fun publishEventLocked(
        connection: InMemoryConnection,
        node: InMemoryNodeState,
        event: NetworkConnectionEvent
    ) {
        val eventOrder = if (event is NetworkConnectionEvent.Connected) 0 else 1
        val endpointOrder = if (node === connection.first) 0 else 1
        node.listeners.toList().forEachIndexed { listenerOrder, listener ->
            workGeneration += 1L
            pendingCallbacks += InMemoryCallbackTask(
                connectionSequence = connection.sequence,
                eventOrder = eventOrder,
                endpointOrder = endpointOrder,
                listenerOrder = listenerOrder
            ) {
                try {
                    listener(event)
                } catch (failure: Throwable) {
                    stateLock.withLock {
                        callbackFailures.addLast(
                            IllegalStateException(
                                "In-memory connection listener on node '${node.peerId}' failed while handling " +
                                    "event '$event': ${failure.message}",
                                failure
                            )
                        )
                    }
                }
            }
        }
    }

    private fun createInboundHandlerTaskLocked(
        onFailureLocked: (Throwable) -> Unit,
        handler: () -> Unit,
    ): InMemoryInboundHandlerTask {
        return InMemoryInboundHandlerTask(
            sequence = nextInboundHandlerSequence,
            handler = handler,
            onFailureLocked = onFailureLocked,
            turnAvailable = stateLock.newCondition(),
            fabricSignalAvailable = stateLock.newCondition()
        )
    }

    private fun startInboundHandlerLocked(task: InMemoryInboundHandlerTask) {
        // Every inbound handler needs its own stack, because a handler may suspend part-way
        // through and resume later, and it must not start until its turn in the deterministic
        // sequence. A scale scenario therefore holds one live handler per in-flight stream:
        // a 1024-node flood keeps several thousand of them alive at once, nearly all of them
        // parked waiting for the exclusive fabric turn rather than running.
        //
        // Those stacks are virtual threads, not platform threads. Thousands of parked platform
        // threads exhaust a small CI executor long before the scenario finishes, while the same
        // number of virtual threads costs a few heap objects and no kernel scheduling at all.
        // Parking is always done through this fabric's ReentrantLock conditions, never a
        // monitor, so a parked handler releases its carrier instead of pinning it.
        val worker = inboundHandlerThreadFactory("in-memory-handler-${task.sequence}", Runnable {
            var failure: Throwable? = null
            try {
                stateLock.withLock {
                    while (task.sequence != nextInboundHandlerToStart) {
                        awaitConditionLocked(
                            stateChanged,
                            "Inbound in-memory handler sequence ${task.sequence} was interrupted before deterministic start."
                        )
                    }
                    task.passedStartBarrier = true
                    nextInboundHandlerToStart += 1L
                    skipCanceledInboundHandlerStartsLocked()
                    markInboundHandlerReadyLocked(task)
                    stateChanged.signalAll()
                    acquireInboundHandlerTurnLocked(task)
                }
                inMemoryCurrentInboundHandler.set(task)
                task.handler()
            } catch (caught: Throwable) {
                failure = caught
            } finally {
                stateLock.withLock {
                    if (failure != null) {
                        inboundHandlerFailures.addLast(failure)
                        task.onFailureLocked(failure)
                    }
                    if (!task.passedStartBarrier) {
                        canceledInboundHandlerStarts += task.sequence
                        skipCanceledInboundHandlerStartsLocked()
                    }
                    if (runningInboundHandler === task) runningInboundHandler = null
                    readyInboundHandlers.remove(task)
                    waitingInboundHandlers.remove(task)
                    task.fabricSignalKey?.let { signalKey ->
                        waitingInboundHandlersBySignalKey[signalKey]?.let { keyedHandlers ->
                            keyedHandlers.remove(task)
                            if (keyedHandlers.isEmpty()) waitingInboundHandlersBySignalKey.remove(signalKey)
                        }
                    }
                    task.fabricSignalKey = null
                    task.waitingForFabricSignal = false
                    if (task.suspendedForDrain) {
                        task.suspendedForDrain = false
                        suspendedInboundHandlerCount -= 1
                    }
                    activeInboundHandlers.remove(task)
                    inboundHandlersCompleted += 1L
                    clearClosedFabricStateIfQuiescentLocked()
                    signalNextInboundHandlerTurnLocked()
                    stateChanged.signalAll()
                }
                inMemoryCurrentInboundHandler.remove()
            }
        })
        task.worker = worker
        worker.start()
    }

    private fun skipCanceledInboundHandlerStartsLocked() {
        while (canceledInboundHandlerStarts.remove(nextInboundHandlerToStart)) {
            nextInboundHandlerToStart += 1L
        }
    }

    private fun publishInboundHandlerStartedLocked(task: InMemoryInboundHandlerTask) {
        check(task.sequence == nextInboundHandlerSequence) {
            "Cannot publish inbound in-memory handler sequence ${task.sequence}: " +
                "the next sequence is $nextInboundHandlerSequence."
        }
        nextInboundHandlerSequence += 1L
        workGeneration += 1L
        inboundHandlersStarted += 1L
        activeInboundHandlers += task
        peakPendingHandlerCount = maxOf(peakPendingHandlerCount, activeInboundHandlers.size)
        stateChanged.signalAll()
    }

    private fun acquireInboundHandlerTurnLocked(task: InMemoryInboundHandlerTask) {
        while (
            runningInboundHandler != null ||
            readyInboundHandlers.isEmpty() ||
            readyInboundHandlers.first() !== task
        ) {
            awaitConditionLocked(
                task.turnAvailable,
                "Inbound in-memory handler sequence ${task.sequence} was interrupted while waiting for its deterministic turn."
            )
        }
        check(readyInboundHandlers.remove(task)) {
            "Inbound in-memory handler ${task.sequence} acquired the deterministic turn without being ready."
        }
        runningInboundHandler = task
    }

    internal fun waitForStateSignalLocked(signalKey: Any, interruptedMessage: String) {
        val task = inMemoryCurrentInboundHandler.get()
        if (task == null) {
            awaitConditionLocked(stateChanged, interruptedMessage)
            return
        }
        check(runningInboundHandler === task) {
            "Inbound in-memory handler ${task.sequence} tried to wait without owning the deterministic fabric turn."
        }
        task.waitingForFabricSignal = true
        task.fabricSignalKey = signalKey
        waitingInboundHandlers += task
        waitingInboundHandlersBySignalKey
            .getOrPut(signalKey) { TreeSet(InMemoryInboundHandlerTask.ORDERING) }
            .add(task)
        runningInboundHandler = null
        signalNextInboundHandlerTurnLocked()
        stateChanged.signalAll()
        while (task.waitingForFabricSignal) {
            awaitConditionLocked(task.fabricSignalAvailable, interruptedMessage)
        }
        acquireInboundHandlerTurnLocked(task)
    }

    internal fun signalFabricLocked(signalKey: Any? = null) {
        val signaledHandlers = if (signalKey == null) {
            waitingInboundHandlers.toList()
        } else {
            waitingInboundHandlersBySignalKey.remove(signalKey)?.toList().orEmpty()
        }
        signaledHandlers.forEach { task ->
            waitingInboundHandlers.remove(task)
            task.fabricSignalKey?.let { key ->
                waitingInboundHandlersBySignalKey[key]?.let { keyedHandlers ->
                    keyedHandlers.remove(task)
                    if (keyedHandlers.isEmpty()) waitingInboundHandlersBySignalKey.remove(key)
                }
            }
            task.fabricSignalKey = null
            task.waitingForFabricSignal = false
            if (!task.suspendedForDrain) markInboundHandlerReadyLocked(task)
            task.fabricSignalAvailable.signal()
        }
        signalNextInboundHandlerTurnLocked()
        stateChanged.signalAll()
    }

    private fun markInboundHandlerReadyLocked(task: InMemoryInboundHandlerTask) {
        check(!task.waitingForFabricSignal) {
            "Inbound in-memory handler ${task.sequence} cannot become ready while waiting for a fabric signal."
        }
        readyInboundHandlers += task
        signalNextInboundHandlerTurnLocked()
    }

    private fun signalNextInboundHandlerTurnLocked() {
        if (runningInboundHandler == null) {
            readyInboundHandlers.firstOrNull()?.turnAvailable?.signal()
        }
    }

    private fun scheduledInboundHandlerCountLocked(): Int =
        activeInboundHandlers.size - suspendedInboundHandlerCount

    private fun startCallbackWorkerIfNeeded() {
        val worker = stateLock.withLock {
            if (callbackWorkerRunning || pendingCallbacks.isEmpty()) return
            callbackWorkerRunning = true
            Thread({ drainCallbacks() }, "in-memory-network-callbacks").apply { isDaemon = true }
        }
        worker.start()
    }

    private fun drainCallbacks() {
        while (true) {
            val callback = stateLock.withLock {
                while (scheduledInboundHandlerCountLocked() > 0) {
                    awaitConditionLocked(
                        stateChanged,
                        "In-memory callback delivery was interrupted while waiting for the deterministic fabric turn."
                    )
                }
                val next = pendingCallbacks.poll()
                if (next == null) {
                    callbackWorkerRunning = false
                    clearClosedFabricStateIfQuiescentLocked()
                    stateChanged.signalAll()
                    return
                }
                executingCallbackCount += 1
                next
            }
            try {
                callback.callback()
            } finally {
                stateLock.withLock {
                    executingCallbackCount -= 1
                    stateChanged.signalAll()
                }
            }
        }
    }

    private fun closeConnectionLocked(
        connection: InMemoryConnection,
        abrupt: Boolean,
        reason: String
    ): Boolean {
        if (!connection.closed.compareAndSet(false, true)) return false
        connection.abrupt = abrupt
        connection.firstEndpointUsable = false
        connection.secondEndpointUsable = false
        connections.remove(connection)
        connection.first.connections.remove(connection)
        connection.second.connections.remove(connection)
        connection.firstToSecond.closeLocked(abrupt, reason)
        connection.secondToFirst.closeLocked(abrupt, reason)
        connection.firstEndpoint?.markClosed()
        connection.secondEndpoint?.markClosed()
        publishEventLocked(
            connection,
            connection.first,
            NetworkConnectionEvent.Disconnected(connection.second.peerId)
        )
        publishEventLocked(
            connection,
            connection.second,
            NetworkConnectionEvent.Disconnected(connection.first.peerId)
        )
        signalFabricLocked()
        return true
    }

    private fun requireKnownNodeLocked(nodeId: String): InMemoryNodeState {
        return nodes[nodeId]
            ?: throw IllegalArgumentException(
                "Unknown in-memory node '$nodeId': registered node IDs are [${nodes.keys.joinToString(", ")}]."
            )
    }

    private fun requireControllableNodeLocked(nodeId: String): InMemoryNodeState {
        checkFabricOpenLocked()
        return requireKnownNodeLocked(nodeId)
    }

    private fun checkNodeUsableLocked(node: InMemoryNodeState, operation: String) {
        check(nodes[node.peerId] === node) {
            "Cannot $operation with in-memory node '${node.peerId}': it is not registered in this fabric."
        }
        check(!node.closed) {
            "Cannot $operation with in-memory node '${node.peerId}': the provider is closed."
        }
        check(!node.killed) {
            "Cannot $operation with in-memory node '${node.peerId}': the node was killed."
        }
    }

    private fun checkFabricOpenLocked() {
        check(!closed) { "InMemoryNetworkFabric is closed and cannot perform network operations." }
    }

    private fun waitForStateSignalWithoutHandlerLocked(interruptedMessage: String) {
        awaitConditionLocked(stateChanged, interruptedMessage)
    }

    private fun clearClosedFabricStateIfQuiescentLocked() {
        if (
            closedStateCleared ||
            !closed ||
            connections.isNotEmpty() ||
            activeInboundHandlers.isNotEmpty() ||
            pendingCallbacks.isNotEmpty() ||
            callbackWorkerRunning ||
            executingCallbackCount > 0 ||
            scheduledDeadlines.isNotEmpty()
        ) {
            return
        }
        nodes.clear()
        sortedNodeIds.clear()
        addresses.clear()
        partitions.clear()
        readyInboundHandlers.clear()
        waitingInboundHandlers.clear()
        waitingInboundHandlersBySignalKey.clear()
        canceledInboundHandlerStarts.clear()
        inboundHandlerFailures.clear()
        callbackFailures.clear()
        readerModes.clear()
        writtenBytesByLink.clear()
        acceptedBytesByProtocolId.clear()
        successfulStreamOpensByProtocolId.clear()
        acceptedBytesByNode.clear()
        successfulStreamOpensByNode.clear()
        bufferedBytesByDestination.clear()
        reusablePipeBuffers.clear()
        blockingOperationDeadlines.clear()
        totalAcceptedBytes = 0L
        totalSuccessfulStreamOpens = 0L
        totalBufferedBytes = 0L
        peakActiveStreamCount = 0
        dialFailureCount = 0L
        dialTimeoutCount = 0L
        dialAddressDescriptionCandidatesInspectedCount = 0L
        pipeBufferAllocationCountValue = 0L
        inboundHandlersStarted = 0L
        inboundHandlersCompleted = 0L
        peakPendingHandlerCount = 0
        closedStateCleared = true
    }

    companion object {
        const val DEFAULT_BUFFER_CAPACITY_BYTES = 4 * 1024
        const val DEFAULT_WRITE_TIMEOUT_MS = 30_000L
        const val DEFAULT_READER_TICK_MS = 10L
        private const val MAX_RETAINED_PIPE_BUFFERS = 256
    }
}

/** One deterministic in-process node attached to an [InMemoryNetworkFabric]. */
class InMemoryNetworkProvider(
    private val fabric: InMemoryNetworkFabric,
    keySeed: String
) : RpcResponseReaderNetworkProvider {
    val peerId: String = inMemoryPeerIdFromSeed(keySeed)
    private val node: InMemoryNodeState = fabric.register(this)
    private val closed = AtomicBoolean(false)

    override fun derivePeerId(keySeed: String): String = inMemoryPeerIdFromSeed(keySeed)

    override fun listen(port: Int): NetworkListenInfo {
        checkOpen()
        return fabric.listen(node, port)
    }

    override fun dial(
        peerId: String,
        address: String,
        protocolId: String,
        timeoutMs: Long
    ): RpcStream {
        checkOpen()
        return fabric.dial(node, peerId, address, protocolId, timeoutMs)
    }

    override fun dial(
        peerId: String,
        address: String,
        protocolId: String,
        responseReader: RpcResponseReader,
        timeoutMs: Long,
    ): RpcStream {
        val stream = dial(peerId, address, protocolId, timeoutMs)
        return if (responseReader == RpcResponseReader.CALLER) CallerReadRpcStream(stream) else stream
    }

    override fun registerInboundStreamHandler(
        protocolId: String,
        handler: (RpcStream) -> Unit
    ): AutoCloseable {
        require(protocolId.isNotBlank()) {
            "Cannot register an inbound stream handler for a blank protocol ID."
        }
        checkOpen()
        fabric.stateLock.withLock {
            checkOpen()
            node.handlers[protocolId] = handler
            fabric.signalFabricLocked()
        }
        return AutoCloseable {
            fabric.stateLock.withLock {
                if (node.handlers[protocolId] === handler) {
                    node.handlers.remove(protocolId)
                    fabric.signalFabricLocked()
                }
            }
        }
    }

    override fun addConnectionListener(listener: (NetworkConnectionEvent) -> Unit): AutoCloseable {
        checkOpen()
        fabric.stateLock.withLock {
            checkOpen()
            node.listeners += listener
        }
        return AutoCloseable {
            fabric.stateLock.withLock { node.listeners.remove(listener) }
        }
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) fabric.unregister(node)
    }

    private fun checkOpen() {
        check(!closed.get()) {
            "InMemoryNetworkProvider for node '$peerId' is closed and cannot perform network operations."
        }
    }
}

internal class InMemoryBoundedPipe(
    private val fabric: InMemoryNetworkFabric,
    val sourcePeerId: String,
    val destinationPeerId: String,
    val protocolId: String
) {
    private val bytes = fabric.acquirePipeBufferLocked()
    private var readIndex = 0
    private var writeIndex = 0
    var size: Int = 0
        private set
    private var bufferedBytesAccounted = true
    private var bufferReleased = false
    private var closed = false
    private var abrupt = false
    private var closeReason = "The in-memory stream closed."

    val input = object : InputStream() {
        override fun read(): Int {
            val one = ByteArray(1)
            return if (read(one, 0, 1) < 0) -1 else one[0].toInt() and 0xff
        }

        override fun read(target: ByteArray, offset: Int, length: Int): Int {
            requireBufferBounds(target, offset, length)
            if (length == 0) return 0
            fabric.stateLock.withLock {
                while (true) {
                    val allowance = fabric.readerAllowanceLocked(destinationPeerId, length)
                    if (size > 0 && allowance > 0) {
                        val count = minOf(size, allowance, length)
                        val firstCopyCount = minOf(count, bytes.size - readIndex)
                        System.arraycopy(bytes, readIndex, target, offset, firstCopyCount)
                        val secondCopyCount = count - firstCopyCount
                        if (secondCopyCount > 0) {
                            System.arraycopy(bytes, 0, target, offset + firstCopyCount, secondCopyCount)
                        }
                        readIndex = (readIndex + count) % bytes.size
                        size -= count
                        if (bufferedBytesAccounted) {
                            fabric.adjustBufferedBytesLocked(destinationPeerId, -count)
                        }
                        fabric.consumeReaderAllowanceLocked(destinationPeerId, count)
                        releaseBufferIfEmptyAndClosedLocked()
                        fabric.signalFabricLocked(this@InMemoryBoundedPipe)
                        return count
                    }
                    if (closed && size == 0) {
                        if (abrupt) throw IOException(closeReason)
                        return -1
                    }
                    fabric.waitForStateSignalLocked(
                        this@InMemoryBoundedPipe,
                        "Inbound read from '$sourcePeerId' to '$destinationPeerId' was interrupted."
                    )
                }
            }
        }
    }

    val output = object : OutputStream() {
        override fun write(value: Int) {
            write(byteArrayOf(value.toByte()), 0, 1)
        }

        override fun write(source: ByteArray, offset: Int, length: Int) {
            requireBufferBounds(source, offset, length)
            if (length == 0) return
            val deadline = fabric.clock.currentTimeMillis() + fabric.writeTimeoutMs
            var attempt: InMemoryWriteAttempt? = null
            var scheduled: Scheduled? = null
            var written = 0
            try {
                fabric.stateLock.withLock {
                    while (written < length) {
                        if (closed) {
                            val failure = IOException(
                                "In-memory write failed: sourcePeerId='$sourcePeerId', " +
                                    "destinationPeerId='$destinationPeerId', requestedBytes=$length, " +
                                    "writtenBytes=$written, bufferedBytes=$size, capacityBytes=${bytes.size}. $closeReason"
                            )
                            if (written == 0) {
                                throw StreamClosedBeforeWriteException(
                                    "in-memory stream from $sourcePeerId to $destinationPeerId", failure
                                )
                            }
                            throw failure
                        }
                        if (attempt?.timedOut == true) {
                            throw IOException(
                                "In-memory write timed out: sourcePeerId='$sourcePeerId', " +
                                    "destinationPeerId='$destinationPeerId', requestedBytes=$length, " +
                                    "writtenBytes=$written, bufferedBytes=$size, capacityBytes=${bytes.size}, " +
                                    "timeoutMs=${fabric.writeTimeoutMs}."
                            )
                        }
                        val available = bytes.size - size
                        if (available > 0) {
                            val count = minOf(available, length - written)
                            val firstCopyCount = minOf(count, bytes.size - writeIndex)
                            System.arraycopy(source, offset + written, bytes, writeIndex, firstCopyCount)
                            val secondCopyCount = count - firstCopyCount
                            if (secondCopyCount > 0) {
                                System.arraycopy(source, offset + written + firstCopyCount, bytes, 0, secondCopyCount)
                            }
                            writeIndex = (writeIndex + count) % bytes.size
                            size += count
                            fabric.adjustBufferedBytesLocked(destinationPeerId, count)
                            written += count
                            fabric.recordWrittenBytesLocked(
                                sourcePeerId,
                                destinationPeerId,
                                protocolId,
                                count
                            )
                            fabric.signalFabricLocked(this@InMemoryBoundedPipe)
                            continue
                        }
                        if (attempt == null) {
                            attempt = InMemoryWriteAttempt()
                            scheduled = fabric.scheduleDeadline(
                                deadline,
                                InMemoryDeadlineKind.BLOCKING_OPERATION
                            ) {
                                fabric.stateLock.withLock {
                                    attempt?.timedOut = true
                                    fabric.signalFabricLocked(this@InMemoryBoundedPipe)
                                }
                            }
                            if (attempt?.timedOut == true) continue
                        }
                        fabric.waitForStateSignalLocked(
                            this@InMemoryBoundedPipe,
                            "Outbound write from '$sourcePeerId' to '$destinationPeerId' was interrupted."
                        )
                    }
                }
            } finally {
                scheduled?.let(fabric::unscheduleDeadline)
            }
        }
    }

    fun closeLocked(abrupt: Boolean, reason: String) {
        closed = true
        this.abrupt = abrupt
        closeReason = reason
        if (bufferedBytesAccounted) {
            fabric.adjustBufferedBytesLocked(destinationPeerId, -size)
            bufferedBytesAccounted = false
        }
        if (abrupt) {
            size = 0
            readIndex = 0
            writeIndex = 0
        }
        releaseBufferIfEmptyAndClosedLocked()
    }

    private fun releaseBufferIfEmptyAndClosedLocked() {
        if (closed && size == 0 && !bufferReleased) {
            bufferReleased = true
            fabric.releasePipeBufferLocked(bytes)
        }
    }
}

internal class InMemoryRpcStream(
    private val fabric: InMemoryNetworkFabric,
    private val connection: InMemoryConnection,
    private val inputPipe: InMemoryBoundedPipe,
    private val outputPipe: InMemoryBoundedPipe,
    override val remotePeerId: String,
    override val serviceIdentifier: String
) : RpcResponseReaderOwnership {
    override val ownsResponseReader: Boolean = false
    private val open = AtomicBoolean(true)
    private val streamInput = object : InputStream() {
        override fun read(): Int = inputPipe.input.read()
        override fun read(target: ByteArray, offset: Int, length: Int): Int =
            inputPipe.input.read(target, offset, length)
        override fun close() = this@InMemoryRpcStream.close()
    }
    private val streamOutput = object : OutputStream() {
        override fun write(value: Int) = outputPipe.output.write(value)
        override fun write(source: ByteArray, offset: Int, length: Int) =
            outputPipe.output.write(source, offset, length)
        override fun flush() = outputPipe.output.flush()
        override fun close() = this@InMemoryRpcStream.close()
    }

    override val input: InputStream get() = streamInput
    override val output: OutputStream get() = streamOutput
    override val isOpen: Boolean get() = open.get() && connection.isOpen()

    override fun sendRequest(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse {
        return sendRequestInternal(request, raw = false)
    }

    override fun sendRequestRaw(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse {
        return sendRequestInternal(request, raw = true)
    }

    override suspend fun sendRequestAsync(
        request: Libp2pRpcProtocol.RpcRequest
    ): Libp2pRpcProtocol.RpcResponse = sendRequest(request)

    private fun sendRequestInternal(
        request: Libp2pRpcProtocol.RpcRequest,
        raw: Boolean
    ): Libp2pRpcProtocol.RpcResponse {
        if (!isOpen) {
            return localTransportFailureResponse(
                request.id,
                "Stream closed",
                RpcTransportFailure.Phase.CONNECTION_CLOSED,
                null,
            )
        }
        val attachments = mutableListOf<ByteArray>()
        // Caller input serialization is independent of writing the encoded request.
        val json = request.toJson(attachments)
        var phase = RpcTransportFailure.Phase.REQUEST_WRITE
        return try {
            Libp2pRpcProtocol.writeMessage(output, json, attachments)
            phase = RpcTransportFailure.Phase.RESPONSE_READ
            fabric.runUntilIdle()
            val frame = Libp2pRpcProtocol.readMessageFrameFromStream(input)
            if (raw) {
                Libp2pRpcProtocol.resolveBinaryRefsToBase64(frame.json, frame.attachments)
                Libp2pRpcProtocol.RpcResponse.fromJsonRaw(frame.json)
            } else {
                Libp2pRpcProtocol.RpcResponse.fromJson(frame.json, frame.attachments)
            }
        } catch (failure: IOException) {
            val reportedFailure = inMemoryRpcFailureWithWriteDetails(failure)
            localTransportFailureResponse(
                request.id,
                "Failed to send request: ${reportedFailure.message}",
                if (phase == RpcTransportFailure.Phase.RESPONSE_READ && !isOpen) {
                    RpcTransportFailure.Phase.CONNECTION_CLOSED
                } else phase,
                reportedFailure,
            )
        }
    }

    override fun close() {
        if (open.compareAndSet(true, false)) {
            val reason = "The in-memory RPC stream between '${connection.first.peerId}' and " +
                "'${connection.second.peerId}' closed gracefully."
            fabric.closeEndpoint(connection, this, reason)
        }
    }

    fun markClosed() {
        open.set(false)
    }
}

private fun inMemoryRpcFailureWithWriteDetails(failure: IOException): IOException {
    if (failure !is StreamClosedBeforeWriteException) return failure
    val detail = failure.cause as? IOException ?: return failure
    // RPC callers keep the established write diagnostic and the zero-admission type.
    // Retain the raw-output marker too, so reporting never discards a transport cause.
    return StreamClosedBeforeWriteException(failure.streamDescription, checkNotNull(detail.message), failure)
}

internal class InMemoryNodeState(
    val provider: InMemoryNetworkProvider,
    val peerId: String,
    val address: String
) {
    var listening = false
    var dialable = true
    var killed = false
    var closed = false
    val handlers = LinkedHashMap<String, (RpcStream) -> Unit>()
    val listeners = mutableListOf<(NetworkConnectionEvent) -> Unit>()
    val connections = LinkedHashSet<InMemoryConnection>()
}

internal class InMemoryConnection(
    val sequence: Long,
    val fabric: InMemoryNetworkFabric,
    val first: InMemoryNodeState,
    val second: InMemoryNodeState,
    val firstToSecond: InMemoryBoundedPipe,
    val secondToFirst: InMemoryBoundedPipe
) {
    val closed = AtomicBoolean(false)
    var abrupt = false
    var firstEndpoint: InMemoryRpcStream? = null
    var secondEndpoint: InMemoryRpcStream? = null
    var firstEndpointUsable = true
    var secondEndpointUsable = true

    fun markEndpointAndPeerUnusable(endpoint: InMemoryRpcStream) {
        check(endpoint === firstEndpoint || endpoint === secondEndpoint) {
            "Cannot close an in-memory stream endpoint that does not belong to this connection."
        }
        if (endpoint === firstEndpoint) firstEndpointUsable = false else secondEndpointUsable = false
        if (endpoint === firstEndpoint) secondEndpointUsable = false else firstEndpointUsable = false
        firstEndpoint?.markClosed()
        secondEndpoint?.markClosed()
    }

    fun isOpen(): Boolean = !closed.get()
    fun connects(nodeA: String, nodeB: String): Boolean =
        (first.peerId == nodeA && second.peerId == nodeB) ||
            (first.peerId == nodeB && second.peerId == nodeA)

    fun pipes(): List<InMemoryBoundedPipe> = listOf(firstToSecond, secondToFirst)
}

internal class InMemoryCallbackTask(
    val connectionSequence: Long,
    val eventOrder: Int,
    val endpointOrder: Int,
    val listenerOrder: Int,
    val callback: () -> Unit
) {
    companion object {
        val ORDERING = compareBy<InMemoryCallbackTask>(
            { it.connectionSequence },
            { it.eventOrder },
            { it.endpointOrder },
            { it.listenerOrder }
        )
    }
}

internal class InMemoryDialAttempt {
    var state: InMemoryDialAttemptState = InMemoryDialAttemptState.PENDING
}

internal class InMemoryWriteAttempt {
    var timedOut = false
}

internal enum class InMemoryDialAttemptState {
    PENDING,
    TIMED_OUT,
    SUCCEEDED
}

internal class InMemoryInboundHandlerTask(
    val sequence: Long,
    val handler: () -> Unit,
    val onFailureLocked: (Throwable) -> Unit,
    val turnAvailable: Condition,
    val fabricSignalAvailable: Condition
) {
    var waitingForFabricSignal = false
    var fabricSignalKey: Any? = null
    var suspendedForDrain = false
    var passedStartBarrier = false
    var worker: Thread? = null

    companion object {
        val ORDERING = compareBy<InMemoryInboundHandlerTask> { task -> task.sequence }
    }
}

internal class InMemoryDrainCycle(
    initialStopAtClockBoundary: Boolean
) {
    @Volatile
    var stopAtClockBoundary = initialStopAtClockBoundary
    var completed = false
    var generation = -1L
    var failure: Throwable? = null
    var result: FabricDrainResult? = null
    var resultUsesClockBoundaryMode = false
}

internal sealed class InMemoryReaderMode {
    object Stalled : InMemoryReaderMode()

    class Slow(val bytesPerTick: Int) : InMemoryReaderMode() {
        var availableBytes: Int = 0
        var scheduled: Scheduled? = null
    }
}

internal enum class InMemoryDeadlineKind {
    BLOCKING_OPERATION,
    READER_TICK
}

internal class InMemoryFabricScheduledTask(
    val sequence: Long,
    val deadlineMillis: Long,
    val kind: InMemoryDeadlineKind,
    val fabric: InMemoryNetworkFabric
) : Scheduled {
    var delegate: Scheduled? = null
    var active = true
    var firing = false

    override fun cancel() {
        fabric.unscheduleDeadline(this)
    }

    companion object {
        val ORDERING = compareBy<InMemoryFabricScheduledTask>(
            { task -> task.deadlineMillis },
            { task -> task.sequence }
        )
    }
}

internal data class InMemoryNodePair(val first: String, val second: String) {
    companion object {
        fun of(nodeA: String, nodeB: String): InMemoryNodePair =
            if (nodeA <= nodeB) InMemoryNodePair(nodeA, nodeB) else InMemoryNodePair(nodeB, nodeA)
    }
}

internal fun inMemoryPeerIdFromSeed(seed: String): String {
    require(seed.isNotBlank()) { "Cannot derive an in-memory peer ID from a blank key seed." }
    val encodedSeed = Base64.getUrlEncoder().withoutPadding().encodeToString(seed.toByteArray(Charsets.UTF_8))
    return "in-memory-$encodedSeed"
}

internal fun isInMemoryPeerId(value: String): Boolean {
    if (!value.startsWith("in-memory-")) return false
    val bytes = try {
        Base64.getUrlDecoder().decode(value.substring("in-memory-".length))
    } catch (failure: IllegalArgumentException) {
        return false
    }
    val seed = bytes.toString(Charsets.UTF_8)
    // Derive again to reject padding, noncanonical trailing bits and invalid UTF-8. Seeds have
    // no length cap; this provider's base64 conversion is linear, unlike libp2p's base58 conversion.
    return seed.isNotBlank() && inMemoryPeerIdFromSeed(seed) == value
}

internal fun requireBufferBounds(bytes: ByteArray, offset: Int, length: Int) {
    if (offset < 0 || length < 0 || offset > bytes.size - length) {
        throw IndexOutOfBoundsException(
            "Invalid byte range: offset=$offset, length=$length, arraySize=${bytes.size}."
        )
    }
}

internal fun MutableMap<String, Long>.increment(key: String, amount: Long) {
    this[key] = (this[key] ?: 0L) + amount
}

private fun <K, V> immutableMapCopy(source: Map<K, V>): Map<K, V> =
    Collections.unmodifiableMap(LinkedHashMap(source))

internal fun waitOnMonitorLocked(lock: Object, interruptedMessage: String) {
    try {
        lock.wait()
    } catch (interrupted: InterruptedException) {
        Thread.currentThread().interrupt()
        throw IOException(interruptedMessage, interrupted)
    }
}

internal fun awaitConditionLocked(condition: Condition, interruptedMessage: String) {
    try {
        condition.await()
    } catch (interrupted: InterruptedException) {
        Thread.currentThread().interrupt()
        throw IOException(interruptedMessage, interrupted)
    }
}

internal val inMemoryCurrentInboundHandler = ThreadLocal<InMemoryInboundHandlerTask?>()
