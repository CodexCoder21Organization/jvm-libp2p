package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.logging.MessageSeverity
import io.libp2p.core.ChannelVisitor
import io.libp2p.core.Connection
import io.libp2p.core.ConnectionClosedException
import io.libp2p.core.Stream
import io.netty.channel.Channel
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import io.netty.channel.ChannelOutboundHandlerAdapter
import io.netty.channel.ChannelPromise
import io.libp2p.multistream.Negotiator
import io.netty.util.AttributeKey
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CompletionException
import java.util.concurrent.ExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.algebraiceffects.`$effectHandlerRepository`
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.toss

// A positive one-stream budget must drain at zero too; use Long to avoid overflow for large caps.
private fun inboundAdmissionLowWater(cap: Int): Int =
    (cap.toLong() * 3L / 4L).coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()

private fun reportInboundAdmissionCleanupFailure(channel: Channel?, failure: Throwable) {
    // CompletableFuture captures exceptions thrown by a completion action. Route cleanup failures
    // to Netty's normal exception path rather than leaving them in an unobserved dependent future.
    if (channel != null) channel.pipeline().fireExceptionCaught(failure)
    else Thread.currentThread().let { it.uncaughtExceptionHandler.uncaughtException(it, failure) }
}

/** Delivery of a record that has nothing left to deliver. */
private val NO_PENDING_RECORD: () -> Throwable? = { null }

/** [record]'s delivery, returning [earlierFatal] first when a record already raised one. */
private fun withEarlierFatal(earlierFatal: Throwable?, record: () -> Throwable?): () -> Throwable? =
    if (earlierFatal == null) record else { { combineFatal(earlierFatal, record()) } }

/** Keeps the first fatal error and attaches any later, distinct one to it. */
private fun combineFatal(first: Throwable?, next: Throwable?): Throwable? {
    if (first == null) return next
    if (next != null && next !== first) first.addSuppressed(next)
    return first
}

/**
 * Finishes a path whose actions ran before its records were delivered. An action's own failure
 * propagates exactly as before the records existed, unless a record raised a fatal JVM error while
 * the action's failure is not fatal; then the fatal error propagates with the action's failure
 * attached, so neither is lost.
 */
private fun rethrowAfterRecords(actionFailure: Throwable?, recordFatal: Throwable?) {
    val primary = when {
        actionFailure == null -> recordFatal
        recordFatal == null || recordFatal === actionFailure -> actionFailure
        isFatalJvmError(actionFailure) -> actionFailure.also { it.addSuppressed(recordFatal) }
        else -> recordFatal.also { it.addSuppressed(actionFailure) }
    }
    if (primary != null) throw primary
}

private fun unwrapInboundAdmissionCloseFailure(failure: Throwable): Throwable {
    var current = failure
    while ((current is CompletionException || current is ExecutionException) && current.cause != null) {
        current = current.cause!!
    }
    return current
}

internal enum class InboundAdmissionManualReadPhase {
    IDLE,
    TASK_QUEUED,
    READ_PENDING,
}

private class InboundAutoReadCapture(val generation: Long, val observedAtNanos: Long)

/**
 * State shared by the admission controller and attachment decoders for one physical parent.
 * Admission changes and a decoder's one-shot manual-read request use the same monitor so a
 * decoder cannot observe an unmarked pause while the admission controller is engaging it.
 */
internal class InboundPhysicalReadState(private val clock: Clock = SystemClock()) {
    var pausedByInboundAdmission: Boolean = false
        private set
    private var pauseStartedAtNanos: Long? = null
    private var completedPauseNanos: Long = 0L
    // Unlike manualReadGeneration, this changes only when the observed read state changes.
    // Both fields are guarded by this state's existing caller-held monitor.
    private var autoReadGeneration: Long = 0L
    private var autoReadCapture: InboundAutoReadCapture? = null
    /** Guarded by this state's monitor. */
    var manualReadPumpInstalled: Boolean = false
    /** The one allowed manual-read phase for the current admission-pause generation. */
    var manualReadPhase: InboundAdmissionManualReadPhase = InboundAdmissionManualReadPhase.IDLE
    /** Invalidates queued work whenever the physical parent enters or leaves an admission pause. */
    var manualReadGeneration: Long = 0L

    /**
     * Records a parent state confirmed by a successful update or physical readback.
     *
     * The caller must hold this state's monitor and supply the timestamp captured before any
     * update callback. Every pause boundary also retires queued or pending work from the old read
     * lifecycle, so a later pause cannot mistake it for coverage.
     */
    fun recordObservedAutoRead(autoRead: Boolean, observedAtNanos: Long) {
        val paused = !autoRead
        if (pausedByInboundAdmission == paused) return
        if (paused) {
            pauseStartedAtNanos = observedAtNanos
        } else {
            val startedAt = pauseStartedAtNanos
            if (startedAt != null) {
                completedPauseNanos += (observedAtNanos - startedAt).coerceAtLeast(0L)
            }
            pauseStartedAtNanos = null
        }
        pausedByInboundAdmission = paused
        autoReadGeneration++
        manualReadGeneration++
        manualReadPhase = InboundAdmissionManualReadPhase.IDLE
    }

    /** Share the earliest in-progress observation only within the same read-state generation. */
    fun applyAutoReadChange(update: () -> Boolean) {
        val previousCapture = autoReadCapture
        val capture = previousCapture?.takeIf { it.generation == autoReadGeneration }
            ?: InboundAutoReadCapture(
                autoReadGeneration,
                java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(clock.currentTimeMillis()),
            )
        autoReadCapture = capture
        try {
            val autoRead = update()
            // A nested recovery may be the first successful readback of this transition. It
            // must commit the outer timestamp. After an intervening transition, the older
            // capture cannot describe another change observed as this call unwinds.
            val observedAtNanos = if (capture.generation == autoReadGeneration) {
                capture.observedAtNanos
            } else {
                java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(clock.currentTimeMillis())
            }
            recordObservedAutoRead(autoRead, observedAtNanos)
        } finally {
            // A throwing update leaves accounting alone and cannot retain an armed capture.
            autoReadCapture = previousCapture
        }
    }

    /** Total time that this physical parent has been observed with admission reads paused. */
    fun pausedNanosThrough(nowNanos: Long): Long {
        val activePauseNanos = pauseStartedAtNanos?.let { startedAt ->
            (nowNanos - startedAt).coerceAtLeast(0L)
        } ?: 0L
        return completedPauseNanos + activePauseNanos
    }
}

/**
 * Keeps one explicit socket read pending while per-connection admission has disabled `autoRead`.
 *
 * A pending read observes either the peer's FIN or its next frame. A FIN lets Netty close the
 * connection and release every reservation it holds. A bounded burst of new inbound streams may
 * use the hard-limit headroom while ordinary work drains; the next stream beyond that hard limit
 * resets only that child and defers accepted-root retirement until both directions are idle.
 * Re-arming only after `channelReadComplete` preserves the one-read-at-a-time boundary instead
 * of restoring automatic reads.
 */
private class InboundAdmissionManualReadPump(
    private val reportFailure: (Throwable) -> Unit,
) : ChannelInboundHandlerAdapter() {
    override fun channelReadComplete(ctx: ChannelHandlerContext) {
        super.channelReadComplete(ctx)
        val state = inboundPhysicalReadStateFor(ctx.channel())
        synchronized(state) {
            if (state.manualReadPhase == InboundAdmissionManualReadPhase.READ_PENDING) {
                state.manualReadPhase = InboundAdmissionManualReadPhase.IDLE
            }
        }
        try {
            scheduleInboundAdmissionManualRead(ctx.channel(), reportFailure)
        } catch (failure: Throwable) {
            restoreInboundAdmissionReads(ctx.channel(), failure)
            reportFailure(failure)
        }
    }
}

/**
 * Keeps at most one physical manual read pending while inbound admission owns the pause.
 *
 * The event-loop task is required both for the first read after installing the pump and for every
 * later re-arm. The first installation can happen after the current physical read-complete event
 * has already passed the pump's new pipeline position, and an inline read from either boundary can
 * be consumed by the cycle that is still unwinding.
 */
private fun scheduleInboundAdmissionManualRead(channel: Channel, reportFailure: (Throwable) -> Unit) {
    val state = inboundPhysicalReadStateFor(channel)
    val scheduledGeneration = synchronized(state) {
        if (
            !state.pausedByInboundAdmission ||
            state.manualReadPhase != InboundAdmissionManualReadPhase.IDLE ||
            !channel.isActive
        ) {
            null
        } else {
            state.manualReadPhase = InboundAdmissionManualReadPhase.TASK_QUEUED
            state.manualReadGeneration
        }
    }
    if (scheduledGeneration == null) return

    // Submission failures reach the caller, which restores reads before reporting outside the
    // physical-state monitor. The asynchronous read has the same recovery boundary below.
    channel.eventLoop().execute {
        val shouldRead = synchronized(state) {
            if (
                state.manualReadGeneration != scheduledGeneration ||
                state.manualReadPhase != InboundAdmissionManualReadPhase.TASK_QUEUED
            ) {
                false
            } else if (!state.pausedByInboundAdmission || !channel.isActive) {
                state.manualReadPhase = InboundAdmissionManualReadPhase.IDLE
                false
            } else {
                state.manualReadPhase = InboundAdmissionManualReadPhase.READ_PENDING
                true
            }
        }
        if (shouldRead) {
            try {
                channel.read()
            } catch (failure: Throwable) {
                restoreInboundAdmissionReads(channel, failure)
                reportFailure(failure)
            }
        }
    }
}

/** Restore physical reads and their accounting before any failure observer can re-enter. */
private fun restoreInboundAdmissionReads(channel: Channel, failure: Throwable) {
    val state = inboundPhysicalReadStateFor(channel)
    synchronized(state) {
        // Invalidate even a failed initial submission whose phase never reached READ_PENDING.
        state.manualReadGeneration++
        state.manualReadPhase = InboundAdmissionManualReadPhase.IDLE
        // Recovery must restore read demand as well as the flag: Netty sets autoRead=true
        // before dispatching its read, so a rejected resume can leave the flag true without
        // a socket read. The old controlled read was invalidated above. Explicitly hand off
        // fresh demand even if the setter saw true already or changed the flag before failing.
        // Capture the transition time before either operation can dispatch an inline callback.
        // Netty coalesces read demand; this does not resend any request or response bytes.
        try {
            state.applyAutoReadChange {
                try {
                    channel.config().isAutoRead = true
                } catch (restoreFailure: Throwable) {
                    if (restoreFailure !== failure) failure.addSuppressed(restoreFailure)
                }
                try {
                    channel.read()
                } catch (readFailure: Throwable) {
                    if (readFailure !== failure) failure.addSuppressed(readFailure)
                }
                // A setter can change autoRead and then throw from the read it initiates. Observe
                // the actual value after both restore attempts have completed.
                channel.config().isAutoRead
            }
        } catch (observationFailure: Throwable) {
            if (observationFailure !== failure) failure.addSuppressed(observationFailure)
        }
    }
}

private const val INBOUND_ADMISSION_MANUAL_READ_PUMP: String =
    "foundation.url.protocol.inboundAdmissionManualReadPump"

private const val MIN_INBOUND_CONTROLLED_READ_HEADROOM: Int = 2
private const val MAX_INBOUND_CONTROLLED_READ_HEADROOM: Int = 64

internal val INBOUND_PHYSICAL_READ_STATE_ATTR: AttributeKey<InboundPhysicalReadState> =
    AttributeKey.valueOf("foundation.url.protocol.inboundPhysicalReadState")

internal val RPC_READ_IDLE_CLOCK_ATTR: AttributeKey<Clock> =
    AttributeKey.valueOf("foundation.url.protocol.rpcReadIdleClock")

internal fun inboundPhysicalReadStateFor(channel: Channel): InboundPhysicalReadState {
    val attr = channel.attr(INBOUND_PHYSICAL_READ_STATE_ATTR)
    return attr.get() ?: attr.setIfAbsent(
        InboundPhysicalReadState(channel.attr(RPC_READ_IDLE_CLOCK_ATTR).get() ?: SystemClock())
    ) ?: attr.get()!!
}

/**
 * Whether inbound reads on [channel]'s physical connection are currently held by admission control.
 *
 * While that pause is engaged automatic reads are disabled. Admission control keeps one explicit
 * read pending so FIN and admitted traffic remain observable, but callers must not treat that
 * controlled read as ordinary response capacity. The root is at its admission boundary,
 * so new requests should wait until ordinary response reads resume.
 */
internal fun inboundReadsPausedByAdmission(channel: Channel): Boolean {
    val state = inboundPhysicalReadStateFor(channel)
    return synchronized(state) { state.pausedByInboundAdmission }
}

/** Commits [write] only while admission control still permits response reads on [channel]. */
internal fun commitIfInboundReadsObservable(channel: Channel, write: () -> Unit): Boolean {
    val state = inboundPhysicalReadStateFor(channel)
    synchronized(state) {
        if (state.pausedByInboundAdmission) return false
        write()
        return true
    }
}

/** Runs [read] only while the inbound-substream admission pause is not engaged. */
internal fun requestPhysicalReadIfAdmissionAllows(channel: Channel, read: () -> Unit): Boolean {
    val state = inboundPhysicalReadStateFor(channel)
    synchronized(state) {
        if (state.pausedByInboundAdmission) return false
        read()
        return true
    }
}

/**
 * Admission control for INBOUND libp2p substreams (issue #294).
 *
 * Background: when many peers reconnect at once they open new inbound substreams faster than the
 * host reclaims them. jvm-libp2p builds a full Netty child channel, pipeline, multistream
 * negotiator and negotiation-timeout task for each inbound substream BEFORE any handler of ours
 * runs, including the `streamPreHandler` hook that reaches this class. A production heap dump
 * (ContainerNursery, `-Xmx128m`) showed 6,779 live `MuxChannel`s holding 46% of the heap, and the
 * process then ran out of heap (UrlProtocol #294, ContainerNursery #459).
 *
 * **Why counting admitted substreams is not enough by itself.** An earlier version counted admitted
 * substreams and called `reset()` on the excess. Because the muxer builds the scaffolding before
 * this class is consulted, and because `reset()` runs on the same event loop that is creating the
 * new substreams, creates outran reclaims whenever that loop was busy: the refused substreams piled
 * up, each held alive by its pending negotiation-timeout task. A later production heap dump showed
 * 35,783 live `MuxChannel`s across about 120 connections while the counter cap was in force.
 * Bounding the number of substreams this class knows about does not bound the heap.
 *
 * **What this class does instead: slow creation down at the TCP layer, per connection.** When one
 * connection's live inbound substreams reach the per-connection cap, this class disables `autoRead`
 * on that connection's parent channel and permits one explicit read at a time. That keeps a read
 * pending so the peer's FIN is still seen, without restoring an unrestricted read loop. A small,
 * bounded burst may enter the headroom above the pause point so a healthy peer's already-queued
 * substreams stay pending work rather than refusals. Reads return to automatic mode once the live
 * count drains below a low-water mark. Host-initiated substreams are tracked for root lifetime,
 * but never charged to the inbound capacity limit.
 *
 * **Refusal policies.** Aggregate overflow resets the new substream before negotiation while
 * preserving every live stream in either direction on its root. An idle accepted asker is retired;
 * a busy accepted asker acquires an obligation to retire after its last stream closes, even if
 * the aggregate generation has drained by then. Retirement and new admission are serialized.
 * Per-connection-only hard overflow also preserves every live stream and records a separate
 * deferred retirement reason, excluded from the aggregate idle metric. Connections dialled by
 * this host are exempt from both retirement paths.
 *
 * **Read policy and retained resources.** Aggregate engagement suspends ordinary per-connection
 * pauses. An accepted busy root spared after refusal is throttled for that exact aggregate
 * generation; terminal roots remain throttled until physical close completes. The controlled read pump keeps one read pending and yields between read cycles, so
 * FIN and admitted traffic remain observable. The muxer's independent live-child ceiling bounds
 * scaffolding per root; deferred retirement prevents a history of spared roots accumulating when
 * their work finishes. Roots carrying only host-initiated work remain owned by those streams,
 * independently of the inbound aggregate count. Refusal throttles cannot survive their generation
 * draining or attach to a later generation.
 */

/**
 * Reports that the aggregate inbound-substream cap became engaged, so inbound substreams are being
 * refused across the host.
 *
 * Emitted when the cap first engages and rate-limited to at most one report per
 * [MIN_MILLIS_BETWEEN_INBOUND_ADMISSION_CAP_EFFECTS] afterwards, so a host that is saturated for a
 * long time reports at a steady low rate instead of once per refused substream. The counts are read
 * when each report is selected: [liveInboundSubstreams] is the live inbound substream count across
 * all connections, [maxInboundSubstreams] is the configured aggregate cap, and
 * [refusedInboundSubstreams] is the running total of substreams refused for exceeding a cap since
 * this admission controller was created.
 *
 * Consumers that want to alert on saturation should handle this effect. The same numbers stay
 * available on demand through [InboundSubstreamAdmissionControl.currentGlobalLive] and
 * [InboundSubstreamAdmissionControl.rejectedCount].
 */
class InboundSubstreamAdmissionCapEngagedEffect(
    val liveInboundSubstreams: Int,
    val maxInboundSubstreams: Int,
    val refusedInboundSubstreams: Int,
) : NotificationEffect(
    "Inbound substream admission is refusing new substreams: " +
        "$liveInboundSubstreams of $maxInboundSubstreams live inbound substreams are in use " +
        "across all connections, and $refusedInboundSubstreams inbound substreams have been " +
        "refused so far. Excess inbound substreams are refused; aggregate refusal throttles clear " +
        "when the live count drains below ${inboundAdmissionLowWater(maxInboundSubstreams)}.",
    MessageSeverity.WARNING
)

/**
 * Reports that a terminal inbound-admission root could not complete its physical close operation.
 *
 * [rootConnectionIdentity] identifies the exact root without retaining it. The state fields are
 * sampled after the failed close relinquishes attempt ownership: retirement remains required,
 * [retirementCloseInFlight] is false, and a later refused visit may hand off another close.
 */
class InboundSubstreamAdmissionRetirementFailureEffect(
    val rootConnectionIdentity: String,
    val retirementRequired: Boolean,
    val retirementCloseInFlight: Boolean,
    val countAsIdleRetirement: Boolean,
    val failure: Throwable,
    val rootLinkDiagnostics: RootLinkDiagnostics?,
) : NotificationEffect(
    "Inbound admission could not close retired root connection '$rootConnectionIdentity': " +
        "expected retirementRequired=true and retirementCloseInFlight=false after the failed " +
        "close operation, but actual retirementRequired=$retirementRequired and " +
        "retirementCloseInFlight=$retirementCloseInFlight; " +
        "countAsIdleRetirement=$countAsIdleRetirement; cause=${failure.javaClass.name}: " +
        (failure.message ?: "no message") + rootLinkDiagnostics.diagnosticSuffix(),
    MessageSeverity.ERROR,
    failure,
) {
    constructor(
        rootConnectionIdentity: String,
        retirementRequired: Boolean,
        retirementCloseInFlight: Boolean,
        countAsIdleRetirement: Boolean,
        failure: Throwable,
    ) : this(
        rootConnectionIdentity,
        retirementRequired,
        retirementCloseInFlight,
        countAsIdleRetirement,
        failure,
        null,
    )
}

/** Which admission decision started closing an accepted root connection. */
enum class InboundAdmissionRetirementTrigger(val description: String) {
    REFUSED_WHILE_IDLE("an inbound substream was refused while the connection held no live substream"),
    LAST_SUBSTREAM_CLOSED("the last live substream closed after retirement had been deferred"),
    READ_FAILURE_WHILE_IDLE("an admission read-state change failed while the connection held no live substream"),
    CLOSE_RETRY("a new substream arrived after an earlier close attempt had failed"),
}

/**
 * Records that inbound admission is closing an accepted root connection, and why.
 *
 * Emitted once per close attempt to the scope that constructed the admission controller, and
 * always also written to standard error as one `[InboundAdmissionRetirement]` line. The record is
 * produced only after the close it describes has completed (or failed), so neither a failure nor a
 * slow handler while producing it can prevent or hold up that close; a failure is reported through
 * the transport exception path. [reasons] lists every retirement obligation recorded on the
 * connection: `aggregate-cap-refusal`, `per-connection-overflow` and `read-failure`. The counts are
 * sampled under the admission monitor when the close is started, which on a refusal is just after
 * the refused substream's reset rather than at the refusal decision itself, so the host-wide count
 * can differ slightly from the one at the decision. A retiring connection never holds a live
 * substream, so the per-connection counts are zero unless that invariant is broken. A close that
 * never completes produces no record.
 * [rootConnectionIdentity] matches the identity in `[ConnectionClosed]` records for the same root.
 */
class InboundSubstreamAdmissionRetirementEffect(
    val rootConnectionIdentity: String,
    val reasons: List<String>,
    val trigger: InboundAdmissionRetirementTrigger,
    val remotePeerId: String,
    val remoteAddress: String,
    val liveInboundSubstreamsOnConnection: Int,
    val liveHostInitiatedSubstreamsOnConnection: Int,
    val liveInboundSubstreamsAcrossHost: Int,
    val maxInboundSubstreamsAcrossHost: Int,
    val cause: String,
    val rootLinkDiagnostics: RootLinkDiagnostics?,
) : NotificationEffect(
    "Inbound admission is closing accepted root connection '$rootConnectionIdentity' from peer " +
        "$remotePeerId at $remoteAddress: reasons=${reasons.joinToString(",")}; " +
        "trigger=$trigger (${trigger.description}); live substreams on this connection: " +
        "inbound=$liveInboundSubstreamsOnConnection, " +
        "host-initiated=$liveHostInitiatedSubstreamsOnConnection; live inbound substreams " +
        "across the host: $liveInboundSubstreamsAcrossHost of $maxInboundSubstreamsAcrossHost; " +
        "cause=$cause" + rootLinkDiagnostics.diagnosticSuffix(),
    MessageSeverity.WARNING,
) {
    constructor(rootConnectionIdentity: String, reasons: List<String>, trigger: InboundAdmissionRetirementTrigger, remotePeerId: String, remoteAddress: String, liveInboundSubstreamsOnConnection: Int, liveHostInitiatedSubstreamsOnConnection: Int, liveInboundSubstreamsAcrossHost: Int, maxInboundSubstreamsAcrossHost: Int, cause: String) : this(rootConnectionIdentity, reasons, trigger, remotePeerId, remoteAddress, liveInboundSubstreamsOnConnection, liveHostInitiatedSubstreamsOnConnection, liveInboundSubstreamsAcrossHost, maxInboundSubstreamsAcrossHost, cause, null)
}

/**
 * Records the first inbound substream that admission refused (reset) on one root connection.
 *
 * Reported at most once per root connection so a refused peer cannot turn refusals into one line
 * per substream; every refusal is still counted by [InboundSubstreamAdmissionControl.rejectedCount].
 * [reason] is `aggregate-cap`, `per-connection-cap`, `connection-retiring` (the root is already
 * terminal), or `connection-closed`. The counts are sampled at the refusal decision. Delivered like
 * [InboundSubstreamAdmissionRetirementEffect], with an `[InboundAdmissionRefusal]` standard-error
 * line, after the refused substream has been reset and after any retirement close it triggered.
 */
class InboundSubstreamRefusedEffect(
    val rootConnectionIdentity: String,
    val reason: String,
    val remotePeerId: String,
    val remoteAddress: String,
    val liveInboundSubstreamsOnConnection: Int,
    val hardPerConnectionLimit: Int,
    val liveInboundSubstreamsAcrossHost: Int,
    val maxInboundSubstreamsAcrossHost: Int,
    val rootLinkDiagnostics: RootLinkDiagnostics?,
) : NotificationEffect(
    "Inbound admission reset a refused inbound substream on root connection " +
        "'$rootConnectionIdentity' from peer $remotePeerId at $remoteAddress: reason=$reason; " +
        "live inbound substreams on this connection: $liveInboundSubstreamsOnConnection of " +
        "$hardPerConnectionLimit; live inbound substreams across the host: " +
        "$liveInboundSubstreamsAcrossHost of $maxInboundSubstreamsAcrossHost; later refusals on " +
        "this connection are counted but not reported individually" + rootLinkDiagnostics.diagnosticSuffix(),
    MessageSeverity.WARNING,
) {
    constructor(rootConnectionIdentity: String, reason: String, remotePeerId: String, remoteAddress: String, liveInboundSubstreamsOnConnection: Int, hardPerConnectionLimit: Int, liveInboundSubstreamsAcrossHost: Int, maxInboundSubstreamsAcrossHost: Int) : this(rootConnectionIdentity, reason, remotePeerId, remoteAddress, liveInboundSubstreamsOnConnection, hardPerConnectionLimit, liveInboundSubstreamsAcrossHost, maxInboundSubstreamsAcrossHost, null)
}

/** Installs the capacity decision before the responder writes its protocol acknowledgement. */
private class InboundProtocolAcknowledgementGuard(
    private val admit: (String) -> Boolean,
) : ChannelInboundHandlerAdapter() {
    override fun channelActive(ctx: ChannelHandlerContext) {
        val responder = checkNotNull(ctx.pipeline().context(Negotiator.ResponderHandler::class.java)) {
            "Inbound protocol admission requires a multistream responder before stream activation."
        }
        ctx.pipeline().addBefore(responder.name(), "inbound-protocol-capacity", object : ChannelOutboundHandlerAdapter() {
            override fun write(context: ChannelHandlerContext, message: Any, promise: ChannelPromise) {
                if (message is String && message != "/multistream/1.0.0" && message != "na") {
                    val admitted = try {
                        admit(message)
                    } catch (failure: Throwable) {
                        promise.tryFailure(failure)
                        context.close()
                        context.fireExceptionCaught(failure)
                        return
                    }
                    if (!admitted) {
                        promise.tryFailure(ConnectionClosedException("Inbound protocol '$message' was refused before acknowledgement."))
                        return
                    }
                    context.write(message, promise)
                    if (context.pipeline().context(this) != null) context.pipeline().remove(this)
                } else {
                    context.write(message, promise)
                }
            }
        })
        ctx.fireChannelActive()
        if (ctx.pipeline().context(this) != null) ctx.pipeline().remove(this)
    }
}

/** A negotiated child was reset because its own protocol category is full. */
class InboundProtocolCapacityRefusedEffect(
    val protocolId: String,
    val budget: String,
    val liveSubstreams: Int,
    val limit: Int,
) : NotificationEffect(
    "Inbound stream '$protocolId' was refused: the $budget stream budget on this connection " +
        "already holds $liveSubstreams of $limit streams; admitted streams remain open.",
    MessageSeverity.WARNING,
)

/** Separate from the unchanged 256-stream soft request cap and 64-stream request headroom. */
const val MAX_BACKGROUND_INBOUND_SUBSTREAMS_PER_CONNECTION: Int = 64

/**
 * Shortest interval between two [InboundSubstreamAdmissionCapEngagedEffect] reports.
 *
 * The cap can engage and drain repeatedly while a host is saturated, and one report per engagement
 * would be as noisy as one per refused substream. A minute is short enough that a consumer polling
 * its own alerting sees saturation promptly and long enough that a saturated host reports a bounded
 * number of times per hour.
 */
const val MIN_MILLIS_BETWEEN_INBOUND_ADMISSION_CAP_EFFECTS: Long = 60_000L

/**
 * Maximum concurrent live inbound substreams a single remote connection may hold
 * before its reads are paused (anti-monopoly bound). A healthy peer multiplexes
 * only a handful; a legitimately busy peer can burst higher, so this is generous.
 * This bounds one peer's share, not the host's total; see
 * [MAX_INBOUND_SUBSTREAMS_GLOBAL] for what does and does not bound the aggregate.
 */
const val MAX_INBOUND_SUBSTREAMS_PER_CONNECTION: Int = 256

/**
 * Maximum concurrent live inbound substreams across ALL connections before further inbound
 * substreams are refused. At about 5KB of scaffolding per substream this caps the substreams this
 * class is told about at a few MB, far above any legitimate aggregate concurrency.
 *
 * What this number does NOT by itself bound is the TRANSIENT scaffolding: the muxer builds a
 * substream's channel, pipeline, negotiator and negotiation-timeout task before the stream
 * pre-handler that reaches this class runs, and the muxer's own ceiling on that (jvm-libp2p
 * `maxInboundStreams`, 512 by default and not configured by this repository) is PER CONNECTION, so
 * across N connections it bounds N x 512 and not this number. The reject branch of [visit] explains
 * how N is bounded. Making the muxer ceiling aggregate-aware upstream would bound the transient
 * population directly and is the better long-term shape.
 */
const val MAX_INBOUND_SUBSTREAMS_GLOBAL: Int = 1024

/**
 * Tracks live inbound substreams per [Host][io.libp2p.core.Host], applies per-connection
 * TCP `autoRead` backpressure, and refuses substreams over the aggregate cap, so the
 * inbound substream heap stays bounded even when the event loop is saturated. One instance per host
 * (registered as a `streamPreHandler` visitor by [Libp2pHostFactory]).
 * Thread-safe. Exercised by the inbound-substream stress tests.
 */
class InboundSubstreamAdmissionControl(
    private val maxPerConnection: Int,
    private val maxGlobal: Int,
    private val clock: Clock,
    private val maxBackgroundSubstreamsPerConnection: Int,
) : ChannelVisitor<Stream> {
    constructor(maxPerConnection: Int, maxGlobal: Int, clock: Clock) :
        this(maxPerConnection, maxGlobal, clock, 0)

    init {
        require(maxBackgroundSubstreamsPerConnection >= 0) {
            "Background inbound substream capacity must be nonnegative, but was $maxBackgroundSubstreamsPerConnection."
        }
    }

    private val separateProtocolBudgets = maxBackgroundSubstreamsPerConnection > 0
    private val pendingNegotiationLimit = maxBackgroundSubstreamsPerConnection.coerceAtMost(64)

    // V5: Keep the historical (int,int), Kotlin default bridge, and () JVM descriptors.
    constructor(
        maxPerConnection: Int = MAX_INBOUND_SUBSTREAMS_PER_CONNECTION,
        maxGlobal: Int = MAX_INBOUND_SUBSTREAMS_GLOBAL,
    ) : this(maxPerConnection, maxGlobal, SystemClock())

    constructor() : this(MAX_INBOUND_SUBSTREAMS_PER_CONNECTION, MAX_INBOUND_SUBSTREAMS_GLOBAL, SystemClock())

    // V4: Netty callbacks report to the scope that constructed this host's admission controller.
    private val ownerEffectRepository = `$effectHandlerRepository`.get()
    private val admissionMonitor = Any()
    @Volatile private var aggregateGeneration: Long = 0
    private var nextAggregateGeneration: Long = 0


    /**
     * Extra live children allowed after the soft pause point before a hard refusal.
     *
     * The quarter-cap share matches the existing 75% low-water hysteresis: one ordinary burst can
     * arrive while the earlier work drains, but its retained scaffolding remains a fixed fraction
     * of the configured cap. Two slots keep very small test and embedded caps useful for a normal
     * stream pair; 64 slots cap the shipped 256-stream setting at 320 live children.
     */
    private val controlledReadHeadroom: Int = if (maxPerConnection <= 0) {
        0
    } else {
        (maxPerConnection / 4)
            .coerceAtLeast(MIN_INBOUND_CONTROLLED_READ_HEADROOM)
            .coerceAtMost(MAX_INBOUND_CONTROLLED_READ_HEADROOM)
            .coerceAtMost(maxPerConnection)
    }

    private val hardPerConnectionLimit: Int =
        (maxPerConnection.toLong() + controlledReadHeadroom.toLong())
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()

    private class ConnState(val connection: Connection, @Volatile var channel: io.netty.channel.Channel?) {
        /** Inbound substreams admitted on this connection and not yet closed. */
        val live = AtomicInteger(0)
        /** Negotiated request occupancy; the other category counts use admissionMonitor. */
        val requests = AtomicInteger(0)
        var background: Int = 0
        var negotiating: Int = 0
        /** Host-initiated children owned by this root; guarded by admissionMonitor. */
        var initiatedLive: Int = 0
        val pausedByConn = AtomicBoolean(false)

        /**
         * Set while this connection was refused an inbound substream although it was doing accepted
         * work, so it was spared instead of closed. It is throttled at the TCP layer for as long as
         * the aggregate cap is engaged; see the reject branch of `visit`.
         */
        @Volatile var refusalGeneration: Long = 0
        // Terminal retirement excludes subsequent reservations, including between close attempts.
        var retirementRequired: Boolean = false
        // Unlike cap generations and per-connection hysteresis, this read reason survives a failed
        // close. Only physical close completion clears it. Sampled under the physical monitor.
        @Volatile var terminalReadPause: Boolean = false
        // A failed close operation makes another attempt eligible without admitting new work.
        var retirementCloseInFlight: Boolean = false
        // Only aggregate refusal contributes to the aggregate idle-retirement counter.
        var countAsIdleRetirement: Boolean = false
        // Unlike the throttle, retirement survives generation drain: historical spared roots
        // cannot accumulate when successive saturation episodes finish their work.
        var retireWhenIdle: Boolean = false
        // I1: Per-connection overload records an independent deferred reason. It cannot close
        // admitted work or turn a per-connection retirement into an aggregate idle retirement.
        var retireAfterPerConnectionOverflow: Boolean = false
        var retireAfterReadFailure: Boolean = false
        // Only the first refused inbound substream on a root is reported; guarded by admissionMonitor.
        var refusalReported: Boolean = false
    }

    private val conns = ConcurrentHashMap<Connection, ConnState>()
    private val globalLive = AtomicInteger(0)
    private val globalNegotiating = AtomicInteger(0)
    private val totalInboundSeen = AtomicInteger(0)
    private val rejectedCount = AtomicInteger(0)
    private val shedIdleConnectionCount = AtomicInteger(0)
    private val maxObservedGlobalLive = AtomicInteger(0)
    /** Report baseline in the injected clock's timeline; guarded by admissionMonitor. */
    private var lastCapEngagedReportAtMillis: Long? = null

    /** Admitted inbound streams; separate protocol budgets admit only at protocol selection. */
    fun currentGlobalLive(): Int = globalLive.get()

    /** Factory-policy negotiations still awaiting admission, also charged to the aggregate cap. */
    fun currentGlobalNegotiating(): Int = globalNegotiating.get()

    /** Total inbound substreams observed since this admission controller was created. */
    fun totalInboundSeen(): Int = totalInboundSeen.get()

    /** Highest admitted [currentGlobalLive] value ever observed (test instrumentation). */
    fun maxObservedGlobalLive(): Int = maxObservedGlobalLive.get()

    /** Total inbound substreams reset for exceeding a hard cap (race fallback). */
    fun rejectedCount(): Int = rejectedCount.get()

    /**
     * Accepted connections closed as a last resort after being refused an inbound substream.
     *
     * Counts completed, exactly-once aggregate retirements of idle accepted connections, including
     * a spared connection whose last live stream in either direction closes after its cap generation
     * drains. Per-connection-only deferred retirement does not contribute to this count.
     */
    fun shedIdleConnectionCount(): Int = shedIdleConnectionCount.get()

    /**
     * Number of connections whose own per-connection admission pause is currently engaged.
     *
     * Conservative in the safe direction for that per-connection pause: a connection stays counted
     * here until its resume has reached the physical parent channel, so this count never reports a
     * connection as free of its own admission pause while that pause is still on the channel. It may
     * briefly count a connection whose pause has not reached the channel yet.
     *
     * This is deliberately not an answer to "is this connection reading?", and the two can differ
     * in BOTH directions: aggregate engagement suspends ordinary per-connection pauses, but
     * a busy accepted root spared after an aggregate refusal has its own deliberate throttle.
     * The authoritative per-channel answer, which is the one the relay paths consult before
     * committing a request, is `inboundReadsPausedByAdmission`.
     */
    fun pausedConnectionCount(): Int = conns.values.count { it.pausedByConn.get() }

    /**
     * Whether the aggregate cap is engaged, i.e. live inbound substreams across all connections
     * have reached [maxGlobal] and have not since drained below its low-water mark.
     *
     * Engagement suspends ordinary per-connection pauses. A busy accepted connection spared
     * after an aggregate refusal is deliberately throttled with one controlled read pending;
     * its throttle expires with this aggregate generation.
     */
    fun isGloballyPaused(): Boolean = (aggregateGeneration != 0L)

    override fun visit(stream: Stream) {
        val inbound = !stream.isInitiator
        if (inbound) totalInboundSeen.incrementAndGet()
        val connection = stream.connection
        val candidate = ConnState(connection, parentChannelOf(stream))
        val installed = conns.putIfAbsent(connection, candidate)
        val st = installed ?: candidate
        if (installed == null) {
            // I5: Publish before attaching a possibly inline close callback. Only the winning
            // publisher attaches cleanup, and an old callback can remove only its own state.
            // Cleanup failures go to transport reporting, never an ignored completion stage.
            connection.closeFuture().whenComplete { _, closeFailure ->
                st.terminalReadPause = false
                try { conns.remove(connection, st) }
                catch (cleanupFailure: Throwable) {
                    if (closeFailure != null && closeFailure !== cleanupFailure) cleanupFailure.addSuppressed(closeFailure)
                    reportInboundAdmissionCleanupFailure(st.channel, cleanupFailure)
                    return@whenComplete
                }
                if (closeFailure != null) reportInboundAdmissionCleanupFailure(st.channel, closeFailure)
            }
        }
        if (st.channel == null) st.channel = parentChannelOf(stream)

        var reserved = false
        // 0 = generic or host-initiated, 1 = negotiating, 2 = request, 3 = background.
        // Category and reservation transfer together under admissionMonitor, including close races.
        var capacityCategory = 0
        var overAggregate = false
        var overPerConnection = false
        var engagementChanged = false
        var refusalGeneration = 0L
        var retireRoot = false
        var retireTrigger = InboundAdmissionRetirementTrigger.REFUSED_WHILE_IDLE
        var countCompletedRetirement = false
        // The refusal record is sampled under the monitor and produced only after the reset and
        // any retirement close, so producing or delivering it can never prevent either action.
        var refusalReason: String? = null
        var refusalLiveOnConnection = 0
        var refusalPerConnectionLimit = hardPerConnectionLimit
        var refusalLiveAcrossHost = 0
        synchronized(admissionMonitor) {
            // I2: Both registration directions and every terminal decision use this
            // monitor. A terminal root cannot acquire new work, even between failed close attempts.
            if (st.retirementRequired && !connection.closeFuture().isDone) {
                if (!st.retirementCloseInFlight) {
                    st.retirementCloseInFlight = true
                    retireRoot = true
                    retireTrigger = InboundAdmissionRetirementTrigger.CLOSE_RETRY
                    countCompletedRetirement = st.countAsIdleRetirement
                }
            } else if (!connection.closeFuture().isDone && !inbound) {
                // I4: Host-initiated work owns its exact root without consuming inbound capacity,
                // independently of whether that root negotiated Yamux or Mplex.
                reserved = true
                st.initiatedLive++
            } else if (!connection.closeFuture().isDone) {
                overAggregate = globalLive.get() + globalNegotiating.get() >= maxGlobal
                overPerConnection = if (separateProtocolBudgets) {
                    st.negotiating >= pendingNegotiationLimit
                } else st.live.get() >= hardPerConnectionLimit
                // A zero-cap controller still refuses and retires idle asking roots.
                if (overAggregate && aggregateGeneration == 0L) {
                    aggregateGeneration = ++nextAggregateGeneration
                    engagementChanged = true
                }
                if (!overAggregate && !overPerConnection) {
                    reserved = true
                    st.live.incrementAndGet()
                    if (separateProtocolBudgets) {
                        capacityCategory = 1
                        st.negotiating++
                    }
                    val live = if (separateProtocolBudgets) {
                        globalLive.get() + globalNegotiating.incrementAndGet()
                    } else globalLive.incrementAndGet()
                    if (!separateProtocolBudgets) updateMaxObserved(live)
                    if (live >= maxGlobal && aggregateGeneration == 0L) {
                        aggregateGeneration = ++nextAggregateGeneration
                        engagementChanged = true
                    }
                }
                refusalGeneration = aggregateGeneration
                if (!reserved && !connection.isInitiator) {
                    if (overAggregate) st.retireWhenIdle = true
                    else if (overPerConnection) st.retireAfterPerConnectionOverflow = true
                    // I1/I2: Every admission retirement requires no live child in EITHER
                    // direction. Record the reason before reset can re-enter or release work,
                    // and serialize terminal publication with registrations in both directions.
                    if (st.live.get() == 0 && st.initiatedLive == 0) {
                        st.retirementRequired = true
                        st.terminalReadPause = true
                        st.retirementCloseInFlight = true
                        st.countAsIdleRetirement = st.retireWhenIdle
                        retireRoot = true
                        countCompletedRetirement = st.countAsIdleRetirement
                    }
                }
            }
            if (!reserved && inbound) {
                rejectedCount.incrementAndGet()
                if (!st.refusalReported) {
                    st.refusalReported = true
                    // The cap flags are set only by this visit's admission branch; the refusal
                    // above may already have made the root terminal, so test them first.
                    refusalReason = when {
                        overAggregate -> "aggregate-cap"
                        overPerConnection && separateProtocolBudgets -> "negotiation-cap"
                        overPerConnection -> "per-connection-cap"
                        connection.closeFuture().isDone -> "connection-closed"
                        else -> "connection-retiring"
                    }
                    if (separateProtocolBudgets && overPerConnection && !overAggregate) {
                        refusalLiveOnConnection = st.negotiating
                        refusalPerConnectionLimit = pendingNegotiationLimit
                    } else {
                        refusalLiveOnConnection = st.live.get()
                        if (separateProtocolBudgets) {
                            refusalPerConnectionLimit = (hardPerConnectionLimit.toLong() +
                                maxBackgroundSubstreamsPerConnection + pendingNegotiationLimit)
                                .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                        }
                    }
                    refusalLiveAcrossHost = globalLive.get() + globalNegotiating.get()
                }
            }
        }

        // V4: Install exactly-once cleanup before Clock, effect handlers, read updates or reset
        // callbacks can throw or re-enter. A synchronous close also releases this reservation.
        // Returns a fatal error raised by an admission record's handler, for the caller to rethrow
        // once its own remaining steps have run; an action's own failure is thrown at once.
        fun releaseReservation(): Throwable? {
            var generationDrained = false
            var retire = false
            var countRetirement = false
            synchronized(admissionMonitor) {
                if (!reserved) return null
                reserved = false
                if (inbound) {
                    st.live.decrementAndGet()
                    when (capacityCategory) {
                        1 -> st.negotiating--
                        2 -> st.requests.decrementAndGet()
                        3 -> st.background--
                    }
                    if (capacityCategory == 1) globalNegotiating.decrementAndGet()
                    else globalLive.decrementAndGet()
                    val global = globalLive.get() + globalNegotiating.get()
                    if (global < lowWater(maxGlobal) && aggregateGeneration != 0L) {
                        aggregateGeneration = 0L
                        generationDrained = true
                    }
                } else {
                    // I4: Release only the per-root ownership held by a host-initiated child.
                    st.initiatedLive--
                }
                // I1/I2: Neither last-inbound nor last-initiated cleanup can make any admission
                // retirement terminal while ANY child remains. New registration shares this lock,
                // so no child can arrive between the zero-live decision and terminal publication.
                if (st.live.get() == 0 && st.initiatedLive == 0 &&
                    (st.retireWhenIdle || st.retireAfterPerConnectionOverflow || st.retireAfterReadFailure) &&
                    !connection.isInitiator &&
                    !connection.closeFuture().isDone && !st.retirementRequired
                ) {
                    st.retirementRequired = true
                    st.terminalReadPause = true
                    st.retirementCloseInFlight = true
                    st.countAsIdleRetirement = st.retireWhenIdle
                    countRetirement = st.countAsIdleRetirement
                    retire = true
                }
            }
            var retirementRecord = NO_PENDING_RECORD
            var recordFatal: Throwable? = null
            val actionFailure = try {
                if (retire) {
                    retirementRecord = retireConnection(
                        connection,
                        st,
                        countAsIdleRetirement = countRetirement,
                        trigger = InboundAdmissionRetirementTrigger.LAST_SUBSTREAM_CLOSED,
                    )
                }
                if ((if (separateProtocolBudgets) st.requests.get() else st.live.get()) < lowWater(maxPerConnection)) {
                    recordFatal = combineFatal(recordFatal, resumeConnection(st))
                }
                if (generationDrained) {
                    conns.values.forEach { recordFatal = combineFatal(recordFatal, applyReadState(it)) }
                }
                null
            } catch (failure: Throwable) {
                failure
            }
            recordFatal = combineFatal(recordFatal, retirementRecord())
            if (actionFailure != null) rethrowAfterRecords(actionFailure, recordFatal)
            return recordFatal
        }

        // A fatal error raised by an admission record's handler during this visit. It is rethrown
        // only after every step the visit takes without records has run, including the cleanup in
        // the catch block below; the first one is primary and later ones are attached as suppressed.
        var recordFatal: Throwable? = null
        try {
            if (reserved) {
                stream.closeFuture().whenComplete { _, closeFailure ->
                    val releaseRecordFatal = try { releaseReservation() }
                    catch (cleanupFailure: Throwable) {
                        if (closeFailure != null) cleanupFailure.addSuppressed(closeFailure)
                        reportInboundAdmissionCleanupFailure(st.channel, cleanupFailure)
                        return@whenComplete
                    }
                    if (closeFailure != null) reportInboundAdmissionCleanupFailure(st.channel, closeFailure)
                    // whenComplete captures anything thrown here in an unobserved dependent stage,
                    // so a record's fatal error is routed explicitly, after this callback's steps.
                    releaseRecordFatal?.let { reportInboundAdmissionCleanupFailure(st.channel, it) }
                }
                if (!inbound) return
                if (separateProtocolBudgets) {
                    streamAsChannel(stream)?.pipeline()?.addLast(InboundProtocolAcknowledgementGuard { protocol ->
                        var refusedBudget: String? = null
                        var occupied = 0
                        var limit = 0
                        var admitted = false
                        var reportRefusal = false
                        synchronized(admissionMonitor) {
                            if (reserved && capacityCategory == 1) {
                                val background = protocol == "/ipfs/id/1.0.0" ||
                                    protocol == "/ipfs/ping/1.0.0" ||
                                    protocol == "/urlresolver-relay/1.0.0" ||
                                    protocol == GossipProtocol.PROTOCOL_ID
                                occupied = if (background) st.background else st.requests.get()
                                limit = if (background) maxBackgroundSubstreamsPerConnection else hardPerConnectionLimit
                                if (occupied >= limit) {
                                    refusedBudget = if (background) "background" else "request"
                                    rejectedCount.incrementAndGet()
                                    if (!st.refusalReported) {
                                        st.refusalReported = true
                                        reportRefusal = true
                                    }
                                    if (!connection.isInitiator) st.retireAfterPerConnectionOverflow = true
                                } else {
                                    st.negotiating--
                                    globalNegotiating.decrementAndGet()
                                    updateMaxObserved(globalLive.incrementAndGet())
                                    if (background) {
                                        capacityCategory = 3
                                        st.background++
                                    } else {
                                        capacityCategory = 2
                                        st.requests.incrementAndGet()
                                    }
                                    admitted = true
                                }
                            }
                        }
                        val budget = refusedBudget
                        if (!admitted) {
                            stream.reset()
                            if (budget != null && reportRefusal) {
                                deliverAdmissionRecord(st, "[InboundProtocolCapacityRefusal]") {
                                    InboundProtocolCapacityRefusedEffect(protocol, budget, occupied, limit)
                                }?.let { reportInboundAdmissionCleanupFailure(st.channel, it) }
                            }
                        } else if (st.requests.get() >= maxPerConnection) {
                            pauseConnection(st)?.let { reportInboundAdmissionCleanupFailure(st.channel, it) }
                        }
                        admitted
                    }) ?: error("Inbound protocol admission requires the stream's transport channel.")
                }
                recordFatal = if ((if (separateProtocolBudgets) st.requests.get() else st.live.get()) >= maxPerConnection) pauseConnection(st)
                else applyReadState(st)
                if (engagementChanged) {
                    conns.values.forEach { recordFatal = combineFatal(recordFatal, applyReadState(it)) }
                    reportAggregateCapEngagedIfDue()
                }
            } else {
                // I3: Reset precedes protocol initialization in both directions. It certifies no
                // dispatch only to the local failed-negotiation caller; an established RPC reset is
                // ambiguous.
                var retirementRecord = NO_PENDING_RECORD
                val actionFailure = try {
                    try {
                        stream.reset()
                    } finally {
                        if (retireRoot) {
                            retirementRecord =
                                retireConnection(connection, st, countCompletedRetirement, retireTrigger)
                        }
                    }
                    null
                } catch (failure: Throwable) {
                    failure
                }
                // Records are produced only now, after the reset and the close they describe.
                recordFatal = refusalReason?.let { reason ->
                    deliverAdmissionRecord(st, "[InboundAdmissionRefusal]") {
                        InboundSubstreamRefusedEffect(
                            rootConnectionIdentity = connectionRecordIdentity(connection),
                            reason = reason,
                            remotePeerId = connectionRecordRemotePeerId(connection),
                            remoteAddress = connectionRecordValue { connection.remoteAddress() },
                            liveInboundSubstreamsOnConnection = refusalLiveOnConnection,
                            hardPerConnectionLimit = refusalPerConnectionLimit,
                            liveInboundSubstreamsAcrossHost = refusalLiveAcrossHost,
                            maxInboundSubstreamsAcrossHost = maxGlobal,
                            rootLinkDiagnostics = connection.rootLinkDiagnostics(),
                        )
                    }
                }
                recordFatal = combineFatal(recordFatal, retirementRecord())
                // An action's own failure propagates at once, as it does without records; a record's
                // fatal error alone waits until the rest of the visit has run.
                if (actionFailure != null) {
                    val raised = recordFatal
                    // Carried by the failure thrown here; the catch block must not attach it twice.
                    recordFatal = null
                    rethrowAfterRecords(actionFailure, raised)
                }
                if (!inbound) {
                    // I3: Refusing local registration must also fail stream initialization. Returning
                    // normally would install negotiation handlers after reset's close event and leave
                    // the caller's controller future pending. No protocol or request was dispatched.
                    throw ConnectionClosedException(
                        "Cannot register a host-initiated substream on root " +
                            "connection@${System.identityHashCode(connection).toString(16)}: " +
                            "expected a connection accepting new work, but inbound admission " +
                            "has made it terminal or the physical connection is closed."
                    )
                }
                synchronized(admissionMonitor) {
                    // V3: Only this still-active aggregate generation can publish a throttle. A
                    // per-connection-only refusal never touches it, and dialled roots stay exempt.
                    if (overAggregate && !connection.isInitiator && !st.retirementRequired &&
                        refusalGeneration != 0L && refusalGeneration == aggregateGeneration
                    ) st.refusalGeneration = refusalGeneration
                }
                recordFatal = combineFatal(recordFatal, applyReadState(st))
                if (overAggregate) reportAggregateCapEngagedIfDue()
            }
        } catch (failure: Throwable) {
            var cleanupRecordFatal = recordFatal
            try { cleanupRecordFatal = combineFatal(cleanupRecordFatal, releaseReservation()) }
            catch (cleanup: Throwable) { failure.addSuppressed(cleanup) }
            try { stream.reset() } catch (cleanup: Throwable) { failure.addSuppressed(cleanup) }
            rethrowAfterRecords(failure, cleanupRecordFatal)
            throw failure
        }
        recordFatal?.let { throw it }
    }

    private fun lowWater(cap: Int): Int = inboundAdmissionLowWater(cap)

    /**
     * Starts one retirement close and returns the delivery of its `[InboundAdmissionRetirement]`
     * record, which the caller invokes once its own actions are finished. Delivery returns a fatal
     * JVM error for the caller to rethrow, or null; every other failure is already reported.
     *
     * When the close has not completed by the time this returns (it was queued to the channel's
     * event loop from another thread), the record is instead delivered when the close completes and
     * the returned delivery only returns a fatal error an earlier record already raised, if any.
     */
    private fun retireConnection(
        connection: Connection,
        st: ConnState,
        countAsIdleRetirement: Boolean,
        trigger: InboundAdmissionRetirementTrigger,
        cause: Throwable? = null,
    ): () -> Throwable? {
        // Sample the decision's state under the monitor; the record itself is produced only after
        // the close, so producing or delivering it cannot prevent the close.
        var reasons: List<String> = emptyList()
        var liveInbound = 0
        var liveHostInitiated = 0
        var liveAcrossHost = 0
        synchronized(admissionMonitor) {
            reasons = listOfNotNull(
                "aggregate-cap-refusal".takeIf { st.retireWhenIdle },
                "per-connection-overflow".takeIf { st.retireAfterPerConnectionOverflow },
                "read-failure".takeIf { st.retireAfterReadFailure },
            )
            liveInbound = st.live.get()
            liveHostInitiated = st.initiatedLive
            liveAcrossHost = globalLive.get() + globalNegotiating.get()
        }
        val linkDiagnostics = (connection as? io.libp2p.transport.implementation.P2PChannelOverNetty)?.nettyChannel
            ?.rootLinkState()?.freeze(reasons.joinToString(","), "LOCAL_CLOSE") ?: connection.rootLinkDiagnostics()
        val record: () -> Throwable? = {
            deliverAdmissionRecord(st, "[InboundAdmissionRetirement]") {
                InboundSubstreamAdmissionRetirementEffect(
                    rootConnectionIdentity = connectionRecordIdentity(connection),
                    reasons = reasons,
                    trigger = trigger,
                    remotePeerId = connectionRecordRemotePeerId(connection),
                    remoteAddress = connectionRecordValue { connection.remoteAddress() },
                    liveInboundSubstreamsOnConnection = liveInbound,
                    liveHostInitiatedSubstreamsOnConnection = liveHostInitiated,
                    liveInboundSubstreamsAcrossHost = liveAcrossHost,
                    maxInboundSubstreamsAcrossHost = maxGlobal,
                    cause = connectionRecordCause(cause),
                    rootLinkDiagnostics = linkDiagnostics,
                )
            }
        }
        // Retirement remains terminal while exactly one close operation is in flight. A failed
        // operation clears only that ownership bit, so a later refused visit can hand off another
        // close without admitting new work. The physical close future independently removes state
        // when the peer departs. Only a successful idle-retirement operation changes the counter.
        // A held or failed close must keep yielding between reads, even after aggregate drain
        // or the last-child callback clears its ordinary per-connection pause.
        val readStateFatal = applyReadState(st)
        val closeFuture = try {
            connection.close()
        } catch (failure: Throwable) {
            synchronized(admissionMonitor) { st.retirementCloseInFlight = false }
            reportRetirementFailure(connection, st, failure, linkDiagnostics)
            return withEarlierFatal(readStateFatal, record)
        }
        closeFuture.whenComplete { _, failure ->
            if (failure == null) {
                if (countAsIdleRetirement) shedIdleConnectionCount.incrementAndGet()
            } else {
                synchronized(admissionMonitor) { st.retirementCloseInFlight = false }
                reportRetirementFailure(
                    connection,
                    st,
                    unwrapInboundAdmissionCloseFailure(failure),
                    linkDiagnostics,
                )
            }
        }
        if (closeFuture.isDone) return withEarlierFatal(readStateFatal, record)
        closeFuture.whenComplete { _, _ ->
            // whenComplete captures anything thrown here in an unobserved dependent stage, so a
            // fatal error from the record is routed explicitly, as reportRetirementFailure does.
            record()?.let { fatal -> reportInboundAdmissionCleanupFailure(st.channel, fatal) }
        }
        return withEarlierFatal(readStateFatal, NO_PENDING_RECORD)
    }

    private fun reportRetirementFailure(
        connection: Connection,
        st: ConnState,
        failure: Throwable,
        rootLinkDiagnostics: RootLinkDiagnostics?,
    ) {
        val state = synchronized(admissionMonitor) {
            Triple(st.retirementRequired, st.retirementCloseInFlight, st.countAsIdleRetirement)
        }
        val effect = InboundSubstreamAdmissionRetirementFailureEffect(
            rootConnectionIdentity = "connection@${System.identityHashCode(connection).toString(16)}",
            retirementRequired = state.first,
            retirementCloseInFlight = state.second,
            countAsIdleRetirement = state.third,
            failure = failure,
            rootLinkDiagnostics = rootLinkDiagnostics,
        )
        val observerFailure = try {
            tossToOwner(effect)
            null
        } catch (caught: Throwable) {
            caught
        }
        // The owner may propagate the exact reported cause. That cause is already the primary
        // failure and Java rejects suppressing a Throwable onto itself, so only a distinct owner
        // failure is attached. Report the original close cause before reporting a fatal owner Error.
        if (observerFailure != null && observerFailure !== failure) {
            failure.addSuppressed(observerFailure)
        }
        // Keep the transport observer path in addition to the owner-scoped typed effect.
        reportInboundAdmissionCleanupFailure(st.channel, failure)
        // whenComplete captures thrown Errors in its dependent stage. Route the exact fatal
        // owner failure explicitly, after the original close cause, so asynchronous close failure
        // cannot hide it. Attempt ownership was already released; later refusal can retry closing.
        if (observerFailure is Error && observerFailure !== failure) {
            reportInboundAdmissionCleanupFailure(st.channel, observerFailure)
        }
    }

    private fun tossToOwner(effect: NotificationEffect) {
        if (ownerEffectRepository == null) {
            toss(effect)
            return
        }
        synchronized(ownerEffectRepository) {
            val workerRepository = `$effectHandlerRepository`.get()
            `$effectHandlerRepository`.set(ownerEffectRepository)
            try { toss(effect) }
            finally { `$effectHandlerRepository`.set(workerRepository) }
        }
    }

    /**
     * Produces, writes and delivers one admission record to the owner's scope. Callers invoke it
     * only after the reset or close the record describes.
     *
     * A failure building the record, a standard-error sink that rejects the line, and a handler
     * failure go to the transport exception path, as the controller's other cleanup failures do. A
     * fatal JVM error is returned instead, for the caller to rethrow once its action is finished.
     */
    private inline fun deliverAdmissionRecord(
        st: ConnState,
        prefix: String,
        produce: () -> NotificationEffect,
    ): Throwable? {
        var fatal: Throwable? = null
        deliverConnectionRecord(ownerEffectRepository, prefix, produce) { failure ->
            if (isFatalJvmError(failure)) fatal = combineFatal(fatal, failure)
            else reportInboundAdmissionCleanupFailure(st.channel, failure)
        }
        return fatal
    }

    /**
     * Emits [InboundSubstreamAdmissionCapEngagedEffect] unless one was emitted too recently.
     *
     * Saturation has to be visible without turning on debug logging, because that is the state in
     * which peers are being refused substreams and it is otherwise indistinguishable from a healthy
     * host. Reporting every refusal would be one report per substream on a saturated host, so
     * reports are spaced by [MIN_MILLIS_BETWEEN_INBOUND_ADMISSION_CAP_EFFECTS]. Clock sampling,
     * rollback recovery and report selection share the admission monitor; delivery runs outside it.
     */
    private fun reportAggregateCapEngagedIfDue() {
        val effect = synchronized(admissionMonitor) {
            if (aggregateGeneration == 0L) return
            val now = clock.currentTimeMillis()
            val last = lastCapEngagedReportAtMillis
            // A rollback establishes a new baseline without duplicating a report. Sampling
            // under the same lock prevents concurrent callers from applying an older clock sample
            // after a newer report. A full interval on the new timeline permits exactly one report.
            if (last != null && now < last) {
                lastCapEngagedReportAtMillis = now
                return
            }
            if (last != null && now - last in 0 until MIN_MILLIS_BETWEEN_INBOUND_ADMISSION_CAP_EFFECTS) return
            lastCapEngagedReportAtMillis = now
            InboundSubstreamAdmissionCapEngagedEffect(
                liveInboundSubstreams = globalLive.get() + globalNegotiating.get(),
                maxInboundSubstreams = maxGlobal,
                refusedInboundSubstreams = rejectedCount.get(),
            )
        }
        // V4: No admission or physical-read monitor is held across user code. Restore the worker
        // scope even when the observer throws; visit has already installed reservation cleanup.
        tossToOwner(effect)
    }

    /** Returns a fatal error raised by an admission record's handler, for the caller to rethrow. */
    private fun pauseConnection(st: ConnState): Throwable? =
        if (st.pausedByConn.compareAndSet(false, true)) applyReadState(st) else null

    /**
     * Restores this connection's reads BEFORE clearing the published pause flag.
     *
     * The two directions of [pausedConnectionCount] are not equally safe. Reporting a connection as
     * still carrying its own admission pause slightly early only costs a reader a conclusion it
     * could have drawn. Reporting it as free of that pause while the pause is still on the channel
     * is the misleading one, so that is the direction this ordering rules out: the resume reaches
     * the channel first, and only then is the flag cleared. The gap matters because applying the
     * resume has to acquire the parent's read-state monitor that the relay request-write commit path
     * holds across its own Netty write handoff, so a flag cleared first can lead the channel by a
     * long way.
     *
     * Netty's `autoRead` and this flag are both volatile, so clearing the flag last means a reader
     * that sees the connection unpaused is guaranteed to see the already-restored channel.
     *
     * This concerns the published diagnostic [pausedConnectionCount] only. The question the relay
     * paths ask before committing a request is `inboundReadsPausedByAdmission`, which reads the
     * physical parent's [InboundPhysicalReadState] and is unaffected by the order of this flag.
     */
    private fun resumeConnection(st: ConnState): Throwable? {
        // Lock-free fast path, and the reason this is not merely an optimisation: this runs from
        // stream.closeFuture() on the Netty event loop, and it runs on essentially every substream
        // close, because a connection sits below the low-water mark almost all of the time. The
        // monitor acquired below is the one the relay request-write commit path holds across a full
        // writeAndFlush pipeline traversal, so acquiring it unconditionally here would let an
        // ordinary close block the event loop behind a multi-MiB relay write. Reading the flag first
        // keeps the common no-pause-to-lift case entirely lock-free, exactly as the plain
        // compare-and-set did before. The re-check inside the monitor remains the authoritative one.
        if (!st.pausedByConn.get()) return null
        val channel = st.channel
        if (channel == null) {
            // No parent channel captured yet, so there is no applied pause to outlive the flag.
            st.pausedByConn.set(false)
            return null
        }
        val state = inboundPhysicalReadStateFor(channel)
        val applied = synchronized(state) {
            if (!st.pausedByConn.get()) return null
            val result = applyReadStateWhileHoldingMonitor(
                channel,
                state,
                connectionPaused = false,
                refusalThrottled = (st.refusalGeneration != 0L && st.refusalGeneration == aggregateGeneration),
                terminalPaused = st.terminalReadPause,
                reportFailure = { reportReadStateFailureFromCallback(st, it) },
            )
            // Cleared unconditionally, having observed the flag set under this monitor. A
            // concurrent pauseConnection whose compare-and-set lost to this resume applied nothing
            // of its own (it found the flag already true), so its pause is dropped here. Reaching
            // that needs the live count to fall by a full quarter of the cap in between; it leaves
            // the flag and the channel consistent with each other either way, so the conservative
            // direction above still holds; and the next inbound substream re-pauses the connection,
            // with the hard reset() fallback in visit() backstopping the gap.
            st.pausedByConn.set(false)
            result
        }
        return applied.updateFailure?.let { reportReadStateFailure(st, it) }
    }

    /**
     * Applies the read state [st] currently implies.
     *
     * [ConnState.pausedByConn] is sampled INSIDE the monitor. Sampling it before acquiring the
     * monitor let a caller apply a stale value: a `visit()` that read `paused = true` and then
     * blocked on the monitor (which the relay request-write commit path holds across a full
     * `writeAndFlush`) could be overtaken by a `resumeConnection` that restored reads and cleared
     * the flag, and would then re-apply `autoRead = false` while the flag stayed `false`. Nothing
     * recovers from that: `resumeConnection`'s fast path returns immediately on a clear flag, and
     * no later `resumeConnection` would restore automatic reads. The controlled read pump prevents
     * transport stranding in that state, and the physical-state record keeps relay callers safe,
     * but the connection would remain needlessly throttled while its public count said otherwise.
     *
     * Returns a fatal error raised by an admission record's handler, for the caller to rethrow once
     * everything it does after this call has run; [resumeConnection] and [pauseConnection] do the same.
     */
    private fun applyReadState(st: ConnState): Throwable? {
        val ch = st.channel ?: return null
        val state = inboundPhysicalReadStateFor(ch)
        val applied = synchronized(state) {
            applyReadStateWhileHoldingMonitor(
                ch,
                state,
                st.pausedByConn.get(),
                (st.refusalGeneration != 0L && st.refusalGeneration == aggregateGeneration),
                st.terminalReadPause,
                { reportReadStateFailureFromCallback(st, it) },
            )
        }
        return applied.updateFailure?.let { reportReadStateFailure(st, it) }
    }

    /** Any failure raised while applying the parent read state, reported after releasing its monitor. */
    private class AppliedReadState(val updateFailure: Throwable?)

    /**
     * Applies the parent read state implied by [connectionPaused]. The caller must hold [state]'s
     * monitor, which serializes every writer of this connection's physical read state against each
     * other, so that the last writer of the channel is also the last recorder of the observation
     * `inboundReadsPausedByAdmission` reports to the relay paths.
     */
    private fun applyReadStateWhileHoldingMonitor(
        ch: io.netty.channel.Channel,
        state: InboundPhysicalReadState,
        connectionPaused: Boolean,
        refusalThrottled: Boolean,
        terminalPaused: Boolean,
        reportFailure: (Throwable) -> Unit,
    ): AppliedReadState {
        // V3: The caller samples refusalGeneration against the active generation while holding
        // this physical monitor. A drain invalidates the generation before scheduling refreshes,
        // so a delayed apply cannot republish an expired throttle. autoRead and its authoritative
        // pause record are updated under this same monitor below.
        // Ordinary per-connection pauses are suspended at aggregate saturation. A spared
        // aggregate asker and any physically open terminal root retain a controlled read for FIN
        // and accepted work. The single read keeps transport progress
        // moving; the muxer's independent 512-child ceiling bounds each read burst's scaffolding.
        val shouldRead = (!connectionPaused || (aggregateGeneration != 0L)) &&
            !refusalThrottled && !terminalPaused
        var updateFailure: Throwable? = null
        try {
            if (!shouldRead && !state.manualReadPumpInstalled) {
                // Yamux consumes the physical parent's channelReadComplete event instead of
                // forwarding it to handlers placed after the muxer. Install at the front so the
                // pump observes every physical read cycle, while its pass-through adapter leaves
                // the existing inbound data path unchanged.
                ch.pipeline().addFirst(
                    INBOUND_ADMISSION_MANUAL_READ_PUMP,
                    InboundAdmissionManualReadPump(reportFailure),
                )
                state.manualReadPumpInstalled = true
            }
            val config = ch.config()
            // Enabling autoRead dispatches read callbacks before its setter returns. Time
            // spent in those callbacks is readable time, not part of the admission pause.
            state.applyAutoReadChange {
                if (config.isAutoRead != shouldRead) config.isAutoRead = shouldRead
                shouldRead
            }
            // Keep one read pending while autoRead is disabled. The first read and every re-arm
            // are deferred so neither can be consumed by a physical read cycle still unwinding.
            if (!shouldRead) scheduleInboundAdmissionManualRead(ch, reportFailure)
        } catch (caught: Throwable) {
            updateFailure = caught
            restoreInboundAdmissionReads(ch, caught)
        }
        return AppliedReadState(updateFailure)
    }

    /**
     * [reportReadStateFailure] for a manual-read callback, whose last step this is, so a fatal error
     * from an admission record's handler is rethrown straight away.
     */
    private fun reportReadStateFailureFromCallback(st: ConnState, failure: Throwable) {
        reportReadStateFailure(st, failure)?.let { fatal -> throw fatal }
    }

    /**
     * Reports a read-state failure and, when the connection is idle, starts its retirement. A fatal
     * error raised by the retirement record's handler is returned rather than thrown, so that the
     * caller's remaining steps still run; the caller rethrows it once they have.
     */
    private fun reportReadStateFailure(st: ConnState, failure: Throwable): Throwable? {
        val connection = st.connection
        var retire = false
        var countRetirement = false
        synchronized(admissionMonitor) {
            // No admission-control path — refusal at either cap, deferred retirement, read-pause
            // installation, manual-read scheduling, or their failures — closes an accepted root
            // while it has any live stream in either direction. A read-state failure restores a
            // consistent readable parent (autoRead = true, fresh read demand, matching recorded
            // state), is reported
            // through the transport reporting path, and admission continues to refuse only excess
            // children; any retirement obligation stays deferred until both counts are zero.
            if (!connection.isInitiator && !connection.closeFuture().isDone) {
                st.retireAfterReadFailure = true
                if (st.live.get() == 0 && st.initiatedLive == 0 && !st.retirementRequired) {
                    st.retirementRequired = true
                    st.terminalReadPause = true
                    st.retirementCloseInFlight = true
                    st.countAsIdleRetirement = st.retireWhenIdle
                    countRetirement = st.countAsIdleRetirement
                    retire = true
                }
            }
        }
        // Recovery has already recorded the physical value and retired old queued reads. Neither
        // controller monitor is held while the transport observer runs or re-enters admission.
        var retirementRecord = NO_PENDING_RECORD
        val actionFailure = try {
            try {
                reportInboundAdmissionCleanupFailure(st.channel, failure)
            } finally {
                if (retire) {
                    retirementRecord = retireConnection(
                        connection,
                        st,
                        countRetirement,
                        InboundAdmissionRetirementTrigger.READ_FAILURE_WHILE_IDLE,
                        failure,
                    )
                }
            }
            null
        } catch (caught: Throwable) {
            caught
        }
        val recordFatal = retirementRecord()
        // An action's own failure propagates at once, as it does without records.
        if (actionFailure != null) rethrowAfterRecords(actionFailure, recordFatal)
        return recordFatal
    }

    private fun parentChannelOf(stream: Stream): io.netty.channel.Channel? =
        try {
            streamAsChannel(stream)?.parent()
        } catch (_: Throwable) {
            null
        }

    private fun updateMaxObserved(candidate: Int) {
        var prev = maxObservedGlobalLive.get()
        while (candidate > prev && !maxObservedGlobalLive.compareAndSet(prev, candidate)) {
            prev = maxObservedGlobalLive.get()
        }
    }

}
