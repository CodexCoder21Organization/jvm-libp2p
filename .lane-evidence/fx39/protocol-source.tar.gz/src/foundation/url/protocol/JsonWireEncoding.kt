package foundation.url.protocol

import java.io.IOException
import java.io.Reader
import java.io.Writer
import java.nio.charset.StandardCharsets
import org.json.JSONException
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Serializes [json] into the UTF-8 bytes this protocol puts on the wire.
 *
 * The output is byte-for-byte identical to `json.toString().toByteArray(UTF_8)`; only the buffer
 * the characters are accumulated in differs. org.json's [JSONObject.toString] writes through a
 * [java.io.StringWriter], whose backing [StringBuffer] is synchronized, and org.json emits a string
 * *value* one character at a time through [Writer.write], so a payload pays one monitor
 * acquire/release per character. Accumulating into an unsynchronized [StringBuilder] removes that
 * locking, which is the dominant cost for the large base64 request chunks and multi-megabyte gossip
 * payloads this protocol frames.
 *
 * This covers values only. [JSONObject.write] emits each *key* by calling the one-argument
 * `JSONObject.quote`, which builds the quoted key in its own private [java.io.StringWriter] and
 * hands the finished string over in a single write, so keys keep their original cost. That is
 * deliberate and harmless here: relay frames pair short keys with large values. Measured on an
 * object whose bulk is in its keys, this path is 0.95x — i.e. unchanged — while the same object
 * with the bulk in its values is 3.2x.
 *
 * Non-response frames use [JSONObject.write]. Responses traverse the same container shapes
 * and use org.json's scalar formatting, retaining each first-pass key for failure context.
 * Escaping, key order, and number formatting are unchanged. Unlike [JSONObject.toString] — which catches
 * every exception and returns `null` — a serialization failure propagates here as the
 * `org.json.JSONException` that describes it, instead of becoming a `NullPointerException` at the
 * call site.
 */
internal fun jsonWireBytes(json: JSONObject): ByteArray =
    jsonWireString(json).toByteArray(StandardCharsets.UTF_8)

/** Serializes [json] exactly as [jsonWireBytes] does, but stops at the encoded text. */
internal fun jsonWireString(json: JSONObject): String {
    val writer = StringBuilderWriter()
    if (json.javaClass != JSONObject::class.java) {
        // Keep a caller's root write hook, and inspect its context only after a failure.
        try {
            json.write(writer)
        } catch (failure: Throwable) {
            rethrowFatalJvmError(failure)
            val response = try {
                (json.opt("type") as? String) == Libp2pRpcProtocol.TYPE_RESPONSE
            } catch (diagnosticFailure: Throwable) {
                if (diagnosticFailure !== failure) failure.addSuppressed(diagnosticFailure)
                throw failure
            }
            if (!response) throw failure
            throw rpcJsonPathException(rpcOpaqueJsonWriteFailure(failure))
        }
    } else if ((json.opt("type") as? String) != Libp2pRpcProtocol.TYPE_RESPONSE) {
        json.write(writer)
    } else {
        try {
            writeRpcJsonValue(writer, json)
        } catch (failure: RpcJsonPathFailure) {
            throw rpcJsonPathException(failure)
        } catch (failure: Throwable) {
            throw rpcValueEncodingFailure("result", failure)
        }
    }
    return writer.toString()
}

/** Locates the actual failed write, including values refused during org.json wrapping. */
private fun rpcJsonPathException(failure: RpcJsonPathFailure): Throwable =
    rpcValueEncodingFailure(failure.path.removePrefix(".").ifEmpty { "result" }, failure.original)

/** Retains only one bounded suffix, and only after a write fails. */
private class RpcJsonPathFailure(
    val original: Throwable,
    var writerFailure: Throwable,
    var path: String = "",
) : RuntimeException(null, original, false, false)

/** Adds writer context without reading the caller's container or rendering its key again. */
private fun rpcJsonWriteFailure(failure: Throwable, key: String?, index: Int = -1): RpcJsonPathFailure {
    val located = if (failure is RpcJsonPathFailure) failure else {
        rethrowFatalJvmError(failure)
        RpcJsonPathFailure(failure, failure)
    }
    try {
        val segment = if (key == null) "[$index]" else rpcFieldPathSuffix(key)
        located.path = boundedRpcFieldPath(segment + located.path)
        located.writerFailure = JSONException(
            if (key == null) "Unable to write JSONArray value at index: $index"
            else "Unable to write JSONObject value for key: $key", located.writerFailure,
        )
    } catch (diagnosticFailure: Throwable) {
        if (diagnosticFailure !== located.original) located.original.addSuppressed(diagnosticFailure)
    }
    return located
}

/** Reuses only org.json writer context from an opaque serializer's failure; never rereads its data. */
private fun rpcOpaqueJsonWriteFailure(failure: Throwable): RpcJsonPathFailure {
    rethrowFatalJvmError(failure)
    var original = failure
    var path = ""
    try {
        val seen = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
        while (original is JSONException && seen.add(original)) {
            // A leaf may use the same message as org.json. Its writer origin distinguishes
            // actual context wrappers without invoking the caller's serializer again.
            val origin = original.stackTrace.firstOrNull() ?: break
            if (origin.methodName != "write") break
            val message = rpcEncodingFailureMessage(original) ?: break
            when {
                origin.className == "org.json.JSONObject" &&
                    message.startsWith("Unable to write JSONObject value for key: ") ->
                    path = rpcFieldPath(path, message.removePrefix("Unable to write JSONObject value for key: "))
                origin.className == "org.json.JSONArray" &&
                    message.startsWith("Unable to write JSONArray value at index: ") -> {
                    val index = message.removePrefix("Unable to write JSONArray value at index: ").toIntOrNull() ?: break
                    path = boundedRpcFieldPath("$path[$index]")
                }
                else -> break
            }
            original = original.cause ?: break
        }
    } catch (diagnosticFailure: Throwable) {
        if (diagnosticFailure !== original) original.addSuppressed(diagnosticFailure)
    }
    return RpcJsonPathFailure(original, failure, path.let { if (it.isEmpty() || it.startsWith("[")) it else ".$it" })
}

/**
 * The response writer follows org.json's compact write rules. Scalars still use org.json;
 * container boundaries retain the already-written key/index on failure instead of traversing
 * caller data a second time. No path strings are built for successful children.
 */
private fun writeRpcJsonValue(writer: Writer, value: Any?) {
    when {
        value == null || value.equals(null) -> writer.write("null")
        value is org.json.JSONString -> {
            val text = try { value.toJSONString() } catch (failure: Exception) { throw JSONException(rpcEncodingFailureMessage(failure), failure) }
            writer.write(text ?: JSONObject.quote(value.toString()))
        }
        value is Number || value is Boolean -> {
            requireFiniteRpcJsonNumber(value)
            writer.write(JSONObject.valueToString(value))
        }
        value is Enum<*> -> writer.write(JSONObject.quote(value.name))
        value is JSONObject -> {
            // Preserve caller-defined serializers rather than replacing their public write hook.
            if (value.javaClass != JSONObject::class.java) {
                try { value.write(writer, 0, 0) }
                catch (failure: Throwable) { throw rpcOpaqueJsonWriteFailure(failure) }
                return
            }
            writer.write('{'.code)
            var comma = false
            for (key in value.keySet()) {
                if (comma) writer.write(','.code)
                writer.write(JSONObject.quote(key))
                writer.write(':'.code)
                try { writeRpcJsonValue(writer, value.opt(key)) }
                catch (failure: Throwable) { throw rpcJsonWriteFailure(failure, key) }
                comma = true
            }
            writer.write('}'.code)
        }
        value is JSONArray -> {
            if (value.javaClass != JSONArray::class.java) {
                try { value.write(writer, 0, 0) }
                catch (failure: Throwable) { throw rpcOpaqueJsonWriteFailure(failure) }
                return
            }
            writer.write('['.code)
            for (index in 0 until value.length()) {
                if (index != 0) writer.write(','.code)
                try {
                    val length = value.length()
                    if (index >= length) throw IndexOutOfBoundsException("Index $index out of bounds for length $length")
                    writeRpcJsonValue(writer, value.opt(index))
                } catch (failure: Throwable) {
                    throw rpcJsonWriteFailure(failure, null, index)
                }
            }
            writer.write(']'.code)
        }
        value is Map<*, *> -> writeRpcJsonValue(writer, wrapRpcJsonMap(value))
        value is Collection<*> -> writeRpcJsonValue(writer, wrapRpcJsonCollection(value))
        value is Array<*> -> writeRpcJsonValue(writer, wrapRpcJsonArray(value.size) { value[it] })
        value is DoubleArray -> writeRpcJsonValue(writer, wrapRpcJsonArray(value.size) { value[it] })
        value is FloatArray -> writeRpcJsonValue(writer, wrapRpcJsonArray(value.size) { value[it] })
        value is ByteArray || value is ShortArray || value is IntArray || value is LongArray ||
            value is BooleanArray || value is CharArray -> writeRpcJsonValue(writer, JSONArray(value))
        else -> JSONObject.quote(value.toString(), writer)
    }
}

/** Only primitive floating point values are refused by org.json's numeric validity check. */
private fun requireFiniteRpcJsonNumber(value: Any?) {
    if ((value is Double && !value.isFinite()) || (value is Float && !value.isFinite())) {
        throw RpcJsonPathFailure(
            RpcValueEncodingException("", "is $value, a non-finite number, which JSON does not allow.",
                JSONException("JSON does not allow non-finite numbers.")),
            JSONException("JSON does not allow non-finite numbers."),
        )
    }
}

/**
 * org.json wraps Maps, Collections and arrays before writing them. Retain the key/index of
 * that first conversion, too: constructors can refuse a number before the writer reaches it.
 * Other leaves still use org.json's own wrapping, including its established bean conversion.
 */
private fun wrapRpcJsonValue(value: Any?): Any? = try {
    requireFiniteRpcJsonNumber(value)
    when {
        value == null || value is org.json.JSONString || value is JSONObject || value is JSONArray -> value
        value is Map<*, *> -> wrapRpcJsonMap(value)
        value is Collection<*> -> wrapRpcJsonCollection(value)
        value is Array<*> -> wrapRpcJsonArray(value.size) { value[it] }
        value is DoubleArray -> wrapRpcJsonArray(value.size) { value[it] }
        value is FloatArray -> wrapRpcJsonArray(value.size) { value[it] }
        else -> JSONObject.wrap(value)
    }
} catch (failure: RpcJsonPathFailure) {
    // JSONObject.wrap rethrows JSON refusals but renders ordinary wrapping failures as null.
    // Keep that distinction after adding location, without invoking caller code again.
    if (failure.original is JSONException || failure.original !is Exception) throw failure
    null
} catch (failure: JSONException) {
    throw failure
} catch (failure: Exception) {
    // Preserve org.json's established wrapping contract for otherwise accepted raw trees.
    null
}

/** A non-string key's text is evaluated once, even when string keys collide after conversion. */
private class RpcJsonRenderedKey(private val text: String) {
    override fun toString(): String = text
}

private fun wrapRpcJsonMap(value: Map<*, *>): JSONObject {
    val wrapped = LinkedHashMap<Any, Any?>()
    for ((key, child) in value) {
        if (key == null) throw NullPointerException("Null key.")
        // JSONObject's constructor does not render a key whose value is absent.
        if (child == null) {
            wrapped[RpcJsonRenderedKey("")] = null
            continue
        }
        // JSONObject(Map) checks a direct number before it describes that entry's key.
        // A failed description must not turn this known JSON refusal into a wrapped null.
        try {
            requireFiniteRpcJsonNumber(child)
        } catch (failure: RpcJsonPathFailure) {
            val text = try { key.toString() } catch (diagnostic: Throwable) {
                if (diagnostic !== failure.original) failure.original.addSuppressed(diagnostic)
                "<${key.javaClass.name}>"
            }
            throw rpcJsonWriteFailure(failure, text)
        }
        val text = key.toString()
        val encoded = try { wrapRpcJsonValue(child) }
        catch (failure: Throwable) { throw rpcJsonWriteFailure(failure, text) }
        // Keep the original entry count and iteration order until JSONObject builds its HashMap.
        // Distinct keys whose rendered text agrees must still keep the last source value.
        // A non-null source that wraps to null is retained as a written JSON null;
        // only an originally null map value is omitted by JSONObject's constructor.
        wrapped[RpcJsonRenderedKey(text)] = encoded ?: JSONObject.NULL
    }
    return JSONObject(wrapped)
}

private fun wrapRpcJsonCollection(value: Collection<*>): JSONArray {
    val wrapped = JSONArray(value.size)
    for ((index, child) in value.withIndex()) {
        try { wrapped.put(wrapRpcJsonValue(child)) }
        catch (failure: Throwable) { throw rpcJsonWriteFailure(failure, null, index) }
    }
    return wrapped
}

private inline fun wrapRpcJsonArray(size: Int, valueAt: (Int) -> Any?): JSONArray {
    val wrapped = JSONArray(size)
    for (index in 0 until size) {
        try { wrapped.put(wrapRpcJsonValue(valueAt(index))) }
        catch (failure: Throwable) { throw rpcJsonWriteFailure(failure, null, index) }
    }
    return wrapped
}

/**
 * Parses [text], which arrived on the wire, into a [JSONObject].
 *
 * This is the same parser `JSONObject(String)` runs, reading from an unsynchronized source instead
 * of the synchronized one org.json picks by default. `JSONObject(String)` builds a [JSONTokener]
 * over a [java.io.StringReader], whose `read`, `mark`, and `reset` all synchronize, and the
 * tokenizer walks its input one character at a time — taking that lock several times per character.
 * Removing it is the whole of the win: an otherwise byte-identical reader with the locking put back
 * measures 5.36 ms against `JSONObject(String)`'s 5.46 ms on a 175 KB frame, while the
 * unsynchronized one measures 2.57 ms.
 *
 * What this does *not* touch is the [StringBuilder] [JSONTokener] grows internally while
 * accumulating a string token; that reallocation remains org.json's and is unaffected.
 *
 * Because [FastStringReader] supports marks, [JSONTokener] uses it directly rather than wrapping it
 * in a [java.io.BufferedReader], and the tokenizer's position tracking — and therefore the
 * character offsets in its error messages — is unchanged.
 */
internal fun parseJsonWireString(text: String): JSONObject =
    JSONObject(JSONTokener(FastStringReader(text)))

/**
 * An unsynchronized [Reader] over a [String].
 *
 * Matches [java.io.StringReader]'s observable behaviour — the same results and the same exception
 * types from every method, including the details that are easy to get wrong: a zero-length read
 * reports zero rather than end-of-input even when the input is exhausted, a skip past the end
 * reports zero before it considers the sign of its argument, and every method rejects use after
 * [close]. Only the per-call locking is gone, and the exception messages are this class's own.
 *
 * [JSONTokener] currently calls only `markSupported`, `mark`, `reset`, and `read`. The rest are
 * held to the same contract anyway so that a future org.json fast path cannot quietly diverge.
 *
 * Instances are confined to the single parse that creates them.
 */
private class FastStringReader(private val text: String) : Reader() {
    private var next = 0
    private var markedAt = 0
    private var closed = false

    private fun requireOpen() {
        if (closed) throw IOException("Stream closed")
    }

    override fun read(): Int {
        requireOpen()
        return if (next >= text.length) -1 else text[next++].code
    }

    override fun read(cbuf: CharArray, off: Int, len: Int): Int {
        requireOpen()
        if (off < 0 || len < 0 || len > cbuf.size - off) {
            throw IndexOutOfBoundsException(
                "Cannot read $len characters at offset $off into a ${cbuf.size}-character array"
            )
        }
        // Ordered exactly as java.io.StringReader does it: a zero-length read reports zero even at
        // the end of the input, and only a non-empty read past the end reports end-of-input.
        if (len == 0) return 0
        if (next >= text.length) return -1
        val count = minOf(text.length - next, len)
        text.toCharArray(cbuf, off, next, next + count)
        next += count
        return count
    }

    override fun skip(n: Long): Long {
        requireOpen()
        // StringReader reports zero once the input is exhausted, and does so before considering
        // the sign of [n] — so a negative skip at the end rewinds nothing rather than seeking back.
        if (next >= text.length) return 0L
        val forward = minOf((text.length - next).toLong(), n)
        val moved = maxOf(-next.toLong(), forward)
        next += moved.toInt()
        return moved
    }

    override fun ready(): Boolean {
        requireOpen()
        return true
    }

    override fun markSupported(): Boolean = true

    override fun mark(readAheadLimit: Int) {
        requireOpen()
        require(readAheadLimit >= 0) {
            "Read-ahead limit must not be negative, but was $readAheadLimit"
        }
        markedAt = next
    }

    override fun reset() {
        requireOpen()
        next = markedAt
    }

    override fun close() {
        closed = true
    }
}

/**
 * An unsynchronized [Writer] that accumulates into a [StringBuilder].
 *
 * Instances are confined to the single call that creates them, so the synchronization
 * [java.io.StringWriter] pays for is pure overhead on this path.
 */
private class StringBuilderWriter : Writer() {
    private val builder = StringBuilder()

    override fun write(c: Int) {
        builder.append(c.toChar())
    }

    override fun write(cbuf: CharArray, off: Int, len: Int) {
        builder.append(cbuf, off, len)
    }

    override fun write(str: String) {
        builder.append(str)
    }

    override fun write(str: String, off: Int, len: Int) {
        builder.append(str, off, off + len)
    }

    override fun flush() = Unit

    override fun close() = Unit

    override fun toString(): String = builder.toString()
}
