package foundation.url.protocol

/** Whether [failure] is a fatal JVM error that callback and reporting boundaries must not absorb. */
internal fun isFatalJvmError(failure: Throwable): Boolean =
    failure is VirtualMachineError || failure is ThreadDeath || failure is LinkageError

/** Fatal JVM errors leave callback/reporting boundaries without diagnostic rendering. */
internal fun rethrowFatalJvmError(failure: Throwable) {
    if (isFatalJvmError(failure)) {
        throw failure
    }
}
