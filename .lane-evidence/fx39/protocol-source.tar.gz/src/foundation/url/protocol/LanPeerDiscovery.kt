package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.logging.MessageSeverity
import io.libp2p.core.Host
import io.libp2p.core.PeerId
import io.libp2p.core.PeerInfo as Libp2pPeerInfo
import io.libp2p.core.multiformats.Multiaddr
import io.libp2p.discovery.MDnsDiscovery
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.toss
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Configuration for zero-config LAN peer discovery over link-local multicast.
 *
 * Discovery is enabled by default and uses the project-specific mDNS service tag
 * `_urlresolver._udp.local.`. The current jvm-libp2p MDnsDiscovery implementation
 * exposes explicit bind addresses and query interval. UrlProtocol also sends a
 * small project-local UDP multicast beacon so callers can confine discovery by
 * multicast group and UDP port without changing the libp2p artifact.
 */
data class LanDiscoveryConfig @JvmOverloads constructor(
    val enabled: Boolean = true,
    val serviceTag: String = "_urlresolver._udp.local.",
    val queryIntervalSeconds: Int = 120,
    val udpPort: Int = 5353,
    val multicastGroup: String = "224.0.0.251",
    val interfaceAllowlist: Set<String> = emptySet(),
    val interfaceDenylist: Set<String> = emptySet(),
    val addressCidrsAllowlist: Set<String> = emptySet(),
    val addressCidrsDenylist: Set<String> = emptySet(),
    val dialRateIntervalMs: Long = 60_000,
    val maxDialsPerInterval: Int = 16,
    val initialFailureBackoffMs: Long = 1_000,
    val maxFailureBackoffMs: Long = 60_000,
    val maxConcurrentDiscoveryDials: Int = 4,
    val mdnsEnabled: Boolean = true,
    val maxAddressesPerBeacon: Int = 8,
    val peerBackoffMaxEntries: Int = 1_024,
    val peerBackoffExpiredRetentionMs: Long = 60_000,
    val verifiedPeerFreshnessMs: Long = 10 * 60 * 1_000L
) {
    init {
        require(queryIntervalSeconds > 0) {
            "LAN discovery queryIntervalSeconds must be greater than 0, but was $queryIntervalSeconds"
        }
        require(udpPort in 1..65_535) {
            "LAN discovery udpPort must be in range 1..65535, but was $udpPort"
        }
        require(dialRateIntervalMs > 0) {
            "LAN discovery dialRateIntervalMs must be greater than 0, but was $dialRateIntervalMs"
        }
        require(maxDialsPerInterval >= 0) {
            "LAN discovery maxDialsPerInterval must be at least 0, but was $maxDialsPerInterval"
        }
        require(initialFailureBackoffMs > 0) {
            "LAN discovery initialFailureBackoffMs must be greater than 0, but was $initialFailureBackoffMs"
        }
        require(maxFailureBackoffMs >= initialFailureBackoffMs) {
            "LAN discovery maxFailureBackoffMs must be at least initialFailureBackoffMs " +
                "($initialFailureBackoffMs), but was $maxFailureBackoffMs"
        }
        require(maxConcurrentDiscoveryDials >= 0) {
            "LAN discovery maxConcurrentDiscoveryDials must be at least 0, but was $maxConcurrentDiscoveryDials"
        }
        require(maxAddressesPerBeacon > 0) {
            "LAN discovery maxAddressesPerBeacon must be greater than 0, but was $maxAddressesPerBeacon"
        }
        require(peerBackoffMaxEntries > 0) {
            "LAN discovery peerBackoffMaxEntries must be greater than 0, but was $peerBackoffMaxEntries"
        }
        require(peerBackoffExpiredRetentionMs >= 0) {
            "LAN discovery peerBackoffExpiredRetentionMs must be at least 0, but was $peerBackoffExpiredRetentionMs"
        }
        require(verifiedPeerFreshnessMs >= 0) {
            "LAN discovery verifiedPeerFreshnessMs must be at least 0, but was $verifiedPeerFreshnessMs"
        }
        (addressCidrsAllowlist + addressCidrsDenylist).forEach { cidr ->
            validateCidr(cidr)
        }
    }
}

data class LanDiscoveryDiagnostics(
    val acceptedBeacons: Long,
    val dialAttempts: Long,
    val pendingDials: Int,
    val malformedBeacons: Long,
    val warningCount: Long,
    val attemptedAddresses: Long,
    val peerBackoffEntries: Int = 0
)

class LanDiscoveryWarningEffect(
    message: String,
    cause: Throwable? = null
) : NotificationEffect(message, MessageSeverity.WARNING, cause)

class LanPeerDiscovery @JvmOverloads constructor(
    private val host: Host,
    private val peerRegistry: PeerRegistry,
    private val config: LanDiscoveryConfig = LanDiscoveryConfig(),
    private val clock: Clock = SystemClock(),
    private val localPeersForExchange: () -> List<PeerInfo> = { emptyList() },
    private val warningSink: (LanDiscoveryWarningEffect) -> Unit = {}
) : AutoCloseable {
    private val started = AtomicBoolean(false)
    private val discoveries = mutableListOf<MDnsDiscovery>()
    private val udpBeacons = mutableListOf<UdpBeacon>()
    private val acceptedBeacons = AtomicLong(0)
    private val dialAttempts = AtomicLong(0)
    private val pendingDials = AtomicInteger(0)
    private val malformedBeacons = AtomicLong(0)
    private val warningCount = AtomicLong(0)
    private val attemptedAddresses = AtomicLong(0)
    private val intervalStartMs = AtomicLong(clock.currentTimeMillis())
    private val dialsInInterval = AtomicInteger(0)
    private val peerBackoff = ConcurrentHashMap<String, BackoffState>()
    private val dialBudgetLock = Any()
    private val waitMonitor = Object()
    @Volatile
    private var dialExecutor: ExecutorService = newDialExecutor()

    fun start(): CompletableFuture<Void> {
        if (!config.enabled) {
            started.set(true)
            return CompletableFuture.completedFuture(null)
        }
        if (!started.compareAndSet(false, true)) {
            return CompletableFuture.completedFuture(null)
        }

        val targets = qualifyingBindTargets()
        val futures = if (config.mdnsEnabled) targets.mapNotNull { target ->
            try {
                val discovery = MDnsDiscovery(
                    host = host,
                    serviceTag = config.serviceTag,
                    queryInterval = config.queryIntervalSeconds,
                    address = target.address
                )
                discovery.newPeerFoundListeners += { peerInfo -> acceptDiscoveredPeer(peerInfo) }
                discoveries += discovery
                discovery.start().handle { _, error ->
                    if (error != null) {
                        warn("Failed to start LAN discovery mDNS on ${target.networkInterface.name}/${target.address.hostAddress}: ${error.message}", error)
                    }
                    null
                }
            } catch (e: Exception) {
                warn("Failed to start LAN discovery mDNS on ${target.networkInterface.name}/${target.address.hostAddress}: ${e.message}", e)
                null
            }
        } else {
            emptyList()
        }
        udpBeacons += targets.mapNotNull { target -> startUdpBeacon(target) }
        return CompletableFuture.allOf(*futures.toTypedArray())
    }

    fun stop(): CompletableFuture<Void> {
        started.set(false)
        udpBeacons.forEach { it.stop() }
        udpBeacons.clear()
        val futures = discoveries.map { discovery -> discovery.stop() }
        discoveries.clear()
        return CompletableFuture.allOf(*futures.toTypedArray()).whenComplete { _, _ ->
            dialExecutor.shutdownNow()
            dialExecutor = newDialExecutor()
            signalDiagnosticsChanged()
        }
    }

    override fun close() {
        stop().get(5, TimeUnit.SECONDS)
    }

    fun diagnostics(): LanDiscoveryDiagnostics {
        // Read the published reservation before its preceding cumulative-attempt counter. This
        // pairs with tryAcquireDialBudget's write order so the snapshot cannot report a pending
        // dial whose attempt is absent.
        val pendingDialsSnapshot = pendingDials.get()
        val dialAttemptsSnapshot = dialAttempts.get()
        return LanDiscoveryDiagnostics(
            acceptedBeacons = acceptedBeacons.get(),
            dialAttempts = dialAttemptsSnapshot,
            pendingDials = pendingDialsSnapshot,
            malformedBeacons = malformedBeacons.get(),
            warningCount = warningCount.get(),
            attemptedAddresses = attemptedAddresses.get(),
            peerBackoffEntries = peerBackoff.size
        )
    }

    fun awaitAcceptedBeaconsAtLeast(count: Long, timeout: Long, unit: TimeUnit): Boolean {
        val deadline = System.nanoTime() + unit.toNanos(timeout)
        synchronized(waitMonitor) {
            while (acceptedBeacons.get() < count) {
                val remaining = deadline - System.nanoTime()
                if (remaining <= 0) {
                    return false
                }
                TimeUnit.NANOSECONDS.timedWait(waitMonitor, remaining)
            }
            return true
        }
    }

    fun awaitNoPendingDials(timeout: Long, unit: TimeUnit): Boolean {
        val deadline = System.nanoTime() + unit.toNanos(timeout)
        synchronized(waitMonitor) {
            while (pendingDials.get() != 0) {
                val remaining = deadline - System.nanoTime()
                if (remaining <= 0) {
                    return false
                }
                TimeUnit.NANOSECONDS.timedWait(waitMonitor, remaining)
            }
            return true
        }
    }

    private fun startUdpBeacon(target: BindTarget): UdpBeacon? {
        val group = try {
            InetAddress.getByName(config.multicastGroup)
        } catch (e: Exception) {
            warn("Failed to resolve LAN discovery multicast group '${config.multicastGroup}' for ${target.networkInterface.name}/${target.address.hostAddress}: ${e.message}", e)
            return null
        }
        if ((group is Inet4Address && target.address !is Inet4Address) ||
            (group is Inet6Address && target.address !is Inet6Address)
        ) {
            return null
        }
        val socket = try {
            MulticastSocket(null)
        } catch (e: Exception) {
            warn("Failed to create LAN discovery UDP socket for ${target.networkInterface.name}/${target.address.hostAddress}: ${e.message}", e)
            return null
        }
        return try {
            socket.reuseAddress = true
            socket.soTimeout = 500
            socket.networkInterface = target.networkInterface
            socket.bind(InetSocketAddress(config.udpPort))
            socket.joinGroup(InetSocketAddress(group, config.udpPort), target.networkInterface)
            val beacon = UdpBeacon(socket, group, target.address)
            beacon.start()
            beacon
        } catch (e: Exception) {
            // Some OS/interface combinations reject multicast membership even after reporting
            // multicast support. The explicit mDNS instance for this address is still running,
            // so this optional UDP beacon path can be skipped for that interface.
            socket.close()
            warn("Failed to start LAN discovery UDP beacon on ${target.networkInterface.name}/${target.address.hostAddress}: ${e.message}", e)
            null
        }
    }

    private fun localBeaconPayload(interfaceAddress: InetAddress): ByteArray {
        val addresses = host.listenAddresses()
            .map { it.toString() }
            .map { substituteWildcardHost(it, interfaceAddress.hostAddress) }
            .filter { it.isNotBlank() }
            .distinct()
        val json = JSONObject()
            .put("peerId", host.peerId.toBase58())
            .put("multiaddresses", JSONArray(addresses))
        return json.toString().toByteArray(StandardCharsets.UTF_8)
    }

    fun acceptUdpBeacon(bytes: ByteArray, length: Int, sourceAddress: InetAddress? = null): Boolean {
        return try {
            val json = JSONObject(String(bytes, 0, length, StandardCharsets.UTF_8))
            val peerId = json.optString("peerId")
            val addressesJson = json.optJSONArray("multiaddresses") ?: JSONArray()
            val advertised = mutableListOf<String>()
            for (index in 0 until addressesJson.length()) {
                val address = addressesJson.optString(index)
                if (address.isNotBlank()) {
                    advertised += address
                }
            }
            if (peerId.isBlank()) {
                return false
            }
            val sourceDerived = if (sourceAddress == null) {
                emptyList()
            } else {
                advertised.mapNotNull { deriveSourceAddress(it, sourceAddress.hostAddress) }
            }
            val addresses = (sourceDerived + advertised)
                .distinct()
                .take(config.maxAddressesPerBeacon)
                .map { Multiaddr(it) }
            acceptDiscoveredPeer(Libp2pPeerInfo(PeerId.fromBase58(peerId), addresses))
        } catch (e: Exception) {
            malformedBeacons.incrementAndGet()
            val source = sourceAddress?.hostAddress ?: "unknown source"
            warn("Failed to parse LAN discovery UDP beacon from $source: ${e.message}", e)
            signalDiagnosticsChanged()
            false
        }
    }

    fun acceptDiscoveredPeer(peerInfo: Libp2pPeerInfo): Boolean {
        if (!config.enabled) {
            return false
        }

        val peerId = peerInfo.peerId.toBase58()
        if (peerInfo.peerId == host.peerId) {
            return false
        }
        val addresses = peerInfo.addresses
            .map { it.toString() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(config.maxAddressesPerBeacon)
        if (addresses.isEmpty()) {
            return false
        }

        peerRegistry.addImportedPeer(
            Libp2pPeer.remote(
                peerId = peerId,
                multiaddresses = addresses,
                advertisedServices = emptyList()
            ),
            freshness = null,
            exchangeElapsedMillis = 0L,
            origin = PeerRegistryAddOrigin.DISCOVERY,
            persist = false
        )
        maybeDial(peerInfo, peerId, addresses)
        // Publish acceptance only after maybeDial has either reserved its pending work or decided
        // that no dial is needed. Callers that await acceptance and then await zero pending dials
        // must not slip through the interval before the accepted beacon's dial is registered.
        acceptedBeacons.incrementAndGet()
        signalDiagnosticsChanged()
        return true
    }

    private fun maybeDial(peerInfo: Libp2pPeerInfo, peerId: String, addresses: List<String>) {
        val lastVerifiedMs = peerRegistry.getLastDirectConnectionMs(peerId)
        if (lastVerifiedMs != null && clock.currentTimeMillis() - lastVerifiedMs <= config.verifiedPeerFreshnessMs) {
            return
        }
        if (!tryAcquireDialBudget(peerId)) {
            return
        }

        try {
            CompletableFuture.runAsync(
                {
                    try {
                        connectAndExchangePeers(peerInfo.peerId, addresses)
                        peerBackoff.remove(peerId)
                        peerRegistry.addPeer(
                            Libp2pPeer.remote(
                                peerId = peerId,
                                multiaddresses = addresses,
                                advertisedServices = emptyList()
                            ),
                            origin = PeerRegistryAddOrigin.DISCOVERY,
                            persist = true
                        )
                        peerRegistry.recordDirectReachability(peerId)
                        peerRegistry.getObservationLog().recordSuccess(peerId)
                    } catch (e: Exception) {
                        recordDialFailure(peerId)
                    } finally {
                        pendingDials.decrementAndGet()
                        signalDiagnosticsChanged()
                    }
                },
                dialExecutor
            )
        } catch (e: Exception) {
            pendingDials.decrementAndGet()
            signalDiagnosticsChanged()
            warn("Failed to schedule LAN discovery dial for peer '$peerId': ${e.message}", e)
        }
    }

    private fun connectAndExchangePeers(peerId: PeerId, addresses: List<String>) {
        var lastException: Exception? = null
        for (address in addresses) {
            if (address.contains("/ip6/::/") || address.contains("/ip4/0.0.0.0/")) {
                continue
            }
            attemptedAddresses.incrementAndGet()
            signalDiagnosticsChanged()
            try {
                val controller = host.newStream<Libp2pRpcController>(
                    listOf(Libp2pRpcProtocol.PROTOCOL_ID),
                    peerId,
                    Multiaddr(address)
                ).controller.get(5, TimeUnit.SECONDS)
                try {
                    val request = GossipProtocol.PeerExchange(
                        id = "lan-discovery-${host.peerId.toBase58()}-${clock.currentTimeMillis()}",
                        peers = localPeersForExchange(),
                        isRequest = true
                    )
                    val requestStartedAt = samplePeerFreshnessTime(clock)
                    Libp2pRpcProtocol.writeMessage(controller.output, request.toJson())
                    val responseJson = CompletableFuture.supplyAsync {
                        Libp2pRpcProtocol.readMessage(controller.input)
                    }.get(5, TimeUnit.SECONDS)
                    val responseReceivedAt = samplePeerFreshnessTime(clock)
                    val response = GossipProtocol.PeerExchange.fromJson(responseJson)
                    if (response.isRequest || response.id != request.id) {
                        throw UrlProtocolException(
                            "Peer '${peerId.toBase58()}' returned PeerExchange id '${response.id}' " +
                                "with isRequest=${response.isRequest}; expected id '${request.id}' " +
                                "with isRequest=false."
                        )
                    }
                    val exchangeElapsedMillis = peerFreshnessElapsedMillis(requestStartedAt, responseReceivedAt)
                    for (peer in response.peers) {
                        peerRegistry.addImportedPeer(
                            Libp2pPeer.remote(
                                peerId = peer.peerId,
                                multiaddresses = peer.multiaddresses,
                                advertisedServices = peer.advertisedServices
                            ),
                            freshness = peer.freshness,
                            exchangeElapsedMillis = exchangeElapsedMillis,
                            origin = PeerRegistryAddOrigin.DISCOVERY,
                            receivedAtElapsedMillis = responseReceivedAt.nowMillis,
                            receivedAtTimeSample = responseReceivedAt
                        )
                    }
                } finally {
                    controller.close()
                }
                return
            } catch (e: Exception) {
                lastException = e
            }
        }
        throw UrlProtocolException(
            "Failed to connect to LAN-discovered peer '${peerId.toBase58()}': all ${addresses.size} " +
                "announced multiaddresses failed. Last error: ${lastException?.message}",
            lastException
        )
    }

    private fun tryAcquireDialBudget(peerId: String): Boolean {
        val now = clock.currentTimeMillis()
        prunePeerBackoff(now)
        val state = peerBackoff[peerId]
        if (state != null && now < state.nextDialAllowedMs) {
            return false
        }

        synchronized(dialBudgetLock) {
            if (config.maxConcurrentDiscoveryDials <= 0 ||
                pendingDials.get() >= config.maxConcurrentDiscoveryDials
            ) {
                return false
            }

            val currentInterval = intervalStartMs.get()
            if (now - currentInterval >= config.dialRateIntervalMs) {
                intervalStartMs.set(now)
                dialsInInterval.set(0)
            }

            val current = dialsInInterval.get()
            if (config.maxDialsPerInterval <= 0 || current >= config.maxDialsPerInterval) {
                return false
            }

            dialsInInterval.set(current + 1)
            dialAttempts.incrementAndGet()
            // Publish the pending reservation last. A diagnostics snapshot that observes it must
            // also observe the corresponding cumulative dial attempt.
            pendingDials.incrementAndGet()
        }
        signalDiagnosticsChanged()
        return true
    }

    private fun recordDialFailure(peerId: String) {
        val now = clock.currentTimeMillis()
        peerBackoff.compute(peerId) { _, existing ->
            val nextBackoff = if (existing == null) {
                config.initialFailureBackoffMs
            } else {
                (existing.backoffMs * 2).coerceAtMost(config.maxFailureBackoffMs)
            }
            BackoffState(
                backoffMs = nextBackoff,
                nextDialAllowedMs = now + nextBackoff,
                updatedMs = now
            )
        }
        prunePeerBackoff(now)
        peerRegistry.getObservationLog().recordFailure(peerId)
        signalDiagnosticsChanged()
    }

    private fun prunePeerBackoff(now: Long) {
        for ((peerId, state) in peerBackoff.entries) {
            if (now - state.nextDialAllowedMs > config.peerBackoffExpiredRetentionMs) {
                peerBackoff.remove(peerId, state)
            }
        }
        while (peerBackoff.size > config.peerBackoffMaxEntries) {
            val victim = peerBackoff.entries.minWithOrNull(compareBy({ it.value.nextDialAllowedMs }, { it.value.updatedMs }))
                ?: return
            peerBackoff.remove(victim.key, victim.value)
        }
    }

    private fun qualifyingBindTargets(): List<BindTarget> {
        val targets = mutableListOf<BindTarget>()
        val interfaces = try {
            Collections.list(NetworkInterface.getNetworkInterfaces())
        } catch (e: Exception) {
            emptyList()
        }
        for (networkInterface in interfaces) {
            if (!interfaceAllowed(networkInterface)) {
                continue
            }
            val qualifies = try {
                networkInterface.isUp && (networkInterface.supportsMulticast() || networkInterface.isLoopback)
            } catch (e: Exception) {
                false
            }
            if (!qualifies) {
                continue
            }
            for (address in Collections.list(networkInterface.inetAddresses)) {
                if (addressAllowed(address)) {
                    targets += BindTarget(networkInterface, address)
                }
            }
        }
        if (targets.none { it.address.isLoopbackAddress }) {
            val loopback = NetworkInterface.getByInetAddress(InetAddress.getByName("127.0.0.1"))
            if (loopback != null) {
                targets += BindTarget(loopback, InetAddress.getByName("127.0.0.1"))
            }
        }
        return targets.distinctBy { "${it.networkInterface.name}:${it.address.hostAddress}" }
    }

    private fun interfaceAllowed(networkInterface: NetworkInterface): Boolean {
        val name = networkInterface.name
        val displayName = networkInterface.displayName
        if (config.interfaceAllowlist.isNotEmpty() &&
            name !in config.interfaceAllowlist &&
            displayName !in config.interfaceAllowlist
        ) {
            return false
        }
        if (name in config.interfaceDenylist || displayName in config.interfaceDenylist) {
            return false
        }
        return true
    }

    private fun addressAllowed(address: InetAddress): Boolean {
        if (config.addressCidrsAllowlist.isNotEmpty() &&
            config.addressCidrsAllowlist.none { cidrContains(it, address) }
        ) {
            return false
        }
        if (config.addressCidrsDenylist.any { cidrContains(it, address) }) {
            return false
        }
        return address is Inet4Address || address is Inet6Address
    }

    private data class BackoffState(
        val backoffMs: Long,
        val nextDialAllowedMs: Long,
        val updatedMs: Long
    )

    private data class BindTarget(
        val networkInterface: NetworkInterface,
        val address: InetAddress
    )

    private inner class UdpBeacon(
        private val socket: MulticastSocket,
        private val group: InetAddress,
        private val interfaceAddress: InetAddress
    ) {
        private val running = AtomicBoolean(true)
        private val thread = Thread({ run() }, "LanPeerDiscovery-udp").apply { isDaemon = true }

        fun start() {
            thread.start()
        }

        fun stop() {
            running.set(false)
            socket.close()
            thread.join(1_000)
        }

        private fun run() {
            var nextAnnouncementMs = clock.currentTimeMillis()
            val buffer = ByteArray(65_507)
            while (running.get()) {
                val now = clock.currentTimeMillis()
                if (now >= nextAnnouncementMs) {
                    try {
                        sendAnnouncement()
                    } catch (e: Exception) {
                        if (running.get()) {
                            warn("LAN discovery UDP socket error while sending on ${interfaceAddress.hostAddress}: ${e.message}", e)
                        }
                    }
                    nextAnnouncementMs = now + TimeUnit.SECONDS.toMillis(config.queryIntervalSeconds.toLong())
                }
                val packet = DatagramPacket(buffer, buffer.size)
                try {
                    socket.receive(packet)
                    acceptUdpBeacon(packet.data, packet.length, packet.address)
                } catch (e: SocketTimeoutException) {
                    // Timeout is the receive loop's clock tick; periodic announcements are driven above.
                } catch (e: Exception) {
                    if (running.get()) {
                        warn("LAN discovery UDP socket error while receiving on ${interfaceAddress.hostAddress}: ${e.message}", e)
                    }
                }
            }
        }

        private fun sendAnnouncement() {
            val payload = localBeaconPayload(interfaceAddress)
            val packet = DatagramPacket(payload, payload.size, InetSocketAddress(group, config.udpPort))
            socket.send(packet)
        }
    }

    private fun warn(message: String, cause: Throwable? = null) {
        warningCount.incrementAndGet()
        emitLanDiscoveryWarning(LanDiscoveryWarningEffect(message, cause), warningSink)
        signalDiagnosticsChanged()
    }

    private fun signalDiagnosticsChanged() {
        synchronized(waitMonitor) {
            waitMonitor.notifyAll()
        }
    }

    private fun newDialExecutor(): ExecutorService {
        return Executors.newCachedThreadPool { runnable ->
            Thread(runnable, "LanPeerDiscovery-dial").apply { isDaemon = true }
        }
    }
}

internal fun tossLanDiscoveryWarning(message: String, cause: Throwable? = null) {
    emitLanDiscoveryWarning(LanDiscoveryWarningEffect(message, cause))
}

private fun emitLanDiscoveryWarning(
    effect: LanDiscoveryWarningEffect,
    sink: (LanDiscoveryWarningEffect) -> Unit = {}
) {
    sink(effect)
    try {
        toss(effect)
    } catch (e: UnhandledNotificationEffect) {
        if (e.effect !== effect) {
            throw e
        }
        // Discovery warnings are intentionally best-effort: callers may install an
        // algebraic-effect handler, but absence of one must not make discovery startup fatal.
    }
}

private fun validateCidr(cidr: String) {
    val pieces = cidr.split("/")
    require(pieces.size == 2) {
        "Invalid LAN discovery CIDR '$cidr': expected '<address>/<prefixLength>'"
    }
    val network = InetAddress.getByName(pieces[0])
    val prefixLength = pieces[1].toIntOrNull()
        ?: throw IllegalArgumentException(
            "Invalid LAN discovery CIDR '$cidr': prefix '${pieces[1]}' is not an integer"
        )
    require(prefixLength in 0..(network.address.size * 8)) {
        "Invalid LAN discovery CIDR '$cidr': prefix length $prefixLength is outside valid range 0..${network.address.size * 8}"
    }
}

private fun cidrContains(cidr: String, address: InetAddress): Boolean {
    validateCidr(cidr)
    val pieces = cidr.split("/")
    val network = InetAddress.getByName(pieces[0])
    val prefixLength = pieces[1].toInt()
    val networkBytes = network.address
    val addressBytes = address.address
    if (networkBytes.size != addressBytes.size) {
        return false
    }

    var remainingBits = prefixLength
    for (index in networkBytes.indices) {
        if (remainingBits <= 0) {
            return true
        }
        val bits = remainingBits.coerceAtMost(8)
        val mask = (0xFF shl (8 - bits)) and 0xFF
        if ((networkBytes[index].toInt() and mask) != (addressBytes[index].toInt() and mask)) {
            return false
        }
        remainingBits -= bits
    }
    return true
}

private fun deriveSourceAddress(multiaddr: String, sourceHost: String): String? {
    if (!multiaddr.contains("/tcp/")) {
        return null
    }
    return replaceIpHost(multiaddr, sourceHost)
}

private fun substituteWildcardHost(multiaddr: String, concreteHost: String): String {
    if (!multiaddr.contains("/ip4/0.0.0.0/") && !multiaddr.contains("/ip6/::/")) {
        return multiaddr
    }
    return replaceIpHost(multiaddr, concreteHost) ?: multiaddr
}

private fun replaceIpHost(multiaddr: String, host: String): String? {
    val protocol = if (host.contains(":")) "ip6" else "ip4"
    val ip4 = Regex("/ip4/[^/]+/")
    val ip6 = Regex("/ip6/[^/]+/")
    return when {
        ip4.containsMatchIn(multiaddr) -> multiaddr.replace(ip4, "/$protocol/$host/")
        ip6.containsMatchIn(multiaddr) -> multiaddr.replace(ip6, "/$protocol/$host/")
        else -> null
    }
}
