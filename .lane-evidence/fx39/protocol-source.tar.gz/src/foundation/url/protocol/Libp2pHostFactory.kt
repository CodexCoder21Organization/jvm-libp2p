package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.clocks.simple.Scheduled

import community.kotlin.logging.MessageSeverity
import io.libp2p.core.Host
import io.libp2p.core.Connection
import io.libp2p.core.Stream
import io.libp2p.core.crypto.KeyType
import io.libp2p.core.crypto.generateKeyPair
import io.libp2p.core.dsl.host
import io.libp2p.core.multiformats.Multiaddr
import io.libp2p.core.multistream.ProtocolBinding
import io.libp2p.core.multistream.StrictProtocolBinding
import io.libp2p.core.multistream.ProtocolDescriptor
import io.libp2p.protocol.Identify
import io.libp2p.protocol.IdentifyBinding
import io.libp2p.protocol.IdentifyController
import io.libp2p.protocol.Ping
import io.libp2p.security.noise.NoiseXXSecureChannel
import io.libp2p.transport.tcp.TcpTransport
import io.libp2p.core.mux.StreamMuxerProtocol
import io.netty.buffer.ByteBuf
import io.netty.buffer.CompositeByteBuf
import io.netty.buffer.Unpooled
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelDuplexHandler
import io.netty.channel.ChannelInboundHandlerAdapter
import io.netty.channel.DefaultChannelPromise
import io.netty.util.concurrent.ImmediateEventExecutor
import io.netty.channel.ChannelPromise
import io.netty.channel.SimpleChannelInboundHandler
import io.netty.handler.codec.LengthFieldBasedFrameDecoder
import io.netty.handler.codec.ByteToMessageDecoder
import io.netty.handler.codec.CorruptedFrameException
import io.netty.handler.timeout.ReadTimeoutException
import io.netty.util.AttributeKey
import org.json.JSONObject
import java.io.*
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import kotlin.concurrent.thread
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.locks.ReentrantLock
import java.nio.charset.StandardCharsets
import kotlin.concurrent.withLock
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.algebraiceffects.`$effectHandlerRepository`
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.toss
import kotlin.coroutines.resume

/**
 * Default idle timeout for RPC streams in seconds.
 * Streams that receive no messages for this duration are closed.
 * Set to 120s (2 minutes) which is 2-4x the typical gossip interval (30-60s).
 */
const val RPC_STREAM_IDLE_TIMEOUT_SECONDS = 120L

/**
 * Observes the request-admission pause on a server-side unified RPC stream.
 *
 * The callback is invoked on the stream event loop when the pending-request bound pauses or
 * resumes reads. It is an observation seam for callers that need to coordinate work with the
 * admission boundary; it does not change the admission thresholds or stream lifetime policy. The
 * callback must be quick and must not throw, because it runs inline on the stream event loop.
 */
fun interface RpcReadPauseObserver {
    fun onReadPauseChanged(paused: Boolean)
}

/**
 * Existing bound used by the libp2p network close path. PeerExchange host-stop draining reuses
 * this same lifecycle budget so a stuck registry callback cannot make a host stop unbounded.
 */
internal const val LIBP2P_HOST_STOP_TIMEOUT_SECONDS: Long = 5L

/**
 * Aggregate retained-object budget for admitted PeerExchange requests. It scales with the JVM
 * heap but has a fixed floor and ceiling, so a single host cannot retain an unbounded parsed peer
 * list even when the count-based running and pending limits are not full.
 */
private val PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET: Int =
    (Runtime.getRuntime().maxMemory() / 8L)
        .coerceIn(8L * 1024 * 1024, 32L * 1024 * 1024)
        .toInt()

/**
 * WriteBufferWaterMark applied to mux substream channels so [io.netty.channel.Channel.isWritable]
 * trips at sane thresholds. Without an explicit setting, mplex MuxChannel uses
 * Netty defaults (32KB low / 64KB high) which is fine in principle, but explicitly
 * configuring it makes the contract visible and lets us tune separately from Netty defaults.
 *
 * 32KB low / 64KB high keeps per-stream peak retained bytes around 64KB even
 * under flood, which fits comfortably in CN's 128MB heap budget across hundreds
 * of concurrent streams.
 */
internal val LIBP2P_RPC_WRITE_WATER_MARK: io.netty.channel.WriteBufferWaterMark =
    io.netty.channel.WriteBufferWaterMark(32 * 1024, 64 * 1024)

/**
 * Maximum time [writeFramedBufferWithBackpressure] will block waiting for a
 * stalled channel to become writable when called from a non-event-loop thread.
 * After this, the buffer is dropped to prevent unbounded WriteTask accumulation
 * (the OOM root cause from production outage 2026-04-27).
 *
 * 200ms is short enough that a tight producer loop hitting a sustained stall
 * doesn't pile up Thread.sleep latency (a multi-second wait would let a 1k-write
 * flood take many minutes to drain), but long enough that occasional bursts on a
 * healthy peer ride out a transient TCP congestion event.
 */
internal const val WRITE_BACKPRESSURE_WAIT_MS: Long = 200L
internal const val WRITE_BACKPRESSURE_POLL_MS: Long = 5L

/**
 * How long an AWAITED request/effect framed write ([writeRpcMessageReturningDelivered],
 * [writeStreamingBytecodeMessageReturningDelivered], the client request path in [NettyOutputStream],
 * and the effect-request path) will wait for a transiently-stalled connection to recover writability
 * before giving up. Computed handler responses use [AwaitedResponseOutbox] instead: they pin no
 * caller thread and remain queued through a transient stall, while a root that stops accepting
 * writes is retired by [AWAITED_RESPONSE_OUTBOX_STALLED_CONNECTION_GRACE_MS].
 *
 * **Why a separate, much longer wait than [WRITE_BACKPRESSURE_WAIT_MS]:** the 200ms best-effort wait
 * was the systemic root cause of every 30s/120s RPC hang on the prod host (netlab-hosted uploadFile/
 * logs/apply, lambdaserver callback "Stream closed", buildtest uploadChunk 120s). A real TCP
 * congestion event, a peer GC pause, or a momentarily-slow reader keeps the connection unwritable for
 * far longer than 200ms. Dropping an awaited request after only 200ms loses a message the
 * connection would have accepted a moment later, so the awaiting caller hangs its full invocation
 * timeout even though nothing was actually wrong with the connection. Best-effort gossip can still
 * drop fast (it is loss-tolerant and high-volume); computed responses are retained by the bounded
 * outbox, while request/effect writes use this bounded wait.
 *
 * Bounded (not infinite) so a genuinely *wedged* / dead peer fails the write — and the caller
 * fast-fails — well within the 30s RPC invocation timeout, instead of parking forever.
 *
 * 5s is chosen as the smallest value that comfortably rides out the real prod stalls while still
 * fast-failing a dead connection: a multi-MB payload (a 1.7 MB bytecode response, a 2 MB uploadChunk)
 * leaves the connection unwritable only until the peer drains it — sub-second at datacenter/loopback
 * rates, a few seconds for a slow-but-alive peer — so 5s delivers virtually every transient stall
 * while the 200ms wait dropped them. It is also deliberately kept under the awaited-write fast-fail
 * contract enforced by `testSendRequestFastFailsWhenConnectionUnwritable` (a dropped awaited write
 * must surface within 8s) — do not raise it past that bound.
 */
internal const val WRITE_BACKPRESSURE_DELIVERY_WAIT_MS: Long = 5_000L

/**
 * How long a root connection may hold an admitted response while it is non-writable before the
 * server retires that connection. This is twice [WRITE_BACKPRESSURE_DELIVERY_WAIT_MS], preserving
 * the existing six-second relay-target backpressure contract while keeping a genuinely stalled
 * connection well inside the 15-second end-to-end retirement bound. The timer is armed only when
 * the outbox has buffered output and the root is non-writable, and is canceled when the root
 * becomes writable again.
 */
internal const val AWAITED_RESPONSE_OUTBOX_STALLED_CONNECTION_GRACE_MS: Long =
    WRITE_BACKPRESSURE_DELIVERY_WAIT_MS * 2L

const val RESPONSE_DELIVERY_ENDED_CODE: String = "RESPONSE_DELIVERY_ENDED"

const val RESPONSE_DELIVERY_ENDED_MESSAGE: String =
    "The request handler completed, but UrlProtocol closed the connection before its queued " +
        "response was delivered. No response-frame byte completed, and the request was not replayed."

enum class RpcResponseDeliveryCloseInitiator {
    PROTOCOL,
    TRANSPORT,
}

/**
 * Reports one completed RPC response that could not leave its response outbox before teardown.
 */
class RpcResponseDeliveryLossEffect(
    val requestId: String,
    val method: String,
    val serviceIdentifier: String,
    val childStreamId: String,
    val rootConnectionGeneration: Long,
    val closeInitiator: RpcResponseDeliveryCloseInitiator,
    val deliveryCause: Throwable,
    val responseFrameBytesCompleted: Long,
    val rootLinkDiagnostics: RootLinkDiagnostics?,
) : NotificationEffect(
    "Completed RPC response '$requestId' for '$method' on service '$serviceIdentifier' was not " +
        "delivered on child stream '$childStreamId' of root generation " +
        "$rootConnectionGeneration; close initiator=$closeInitiator; cause=" +
        "${deliveryCause.javaClass.name}: ${deliveryCause.message ?: "no message"}; " +
        "response-frame bytes completed=$responseFrameBytesCompleted" + rootLinkDiagnostics.diagnosticSuffix(),
    MessageSeverity.ERROR,
    deliveryCause,
) {
    constructor(requestId: String, method: String, serviceIdentifier: String, childStreamId: String,
        rootConnectionGeneration: Long, closeInitiator: RpcResponseDeliveryCloseInitiator,
        deliveryCause: Throwable, responseFrameBytesCompleted: Long) : this(requestId, method,
        serviceIdentifier, childStreamId, rootConnectionGeneration, closeInitiator, deliveryCause, responseFrameBytesCompleted, null)
}

private fun structuredDeliveryLossValue(value: String): String =
    value.replace("\\", "\\\\").replace("'", "\\'").replace("\r", "\\r").replace("\n", "\\n")

private fun reportRpcResponseDeliveryLoss(effect: RpcResponseDeliveryLossEffect) {
    System.err.println(
        "[RpcResponseDeliveryLoss] " +
            "requestId='${structuredDeliveryLossValue(effect.requestId)}' " +
            "method='${structuredDeliveryLossValue(effect.method)}' " +
            "service='${structuredDeliveryLossValue(effect.serviceIdentifier)}' " +
            "childStream='${structuredDeliveryLossValue(effect.childStreamId)}' " +
            "rootConnectionGeneration=${effect.rootConnectionGeneration} " +
            "closeInitiator=${effect.closeInitiator} " +
            "cause='${structuredDeliveryLossValue(effect.deliveryCause.javaClass.name + ": " +
                (effect.deliveryCause.message ?: "no message"))}' " +
            "responseFrameBytesCompleted=${effect.responseFrameBytesCompleted}" +
            (effect.rootLinkDiagnostics?.let { " $it" } ?: "")
    )
    try {
        toss(effect)
    } catch (unhandled: UnhandledNotificationEffect) {
        if (unhandled.effect !== effect) throw unhandled
        // Swallowed deliberately: root teardown has no caller-side effect handler. The structured
        // stderr line above is the durable record, and reporting must not alter channel cleanup.
    }
}

/**
 * Reports that an ordered RPC response close barrier failed before the stream was closed.
 *
 * The effect is deliberately not caught at the protocol layer. Callers may handle this specific
 * type at the application boundary. This effect owns [cause] because the selected
 * algebraic-effects runtime does not retain the cause supplied to [NotificationEffect]; the
 * message includes the cause class and complete message so the always-on unhandled report renders
 * the failure details.
 */
class RpcResponseCloseBarrierFailureEffect(
    val responseType: String,
    val peerId: String,
    val barrierTimeoutMillis: Long,
    val cause: Throwable
) : NotificationEffect(
    "$responseType response close barrier for peer $peerId did not complete within " +
        "$barrierTimeoutMillis milliseconds; the response stream will be closed; cause: " +
        "${cause.javaClass.name}${cause.message?.let { ": $it" } ?: ""}",
    MessageSeverity.ERROR,
    cause
)

/**
 * Describes a PeerExchange request refused before its parsed peer list could be retained by the
 * host-owned admission scope.
 */
class PeerExchangeAdmissionWarningEffect(
    val peerId: String,
    val requestRetainedBytes: Int,
    val aggregateRetainedBytes: Int,
    val aggregateRetainedByteLimit: Int,
    val reason: String
) : NotificationEffect(
    "PeerExchange request from $peerId was rejected: estimated retained bytes=" +
        "$requestRetainedBytes; aggregate retained bytes=$aggregateRetainedBytes; " +
        "aggregate retained-byte limit=$aggregateRetainedByteLimit; $reason",
    MessageSeverity.WARNING
)

/**
 * Immutable diagnostics for one host's aggregate PeerExchange request admission scope.
 * [completedAdmissionAttempts] advances only after the public interaction report (and, for a
 * rejection, its typed warning report) has returned, so monitoring callers can use it as a
 * server-observable completion barrier rather than inferring admission from client writes.
 */
data class PeerExchangeAdmissionSnapshot(
    val completedAdmissionAttempts: Long,
    val admittedRequests: Long,
    val rejectedRequests: Long,
    val retainedBytesInUse: Long,
    val maxObservedRetainedBytes: Long,
    val pendingRequests: Int,
    val startingRequests: Int,
    val runningRequests: Int,
    val retainedByteLimit: Int,
    val closed: Boolean,
)

private fun reportPeerExchangeAdmissionWarning(effect: PeerExchangeAdmissionWarningEffect) {
    try {
        toss(effect)
    } catch (unhandled: UnhandledNotificationEffect) {
        // An inbound stream has no caller-side effect handler. Keep the expected admission
        // refusal local when nobody handles this warning, while allowing unrelated unhandled
        // effects to propagate normally.
        if (unhandled.effect !== effect) throw unhandled
    }
}

/**
 * A large attachment is already bounded to one 256 KiB chunk per active writer. Do not apply the
 * ordinary single-frame delivery cutoff between its chunks: a busy but progressing multiplexed
 * connection can stay above its high-water mark for longer than five seconds. The RPC invocation
 * deadline remains responsible for ending a transfer whose peer stops making progress.
 */
private const val ATTACHMENT_WRITE_BACKPRESSURE_WAIT_MS: Long = Long.MAX_VALUE

/**
 * Maximum number of framed writes that may simultaneously PARK waiting for one stalled connection to
 * recover writability. Each parked write holds one caller thread plus the retained [ByteBuf]; capping
 * the count per connection bounds both the parked memory (≈ cap × frame size per connection) and the
 * number of caller/handler threads a single misbehaving peer can tie up — so a few wedged connections
 * can never drain the whole RPC handler pool or balloon the heap.
 *
 * When the cap is reached, a further write that finds the connection unwritable is dropped
 * immediately (returns false) instead of adding another parked thread. This is the sustained-
 * backpressure / OOM safety valve: under a genuine flood to an unreading peer, memory and threads
 * stay bounded exactly as the original 200ms-drop design intended — the difference is that, below the
 * cap, an awaited write now *rides out a transient stall and is delivered* rather than being dropped
 * unconditionally at 200ms.
 *
 * Exposed (public, non-const for binary stability) so tests can assert the bound directly.
 */
val maxConcurrentParkedWritesPerConnection: Int = 16

/**
 * Per-connection park-budget semaphore, stored as a Netty channel attribute on the ROOT connection
 * channel so it is shared by all of that connection's mux substreams and is garbage-collected with
 * the connection (no separate map to leak or reap). Lazily created on first contended write.
 */
private val PARKED_WRITE_BUDGET_ATTR: AttributeKey<Semaphore> =
    AttributeKey.valueOf("foundation.url.protocol.parkedWriteBudget")

/**
 * Counts the chunked attachment frames currently being written to one mux SUBSTREAM channel.
 *
 * A chunked attachment frame occupies the substream across several separate writes — framing
 * header, per-attachment length prefix, then bounded body chunks — and is only atomic on the wire
 * if nothing else writes to that substream in between. Every RPC frame writer serializes on
 * [rpcStreamWriteLock] for exactly that reason, but [AwaitedResponseOutbox.drain] cannot: it runs
 * on the connection event loop, which is what drains the socket, so blocking it on a lock a parked
 * off-loop writer may hold for the length of a stalled transfer would deadlock the connection.
 * The drain therefore consults this counter instead and defers an entry whose substream is
 * mid-frame, which needs no lock and cannot block the loop. The counter is set before the frame's
 * first write and cleared after its last, both on the writer thread, so a drain that reads zero is
 * reading a substream the writer has not yet begun writing to.
 */
private val CHUNKED_ATTACHMENT_FRAME_DEPTH_ATTR: AttributeKey<AtomicInteger> =
    AttributeKey.valueOf("foundation.url.protocol.chunkedAttachmentFrameDepth")

/**
 * Bounds large off-event-loop write handoff tasks and zero-budget writes that are waiting for
 * Netty to complete their ordinary thread-safe write handoff. It is separate from the parked-write
 * budget: a connection may have both callers waiting for writability and writes already handed to
 * its loop. Small awaited frames use the byte-bounded lane below.
 */
private val WRITE_HANDOFF_BUDGET_ATTR: AttributeKey<Semaphore> =
    AttributeKey.valueOf("foundation.url.protocol.writeHandoffBudget")

/**
 * Cross-lane admission state for one physical connection. A large awaited write increments
 * [pendingLargeAwaitedWrites] as soon as it starts waiting. Compact and zero-budget writes that
 * arrive after that point do not submit independent handoff tasks until the older large write has
 * completed, so the compact lane cannot repeatedly pass a parked large writer.
 */
private class WriteHandoffOrdering {
    val pendingLargeAwaitedWrites = AtomicInteger(0)

    fun allowsAdmission(largeAwaitedWrite: Boolean): Boolean =
        largeAwaitedWrite || pendingLargeAwaitedWrites.get() == 0
}

private val WRITE_HANDOFF_ORDERING_ATTR: AttributeKey<WriteHandoffOrdering> =
    AttributeKey.valueOf("foundation.url.protocol.writeHandoffOrdering")

/**
 * Compact positive-budget frames get a separate handoff lane. Relay admission opts its bounded
 * frames into the same lane through 256 KiB on non-Yamux streams; generic writers retain the
 * 64 KiB boundary below. Each Yamux child may retain at most 256 KiB of copied bytes; excess
 * frames use the non-copying handoff. When root compact units are full, Yamux writes also use
 * that bounded non-copying handoff so peer receive credit cannot prevent sibling progress.
 * If the root becomes unwritable after a compact handoff starts, up to 256 KiB of
 * exact-size copied child frames may join that root handoff without waiting for an event-loop turn.
 * Waiting for an event-loop scheduling turn can otherwise reject a valid write while the root
 * connection is still writable. The lane has sixty-four 64 KiB units: a small frame takes one unit
 * and a 256 KiB relay frame takes four, so copied frames retain at most 4 MiB per connection.
 * Frames beyond a caller's compact boundary and zero-budget probes keep the stricter 16-write
 * handoff budget.
 */
private const val SMALL_AWAITED_HANDOFF_FRAME_BYTES = 64L * 1024L
private const val SMALL_AWAITED_HANDOFF_UNIT_BYTES = 64L * 1024L
private const val SMALL_AWAITED_HANDOFF_LIMIT = 64
private const val RELAY_COMPACT_HANDOFF_FRAME_BYTES = 256L * 1024L
private const val YAMUX_CHILD_COMPACT_HANDOFF_BYTES = 256 * 1024
private const val YAMUX_CHILD_ROOT_HANDOFF_LIMIT = 4
private val YAMUX_CHILD_COMPACT_HANDOFF_BUDGET_ATTR: AttributeKey<Semaphore> =
    AttributeKey.valueOf("foundation.url.protocol.yamuxChildCompactHandoffBudget")
private val YAMUX_CHILD_ROOT_HANDOFF_BUDGET_ATTR: AttributeKey<Semaphore> =
    AttributeKey.valueOf("foundation.url.protocol.yamuxChildRootHandoffBudget")
private val SMALL_AWAITED_WRITE_HANDOFF_BUDGET_ATTR: AttributeKey<Semaphore> =
    AttributeKey.valueOf("foundation.url.protocol.smallAwaitedWriteHandoffBudget")
private val COMMITTED_COMPACT_HANDOFF_UNITS_ATTR: AttributeKey<AtomicInteger> =
    AttributeKey.valueOf("foundation.url.protocol.committedCompactHandoffUnits")

/** Root units reserved before copying are not pending writes until Netty owns their buffer. */
private class CompactHandoffReservation(
    private val budget: Semaphore,
    private val units: Int,
    private val committedUnits: AtomicInteger,
) {
    val committed = AtomicBoolean(false)
    private val released = AtomicBoolean(false)

    fun commit(future: io.netty.channel.ChannelFuture) {
        check(committed.compareAndSet(false, true))
        committedUnits.addAndGet(units)
        if (!future.isDone) future.addListener { release() }
        // A completed future must return units even when its event loop is shutting down.
        if (future.isDone) release()
    }

    fun release() {
        if (released.compareAndSet(false, true)) {
            if (committed.get()) committedUnits.addAndGet(-units)
            budget.release(units)
        }
    }
}

private fun tryReserveCompactHandoff(
    channel: io.netty.channel.Channel,
    units: Int,
): CompactHandoffReservation? {
    val budget = smallAwaitedWriteHandoffBudgetFor(channel)
    if (!budget.tryAcquire(units)) return null
    val attr = libp2pRootConnectionChannel(channel).attr(COMMITTED_COMPACT_HANDOFF_UNITS_ATTR)
    val committedUnits = attr.get() ?: AtomicInteger().let { attr.setIfAbsent(it) ?: it }
    return CompactHandoffReservation(budget, units, committedUnits)
}

/**
 * Fair one-frame attachment admission gate stored on the root physical connection. Every inbound
 * RPC substream on that connection shares it, so one peer cannot consume the process attachment
 * allowance with many partially drained frames while an independent connection is ready.
 */
private val ATTACHMENT_FRAME_TURN_ATTR:
    AttributeKey<Libp2pRpcProtocol.AttachmentFrameTurn> =
    AttributeKey.valueOf("foundation.url.protocol.attachmentFrameTurn")

/**
 * Awaited response frames are retained without pinning their handler threads when a root connection
 * is temporarily unwritable. Writable roots use both the per-connection and process-wide limits.
 * Once a root becomes non-writable, queued entries release their process-wide charge and remain
 * bounded by the per-connection limits while the retirement grace runs, so one stalled peer cannot
 * consume the allowance needed by healthy roots.
 *
 * Normal responses and priority frames share 4 MiB/connection and 8 MiB/process.
 * Responses that do not fit wait uncharged for space instead of being discarded.
 * Within that response pool, the priority lane (frames no larger than 64 KiB) is capped at
 * 1 MiB/connection and 2 MiB/process.
 * Reserved OUTBOX_FULL signals: separate ordinary and declared-long-poll pools, each
 * 1.5 MiB/connection and 3 MiB/process.
 *
 * Reader refusals: a separate 128 KiB/connection and 256 KiB/process, never waiting for admission.
 * Charged output is therefore bounded by 7.125 MiB/connection (5.625 MiB without declared polls).
 * Process-wide limits continue to cap
 * entries held by writable roots; stalled roots are separately bounded per connection and retired
 * after the finite grace above.
 */
internal const val AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PER_CONNECTION: Long = 4L * 1024L * 1024L
internal const val AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PROCESS_WIDE: Long = 8L * 1024L * 1024L
internal const val AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES: Int = 64 * 1024
internal const val AWAITED_RESPONSE_OUTBOX_PRIORITY_BYTES_PER_CONNECTION: Long = 1L * 1024L * 1024L
internal const val AWAITED_RESPONSE_OUTBOX_PRIORITY_BYTES_PROCESS_WIDE: Long = 2L * 1024L * 1024L
internal const val AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION: Long =
    1536L * 1024L
internal const val AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PROCESS_WIDE: Long =
    3L * 1024L * 1024L
private const val RELAY_REFUSAL_BYTES_PER_CONNECTION = 128L * 1024L
private const val RELAY_REFUSAL_BYTES_PROCESS_WIDE = 256L * 1024L
internal const val AWAITED_RESPONSE_OUTBOX_FULL_CODE: String = "OUTBOX_FULL"
internal const val AWAITED_RESPONSE_OUTBOX_FULL_MESSAGE: String =
    "The request handler completed, but its response could not be returned because the awaited " +
        "response outbox was full. The request was not replayed."
internal const val AWAITED_RESPONSE_ROOT_RETIRING_METADATA_KEY: String =
    "foundation.url.protocol.root-retiring"
internal const val AWAITED_RESPONSE_ROOT_RETIRING_METADATA_FALSE: String = "0"
internal const val AWAITED_RESPONSE_ROOT_RETIRING_METADATA_TRUE: String = "1"
private val awaitedResponseRootRetiringFalseWireMarker: ByteArray =
    ("\"$AWAITED_RESPONSE_ROOT_RETIRING_METADATA_KEY\":" +
        "\"$AWAITED_RESPONSE_ROOT_RETIRING_METADATA_FALSE\"")
        .toByteArray(StandardCharsets.UTF_8)

private val AWAITED_RESPONSE_OUTBOX_ATTR: AttributeKey<AwaitedResponseOutbox> =
    AttributeKey.valueOf("foundation.url.protocol.awaitedResponseOutbox")
private val AWAITED_RESPONSE_RECONCILIATION_CLOCK_ATTR: AttributeKey<Clock> =
    AttributeKey.valueOf("foundation.url.protocol.awaitedResponseReconciliationClock")
private val AWAITED_RESPONSE_OUTBOX_CHILD_ATTR: AttributeKey<AwaitedResponseOutbox> =
    AttributeKey.valueOf("foundation.url.protocol.awaitedResponseOutboxChild")
private val AWAITED_RESPONSE_OUTBOX_OBSERVER_ATTR:
    AttributeKey<java.util.function.Consumer<String>> =
    AttributeKey.valueOf("foundation.url.protocol.awaitedResponseOutboxObserver")
private val INTERLEAVED_WRITE_WAIT_THREAD_OBSERVER_ATTR:
    AttributeKey<java.util.function.Consumer<Thread>> =
    AttributeKey.valueOf("foundation.url.protocol.interleavedWriteWaitThreadObserver")
private val awaitedResponseOutboxResponseBytesProcessWide = AtomicLong()
private val awaitedResponseOutboxPriorityBytesProcessWide = AtomicLong()
private val awaitedResponseOutboxFailureBytesProcessWide = AtomicLong()
private val awaitedResponseOutboxLongPollFailureBytesProcessWide = AtomicLong()
private val relayRefusalBytesProcessWide = AtomicLong()
private val awaitedResponseRootConnectionGeneration = AtomicLong()
private val awaitedResponseFailureCapacityWaiters =
    java.util.concurrent.ConcurrentLinkedQueue<AwaitedResponseFailureCapacityWaiter>()
/** Outboxes waiting for connection admission or a shared charge before transport handoff. */
private val awaitedResponseOutboxesWithPendingCharges: MutableSet<AwaitedResponseOutbox> =
    ConcurrentHashMap.newKeySet()
private const val AWAITED_RESPONSE_OUTBOX_DRAIN_BATCH_ENTRIES: Int = 32

private val RPC_OBSERVER_REPORTING_FAILURE_ATTR: AttributeKey<String> =
    AttributeKey.valueOf("foundation.url.protocol.observerReportingFailure")

private fun reportWritabilityWaitObserverFailure(
    notification: RpcObserverNotification,
    failure: Throwable,
) {
    val observerDescription = notification.description
    // The failure object was created by the observer, so its message and stack-trace rendering
    // are overridable and can themselves throw. Render inside this boundary; if the rendering
    // fails, report a fixed record naming only the two exception classes. Class identity is read
    // through final methods, so the object that already failed is never called into again.
    val failureClassName = failure.javaClass.name
    try {
        System.err.println(
            "[RPC] $observerDescription failed: " +
                "$failureClassName: ${failure.message}",
        )
        failure.printStackTrace(System.err)
    } catch (renderingFailure: Throwable) {
        rethrowFatalJvmError(renderingFailure)
        notification.failureRecord =
            "[RPC] $observerDescription failed with $failureClassName, and rendering that " +
                "failure threw ${renderingFailure.javaClass.name}; no message or stack trace " +
                "can be reported for it"
        System.err.println(notification.failureRecord)
    }
}

/**
 * Notifications collected by nested ownership scopes on this thread. The outermost scope removes
 * the record before dispatch, so a callback may re-enter a writer or wait for another writer.
 * There is no shared callback lock and no ordering guarantee between different threads.
 */
private class RpcObserverNotification(
    val description: String,
    val failedReport: io.netty.util.Attribute<String>,
    val deliver: () -> Unit,
) {
    var failureRecord: String = description
}

private val rpcObserverNotifications = ThreadLocal<MutableList<RpcObserverNotification>>()

private inline fun <T> withRpcNotificationScope(action: () -> T): T {
    if (rpcObserverNotifications.get() != null) return action()
    val pending = ArrayList<RpcObserverNotification>()
    rpcObserverNotifications.set(pending)
    var actionFailure: Throwable? = null
    try {
        return action()
    } catch (failure: Throwable) {
        actionFailure = failure
        throw failure
    } finally {
        rpcObserverNotifications.remove()
        // A fatal error from the action (including callback re-entry) must finish unwinding
        // ownership without starting diagnostic callbacks on the way out.
        actionFailure?.let(::rethrowFatalJvmError)
        pending.forEach(::reportRpcObserverNotification)
    }
}

private inline fun <T> withRpcNotificationMonitor(lock: Any, action: () -> T): T =
    withRpcNotificationScope { synchronized(lock) { action() } }

private fun reportRpcObserverNotification(notification: RpcObserverNotification) {
    try {
        try {
            notification.deliver()
        } catch (failure: Throwable) {
            rethrowFatalJvmError(failure)
            reportWritabilityWaitObserverFailure(notification, failure)
        }
    } catch (reportingFailure: Throwable) {
        rethrowFatalJvmError(reportingFailure)
        // The sink could not write the fixed record. Keep its already-built String in one
        // preobtained passive slot per connection: no formatting, allocation or recursive IO.
        // Replacing an older record bounds retention without retaining caller Throwable graphs.
        notification.failedReport.set(notification.failureRecord)
    }
}

internal fun notifyRpcObserver(
    channel: io.netty.channel.Channel,
    description: String,
    deliver: () -> Unit,
) {
    val notification = RpcObserverNotification(
        description,
        libp2pRootConnectionChannel(channel).attr(RPC_OBSERVER_REPORTING_FAILURE_ATTR),
        deliver,
    )
    val pending = rpcObserverNotifications.get()
    if (pending == null) reportRpcObserverNotification(notification)
    else pending.add(notification)
}

private fun notifyAwaitedResponseOutboxObserver(
    rootChannel: io.netty.channel.Channel,
    event: String,
    observerDescription: String,
) {
    if (!rootChannel.hasAttr(AWAITED_RESPONSE_OUTBOX_OBSERVER_ATTR)) return
    val observer = rootChannel.attr(AWAITED_RESPONSE_OUTBOX_OBSERVER_ATTR).get() ?: return
    notifyRpcObserver(rootChannel, observerDescription) { observer.accept(event) }
}

private fun notifyWritabilityWaitEventObserver(
    rootChannel: io.netty.channel.Channel,
    event: String,
    observerPoint: String,
) {
    notifyAwaitedResponseOutboxObserver(
        rootChannel,
        event,
        "Writability-wait observer '$observerPoint'",
    )
}

private fun notifyInterleavedWriteWaitThreadObserver(rootChannel: io.netty.channel.Channel) {
    if (!rootChannel.hasAttr(INTERLEAVED_WRITE_WAIT_THREAD_OBSERVER_ATTR)) return
    val observer = rootChannel.attr(INTERLEAVED_WRITE_WAIT_THREAD_OBSERVER_ATTR).get() ?: return
    val waitingThread = Thread.currentThread()
    notifyRpcObserver(rootChannel, "Writability-wait observer 'thread'") { observer.accept(waitingThread) }
}

private fun recordFramingOwnerWritabilityWait(rootChannel: io.netty.channel.Channel, frame: ByteBuf) {
    foundation.url.protocol.testing.recordFramingOwnerWritabilityWait(rootChannel, frame)
}

/**
 * One large attachment frame may write on a mux connection at a time. The receiving side applies
 * the same whole-pool serialization before allocating an attachment body; allowing several senders
 * to fill separate mux streams while only one receiver can drain them defeats transport
 * backpressure and can make the mux close a progressing stream. The fair semaphore preserves the
 * order in which response handlers reach this boundary without retaining an extra attachment copy.
 */
private val LARGE_ATTACHMENT_WRITE_TURN_ATTR: AttributeKey<Semaphore> =
    AttributeKey.valueOf("foundation.url.protocol.largeAttachmentWriteTurn")

/**
 * Shared state that records real root-writability transitions once per connection. Writers mark the
 * state while the root is unwritable; the first writer to observe it writable again advances the
 * epoch exactly once. A writer is eligible for bounded recovery admission only if its captured epoch
 * predates that transition.
 */
private class RelayRootRecoveryState {
    val epoch = AtomicLong()
    val rootWasUnwritable = AtomicBoolean(false)

    fun observe(rootIsWritable: Boolean) {
        if (!rootIsWritable) {
            rootWasUnwritable.set(true)
        } else if (rootWasUnwritable.compareAndSet(true, false)) {
            epoch.incrementAndGet()
        }
    }
}

private val RELAY_ROOT_RECOVERY_STATE_ATTR: AttributeKey<RelayRootRecoveryState> =
    AttributeKey.valueOf("foundation.url.protocol.relayRootRecoveryState")

/**
 * Walks [channel] up the [io.netty.channel.Channel.parent] chain to the TCP/transport connection.
 *
 * An outbound connection has no parent. An accepted connection does have a parent, but that parent
 * is the listening [io.netty.channel.ServerChannel], which is shared by every accepted peer and is
 * not part of this connection's writability or memory budget. Stop at the child of a ServerChannel
 * so independent inbound peers never share one parked-write semaphore or recovery marker.
 */
internal fun libp2pRootConnectionChannel(channel: io.netty.channel.Channel): io.netty.channel.Channel {
    var c = channel
    while (true) {
        val p = c.parent() ?: return c
        if (p is io.netty.channel.ServerChannel) return c
        c = p
    }
}

internal enum class AwaitedResponseWriteOutcome {
    DELIVERED,
    QUEUED,
    OUTBOX_FULL,
    CONNECTION_CLOSED,
}

internal data class AwaitedRpcResponseIdentity(
    val requestId: String,
    val method: String,
    val serviceIdentifier: String,
)

/** One handler slot, owned first by its coroutine and then by its queued response. */
internal class RpcRequestPermit(
    private val releaseOnAdmission: Boolean = false,
    private val release: () -> Unit,
) {
    // 0: handler owns it; 1: response owns it; 2: released.
    private val owner = AtomicInteger(0)

    fun handoffToResponse(): RpcRequestPermit {
        check(owner.compareAndSet(0, 1)) { "RPC handler permit was already handed off or released" }
        return this
    }

    fun releaseByHandler() {
        if (owner.compareAndSet(0, 2)) release()
    }

    fun releaseByResponse() {
        if (owner.compareAndSet(1, 2)) release()
    }

    /**
     * A relay slot returns when its answer has a byte charge, before a writer can select it.
     * The release action only returns the framework's atomic slot; it calls no application code.
     */
    fun responseAdmitted() {
        if (releaseOnAdmission) {
            // Oversized answers use the failure frame without handing ownership to an entry.
            releaseByHandler()
            releaseByResponse()
        }
    }
}

internal class AwaitedResponseFailureReservation internal constructor(
    internal val outbox: AwaitedResponseOutbox,
    internal val channel: io.netty.channel.Channel,
    internal val buffer: ByteBuf,
    internal val bytes: Long,
    internal val responseIdentity: AwaitedRpcResponseIdentity?,
    internal val lane: AwaitedResponseOutbox.Lane = AwaitedResponseOutbox.Lane.FAILURE,
) : AutoCloseable {
    private val active = AtomicBoolean(true)

    internal var requestPermit: RpcRequestPermit? = null

    // Registration responses and their unregister boundary share one per-child FIFO.
    internal var registeredRequest: Boolean = false
    private val registeredResponseOwner = AtomicInteger(0)
    internal var registeredClosePermit: RpcRequestPermit? = null
    internal val closeOwnsRegisteredResponse: Boolean get() = registeredResponseOwner.get() == 2

    internal fun claimRegisteredClose(): Boolean = outbox.claimRegisteredClose(this)

    internal fun transferRegisteredClose(): Boolean {
        if (!registeredResponseOwner.compareAndSet(0, 2)) return false
        registeredClosePermit = requestPermit?.handoffToResponse()
        return true
    }

    internal fun claimRegisteredHandler(): Boolean = registeredResponseOwner.compareAndSet(0, 1)

    // Ordinary failure frames keep their existing independent byte-bound lifetime. Declared
    // polls keep their count slot even when an oversized value becomes this small failure frame.
    internal var retainRequestPermitForFailureResponse: Boolean = false

    /**
     * A reservation acquired while its child and root are writable participates in the shared
     * failure budget. Pausing either channel isolates the reservation to its connection so it
     * cannot hold the allowance needed by healthy connections during the retirement grace.
     */
    internal var processWideCharge: Boolean = true

    /**
     * Set when the computed response consuming this reservation had to wait for outbox space.
     * It completes once that response is charged and queued for sending
     * ([AwaitedResponseWriteOutcome.QUEUED]) or its connection or child stream ends first
     * ([AwaitedResponseWriteOutcome.CONNECTION_CLOSED]).
     */
    @Volatile
    internal var pendingAdmission: kotlinx.coroutines.CompletableDeferred<AwaitedResponseWriteOutcome>? = null

    /**
     * Suspends while the computed response waits for outbox space. Direct-RPC permits remain
     * response-owned until write completion or buffer release. Registered relay permits return
     * when the response is charged, before this wait completes. Returns immediately when the
     * response did not have to wait.
     */
    internal suspend fun awaitResponseAdmission(): AwaitedResponseWriteOutcome? =
        pendingAdmission?.await()

    internal fun consume(): Boolean = active.compareAndSet(true, false)
    internal fun invalidate(): Boolean = active.getAndSet(false)

    override fun close() {
        if (registeredRequest && !registeredResponseOwner.compareAndSet(0, 3)) return
        if (active.compareAndSet(true, false)) {
            outbox.releaseFailureReservation(this)
        }
    }
}

private fun retainedLongPollFailurePermit(
    reservation: AwaitedResponseFailureReservation,
): RpcRequestPermit? = if (reservation.retainRequestPermitForFailureResponse) {
    reservation.requestPermit?.handoffToResponse()
} else null

private class AwaitedResponseFailureCapacityWaiter(
    val channel: io.netty.channel.Channel,
    val callback: () -> Unit,
) : AutoCloseable {
    private val active = AtomicBoolean(true)

    fun wake() {
        if (!active.compareAndSet(true, false)) return
        val resume = {
            notifyRpcObserver(channel, "Awaited-response failure-capacity waiter", callback)
        }
        try {
            channel.eventLoop().execute(resume)
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            // The channel's event loop can terminate concurrently with outbox cleanup. Resuming
            // directly is safe for a coroutine continuation and ensures the waiter observes the
            // closed channel instead of remaining stranded on an executor that no longer accepts
            // tasks.
            resume()
        }
    }

    override fun close() {
        active.set(false)
        awaitedResponseFailureCapacityWaiters.remove(this)
    }
}

private fun notifyAwaitedResponseFailureCapacityWaiters() {
    while (true) {
        val waiter = awaitedResponseFailureCapacityWaiters.poll() ?: return
        waiter.wake()
    }
}

/** Returns capacity notifications only after the releasing ownership monitor exits. */
private fun notifyAwaitedResponseFailureCapacityReleased(channel: io.netty.channel.Channel) {
    notifyRpcObserver(channel, "Awaited-response failure-capacity release") {
        notifyAwaitedResponseFailureCapacityWaiters()
    }
}

private fun notifyAwaitedResponseFailureCapacityWaiters(
    channel: io.netty.channel.Channel,
) {
    awaitedResponseFailureCapacityWaiters.forEach { waiter ->
        if (waiter.channel === channel && awaitedResponseFailureCapacityWaiters.remove(waiter)) {
            waiter.wake()
        }
    }
}

/** The physical pipeline promise also retains preparation failures for every protocol caller. */
private class ProtocolRootClosePromise(channel: io.netty.channel.Channel) :
    DefaultChannelPromise(channel, ImmediateEventExecutor.INSTANCE) {
    private val preparationFailure = AtomicReference<Throwable>()
    /** Set, under the recording monitor, once a completion has read the result callers receive. */
    private var resultSelected = false

    /**
     * Records a preparation failure. A fatal JVM error becomes the primary cause even when an
     * ordinary failure was recorded first. Once the result has been selected, a failure is late:
     * it is reported on stderr and never added to the exception callers already received.
     */
    fun recordPreparationFailure(failure: Throwable) {
        val late = synchronized(preparationFailure) {
            if (resultSelected) return@synchronized true
            val first = preparationFailure.get()
            when {
                first == null -> preparationFailure.set(failure)
                first === failure || first.suppressed.any { it === failure } -> Unit
                isFatalJvmError(failure) && !isFatalJvmError(first) -> {
                    failure.addSuppressed(first)
                    preparationFailure.set(failure)
                }
                else -> first.addSuppressed(failure)
            }
            false
        }
        if (late) reportLateProtocolRootCloseFailure(channel(), failure)
    }

    private fun selectResult(): Throwable? = synchronized(preparationFailure) {
        resultSelected = true
        preparationFailure.get()
    }

    // Preparation steps and barrier callbacks record failures before their final decrement
    // permits the physical close handoff. AtomicReference publishes that first cause to the
    // completing thread, so success needs no recording lock. Independent transport notifications
    // that race or follow physical completion are outside this preparation ordering guarantee.
    override fun trySuccess(): Boolean = trySuccess(null)

    override fun trySuccess(result: Void?): Boolean {
        if (isDone) return false
        val failure = selectResult()
        return if (failure == null) super.trySuccess(result) else super.tryFailure(failure)
    }

    override fun setSuccess(): ChannelPromise = setSuccess(null)

    override fun setSuccess(result: Void?): ChannelPromise {
        val failure = selectResult()
        return if (failure == null) super.setSuccess(result) else super.setFailure(failure)
    }

    override fun tryFailure(cause: Throwable): Boolean {
        if (isDone) {
            if (cause !== this.cause()) reportLateProtocolRootCloseFailure(channel(), cause)
            return false
        }
        recordPreparationFailure(cause)
        val first = selectResult() ?: cause
        return super.tryFailure(first)
    }

    override fun setFailure(cause: Throwable): ChannelPromise {
        recordPreparationFailure(cause)
        return super.setFailure(selectResult() ?: cause)
    }
}

/** A failure that arrived after the protocol close result was delivered; the result is unchanged. */
private fun reportLateProtocolRootCloseFailure(root: io.netty.channel.Channel, failure: Throwable) {
    System.err.println(
        "[ProtocolRootCloseLateFailure] root=${root.id().asShortText()} arrived after the protocol " +
            "close result was selected and does not change it; cause=${failure.javaClass.name}: " +
            "${failure.message ?: "no message"}"
    )
}

/** The first fatal JVM error seen while preparing one protocol close; rethrown after bookkeeping. */
private class ProtocolRootCloseFatal {
    var first: Throwable? = null
}

/**
 * Runs one preparation step. Ordinary failures are recorded and preparation continues. A fatal JVM
 * error is recorded as the primary result too, so every caller still completes; it is then either
 * held in [fatal] until the remaining close bookkeeping has run, or rethrown immediately.
 */
private inline fun prepareProtocolRootClose(
    result: ProtocolRootClosePromise,
    fatal: ProtocolRootCloseFatal? = null,
    action: () -> Unit,
) {
    try {
        action()
    } catch (failure: Throwable) {
        // Keep preparing sibling resources and the physical close; all callers observe this failure.
        result.recordPreparationFailure(failure)
        if (isFatalJvmError(failure)) {
            if (fatal == null) throw failure
            if (fatal.first == null) fatal.first = failure
        }
    }
}

/**
 * Netty only substitutes DefaultChannelPromise instances across handler executors. Keep the
 * terminal state in a DefaultPromise instead, and give ordinary listeners executor-bound
 * notification promises. Outbox observation reads the terminal state without those notifications.
 */
private class AwaitedResponseWritePromise(private val channel: io.netty.channel.Channel) :
    io.netty.util.concurrent.DefaultPromise<Void>(channel.eventLoop()), ChannelPromise {
    val observation = AtomicReference<ChannelPromise>()
    val notifications = ConcurrentHashMap<io.netty.util.concurrent.EventExecutor, DefaultChannelPromise>()
    val registrations = java.util.concurrent.CopyOnWriteArrayList<AwaitedResponseListener>()

    fun observe(result: ChannelPromise) {
        check(observation.compareAndSet(null, result)) { "A physical write already has an outbox observation" }
        // Registered after the outbox accounting listener: notifications may re-enter admission.
        result.addListener {
            observation.compareAndSet(result, null)
            publishAwaitedResponseWrite(this)
        }
        copyAwaitedResponseWrite(this, observation.get())
    }

    override fun channel(): io.netty.channel.Channel = channel
    override fun isVoid(): Boolean = false
    override fun unvoid(): ChannelPromise = this
    override fun trySuccess(): Boolean = trySuccess(null)
    override fun trySuccess(result: Void?): Boolean =
        try { super.trySuccess(result) } finally { publishAwaitedResponseWrite(this) }
    override fun setSuccess(): ChannelPromise = setSuccess(null)
    override fun setSuccess(result: Void?): ChannelPromise {
        try { super.setSuccess(result) } finally { publishAwaitedResponseWrite(this) }
        return this
    }
    override fun tryFailure(cause: Throwable): Boolean =
        try { super.tryFailure(cause) } finally { publishAwaitedResponseWrite(this) }
    override fun setFailure(cause: Throwable): ChannelPromise {
        try { super.setFailure(cause) } finally { publishAwaitedResponseWrite(this) }
        return this
    }
    override fun cancel(mayInterruptIfRunning: Boolean): Boolean =
        try { super.cancel(mayInterruptIfRunning) } finally { publishAwaitedResponseWrite(this) }

    override fun addListener(listener: io.netty.util.concurrent.GenericFutureListener<out io.netty.util.concurrent.Future<in Void>>?): ChannelPromise =
        addListeners(listener ?: throw NullPointerException("listener"))

    override fun addListeners(vararg listeners: io.netty.util.concurrent.GenericFutureListener<out io.netty.util.concurrent.Future<in Void>>?): ChannelPromise {
        val executor = channel.pipeline().names().asSequence()
            .mapNotNull { channel.pipeline().context(it)?.executor() }
            .firstOrNull { it.inEventLoop() } ?: channel.eventLoop()
        val notification = notifications.computeIfAbsent(executor) { DefaultChannelPromise(channel, it) }
        val added = listeners.takeWhile { it != null }.filterNotNull().map { listener ->
            val registration = AwaitedResponseListener(listener, notification)
            registration.forward = io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<Void>> {
                registrations.remove(registration)
                @Suppress("UNCHECKED_CAST")
                (listener as io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<Void>>).operationComplete(this)
            }
            registration
        }
        registrations.addAll(added)
        notification.addListeners(*added.map { it.forward }.toTypedArray())
        publishAwaitedResponseWrite(this)
        return this
    }
    override fun removeListener(listener: io.netty.util.concurrent.GenericFutureListener<out io.netty.util.concurrent.Future<in Void>>?): ChannelPromise {
        if (listener == null) throw NullPointerException("listener")
        while (true) {
            val registration = registrations.firstOrNull { it.original === listener } ?: break
            if (registrations.remove(registration)) {
                registration.notification.removeListener(registration.forward)
                break
            }
        }
        return this
    }
    override fun removeListeners(vararg listeners: io.netty.util.concurrent.GenericFutureListener<out io.netty.util.concurrent.Future<in Void>>?): ChannelPromise {
        listeners.takeWhile { it != null }.forEach { removeListener(it) }
        return this
    }
    override fun sync(): ChannelPromise { super.sync(); return this }
    override fun syncUninterruptibly(): ChannelPromise { super.syncUninterruptibly(); return this }
    override fun await(): ChannelPromise { super.await(); return this }
    override fun awaitUninterruptibly(): ChannelPromise { super.awaitUninterruptibly(); return this }
}

private class AwaitedResponseListener(
    val original: io.netty.util.concurrent.GenericFutureListener<out io.netty.util.concurrent.Future<in Void>>,
    val notification: DefaultChannelPromise,
) {
    lateinit var forward: io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<Void>>
}

private fun publishAwaitedResponseWrite(write: AwaitedResponseWritePromise) {
    val observation = write.observation.get()
    if (observation != null) {
        // Its completion listener publishes notifications after accounting, even when Netty
        // defers nested listeners. Late registrations must pass through this same ordering.
        copyAwaitedResponseWrite(write, observation)
    } else {
        write.notifications.values.forEach { copyAwaitedResponseWrite(write, it) }
    }
}

private fun copyAwaitedResponseWrite(write: io.netty.channel.ChannelFuture, result: ChannelPromise?) {
    if (result == null || !write.isDone) return
    if (write.isSuccess) result.trySuccess() else result.tryFailure(write.cause())
}

private fun newAwaitedResponseWritePromise(channel: io.netty.channel.Channel) =
    AwaitedResponseWritePromise(channel)

/** This result never enters the pipeline; only outbox-owned listeners may use it. */
private fun mirrorAwaitedResponseWrite(write: AwaitedResponseWritePromise, result: ChannelPromise) {
    write.observe(result)
}

private val awaitedResponseWriteObservations = AttributeKey.valueOf<MutableSet<AwaitedResponseWriteLifetime>>(
    "foundation.url.protocol.awaitedResponseWriteObservations"
)

/** A closing answer remains observed even if it first pauses after close selected its barriers. */
private class AwaitedResponseCloseRetirement(
    val isRequired: () -> Boolean,
    val retire: () -> Unit,
)

private class AwaitedResponseWriteLifetime(
    val root: io.netty.channel.Channel,
    val write: io.netty.channel.ChannelFuture,
    val result: ChannelPromise,
    val registrationFailure: (Throwable) -> Unit,
    val closeRetirement: AwaitedResponseCloseRetirement? = null,
)

private class AwaitedResponseReconciliation {
    val scheduled = AtomicReference<Scheduled>()
}

private fun awaitedResponseObservations(channel: io.netty.channel.Channel): MutableSet<AwaitedResponseWriteLifetime> {
    val attr = channel.attr(awaitedResponseWriteObservations)
    attr.get()?.let { return it }
    val created = ConcurrentHashMap.newKeySet<AwaitedResponseWriteLifetime>()
    return attr.setIfAbsent(created) ?: created
}

private fun reconcileAwaitedResponseWrite(observation: AwaitedResponseWriteLifetime) {
    val root = observation.root
    val write = observation.write
    val result = observation.result
    if (result.isDone) return
    if (write.isDone) {
        copyAwaitedResponseWrite(write, result)
        return
    }
    observation.closeRetirement?.let { retirement ->
        if (retirement.isRequired()) {
            retirement.retire()
            return
        }
    }
    val child = write.channel()
    // closeFuture's terminal state is safely published even if every listener was rejected.
    // In particular, a mux child's isOpen implementation need not itself use a volatile field.
    if (root.closeFuture().isDone || child.closeFuture().isDone || !root.isOpen || !child.isOpen ||
        root.eventLoop().isTerminated || child.eventLoop().isTerminated) {
        result.tryFailure(IOException(
            "Awaited response write on child ${child.id()} cannot complete: " +
                "root ${root.id()} open=${root.isOpen}, child open=${child.isOpen}, " +
                "root executor terminated=${root.eventLoop().isTerminated}, " +
                "child executor terminated=${child.eventLoop().isTerminated}"
        ))
    }
}

/** Direct lifecycle calls are the primary lifetime path; no notification task is submitted. */
private fun reconcileAwaitedResponseWrites(channel: io.netty.channel.Channel) {
    channel.attr(awaitedResponseWriteObservations).get()?.forEach(::reconcileAwaitedResponseWrite)
}

private fun closeAndReconcileAwaitedResponseWrites(ctx: ChannelHandlerContext, promise: ChannelPromise) {
    try { ctx.close(promise) } finally { reconcileAwaitedResponseWrites(ctx.channel()) }
}

/**
 * Cadence of the per-root reconciliation check for pending awaited-response writes, and of
 * re-offering a protocol close whose submission a live but full event-loop queue rejected.
 */
internal const val AWAITED_RESPONSE_RECONCILIATION_INTERVAL_MS: Long = 100L

/** Why a protocol close runs without its event loop; completes "Protocol close of root <id> ...". */
private const val LOOP_STOPPED_REASON = "ran after its event loop stopped running tasks"
private const val FULL_QUEUE_CLOCK_REJECTED_REASON =
    "ran without its event loop because the loop's task queue was full and the reconciliation " +
        "clock rejected the retry"

/**
 * One pending clock ticket per root, including terminal writes detached from the byte ledger.
 * The clock callback only inspects state; completing writes, physical closes and caller listeners
 * run on the root's event loop, or on [fallbackExecutor] once that loop can no longer run tasks.
 */
private class AwaitedResponseReconciler(val clock: Clock, val root: io.netty.channel.Channel) {
    val observations = LinkedHashSet<AwaitedResponseWriteLifetime>()
    var ticket: AwaitedResponseReconciliation? = null
    val rootLifetimeWatched = AtomicBoolean(false)
    private var fallback: java.util.concurrent.ThreadPoolExecutor? = null

    /** A single daemon thread, created only when the root's event loop cannot run a task. */
    @Synchronized
    fun fallbackExecutor(): java.util.concurrent.Executor = fallback ?: java.util.concurrent.ThreadPoolExecutor(
        0, 1, 1L, TimeUnit.SECONDS, java.util.concurrent.LinkedBlockingQueue(),
    ) { task ->
        Thread(task, "url-protocol-root-close-fallback-${root.id().asShortText()}").apply { isDaemon = true }
    }.also { fallback = it }
}

private fun addAwaitedResponseObservation(owner: AwaitedResponseReconciler, observation: AwaitedResponseWriteLifetime) {
    synchronized(owner) { owner.observations.add(observation) }
    watchAwaitedResponseRootLifetime(owner)
}

/**
 * The root's close future and its event loop's termination future are shared by every pending
 * write on that root (and the termination future by every channel on the loop). One listener per
 * root keeps per-write registration O(1); it is removed when the root closes.
 */
private fun watchAwaitedResponseRootLifetime(owner: AwaitedResponseReconciler) {
    if (!owner.rootLifetimeWatched.compareAndSet(false, true)) return
    val root = owner.root
    val reconcileAll = {
        runAwaitedResponseReconciliation(owner, synchronized(owner) { owner.observations.toList() })
    }
    // Netty notifies termination listeners on its single process-wide GlobalEventExecutor thread,
    // which swallows failures. Only dispatch there: completing writes, loss handlers, barriers,
    // the physical close and caller listeners run on this root's fallback thread.
    val onTermination = io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<Any?>> {
        owner.fallbackExecutor().execute { reconcileAll() }
    }
    val termination = root.eventLoop().terminationFuture()
    termination.addListener(onTermination)
    root.closeFuture().addListener {
        try { reconcileAll() }
        finally { termination.removeListener(onTermination) }
    }
}

private fun removeAwaitedResponseObservation(owner: AwaitedResponseReconciler, observation: AwaitedResponseWriteLifetime) {
    val canceled = synchronized(owner) {
        owner.observations.remove(observation)
        if (owner.observations.isEmpty()) owner.ticket.also { owner.ticket = null } else null
    }
    canceled?.scheduled?.get()?.cancel()
}

private fun failAwaitedResponseObservation(observation: AwaitedResponseWriteLifetime, failure: Throwable) {
    try { observation.registrationFailure(failure) }
    finally { observation.result.tryFailure(failure) }
}

private fun awaitedResponseWriteNeedsReconciliation(observation: AwaitedResponseWriteLifetime): Boolean {
    if (observation.result.isDone) return false
    if (observation.write.isDone) return true
    if (observation.closeRetirement?.isRequired?.invoke() == true) return true
    val root = observation.root
    val child = observation.write.channel()
    return root.closeFuture().isDone || child.closeFuture().isDone || !root.isOpen || !child.isOpen ||
        root.eventLoop().isTerminated || child.eventLoop().isTerminated
}

/** Reconciles on the calling thread and reports each failure; used on the loop or the fallback. */
private fun runAwaitedResponseReconciliation(
    owner: AwaitedResponseReconciler,
    pending: List<AwaitedResponseWriteLifetime>,
) {
    var reportedFailure: Throwable? = null
    pending.forEach { observation ->
        try { reconcileAwaitedResponseWrite(observation) }
        catch (failure: Throwable) {
            try { failAwaitedResponseObservation(observation, failure) }
            catch (reportingFailure: Throwable) {
                val first = reportedFailure
                if (first == null) reportedFailure = reportingFailure
                else if (first !== reportingFailure) first.addSuppressed(reportingFailure)
            }
        }
    }
    reportedFailure?.let { failure ->
        System.err.println(
            "[AwaitedResponseReconciliationFailure] root=${owner.root.id().asShortText()} " +
                "cause=${failure.javaClass.name}: ${failure.message ?: "no message"}"
        )
        rethrowFatalJvmError(failure)
    }
}

/** Hands a reconciliation pass to the root's event loop, or to the fallback once it cannot run. */
private fun handOffAwaitedResponseReconciliation(
    owner: AwaitedResponseReconciler,
    pending: List<AwaitedResponseWriteLifetime>,
): Boolean {
    val task = Runnable {
        try { runAwaitedResponseReconciliation(owner, pending) }
        finally { scheduleAwaitedResponseReconciliation(owner) }
    }
    val loop = owner.root.eventLoop()
    if (!loop.isShuttingDown) {
        try {
            loop.execute(task)
            return true
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            // A live loop with a full queue: the next tick offers the pass again.
            if (!loop.isShuttingDown) return false
        }
    }
    owner.fallbackExecutor().execute(task)
    return true
}

/** A removed handler or rejected notification cannot be the last observation of a pending write. */
private fun scheduleAwaitedResponseReconciliation(owner: AwaitedResponseReconciler) {
    val ticket = synchronized(owner) {
        if (owner.observations.isEmpty() || owner.ticket != null) return
        AwaitedResponseReconciliation().also { owner.ticket = it }
    }
    try {
        val scheduled = owner.clock.schedule(
            owner.clock.currentTimeMillis() + AWAITED_RESPONSE_RECONCILIATION_INTERVAL_MS,
        ) {
            // Runs on the clock's thread: inspect only, never complete writes or run callers here.
            val pending = synchronized(owner) {
                if (owner.ticket !== ticket) return@schedule
                owner.ticket = null
                owner.observations.toList()
            }
            val actionable = pending.filter(::awaitedResponseWriteNeedsReconciliation)
            if (actionable.isEmpty() || !handOffAwaitedResponseReconciliation(owner, actionable)) {
                scheduleAwaitedResponseReconciliation(owner)
            }
        }
        ticket.scheduled.set(scheduled)
        // Completion or a callback can precede publication; cancel only this ticket's handle.
        if (synchronized(owner) { owner.ticket !== ticket }) scheduled.cancel()
    } catch (failure: Throwable) {
        val pending = synchronized(owner) {
            if (owner.ticket === ticket) owner.ticket = null
            owner.observations.toList()
        }
        var reportedFailure: Throwable? = null
        pending.forEach { observation ->
            try { failAwaitedResponseObservation(observation, failure) }
            catch (reportingFailure: Throwable) {
                val first = reportedFailure
                if (first == null) reportedFailure = reportingFailure
                else if (first !== reportingFailure) first.addSuppressed(reportingFailure)
            }
        }
        reportedFailure?.let { throw it }
    }
}

private fun <T> observeAwaitedResponseWriteEnd(
    lifetime: io.netty.util.concurrent.Future<T>,
    write: io.netty.channel.ChannelFuture,
    result: ChannelPromise,
    description: String,
    removals: MutableList<() -> Unit>,
    dispatch: java.util.concurrent.Executor? = null,
) {
    val listener = io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<T>> { ended ->
        val complete = Runnable {
            if (write.isSuccess) result.trySuccess()
            else result.tryFailure(write.cause() ?: ended.cause() ?: IOException(
                "Awaited response write on child ${write.channel().id()} could not complete because $description ended"
            ))
        }
        if (dispatch != null) dispatch.execute(complete) else complete.run()
    }
    removals.add { lifetime.removeListener(listener); Unit }
    lifetime.addListener(listener)
}

/** Observe teardown after the pipeline has taken ownership of the buffer. */
private fun observeAwaitedResponseWriteLifetime(
    root: io.netty.channel.Channel,
    write: io.netty.channel.ChannelFuture,
    result: ChannelPromise,
    reconciliation: AwaitedResponseReconciler,
    closeRetirement: AwaitedResponseCloseRetirement? = null,
    registrationFailure: (Throwable) -> Unit,
) {
    if (result.isDone) return
    val child = write.channel()
    val removals = ArrayList<() -> Unit>()
    val observation = AwaitedResponseWriteLifetime(root, write, result, registrationFailure, closeRetirement)
    val channels = linkedSetOf(root, child)
    channels.forEach { awaitedResponseObservations(it).add(observation) }
    addAwaitedResponseObservation(reconciliation, observation)
    try {
        // The root's close and loop-termination futures are watched once per root by the
        // reconciler; only the child's own lifetimes need a per-write listener.
        val lifetimes = linkedMapOf<io.netty.util.concurrent.Future<*>, String>()
        if (child !== root) lifetimes[child.closeFuture()] = "child channel ${child.id()}"
        if (child.eventLoop() !== root.eventLoop()) {
            lifetimes[child.eventLoop().terminationFuture()] = "child event loop for ${child.id()}"
        }
        lifetimes.forEach { (lifetime, description) ->
            // A loop's termination is notified on Netty's shared GlobalEventExecutor thread.
            val dispatch = if (lifetime === child.eventLoop().terminationFuture()) reconciliation.fallbackExecutor() else null
            observeAwaitedResponseWriteEnd(lifetime, write, result, description, removals, dispatch)
        }
        reconcileAwaitedResponseWrite(observation)
        scheduleAwaitedResponseReconciliation(reconciliation)
    } catch (failure: Throwable) {
        try {
            registrationFailure(failure)
        } finally {
            result.tryFailure(failure)
        }
    } finally {
        // Register after all lifetime listeners, including any that completed the result inline.
        // Immediate completion removes references even when the physical promise stays pending.
        result.addListener {
            channels.forEach { it.attr(awaitedResponseWriteObservations).get()?.remove(observation) }
            try { removeAwaitedResponseObservation(reconciliation, observation) }
            finally { removals.forEach { remove -> remove() } }
        }
    }
}

private val awaitedResponseDispatchClock: Clock = SystemClock()

private fun awaitedResponseRetirementTime(clock: Clock = awaitedResponseDispatchClock): Long {
    // Netty's relative deadlines use monotonic time; a wall-clock correction cannot renew one.
    return if (clock is SystemClock) TimeUnit.NANOSECONDS.toMillis(System.nanoTime())
    else clock.currentTimeMillis()
}

private fun reportAwaitedResponseTaskRejection(
    root: io.netty.channel.Channel,
    rejection: java.util.concurrent.RejectedExecutionException,
) {
    // The on-loop branch may own the outbox monitor. Formatting and output belong
    // to the outer notification scope, as for caller callbacks.
    notifyRpcObserver(root, "Awaited-response drain rejection diagnostic") {
        debugLogErr {
            "[RPC] Awaited-response drain submission rejected: " +
                "${rejection.javaClass.name}: ${rejection.message}"
        }
    }
}

/**
 * One loop task or its terminal cleanup owns the handoff. Terminal cleanup must be safe
 * off-loop: a live full tail queue runs it directly, while shutdown retains it until termination.
 */
private fun dispatchAwaitedResponseTask(
    root: io.netty.channel.Channel,
    task: () -> Unit,
    afterTermination: () -> Unit,
) {
    val loop = root.eventLoop()
    if (loop.inEventLoop()) {
        try {
            loop.execute(task)
        } catch (rejection: java.util.concurrent.RejectedExecutionException) {
            // On the loop, the scheduled heap needs no space in the ordinary task queue.
            try { loop.schedule(task, 0L, TimeUnit.NANOSECONDS) }
            finally { reportAwaitedResponseTaskRejection(root, rejection) }
        }
        return
    }

    val termination = loop.terminationFuture()
    // Clear both closures when either path claims ownership. A tail task offered
    // concurrently with termination can remain queued, but cannot retain a response.
    val actions = AtomicReference<Pair<() -> Unit, () -> Unit>?>(task to afterTermination)
    val finish = { actions.getAndSet(null)?.second?.invoke(); Unit }
    val onTermination = io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<Any?>> {
        finish()
    }
    termination.addListener(onTermination)
    val deliver = Runnable {
        val owned = actions.getAndSet(null) ?: return@Runnable
        termination.removeListener(onTermination)
        owned.first()
    }
    try {
        if (loop is io.netty.channel.SingleThreadIoEventLoop) {
            // Netty's I/O loops drain their bounded tail queue after ordinary tasks.
            // Other loop implementations keep their ordinary task queue.
            loop.executeAfterEventLoopIteration(deliver)
        } else {
            loop.execute(deliver)
        }
    } catch (rejection: java.util.concurrent.RejectedExecutionException) {
        try {
            when {
                loop.isTerminated -> finish()
                loop.isShuttingDown -> {
                    // The listener already owns cleanup. Cover termination racing the check.
                    if (loop.isTerminated) finish()
                }
                else -> {
                    termination.removeListener(onTermination)
                    finish()
                }
            }
        } finally {
            reportAwaitedResponseTaskRejection(root, rejection)
        }
    }
}

/**
 * Connection-scoped, byte-bounded admission for every computed response before it enters Netty.
 *
 * The outbox itself lives on the root connection channel. Entries retain their child channel so
 * independent mux substreams share the same connection/process budgets without sharing stream
 * lifetime. Drain work is event-loop scheduled and driven by root/child writability transitions;
 * callers never park a thread. A response that does not fit its lane waits uncharged in arrival
 * order and is charged once space frees up; its request coroutine suspends on
 * [AwaitedResponseFailureReservation.awaitResponseAdmission] meanwhile. A root whose queued or
 * in-flight output remains paused at the child or root is retired after
 * [AWAITED_RESPONSE_OUTBOX_STALLED_CONNECTION_GRACE_MS] without a completed response on that child.
 *
 * Ownership invariant (including callbacks re-entering close):
 * - Each paused unfinished answer belongs to one child deadline until completion or retirement.
 *   Only a whole response completed on that child renews it; returned credit is not completion.
 * - Queued buffers belong to the outbox; handed-off buffers belong to the transport. Retirement
 *   closes the child to discard its transport frame and never appends JSON to a partial frame.
 * - The answer's single logical write result releases its byte charge and response-owned handler
 *   permit exactly once. Late physical completion cannot acquire either resource again.
 * - Close is terminal for paused answers, independent of current writability. It retires them
 *   before selecting pending-write barriers; a frame needing retirement cannot hold close open.
 * - An expired deadline claims retirement under the same monitor as completion and close. A
 *   cancelled or replaced callback cannot retire new output, and closed ownership never restarts.
 */
internal class AwaitedResponseOutbox(
    private val rootChannel: io.netty.channel.Channel,
    reconciliationClock: Clock = SystemClock(),
) {
    private val reconciliation = AwaitedResponseReconciler(reconciliationClock, rootChannel)

    fun observeForwardedWrite(write: io.netty.channel.ChannelFuture, result: ChannelPromise) {
        observeAwaitedResponseWriteLifetime(rootChannel, write, result, reconciliation) { failure ->
            throw failure
        }
    }

    internal enum class Lane {
        NORMAL,
        PRIORITY,
        FAILURE,
        LONG_POLL_FAILURE,
        REFUSAL;

        val isFailure: Boolean get() = this == FAILURE || this == LONG_POLL_FAILURE
        // The observer describes the writer lane; both completion pools share that lane.
        val observerName: String get() = if (isFailure) FAILURE.name else name
    }

    private inner class Entry(
        val channel: io.netty.channel.Channel,
        val buffer: ByteBuf,
        val bytes: Long,
        val lane: Lane,
        var processWideCharge: Boolean,
        val terminalFailure: AwaitedResponseFailureReservation? = null,
        val responseIdentity: AwaitedRpcResponseIdentity? = null,
        val deliveryCompletion: ((Throwable?) -> Unit)? = null,
        /**
         * False while the entry waits in its lane for outbox space: it holds no connection or
         * process-wide charge and cannot be drained until [promoteWaiting] charges it.
         */
        var charged: Boolean = true,
        val pendingAdmission: kotlinx.coroutines.CompletableDeferred<AwaitedResponseWriteOutcome>? = null,
        val requestPermit: RpcRequestPermit? = null,
        // Admission refusals carry no completed application work to salvage on close. Keeping
        // them out of terminal writes prevents returning their byte charge ahead of their data.
        val preserveOnClose: Boolean = true,
        val orderedRegistration: Boolean = terminalFailure?.registeredRequest == true,
    ) {
        val order = nextEntryOrder++
        init {
            if (orderedRegistration) orderedRegistrationEntries.getOrPut(channel) { ArrayDeque() }.addLast(this)
        }
        val deliveryLossReported = AtomicBoolean(false)
        val responseFrameCompleted = AtomicBoolean(false)
        // The logical result exists before queue ownership can transfer to the transport. Close
        // can retire it even between drain selection and the actual pipeline call.
        val writeFuture: ChannelPromise = DefaultChannelPromise(channel, ImmediateEventExecutor.INSTANCE).also { result ->
            result.addListener { completeResponseWrite(this, result) }
        }
        @Volatile
        var transportWrite: io.netty.channel.ChannelFuture? = null
        var writeStarted = false
        var retirementOwner: StalledChildRetirement? = null
        // A queued pause owns a deadline, but a writable first handoff is still allowed to
        // finish during close. Once the transport pauses, returned credit cannot undo it.
        var pausedInFlight = false
        @Volatile
        var retired = false
    }

    private data class TerminalWrite(
        val channel: io.netty.channel.Channel,
        val buffer: ByteBuf,
        val sourceEntry: Entry? = null,
    )

    private data class CloseCleanup(
        val retainedBuffers: List<ByteBuf>,
        val terminalWrites: List<TerminalWrite>,
        val affectedChannels: Set<io.netty.channel.Channel>,
        val inFlightEntries: List<Entry>,
        val queuedEntries: List<Entry>,
        val undeliverableQueuedEntries: List<Entry>,
    )

    private class LaneQueue {
        private val entriesByChannel =
            LinkedHashMap<io.netty.channel.Channel, ArrayDeque<Entry>>()
        private val channelTurns = ArrayDeque<io.netty.channel.Channel>()
        var size: Int = 0
            private set

        fun addLast(entry: Entry) {
            val entries = entriesByChannel[entry.channel]
            if (entries == null) {
                entriesByChannel[entry.channel] = ArrayDeque<Entry>().apply {
                    addLast(entry)
                }
                channelTurns.addLast(entry.channel)
            } else {
                entries.addLast(entry)
            }
            size++
        }

        fun firstDrainable(canDrain: (Entry) -> Boolean): Entry? {
            repeat(channelTurns.size) {
                val channel = channelTurns.removeFirst()
                channelTurns.addLast(channel)
                val entry = entriesByChannel.getValue(channel).first()
                if (canDrain(entry)) return entry
            }
            return null
        }

        fun hasDrainable(canDrain: (Entry) -> Boolean): Boolean =
            entriesByChannel.values.any { entries -> canDrain(entries.first()) }

        fun remove(entry: Entry) {
            val entries = entriesByChannel[entry.channel]
                ?: error("Awaited response outbox lost the queue for child ${entry.channel.id()}")
            check(entries.removeFirst() === entry) {
                "Awaited response outbox substream accounting diverged for ${entry.lane}"
            }
            size--
            if (entries.isEmpty()) {
                entriesByChannel.remove(entry.channel)
                check(channelTurns.remove(entry.channel)) {
                    "Awaited response outbox lost the drain turn for child ${entry.channel.id()}"
                }
            }
        }

        fun removeAll(channel: io.netty.channel.Channel): List<Entry> {
            val entries = entriesByChannel.remove(channel) ?: return emptyList()
            check(channelTurns.remove(channel)) {
                "Awaited response outbox lost the drain turn for child ${channel.id()}"
            }
            size -= entries.size
            return entries.toList()
        }

        fun snapshot(): List<Entry> =
            entriesByChannel.values.flatMap { entries -> entries.toList() }

        fun clear() {
            entriesByChannel.clear()
            channelTurns.clear()
            size = 0
        }

        fun isEmpty(): Boolean = size == 0
    }

    private val lock = Any()
    private var nextEntryOrder = 0L
    private val orderedRegistrationEntries = HashMap<io.netty.channel.Channel, ArrayDeque<Entry>>()
    private val normalQueue = LaneQueue()
    private val priorityQueue = LaneQueue()
    private val failureQueue = LaneQueue()
    private val inFlightEntries = LinkedHashSet<Entry>()
    private var normalBytes = 0L
    private var priorityBytes = 0L
    private var failureBytes = 0L
    private var longPollFailureBytes = 0L
    private var refusalBytes = 0L
    private val activeFailureReservations = HashSet<AwaitedResponseFailureReservation>()
    /**
     * Computed responses that are retained in their lane but not yet charged, in arrival order.
     * Only the head may be charged next, so a large response cannot be overtaken indefinitely by
     * smaller ones on the same connection.
     */
    private val waitingEntries = ArrayDeque<Entry>()
    private val promotionScheduled = AtomicBoolean(false)
    private var nextLaneIndex = 0
    private var drainScheduled = false
    private var drainRegistrationPending = false
    private var closed = false
    private var protocolClosePromise: ProtocolRootClosePromise? = null
    private val rootHandlerInstallationClaimed = AtomicBoolean(false)
    private val remoteResetObserverInstallationClaimed = AtomicBoolean(false)

    /**
     * Multiplexed child streams this outbox has delivered to, keyed by their multiplexer id, with
     * whether the requester has reset that stream. A reset stream can no longer carry any frame in
     * either direction, so its close must not wait to write terminal frames to it. Entries are
     * removed when the child becomes inactive.
     */
    private val muxChildResetByRequester = HashMap<io.libp2p.etc.util.netty.mux.MuxId, Boolean>()
    private var transportFailure: Throwable? = null
    /** One deadline generation shared by the unfinished answers on exactly one child. */
    private class StalledChildRetirement(val deadlineMillis: Long) {
        var task: java.util.concurrent.ScheduledFuture<*>? = null
        var expired = false
    }

    private val stalledChildRetirements =
        HashMap<io.netty.channel.Channel, StalledChildRetirement>()
    private val rootConnectionGeneration = awaitedResponseRootConnectionGeneration.incrementAndGet()

    /**
     * Reader-owned refusals never borrow a handler's reservation or enter waitingEntries.
     * Ownership of the buffer transfers here on every outcome. The caller must end its
     * registration if this separate budget is exhausted, rather than wait on the reader.
     */
    fun tryEnqueueRelayRefusal(channel: io.netty.channel.Channel, buffer: ByteBuf): Boolean {
        observeChildChannel(channel)
        val bytes = buffer.readableBytes().toLong()
        val admitted = withRpcNotificationMonitor(lock) {
            isolateFromProcessWideBudgetLocked()
            val processWideCharge = effectiveIsWritable(channel)
            if (closed || !rootChannel.isOpen || !channel.isOpen ||
                bytes > AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES ||
                !reserve(Lane.REFUSAL, bytes, processWideCharge)
            ) {
                releaseIfRetained(buffer)
                false
            } else {
                failureQueue.addLast(Entry(channel, buffer, bytes, Lane.REFUSAL, processWideCharge))
                true
            }
        }
        if (admitted) {
            scheduleDrain()
            notifyObserver("ADMITTED:REFUSAL")
        }
        return admitted
    }

    fun tryReserveFailureSignal(
        channel: io.netty.channel.Channel,
        responseIdentity: AwaitedRpcResponseIdentity? = null,
        longPoll: Boolean = false,
        outboxFullSignal: () -> ByteBuf,
    ): AwaitedResponseFailureReservation? {
        observeChildChannel(channel)
        val lane = if (longPoll) Lane.LONG_POLL_FAILURE else Lane.FAILURE
        val failureBuffer = outboxFullSignal()
        val failureBytesToReserve = failureBuffer.readableBytes().toLong()
        if (failureBytesToReserve >
            AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES.toLong()
        ) {
            releaseIfRetained(failureBuffer)
            throw IllegalArgumentException(
                "OUTBOX_FULL signal is $failureBytesToReserve bytes, exceeding the " +
                    "reserved-signal frame limit of " +
                    "$AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES bytes"
            )
        }
        val reservation = withRpcNotificationMonitor(lock) {
            isolateFromProcessWideBudgetLocked()
            val processWideCharge = effectiveIsWritable(channel)
            if (
                closed || !rootChannel.isOpen || !channel.isOpen ||
                !reserve(lane, failureBytesToReserve, processWideCharge)
            ) {
                null
            } else {
                AwaitedResponseFailureReservation(
                    this,
                    channel,
                    failureBuffer,
                    failureBytesToReserve,
                    responseIdentity,
                    lane,
                ).also {
                    it.processWideCharge = processWideCharge
                    activeFailureReservations.add(it)
                }
            }
        }
        if (reservation == null) {
            releaseIfRetained(failureBuffer)
        }
        return reservation
    }

    fun registerFailureCapacityWaiter(
        channel: io.netty.channel.Channel,
        callback: () -> Unit,
    ): AutoCloseable {
        val waiter = AwaitedResponseFailureCapacityWaiter(channel, callback)
        awaitedResponseFailureCapacityWaiters.add(waiter)
        return waiter
    }

    fun hasFailureCapacity(
        channel: io.netty.channel.Channel,
        bytes: Long,
        longPoll: Boolean = false,
    ): Boolean = withRpcNotificationMonitor(lock) {
        isolateFromProcessWideBudgetLocked()
        val connectionBytes = if (longPoll) longPollFailureBytes else failureBytes
        val processBytes = if (longPoll) awaitedResponseOutboxLongPollFailureBytesProcessWide
            else awaitedResponseOutboxFailureBytesProcessWide
        !closed &&
            rootChannel.isOpen &&
            bytes > 0L &&
            bytes <= AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION &&
            connectionBytes <= AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION - bytes &&
            (!effectiveIsWritable(channel) ||
                processBytes.get() <=
                    AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PROCESS_WIDE - bytes)
    }

    fun writeOrEnqueue(
        channel: io.netty.channel.Channel,
        responseBuffer: ByteBuf,
        failureReservation: AwaitedResponseFailureReservation,
        completion: ((Throwable?) -> Unit)? = null,
        registeredClose: Boolean = false,
    ): AwaitedResponseWriteOutcome {
        observeChildChannel(channel)
        if (failureReservation.outbox !== this || failureReservation.channel !== channel) {
            releaseIfRetained(responseBuffer)
            error(
                "An awaited response must consume the failure reservation acquired for its own " +
                    "connection and child stream"
            )
        }
        var scheduleDrain = false
        var releasedFailureCapacity = false
        var admittedEvent: String? = null
        val outcome = withRpcNotificationMonitor(lock) {
            isolateFromProcessWideBudgetLocked()
            if (closed || !rootChannel.isOpen || !channel.isOpen) {
                releaseIfRetained(responseBuffer)
                releaseReservedFailureLocked(failureReservation)
                releasedFailureCapacity = true
                return@withRpcNotificationMonitor AwaitedResponseWriteOutcome.CONNECTION_CLOSED
            }
            if (failureReservation.registeredRequest && !registeredClose &&
                !failureReservation.claimRegisteredHandler()) {
                releaseIfRetained(responseBuffer)
                return@withRpcNotificationMonitor AwaitedResponseWriteOutcome.QUEUED
            }
            if (!failureReservation.consume()) {
                releaseIfRetained(responseBuffer)
                if (failureReservation.registeredRequest) {
                    // Close and the handler use the same reservation. Losing is a no-op.
                    return@withRpcNotificationMonitor AwaitedResponseWriteOutcome.QUEUED
                }
                error("An awaited response failure reservation cannot be consumed more than once")
            }

            val responseBytes = responseBuffer.readableBytes().toLong()
            val responseLane = if (
                responseBytes <= AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES.toLong()
            ) {
                Lane.PRIORITY
            } else {
                Lane.NORMAL
            }
            val processWideCharge = effectiveIsWritable(channel)
            if (waitingEntries.isEmpty() && reserve(responseLane, responseBytes, processWideCharge)) {
                queue(responseLane).addLast(
                    Entry(
                        channel,
                        responseBuffer,
                        responseBytes,
                        responseLane,
                        processWideCharge,
                        terminalFailure = failureReservation,
                        responseIdentity = failureReservation.responseIdentity,
                        deliveryCompletion = completion,
                        requestPermit = if (registeredClose) failureReservation.registeredClosePermit
                            else failureReservation.requestPermit?.handoffToResponse(),
                    )
                )
                scheduleDrain = true
                failureReservation.requestPermit?.responseAdmitted()
                admittedEvent = "ADMITTED:${responseLane.name}"
                return@withRpcNotificationMonitor AwaitedResponseWriteOutcome.QUEUED
            }
            if (responseBytes <= laneConnectionLimit(responseLane)) {
                // The handler already did its work, so its response is never discarded for lack
                // of space: it waits, uncharged, behind every earlier waiting response of this
                // connection until queued responses drain. The caller suspends on the admission
                // while its response-owned permit keeps retained answers within the explicit
                // handler-concurrency bound.
                val admission = kotlinx.coroutines.CompletableDeferred<AwaitedResponseWriteOutcome>()
                failureReservation.pendingAdmission = admission
                val waiting = Entry(
                    channel,
                    responseBuffer,
                    responseBytes,
                    responseLane,
                    processWideCharge = false,
                    terminalFailure = failureReservation,
                    responseIdentity = failureReservation.responseIdentity,
                    deliveryCompletion = completion,
                    charged = false,
                    pendingAdmission = admission,
                    requestPermit = if (registeredClose) failureReservation.registeredClosePermit
                            else failureReservation.requestPermit?.handoffToResponse(),
                )
                queue(responseLane).addLast(waiting)
                waitingEntries.addLast(waiting)
                awaitedResponseOutboxesWithPendingCharges.add(this)
                // Space released by another connection after the failed charge above, but before
                // this outbox was registered, would not wake it. Re-check once from the event loop.
                requestPromotion()
                admittedEvent = "WAITING:${responseLane.name}"
                return@withRpcNotificationMonitor AwaitedResponseWriteOutcome.QUEUED
            }

            releaseIfRetained(responseBuffer)
            check(activeFailureReservations.remove(failureReservation)) {
                "An awaited response lost its pre-acquired failure reservation"
            }
            failureQueue.addLast(
                Entry(
                    channel,
                    failureReservation.buffer,
                    failureReservation.bytes,
                    failureReservation.lane,
                    processWideCharge = failureReservation.processWideCharge,
                    responseIdentity = failureReservation.responseIdentity,
                    orderedRegistration = failureReservation.registeredRequest,
                    requestPermit = retainedLongPollFailurePermit(failureReservation),
                )
            )
            failureReservation.requestPermit?.responseAdmitted()
            scheduleDrain = true
            admittedEvent = "ADMITTED:${failureReservation.lane.observerName}"
            AwaitedResponseWriteOutcome.OUTBOX_FULL
        }
        if (releasedFailureCapacity) notifyAwaitedResponseFailureCapacityWaiters()
        if (scheduleDrain) scheduleDrain()
        admittedEvent?.let(::notifyObserver)
        return outcome
    }

    fun claimRegisteredClose(reservation: AwaitedResponseFailureReservation): Boolean =
        withRpcNotificationMonitor(lock) {
            !closed && activeFailureReservations.contains(reservation) && reservation.transferRegisteredClose()
        }

    /** Appends unregister behind every earlier response on this registration's FIFO. */
    fun enqueueRegistrationBoundary(
        channel: io.netty.channel.Channel,
        buffer: ByteBuf,
        completion: (Throwable?) -> Unit,
    ) {
        observeChildChannel(channel)
        val bytes = buffer.readableBytes().toLong()
        require(bytes <= AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES) {
            "Relay unregister frame is $bytes bytes, exceeding the 65536-byte control-frame limit"
        }
        val accepted = withRpcNotificationMonitor(lock) {
            isolateFromProcessWideBudgetLocked()
            if (closed || !rootChannel.isOpen || !channel.isOpen) {
                releaseIfRetained(buffer)
                false
            } else {
                val processCharge = effectiveIsWritable(channel)
                val charged = waitingEntries.isEmpty() && reserve(Lane.PRIORITY, bytes, processCharge)
                val entry = Entry(
                    channel, buffer, bytes, Lane.PRIORITY, charged && processCharge,
                    deliveryCompletion = completion,
                    charged = charged,
                    orderedRegistration = true,
                )
                priorityQueue.addLast(entry)
                if (!charged) {
                    waitingEntries.addLast(entry)
                    awaitedResponseOutboxesWithPendingCharges.add(this)
                    requestPromotion()
                }
                true
            }
        }
        if (accepted) scheduleDrain()
        else completion(EOFException("Relay registration closed before unregister could be queued"))
    }

    /**
     * Rejects a response representation that is already known to exceed an outbox lane without
     * first materializing another aggregate buffer. Used by large attachment responses whose source
     * arrays already account for the retained response bytes.
     */
    fun enqueueReservedOutboxFullSignal(
        channel: io.netty.channel.Channel,
        responseBytes: Long,
        failureReservation: AwaitedResponseFailureReservation,
    ): AwaitedResponseWriteOutcome {
        observeChildChannel(channel)
        check(failureReservation.outbox === this && failureReservation.channel === channel) {
            "An oversized awaited response must consume the failure reservation acquired for its " +
                "own connection and child stream"
        }
        var scheduleDrain = false
        var releasedFailureCapacity = false
        var admittedEvent: String? = null
        val outcome = withRpcNotificationMonitor(lock) {
            isolateFromProcessWideBudgetLocked()
            if (closed || !rootChannel.isOpen || !channel.isOpen) {
                releaseReservedFailureLocked(failureReservation)
                releasedFailureCapacity = true
                return@withRpcNotificationMonitor AwaitedResponseWriteOutcome.CONNECTION_CLOSED
            }
            check(failureReservation.consume()) {
                "An awaited response failure reservation cannot be consumed more than once"
            }
            check(
                responseBytes > AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PER_CONNECTION
            ) {
                "A response of $responseBytes bytes was rejected without admission even though it " +
                    "does not exceed the ${AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PER_CONNECTION}-byte " +
                    "normal outbox lane"
            }
            check(activeFailureReservations.remove(failureReservation)) {
                "An oversized awaited response lost its pre-acquired failure reservation"
            }
            failureQueue.addLast(
                Entry(
                    channel,
                    failureReservation.buffer,
                    failureReservation.bytes,
                    failureReservation.lane,
                    failureReservation.processWideCharge,
                    responseIdentity = failureReservation.responseIdentity,
                    requestPermit = retainedLongPollFailurePermit(failureReservation),
                )
            )
            scheduleDrain = true
            admittedEvent = "ADMITTED:${failureReservation.lane.observerName}"
            AwaitedResponseWriteOutcome.OUTBOX_FULL
        }
        if (releasedFailureCapacity) notifyAwaitedResponseFailureCapacityWaiters()
        if (scheduleDrain) scheduleDrain()
        admittedEvent?.let(::notifyObserver)
        return outcome
    }

    /** Queues a pre-charged refusal without entering the uncharged waiting-response list. */
    fun enqueueReservedFailureSignal(
        channel: io.netty.channel.Channel,
        reservation: AwaitedResponseFailureReservation,
    ): AwaitedResponseWriteOutcome {
        observeChildChannel(channel)
        check(reservation.outbox === this && reservation.channel === channel) {
            "An RPC refusal must use the failure reservation acquired for its connection and child stream"
        }
        val outcome = withRpcNotificationMonitor(lock) {
            isolateFromProcessWideBudgetLocked()
            if (closed || !rootChannel.isOpen || !channel.isOpen) {
                releaseReservedFailureLocked(reservation)
                return@withRpcNotificationMonitor AwaitedResponseWriteOutcome.CONNECTION_CLOSED
            }
            check(reservation.consume()) { "An RPC refusal reservation cannot be consumed more than once" }
            check(activeFailureReservations.remove(reservation)) {
                "An RPC refusal lost its pre-acquired failure reservation"
            }
            failureQueue.addLast(
                Entry(
                    channel,
                    reservation.buffer,
                    reservation.bytes,
                    reservation.lane,
                    reservation.processWideCharge,
                    responseIdentity = reservation.responseIdentity,
                    requestPermit = reservation.requestPermit?.handoffToResponse(),
                    preserveOnClose = false,
                )
            )
            AwaitedResponseWriteOutcome.QUEUED
        }
        if (outcome == AwaitedResponseWriteOutcome.QUEUED) {
            scheduleDrain()
            notifyObserver("ADMITTED:${reservation.lane.observerName}")
        } else {
            notifyAwaitedResponseFailureCapacityWaiters()
        }
        return outcome
    }

    fun sendReservedFailureThenClose(
        channel: io.netty.channel.Channel,
        failureReservation: AwaitedResponseFailureReservation,
    ): AwaitedResponseWriteOutcome {
        check(failureReservation.outbox === this && failureReservation.channel === channel) {
            "An awaited response must use the failure reservation acquired for its own " +
                "connection and child stream"
        }
        val failureBuffer = withRpcNotificationMonitor(lock) {
            if (closed || !rootChannel.isOpen || !channel.isOpen) {
                releaseReservedFailureLocked(failureReservation)
                null
            } else {
                check(failureReservation.consume()) {
                    "An awaited response failure reservation cannot be consumed more than once"
                }
                detachReservedFailureLocked(failureReservation)
                    ?: error("An awaited response lost its pre-acquired failure reservation")
            }
        }
        notifyAwaitedResponseFailureCapacityWaiters()
        if (failureBuffer == null) return AwaitedResponseWriteOutcome.CONNECTION_CLOSED
        val permit = retainedLongPollFailurePermit(failureReservation)
        try {
            val terminal = writeTerminalFramesThenClose(channel, listOf(failureBuffer))
            if (terminal == null) permit?.releaseByResponse()
            else terminal.addListener { permit?.releaseByResponse() }
        } catch (failure: Throwable) {
            permit?.releaseByResponse()
            throw failure
        }
        return AwaitedResponseWriteOutcome.OUTBOX_FULL
    }

    fun scheduleDrain() {
        if (!rootChannel.eventLoop().inEventLoop()) {
            val registerOnLoop = withRpcNotificationMonitor(lock) {
                // Record first pause before waiting for the loop, including when registering
                // its timer is rejected. Recovery must not grant a fresh grace interval.
                updateStalledRetirementLocked()
                // Closed output still uses the immediate paused-write retirement path below.
                if (closed) false
                else {
                    if (drainRegistrationPending) return
                    drainRegistrationPending = true
                    true
                }
            }
            if (registerOnLoop) {
                dispatchAwaitedResponseTask(rootChannel, {
                    synchronized(lock) { drainRegistrationPending = false }
                    scheduleDrain()
                }, { reconciliation.fallbackExecutor().execute { closeAndRelease() } })
                return
            }
        }
        var retiring = emptyList<Entry>()
        // Submission and rollback share the claim monitor so another admission cannot rely
        // on a claim whose task was rejected. Netty queues this task; no observer runs here.
        withRpcNotificationMonitor(lock) {
            updateStalledRetirementLocked()
            if (closed || queuesAreEmpty()) {
                drainScheduled = false
                if (closed) {
                    retiring = inFlightEntries.filter {
                        !it.writeFuture.isDone && requiresCloseRetirementLocked(it)
                    }
                    retiring.forEach { it.retired = true }
                }
            } else if (!drainScheduled && hasDrainableEntry()) {
                drainScheduled = true
                try {
                    dispatchAwaitedResponseTask(rootChannel, ::drain, {
                        reconciliation.fallbackExecutor().execute { closeAndRelease() }
                    })
                } catch (rejection: java.util.concurrent.RejectedExecutionException) {
                    drainScheduled = false
                    throw rejection
                }
            }
        }
        // Returned credit cannot remove a pause already observed during close. Completing the
        // logical owner and invoking the child pipeline must happen outside the monitor.
        retiring.forEach(::retireResponseForClose)
    }

    private fun requiresCloseRetirementLocked(entry: Entry): Boolean =
        closed && (entry.retired || entry.pausedInFlight || !effectiveIsWritable(entry.channel))

    private fun retireResponseForClose(entry: Entry) {
        withRpcNotificationMonitor(lock) { entry.retired = true }
        try {
            endRetiredResponse(entry, IOException(
                "UrlProtocol closed the root connection before its paused response completed"
            ))
        } finally {
            if (entry.channel !== rootChannel) entry.channel.close()
        }
    }

    private fun endRetiredResponse(entry: Entry, cause: Throwable) {
        // Physical success published before retirement must keep its successful outcome even
        // when its ordinary executor notification has not run yet.
        val physical = entry.transportWrite
        if (physical != null && physical.isDone) copyAwaitedResponseWrite(physical, entry.writeFuture)
        else entry.writeFuture.tryFailure(cause)
    }

    /**
     * Queued output paused at its child or root keeps only its connection charge. An in-flight
     * frame keeps its shared charge until completion: those bytes already belong to the transport
     * and cannot wait for a fresh charge if the child resumes. Retirement bounds a paused write's
     * lifetime using the same grace as paused queued output.
     */
    private fun isolateFromProcessWideBudgetLocked() {
        fun isolate(entry: Entry) {
            if (!entry.processWideCharge || effectiveIsWritable(entry.channel)) return
            entry.processWideCharge = false
            releaseLaneBytes(entry.lane, entry.bytes)
        }

        normalQueue.snapshot().forEach(::isolate)
        priorityQueue.snapshot().forEach(::isolate)
        failureQueue.snapshot().forEach(::isolate)
        activeFailureReservations.forEach { reservation ->
            if (reservation.processWideCharge && !effectiveIsWritable(reservation.channel)) {
                reservation.processWideCharge = false
                releaseLaneBytes(reservation.lane, reservation.bytes)
            }
        }
        updateCapacityWaiterLocked()
    }

    private fun updateCapacityWaiterLocked() {
        val needsCharge = !closed &&
            (normalQueue.snapshot() + priorityQueue.snapshot() + failureQueue.snapshot())
                .any { !it.charged || !it.processWideCharge }
        if (needsCharge) awaitedResponseOutboxesWithPendingCharges.add(this)
        else awaitedResponseOutboxesWithPendingCharges.remove(this)
    }

    private fun liveOutputEntriesLocked(): List<Entry> =
        normalQueue.snapshot() + priorityQueue.snapshot() + failureQueue.snapshot() + inFlightEntries

    private fun cancelStalledChildRetirementLocked(channel: io.netty.channel.Channel) {
        stalledChildRetirements.remove(channel)?.task?.cancel(false)
    }

    private fun cancelStalledRetirementLocked() {
        stalledChildRetirements.values.forEach { it.task?.cancel(false) }
        stalledChildRetirements.clear()
        // Answers retain their owner reference: protocol close still owes them retirement even
        // if a writability callback gets here after the close claim cancelled its timers.
    }

    private fun cancelInactiveStalledRetirementsLocked() {
        val liveChannels = liveOutputEntriesLocked().mapTo(HashSet()) { it.channel }
        stalledChildRetirements.keys.toList().forEach { channel ->
            if (channel !in liveChannels) cancelStalledChildRetirementLocked(channel)
        }
    }

    private fun updateStalledRetirementLocked(completedChild: io.netty.channel.Channel? = null) {
        isolateFromProcessWideBudgetLocked()
        if (!rootChannel.isOpen) {
            cancelStalledRetirementLocked()
            return
        }
        val outputByChild = liveOutputEntriesLocked().groupBy { it.channel }
        outputByChild.forEach { (channel, entries) ->
            if (!effectiveIsWritable(channel)) entries.filter { it.writeStarted }.forEach {
                it.pausedInFlight = true
            }
        }
        // A whole response completion alone renews an existing obligation, including while
        // returned credit makes the child writable. Partial writes never reach this transition.
        val renewed = completedChild?.let { channel ->
            stalledChildRetirements[channel]?.takeUnless { it.expired }?.let {
                cancelStalledChildRetirementLocked(channel)
                channel
            }
        }
        cancelInactiveStalledRetirementsLocked()
        outputByChild.forEach { (channel, entries) ->
            var owner = stalledChildRetirements[channel]
            if (owner == null && channel.isOpen &&
                (channel === renewed || (!closed && !effectiveIsWritable(channel)))
            ) {
                owner = StalledChildRetirement(
                    awaitedResponseRetirementTime() + AWAITED_RESPONSE_OUTBOX_STALLED_CONNECTION_GRACE_MS,
                )
                stalledChildRetirements[channel] = owner
            }
            if (owner != null && owner.task == null && !owner.expired) {
                val retirement = owner
                try {
                    retirement.task = rootChannel.eventLoop().schedule(
                        { retireIfStillStalled(channel, retirement) },
                        (retirement.deadlineMillis - awaitedResponseRetirementTime()).coerceAtLeast(0L),
                        TimeUnit.MILLISECONDS,
                    )
                } catch (_: java.util.concurrent.RejectedExecutionException) {
                    // The retained drain registration offers this same deadline again. If it
                    // has already elapsed, the loop schedules retirement with zero delay.
                }
            }
            if (owner != null) entries.forEach { it.retirementOwner = owner }
        }
    }

    private fun retireIfStillStalled(
        channel: io.netty.channel.Channel,
        retirement: StalledChildRetirement,
    ) {
        val shouldRetire = withRpcNotificationMonitor(lock) {
            // Completion may have replaced this deadline. Returned credit cannot replace it.
            if (stalledChildRetirements[channel] !== retirement || retirement.expired ||
                (closed && protocolClosePromise == null) ||
                !rootChannel.isOpen || liveOutputEntriesLocked().none { it.retirementOwner === retirement }
            ) return@withRpcNotificationMonitor false
            retirement.expired = true
            // Expiry claims all current output before caller callbacks can re-enter close.
            liveOutputEntriesLocked().forEach { it.retired = true }
            true
        }
        if (!shouldRetire) {
            scheduleDrain()
            return
        }

        try {
            markRelayStreamClose(rootChannel, true, "stalled-write-retirement")
            notifyObserver("RETIRED_STALLED")
            debugLogErr {
                "[RPC] Retiring root ${rootChannel.id().asShortText()} after " +
                    "${AWAITED_RESPONSE_OUTBOX_STALLED_CONNECTION_GRACE_MS}ms without a completed " +
                    "response on child ${channel.id()}; releasing its pending awaited responses"
            }
        } finally {
            finishStalledRetirement()
        }
    }

    private fun finishStalledRetirement() {
        val closingEntries = withRpcNotificationMonitor(lock) {
            if (closed) inFlightEntries.toList() else null
        }
        if (closingEntries != null) {
            // Protocol close already owns the root and its queued cleanup. An existing grace
            // still owns writable barriers; expiration must settle them rather than just join.
            closingEntries.forEach(::retireResponseForClose)
            rootChannel.closeProtocolRoot()
            return
        }
        val terminalWriteFutures = closeAndRelease()
        if (terminalWriteFutures.isEmpty()) {
            rootChannel.closeProtocolRoot()
        } else {
            val remainingWrites = AtomicInteger(terminalWriteFutures.size)
            terminalWriteFutures.forEach { terminalWriteFuture ->
                terminalWriteFuture.addListener {
                    if (remainingWrites.decrementAndGet() == 0) rootChannel.closeProtocolRoot()
                }
            }
        }
    }

    private fun reportDeliveryLoss(
        entry: Entry,
        closeInitiator: RpcResponseDeliveryCloseInitiator,
        cause: Throwable,
    ) {
        entry.deliveryCompletion?.let { completion ->
            notifyRpcObserver(rootChannel, "Relay response delivery failure") { completion(cause) }
        }
        val identity = entry.responseIdentity ?: return
        if (entry.responseFrameCompleted.get() || !entry.deliveryLossReported.compareAndSet(false, true)) {
            return
        }
        try {
            reportRpcResponseDeliveryLoss(
                RpcResponseDeliveryLossEffect(
                    requestId = identity.requestId,
                    method = identity.method,
                    serviceIdentifier = identity.serviceIdentifier,
                    childStreamId = entry.channel.id().asLongText(),
                    rootConnectionGeneration = rootConnectionGeneration,
                    closeInitiator = closeInitiator,
                    deliveryCause = cause,
                    responseFrameBytesCompleted = 0L,
                    rootLinkDiagnostics = rootChannel.rootLinkDiagnostics(),
                )
            )
        } catch (failure: Throwable) {
            val close = withRpcNotificationMonitor(lock) { protocolClosePromise }
            close?.recordPreparationFailure(failure)
            throw failure
        }
    }

    fun recordTransportFailure(cause: Throwable) {
        withRpcNotificationMonitor(lock) {
            if (transportFailure == null) transportFailure = cause
        }
    }

    private fun mirrorProtocolCloseResult(previous: ChannelPromise, promise: ChannelPromise) {
        // A terminal result needs no source listener, whose executor may already be stopped.
        if (previous.isDone) {
            if (previous.isSuccess) promise.trySuccess()
            else promise.tryFailure(previous.cause())
            return
        }
        // An already-complete promise invokes this listener inline. Keep it outside the monitor so
        // caller callbacks cannot re-enter while owning outbox state.
        previous.addListener { completed ->
            if (completed.isSuccess) promise.trySuccess()
            else promise.tryFailure(completed.cause())
        }
    }

    fun installRootHandler() {
        if (rootHandlerInstallationClaimed.compareAndSet(false, true)) {
            installAwaitedResponseOutboxRootHandler(rootChannel, this)
        }
    }

    fun closeFromPipeline(ctx: ChannelHandlerContext, promise: ChannelPromise) {
        val shouldIntercept = withRpcNotificationMonitor(lock) {
            // Explicit callers join through closeForProtocol, never through the pipeline.
            // Once that operation owns the close, every outbound traversal is a physical
            // continuation or an independent transport close, even if a handler replaces its
            // promise. Neither may wait on the protocol result it is helping to produce.
            protocolClosePromise == null && !closed &&
                (normalQueue.snapshot() + priorityQueue.snapshot() + failureQueue.snapshot() +
                    inFlightEntries).any { it.responseIdentity != null || it.orderedRegistration }
        }
        if (shouldIntercept) {
            closeForProtocol(promise.unvoid(), ctx)
        } else {
            ctx.close(promise)
        }
    }

    /**
     * Replaces each still-queued RPC response with a small terminal response before a local root
     * close. This outbox owns completion of every protocol close, including an empty outbox.
     */
    fun closeForProtocol(
        promise: ChannelPromise,
        interceptedContext: ChannelHandlerContext? = null,
    ) {
        // Publish ownership on the calling thread, before handler installation or loop submission.
        // Joiners only attach to this independently dispatched result, outside the outbox monitor.
        val candidate = ProtocolRootClosePromise(rootChannel)
        val owned = withRpcNotificationMonitor(lock) {
            protocolClosePromise ?: candidate.also {
                protocolClosePromise = it
                closed = true
            }
        }
        mirrorProtocolCloseResult(owned, promise)
        if (owned !== candidate) return

        val close = OwnedProtocolClose(owned, interceptedContext)
        if (rootChannel.eventLoop().inEventLoop()) {
            startOwnedProtocolClose(close, loopAvailable = true)
            return
        }
        // Termination is watched before the first offer: Netty can accept a task that loses the
        // shutdown race and then neither runs nor rejects it. Whichever path starts first owns
        // preparation; the other returns.
        val termination = io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<Any?>> {
            startOwnedProtocolCloseWithoutLoop(close)
        }
        close.terminationListener = termination
        rootChannel.eventLoop().terminationFuture().addListener(termination)
        offerOwnedProtocolClose(close)
    }

    /** One claimed protocol close; exactly one of its start paths runs preparation. */
    private class OwnedProtocolClose(
        val physicalClose: ProtocolRootClosePromise,
        val interceptedContext: ChannelHandlerContext?,
    ) {
        val started = AtomicBoolean(false)
        @Volatile
        var withoutLoopReason: String = LOOP_STOPPED_REASON
        @Volatile
        var terminationListener: io.netty.util.concurrent.GenericFutureListener<io.netty.util.concurrent.Future<Any?>>? = null
    }

    private fun startOwnedProtocolClose(close: OwnedProtocolClose, loopAvailable: Boolean) {
        if (!close.started.compareAndSet(false, true)) return
        close.terminationListener?.let { listener ->
            close.terminationListener = null
            rootChannel.eventLoop().terminationFuture().removeListener(listener)
        }
        prepareOwnedProtocolClose(
            close.physicalClose,
            if (loopAvailable) close.interceptedContext else null,
            loopAvailable,
            close.withoutLoopReason,
        )
    }

    private fun startOwnedProtocolCloseWithoutLoop(close: OwnedProtocolClose) {
        if (close.started.get()) return
        val task = Runnable { startOwnedProtocolClose(close, loopAvailable = false) }
        try {
            reconciliation.fallbackExecutor().execute(task)
        } catch (rejection: java.util.concurrent.RejectedExecutionException) {
            task.run()
        }
    }

    /**
     * Offers preparation to the root's live event loop. A full queue on a live loop defers the
     * offer by [AWAITED_RESPONSE_RECONCILIATION_INTERVAL_MS] on the reconciliation clock; the
     * clock thread only re-offers the task. A loop that is shutting down is left to the
     * termination listener, which prepares and closes without the loop.
     */
    private fun offerOwnedProtocolClose(close: OwnedProtocolClose) {
        if (close.started.get()) return
        val loop = rootChannel.eventLoop()
        try {
            loop.execute { startOwnedProtocolClose(close, loopAvailable = true) }
        } catch (failure: Throwable) {
            if (failure is java.util.concurrent.RejectedExecutionException && loop.isShuttingDown) return
            if (isFatalJvmError(failure)) {
                // Protect the claim first: it stays owned and is offered again, so every caller
                // completes, with this error as the primary result. Then the error leaves here.
                close.physicalClose.recordPreparationFailure(failure)
                deferOwnedProtocolClose(close)
                throw failure
            }
            deferOwnedProtocolClose(close)
        }
    }

    private fun deferOwnedProtocolClose(close: OwnedProtocolClose) {
        val clock = reconciliation.clock
        try {
            clock.schedule(clock.currentTimeMillis() + AWAITED_RESPONSE_RECONCILIATION_INTERVAL_MS) {
                offerOwnedProtocolClose(close)
            }
        } catch (failure: Throwable) {
            close.physicalClose.recordPreparationFailure(IOException(
                "Protocol close of root ${rootChannel.id()} could not be offered to its event loop " +
                    "again because the reconciliation clock rejected the retry",
                failure,
            ))
            close.withoutLoopReason = FULL_QUEUE_CLOCK_REJECTED_REASON
            startOwnedProtocolCloseWithoutLoop(close)
            rethrowFatalJvmError(failure)
        }
    }

    private fun prepareOwnedProtocolClose(
        physicalClose: ProtocolRootClosePromise,
        interceptedContext: ChannelHandlerContext?,
        loopAvailable: Boolean,
        withoutLoopReason: String = LOOP_STOPPED_REASON,
    ) {
        val fatal = ProtocolRootCloseFatal()
        val loopEnded: Throwable? = if (loopAvailable) null else IOException(
            "UrlProtocol could not prepare the protocol close of root ${rootChannel.id()} on its " +
                "event loop because " + if (withoutLoopReason == LOOP_STOPPED_REASON) "that loop stopped running tasks"
                else "that loop's task queue was full and the reconciliation clock rejected the retry"
        )
        var queuedEntries = emptyList<Entry>()
        var inFlightSnapshot = emptyList<Entry>()
        var reservationBuffers = emptyList<ByteBuf>()
        prepareProtocolRootClose(physicalClose, fatal) {
            withRpcNotificationMonitor(lock) {
                drainScheduled = false
                queuedEntries = (normalQueue.snapshot() + priorityQueue.snapshot() + failureQueue.snapshot()).sortedBy { it.order }
                inFlightSnapshot = inFlightEntries.toList()
                inFlightSnapshot.forEach { entry ->
                    if (entry.writeStarted && !effectiveIsWritable(entry.channel)) entry.pausedInFlight = true
                    if (entry.retired || !entry.writeStarted || entry.pausedInFlight) entry.retired = true
                }
                // Detach each reservation from the pool it originally charged, including
                // reservations isolated from the shared budget while their output was paused.
                reservationBuffers = activeFailureReservations.toList()
                    .mapNotNull(::detachReservedFailureLocked)
                orderedRegistrationEntries.clear()
                normalQueue.clear()
                priorityQueue.clear()
                failureQueue.clear()
                queuedEntries.forEach(::releaseEntryChargeLocked)
            }
        }
        if (loopAvailable) {
            prepareProtocolRootClose(physicalClose, fatal) { installRootHandler() }
        }
        reservationBuffers.forEach { buffer ->
            prepareProtocolRootClose(physicalClose, fatal) { releaseIfRetained(buffer) }
        }
        prepareProtocolRootClose(physicalClose, fatal) { notifyAwaitedResponseFailureCapacityWaiters() }

        val barriers = ArrayList<Pair<Entry, io.netty.channel.ChannelFuture>>()
        queuedEntries.forEach { entry ->
            prepareProtocolRootClose(physicalClose, fatal) {
                try { if (!entry.orderedRegistration) releaseIfRetained(entry.buffer) }
                finally { entry.requestPermit?.releaseByResponse() }
            }
            prepareProtocolRootClose(physicalClose, fatal) {
                val identity = entry.responseIdentity
                val canWriteTerminal = loopAvailable && (identity != null || entry.orderedRegistration) &&
                    rootChannel.isOpen && rootChannel.isWritable && entry.channel.isOpen &&
                    effectiveIsWritable(entry.channel) && !chunkedAttachmentFrameInFlight(entry.channel) &&
                    inFlightSnapshot.none { it.channel === entry.channel && it.retired }
                if (canWriteTerminal) {
                    val terminalBuffer = if (entry.orderedRegistration) entry.buffer else framedRpcJsonBuffer(
                        Libp2pRpcProtocol.RpcResponse(
                            id = checkNotNull(identity).requestId,
                            result = null,
                            error = Libp2pRpcProtocol.RpcError(
                                code = RESPONSE_DELIVERY_ENDED_CODE,
                                message = RESPONSE_DELIVERY_ENDED_MESSAGE,
                            ),
                        ).toJson()
                    )
                    var handedOff = false
                    var writePromise: ChannelPromise? = null
                    try {
                        val result = DefaultChannelPromise(entry.channel, ImmediateEventExecutor.INSTANCE)
                        writePromise = result
                        barriers.add(entry to result)
                        val write = newAwaitedResponseWritePromise(entry.channel)
                        mirrorAwaitedResponseWrite(write, result)
                        entry.channel.writeAndFlush(terminalBuffer, write)
                        handedOff = true
                        observeAwaitedResponseWriteLifetime(
                            rootChannel, write, result, reconciliation,
                            registrationFailure = physicalClose::recordPreparationFailure,
                        )
                    } catch (failure: Throwable) {
                        physicalClose.recordPreparationFailure(failure)
                        if (isFatalJvmError(failure) && fatal.first == null) fatal.first = failure
                        writePromise?.tryFailure(failure)
                        if (!handedOff) {
                            prepareProtocolRootClose(physicalClose, fatal) { releaseIfRetained(terminalBuffer) }
                        }
                        reportDeliveryLoss(entry, RpcResponseDeliveryCloseInitiator.PROTOCOL, failure)
                    }
                } else if (identity != null || entry.orderedRegistration) {
                    if (entry.orderedRegistration) releaseIfRetained(entry.buffer)
                    reportDeliveryLoss(
                        entry,
                        RpcResponseDeliveryCloseInitiator.PROTOCOL,
                        loopEnded ?: IOException(
                            "UrlProtocol closed the root connection while its queued terminal " +
                                "response could not be written"
                        ),
                    )
                }
            }
        }
        inFlightSnapshot.forEach { entry ->
            prepareProtocolRootClose(physicalClose, fatal) {
                val writeFuture = entry.writeFuture
                // Close is terminal for paused output even during a returned-credit window.
                // Settle its logical owner before selecting barriers; physical completion may
                // still win the result, but an incomplete frame can never hold this close open.
                if (entry.retired) {
                    retireResponseForClose(entry)
                } else if (!writeFuture.isDone) {
                    barriers.add(entry to writeFuture)
                } else if (writeFuture.isSuccess) {
                    entry.responseFrameCompleted.set(true)
                } else if (entry.responseIdentity != null) {
                    reportDeliveryLoss(
                        entry,
                        RpcResponseDeliveryCloseInitiator.PROTOCOL,
                        writeFuture.cause() ?: loopEnded ?: IOException(
                            "UrlProtocol closed the root connection before the response write completed"
                        ),
                    )
                }
            }
        }

        val handedOff = AtomicBoolean(false)
        fun finishClose() {
            if (!handedOff.compareAndSet(false, true)) return
            if (!loopAvailable) {
                closeRootWithoutLoop(physicalClose, withoutLoopReason)
                return
            }
            val loop = rootChannel.eventLoop()
            if (!loop.inEventLoop() && loop.isShuttingDown) {
                // The barrier completed after the loop stopped accepting work; a submission would
                // only be rejected. Close without the loop on this root's fallback thread.
                val task = Runnable { closeRootWithoutLoop(physicalClose, LOOP_STOPPED_REASON) }
                try { reconciliation.fallbackExecutor().execute(task) }
                catch (_: java.util.concurrent.RejectedExecutionException) { task.run() }
                return
            }
            try {
                // Preserve the complete outbound traversal, including replacement promises.
                if (interceptedContext != null) interceptedContext.close(physicalClose)
                else rootChannel.close(physicalClose)
            } catch (failure: Throwable) {
                physicalClose.tryFailure(failure)
            }
        }

        // The extra barrier owns listener registration itself. Even an inline callback followed by
        // a registration failure cannot finish the close before that failure has been recorded.
        val remaining = AtomicInteger(barriers.size + 1)
        val registering = AtomicBoolean(true)
        barriers.forEach { (entry, future) ->
            val discharged = AtomicBoolean(false)
            try {
                future.addListener { completed ->
                    if (discharged.compareAndSet(false, true)) {
                        try {
                            // Inline completion during registration defers a fatal error until the
                            // bookkeeping below has run; a later completion rethrows it at once.
                            prepareProtocolRootClose(physicalClose, if (registering.get()) fatal else null) {
                                if (completed.isSuccess) {
                                    entry.responseFrameCompleted.set(true)
                                    if (entry.orderedRegistration) entry.deliveryCompletion?.invoke(null)
                                } else {
                                    reportDeliveryLoss(
                                        entry,
                                        RpcResponseDeliveryCloseInitiator.PROTOCOL,
                                        completed.cause() ?: IOException(
                                            "UrlProtocol could not complete a response frame before closing"
                                        ),
                                    )
                                }
                            }
                        } finally {
                            if (remaining.decrementAndGet() == 0) finishClose()
                        }
                    }
                }
            } catch (failure: Throwable) {
                physicalClose.recordPreparationFailure(failure)
                if (isFatalJvmError(failure) && fatal.first == null) fatal.first = failure
                if (discharged.compareAndSet(false, true)) remaining.decrementAndGet()
            }
        }
        registering.set(false)
        if (remaining.decrementAndGet() == 0) finishClose()
        // Every caller is settled or owned by a registered barrier; the fatal error leaves now.
        fatal.first?.let { throw it }
    }

    /**
     * The physical close once the root's event loop stopped running tasks. A root the transport
     * already closed completes successfully without another attempt; otherwise one close is
     * attempted from this thread and a failure names the root.
     */
    private fun closeRootWithoutLoop(physicalClose: ProtocolRootClosePromise, reason: String) {
        if (rootChannel.closeFuture().isDone) {
            physicalClose.trySuccess()
            return
        }
        val attempt = DefaultChannelPromise(rootChannel, ImmediateEventExecutor.INSTANCE)
        attempt.addListener { attempted ->
            if (attempted.isSuccess) physicalClose.trySuccess()
            else physicalClose.tryFailure(IOException(
                "Protocol close of root ${rootChannel.id()} $reason, and the physical close attempt failed",
                attempted.cause(),
            ))
        }
        try { rootChannel.close(attempt) } catch (failure: Throwable) { attempt.tryFailure(failure) }
    }


    fun closeAndRelease(
        closeInitiator: RpcResponseDeliveryCloseInitiator =
            RpcResponseDeliveryCloseInitiator.TRANSPORT,
        cause: Throwable? = null,
    ): List<io.netty.channel.ChannelFuture> {
        val cleanup = withRpcNotificationMonitor(lock) {
            if (closed) return emptyList()
            closed = true
            cancelStalledRetirementLocked()
            drainScheduled = false
            val queuedEntries =
                (normalQueue.snapshot() + priorityQueue.snapshot() + failureQueue.snapshot()).sortedBy { it.order }
            val retained = ArrayList<ByteBuf>(queuedEntries.size + activeFailureReservations.size)
            val terminalWrites = ArrayList<TerminalWrite>(queuedEntries.size)
            val affectedChannels = LinkedHashSet<io.netty.channel.Channel>()
            val partialChildren = inFlightEntries.filter { !it.writeFuture.isDone }
                .mapTo(HashSet()) { it.channel }
            val rootWasActive = rootChannel.isActive
            val undeliverableQueuedEntries = ArrayList<Entry>()
            queuedEntries.forEach { entry ->
                affectedChannels.add(entry.channel)
                releaseEntryChargeLocked(entry)
                if (!rootWasActive || entry.channel in partialChildren) {
                    undeliverableQueuedEntries.add(entry)
                    // A child write can still report success after its physical root has gone
                    // inactive. Do not turn that local acceptance into a claim that either the
                    // queued response or its fallback reached the peer.
                    retained.add(entry.buffer)
                    entry.terminalFailure?.let { reservation ->
                        detachReservedFailureLocked(reservation)?.let(retained::add)
                    }
                } else if (entry.orderedRegistration || (entry.lane.isFailure && entry.preserveOnClose) || entry.lane == Lane.REFUSAL) {
                    if (entry.orderedRegistration) entry.terminalFailure?.let { reservation ->
                        detachReservedFailureLocked(reservation)?.let(retained::add)
                    }
                    terminalWrites.add(TerminalWrite(entry.channel, entry.buffer, entry))
                } else {
                    retained.add(entry.buffer)
                    entry.terminalFailure?.let { reservation ->
                        detachReservedFailureLocked(reservation)?.let { failureBuffer ->
                            terminalWrites.add(TerminalWrite(entry.channel, failureBuffer, entry))
                        }
                    }
                }
            }
            activeFailureReservations.toList().forEach { reservation ->
                affectedChannels.add(reservation.channel)
                detachReservedFailureLocked(reservation)?.let(retained::add)
            }
            val inFlightSnapshot = inFlightEntries.toList()
            inFlightSnapshot.forEach { entry ->
                entry.retired = true
                affectedChannels.add(entry.channel)
            }
            orderedRegistrationEntries.clear()
            normalQueue.clear()
            priorityQueue.clear()
            failureQueue.clear()
            updateCapacityWaiterLocked()
            CloseCleanup(
                retained,
                terminalWrites,
                affectedChannels,
                inFlightSnapshot,
                queuedEntries,
                undeliverableQueuedEntries,
            )
        }
        val deliveryCause = cause ?: withRpcNotificationMonitor(lock) { transportFailure } ?: EOFException(
            "Root connection became inactive before any response-frame byte completed"
        )
        cleanup.retainedBuffers.forEach(::releaseIfRetained)
        cleanup.queuedEntries.forEach { it.requestPermit?.releaseByResponse() }
        cleanup.inFlightEntries.forEach { entry ->
            // The transport owns the buffer. End the answer once, then close the child to drop
            // physical output. A retaining extension still owns its own ByteBuf reference.
            try { endRetiredResponse(entry, deliveryCause) }
            finally { if (entry.channel !== rootChannel) entry.channel.close() }
        }
        cleanup.undeliverableQueuedEntries.forEach { entry ->
            reportDeliveryLoss(entry, closeInitiator, deliveryCause)
        }
        cleanup.terminalWrites.forEach { terminal ->
            markAwaitedResponseAsRetiringRoot(terminal.buffer)
        }
        // Remove each channel's references from this owned ledger before invoking its pipeline.
        // A synchronous child close cannot put transferred references back into the ledger.
        val terminalWritesByChannel = cleanup.terminalWrites.groupBy { it.channel }.toMutableMap()
        val terminalWriteFutures = ArrayList<io.netty.channel.ChannelFuture>(
            cleanup.affectedChannels.size
        )
        cleanup.affectedChannels.forEach { channel ->
            if (channel !== rootChannel && channel.isOpen) {
                val terminalWrites = terminalWritesByChannel.remove(channel).orEmpty()
                val terminalWriteFuture = writeTerminalFramesThenClose(
                    channel,
                    terminalWrites.map { it.buffer },
                )
                if (terminalWriteFuture == null) {
                    terminalWrites.forEach { terminal ->
                        terminal.sourceEntry?.let { entry ->
                            reportDeliveryLoss(entry, closeInitiator, deliveryCause)
                        }
                    }
                } else {
                    terminalWriteFuture.addListener { completed ->
                        terminalWrites.forEach { terminal ->
                            terminal.sourceEntry?.let { entry ->
                                if (completed.isSuccess) {
                                    entry.responseFrameCompleted.set(true)
                                } else {
                                    reportDeliveryLoss(
                                        entry,
                                        closeInitiator,
                                        completed.cause() ?: deliveryCause,
                                    )
                                }
                            }
                        }
                    }
                    terminalWriteFutures.add(terminalWriteFuture)
                }
            }
        }
        terminalWritesByChannel.values.flatten().forEach { terminal ->
            releaseIfRetained(terminal.buffer)
            terminal.sourceEntry?.let { entry ->
                reportDeliveryLoss(entry, closeInitiator, deliveryCause)
            }
        }
        notifyAwaitedResponseFailureCapacityWaiters()
        return terminalWriteFutures
    }

    /** The sole terminal owner of a response's byte charge, failure reservation and permit. */
    private fun completeResponseWrite(entry: Entry, completed: io.netty.channel.ChannelFuture) {
        withRpcNotificationMonitor(lock) {
            inFlightEntries.remove(entry)
            updateStalledRetirementLocked(if (completed.isSuccess) entry.channel else null)
        }
        try {
            if (completed.isSuccess) {
                entry.responseFrameCompleted.set(true)
                entry.deliveryCompletion?.invoke(null)
            } else {
                val closeInitiator = withRpcNotificationMonitor(lock) {
                    if (protocolClosePromise != null) {
                        RpcResponseDeliveryCloseInitiator.PROTOCOL
                    } else {
                        RpcResponseDeliveryCloseInitiator.TRANSPORT
                    }
                }
                reportDeliveryLoss(
                    entry,
                    closeInitiator,
                    completed.cause() ?: IOException(
                        "Response frame write ended before completion"
                    ),
                )
            }
        } finally {
            try {
                releaseEntryCharge(entry)
                if (entry.lane.isFailure || entry.lane == Lane.REFUSAL) {
                    notifyAwaitedResponseFailureCapacityWaiters()
                } else if (completed.isSuccess || entry.retired) {
                    withRpcNotificationMonitor(lock) {
                        entry.terminalFailure?.let(::releaseReservedFailureLocked)
                    }
                    notifyAwaitedResponseFailureCapacityWaiters()
                } else {
                    val failureBuffer = withRpcNotificationMonitor(lock) {
                        entry.terminalFailure?.let(::detachReservedFailureLocked)
                    }
                    if (failureBuffer != null) {
                        writeTerminalFramesThenClose(entry.channel, listOf(failureBuffer))
                        notifyAwaitedResponseFailureCapacityWaiters()
                    }
                }
            } finally {
                entry.requestPermit?.releaseByResponse()
            }
        }
    }

    private fun drain() {
        var drainedEntries = 0
        while (drainedEntries < AWAITED_RESPONSE_OUTBOX_DRAIN_BATCH_ENTRIES) {
            val entry = withRpcNotificationMonitor(lock) {
                if (closed || !rootChannel.isOpen) {
                    null
                } else {
                    nextEntry()
                }
            }
            if (entry == null) {
                if (!rootChannel.isOpen) closeAndRelease()
                val reschedule = withRpcNotificationMonitor(lock) {
                    drainScheduled = false
                    !closed && hasDrainableEntry()
                }
                if (reschedule) scheduleDrain()
                return
            }

            var handedOff = false
            try {
                val writeFuture = entry.writeFuture
                val startWrite = withRpcNotificationMonitor(lock) {
                    if (closed || entry.retired || !entry.channel.isOpen || writeFuture.isDone) false
                    else { entry.writeStarted = true; true }
                }
                if (!startWrite) {
                    releaseIfRetained(entry.buffer)
                    writeFuture.tryFailure(EOFException("Awaited response ended before transport handoff"))
                    drainedEntries++
                    continue
                }
                val physicalWrite = newAwaitedResponseWritePromise(entry.channel)
                entry.transportWrite = physicalWrite
                mirrorAwaitedResponseWrite(physicalWrite, writeFuture)
                entry.channel.writeAndFlush(entry.buffer, physicalWrite)
                handedOff = true
                observeAwaitedResponseWriteLifetime(
                    rootChannel, physicalWrite, writeFuture, reconciliation,
                    registrationFailure = { failure ->
                        val close = withRpcNotificationMonitor(lock) { protocolClosePromise }
                        close?.recordPreparationFailure(failure)
                    },
                    closeRetirement = AwaitedResponseCloseRetirement(
                        isRequired = { synchronized(lock) { requiresCloseRetirementLocked(entry) } },
                        retire = { retireResponseForClose(entry) },
                    ),
                )
            } catch (failure: Throwable) {
                // Any throwable, fatal or not, still leaves this write observed and accounted.
                if (!handedOff) releaseIfRetained(entry.buffer)
                // The answer's terminal listener owns every release, even before handoff.
                entry.writeFuture.tryFailure(failure)
                if (isFatalJvmError(failure)) {
                    // The write is already observed and accounted above. Hand the remaining queue
                    // to a fresh drain claim, then let the fatal error leave this task.
                    try {
                        withRpcNotificationMonitor(lock) { drainScheduled = false }
                        scheduleDrain()
                    } finally {
                        throw failure
                    }
                }
                entry.channel.pipeline().fireExceptionCaught(failure)
            }
            try {
                // The transport owns the buffer and its completion listener before caller code
                // can run. A reporter failure cannot interrupt that ownership handoff.
                notifyObserver("DRAINED:${entry.lane.observerName}")
            } catch (failure: Throwable) {
                // This task ends here, but already queued siblings still need a drain owner.
                // Use the ordinary claim so a concurrent admission cannot schedule a duplicate.
                synchronized(lock) { drainScheduled = false }
                try {
                    scheduleDrain()
                } catch (rejection: java.util.concurrent.RejectedExecutionException) {
                    // This drain runs on the root event loop. Scheduling from that thread
                    // enters Netty's separate scheduled queue even when its ordinary task
                    // queue is full. The accepted continuation reclaims through scheduleDrain
                    // after this fatal leaves the current task; it runs no observer here.
                    try {
                        rootChannel.eventLoop().schedule({
                            try {
                                scheduleDrain()
                            } catch (continuationRejection: java.util.concurrent.RejectedExecutionException) {
                                // Another producer can fill the ordinary queue again. End the
                                // queued responses through protocol close instead of leaving
                                // this failed continuation as their only remaining owner.
                                recordTransportFailure(continuationRejection)
                                rootChannel.closeProtocolRoot()
                            }
                        }, 0L, TimeUnit.NANOSECONDS)
                    } finally {
                        debugLogErr {
                            "[RPC] Awaited-response drain submission rejected: " +
                                "${rejection.javaClass.name}: ${rejection.message}"
                        }
                    }
                } finally {
                    // Preserve the original fatal even if submission or its diagnostic fails.
                    throw failure
                }
            }
            drainedEntries++
        }
        val reschedule = withRpcNotificationMonitor(lock) {
            drainScheduled = false
            !closed && hasDrainableEntry()
        }
        if (reschedule) scheduleDrain()
    }

    private fun nextEntry(): Entry? {
        // Completion and relay-refusal budgets share one writer turn between response lanes.
        val lanes = listOf(Lane.NORMAL, Lane.PRIORITY, Lane.FAILURE)
        repeat(lanes.size) {
            val laneIndex = (nextLaneIndex + it) % lanes.size
            val lane = lanes[laneIndex]
            val entry = queue(lane).firstDrainable(::canDrain)
            if (entry != null) {
                nextLaneIndex = (laneIndex + 1) % lanes.size
                queue(entry.lane).remove(entry)
                if (entry.orderedRegistration) {
                    val ordered = orderedRegistrationEntries.getValue(entry.channel)
                    check(ordered.removeFirst() === entry)
                    if (ordered.isEmpty()) orderedRegistrationEntries.remove(entry.channel)
                }
                inFlightEntries.add(entry)
                updateStalledRetirementLocked()
                updateCapacityWaiterLocked()
                return entry
            }
        }
        return null
    }

    private fun hasDrainableEntry(): Boolean =
        listOf(normalQueue, priorityQueue, failureQueue).any { it.hasDrainable(::canDrain) }

    /**
     * A queued response may be written once its substream can take it. A substream that is
     * mid-frame cannot: this drain does not hold [rpcStreamWriteLock], so writing now would place a
     * complete frame between two chunks of the attachment frame already occupying that substream,
     * and the receiver — which copies exactly the declared attachment length — would take those
     * bytes as payload. The frame writer schedules another drain when it finishes, so a deferred
     * entry is retained rather than dropped. A closed substream is still handled here so its entry
     * is released instead of accumulating behind a frame that can no longer complete. An isolated
     * entry reacquires its shared charge here before either drain or its readiness check succeeds.
     */
    private fun canDrain(entry: Entry): Boolean {
        if (entry.orderedRegistration && orderedRegistrationEntries[entry.channel]?.firstOrNull() !== entry) return false
        if (!entry.channel.isOpen) return true
        if (!entry.charged || !effectiveIsWritable(entry.channel) ||
            chunkedAttachmentFrameInFlight(entry.channel)
        ) return false
        if (!entry.processWideCharge) {
            // Register before reserving so a concurrent release cannot miss this connection.
            // Connection capacity is already held; only its shared charge needs reacquiring.
            awaitedResponseOutboxesWithPendingCharges.add(this)
            if (!reserveProcessBytes(entry.lane, entry.bytes)) return false
            entry.processWideCharge = true
        }
        return true
    }

    private fun releaseEntryCharge(entry: Entry) {
        withRpcNotificationMonitor(lock) {
            releaseEntryChargeLocked(entry)
        }
    }

    private fun releaseEntryChargeLocked(entry: Entry) {
        if (!entry.charged) {
            // A waiting response leaves its lane only when its connection or child stream ends
            // (promotion charges it instead). It holds no charge; its caller stops waiting here,
            // exactly once, while the path removing it owns its buffer and terminal frame.
            waitingEntries.remove(entry)
            updateCapacityWaiterLocked()
            if (waitingEntries.isNotEmpty()) requestPromotion()
            entry.pendingAdmission?.complete(AwaitedResponseWriteOutcome.CONNECTION_CLOSED)
            cancelInactiveStalledRetirementsLocked()
            return
        }
        when (entry.lane) {
            Lane.NORMAL -> normalBytes -= entry.bytes
            Lane.PRIORITY -> priorityBytes -= entry.bytes
            Lane.FAILURE -> failureBytes -= entry.bytes
            Lane.LONG_POLL_FAILURE -> longPollFailureBytes -= entry.bytes
            Lane.REFUSAL -> refusalBytes -= entry.bytes
        }
        check(normalBytes >= 0L && priorityBytes >= 0L && failureBytes >= 0L &&
            longPollFailureBytes >= 0L && refusalBytes >= 0L) {
            "Awaited response outbox connection accounting became negative after releasing " +
                "${entry.bytes} ${entry.lane.name.lowercase()} bytes"
        }
        if (entry.processWideCharge) releaseLaneBytes(entry.lane, entry.bytes)
        // An isolated entry returns local space even though it no longer has a shared charge.
        if (entry.lane.isFailure) notifyAwaitedResponseFailureCapacityReleased(rootChannel)
        if (waitingEntries.isNotEmpty()) requestPromotion()
        cancelInactiveStalledRetirementsLocked()
    }

    /**
     * Asks the root event loop to charge waiting responses that now fit. Never takes the outbox
     * monitor, so any thread may call it, including while another outbox's monitor is held.
     */
    internal fun requestPromotion() {
        if (!promotionScheduled.compareAndSet(false, true)) return
        try {
            rootChannel.eventLoop().execute {
                promotionScheduled.set(false)
                promoteWaiting()
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            // The root's loop has stopped. Its close path releases every waiting entry through
            // releaseEntryChargeLocked, which ends each waiting caller.
            promotionScheduled.set(false)
        }
    }

    private fun promoteWaiting() {
        val promoted = withRpcNotificationMonitor(lock) {
            if (closed || !rootChannel.isOpen) return@withRpcNotificationMonitor emptyList()
            isolateFromProcessWideBudgetLocked()
            val charged = ArrayList<Entry>()
            while (waitingEntries.isNotEmpty()) {
                val head = waitingEntries.first()
                val processWideCharge = effectiveIsWritable(head.channel)
                if (!reserve(head.lane, head.bytes, processWideCharge)) break
                waitingEntries.removeFirst()
                head.charged = true
                head.processWideCharge = processWideCharge
                head.requestPermit?.responseAdmitted()
                charged.add(head)
            }
            updateCapacityWaiterLocked()
            charged
        }
        promoted.forEach { it.pendingAdmission?.complete(AwaitedResponseWriteOutcome.QUEUED) }
        scheduleDrain()
        promoted.forEach { notifyObserver("PROMOTED:${it.lane.observerName}") }
    }

    private fun reserve(
        lane: Lane,
        bytes: Long,
        processWideCharge: Boolean,
    ): Boolean {
        if (bytes <= 0L || bytes > laneConnectionLimit(lane)) return false
        val hasConnectionCapacity = when (lane) {
            Lane.NORMAL ->
                normalBytes + priorityBytes <=
                    AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PER_CONNECTION - bytes
            Lane.PRIORITY ->
                priorityBytes <= AWAITED_RESPONSE_OUTBOX_PRIORITY_BYTES_PER_CONNECTION - bytes &&
                    normalBytes + priorityBytes <=
                    AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PER_CONNECTION - bytes
            Lane.FAILURE ->
                failureBytes <= AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION - bytes
            Lane.LONG_POLL_FAILURE ->
                longPollFailureBytes <= AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION - bytes
            Lane.REFUSAL -> refusalBytes <= RELAY_REFUSAL_BYTES_PER_CONNECTION - bytes
        }
        if (!hasConnectionCapacity ||
            (processWideCharge && !reserveProcessBytes(lane, bytes))
        ) return false
        when (lane) {
            Lane.NORMAL -> normalBytes += bytes
            Lane.PRIORITY -> priorityBytes += bytes
            Lane.FAILURE -> failureBytes += bytes
            Lane.LONG_POLL_FAILURE -> longPollFailureBytes += bytes
            Lane.REFUSAL -> refusalBytes += bytes
        }
        return true
    }

    private fun queuesAreEmpty(): Boolean =
        normalQueue.isEmpty() && priorityQueue.isEmpty() && failureQueue.isEmpty()

    private fun queue(lane: Lane): LaneQueue = when (lane) {
        Lane.NORMAL -> normalQueue
        Lane.PRIORITY -> priorityQueue
        Lane.FAILURE, Lane.LONG_POLL_FAILURE, Lane.REFUSAL -> failureQueue
    }

    private fun observeChildChannel(channel: io.netty.channel.Channel) {
        if (channel === rootChannel) return
        withRpcNotificationMonitor(channel) {
            val attr = channel.attr(AWAITED_RESPONSE_OUTBOX_CHILD_ATTR)
            val existing = attr.get()
            if (existing === this) return
            check(existing == null) {
                "A child channel cannot be observed by two awaited response outboxes"
            }
            attr.set(this)
            val handlerName =
                "foundation.url.protocol.awaitedResponseOutboxDrain.${rootChannel.id().asShortText()}"
            if (channel.pipeline().context(handlerName) == null) {
                channel.pipeline().addLast(
                    handlerName,
                    object : ChannelDuplexHandler() {
                        override fun channelWritabilityChanged(ctx: ChannelHandlerContext) {
                            scheduleDrain()
                            ctx.fireChannelWritabilityChanged()
                        }

                        override fun close(ctx: ChannelHandlerContext, promise: ChannelPromise) {
                            val terminalFrames = takeTerminalFramesForClose(ctx.channel())
                            if (terminalFrames.isNotEmpty() && wasResetByRequester(ctx.channel())) {
                                // The requester abandoned this stream. Nothing written to it can
                                // arrive, and a write may never complete once the requester's
                                // receive window is spent, so close now instead of after writes.
                                terminalFrames.forEach(::releaseIfRetained)
                                closeAndReconcileAwaitedResponseWrites(ctx, promise)
                            } else if (terminalFrames.isEmpty()) {
                                closeAndReconcileAwaitedResponseWrites(ctx, promise)
                            } else {
                                writeTerminalFramesThenClose(ctx.channel(), terminalFrames) {
                                    closeAndReconcileAwaitedResponseWrites(ctx, promise)
                                }
                            }
                        }

                        override fun handlerRemoved(ctx: ChannelHandlerContext) {
                            reconcileAwaitedResponseWrites(ctx.channel())
                        }

                        override fun channelInactive(ctx: ChannelHandlerContext) {
                            forgetMuxChild(ctx.channel())
                            reconcileAwaitedResponseWrites(ctx.channel())
                            notifyAwaitedResponseFailureCapacityWaiters(ctx.channel())
                            scheduleDrain()
                            ctx.fireChannelInactive()
                        }
                    }
                )
            }
        }
        // Outside the child monitor: the outbox lock is never taken while a channel monitor is held.
        rememberMuxChild(channel)
    }

    private fun rememberMuxChild(channel: io.netty.channel.Channel) {
        val muxChild = channel as? io.libp2p.etc.util.netty.mux.MuxChannel<*> ?: return
        withRpcNotificationMonitor(lock) {
            muxChildResetByRequester.putIfAbsent(muxChild.id, false)
        }
        // A child that closed before it was remembered never reaches the inactive handler again.
        if (!channel.isOpen) forgetMuxChild(channel)
        installRemoteResetObserver()
    }

    private fun forgetMuxChild(channel: io.netty.channel.Channel) {
        val muxChild = channel as? io.libp2p.etc.util.netty.mux.MuxChannel<*> ?: return
        withRpcNotificationMonitor(lock) {
            muxChildResetByRequester.remove(muxChild.id)
        }
    }

    private fun wasResetByRequester(channel: io.netty.channel.Channel): Boolean {
        val muxChild = channel as? io.libp2p.etc.util.netty.mux.MuxChannel<*> ?: return false
        return withRpcNotificationMonitor(lock) { muxChildResetByRequester[muxChild.id] == true }
    }

    /** Runs on the root event loop, before the multiplexer turns the reset into a child close. */
    private fun recordResetByRequester(id: io.libp2p.etc.util.netty.mux.MuxId) {
        withRpcNotificationMonitor(lock) {
            if (muxChildResetByRequester.containsKey(id)) muxChildResetByRequester[id] = true
        }
    }

    /**
     * Watches the root connection's inbound Yamux frames ahead of the multiplexer so a stream reset
     * sent by the requester is known when the multiplexer closes the child in response. Mplex
     * children have no receive window and need no such observation.
     */
    private fun installRemoteResetObserver() {
        val pipeline = rootChannel.pipeline()
        val yamuxContext = pipeline.context(io.libp2p.mux.yamux.YamuxHandler::class.java) ?: return
        if (!remoteResetObserverInstallationClaimed.compareAndSet(false, true)) return
        val outbox = this
        try {
            pipeline.addBefore(
                yamuxContext.name(),
                "foundation.url.protocol.awaitedResponseRemoteReset.${rootChannel.id().asShortText()}",
                object : ChannelInboundHandlerAdapter() {
                    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
                        if (
                            msg is io.libp2p.mux.yamux.YamuxFrame &&
                            io.libp2p.mux.yamux.YamuxFlag.RST in msg.flags
                        ) {
                            outbox.recordResetByRequester(msg.id)
                        }
                        ctx.fireChannelRead(msg)
                    }
                },
            )
        } catch (_: java.util.NoSuchElementException) {
            // The multiplexer left the pipeline while the root was closing; no child can be
            // reset after that, and root close releases every queued reply.
        }
    }

    private fun takeTerminalFramesForClose(
        channel: io.netty.channel.Channel,
    ): List<ByteBuf> {
        val releasedResponses = ArrayList<ByteBuf>()
        val terminalFrames = ArrayList<ByteBuf>()
        val transportLossEntries = ArrayList<Entry>()
        var removedEntries = emptyList<Entry>()
        var cancelledInFlight = emptyList<Entry>()
        withRpcNotificationMonitor(lock) {
            val entries = (normalQueue.removeAll(channel) +
                priorityQueue.removeAll(channel) +
                failureQueue.removeAll(channel)).sortedBy { it.order }
            orderedRegistrationEntries.remove(channel)
            removedEntries = entries
            cancelledInFlight = inFlightEntries.filter { it.channel === channel }
            cancelledInFlight.forEach { it.retired = true }
            val rootWasActive = rootChannel.isActive && !closed && cancelledInFlight.isEmpty()
            entries.forEach { entry ->
                releaseEntryChargeLocked(entry)
                if (!rootWasActive) {
                    releasedResponses.add(entry.buffer)
                    entry.terminalFailure?.let { reservation ->
                        detachReservedFailureLocked(reservation)?.let(releasedResponses::add)
                    }
                    transportLossEntries.add(entry)
                } else if (entry.orderedRegistration || (entry.lane.isFailure && entry.preserveOnClose) || entry.lane == Lane.REFUSAL) {
                    if (entry.orderedRegistration) entry.terminalFailure?.let { reservation ->
                        detachReservedFailureLocked(reservation)?.let(releasedResponses::add)
                    }
                    terminalFrames.add(entry.buffer)
                } else {
                    releasedResponses.add(entry.buffer)
                    entry.terminalFailure?.let { reservation ->
                        detachReservedFailureLocked(reservation)?.let(terminalFrames::add)
                    }
                }
            }
            updateCapacityWaiterLocked()
        }
        releasedResponses.forEach(::releaseIfRetained)
        removedEntries.forEach { it.requestPermit?.releaseByResponse() }
        cancelledInFlight.forEach { entry ->
            entry.writeFuture.tryFailure(EOFException("Awaited response child closed before its frame completed"))
        }
        if (transportLossEntries.isNotEmpty()) {
            val deliveryCause = withRpcNotificationMonitor(lock) { transportFailure } ?: EOFException(
                "Root connection became inactive before any response-frame byte completed"
            )
            transportLossEntries.forEach { entry ->
                reportDeliveryLoss(
                    entry,
                    RpcResponseDeliveryCloseInitiator.TRANSPORT,
                    deliveryCause,
                )
            }
        }
        if (terminalFrames.isNotEmpty()) notifyAwaitedResponseFailureCapacityWaiters()
        return terminalFrames
    }

    private fun writeTerminalFramesThenClose(
        channel: io.netty.channel.Channel,
        terminalFrames: List<ByteBuf>,
        close: () -> Unit = {
            if (channel === rootChannel) channel.closeProtocolRoot() else channel.close()
        },
    ): io.netty.channel.ChannelFuture? {
        if (!channel.isOpen || terminalFrames.isEmpty()) {
            terminalFrames.forEach(::releaseIfRetained)
            close()
            return null
        }
        return try {
            var lastWrite: AwaitedResponseWritePromise? = null
            var handedOff = 0
            try {
                terminalFrames.forEach { frame ->
                    val physicalWrite = newAwaitedResponseWritePromise(channel)
                    channel.write(frame, physicalWrite)
                    lastWrite = physicalWrite
                    handedOff++
                }
            } catch (failure: Exception) {
                terminalFrames.drop(handedOff).forEach(::releaseIfRetained)
                throw failure
            }
            channel.flush()
            val write = checkNotNull(lastWrite)
            val result = DefaultChannelPromise(channel, ImmediateEventExecutor.INSTANCE)
            mirrorAwaitedResponseWrite(write, result)
            // Automatic stalled retirement reaches this path before it publishes a protocol
            // close owner. A handler-retained terminal write must therefore observe child/root
            // lifetime here too, or a dead child can prevent that owner from ever being created.
            observeAwaitedResponseWriteLifetime(rootChannel, write, result, reconciliation) { failure ->
                val ownedClose = withRpcNotificationMonitor(lock) { protocolClosePromise }
                if (ownedClose != null) ownedClose.recordPreparationFailure(failure)
                else channel.pipeline().fireExceptionCaught(failure)
            }
            result.also { it.addListener { close() } }
        } catch (_: Exception) {
            close()
            null
        }
    }

    private fun markAwaitedResponseAsRetiringRoot(buffer: ByteBuf) {
        val marker = awaitedResponseRootRetiringFalseWireMarker
        val lastStart = buffer.writerIndex() - marker.size
        for (start in buffer.readerIndex()..lastStart) {
            var matches = true
            for (offset in marker.indices) {
                if (buffer.getByte(start + offset) != marker[offset]) {
                    matches = false
                    break
                }
            }
            if (matches) {
                buffer.setByte(
                    start + marker.size - 2,
                    AWAITED_RESPONSE_ROOT_RETIRING_METADATA_TRUE[0].code,
                )
                return
            }
        }
        // Relay protocols share this bounded outbox with RPC but reserve their own terminal JSON
        // shapes. They have no Libp2pRpcStream client completion to coordinate, so their frames do
        // not carry this RPC-only marker and retain their existing close behavior.
    }

    private fun laneConnectionLimit(lane: Lane): Long = when (lane) {
        Lane.NORMAL -> AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PER_CONNECTION
        Lane.PRIORITY -> AWAITED_RESPONSE_OUTBOX_PRIORITY_BYTES_PER_CONNECTION
        Lane.FAILURE, Lane.LONG_POLL_FAILURE -> AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION
        Lane.REFUSAL -> RELAY_REFUSAL_BYTES_PER_CONNECTION
    }

    private fun reserveProcessBytes(lane: Lane, bytes: Long): Boolean = when (lane) {
        Lane.NORMAL -> reserveGlobalBytes(
            awaitedResponseOutboxResponseBytesProcessWide,
            AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PROCESS_WIDE,
            bytes,
        )
        Lane.PRIORITY -> {
            if (!reserveGlobalBytes(
                    awaitedResponseOutboxPriorityBytesProcessWide,
                    AWAITED_RESPONSE_OUTBOX_PRIORITY_BYTES_PROCESS_WIDE,
                    bytes,
                )
            ) {
                false
            } else if (reserveGlobalBytes(
                    awaitedResponseOutboxResponseBytesProcessWide,
                    AWAITED_RESPONSE_OUTBOX_NORMAL_BYTES_PROCESS_WIDE,
                    bytes,
                )
            ) {
                true
            } else {
                val remaining = awaitedResponseOutboxPriorityBytesProcessWide.addAndGet(-bytes)
                check(remaining >= 0L) {
                    "Awaited response outbox process-wide priority accounting became negative " +
                        "while rolling back a combined response reservation"
                }
                false
            }
        }
        Lane.FAILURE -> reserveGlobalBytes(
            awaitedResponseOutboxFailureBytesProcessWide,
            AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PROCESS_WIDE,
            bytes,
        )
        Lane.LONG_POLL_FAILURE -> reserveGlobalBytes(
            awaitedResponseOutboxLongPollFailureBytesProcessWide,
            AWAITED_RESPONSE_OUTBOX_FAILURE_BYTES_PROCESS_WIDE,
            bytes,
        )
        Lane.REFUSAL -> reserveGlobalBytes(
            relayRefusalBytesProcessWide, RELAY_REFUSAL_BYTES_PROCESS_WIDE, bytes,
        )
    }

    private fun releaseLaneBytes(lane: Lane, bytes: Long) {
        if (bytes == 0L) return
        fun release(counter: AtomicLong, description: String) {
            val remaining = counter.addAndGet(-bytes)
            check(remaining >= 0L) {
                "Awaited response outbox process-wide $description accounting became negative " +
                    "after releasing $bytes bytes"
            }
        }
        when (lane) {
            Lane.NORMAL -> release(awaitedResponseOutboxResponseBytesProcessWide, "response")
            Lane.PRIORITY -> {
                release(awaitedResponseOutboxPriorityBytesProcessWide, "priority")
                release(awaitedResponseOutboxResponseBytesProcessWide, "response")
            }
            Lane.FAILURE -> release(awaitedResponseOutboxFailureBytesProcessWide, "failure")
            Lane.LONG_POLL_FAILURE -> release(awaitedResponseOutboxLongPollFailureBytesProcessWide, "long-poll failure")
            Lane.REFUSAL -> release(relayRefusalBytesProcessWide, "relay refusal")
        }
        // Isolation also returns shared completion space without ending a response. Wake
        // requests waiting to reserve that space as well as already-computed response entries.
        if (lane.isFailure) notifyAwaitedResponseFailureCapacityReleased(rootChannel)
        // requestPromotion takes no monitor, so waking another connection cannot form a lock
        // cycle. A resumed failure-lane entry needs the same wake-up as a normal response.
        awaitedResponseOutboxesWithPendingCharges.forEach { it.requestPromotion() }
    }

    private fun notifyObserver(event: String) {
        notifyAwaitedResponseOutboxObserver(
            rootChannel,
            event,
            "Awaited-response outbox observer '$event'",
        )
    }

    internal fun releaseFailureReservation(
        reservation: AwaitedResponseFailureReservation,
    ) {
        var released = false
        withRpcNotificationMonitor(lock) {
            val retained = detachReservedFailureLocked(reservation)
            if (retained != null) {
                releaseIfRetained(retained)
                released = true
            }
        }
        notifyAwaitedResponseFailureCapacityWaiters()
        if (released) {
            notifyObserver("RELEASED:FAILURE_RESERVATION:${reservation.bytes}")
        }
    }

    private fun releaseReservedFailureLocked(
        reservation: AwaitedResponseFailureReservation,
    ) {
        detachReservedFailureLocked(reservation)?.let(::releaseIfRetained)
    }

    private fun detachReservedFailureLocked(
        reservation: AwaitedResponseFailureReservation,
    ): ByteBuf? {
        if (!activeFailureReservations.remove(reservation)) return null
        reservation.invalidate()
        reservation.registeredClosePermit?.releaseByResponse()
        when (reservation.lane) {
            Lane.FAILURE -> failureBytes -= reservation.bytes
            Lane.LONG_POLL_FAILURE -> longPollFailureBytes -= reservation.bytes
            else -> error("A failure reservation cannot own the ${reservation.lane} response budget")
        }
        check(failureBytes >= 0L && longPollFailureBytes >= 0L) {
            "Awaited response outbox failure reservation accounting became negative"
        }
        if (reservation.processWideCharge) {
            releaseLaneBytes(reservation.lane, reservation.bytes)
        }
        notifyAwaitedResponseFailureCapacityReleased(rootChannel)
        return reservation.buffer
    }
}

private fun reserveGlobalBytes(counter: AtomicLong, limit: Long, bytes: Long): Boolean {
    while (true) {
        val current = counter.get()
        if (current > limit - bytes) return false
        if (counter.compareAndSet(current, current + bytes)) return true
    }
}

private fun releaseIfRetained(buffer: ByteBuf) {
    if (buffer.refCnt() > 0) buffer.release()
}

private fun rejectLongPollBeforeDispatch(
    stream: Stream,
    request: Libp2pRpcProtocol.RpcRequest,
    completionPermit: RpcRequestPermit,
) {
    if (request.id.length > AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES) {
        stream.close()
        return
    }
    val channel = streamAsChannel(stream)
    // Install the outbox before allocating the frame so a setup failure retains no buffer.
    val outbox = channel?.let { awaitedResponseOutboxFor(it) }
    val buffer = framedRpcJsonBuffer(Libp2pRpcProtocol.RpcResponse.error(
        request.id,
        LongPollRpcRequestHandler.NOT_STARTED_ERROR_CODE,
        LongPollRpcRequestHandler.NOT_STARTED_ERROR_MESSAGE,
    ).toJson())
    // A valid incoming request can have an ID too large for a failure frame. Never keep
    // an oversized or uncharged refusal, and never mistake stream loss for retry permission.
    if (buffer.readableBytes() > AWAITED_RESPONSE_OUTBOX_PRIORITY_MAX_FRAME_BYTES) {
        releaseIfRetained(buffer)
        stream.close()
        return
    }
    if (channel == null) {
        writeRawStreamBufferOrThrow(stream, buffer)
        return
    }
    val reservation = checkNotNull(outbox).tryReserveFailureSignal(channel, longPoll = true) { buffer }
    if (reservation == null) {
        stream.close()
        return
    }
    try {
        reservation.requestPermit = completionPermit
        outbox.enqueueReservedFailureSignal(channel, reservation)
    } finally {
        reservation.close()
    }
}


/**
 * Writes through a non-Netty [Stream] while retaining the same ownership rule as the channel path:
 * a synchronous failure leaves the original exception visible to the caller and releases the
 * caller-owned buffer exactly once.
 */
private fun writeRawStreamBufferOrThrow(stream: Stream, buffer: ByteBuf): Boolean = try {
    stream.writeAndFlush(buffer)
    true
} catch (failure: Throwable) {
    releaseIfRetained(buffer)
    throw failure
}

/**
 * Closes an RPC root connection, retaining the first close result for all protocol callers.
 * Use this entry point instead of raw Netty close when the result must survive pipeline removal.
 */
fun io.netty.channel.Channel.closeProtocolRoot(
    promise: ChannelPromise = newPromise(),
): io.netty.channel.ChannelFuture {
    require(libp2pRootConnectionChannel(this) === this) {
        "Protocol root close requires a root connection channel, but ${id()} is a child stream"
    }
    require(promise.channel() === this && !promise.isVoid) {
        "Protocol root close for ${id()} requires a pending, non-void promise belonging to that channel; " +
            "received channel=${promise.channel().id()}, void=${promise.isVoid}"
    }
    require(!promise.isDone && promise.setUncancellable()) {
        "Protocol root close for ${id()} requires a pending promise, but the supplied promise is already complete"
    }
    awaitedResponseOutboxFor(this, installHandler = false).closeForProtocol(promise)
    return promise
}

private const val AWAITED_RESPONSE_OUTBOX_ROOT_HANDLER =
    "foundation.url.protocol.awaitedResponseOutboxRoot"

/**
 * Obtains the one outbox for a root connection. Creation and attribute publication are performed
 * under the root channel monitor so two racing substreams cannot create separate outboxes and orphan
 * retained responses.
 */
internal fun awaitedResponseOutboxFor(
    channel: io.netty.channel.Channel,
    installHandler: Boolean = true,
    reconciliationClock: Clock = SystemClock(),
): AwaitedResponseOutbox {
    val root = libp2pRootConnectionChannel(channel)
    val outbox = withRpcNotificationMonitor(root) {
        val rootClockAttribute = root.attr(AWAITED_RESPONSE_RECONCILIATION_CLOCK_ATTR)
        val rootClock = rootClockAttribute.get()
            ?: rootClockAttribute.setIfAbsent(reconciliationClock)
            ?: reconciliationClock
        val attr = root.attr(AWAITED_RESPONSE_OUTBOX_ATTR)
        attr.get() ?: AwaitedResponseOutbox(root, rootClock).also { attr.set(it) }
    }
    if (installHandler) outbox.installRootHandler()
    return outbox
}

private fun installAwaitedResponseOutboxRootHandler(
    root: io.netty.channel.Channel,
    created: AwaitedResponseOutbox,
) {
    val handlerName = AWAITED_RESPONSE_OUTBOX_ROOT_HANDLER
    check(root.pipeline().context(handlerName) == null) {
        "Root connection ${root.id()} already has an awaited-response outbox handler without " +
            "the corresponding channel attribute"
    }
    root.pipeline().addLast(
        handlerName,
        object : ChannelDuplexHandler() {
            override fun channelWritabilityChanged(ctx: ChannelHandlerContext) {
                created.scheduleDrain()
                ctx.fireChannelWritabilityChanged()
            }

            override fun close(ctx: ChannelHandlerContext, promise: ChannelPromise) {
                // Best-effort interception for external Netty callers. Protocol callers use
                // closeProtocolRoot directly, so removing this handler cannot lose their result.
                try { created.closeFromPipeline(ctx, promise) }
                finally { reconcileAwaitedResponseWrites(ctx.channel()) }
            }

            @Suppress("OVERRIDE_DEPRECATION")
            override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
                created.recordTransportFailure(cause)
                ctx.fireExceptionCaught(cause)
            }

            override fun handlerRemoved(ctx: ChannelHandlerContext) {
                reconcileAwaitedResponseWrites(ctx.channel())
            }

            override fun channelInactive(ctx: ChannelHandlerContext) {
                reconcileAwaitedResponseWrites(ctx.channel())
                created.closeAndRelease(
                    RpcResponseDeliveryCloseInitiator.TRANSPORT,
                )
                ctx.fireChannelInactive()
            }
        }
    )
    root.closeFuture().addListener {
        created.closeAndRelease()
    }
}

/** A registration reader must never suspend behind reservations owned by running handlers. */
internal fun tryReserveAwaitedResponseFailureSignal(
    stream: Stream,
    outboxFullSignal: () -> ByteBuf,
): AwaitedResponseFailureReservation? {
    val channel = streamAsChannel(stream) ?: return null
    return awaitedResponseOutboxFor(channel).tryReserveFailureSignal(channel, outboxFullSignal = outboxFullSignal)
}

internal fun tryWriteRelayRefusalWithOutbox(stream: Stream, buffer: ByteBuf): Boolean {
    val channel = streamAsChannel(stream)
    if (channel == null) return writeRawStreamBufferOrThrow(stream, buffer)
    return awaitedResponseOutboxFor(channel).tryEnqueueRelayRefusal(channel, buffer)
}

internal suspend fun reserveAwaitedResponseFailureSignal(
    stream: Stream,
    responseIdentity: AwaitedRpcResponseIdentity? = null,
    longPoll: Boolean = false,
    outboxFullSignal: () -> ByteBuf,
): AwaitedResponseFailureReservation? {
    val channel = streamAsChannel(stream) ?: return null
    val outbox = awaitedResponseOutboxFor(channel)
    while (channel.isOpen && libp2pRootConnectionChannel(channel).isOpen) {
        val candidate = outboxFullSignal()
        val candidateBytes = candidate.readableBytes().toLong()
        val reservation = outbox.tryReserveFailureSignal(
            channel,
            responseIdentity,
            longPoll,
        ) { candidate }
        if (reservation != null) return reservation

        suspendCancellableCoroutine<Unit> { continuation ->
            val waiter = outbox.registerFailureCapacityWaiter(channel) {
                if (continuation.isActive) continuation.resume(Unit)
            }
            continuation.invokeOnCancellation { waiter.close() }
            if (!channel.isOpen || outbox.hasFailureCapacity(channel, candidateBytes, longPoll)) {
                waiter.close()
                if (continuation.isActive) continuation.resume(Unit)
            }
        }
    }
    return null
}

internal fun enqueueRelayRegistrationBoundary(
    stream: Stream,
    buffer: ByteBuf,
    completion: (Throwable?) -> Unit,
) {
    val channel = streamAsChannel(stream)
    if (channel == null) {
        releaseIfRetained(buffer)
        throw IllegalArgumentException("Ordered relay unregister requires a channel-backed registration stream")
    }
    awaitedResponseOutboxFor(channel).enqueueRegistrationBoundary(channel, buffer, completion)
}

internal fun writeAwaitedResponseWithOutbox(
    stream: Stream,
    responseBuffer: ByteBuf,
    failureReservation: AwaitedResponseFailureReservation?,
    completion: ((Throwable?) -> Unit)? = null,
    registeredClose: Boolean = false,
): AwaitedResponseWriteOutcome {
    val channel = streamAsChannel(stream)
    if (channel == null) {
        writeRawStreamBufferOrThrow(stream, responseBuffer)
        completion?.invoke(null)
        return AwaitedResponseWriteOutcome.DELIVERED
    }
    val reservation = checkNotNull(failureReservation) {
        "A channel-backed awaited response cannot execute without a pre-acquired failure reservation"
    }
    return awaitedResponseOutboxFor(channel).writeOrEnqueue(
        channel,
        responseBuffer,
        reservation,
        completion,
        registeredClose,
    )
}

/**
 * Returns the park-budget [Semaphore] for [channel]'s connection, creating it once on first use.
 * Keyed on the root connection channel so every substream of the same connection shares one budget.
 */
private fun parkedWriteBudgetFor(channel: io.netty.channel.Channel): Semaphore {
    val attr = libp2pRootConnectionChannel(channel).attr(PARKED_WRITE_BUDGET_ATTR)
    attr.get()?.let { return it }
    val created = Semaphore(maxConcurrentParkedWritesPerConnection)
    // setIfAbsent returns the previously-set value if another thread won the race, else null.
    return attr.setIfAbsent(created) ?: created
}

/** Healthy handoff queueing does not own a stalled-transport slot. */
internal fun relayCallParkedWriteBudget(stream: Stream?): Semaphore? {
    if (stream == null) return null
    val channel = streamAsChannel(stream) ?: return null
    if (effectiveIsWritable(channel)) return null
    return parkedWriteBudgetFor(channel)
}

/**
 * Returns the in-flight chunked attachment frame counter for [channel], creating it once on first
 * use. Keyed on the substream channel itself: two substreams of one connection are framed
 * independently by the muxer, so a frame on one never conflicts with a write to another.
 */
private fun chunkedAttachmentFrameDepthFor(channel: io.netty.channel.Channel): AtomicInteger {
    val attr = channel.attr(CHUNKED_ATTACHMENT_FRAME_DEPTH_ATTR)
    attr.get()?.let { return it }
    val created = AtomicInteger()
    // setIfAbsent returns the previously-set value if another thread won the race, else null.
    return attr.setIfAbsent(created) ?: created
}

/**
 * Whether a chunked attachment frame currently occupies [channel], so another complete frame
 * written to it now would land inside that frame's body.
 */
private fun chunkedAttachmentFrameInFlight(channel: io.netty.channel.Channel): Boolean =
    (channel.attr(CHUNKED_ATTACHMENT_FRAME_DEPTH_ATTR).get()?.get() ?: 0) > 0

private fun writeHandoffBudgetFor(channel: io.netty.channel.Channel): Semaphore {
    val attr = libp2pRootConnectionChannel(channel).attr(WRITE_HANDOFF_BUDGET_ATTR)
    attr.get()?.let { return it }
    val created = Semaphore(maxConcurrentParkedWritesPerConnection, true)
    return attr.setIfAbsent(created) ?: created
}

private fun smallAwaitedWriteHandoffBudgetFor(channel: io.netty.channel.Channel): Semaphore {
    val attr = libp2pRootConnectionChannel(channel).attr(SMALL_AWAITED_WRITE_HANDOFF_BUDGET_ATTR)
    attr.get()?.let { return it }
    val created = Semaphore(SMALL_AWAITED_HANDOFF_LIMIT, true)
    return attr.setIfAbsent(created) ?: created
}

private fun yamuxChildCompactHandoffBudgetFor(channel: io.netty.channel.Channel): Semaphore? {
    val child = channel as? io.libp2p.etc.util.netty.mux.MuxChannel<*> ?: return null
    if (child.id !is io.libp2p.mux.yamux.YamuxId) return null
    val attr = child.attr(YAMUX_CHILD_COMPACT_HANDOFF_BUDGET_ATTR)
    attr.get()?.let { return it }
    val created = Semaphore(YAMUX_CHILD_COMPACT_HANDOFF_BYTES, true)
    return attr.setIfAbsent(created) ?: created
}

private fun yamuxChildRootHandoffBudgetFor(channel: io.netty.channel.Channel): Semaphore? {
    val child = channel as? io.libp2p.etc.util.netty.mux.MuxChannel<*> ?: return null
    if (child.id !is io.libp2p.mux.yamux.YamuxId) return null
    val attr = child.attr(YAMUX_CHILD_ROOT_HANDOFF_BUDGET_ATTR)
    attr.get()?.let { return it }
    val created = Semaphore(YAMUX_CHILD_ROOT_HANDOFF_LIMIT, true)
    return attr.setIfAbsent(created) ?: created
}

private fun smallAwaitedWriteHandoffUnits(buffer: ByteBuf): Int {
    val readableBytes = buffer.readableBytes().toLong().coerceAtLeast(1L)
    return ((readableBytes + SMALL_AWAITED_HANDOFF_UNIT_BYTES - 1L) /
        SMALL_AWAITED_HANDOFF_UNIT_BYTES).toInt()
}

private fun retainedBufferHandoffUnits(buffer: ByteBuf): Int {
    val retainedBytes = retainedByteBufCapacityBytes(buffer).coerceAtLeast(1L)
    return ((retainedBytes + SMALL_AWAITED_HANDOFF_UNIT_BYTES - 1L) /
        SMALL_AWAITED_HANDOFF_UNIT_BYTES).toInt()
}

private fun compactHandoffLaneHasPendingWrites(channel: io.netty.channel.Channel): Boolean =
    (libp2pRootConnectionChannel(channel).attr(COMMITTED_COMPACT_HANDOFF_UNITS_ATTR).get()?.get() ?: 0) > 0

/**
 * Whether an active child stream can join an already-active bounded compact handoff lane. The root
 * itself may be unwritable: the lane owns the bounded queued bytes, so the child channel's ordinary
 * watermark is not an admission signal while that lane is active. Open/active checks still prevent
 * handing a buffer to a closed or inactive mux path.
 */
private fun compactHandoffChildPathIsWritable(
    channel: io.netty.channel.Channel,
    root: io.netty.channel.Channel,
): Boolean {
    var current: io.netty.channel.Channel? = channel
    while (current != null && current !== root) {
        if (!current.isOpen) return false
        current = current.parent()
    }
    return current === root && root.isOpen && channel.isActive
}

private fun writeHandoffOrderingFor(channel: io.netty.channel.Channel): WriteHandoffOrdering {
    val attr = libp2pRootConnectionChannel(channel).attr(WRITE_HANDOFF_ORDERING_ATTR)
    attr.get()?.let { return it }
    val created = WriteHandoffOrdering()
    return attr.setIfAbsent(created) ?: created
}

/**
 * Returns the retained capacity represented by [buffer]. Derived Netty views such as slices and
 * retained duplicates report only their visible capacity, while [ByteBuf.unwrap] reaches the
 * backing buffer that remains pinned by the view. A [CompositeByteBuf] can retain several such
 * backing buffers despite exposing only a few readable bytes and returning null from `unwrap()`,
 * so its components are walked recursively. Some public Netty factories return opaque
 * multi-segment buffers which are not [CompositeByteBuf] instances and expose no unwrap target.
 * When [ByteBuf.nioBufferCount] reports several segments for such a terminal-looking node, its
 * backing allocations cannot be bounded through the public API; return [Long.MAX_VALUE] so it is
 * conservatively excluded from the compact lane. This walk is only a routing aid: a one-byte NIO
 * slice can still hide a much larger direct [java.nio.ByteBuffer] root from the complete ByteBuf
 * graph. The compact lane's actual memory bound comes from copying each admitted value into
 * exact-size lane-owned storage and immediately releasing the caller buffer. Terminal backing
 * allocations which can be enumerated are counted once by identity, and the visible capacity
 * remains a conservative floor for composites that repeat views of one backing allocation. The
 * identity set also prevents a custom public [ByteBuf] implementation from making this defensive
 * walk loop forever.
 */
private fun retainedByteBufCapacityBytes(buffer: ByteBuf): Long {
    val visited = java.util.Collections.newSetFromMap(
        java.util.IdentityHashMap<ByteBuf, Boolean>()
    )
    val pending = java.util.ArrayDeque<ByteBuf>()
    pending.add(buffer)
    var retainedAllocationCapacity = 0L
    while (pending.isNotEmpty()) {
        val current = pending.removeLast()
        if (!visited.add(current)) continue
        if (current is CompositeByteBuf && current.numComponents() > 0) {
            repeat(current.numComponents()) { index ->
                pending.add(current.component(index))
            }
            continue
        }
        val unwrapped = current.unwrap()
        if (unwrapped != null && unwrapped !== current) {
            pending.add(unwrapped)
            continue
        }
        if (current.nioBufferCount() > 1) {
            return Long.MAX_VALUE
        }
        val capacity = current.capacity().toLong()
        retainedAllocationCapacity = if (Long.MAX_VALUE - retainedAllocationCapacity < capacity) {
            Long.MAX_VALUE
        } else {
            retainedAllocationCapacity + capacity
        }
    }
    return maxOf(buffer.capacity().toLong(), retainedAllocationCapacity)
}

private fun writeHandoffBudgetFor(
    channel: io.netty.channel.Channel,
    compactLaneOwnedCopy: Boolean,
    maxWaitMs: Long,
): Semaphore = if (maxWaitMs > 0L && compactLaneOwnedCopy) {
    smallAwaitedWriteHandoffBudgetFor(channel)
} else {
    writeHandoffBudgetFor(channel)
}

/**
 * Transfers an eligible awaited write into the compact lane's exact-size owned storage.
 *
 * The public writer owns [buffer]. This operation therefore releases it on both success and
 * failure. Once the copy succeeds, no caller wrapper or hidden backing root remains reachable from
 * the compact lane; it retains exactly [ByteBuf.readableBytes] bytes for this entry.
 */
private fun copyIntoCompactLaneAndRelease(buffer: ByteBuf): ByteBuf {
    val readableBytes = buffer.readableBytes()
    val copy = try {
        Unpooled.buffer(readableBytes, readableBytes)
    } catch (failure: Throwable) {
        releaseIfRetained(buffer)
        throw failure
    }
    try {
        copy.writeBytes(buffer, buffer.readerIndex(), readableBytes)
    } catch (failure: Throwable) {
        releaseIfRetained(copy)
        releaseIfRetained(buffer)
        throw failure
    }
    try {
        releaseIfRetained(buffer)
    } catch (failure: Throwable) {
        releaseIfRetained(copy)
        throw failure
    }
    return copy
}

private fun attachmentFrameTurnFor(
    channel: io.netty.channel.Channel
): Libp2pRpcProtocol.AttachmentFrameTurn {
    val attr = libp2pRootConnectionChannel(channel).attr(ATTACHMENT_FRAME_TURN_ATTR)
    attr.get()?.let { return it }
    val created = Libp2pRpcProtocol.AttachmentFrameTurn()
    return attr.setIfAbsent(created) ?: created
}

private fun largeAttachmentWriteTurnFor(stream: Stream): Semaphore? {
    val channel = streamAsChannel(stream) ?: return null
    val attr = libp2pRootConnectionChannel(channel).attr(LARGE_ATTACHMENT_WRITE_TURN_ATTR)
    attr.get()?.let { return it }
    val created = Semaphore(1, true)
    return attr.setIfAbsent(created) ?: created
}

/**
 * Error surfaced by the awaited request/response write path (NettyOutputStream) when a
 * framed write is dropped because the stream/connection stayed unwritable through the
 * backpressure wait. Best-effort writes (gossip) still drop silently; only the awaited
 * path raises this so the caller fast-fails instead of hanging its full invocation timeout.
 */
internal val RPC_WRITE_DROPPED_UNWRITABLE_MESSAGE: String =
    "RPC write dropped: stream/connection unwritable after " +
        "${WRITE_BACKPRESSURE_DELIVERY_WAIT_MS}ms awaited-write delivery wait " +
        "(peer not reading); failing fast instead of leaving the awaiting caller to block its full invocation timeout."

/**
 * Apply [LIBP2P_RPC_WRITE_WATER_MARK] to a mux substream so subsequent
 * [writeFramedBufferWithBackpressure] calls have a meaningful [io.netty.channel.Channel.isWritable]
 * to gate on. Best-effort: if the underlying channel rejects the config (some
 * test channels), fall through silently — the gating still functions, just
 * with Netty's default thresholds.
 */
fun configureWriteBackpressure(stream: Stream) {
    val channel = streamAsChannel(stream) ?: return
    try {
        channel.config().writeBufferWaterMark = LIBP2P_RPC_WRITE_WATER_MARK
    } catch (_: UnsupportedOperationException) {
        // Some channel impls don't allow runtime watermark changes; skip.
    } catch (_: ClassCastException) {
        // Some libp2p versions wrap config() with a type that rejects writeBufferWaterMark setter.
    }
}

/**
 * Best-effort accessor for the underlying Netty [io.netty.channel.Channel] backing
 * a libp2p [Stream].
 *
 * The libp2p Stream interface does not extend Channel; the shipped implementation
 * is `io.libp2p.transport.implementation.StreamOverNetty`, which extends the public
 * `P2PChannelOverNetty` transport base and exposes its typed `nettyChannel` property.
 * Returns null for a non-Netty transport implementation; callers then skip the
 * Netty-specific backpressure gate.
 */
fun streamAsChannel(stream: Stream): io.netty.channel.Channel? {
    if (stream is io.netty.channel.Channel) return stream
    return (stream as? io.libp2p.transport.implementation.P2PChannelOverNetty)?.nettyChannel
}

/**
 * Writes a framed buffer to a Netty [io.netty.channel.Channel] with bounded backpressure.
 *
 * Behavior:
 * - If the channel is writable, calls [io.netty.channel.Channel.writeAndFlush] and returns true.
 * - If the channel is unwritable (its outbound buffer crossed the high water mark),
 *   the function either waits or drops, depending on the calling thread:
 *     - Off the channel's event loop: poll-waits up to [WRITE_BACKPRESSURE_WAIT_MS]
 *       for writability, then either writes or drops with a logged warning.
 *     - On the channel's event loop: drops immediately (blocking the loop would
 *       deadlock — the loop is what drains the outbound buffer).
 *
 * Returns true if the buffer was queued for writing, false if it was dropped
 * (either because the channel was closed, the event loop can't block, or the
 * backpressure wait expired).
 *
 * **Why drop on stall is acceptable here:** without gating, every
 * [io.netty.channel.Channel.writeAndFlush] from a non-event-loop thread enqueues a `WriteTask`
 * on the event loop's `MpscUnboundedArrayQueue` regardless of channel writability,
 * growing without bound until OOM. CN's heap dump from the 2026-04-27 outage
 * showed 982 pending WriteTasks per loop × 2 loops eating 55% of 128MB heap.
 * For gossip and best-effort RPC traffic, dropping a single stalled message is
 * vastly preferable to OOMing the entire process and dropping every concurrent stream.
 */
/**
 * Effective writability of [channel] INCLUDING its parent connection chain.
 *
 * A mux substream is a child Netty [io.netty.channel.Channel] whose writes are encoded and flow
 * straight through to the underlying TCP connection channel ([io.netty.channel.Channel.parent]).
 * The substream's own outbound buffer therefore stays near-empty even while the parent connection's
 * buffer fills, so gating only on the substream's [io.netty.channel.Channel.isWritable] never trips
 * when the *connection* is the thing that has stalled. Production heap dump (kotlin-build-ci OOM,
 * 2026-06-10): a single NioSocketChannel accumulated 310,898 flushed-but-undrained outbound entries
 * (~33 MB pending) while every substream still reported writable.
 *
 * This walks `channel` and its outbound ancestors through the connection; if any is unwritable, the
 * effective answer is false, so backpressure engages on the real bottleneck. An accepted socket's
 * parent is the shared listening [io.netty.channel.ServerChannel], not an outbound transport stage,
 * so traversal stops before that listener. The connection channel uses Netty's default water mark
 * (64 KB high), bounding its outbound buffer near that instead of growing without limit.
 */
internal fun effectiveIsWritable(channel: io.netty.channel.Channel): Boolean {
    var c: io.netty.channel.Channel? = channel
    while (c != null) {
        if (!c.isWritable) return false
        val parent = c.parent()
        if (parent is io.netty.channel.ServerChannel) return true
        c = parent
    }
    return true
}

/**
 * Gives the channel event loop one deterministic turn after an attachment chunk is submitted.
 *
 * Off-loop writers can otherwise submit several chunks before Netty processes the first write and
 * publishes the resulting parent/child writability change. Under concurrent large transfers that
 * lets every producer run past the intended chunk boundary and fill mux queues with data whose
 * readers are deliberately serialized by the attachment-memory budget. The marker is ordered after
 * the preceding write on the same event loop, so returning from this function means the next chunk
 * observes the channel state produced by that write. This waits for scheduler progress, not time.
 */
private fun yieldAttachmentWriterToEventLoop(stream: Stream): Boolean {
    val channel = streamAsChannel(stream) ?: return true
    if (channel.eventLoop().inEventLoop()) return true
    val turn = channel.eventLoop().submit {}
    turn.syncUninterruptibly()
    return turn.isSuccess && channel.isOpen
}

private enum class EventLoopWriteOutcome {
    DELIVERED,
    RETRY,
    FAILED,
}

private data class EventLoopWriteResult(
    val outcome: EventLoopWriteOutcome,
    val remainingWaitMs: Long,
    val failure: Throwable? = null,
)

private fun remainingWriteWaitMs(maxWaitMs: Long, waitStartedAtNanos: Long): Long {
    if (maxWaitMs <= 0L || maxWaitMs == Long.MAX_VALUE) {
        return if (maxWaitMs == Long.MAX_VALUE) Long.MAX_VALUE else 0L
    }
    val maxWaitNanos = TimeUnit.MILLISECONDS.toNanos(maxWaitMs)
    val elapsedNanos = System.nanoTime() - waitStartedAtNanos
    if (elapsedNanos >= maxWaitNanos) return 0L
    return TimeUnit.NANOSECONDS.toMillis(maxWaitNanos - elapsedNanos).coerceAtLeast(1L)
}

/**
 * Submits an admission check and the corresponding write as one event-loop operation. The caller
 * thread must not check admission and then queue the write separately: another large off-loop write
 * can otherwise pass the same stale check before Netty accounts for the first one.
 *
 * A delivered result means this function owns and handed off [buf], a failed result means it
 * released [buf], and a retry result leaves [buf] owned by the caller so it can enter the existing
 * bounded recovery path. In particular, exhausting the local handoff budget is not peer
 * backpressure and must not drop the write before the parked-write semaphore is consulted. The
 * event-loop task itself is deliberately short; if it has started when the handoff wait expires,
 * the caller waits only for that short ownership decision so it never releases a buffer that the
 * event loop might still write. Off-loop handoffs are capped by the per-connection write-handoff
 * budget so a delayed event loop cannot accumulate an unbounded task queue. A zero wait is a
 * distinct non-blocking probe used by relay fan-out: it uses Netty's ordinary thread-safe write
 * handoff directly and holds one permit until that write completes. Only a caller whose original
 * budget was zero may take that probe; [allowZeroWaitAdmission] carries that fact, because a
 * positive budget that has run out also reaches this function as a zero remaining wait and must be
 * refused rather than admitted outside the budget it was charged against.
 */
private fun tryWriteOnEventLoopIf(
    channel: io.netty.channel.Channel,
    buf: ByteBuf,
    maxWaitMs: Long,
    allowZeroWaitAdmission: Boolean,
    compactLaneOwnedCopy: Boolean,
    compactRootReservation: CompactHandoffReservation?,
    admitted: () -> Boolean,
    commitGuard: (() -> Unit) -> Boolean,
    writeBuffer: (ByteBuf) -> io.netty.channel.ChannelFuture,
    onCompactWriteCommitted: (io.netty.channel.ChannelFuture) -> Unit,
): EventLoopWriteResult {
    if (channel.eventLoop().inEventLoop()) {
        if (!channel.isOpen) {
            releaseIfRetained(buf)
            return EventLoopWriteResult(EventLoopWriteOutcome.FAILED, 0L)
        }
        if (!admitted()) return EventLoopWriteResult(EventLoopWriteOutcome.RETRY, maxWaitMs)
        return try {
            if (!commitGuard { writeBuffer(buf) }) {
                return EventLoopWriteResult(EventLoopWriteOutcome.RETRY, maxWaitMs)
            }
            EventLoopWriteResult(EventLoopWriteOutcome.DELIVERED, maxWaitMs)
        } catch (failure: Throwable) {
            // A channel implementation may reject a write synchronously before it creates a
            // failed future. The caller still owns the buffer in that case, so release it here
            // and carry the exact failure back to the common writer path.
            releaseIfRetained(buf)
            EventLoopWriteResult(EventLoopWriteOutcome.FAILED, maxWaitMs, failure)
        }
    }

    if (maxWaitMs == 0L) {
        if (!allowZeroWaitAdmission) {
            // The caller asked for a positive wait and that wait has now run out. The caller still
            // owns the buffer; its recovery path observes the expired deadline and drops it.
            return EventLoopWriteResult(EventLoopWriteOutcome.RETRY, 0L)
        }
        if (!channel.isOpen) {
            releaseIfRetained(buf)
            return EventLoopWriteResult(EventLoopWriteOutcome.FAILED, 0L)
        }
        if (!admitted()) return EventLoopWriteResult(EventLoopWriteOutcome.RETRY, 0L)

        val handoffBudget = writeHandoffBudgetFor(channel)
        if (!handoffBudget.tryAcquire()) {
            return EventLoopWriteResult(EventLoopWriteOutcome.RETRY, 0L)
        }
        try {
            var writeAccepted = false
            val committed = commitGuard {
                writeBuffer(buf).addListener { handoffBudget.release() }
                writeAccepted = true
            }
            if (!committed) {
                handoffBudget.release()
                return EventLoopWriteResult(EventLoopWriteOutcome.RETRY, 0L)
            }
            check(writeAccepted)
            return EventLoopWriteResult(EventLoopWriteOutcome.DELIVERED, 0L)
        } catch (failure: Throwable) {
            handoffBudget.release()
            releaseIfRetained(buf)
            return EventLoopWriteResult(EventLoopWriteOutcome.FAILED, 0L, failure)
        }
    }

    if (compactLaneOwnedCopy) {
        val waitStartedAtNanos = System.nanoTime()
        if (!channel.isOpen) {
            releaseIfRetained(buf)
            return EventLoopWriteResult(EventLoopWriteOutcome.FAILED, 0L)
        }
        if (!admitted()) {
            return EventLoopWriteResult(EventLoopWriteOutcome.RETRY, maxWaitMs)
        }

        // The weighted units account for the exact-size lane-owned copy, including root-stalled
        // successors. Hand it to Netty directly instead of spending the peer-backpressure budget
        // waiting for an event-loop scheduling turn. Re-check after acquiring
        // the permit so an older large write cannot be passed while this caller was contending.
        val reservation = compactRootReservation ?: tryReserveCompactHandoff(
            channel, retainedBufferHandoffUnits(buf),
        ) ?: return EventLoopWriteResult(
            EventLoopWriteOutcome.RETRY,
            remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
        )
        fun releaseUncommittedReservation() {
            // A pre-copy reservation belongs to the outer call across admission retries.
            if (compactRootReservation == null && !reservation.committed.get()) reservation.release()
        }
        if (!channel.isOpen) {
            releaseUncommittedReservation()
            releaseIfRetained(buf)
            return EventLoopWriteResult(EventLoopWriteOutcome.FAILED, 0L)
        }
        if (!admitted()) {
            releaseUncommittedReservation()
            return EventLoopWriteResult(
                EventLoopWriteOutcome.RETRY,
                remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
            )
        }
        return try {
            var writeFuture: io.netty.channel.ChannelFuture? = null
            if (!commitGuard { writeFuture = writeBuffer(buf) }) {
                releaseUncommittedReservation()
                return EventLoopWriteResult(
                    EventLoopWriteOutcome.RETRY,
                    remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
                )
            }
            val committedWrite = checkNotNull(writeFuture)
            reservation.commit(committedWrite)
            onCompactWriteCommitted(committedWrite)
            if (committedWrite.isDone) {
                if (!committedWrite.isSuccess) {
                    // Once writeAndFlush returns a future, Netty owns the buffer and releases it
                    // when submission fails. Do not release that buffer a second time here.
                    return EventLoopWriteResult(
                        EventLoopWriteOutcome.FAILED,
                        remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
                    )
                }
            }
            EventLoopWriteResult(
                EventLoopWriteOutcome.DELIVERED,
                remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
            )
        } catch (failure: Throwable) {
            releaseUncommittedReservation()
            if (!reservation.committed.get()) releaseIfRetained(buf)
            EventLoopWriteResult(
                EventLoopWriteOutcome.FAILED,
                remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
                failure,
            )
        }
    }

    val waitStartedAtNanos = System.nanoTime()
    val state = AtomicReference<Any>(Any())
    val pending = state.get()
    val expired = AtomicBoolean(false)
    val failure = AtomicReference<Throwable?>(null)
    val handoffBudget = writeHandoffBudgetFor(
        channel,
        compactLaneOwnedCopy,
        maxWaitMs,
    )
    if (!handoffBudget.tryAcquire()) {
        return EventLoopWriteResult(
            EventLoopWriteOutcome.RETRY,
            remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
        )
    }
    val handoffBudgetReleased = AtomicBoolean(false)
    fun releaseHandoffBudget() {
        if (handoffBudgetReleased.compareAndSet(false, true)) handoffBudget.release()
    }
    val turn = try {
        channel.eventLoop().submit {
            try {
                if (expired.get()) {
                    state.compareAndSet(pending, EventLoopWriteNotWritable)
                } else if (!channel.isOpen) {
                    if (state.compareAndSet(pending, EventLoopWriteAborted)) releaseIfRetained(buf)
                } else if (!admitted()) {
                    state.compareAndSet(pending, EventLoopWriteNotWritable)
                } else if (expired.get()) {
                    state.compareAndSet(pending, EventLoopWriteNotWritable)
                } else {
                    try {
                        if (commitGuard { writeBuffer(buf) }) {
                            state.compareAndSet(pending, EventLoopWriteDelivered)
                        } else {
                            state.compareAndSet(pending, EventLoopWriteNotWritable)
                        }
                    } catch (writeFailure: Throwable) {
                        failure.set(writeFailure)
                        if (state.compareAndSet(pending, EventLoopWriteAborted)) releaseIfRetained(buf)
                    }
                }
            } finally {
                releaseHandoffBudget()
            }
        }.also { acceptedTurn ->
            // A shutting-down event loop can cancel an accepted task without ever invoking its
            // lambda. The future listener is the terminal-path owner for that case; the atomic
            // guard keeps it one release even when the lambda, cancellation path, or listener race.
            acceptedTurn.addListener { releaseHandoffBudget() }
        }
    } catch (_: Throwable) {
        releaseHandoffBudget()
        return EventLoopWriteResult(
            EventLoopWriteOutcome.RETRY,
            remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
        )
    }

    // The handoff is scheduler progress, not peer progress, but it must remain inside the caller's
    // existing write budget. Do not replace the caller's budget with the ordinary five-second
    // delivery window: attachment chunks deliberately pass Long.MAX_VALUE while a progressing
    // connection may keep the event loop busy for longer than that window. The per-connection permit
    // above prevents a delayed event loop from accumulating more than a bounded number of tasks.
    var interrupted = false
    var completed = false
    try {
        completed = turn.await(maxWaitMs, TimeUnit.MILLISECONDS)
    } catch (_: InterruptedException) {
        interrupted = true
    }
    if (!completed) {
        expired.set(true)
        if (turn.cancel(false)) {
            releaseHandoffBudget()
            state.compareAndSet(pending, EventLoopWriteNotWritable)
        } else {
            // A running event-loop task is the sole owner of the buffer decision. It only performs
            // the non-blocking writability check and write handoff, so finish that ownership step
            // before returning a failure to the caller.
            turn.awaitUninterruptibly()
        }
    }
    if (interrupted) Thread.currentThread().interrupt()

    return when (state.get()) {
        EventLoopWriteDelivered -> EventLoopWriteResult(
            EventLoopWriteOutcome.DELIVERED,
            remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
        )
        EventLoopWriteNotWritable -> EventLoopWriteResult(
            EventLoopWriteOutcome.RETRY,
            remainingWriteWaitMs(maxWaitMs, waitStartedAtNanos),
        )
        EventLoopWriteAborted -> EventLoopWriteResult(
            EventLoopWriteOutcome.FAILED,
            0L,
            failure.get(),
        )
        else -> {
            // A failed future may have been canceled before its submitted lambda began. In that
            // case the lambda's finally block never runs, so close the permit accounting here too.
            releaseHandoffBudget()
            if (turn.isSuccess) {
                // The task completed without publishing a state. Treat that as a failed handoff
                // and release the still-owned buffer rather than allowing a later write to retain it.
                if (state.compareAndSet(pending, EventLoopWriteAborted)) releaseIfRetained(buf)
            } else if (state.compareAndSet(pending, EventLoopWriteAborted)) {
                releaseIfRetained(buf)
            }
            EventLoopWriteResult(EventLoopWriteOutcome.FAILED, 0L)
        }
    }
}

private val EventLoopWriteDelivered = Any()
private val EventLoopWriteNotWritable = Any()
private val EventLoopWriteAborted = Any()

/**
 * Best-effort framed write (2-arg overload, preserved for binary compatibility): waits at most
 * [WRITE_BACKPRESSURE_WAIT_MS] (200ms) for a stalled connection, then drops. Suitable for gossip and
 * other loss-tolerant traffic. AWAITED request/response writers must use the 3-arg overload with
 * [WRITE_BACKPRESSURE_DELIVERY_WAIT_MS] so a transient stall is ridden out and the message delivered
 * rather than dropped (the root cause of the prod 30s/120s RPC hangs).
 */
fun writeFramedBufferWithBackpressure(channel: io.netty.channel.Channel, buf: ByteBuf): Boolean =
    writeFramedBufferWithBackpressure(channel, buf, WRITE_BACKPRESSURE_WAIT_MS)

/**
 * Framed write with an explicit [maxWaitMs] for how long to ride out a transiently-unwritable
 * connection before dropping.
 *
 * Behavior:
 * - Channel closed → release + false.
 * - Writable now → [io.netty.channel.Channel.writeAndFlush] + true.
 * - Unwritable on the event loop → drop (blocking the loop would deadlock the very thread that drains
 *   the outbound buffer).
 * - Unwritable off the event loop → acquire a per-connection park permit and poll-wait up to
 *   [maxWaitMs] for the connection to recover writability. If it recovers, the buffer is written
 *   (delivery-on-transient-recovery — the fix). If the per-connection park budget is exhausted
 *   ([maxConcurrentParkedWritesPerConnection] writes already parked on this connection), the write is
 *   dropped immediately rather than parking another thread (the sustained-backpressure / OOM safety
 *   valve). If the wait expires while still unwritable, the buffer is dropped (the connection is
 *   wedged — fail fast so the awaiting caller fast-fails well within its invocation timeout).
 *
 * Memory is bounded the same way the original 200ms-drop design intended: we only ever
 * [io.netty.channel.Channel.writeAndFlush] while writable (so the event loop's WriteTask queue never
 * grows without bound — the 2026-04-27/06-10 OOM root cause), and at most
 * [maxConcurrentParkedWritesPerConnection] writes (each holding one thread + one [ByteBuf]) park per
 * connection.
 */
fun writeFramedBufferWithBackpressure(
    channel: io.netty.channel.Channel,
    buf: ByteBuf,
    maxWaitMs: Long
): Boolean = writeFramedBufferWithBackpressure(
    channel = channel,
    buf = buf,
    maxWaitMs = maxWaitMs,
    admitBoundedYamuxChildWrites = false
)

/**
 * Relay frames through 256 KiB may use the shared 4 MiB compact handoff lane. Each Yamux child
 * may retain at most 256 KiB of compact bytes; larger frames and frames beyond that child's allowance
 * use the non-copying event-loop handoff. Either lane may enter a flow-controlled Yamux child while
 * its root stays writable; Yamux's connection-wide reservation bounds that queue.
 * Non-Yamux relay writes retain their original 256 KiB compact-lane boundary and strict admission.
 */
internal fun writeRelayBufferWithBackpressure(
    channel: io.netty.channel.Channel,
    buf: ByteBuf,
    maxWaitMs: Long,
    admitBoundedYamuxChildWrites: Boolean = false,
): Boolean = writeFramedBufferWithBackpressure(
    channel = channel,
    buf = buf,
    maxWaitMs = maxWaitMs,
    admitBoundedYamuxChildWrites = admitBoundedYamuxChildWrites,
    schedulerIndependentHandoffMaxFrameBytes = RELAY_COMPACT_HANDOFF_FRAME_BYTES,
)

/**
 * Yamux-specific awaited relay write. The ordinary writer refuses admission whenever any parent
 * connection is unwritable, which is the right default for transports without a connection-wide
 * queue bound. Relay response chunking is different: ten large replies are intentionally in flight
 * on one stream. Yamux may mark only that child unwritable when its protocol send window is exhausted
 * while the TCP root remains healthy, or a recovered root can fill again before every parked writer
 * is scheduled. In either case, bounded awaited frames may enter the Yamux child queue while the
 * root is open and writable. Snapshot-19 Yamux reserves those child writes against its 10 MiB
 * connection-wide budget. Chunked responses have ten response fetches per transfer; other awaited
 * JSON frames are not capped at the 256 KiB compact boundary. The muxer's 10 MiB reservation is the
 * hard memory bound across concurrent relay work. A root that remains unwritable still fails after
 * [maxWaitMs].
 */
internal fun writeAwaitedRelayBufferWithBackpressure(
    stream: Stream,
    buf: ByteBuf,
    maxWaitMs: Long
): Boolean {
    val channel = streamAsChannel(stream)
    if (channel == null) {
        return writeRawStreamBufferOrThrow(stream, buf)
    }
    return writeFramedBufferWithBackpressure(
        channel = channel,
        buf = buf,
        maxWaitMs = maxWaitMs,
        admitBoundedYamuxChildWrites = stream.connection.muxerSession() is io.libp2p.mux.yamux.YamuxHandler,
        schedulerIndependentHandoffMaxFrameBytes = RELAY_COMPACT_HANDOFF_FRAME_BYTES,
    )
}

private fun writeFramedBufferWithBackpressure(
    channel: io.netty.channel.Channel,
    buf: ByteBuf,
    maxWaitMs: Long,
    admitBoundedYamuxChildWrites: Boolean,
    parkedWriteBudgetAlreadyAcquired: Boolean = false,
    schedulerIndependentHandoffMaxFrameBytes: Long = SMALL_AWAITED_HANDOFF_FRAME_BYTES,
    commitGuard: (() -> Unit) -> Boolean = { write -> write(); true },
    completeFrame: Boolean = false,
    nonAdmissionFailure: ((reason: String) -> IOException)? = null,
    writeBuffer: (ByteBuf) -> io.netty.channel.ChannelFuture = { channel.writeAndFlush(it) },
): Boolean = withRpcNotificationScope {
    if (!channel.isOpen) {
        buf.release()
        return false
    }
    val awaitedOffEventLoop = maxWaitMs > 0L && !channel.eventLoop().inEventLoop()
    val retainedBytes = if (awaitedOffEventLoop) retainedByteBufCapacityBytes(buf) else Long.MAX_VALUE
    val fitsCompactLane = retainedBytes <= schedulerIndependentHandoffMaxFrameBytes
    val childBudget = if (fitsCompactLane) yamuxChildCompactHandoffBudgetFor(channel) else null
    val childUnits = if (childBudget != null) buf.readableBytes() else 0
    val childBudgetAcquired = childBudget?.tryAcquire(childUnits) == true
    // Child receive-credit pressure with a writable root must stay on the non-copying handoff.
    // When that same root turned unwritable after a compact handoff began, admit one bounded
    // group of compact copies on the root's weighted lane instead. Charge visible retained capacity
    // conservatively, and keep this extra allowance separate from the ordinary child bytes.
    // Copy every compact admission: a NIO slice can hide a much larger direct backing root.
    val rootStalledChild = childBudget != null && !childBudgetAcquired &&
        !libp2pRootConnectionChannel(channel).isWritable && compactHandoffLaneHasPendingWrites(channel)
    val rootHandoffBudget = if (rootStalledChild) yamuxChildRootHandoffBudgetFor(channel) else null
    val rootHandoffUnits = if (rootHandoffBudget != null) retainedBufferHandoffUnits(buf) else 0
    val rootHandoffAcquired = rootHandoffBudget?.tryAcquire(rootHandoffUnits) == true
    val compactCandidate = fitsCompactLane &&
        (childBudget == null || childBudgetAcquired || rootHandoffAcquired)
    // A Yamux child can keep tiny copied frames pending on receive credit. Reserve the shared
    // units before copying; a healthy sibling can use the bounded non-copying handoff when full.
    // Non-Yamux admission keeps its existing read order and reserves inside the admission check.
    val compactRootReservation = if (compactCandidate && childBudget != null) {
        tryReserveCompactHandoff(channel, smallAwaitedWriteHandoffUnits(buf))
    } else null
    val compactAwaitedWrite = compactCandidate && (childBudget == null || compactRootReservation != null)
    val largeAwaitedWrite = awaitedOffEventLoop && !compactAwaitedWrite
    var compactWriteFuture: io.netty.channel.ChannelFuture? = null
    try {
        val ordering = writeHandoffOrderingFor(channel)
        val ownedBuffer = if (compactAwaitedWrite) {
            copyIntoCompactLaneAndRelease(buf)
        } else {
            buf
        }
        // Framed and multipart writers take framing ownership before registering this marker.
        // An interleaved chunk commits independently and must never make a framing owner wait
        // for its marker while it waits for that owner's lock.
        if (largeAwaitedWrite && !completeFrame) ordering.pendingLargeAwaitedWrites.incrementAndGet()
        return try {
            writeFramedBufferWithBackpressureImpl(
                channel = channel,
                buf = ownedBuffer,
                maxWaitMs = maxWaitMs,
                admitBoundedYamuxChildWrites = admitBoundedYamuxChildWrites,
                parkedWriteBudgetAlreadyAcquired = parkedWriteBudgetAlreadyAcquired,
                ordering = ordering,
                largeAwaitedWrite = largeAwaitedWrite,
                compactLaneOwnedCopy = compactAwaitedWrite,
                compactRootReservation = compactRootReservation,
                commitGuard = commitGuard,
                completeFrame = completeFrame,
                nonAdmissionFailure = nonAdmissionFailure,
                writeBuffer = writeBuffer,
                onCompactWriteCommitted = { compactWriteFuture = it },
            )
        } finally {
            if (largeAwaitedWrite && !completeFrame) ordering.pendingLargeAwaitedWrites.decrementAndGet()
        }
    } finally {
        if (compactRootReservation != null && !compactRootReservation.committed.get()) {
            compactRootReservation.release()
        }
        val reservedBudget = if (childBudgetAcquired) childBudget else if (rootHandoffAcquired) rootHandoffBudget else null
        if (reservedBudget != null) {
            val reservedUnits = if (childBudgetAcquired) childUnits else rootHandoffUnits
            // Until a compact write commits, this call owns the child reservation on every exit.
            // After commit, only the future's completion returns them, exactly like the root units.
            val committedWrite = compactWriteFuture
            val reservedBudgetReleased = AtomicBoolean(false)
            fun releaseReservedBudget() {
                if (reservedBudgetReleased.compareAndSet(false, true)) reservedBudget.release(reservedUnits)
            }
            if (committedWrite == null) {
                releaseReservedBudget()
            } else {
                if (!committedWrite.isDone) committedWrite.addListener { releaseReservedBudget() }
                // Completion may race listener registration, including event-loop shutdown.
                // Return completed reservations here without depending on a later callback turn.
                if (committedWrite.isDone) releaseReservedBudget()
            }
        }
    }
}

private fun writeFramedBufferWithBackpressureImpl(
    channel: io.netty.channel.Channel,
    buf: ByteBuf,
    maxWaitMs: Long,
    admitBoundedYamuxChildWrites: Boolean,
    parkedWriteBudgetAlreadyAcquired: Boolean,
    ordering: WriteHandoffOrdering,
    largeAwaitedWrite: Boolean,
    compactLaneOwnedCopy: Boolean,
    compactRootReservation: CompactHandoffReservation?,
    commitGuard: (() -> Unit) -> Boolean,
    completeFrame: Boolean,
    nonAdmissionFailure: ((reason: String) -> IOException)?,
    writeBuffer: (ByteBuf) -> io.netty.channel.ChannelFuture,
    onCompactWriteCommitted: (io.netty.channel.ChannelFuture) -> Unit,
): Boolean {
    if (!channel.isOpen) {
        buf.release()
        return false
    }
    var remainingWaitMs = maxWaitMs
    // Remaining-wait values below reach zero both for an explicit zero-wait request and for a
    // positive budget that has expired. Only the former may use the non-blocking zero-wait handoff.
    val allowZeroWaitAdmission = maxWaitMs == 0L
    if (effectiveIsWritable(channel) && (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))) {
        val attempt = tryWriteOnEventLoopIf(
            channel,
            buf,
            remainingWaitMs,
            allowZeroWaitAdmission,
            compactLaneOwnedCopy,
            compactRootReservation,
            admitted = {
                effectiveIsWritable(channel) && (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))
            },
            commitGuard = commitGuard,
            writeBuffer = writeBuffer,
            onCompactWriteCommitted = onCompactWriteCommitted,
        )
        remainingWaitMs = attempt.remainingWaitMs
        when (attempt.outcome) {
            EventLoopWriteOutcome.DELIVERED -> return true
            EventLoopWriteOutcome.FAILED -> {
                attempt.failure?.let { throw it }
                return false
            }
            EventLoopWriteOutcome.RETRY -> Unit // Re-check through the bounded recovery path.
        }
    }
    // A relay request window can submit its next compact frame while the previous frame is still a
    // pending off-event-loop handoff. Processing that first handoff may make the physical root
    // unwritable before it publishes completion. Routing the successor into the ordinary 200 ms
    // parked-write path then charges local scheduler progress as peer backpressure. Let the
    // successor join the already-active compact lane instead. It still reserves the lane's weighted
    // units, so the total retained handoff memory stays at 4 MiB; a root
    // that was unwritable before any compact handoff still follows the strict recovery path below.
    val compactRoot = if (compactLaneOwnedCopy) libp2pRootConnectionChannel(channel) else null
    if (
        compactRoot != null &&
        compactHandoffLaneHasPendingWrites(channel) &&
        compactHandoffChildPathIsWritable(channel, compactRoot) &&
        (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))
    ) {
        val attempt = tryWriteOnEventLoopIf(
            channel,
            buf,
            remainingWaitMs,
            allowZeroWaitAdmission,
            compactLaneOwnedCopy,
            compactRootReservation,
            admitted = {
                compactHandoffChildPathIsWritable(channel, compactRoot) &&
                    (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))
            },
            commitGuard = commitGuard,
            writeBuffer = writeBuffer,
            onCompactWriteCommitted = onCompactWriteCommitted,
        )
        remainingWaitMs = attempt.remainingWaitMs
        when (attempt.outcome) {
            EventLoopWriteOutcome.DELIVERED -> return true
            EventLoopWriteOutcome.FAILED -> {
                attempt.failure?.let { throw it }
                return false
            }
            EventLoopWriteOutcome.RETRY -> Unit // The compact lane filled; use normal recovery.
        }
    }
    // Yamux protocol flow control can make only the child stream unwritable while its TCP root is
    // still healthy. Waiting for a root recovery transition in that state can never succeed. The
    // snapshot-19 muxer applies its own 10 MiB connection-wide reservation to queued child writes;
    // ordinary gossip also bounds retained frames per registered peer. Frame length is not a
    // child-flow-control condition: a fixed threshold here would discard a valid gossip frame
    // after its outbox has already counted it as queued.
    val yamuxRootChannel = if (admitBoundedYamuxChildWrites) {
        libp2pRootConnectionChannel(channel)
    } else {
        null
    }
    if (
        yamuxRootChannel != null &&
        yamuxRootChannel.isOpen &&
        yamuxRootChannel.isWritable &&
        (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))
    ) {
        val attempt = tryWriteOnEventLoopIf(
            channel,
            buf,
            remainingWaitMs,
            allowZeroWaitAdmission,
            compactLaneOwnedCopy,
            compactRootReservation,
            admitted = {
                yamuxRootChannel.isOpen &&
                    yamuxRootChannel.isWritable &&
                    (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))
            },
            commitGuard = commitGuard,
            writeBuffer = writeBuffer,
            onCompactWriteCommitted = onCompactWriteCommitted,
        )
        remainingWaitMs = attempt.remainingWaitMs
        when (attempt.outcome) {
            EventLoopWriteOutcome.DELIVERED -> return true
            EventLoopWriteOutcome.FAILED -> {
                attempt.failure?.let { throw it }
                return false
            }
            EventLoopWriteOutcome.RETRY -> Unit // Fall through to the bounded recovery path.
        }
    }
    if (channel.eventLoop().inEventLoop()) {
        val sz = buf.readableBytes()
        buf.release()
        debugLogErr { "[RPC] Dropping ${sz}B outbound: channel (or its connection) unwritable on event-loop thread (cannot block the loop)" }
        nonAdmissionFailure?.let {
            throw it(
                "the outbound channel (or its connection) was unwritable while the write ran on that " +
                    "channel's event-loop thread, which must never block waiting for writability"
            )
        }
        return false
    }
    // Off the event loop and currently unwritable: park (bounded) until the connection recovers.
    val budget = parkedWriteBudgetFor(channel)
    if (!parkedWriteBudgetAlreadyAcquired && !budget.tryAcquire()) {
        // The per-connection park budget is exhausted: more than maxConcurrentParkedWritesPerConnection
        // writes are already parked on this stalled connection. Treat it as sustained backpressure /
        // a wedged peer and drop fast — adding another parked thread + retained buffer is what would
        // eventually exhaust the heap or the RPC handler pool.
        val sz = buf.readableBytes()
        buf.release()
        debugLogErr {
            "[RPC] Dropping ${sz}B outbound: $maxConcurrentParkedWritesPerConnection writes already " +
                "parked on this stalled connection (sustained backpressure); dropping to stay bounded"
        }
        nonAdmissionFailure?.let {
            throw it(
                "all $maxConcurrentParkedWritesPerConnection parked-write permits for this stalled connection " +
                    "were already in use (sustained backpressure)"
            )
        }
        return false
    }
    try {
        // Measure one absolute admission budget on the monotonic clock. A wall-clock deadline can
        // move backward under NTP adjustment and `currentTimeMillis() + Long.MAX_VALUE` overflows
        // into the past, turning the largest valid wait into an immediate false non-admission.
        // TimeUnit performs saturating conversion, while subtraction from one nanoTime origin
        // remains wrap-safe for every practical wait (up to the monotonic clock's ~292-year signed
        // range). Pending-byte progress from older frames on the same multiplexed connection must
        // not restart this frame's budget: callers wait for this admission attempt to finish.
        val waitStartedAtNanos = System.nanoTime()
        val maxWaitNanos = TimeUnit.MILLISECONDS.toNanos(remainingWaitMs)
        val rootChannel = libp2pRootConnectionChannel(channel)
        if (completeFrame) {
            foundation.url.protocol.testing.recordInterleavedWritabilityWait(rootChannel)
            notifyWritabilityWaitEventObserver(
                rootChannel,
                "INTERLEAVED_FRAME_WAITING_FOR_WRITABILITY",
                "waiting-event",
            )
            notifyInterleavedWriteWaitThreadObserver(rootChannel)
        } else {
            recordFramingOwnerWritabilityWait(rootChannel, buf)
        }
        val rootRecoveryState = if (admitBoundedYamuxChildWrites) {
            val attr = rootChannel.attr(RELAY_ROOT_RECOVERY_STATE_ATTR)
            attr.get() ?: RelayRootRecoveryState().let { created -> attr.setIfAbsent(created) ?: created }
        } else {
            null
        }
        rootRecoveryState?.observe(rootChannel.isWritable)
        val recoveryEpochAtStart = rootRecoveryState?.epoch?.get() ?: 0L
        fun rootRecoveredSinceThisWriteStarted(): Boolean {
            if (!admitBoundedYamuxChildWrites) return false
            if (!rootChannel.isOpen) return false
            rootRecoveryState!!.observe(rootChannel.isWritable)
            return rootRecoveryState.epoch.get() != recoveryEpochAtStart
        }
        fun remainingHandoffWaitMs(): Long {
            val remainingNanos = maxWaitNanos - (System.nanoTime() - waitStartedAtNanos)
            if (remainingNanos <= 0L) return 0L
            return TimeUnit.NANOSECONDS.toMillis(remainingNanos).coerceAtLeast(1L)
        }
        fun admittedAfterRecovery(): Boolean {
            if (effectiveIsWritable(channel)) return true
            if (
                rootRecoveryState == null ||
                !rootChannel.isOpen
            ) {
                return false
            }
            rootRecoveryState.observe(rootChannel.isWritable)
            return rootRecoveryState.epoch.get() != recoveryEpochAtStart
        }
        while (channel.isOpen) {
            val nowNanos = System.nanoTime()
            if (nowNanos - waitStartedAtNanos >= maxWaitNanos) break
            val rootRecovered = rootRecoveredSinceThisWriteStarted()
            if (
                (effectiveIsWritable(channel) || rootRecovered) &&
                (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))
            ) {
                val attempt = tryWriteOnEventLoopIf(
                    channel,
                    buf,
                    remainingHandoffWaitMs(),
                    allowZeroWaitAdmission,
                    compactLaneOwnedCopy,
                    compactRootReservation,
                    admitted = {
                        admittedAfterRecovery() && (completeFrame || ordering.allowsAdmission(largeAwaitedWrite))
                    },
                    commitGuard = commitGuard,
                    writeBuffer = writeBuffer,
                    onCompactWriteCommitted = onCompactWriteCommitted,
                )
                when (attempt.outcome) {
                    EventLoopWriteOutcome.DELIVERED -> return true
                    EventLoopWriteOutcome.FAILED -> {
                        attempt.failure?.let { throw it }
                        return false
                    }
                    EventLoopWriteOutcome.RETRY -> Unit // The event loop saw a new stall; continue within this budget.
                }
            }
            try {
                Thread.sleep(WRITE_BACKPRESSURE_POLL_MS)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                buf.release()
                return false
            }
        }
        val sz = buf.readableBytes()
        buf.release()
        debugLogErr { "[RPC] Dropping ${sz}B outbound: channel (or its connection) unwritable after ${maxWaitMs}ms backpressure wait" }
        if (channel.isOpen) {
            nonAdmissionFailure?.let {
                throw it(
                    "the outbound channel (or its connection) stayed unwritable for the whole ${maxWaitMs}ms " +
                        "backpressure wait while the channel remained open (peer not reading)"
                )
            }
        }
        return false
    } finally {
        if (!parkedWriteBudgetAlreadyAcquired) {
            budget.release()
        }
        if (completeFrame) {
            notifyWritabilityWaitEventObserver(
                libp2pRootConnectionChannel(channel),
                "INTERLEAVED_FRAME_WRITABILITY_WAIT_FINISHED",
                "finished-event",
            )
        }
    }
}

/**
 * Writes a length-prefixed JSON message to a libp2p [Stream] with bounded backpressure.
 *
 * Message format: 4-byte big-endian length prefix followed by UTF-8 JSON body.
 * Delegates to [writeFramedBufferWithBackpressure] so the write is gated on
 * channel writability and never accumulates unbounded WriteTasks on the event loop.
 *
 * Returns silently on drop; callers that require delivery confirmation should use
 * the request/response pattern with timeouts (see [Libp2pRpcStream.sendRequest]).
 */
/**
 * Stream-typed convenience overload of [writeFramedBufferWithBackpressure].
 *
 * Casts via [streamAsChannel]. If the cast fails (defensive — every shipped libp2p
 * Stream impl is a Channel), falls back to the raw [Stream.writeAndFlush] path so we
 * never silently drop a write just because the type assertion failed.
 */
fun writeFramedBufferWithBackpressure(stream: Stream, buf: ByteBuf): Boolean =
    writeFramedBufferWithBackpressure(stream, buf, WRITE_BACKPRESSURE_WAIT_MS)

/**
 * Stream-typed overload of [writeFramedBufferWithBackpressure] with an explicit [maxWaitMs]. Awaited
 * request/response writers pass [WRITE_BACKPRESSURE_DELIVERY_WAIT_MS]; best-effort writers pass (or
 * default to) [WRITE_BACKPRESSURE_WAIT_MS].
 */
fun writeFramedBufferWithBackpressure(stream: Stream, buf: ByteBuf, maxWaitMs: Long): Boolean {
    val channel = streamAsChannel(stream)
    if (channel != null) {
        return writeFramedBufferWithBackpressure(channel, buf, maxWaitMs)
    }
    // Fallback: cannot inspect writability, but caller wants the write to happen.
    return writeRawStreamBufferOrThrow(stream, buf)
}

internal fun writeRelayBufferWithBackpressure(
    stream: Stream,
    buf: ByteBuf,
    maxWaitMs: Long,
): Boolean {
    val channel = streamAsChannel(stream)
    if (channel != null) {
        return writeRelayBufferWithBackpressure(
            channel,
            buf,
            maxWaitMs,
            admitBoundedYamuxChildWrites =
                stream.connection.muxerSession() is io.libp2p.mux.yamux.YamuxHandler,
        )
    }
    return writeRawStreamBufferOrThrow(stream, buf)
}

/**
 * Writes a relay request only if the parent can still observe its response at the actual Netty
 * write handoff. Admission can pause reads while the writer waits for writability, so checking
 * before this call is not sufficient.
 */
internal fun writeRelayRequestWhileResponseObservable(
    stream: Stream,
    buf: ByteBuf,
    maxWaitMs: Long,
): Boolean = writeRelayFrameWhileResponseObservable(stream, buf, maxWaitMs, false)

/** Keepalives share Yamux's bounded child queue while still requiring an observable response. */
internal fun writeRelayKeepaliveWhileResponseObservable(
    stream: Stream,
    buf: ByteBuf,
    maxWaitMs: Long,
): Boolean = writeRelayFrameWhileResponseObservable(
    stream, buf, maxWaitMs,
    stream.connection.muxerSession() is io.libp2p.mux.yamux.YamuxHandler,
)

private fun writeRelayFrameWhileResponseObservable(
    stream: Stream,
    buf: ByteBuf,
    maxWaitMs: Long,
    admitBoundedYamuxChildWrites: Boolean,
): Boolean {
    val channel = streamAsChannel(stream)
        ?: return writeRawStreamBufferOrThrow(stream, buf)
    val root = libp2pRootConnectionChannel(channel)
    return writeFramedBufferWithBackpressure(
        channel = channel,
        buf = buf,
        maxWaitMs = maxWaitMs,
        admitBoundedYamuxChildWrites = admitBoundedYamuxChildWrites,
        schedulerIndependentHandoffMaxFrameBytes = RELAY_COMPACT_HANDOFF_FRAME_BYTES,
        commitGuard = { write -> commitIfInboundReadsObservable(root, write) },
    )
}

fun writeRpcMessage(stream: Stream, json: JSONObject) {
    writeRpcMessageReturningDelivered(stream, json)
}

private fun framedRpcJsonBuffer(json: JSONObject): ByteBuf = framedRpcJsonBuffer(jsonWireBytes(json))

private fun framedRpcJsonBuffer(bytes: ByteArray): ByteBuf {
    return Unpooled.buffer(4 + bytes.size).apply {
        writeInt(bytes.size)
        writeBytes(bytes)
    }
}

internal fun awaitedResponseOutboxFullResponse(requestId: String): Libp2pRpcProtocol.RpcResponse =
    Libp2pRpcProtocol.RpcResponse(
        id = requestId,
        error = Libp2pRpcProtocol.RpcError(
            AWAITED_RESPONSE_OUTBOX_FULL_CODE,
            AWAITED_RESPONSE_OUTBOX_FULL_MESSAGE,
        ),
        metadata = mapOf(
            AWAITED_RESPONSE_ROOT_RETIRING_METADATA_KEY to
                AWAITED_RESPONSE_ROOT_RETIRING_METADATA_FALSE,
        ),
    )

/**
 * Like [writeRpcMessage], but returns whether the framed message was actually handed to the
 * channel (`true`) or dropped by [writeFramedBufferWithBackpressure] because the connection was
 * unwritable (`false`).
 *
 * Best-effort writers (gossip) can ignore the result. Awaited request/effect callers must react to
 * `false`; computed responses instead use [writeRpcResponseReturningOutcome], which retains the
 * frame in the bounded connection outbox and cannot silently drop it.
 */
internal fun writeRpcMessageReturningDelivered(stream: Stream, json: JSONObject): Boolean {
    val jsonBytes = jsonWireBytes(json)
    // AWAITED request/effect path: ride out a transient stall rather than dropping at 200ms.
    // The per-stream write lock keeps this single-buffer write from landing BETWEEN the bounded
    // chunks of a concurrent large attachment frame on the same substream (see the chunked path
    // in the attachment-aware overload) — chunked frames are only atomic if every other writer
    // to the stream serializes with them. Uncontended in the common case.
    withRpcFramingLock(stream) {
        val buf = framedRpcJsonBuffer(jsonBytes)
        return writeFramedBufferWithBackpressure(stream, buf, WRITE_BACKPRESSURE_DELIVERY_WAIT_MS)
    }
}

/**
 * A computed RPC response encoded for the wire: the exact bytes of its JSON envelope and its binary
 * attachments, already checked against the frame limits.
 */
internal class EncodedRpcResponse(val jsonBytes: ByteArray, val attachments: List<ByteArray>)

/**
 * Encodes the computed [response] to the request for [method]. Byte arrays become binary
 * attachments when [binaryAttachments] is true (protocol 1.1) and inline base64 otherwise.
 *
 * Everything that turns the result into frame bytes happens here, before anything is written:
 * building the JSON envelope, serializing it to bytes, and checking the attachment limits. A result
 * the wire format cannot carry (for example NaN or an infinity, also inside a primitive array, which
 * JSON rejects; a value that contains itself or is nested too deeply; or more or larger attachments
 * than a frame allows) fails only while it is encoded here. Such a failure becomes an
 * [Libp2pRpcProtocol.ERROR_INTERNAL] error response for that request id, so its caller learns why
 * at once; otherwise nothing would be written for the request, and its caller would wait out its
 * whole response timeout and be told the service may be unresponsive. Attachments collected before
 * the failure are discarded with the failed encoding, so the error frame carries none.
 */
internal suspend fun encodeRpcResponseOrEncodingFailure(
    response: Libp2pRpcProtocol.RpcResponse,
    method: String,
    binaryAttachments: Boolean,
    onEncodingFailure: (suspend (Throwable) -> String?)? = null,
    lease: RpcResponseEncodingLease? = null,
): EncodedRpcResponse {
    return try {
        val encoded = encodeRpcResponse(response, binaryAttachments, lease)
        EncodedRpcResponse(encoded.jsonBytes, encoded.attachments)
    } catch (encodingFailure: Throwable) {
        encodeRpcEncodingFailureReply(response, method, encodingFailure, onEncodingFailure)
    }
}

internal suspend fun encodeRpcEncodingFailureReply(
    response: Libp2pRpcProtocol.RpcResponse,
    method: String,
    encodingFailure: Throwable,
    onEncodingFailure: (suspend (Throwable) -> String?)?,
    defaultReason: (() -> String)? = null,
): EncodedRpcResponse {
    val reason = rpcResponseEncodingFailureReason(encodingFailure, onEncodingFailure) {
        defaultReason?.invoke() ?: run {
            val whatFailed = if (response.error == null) "result" else "error"
            "Internal server error: the $whatFailed returned for '$method' could not be " +
                "encoded for transport: ${rpcEncodingFailureDescription(encodingFailure)}"
        }
    }
    debugLogErr { "[RPC] $reason (request ${response.id})" }
    val errorResponse = Libp2pRpcProtocol.RpcResponse.error(
        response.id, Libp2pRpcProtocol.ERROR_INTERNAL, reason,
    )
    return EncodedRpcResponse(jsonWireBytes(errorResponse.toJson()), emptyList())
}

/**
 * Response-only writer. Unlike awaited requests/effects, a response has already been computed and
 * can be retained without pinning its handler thread. If the bounded response lane is full, the
 * frame waits in the outbox for space (see [AwaitedResponseFailureReservation.awaitResponseAdmission]);
 * only a frame larger than the whole per-connection lane is replaced by the reserved, per-request
 * OUTBOX_FULL response.
 */
internal fun writeRpcResponseReturningOutcome(
    stream: Stream,
    response: Libp2pRpcProtocol.RpcResponse,
    failureReservation: AwaitedResponseFailureReservation?,
): AwaitedResponseWriteOutcome = withRpcNotificationScope {
    val jsonBytes = jsonWireBytes(response.toJson())
    withRpcFramingLock(stream) {
        val responseBuffer = framedRpcJsonBuffer(jsonBytes)
        return writeAwaitedResponseWithOutbox(stream, responseBuffer, failureReservation)
    }
}

/** Hand close failures to the writer until it selects its result, then report later arrivals. */
private class ForwardedOutputCloseFailures(private val root: io.netty.channel.Channel) {
    private val failures = ArrayList<Throwable>()
    private var resultSelected = false

    fun record(failure: Throwable) {
        val late = synchronized(failures) {
            if (resultSelected) true else {
                failures.add(failure)
                false
            }
        }
        if (late) reportLateProtocolRootCloseFailure(root, failure)
    }

    fun selectResult(failure: Throwable?): Throwable? = synchronized(failures) {
        // Selection and recording share the monitor: a failure cannot miss both the returned
        // result and the late report, or mutate a result the writer has already delivered.
        resultSelected = true
        failures.fold(failure, ::combineForwardedCompletionFailures).also { failures.clear() }
    }
}

/** Retire the connection if its child cannot close; deliver or report every close failure. */
private fun retireForwardedOutputConnection(
    channel: io.netty.channel.Channel,
    failures: ForwardedOutputCloseFailures,
    failure: Throwable,
) {
    failures.record(failure)
    val root = libp2pRootConnectionChannel(channel)
    root.close().addListener { closed ->
        if (!closed.isSuccess) {
            failures.record(closed.cause() ?: IOException("Forwarded output connection close failed without a cause"))
            // Channel.close() supplies a root-executor promise. Its listener already runs on
            // that event loop; bypass the failed outbound handler without another task offer.
            val completion = root.newPromise()
            completion.addListener { physicalClose ->
                if (!physicalClose.isSuccess) {
                    // Netty publishes closeFuture before completing this promise. The writer
                    // may already have selected its error, so report a later close failure.
                    reportLateProtocolRootCloseFailure(root, physicalClose.cause() ?: IOException(
                        "Forwarded output root teardown failed without a cause"))
                }
            }
            // Normal unsafe close finishes closeFuture, outbound cleanup, inactive delivery
            // and deregistration. closeForcibly only closes the underlying transport.
            root.unsafe().close(completion)
        }
    }
}

private fun closeForwardedResponseOutput(
    stream: Stream,
    channel: io.netty.channel.Channel,
    failures: ForwardedOutputCloseFailures,
) {
    try {
        stream.close().whenComplete { _, failure ->
            if (failure != null) retireForwardedOutputConnection(channel, failures, failure)
        }
    } catch (failure: Throwable) {
        retireForwardedOutputConnection(channel, failures, failure)
    }
}

/** Wait outside the event loop; child/root teardown settles even a retained physical promise. */
private fun awaitForwardedResponseWrite(
    stream: Stream,
    response: ForwardedStreamingBytecodeResponse,
    write: AwaitedResponseWritePromise,
) {
    val channel = write.channel()
    val result = DefaultChannelPromise(channel, ImmediateEventExecutor.INSTANCE)
    val finished = CountDownLatch(1)
    result.addListener { finished.countDown() }
    mirrorAwaitedResponseWrite(write, result)
    awaitedResponseOutboxFor(channel).observeForwardedWrite(write, result)
    val closeFailures = ForwardedOutputCloseFailures(libp2pRootConnectionChannel(channel))
    val closing = AtomicBoolean()
    val closeOutput = {
        if (closing.compareAndSet(false, true)) closeForwardedResponseOutput(stream, channel, closeFailures)
    }
    val cancellation = response.observeWriterCancellation {
        // Body expiry or explicit close must reach the output even while no body read is active.
        if (!result.isDone) closeOutput()
    }
    try {
        try {
            finished.await()
        } catch (interrupted: InterruptedException) {
            val failure: Throwable = IOException(
                "Interrupted while waiting for a forwarded bytecode response write", interrupted,
            )
            try {
                closeOutput()
                // Stream close is asynchronous. Retain the writer until its physical write settles
                // or its output actually terminates, even if cancellation interrupts us again.
                while (true) {
                    try {
                        finished.await()
                        break
                    } catch (_: InterruptedException) {
                        // The original interruption is propagated below and the flag is restored.
                    }
                }
            } finally {
                Thread.currentThread().interrupt()
            }
            throw checkNotNull(closeFailures.selectResult(failure))
        }
        val failure = if (result.isSuccess) null else result.cause() ?: IOException(
            "Forwarded bytecode response write on child ${channel.id()} did not complete successfully"
        )
        closeFailures.selectResult(failure)?.let { throw it }
    } finally {
        cancellation.close()
    }
}

/**
 * Relays a known-length bytecode attachment from an inbound stream to an attachment-capable
 * libp2p response. The JSON and attachment headers are handed to the channel before this function
 * reads the first body chunk, so backend transfer time is no longer added to outer first-byte time.
 */
internal class ForwardedResponseEncodingFailure(val encodingFailure: Throwable) :
    Exception("Forwarded response could not be encoded before writing", encodingFailure)

internal fun writeForwardedStreamingResponseReturningOutcome(
    stream: Stream,
    responseId: String,
    metadata: Map<String, String>,
    response: ForwardedStreamingBytecodeResponse,
    failureReservation: AwaitedResponseFailureReservation?,
    binaryAttachments: Boolean = true,
    interleaveLargeAttachments: Boolean = false,
    notifyEncodingFailure: Boolean = false,
    encodingLease: RpcResponseEncodingLease? = null,
): AwaitedResponseWriteOutcome = withRpcNotificationScope {
    encodingLease?.begin()
    var outputAttempted = false
    var encodingResponse = false
    var preparationFailure: Throwable? = null
    try {
        response.claimWriter()
        try {
            encodingResponse = true
            val json = response.toResponseJson(responseId, metadata)
            val jsonBytes = jsonWireBytes(json)
            val legacy = if (binaryAttachments) null else forwardedLegacyBodySkeleton(json)
            val legacyLength = legacy?.let {
                it.first.size.toLong() + base64EncodedLength(response.jarLength) + it.second.size
            }
            if (legacyLength != null && (
                    legacyLength > Libp2pRpcProtocol.MAX_JSON_FRAME_BYTES ||
                        checkNotNull(legacy).third + base64EncodedLength(response.jarLength) >
                            Libp2pRpcProtocol.MAX_JSON_STRING_LENGTH
                    )) {
                throw IOException("Forwarded legacy bytecode response requires $legacyLength JSON bytes " +
                    "for ${response.jarLength} attachment bytes, exceeding the legacy JSON limits")
            }
            val totalLength = legacyLength?.plus(4L) ?: (12L + jsonBytes.size + response.jarLength)
            val start = if (binaryAttachments && interleaveLargeAttachments) {
                interleavedResponseStartFrame(json.getString("id"), jsonBytes, intArrayOf(response.jarLength))
            } else null
            encodingLease?.complete(null)
            encodingResponse = false
            val channel = streamAsChannel(stream)
            if (channel != null && channel.eventLoop().inEventLoop()) {
                return awaitedResponseOutboxFor(channel).enqueueReservedOutboxFullSignal(
                    channel, totalLength, checkNotNull(failureReservation),
                )
            }
            val largeWriteTurn = largeAttachmentWriteTurnFor(stream)
            val parkedWriteBudget = channel?.let(::parkedWriteBudgetFor)
            val acquiredTurn = try {
                largeWriteTurn?.let { acquireFramePermit(rpcStreamWriteLock(stream), it) }
                true
            } catch (interrupted: InterruptedException) {
                Thread.currentThread().interrupt()
                false
            }
            val acquiredBudget = acquiredTurn && (parkedWriteBudget?.tryAcquire() ?: true)
            if (!acquiredTurn || !acquiredBudget) {
                if (acquiredTurn) largeWriteTurn?.release()
                if (channel == null || failureReservation == null) {
                    stream.close()
                    failureReservation?.close()
                    return AwaitedResponseWriteOutcome.CONNECTION_CLOSED
                }
                return awaitedResponseOutboxFor(channel).enqueueReservedOutboxFullSignal(
                    channel, totalLength, failureReservation,
                )
            }
            val depth = if (start == null) channel?.let(::chunkedAttachmentFrameDepthFor) else null
            depth?.incrementAndGet()
            try {
                fun writeBuffer(buffer: ByteBuf, completeFrame: Boolean = false): Boolean {
                    // Admission hands off ownership; it does not mean a retained transport write
                    // has completed. Keep this response's writer until each actual chunk finishes.
                    val write = channel?.let(::newAwaitedResponseWritePromise)
                    outputAttempted = true
                    val delivered = writeAttachmentChunkWithReservedBackpressure(
                        stream, buffer, parkedWriteBudget != null, completeFrame = completeFrame,
                        writePromise = write,
                    )
                    if (delivered && write != null) awaitForwardedResponseWrite(stream, response, write)
                    return delivered
                }
                fun readChunk(size: Int): ByteArray {
                    val bytes = ByteArray(size)
                    var offset = 0
                    while (offset < size) {
                        val count = response.jarInput.read(bytes, offset, size - offset)
                        if (count < 0) throw EOFException(
                            "Forwarded bytecode attachment ended with ${size - offset} bytes missing from its next chunk"
                        )
                        offset += count
                    }
                    return bytes
                }
                fun drainTurn(): Boolean {
                    channel?.let {
                        libp2pRootConnectionChannel(it).attr(AWAITED_RESPONSE_OUTBOX_ATTR).get()?.scheduleDrain()
                    }
                    return yieldAttachmentWriterToEventLoop(stream)
                }
                val delivered = if (start != null) {
                    // Body demand is outside framing ownership. Only complete frames enter the writer,
                    // allowing an ordinary response to pass while this backend is waiting for bytes.
                    var complete = writeBuffer(framedRpcJsonBuffer(start), completeFrame = true)
                    if (complete) complete = drainTurn()
                    var offset = 0
                    while (complete && offset < response.jarLength) {
                        val chunk = readChunk(minOf(ATTACHMENT_WRITE_CHUNK_BYTES, response.jarLength - offset))
                        val chunkAttachments = mutableListOf<ByteArray>()
                        val chunkJson = Libp2pRpcProtocol.RpcRequest(
                            id = json.getString("id"),
                            method = Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_CHUNK,
                            params = mapOf("chunk" to chunk),
                        ).toJson(chunkAttachments).apply {
                            put("type", Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_CHUNK)
                            put(Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_INDEX_FIELD, 0)
                            put(Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_OFFSET_FIELD, offset)
                        }
                        val encoded = jsonWireBytes(chunkJson)
                        complete = writeBuffer(Unpooled.buffer(12 + encoded.size + chunk.size).apply {
                            writeInt(encoded.size)
                            writeBytes(encoded)
                            writeInt(1)
                            writeInt(chunk.size)
                            writeBytes(chunk)
                        }, completeFrame = true)
                        offset += chunk.size
                        if (complete) complete = drainTurn()
                    }
                    complete
                } else withRpcFramingLock(stream) {
                    val header = if (legacy == null) {
                        Unpooled.buffer(12 + jsonBytes.size).apply {
                            writeInt(jsonBytes.size)
                            writeBytes(jsonBytes)
                            writeInt(1)
                            writeInt(response.jarLength)
                        }
                    } else {
                        Unpooled.buffer(4 + legacy.first.size).apply {
                            writeInt(checkNotNull(legacyLength).toInt())
                            writeBytes(legacy.first)
                        }
                    }
                    var complete = writeBuffer(header)
                    var remaining = response.jarLength
                    while (complete && remaining > 0) {
                        val chunk = readChunk(minOf(
                            if (legacy == null) ATTACHMENT_WRITE_CHUNK_BYTES else STREAM_CHUNK_RAW_BYTES,
                            remaining,
                        ))
                        remaining -= chunk.size
                        val wireChunk = if (legacy == null) chunk else java.util.Base64.getEncoder().encode(chunk)
                        complete = writeBuffer(Unpooled.wrappedBuffer(wireChunk))
                        if (complete) complete = yieldAttachmentWriterToEventLoop(stream)
                    }
                    if (complete && legacy != null) complete = writeBuffer(Unpooled.wrappedBuffer(legacy.second))
                    complete
                }
                if (delivered) {
                    failureReservation?.close()
                    AwaitedResponseWriteOutcome.DELIVERED
                } else {
                    // A refused write may already have handed bytes to the transport. Closing is valid
                    // both before commitment and after a partial atomic body; appending JSON is not.
                    stream.close()
                    failureReservation?.close()
                    AwaitedResponseWriteOutcome.CONNECTION_CLOSED
                }
            } catch (failure: Throwable) {
                // Retire a partly written stream before releasing framing depth or writer turns:
                // their release can wake another response writer on this same stream.
                if (outputAttempted) {
                    try { stream.close() } catch (closeFailure: Throwable) { failure.addSuppressed(closeFailure) }
                }
                throw failure
            } finally {
                if (depth != null && depth.decrementAndGet() == 0) {
                    libp2pRootConnectionChannel(checkNotNull(channel))
                        .attr(AWAITED_RESPONSE_OUTBOX_ATTR).get()?.scheduleDrain()
                }
                parkedWriteBudget?.release()
                largeWriteTurn?.release()
            }
        } catch (failure: Throwable) {
            if (encodingResponse) preparationFailure = failure
            throw failure
        } finally {
            try {
                response.releaseWriter()
            } catch (closeFailure: Throwable) {
                val original = preparationFailure ?: throw closeFailure
                if (closeFailure !== original) original.addSuppressed(closeFailure)
            }
        }
    } catch (failure: Throwable) {
        encodingLease?.complete(failure)
        if (encodingResponse && notifyEncodingFailure) throw ForwardedResponseEncodingFailure(failure)
        var terminalFailure = failure
        if (!outputAttempted && failure is Exception) {
            try {
                // Preparation has released its backend and writer resources. The normal response
                // outbox retains its reserved failure lane if this framed error cannot be admitted.
                return writeRpcResponseReturningOutcome(
                    stream,
                    Libp2pRpcProtocol.RpcResponse(
                        id = responseId,
                        error = Libp2pRpcProtocol.RpcError(
                            code = "INTERNAL_ERROR",
                            message = "Internal server error: ${failure.javaClass.simpleName}: ${failure.message}",
                        ),
                    ),
                    failureReservation,
                )
            } catch (deliveryFailure: Throwable) {
                if (deliveryFailure is Error) {
                    deliveryFailure.addSuppressed(failure)
                    terminalFailure = deliveryFailure
                } else {
                    failure.addSuppressed(deliveryFailure)
                }
            }
        }
        // A body write was attempted, or the preparation error could not be framed/delivered.
        // Close this stream; never append an error frame inside an already declared body.
        try { stream.close() } catch (closeFailure: Throwable) { terminalFailure.addSuppressed(closeFailure) }
        failureReservation?.close()
        throw terminalFailure
    }
}

/** Exact legacy envelope split around the base64 value, preserving all public result fields. */
private fun forwardedLegacyBodySkeleton(json: JSONObject): Triple<ByteArray, ByteArray, Long> {
    val result = JSONObject(json.getJSONObject("result").toString())
    result.remove("jarBytes")
    val remainingFields = result.toString().removePrefix("{")
    val innerSuffix = "\"," + remainingFields
    val outer = JSONObject(json.toString())
    outer.remove("result")
    val outerFields = outer.toString().removeSuffix("}")
    val innerPrefixBytes = jsonEscapeToBytes("{\"jarBytes\":\"")
    val innerSuffixBytes = jsonEscapeToBytes(innerSuffix)
    val prefix = (outerFields + ",\"result\":\"").toByteArray(StandardCharsets.UTF_8) + innerPrefixBytes
    val suffix = innerSuffixBytes + "\"}".toByteArray(StandardCharsets.UTF_8)
    return Triple(prefix, suffix, innerPrefixBytes.size.toLong() + innerSuffixBytes.size)
}

/**
 * Per-[Stream] outbound write locks for RPC framing. A large attachment frame is written as a
 * SEQUENCE of bounded chunk writes (see the attachment-aware
 * [writeRpcMessageReturningDelivered]); any other frame written to the same substream between
 * two of those chunks would corrupt the wire. All RPC frame writers for a stream therefore
 * serialize on this per-stream lock. Complete interleaved frames acquire it only for
 * enqueue, so writability waits leave compact response admission free. Weak keys: entries vanish with their streams.
 */
private class StreamFrameAdmission {
    val frames = FrameAdmission()
    val closeListenerInstalled = AtomicBoolean(false)
}

private val rpcStreamWriteLocks = WeakIdentityRegistry<Stream, StreamFrameAdmission>()

private fun rpcStreamWriteLock(stream: Stream): FrameAdmission {
    val state = rpcStreamWriteLocks.getOrPut(stream) { StreamFrameAdmission() }
    if (state.closeListenerInstalled.compareAndSet(false, true)) {
        stream.closeFuture().whenComplete { _, _ -> state.frames.close() }
    }
    return state.frames
}

private inline fun <T> withRpcFramingLock(stream: Stream, action: () -> T): T =
    withRpcNotificationScope { rpcStreamWriteLock(stream).withFrame(action) }

/** Nonblocking complete-frame commit guard; admission waits remain outside frame ownership. */
private fun commitCompleteRpcFrame(stream: Stream, write: () -> Unit): Boolean =
    withRpcNotificationScope {
        val admission = rpcStreamWriteLock(stream)
        if (!admission.tryAcquire()) return false
        try {
            write()
            true
        } finally {
            admission.release()
        }
    }

/**
 * Above this total frame size, the attachment-aware writer switches from one aggregate
 * [ByteBuf] to bounded sequential chunk writes. A single aggregate write larger than the
 * connection's 4 MiB awaited-response outbox. Four standard 1 MiB stream-pull attachments each
 * need framing bytes in addition to their payload, so aggregating those responses can reject a
 * completed handler even though the raw payloads total exactly the documented budget. Switching
 * frames above 1 MiB to the existing connection-serialized chunk writer keeps those responses
 * bounded without duplicating every payload in the outbox. It also remains well below the muxer's
 * 10 MiB connection-wide queued-write budget.
 */
internal const val ATTACHMENT_SINGLE_BUFFER_FRAME_LIMIT_BYTES: Int = 1024 * 1024

/**
 * Chunk size for large attachment frames: matches the relay path's established 256 KiB
 * bounded-frame convention and sits far below both the Yamux child send window and the
 * 10 MiB connection budget, so each chunk is individually admissible under backpressure.
 */
internal const val ATTACHMENT_WRITE_CHUNK_BYTES: Int = 256 * 1024

/** Returns null when wrapping a valid legacy envelope would exceed the receiver's JSON limits. */
private fun interleavedResponseStartFrame(
    responseId: String,
    encodedResponseBytes: ByteArray,
    attachmentLengths: IntArray,
): JSONObject? {
    // The start adds fields and JSON-string escaping, so an inner envelope that already fills
    // the compact frame can never fit. Return before constructing the outer string; this avoids
    // a second multi-megabyte JSONObject.quote pass for responses that must use the legacy writer.
    if (4 + encodedResponseBytes.size > ATTACHMENT_SINGLE_BUFFER_FRAME_LIMIT_BYTES) {
        return null
    }
    try {
        Libp2pRpcProtocol.parseValidatedJsonBody(encodedResponseBytes)
    } catch (_: IOException) {
        return null
    }
    val encodedResponse = String(encodedResponseBytes, StandardCharsets.UTF_8)
    val start = JSONObject().apply {
        put("type", Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_START)
        put("id", responseId)
        put(Libp2pRpcProtocol.INTERLEAVED_RESPONSE_JSON_FIELD, encodedResponse)
        put(
            Libp2pRpcProtocol.INTERLEAVED_RESPONSE_LENGTHS_FIELD,
            org.json.JSONArray().apply {
                attachmentLengths.forEach { put(it) }
            },
        )
    }
    val startBytes = jsonWireBytes(start)
    if (4 + startBytes.size > ATTACHMENT_SINGLE_BUFFER_FRAME_LIMIT_BYTES) return null
    return try {
        Libp2pRpcProtocol.parseValidatedJsonBody(startBytes)
        start
    } catch (_: IOException) {
        null
    }
}

/**
 * Writes a large response as a compact start frame followed by bounded complete attachment frames.
 * The per-connection large-write turn still preserves one response's chunk order. Releasing the
 * per-stream lock between complete frames lets the existing priority response outbox run safely;
 * no bytes from another response can land inside one chunk frame.
 */
private fun writeInterleavedRpcResponseReturningDelivered(
    stream: Stream,
    start: JSONObject,
    attachments: List<ByteArray>,
    parkedWriteBudgetAlreadyAcquired: Boolean,
): Boolean {
    val responseId = start.getString("id")
    val startBuffer = framedRpcJsonBuffer(start)
    val startDelivered = writeAttachmentChunkWithReservedBackpressure(
        stream,
        startBuffer,
        parkedWriteBudgetAlreadyAcquired,
        completeFrame = true,
    )
    if (!startDelivered) return false

    fun scheduleExistingResponseDrain() {
        val channel = streamAsChannel(stream) ?: return
        libp2pRootConnectionChannel(channel)
            .attr(AWAITED_RESPONSE_OUTBOX_ATTR)
            .get()
            ?.scheduleDrain()
    }

    scheduleExistingResponseDrain()

    for ((attachmentIndex, attachment) in attachments.withIndex()) {
        var offset = 0
        while (offset < attachment.size) {
            val chunkLength = minOf(ATTACHMENT_WRITE_CHUNK_BYTES, attachment.size - offset)
            val chunk = attachment.copyOfRange(offset, offset + chunkLength)
            val chunkAttachments = mutableListOf<ByteArray>()
            val chunkJson = Libp2pRpcProtocol.RpcRequest(
                id = responseId,
                method = Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_CHUNK,
                params = mapOf("chunk" to chunk),
            ).toJson(chunkAttachments).apply {
                put("type", Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_CHUNK)
                put(
                    Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_INDEX_FIELD,
                    attachmentIndex,
                )
                put(Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_OFFSET_FIELD, offset)
            }
            check(chunkAttachments.size == 1) {
                "An interleaved response chunk must encode exactly one binary attachment"
            }
            val jsonBytes = chunkJson.toString().toByteArray(StandardCharsets.UTF_8)
            val frameLength = 12 + jsonBytes.size + chunkLength
            val frame = Unpooled.buffer(frameLength).apply {
                writeInt(jsonBytes.size)
                writeBytes(jsonBytes)
                writeInt(1)
                writeInt(chunkLength)
                writeBytes(chunk)
            }
            val delivered = writeAttachmentChunkWithReservedBackpressure(
                stream,
                frame,
                parkedWriteBudgetAlreadyAcquired,
                completeFrame = true,
            )
            if (!delivered) return false

            offset += chunkLength
            // Any compact response already queued on this connection receives a drain turn before
            // this writer begins another complete chunk frame. The marker is scheduler ordering,
            // not a time budget.
            scheduleExistingResponseDrain()
            if (!yieldAttachmentWriterToEventLoop(stream)) return false
        }
    }
    return true
}

/**
 * Attachment-aware counterpart to [writeRpcMessageReturningDelivered]. The JSON envelope is
 * copied into one bounded Netty buffer followed by the existing 1.1 attachment framing; the
 * attachment byte arrays themselves are never base64-encoded or copied into an intermediate
 * aggregate heap array.
 */
internal fun writeRpcMessageReturningDelivered(
    stream: Stream,
    json: JSONObject,
    attachments: List<ByteArray>,
    largeWriteTurnAlreadyAcquired: Boolean = false,
    parkedWriteBudgetAlreadyAcquired: Boolean = false,
    closeStreamOnFailure: Boolean = true,
): Boolean = writeEncodedRpcMessageReturningDelivered(
    stream,
    jsonWireBytes(json),
    attachments,
    largeWriteTurnAlreadyAcquired,
    parkedWriteBudgetAlreadyAcquired,
    closeStreamOnFailure,
)

private fun firstUnwritableOutboundCapacity(channel: io.netty.channel.Channel): Long? {
    var current: io.netty.channel.Channel? = channel
    while (current != null && current !is io.netty.channel.ServerChannel) {
        if (!current.isWritable) return current.config().writeBufferHighWaterMark.toLong()
        current = current.parent()
    }
    return null
}

private fun rpcFrameNonAdmissionFailure(
    stream: Stream,
    channel: io.netty.channel.Channel?,
    frameSizeBytes: Long,
): ((reason: String) -> IOException)? = channel?.let {
    { reason ->
        RpcFrameNotAdmittedException(
            frameSizeBytes,
            firstUnwritableOutboundCapacity(it),
            reason,
            stream.remotePeerId().toBase58(),
        )
    }
}

private fun writeWholeRpcFrame(
    stream: Stream,
    channel: io.netty.channel.Channel?,
    buffer: ByteBuf,
    nonAdmissionFailure: ((reason: String) -> IOException)?,
): Boolean {
    if (channel == null) return writeRawStreamBufferOrThrow(stream, buffer)
    return writeFramedBufferWithBackpressure(
        channel, buffer, WRITE_BACKPRESSURE_DELIVERY_WAIT_MS,
        admitBoundedYamuxChildWrites = false,
        nonAdmissionFailure = nonAdmissionFailure,
    )
}

// JSONString and other caller values must finish encoding before the caller takes output ownership.
// Keep attachment references here; the existing writer below bounds each materialized wire chunk.
private fun writeEncodedRpcMessageReturningDelivered(
    stream: Stream,
    jsonBytes: ByteArray,
    attachments: List<ByteArray>,
    largeWriteTurnAlreadyAcquired: Boolean = false,
    parkedWriteBudgetAlreadyAcquired: Boolean = false,
    closeStreamOnFailure: Boolean = true,
    reportNonAdmission: Boolean = false,
): Boolean = withRpcNotificationScope {
    if (attachments.size > 1_000) {
        throw IOException(
            "RPC message has ${attachments.size} binary attachments, exceeding the protocol limit of 1000"
        )
    }
    attachments.forEachIndexed { index, attachment ->
        if (attachment.size > 100_000_000) {
            throw IOException(
                "RPC binary attachment $index is ${attachment.size} bytes, exceeding the protocol " +
                    "limit of 100000000 bytes"
            )
        }
    }

    val frameSize = attachments.fold(4L + jsonBytes.size + if (attachments.isEmpty()) 0L else 4L) {
        size, attachment -> size + 4L + attachment.size
    }
    val channel = streamAsChannel(stream)
    val nonAdmissionFailure = if (reportNonAdmission) {
        rpcFrameNonAdmissionFailure(stream, channel, frameSize)
    } else null
    if (attachments.isEmpty()) {
        withRpcFramingLock(stream) {
            return writeWholeRpcFrame(stream, channel, framedRpcJsonBuffer(jsonBytes), nonAdmissionFailure)
        }
    }

    val totalLength = attachments.fold(8L + jsonBytes.size.toLong()) { total, attachment ->
        total + 4L + attachment.size.toLong()
    }
    if (totalLength > Int.MAX_VALUE.toLong()) {
        throw IOException(
            "RPC message with ${attachments.size} binary attachments is too large to buffer: " +
                "$totalLength bytes exceeds the JVM ByteBuf limit ${Int.MAX_VALUE}"
        )
    }

    if (totalLength <= ATTACHMENT_SINGLE_BUFFER_FRAME_LIMIT_BYTES) {
        // Small frame: one aggregate buffer, atomic on the wire by construction. Still takes
        // the per-stream lock so it cannot land between a concurrent large frame's chunks.
        withRpcFramingLock(stream) {
            val buf = Unpooled.buffer(totalLength.toInt())
            var handedToWriter = false
            try {
                buf.writeInt(jsonBytes.size)
                buf.writeBytes(jsonBytes)
                buf.writeInt(attachments.size)
                for (attachment in attachments) {
                    buf.writeInt(attachment.size)
                    buf.writeBytes(attachment)
                }
                handedToWriter = true
                return writeWholeRpcFrame(stream, channel, buf, nonAdmissionFailure)
            } finally {
                if (!handedToWriter) buf.release()
            }
        }
    }

    // Large frame: a single aggregate write larger than the muxer's connection-wide
    // queued-write budget can never be admitted (see
    // ATTACHMENT_SINGLE_BUFFER_FRAME_LIMIT_BYTES), and it would also duplicate the whole
    // payload in heap. Write the framing headers followed by bounded zero-copy slices of the
    // attachment arrays, each individually admitted under backpressure. The per-stream lock
    // makes the chunk sequence atomic with respect to every other RPC frame writer, and the
    // in-flight marker below makes it atomic with respect to the one writer that cannot take that
    // lock — the awaited-response outbox drain, which runs on the connection event loop. A chunk
    // that cannot be delivered leaves the wire mid-frame with no safe resync point, so the
    // stream is closed before reporting the drop.
    val largeWriteTurn = largeAttachmentWriteTurnFor(stream)
    if (!largeWriteTurnAlreadyAcquired) {
        try {
            largeWriteTurn?.let { acquireFramePermit(rpcStreamWriteLock(stream), it) }
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            return false
        }
    }
    val frameChannel = streamAsChannel(stream)
    val frameDepth = frameChannel?.let(::chunkedAttachmentFrameDepthFor)
    frameDepth?.incrementAndGet()
    var frameStarted = false
    var restoreInterrupt = false
    try {
        withRpcFramingLock(stream) {
            fun writeChunk(createBuffer: () -> ByteBuf): Boolean {
                try {
                    while (true) {
                        if (writeAttachmentChunkWithReservedBackpressure(
                                stream,
                                createBuffer(),
                                parkedWriteBudgetAlreadyAcquired,
                                nonAdmissionFailure = if (frameStarted) null else nonAdmissionFailure,
                            )
                        ) {
                            frameStarted = true
                            return true
                        }
                        if (!frameStarted) return false
                        val channelStillOpen = streamAsChannel(stream)?.isOpen ?: false
                        if (channelStillOpen && Thread.interrupted()) {
                            // Once the JSON header has reached the peer, abandoning the remaining
                            // attachment bytes would leave it inside that frame with no resync point.
                            // Finish the already-started frame, then restore the interruption marker.
                            restoreInterrupt = true
                            continue
                        }
                        return false
                    }
                } catch (failure: RpcFrameNotAdmittedException) {
                    if (closeStreamOnFailure) stream.close()
                    throw failure
                }
            }

            if (!writeChunk {
                    Unpooled.buffer(8 + jsonBytes.size).apply {
                        writeInt(jsonBytes.size)
                        writeBytes(jsonBytes)
                        writeInt(attachments.size)
                    }
                }
            ) {
                if (closeStreamOnFailure) stream.close()
                return false
            }
            for (attachment in attachments) {
                if (!writeChunk {
                        Unpooled.buffer(4).apply { writeInt(attachment.size) }
                    }
                ) {
                    if (closeStreamOnFailure) stream.close()
                    return false
                }
                var offset = 0
                while (offset < attachment.size) {
                    val chunkLength = minOf(ATTACHMENT_WRITE_CHUNK_BYTES, attachment.size - offset)
                    if (!writeChunk {
                            Unpooled.wrappedBuffer(attachment, offset, chunkLength)
                        }
                    ) {
                        if (closeStreamOnFailure) stream.close()
                        return false
                    }
                    if (!yieldAttachmentWriterToEventLoop(stream)) {
                        if (closeStreamOnFailure) stream.close()
                        return false
                    }
                    offset += chunkLength
                }
            }
            return true
        }
    } finally {
        if (restoreInterrupt) Thread.currentThread().interrupt()
        // The substream is free again, so the responses this frame deferred must be woken. Reading
        // the outbox without creating one keeps a connection that never queued a response free of
        // outbox state.
        if (frameDepth != null && frameDepth.decrementAndGet() == 0 && frameChannel != null) {
            libp2pRootConnectionChannel(frameChannel)
                .attr(AWAITED_RESPONSE_OUTBOX_ATTR)
                .get()
                ?.scheduleDrain()
        }
        if (!largeWriteTurnAlreadyAcquired) {
            largeWriteTurn?.release()
        }
    }
}

private fun writeAttachmentChunkWithReservedBackpressure(
    stream: Stream,
    buffer: ByteBuf,
    parkedWriteBudgetAlreadyAcquired: Boolean,
    completeFrame: Boolean = false,
    nonAdmissionFailure: ((reason: String) -> IOException)? = null,
    writePromise: ChannelPromise? = null,
): Boolean {
    val completeFrameLock = if (completeFrame) rpcStreamWriteLock(stream) else null
    val channel = streamAsChannel(stream)
    if (channel == null) {
        return if (completeFrameLock == null) {
            writeRawStreamBufferOrThrow(stream, buffer)
        } else {
            var admitted = false
            try {
                withRpcFramingLock(stream) {
                    admitted = true
                    writeRawStreamBufferOrThrow(stream, buffer)
                }
            } finally {
                if (!admitted) releaseIfRetained(buffer)
            }
        }
    }
    return writeFramedBufferWithBackpressure(
        channel = channel,
        buf = buffer,
        maxWaitMs = ATTACHMENT_WRITE_BACKPRESSURE_WAIT_MS,
        admitBoundedYamuxChildWrites = false,
        parkedWriteBudgetAlreadyAcquired = parkedWriteBudgetAlreadyAcquired,
        completeFrame = completeFrame,
        nonAdmissionFailure = nonAdmissionFailure,
        writeBuffer = { bytes ->
            if (writePromise == null) channel.writeAndFlush(bytes)
            else channel.writeAndFlush(bytes, writePromise)
        },
        commitGuard = { write ->
            if (completeFrame) {
                commitCompleteRpcFrame(stream, write)
            } else {
                // Legacy multipart writers own framing across the entire sequence.
                write()
                true
            }
        },
    )
}

internal fun writeRpcResponseReturningOutcome(
    stream: Stream,
    responseId: String,
    json: JSONObject,
    attachments: List<ByteArray>,
    failureReservation: AwaitedResponseFailureReservation?,
    interleaveLargeAttachments: Boolean = false,
): AwaitedResponseWriteOutcome = withRpcNotificationScope {
    writeRpcResponseReturningOutcome(
        stream,
        responseId,
        jsonWireBytes(json),
        attachments,
        failureReservation,
        interleaveLargeAttachments,
    )
}

/**
 * The attachment frame limits a response must satisfy. Returns the frame's total length, or throws
 * an [IOException] naming the limit it exceeds.
 */
internal fun checkRpcAttachmentFrameLimits(jsonBytes: ByteArray, attachments: List<ByteArray>): Long {
    if (attachments.size > 1_000) {
        throw IOException(
            "RPC message has ${attachments.size} binary attachments, exceeding the protocol limit of 1000"
        )
    }
    attachments.forEachIndexed { index, attachment ->
        if (attachment.size > 100_000_000) {
            throw IOException(
                "RPC binary attachment $index is ${attachment.size} bytes, exceeding the protocol " +
                    "limit of 100000000 bytes"
            )
        }
    }
    val totalLength = attachments.fold(8L + jsonBytes.size.toLong()) { total, attachment ->
        total + 4L + attachment.size.toLong()
    }
    if (totalLength > Int.MAX_VALUE.toLong()) {
        throw IOException(
            "RPC message with ${attachments.size} binary attachments is too large to buffer: " +
                "$totalLength bytes exceeds the JVM ByteBuf limit ${Int.MAX_VALUE}"
        )
    }
    return totalLength
}

/**
 * Like the [JSONObject] overload, but for a response whose JSON envelope is already [jsonBytes].
 * (It keeps the overload's name: tests locate the production response writer by this stack frame.)
 */
internal fun writeRpcResponseReturningOutcome(
    stream: Stream,
    responseId: String,
    jsonBytes: ByteArray,
    attachments: List<ByteArray>,
    failureReservation: AwaitedResponseFailureReservation?,
    interleaveLargeAttachments: Boolean = false,
): AwaitedResponseWriteOutcome = withRpcNotificationScope {
    if (attachments.isEmpty()) {
        withRpcFramingLock(stream) {
            val responseBuffer = framedRpcJsonBuffer(jsonBytes)
            return writeAwaitedResponseWithOutbox(
                stream,
                responseBuffer,
                failureReservation,
            )
        }
    }
    val totalLength = checkRpcAttachmentFrameLimits(jsonBytes, attachments)

    if (totalLength <= ATTACHMENT_SINGLE_BUFFER_FRAME_LIMIT_BYTES) {
        withRpcFramingLock(stream) {
            val responseBuffer = Unpooled.buffer(totalLength.toInt())
            var handedToOutbox = false
            try {
                responseBuffer.writeInt(jsonBytes.size)
                responseBuffer.writeBytes(jsonBytes)
                responseBuffer.writeInt(attachments.size)
                for (attachment in attachments) {
                    responseBuffer.writeInt(attachment.size)
                    responseBuffer.writeBytes(attachment)
                }
                handedToOutbox = true
                return writeAwaitedResponseWithOutbox(
                    stream,
                    responseBuffer,
                    failureReservation,
                )
            } finally {
                if (!handedToOutbox) releaseIfRetained(responseBuffer)
            }
        }
    }

    val channel = streamAsChannel(stream)
    if (
        channel != null &&
        channel.eventLoop().inEventLoop()
    ) {
        return awaitedResponseOutboxFor(channel).enqueueReservedOutboxFullSignal(
            channel,
            totalLength,
            checkNotNull(failureReservation) {
                "An oversized channel-backed response cannot execute without a pre-acquired " +
                    "failure reservation"
            },
        )
    }
    val largeWriteTurn = largeAttachmentWriteTurnFor(stream)
    val parkedWriteBudget = channel?.let(::parkedWriteBudgetFor)
    val acquiredLargeWriteTurn = try {
        largeWriteTurn?.let { acquireFramePermit(rpcStreamWriteLock(stream), it) }
        true
    } catch (interrupted: InterruptedException) {
        Thread.currentThread().interrupt()
        false
    }
    val acquiredParkedWriteBudget =
        acquiredLargeWriteTurn && (parkedWriteBudget?.tryAcquire() ?: true)
    if (!acquiredLargeWriteTurn || !acquiredParkedWriteBudget) {
        if (acquiredLargeWriteTurn) {
            largeWriteTurn?.release()
        }
        return checkNotNull(channel) {
            "A non-channel response cannot have a bounded large-write admission conflict"
        }.let { responseChannel ->
            awaitedResponseOutboxFor(responseChannel).enqueueReservedOutboxFullSignal(
                responseChannel,
                totalLength,
                checkNotNull(failureReservation) {
                    "An oversized channel-backed response cannot execute without a pre-acquired " +
                        "failure reservation"
                },
            )
        }
    }
    val interleavedStart = if (interleaveLargeAttachments) {
        interleavedResponseStartFrame(responseId, jsonBytes, attachments.map { it.size }.toIntArray())
    } else {
        null
    }
    val delivered = try {
        if (interleavedStart != null) {
            writeInterleavedRpcResponseReturningDelivered(
                stream,
                interleavedStart,
                attachments,
                parkedWriteBudgetAlreadyAcquired = parkedWriteBudget != null,
            )
        } else {
            writeEncodedRpcMessageReturningDelivered(
                stream,
                jsonBytes,
                attachments,
                largeWriteTurnAlreadyAcquired = largeWriteTurn != null,
                parkedWriteBudgetAlreadyAcquired = parkedWriteBudget != null,
                closeStreamOnFailure = false,
            )
        }
    } finally {
        parkedWriteBudget?.release()
        largeWriteTurn?.release()
    }
    return if (delivered) {
        failureReservation?.close()
        AwaitedResponseWriteOutcome.DELIVERED
    } else {
        if (channel == null || failureReservation == null) {
            stream.close()
            failureReservation?.close()
            AwaitedResponseWriteOutcome.CONNECTION_CLOSED
        } else {
            awaitedResponseOutboxFor(channel).sendReservedFailureThenClose(
                channel,
                failureReservation,
            )
        }
    }
}

/**
 * Writes a [StreamingBytecodeResponse] to a libp2p [Stream] without the
 * `RpcResponse.toJson().toString().toByteArray()` chain that materializes the
 * payload ~5× in heap.
 *
 * The 4-byte length prefix is already embedded by
 * [writeStreamingBytecodeResponse]; this function streams the entire framed
 * message (prefix + body) into a single Netty [ByteBuf] using bounded base64
 * chunks, then hands it to [writeFramedBufferWithBackpressure] for backpressure-
 * gated delivery. The ByteBuf is sized exactly via [streamingBytecodeBodyLength]
 * so it neither over-allocates nor reallocates. Peak heap is roughly
 * `jarBytes.size` (held by the caller) + the framed ByteBuf, skipping the three
 * intermediate Strings entirely.
 */
fun writeStreamingBytecodeMessage(stream: Stream, response: StreamingBytecodeResponse) {
    writeStreamingBytecodeMessageReturningDelivered(stream, response)
}

private fun framedStreamingBytecodeBuffer(response: StreamingBytecodeResponse): ByteBuf {
    val bodyLen = streamingBytecodeBodyLength(response)
    val totalLen = 4L + bodyLen
    val buffer = Unpooled.buffer(totalLen.toInt())
    val out = object : OutputStream() {
        override fun write(b: Int) {
            buffer.writeByte(b)
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            buffer.writeBytes(b, off, len)
        }

        override fun flush() {}
    }
    try {
        writeStreamingBytecodeResponse(out, response)
        return buffer
    } catch (failure: Throwable) {
        releaseIfRetained(buffer)
        throw failure
    }
}

/**
 * Like [writeStreamingBytecodeMessage], but returns whether the framed message was handed to the
 * channel (`true`) or dropped because the connection was unwritable (`false`). See
 * [writeRpcMessageReturningDelivered] for why an awaited-response writer must react to a drop.
 */
internal fun writeStreamingBytecodeMessageReturningDelivered(stream: Stream, response: StreamingBytecodeResponse): Boolean {
    // AWAITED streaming-bytecode response: deliver-on-recovery, not 200ms-drop.
    // Keep the complete frame under the same per-stream lock as chunked attachment writes so a
    // streaming-bytecode frame cannot land between an attachment header and one of its chunks.
    withRpcFramingLock(stream) {
        val buffer = framedStreamingBytecodeBuffer(response)
        return writeFramedBufferWithBackpressure(
            stream,
            buffer,
            WRITE_BACKPRESSURE_DELIVERY_WAIT_MS,
        )
    }
}

internal fun writeStreamingBytecodeResponseReturningOutcome(
    stream: Stream,
    response: StreamingBytecodeResponse,
    failureReservation: AwaitedResponseFailureReservation?,
): AwaitedResponseWriteOutcome {
    withRpcFramingLock(stream) {
        val responseBuffer = framedStreamingBytecodeBuffer(response)
        return writeAwaitedResponseWithOutbox(
            stream,
            responseBuffer,
            failureReservation,
        )
    }
}

/**
 * Shared [java.security.SecureRandom] used to seed Ed25519 key generation for
 * random host identities. The no-argument `SecureRandom()` constructor selects
 * the highest-priority platform/provider default, and the API permits
 * `nextBytes` to block while gathering entropy. The ordinary SUN Linux default
 * is `NativePRNG`, whose `nextBytes` path reads `/dev/urandom`, but provider or
 * platform configuration can select a different implementation. Host startup
 * must not inherit an environment-dependent multi-second entropy wait.
 *
 * Prefer `NativePRNGNonBlocking`, which reads only `/dev/urandom`. On any
 * booted system `/dev/urandom` is cryptographically equivalent to
 * `/dev/random`, so this is not a security downgrade. Platforms without that
 * Unix-specific algorithm fall back to the JVM default
 * [java.security.SecureRandom]. That fallback is non-blocking in practice on
 * Windows and macOS, but the API specification does not guarantee it. The lazy
 * shared instance retains the eager one-byte seed so initialization happens
 * once and subsequent host identities reuse a pre-seeded, thread-safe generator.
 *
 * Thread-safety: [java.security.SecureRandom] is documented as thread-safe.
 */
private val sharedKeyGenSecureRandom: java.security.SecureRandom by lazy {
    val secureRandom = try {
        java.security.SecureRandom.getInstance("NativePRNGNonBlocking")
    } catch (_: java.security.NoSuchAlgorithmException) {
        java.security.SecureRandom()
    }
    secureRandom.also { sr ->
        // Force seeding when the lazy value initializes rather than during key generation.
        sr.nextBytes(ByteArray(1))
    }
}

/**
 * Coroutine dispatcher for handling individual RPC requests in parallel within a stream.
 *
 * This dispatcher processes individual RPC request/response cycles as coroutines. This allows
 * multiple RPC requests received on the same stream to be handled concurrently — a slow request
 * does not block subsequent requests from being processed and returning results.
 *
 * Uses [kotlinx.coroutines.Dispatchers.IO] with [limitedParallelism] to create a **dedicated**
 * parallel worker that is separate from the shared IO pool. RPC request handlers may perform
 * blocking operations (e.g., Thread.sleep, blocking I/O, database calls) which occupy threads
 * for extended periods. Using the shared Dispatchers.IO directly caused thread starvation when
 * other parts of the application (or leaked coroutines from unclosed UrlProtocol2 instances)
 * consumed all 64 IO threads, causing RPC handlers to queue up and execute sequentially instead
 * of concurrently.
 *
 * `Dispatchers.IO.limitedParallelism(64)` creates a separate parallel worker with its own
 * thread limit that does NOT count against the main IO dispatcher's 64-thread limit. This
 * ensures RPC request handling always has threads available, regardless of what other coroutines
 * are doing on the shared Dispatchers.IO.
 *
 * Per-stream CoroutineScope still enables cancellation of in-flight handlers when the stream closes.
 */
private val rpcRequestDispatcher = kotlinx.coroutines.Dispatchers.IO.limitedParallelism(64)

// Announcement application is normally short, but registry/lifetime waits may block.
// Give each host its own bounded capacity without borrowing any of the 64 RPC slots.
private const val ONE_SHOT_GOSSIP_PARALLELISM = 16
private val oneShotGossipWorkerIds = AtomicLong()

private const val ONE_SHOT_GOSSIP_PENDING_PER_PEER = 64
private const val ONE_SHOT_GOSSIP_REFUSAL_LANE = "host:refusal"
private const val ONE_SHOT_GOSSIP_FAILURE_HISTORY = 16
private const val ONE_SHOT_GOSSIP_FAILURE_CLASS_CHARS = 256
private const val ONE_SHOT_GOSSIP_FAILURE_MESSAGE_CHARS = 1024

private fun oneShotGossipFailureDescription(failure: Throwable): String {
    val className = failure.javaClass.name.take(ONE_SHOT_GOSSIP_FAILURE_CLASS_CHARS)
    val message = try {
        failure.message?.take(ONE_SHOT_GOSSIP_FAILURE_MESSAGE_CHARS) ?: "<no message>"
    } catch (renderingFailure: Throwable) {
        // A caller's message getter can throw too. Retain its class only, never its graph.
        "<message unavailable: ${renderingFailure.javaClass.name.take(ONE_SHOT_GOSSIP_FAILURE_CLASS_CHARS)}>"
    }
    return "$className: $message"
}

/**
 * A coalesced refusal sample delivered on the host's ordered announcement worker to its owner.
 * Withdrawal reports retain a scalar count so each refused frame is reported.
 * Shared pressure leaves sender scores unchanged. A sender's own queue overflow takes priority
 * over an earlier shared-pressure sample in the same lane; announcement reports remain coalesced.
 */
class AnnouncementAdmissionRefusedEffect(
    val samplePeerId: String,
    val peerQueueFull: Boolean,
    val reason: String,
    withdrawal: Boolean = false,
) : NotificationEffect(
    (if (withdrawal) "Withdrawal" else "Announcement") + " from $samplePeerId was refused: $reason; " +
        if (peerQueueFull) "the sender's pending queue is full"
        else if (withdrawal) "the withdrawal allowance is full; sender score is unchanged"
        else "the process-wide allowance is full; sender score is unchanged",
    MessageSeverity.WARNING,
)

/** Owns admitted one-way work until the host stops, independently of child/root close. */
internal class OneShotGossipScope(
    private val onIdle: (() -> Unit)? = null,
) {
    private class Work(
        val apply: () -> Unit,
        val reportFailure: (Throwable) -> Unit,
        private val reservation: AutoCloseable? = null,
        val peerQueueFull: Boolean = false,
        var repetitions: Long = 1L,
    ) : AutoCloseable {
        override fun close() { reservation?.close() }
    }
    private class Lane(val key: String) {
        val pending = java.util.ArrayDeque<Work>()
        var action: kotlinx.coroutines.Job? = null
        var current: Work? = null
        var refusedAnnouncement: Work? = null
        var refusedWithdrawal: Work? = null
        var failed = false
        var withdrawalBytes = 0L
    }

    private val ownerEffectRepository = `$effectHandlerRepository`.get()
    private val lock = Any()
    private val supervisor = kotlinx.coroutines.SupervisorJob()
    private val dispatcher = java.util.concurrent.Executors.newFixedThreadPool(ONE_SHOT_GOSSIP_PARALLELISM) { task ->
        Thread(task, "url-one-shot-gossip-${oneShotGossipWorkerIds.incrementAndGet()}").apply { isDaemon = true }
    }.asCoroutineDispatcher()
    private val scope = kotlinx.coroutines.CoroutineScope(dispatcher + supervisor)
    private val lanes = HashMap<String, Lane>()
    private val workers = HashSet<kotlinx.coroutines.Job>()
    private val drained = CompletableFuture<Void>()
    private var closed = false
    private var refusalsClosed = false
    private var releasingAdmissions = 0
    private var reportingFailureCount = 0L
    private val reportingDiagnostics = java.util.ArrayDeque<String>()

    private fun recordFailure(failure: Throwable, callbackFailure: Throwable? = null) {
        // Rendering is caller code: the current worker stays owned, but no coordinator owner
        // is held when its message getter re-enters stop or another public callback.
        val diagnostic = if (callbackFailure == null) {
            "Announcement worker failure ${oneShotGossipFailureDescription(failure)}"
        } else {
            "Transport report failure ${oneShotGossipFailureDescription(failure)}; " +
                "callback failure ${oneShotGossipFailureDescription(callbackFailure)}"
        }
        synchronized(lock) {
            if (reportingFailureCount < Long.MAX_VALUE) reportingFailureCount++
            if (reportingDiagnostics.size == ONE_SHOT_GOSSIP_FAILURE_HISTORY) {
                reportingDiagnostics.removeFirst()
            }
            reportingDiagnostics.addLast(diagnostic)
        }
    }

    fun reportRefusal(effect: AnnouncementAdmissionRefusedEffect) {
        val report = {
            try { toss(effect) }
            catch (unhandled: UnhandledNotificationEffect) {
                if (unhandled.effect !== effect) throw unhandled
                // An inbound frame has no synchronous caller to receive the warning. Preserve
                // the coalesced report on stderr when the host owner has no effect handler.
                System.err.println("[AnnouncementAdmissionRefused] ${effect.message}")
            }
        }
        if (ownerEffectRepository == null) { report(); return }
        // Runtime handler execution state is thread-local. Holding the repository monitor
        // through caller code would block root-close diagnostics on transport event loops.
        val workerRepository = `$effectHandlerRepository`.get()
        `$effectHandlerRepository`.set(ownerEffectRepository)
        try { report() }
        finally { `$effectHandlerRepository`.set(workerRepository) }
    }

    fun admit(
        peerId: String,
        retainedBytes: Long,
        apply: () -> Unit,
        reportFailure: (Throwable) -> Unit,
        onRefused: (String, Boolean) -> Unit,
        withdrawal: Boolean = false,
    ): Boolean {
        var workerToCancel: kotlinx.coroutines.Job? = null
        var workerToStart: kotlinx.coroutines.Job? = null
        val abandoned = ArrayList<AutoCloseable>()
        var ownsCleanup = false
        var terminalRefusal: String? = null
        try {
            val admitted = synchronized(lock) {
                if (closed && refusalsClosed) {
                    terminalRefusal = "the host's announcement scope is closed"
                    return@synchronized false
                }
                val previous = lanes[peerId]
                var lane = previous ?: Lane(peerId)
                if (lane.failed) {
                    terminalRefusal = "the peer's announcement worker has stopped after a failure"
                    return@synchronized false
                }
                if (!closed && !withdrawal && lane.pending.size >= ONE_SHOT_GOSSIP_PENDING_PER_PEER) {
                    // One coalesced observer holds no parsed message and runs after accepted work.
                    if (lane.refusedAnnouncement?.peerQueueFull != true) lane.refusedAnnouncement = Work(
                        { onRefused("all $ONE_SHOT_GOSSIP_PENDING_PER_PEER pending slots are occupied", true) },
                        reportFailure, peerQueueFull = true,
                    )
                    return@synchronized false
                }
                val withdrawalLimit = Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES.toLong() * 3 / 4
                val peerWithdrawalFull = withdrawal &&
                    (retainedBytes <= 0L || retainedBytes > withdrawalLimit - lane.withdrawalBytes)
                val reservation = if (closed) null else if (withdrawal) {
                    if (peerWithdrawalFull) null else reserveOneShotWithdrawalBytes(retainedBytes)?.let { shared ->
                        lane.withdrawalBytes += retainedBytes
                        val released = java.util.concurrent.atomic.AtomicBoolean()
                        AutoCloseable {
                            if (released.compareAndSet(false, true)) {
                                synchronized(lock) { lane.withdrawalBytes -= retainedBytes }
                                // Return process capacity after the peer ledger transition.
                                shared.close()
                            }
                        }
                    }
                } else reserveOneShotGossipBytes(retainedBytes)
                val refusalReason = if (closed) {
                    "the host's announcement scope is closed"
                } else if (peerWithdrawalFull) {
                    "the peer's $withdrawalLimit-byte withdrawal allowance already holds " +
                        "${lane.withdrawalBytes} bytes and cannot reserve $retainedBytes bytes"
                } else if (withdrawal) {
                    "the shared ${Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES}-byte " +
                        "withdrawal allowance cannot reserve $retainedBytes bytes"
                } else {
                    "the shared ${Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES}-byte " +
                        "retained-work allowance cannot reserve $retainedBytes bytes"
                }
                if (reservation == null) {
                    if (previous == null) {
                        // No payload was admitted for this peer. A host-wide lane prevents new,
                        // already-closed peer identities from retaining an uncharged report each.
                        val overflow = lanes[ONE_SHOT_GOSSIP_REFUSAL_LANE]
                        if (overflow != null) {
                            if (withdrawal) {
                                val report = overflow.refusedWithdrawal
                                if (report == null) overflow.refusedWithdrawal = Work(
                                    { onRefused(refusalReason, false) }, reportFailure,
                                ) else report.repetitions = Math.addExact(report.repetitions, 1L)
                            } else if (overflow.refusedAnnouncement == null) {
                                overflow.refusedAnnouncement = Work(
                                    { onRefused(refusalReason, false) },
                                    reportFailure,
                                )
                            }
                            return@synchronized false
                        }
                        lane = Lane(ONE_SHOT_GOSSIP_REFUSAL_LANE)
                    }
                    if (withdrawal) {
                        val report = lane.refusedWithdrawal
                        if (report == null) lane.refusedWithdrawal = Work(
                            { onRefused(refusalReason, false) }, reportFailure,
                        ) else report.repetitions = Math.addExact(report.repetitions, 1L)
                    } else if (lane.refusedAnnouncement == null) {
                        lane.refusedAnnouncement = Work(
                            { onRefused(refusalReason, false) },
                            reportFailure,
                        )
                    }
                } else {
                    try {
                        lane.pending.addLast(Work(apply, reportFailure, reservation))
                    } catch (failure: Throwable) {
                        abandoned.add(reservation)
                        releasingAdmissions++
                        ownsCleanup = true
                        throw failure
                    }
                }
                if (previous != null) return@synchronized reservation != null

                var worker: kotlinx.coroutines.Job? = null
                var completionOwned = false
                try {
                    lanes[lane.key] = lane
                    val created = scope.launch(start = kotlinx.coroutines.CoroutineStart.LAZY) { drain(lane) }
                    worker = created
                    workers.add(created)
                    created.invokeOnCompletion { failure -> finishLane(lane, created, failure) }
                    completionOwned = true
                    workerToStart = created
                } catch (failure: Throwable) {
                    // Detach failed admission work now; release its reservations and cancel
                    // the unstarted worker only after leaving the coordinator monitor.
                    lane.failed = true
                    lanes.remove(lane.key, lane)
                    abandoned.addAll(lane.pending)
                    releasingAdmissions++
                    ownsCleanup = true
                    lane.pending.clear()
                    lane.refusedAnnouncement = null
                    lane.refusedWithdrawal = null
                    workerToCancel = worker
                    if (!completionOwned) worker?.let { workers.remove(it) }
                    throw failure
                }
                reservation != null
            }
            // Rejected dispatch may complete the job inline, including finishLane cleanup.
            // Publish ownership under the lock, but start only after releasing that lock.
            workerToStart?.let { created ->
                check(created.start()) { "Announcement worker for peer '$peerId' did not start after admission" }
            }
            // A direct decoded caller can invoke a handler after its root has finished closing.
            // There is no live worker owner then; report outside the scope monitor.
            terminalRefusal?.let { onRefused(it, false) }
            return admitted
        } catch (failure: Throwable) {
            // Attempt every detached reservation while
            // retaining cleanup ownership, then preserve the original admission failure.
            for (reservation in abandoned) {
                try { reservation.close() }
                catch (releaseFailure: Throwable) {
                    if (releaseFailure !== failure) failure.addSuppressed(releaseFailure)
                }
            }
            try { (workerToCancel ?: workerToStart)?.cancel() }
            catch (cancelFailure: Throwable) {
                if (cancelFailure !== failure) failure.addSuppressed(cancelFailure)
            }
            if (ownsCleanup) {
                val (complete, idle) = synchronized(lock) {
                    releasingAdmissions--
                    val idle = workers.isEmpty() && releasingAdmissions == 0
                    (closed && refusalsClosed && idle) to idle
                }
                if (complete) completeDrain()
                else if (idle) onIdle?.invoke()
            }
            throw failure
        }
    }

    private fun finishLane(lane: Lane, worker: kotlinx.coroutines.Job, failure: Throwable?) {
        // Keep this worker registered through diagnostic rendering and reservation release,
        // including callbacks that re-enter stop on this or another host.
        failure?.let { recordFailure(it) }
        val abandoned = synchronized(lock) {
            // Structural child ownership joins the action before this terminal cleanup.
            lanes.remove(lane.key, lane)
            val detached = ArrayList<Work>(lane.pending)
            lane.pending.clear()
            lane.current?.let { detached.add(it) }
            lane.current = null
            lane.refusedAnnouncement = null
            lane.refusedWithdrawal = null
            lane.action = null
            detached
        }
        try {
            for (work in abandoned) {
                try { work.close() }
                catch (releaseFailure: Throwable) { recordFailure(releaseFailure) }
            }
        } finally {
            val (complete, idle) = synchronized(lock) {
                workers.remove(worker)
                val idle = workers.isEmpty() && releasingAdmissions == 0
                (closed && refusalsClosed && idle) to idle
            }
            if (complete) completeDrain()
            else if (idle) onIdle?.invoke()
        }
    }

    private suspend fun drain(lane: Lane) {
        kotlinx.coroutines.coroutineScope {
            while (true) {
                val work = synchronized(lock) {
                    if (lane.failed) return@coroutineScope
                    (lane.pending.pollFirst()
                        ?: lane.refusedAnnouncement?.also { lane.refusedAnnouncement = null }
                        ?: lane.refusedWithdrawal?.also { lane.refusedWithdrawal = null }
                        ?: run {
                            check(lanes.remove(lane.key, lane)) {
                                "Announcement worker for '${lane.key}' lost its queue owner"
                            }
                            return@coroutineScope
                        }).also { lane.current = it }
                }
                var action: kotlinx.coroutines.Job? = null
                try {
                    // Each action has its own cancellation identity. runInterruptible clears the
                    // interruption before the announcement worker can be reused for another action.
                    val startedAction = launch(start = kotlinx.coroutines.CoroutineStart.LAZY) {
                        try {
                            val actionJob = coroutineContext[kotlinx.coroutines.Job]
                            kotlinx.coroutines.runInterruptible {
                                // Until this block is entered, accepted work is still pending.
                                // Publish only after the interruption handler is installed so stop
                                // cannot cancel a lazy action before it applies its accepted work.
                                synchronized(lock) { lane.action = actionJob }
                                var remaining = work.repetitions
                                while (remaining > 0L) {
                                    try { work.apply() }
                                    catch (failure: Throwable) {
                                        if (work.repetitions == 1L) throw failure
                                        try { work.reportFailure(failure) }
                                        catch (reportFailure: Throwable) { recordFailure(failure, reportFailure) }
                                    }
                                    remaining--
                                }
                            }
                        } catch (failure: Throwable) {
                            val hostCancellation = failure is kotlinx.coroutines.CancellationException &&
                                synchronized(lock) { closed } &&
                                coroutineContext[kotlinx.coroutines.Job]?.isCancelled == true
                            if (!hostCancellation) {
                                try {
                                    work.reportFailure(failure)
                                } catch (reportFailure: Throwable) {
                                    // Completed work must not stay alive through an uncharged error
                                    // graph. Stop preserves bounded diagnostic copies and a total count.
                                    recordFailure(reportFailure, failure)
                                }
                            }
                            // Host stop owns this cancellation and joins the action below. It is not a
                            // transport failure and must not escape into a shared worker's uncaught handler.
                        }
                    }
                    action = startedAction
                    startedAction.start()
                    startedAction.join()
                } finally {
                    // The action may ignore cancellation. Keep its byte charge until it actually
                    // ends even when the lane itself fails after the admission wrapper returned.
                    kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                        action?.cancel()
                        action?.join()
                    }
                    work.close()
                    synchronized(lock) { lane.action = null; lane.current = null }
                }
            }
        }
    }

    fun close(cancelRunning: Boolean = true, finishRefusals: Boolean = true): CompletableFuture<Void> {
        val actions: List<kotlinx.coroutines.Job>
        val complete: Boolean
        synchronized(lock) {
            if (closed) return drained
            closed = true
            refusalsClosed = finishRefusals
            actions = if (cancelRunning) lanes.values.mapNotNull { it.action } else emptyList()
            complete = refusalsClosed && workers.isEmpty() && releasingAdmissions == 0
        }
        // Cancel only actions already running. Accepted pending work retains its ordered lane
        // and drains before stop completes. Never cancel or complete futures under the monitor.
        actions.forEach { it.cancel() }
        if (complete) completeDrain()
        return drained
    }

    /** Host stop seals reporting after transport shutdown has settled every in-flight read. */
    fun finishRefusals() {
        val complete = synchronized(lock) {
            refusalsClosed = true
            closed && workers.isEmpty() && releasingAdmissions == 0
        }
        if (complete) completeDrain()
    }

    fun markClosedIfIdle(): Boolean = synchronized(lock) {
        if (closed || workers.isNotEmpty() || releasingAdmissions != 0) false
        else {
            closed = true
            refusalsClosed = true
            true
        }
    }

    fun finishIdleClose() {
        completeDrain()
    }

    private fun completeDrain() {
        supervisor.cancel()
        // All actions and lane bookkeeping have finished. Shutdown accepts no new work
        // and lets the final worker return without waiting on itself.
        dispatcher.close()
        val failure = synchronized(lock) {
            if (reportingFailureCount == 0L) null else IllegalStateException(
                "Announcement workers recorded $reportingFailureCount failures; retaining the latest " +
                    "${reportingDiagnostics.size} diagnostics (class names at most " +
                    "$ONE_SHOT_GOSSIP_FAILURE_CLASS_CHARS characters, message prefixes at most " +
                    "$ONE_SHOT_GOSSIP_FAILURE_MESSAGE_CHARS characters)"
            ).also { summary ->
                reportingDiagnostics.forEach { summary.addSuppressed(IllegalStateException(it)) }
            }
        }
        if (failure == null) drained.complete(null) else drained.completeExceptionally(failure)
    }
}

private data class OneShotGossipPeerKey(val localPeerId: String, val remotePeerId: String)

private class OneShotGossipPeerScopeEntry(val scope: OneShotGossipScope) {
    val roots: MutableSet<Connection> = java.util.Collections.newSetFromMap(
        java.util.IdentityHashMap<Connection, Boolean>()
    )
}

private val oneShotGossipPeerScopeLock = Any()
private val oneShotGossipPeerScopes = HashMap<OneShotGossipPeerKey, OneShotGossipPeerScopeEntry>()

private fun retireOneShotGossipPeerScope(key: OneShotGossipPeerKey, entry: OneShotGossipPeerScopeEntry) {
    val retired = synchronized(oneShotGossipPeerScopeLock) {
        if (oneShotGossipPeerScopes[key] !== entry || entry.roots.isNotEmpty() ||
            !entry.scope.markClosedIfIdle()
        ) {
            false
        } else {
            oneShotGossipPeerScopes.remove(key)
            true
        }
    }
    if (retired) entry.scope.finishIdleClose()
}

private fun oneShotGossipScopeForConnection(stream: Stream): OneShotGossipScope {
    val connection = stream.connection
    val secureSession = connection.secureSession()
    val key = OneShotGossipPeerKey(
        localPeerId = secureSession.localId.toBase58(),
        remotePeerId = secureSession.remoteId.toBase58(),
    )
    val (entry, registerRootClose) = synchronized(oneShotGossipPeerScopeLock) {
        val existing = oneShotGossipPeerScopes[key]
        if (existing != null) {
            existing to existing.roots.add(connection)
        } else {
            lateinit var created: OneShotGossipPeerScopeEntry
            created = OneShotGossipPeerScopeEntry(
                OneShotGossipScope { retireOneShotGossipPeerScope(key, created) }
            )
            created.roots.add(connection)
            oneShotGossipPeerScopes[key] = created
            created to true
        }
    }
    if (registerRootClose) {
        connection.closeFuture().whenComplete { _, _ ->
            val rootless = synchronized(oneShotGossipPeerScopeLock) {
                if (oneShotGossipPeerScopes[key] !== entry) {
                    false
                } else {
                    entry.roots.remove(connection)
                    entry.roots.isEmpty()
                }
            }
            if (rootless) retireOneShotGossipPeerScope(key, entry)
        }
    }
    return entry.scope
}

// A dispatcher bounds runnable segments; this allowance also counts suspended handlers and
// completed responses retained by the outbox, until their write finishes or their bytes are freed.
private val rpcRequestPermits = kotlinx.coroutines.sync.Semaphore(64)
// Explicit parking declarations use a separate, non-waiting allowance. Keep its lifetime
// identical to ordinary work so completed long-poll replies cannot grow without a count bound.
private val rpcLongPollRequestPermits = kotlinx.coroutines.sync.Semaphore(
    LongPollRpcRequestHandler.MAX_CONCURRENT_REQUESTS,
)

/**
 * Dedicated dispatcher for request-side PeerExchange apply work.
 *
 * A PeerExchange response is a durable acknowledgement: the receiver must not
 * write it until [GossipHandler.onPeersReceived] has completed for the incoming
 * peer list. Response-side PeerExchange follow-up work is allowed to run later
 * on [gossipFollowUpScope], so request-side apply must not share that dispatch
 * lane; otherwise saturated fire-and-forget follow-up work can prevent the
 * receive-side apply from even starting, and the requester waits indefinitely
 * for an acknowledgement that is correctly ordered but not live.
 *
 * Launching request-side apply here keeps the Netty stream callback thread free
 * while preserving backpressure: each request coroutine blocks its own response
 * write until the apply callback returns.
 */
private const val PEER_EXCHANGE_REQUEST_PARALLELISM = 64
private val peerExchangeRequestDispatcher =
    kotlinx.coroutines.Dispatchers.IO.limitedParallelism(PEER_EXCHANGE_REQUEST_PARALLELISM)

/**
 * Host-owned lifecycle and admission coordinator for request-side PeerExchange work.
 *
 * A request stream is only the delivery mechanism for a PeerExchange request. Once the request
 * has been admitted, closing that stream must not cancel the receive-side apply. The host owns
 * this coordinator instead: stopping the host rejects and cancels requests that have not entered
 * their apply callback, while an apply that has started is allowed to finish before the stop
 * future completes.
 *
 * The dispatcher limits running callbacks to [PEER_EXCHANGE_REQUEST_PARALLELISM]. Its separate
 * semaphore limits admitted jobs that are still waiting to enter a callback, so a burst cannot
 * leave an unbounded coroutine queue behind the dispatcher. A second budget accounts for the
 * conservative retained-object estimate of each parsed request and is held across pending,
 * starting, and running states. The pending, starting, and running sets are therefore bounded by
 * both fixed protocol counts and aggregate retained bytes.
 */
internal class PeerExchangeRequestScope {
    internal class AdmittedRequest(
        val retainedBytes: Int,
        val apply: () -> Unit
    ) {
        lateinit var job: kotlinx.coroutines.Job
        var reported = false
        var completed = false
        var retainedBytesReleased = false
    }

    /**
     * Admission reporting is a second phase of admission. The handle is settled only after the
     * public severity callback returns, while the same state lock also arbitrates host close.
     */
    internal class Admission internal constructor(
        private val owner: PeerExchangeRequestScope,
        private val request: AdmittedRequest
    ) {
        fun settle(): Boolean = owner.settle(request)
    }

    internal class AdmissionAttempt(
        val admission: Admission?,
        val rejectionReason: String?,
        val retainedBytesInUse: Int
    )

    private val supervisorJob = kotlinx.coroutines.SupervisorJob()
    private val scope = kotlinx.coroutines.CoroutineScope(
        peerExchangeRequestDispatcher + supervisorJob
    )
    private val pendingBudget = Semaphore(PEER_EXCHANGE_REQUEST_PARALLELISM, true)
    private val lock = Any()
    private val pendingRequests = HashSet<AdmittedRequest>()
    private val startingRequests = HashSet<AdmittedRequest>()
    private val runningRequests = HashSet<AdmittedRequest>()
    private val drainFuture = CompletableFuture<Void>()
    private var retainedBytesInUse = 0L
    private var maxObservedRetainedBytes = 0L
    private var completedAdmissionAttempts = 0L
    private var admittedRequests = 0L
    private var rejectedRequests = 0L
    private var closed = false

    /** Returns a lock-consistent monitoring snapshot without changing admission state. */
    fun snapshot(): PeerExchangeAdmissionSnapshot = synchronized(lock) {
        PeerExchangeAdmissionSnapshot(
            completedAdmissionAttempts = completedAdmissionAttempts,
            admittedRequests = admittedRequests,
            rejectedRequests = rejectedRequests,
            retainedBytesInUse = retainedBytesInUse,
            maxObservedRetainedBytes = maxObservedRetainedBytes,
            pendingRequests = pendingRequests.size,
            startingRequests = startingRequests.size,
            runningRequests = runningRequests.size,
            retainedByteLimit = PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET,
            closed = closed,
        )
    }

    /** Records the end of the public reporting phase for one admission attempt. */
    fun recordAdmissionCompleted(admitted: Boolean) {
        synchronized(lock) {
            completedAdmissionAttempts++
            if (admitted) admittedRequests++ else rejectedRequests++
        }
    }

    /**
     * Admit one request, returning a handle that must be settled before public admission is
     * reported. The lazy job is started while [lock] is held; starting a lazy coroutine only
     * schedules it and does not run user code, so host close cannot cancel a job in the gap between
     * placing it in [pendingRequests] and starting it.
     */
    fun admit(retainedBytes: Int, apply: () -> Unit): AdmissionAttempt {
        synchronized(lock) {
            if (closed) {
                return AdmissionAttempt(
                    admission = null,
                    rejectionReason = "the host is closing",
                    retainedBytesInUse = retainedBytesInUse.toInt()
                )
            }
            if (retainedBytes <= 0) {
                return AdmissionAttempt(
                    admission = null,
                    rejectionReason = "the request retained-byte estimate must be positive, " +
                        "but the observed estimate was $retainedBytes",
                    retainedBytesInUse = retainedBytesInUse.toInt()
                )
            }
            val requestedBytes = retainedBytes.toLong()
            if (requestedBytes > PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET.toLong()) {
                return AdmissionAttempt(
                    admission = null,
                    rejectionReason = "the single request estimate $retainedBytes exceeds the " +
                        "aggregate retained-byte limit " +
                        "$PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET",
                    retainedBytesInUse = retainedBytesInUse.toInt()
                )
            }
            if (!pendingBudget.tryAcquire()) {
                return AdmissionAttempt(
                    admission = null,
                    rejectionReason = "all $PEER_EXCHANGE_REQUEST_PARALLELISM pending admission " +
                        "slots are occupied",
                    retainedBytesInUse = retainedBytesInUse.toInt()
                )
            }
            if (retainedBytesInUse >
                PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET.toLong() - requestedBytes
            ) {
                pendingBudget.release()
                return AdmissionAttempt(
                    admission = null,
                    rejectionReason = "the aggregate retained-byte limit " +
                        "$PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET would be exceeded by " +
                        "adding $retainedBytes bytes to the $retainedBytesInUse bytes already " +
                        "reserved",
                    retainedBytesInUse = retainedBytesInUse.toInt()
                )
            }

            retainedBytesInUse += requestedBytes
            if (retainedBytesInUse > maxObservedRetainedBytes) {
                maxObservedRetainedBytes = retainedBytesInUse
            }
            val request = AdmittedRequest(retainedBytes, apply)
            request.job = scope.launch(start = kotlinx.coroutines.CoroutineStart.LAZY) {
                val enteredStarting = synchronized(lock) {
                    if (!pendingRequests.remove(request) || (closed && !request.reported)) {
                        false
                    } else {
                        startingRequests.add(request)
                        true
                    }
                }
                if (!enteredStarting) {
                    releaseRetainedBytes(request)
                    return@launch
                }

                // The pending budget covers the admission queue. Once a dispatcher worker has
                // taken the request, the starting state is bounded by that dispatcher and is
                // arbitrated separately from both the pending queue and running callbacks.
                pendingBudget.release()

                // Host close uses this same lock. A request is either removed from starting and
                // canceled before this claim, or moved to running by the winning claim and
                // drained as work that has entered the apply phase. This closes the gap between
                // leaving pendingRequests and invoking user code without holding the lock during
                // the user callback.
                val enteredApply = synchronized(lock) {
                    if (!startingRequests.remove(request) || (closed && !request.reported)) {
                        false
                    } else {
                        runningRequests.add(request)
                        true
                    }
                }
                if (!enteredApply) {
                    releaseRetainedBytes(request)
                    return@launch
                }

                try {
                    request.apply()
                } finally {
                    requestFinished(request)
                }
            }
            try {
                pendingRequests.add(request)
                check(request.job.start()) {
                    "PeerExchange request job failed to start after entering the pending admission set"
                }
            } catch (failure: Throwable) {
                pendingRequests.remove(request)
                pendingBudget.release()
                releaseRetainedBytesLocked(request)
                throw failure
            }
            return AdmissionAttempt(
                admission = Admission(this, request),
                rejectionReason = null,
                retainedBytesInUse = retainedBytesInUse.toInt()
            )
        }
    }

    /**
     * Settle the public admission report against host close. A pending request survives a close
     * only when this transition wins first; that is the rule that prevents a request reported as
     * admitted from being silently canceled afterward. Running work is already safe to drain and
     * remains reportable after close.
     */
    private fun settle(request: AdmittedRequest): Boolean = synchronized(lock) {
        if (request.reported) return@synchronized true
        val pending = request in pendingRequests
        val starting = request in startingRequests
        val running = request in runningRequests
        if (!pending && !starting && !running && !request.completed) return@synchronized false
        if (closed && (pending || starting)) return@synchronized false
        request.reported = true
        request.completed = false
        true
    }

    /** Close admission and return the unbounded actual drain future. */
    fun close(): CompletableFuture<Void> {
        val requestsToCancel: List<AdmittedRequest>
        val completeImmediately: Boolean
        synchronized(lock) {
            if (closed) {
                requestsToCancel = emptyList()
            } else {
                closed = true
                val pendingToCancel = pendingRequests.filterNot { it.reported }
                val startingToCancel = startingRequests.filterNot { it.reported }
                pendingToCancel.forEach {
                    pendingRequests.remove(it)
                    releaseRetainedBytesLocked(it)
                }
                startingToCancel.forEach {
                    startingRequests.remove(it)
                    releaseRetainedBytesLocked(it)
                }
                repeat(pendingToCancel.size) { pendingBudget.release() }
                requestsToCancel = pendingToCancel + startingToCancel
            }
            completeImmediately =
                pendingRequests.isEmpty() &&
                    startingRequests.isEmpty() &&
                    runningRequests.isEmpty()
        }

        // Do not invoke cancellation while holding lock: cancellation can synchronously run job
        // bookkeeping and must be free to re-enter this coordinator.
        requestsToCancel.forEach { it.job.cancel() }
        if (completeImmediately) completeDrain()
        return drainFuture
    }

    /**
     * Close admission and bound the host-owned drain with the existing libp2p host-close budget.
     * The actual drain remains alive after a timeout so a later callback completion still releases
     * the supervisor; the returned future reports the bound to the host lifecycle caller.
     */
    fun closeForHostStop(): CompletableFuture<Void> {
        close()
        val bounded = CompletableFuture<Void>()
        drainFuture.whenComplete { _, failure ->
            if (failure == null) bounded.complete(null)
            else bounded.completeExceptionally(failure)
        }
        CompletableFuture.delayedExecutor(
            LIBP2P_HOST_STOP_TIMEOUT_SECONDS,
            TimeUnit.SECONDS
        ).execute {
            bounded.completeExceptionally(
                TimeoutException(
                    "PeerExchange request drain did not complete within " +
                        "$LIBP2P_HOST_STOP_TIMEOUT_SECONDS seconds during host stop; a running " +
                        "PeerExchange apply may still be inside registry work"
                )
            )
        }
        return bounded
    }

    private fun requestFinished(request: AdmittedRequest) {
        val completeNow = synchronized(lock) {
            if (!runningRequests.remove(request)) {
                releaseRetainedBytesLocked(request)
                return@synchronized false
            }
            releaseRetainedBytesLocked(request)
            // Applying the request can finish while the synchronous public severity callback is
            // still running. Keep a terminal admission record until settle() consumes it so a
            // completed admitted request cannot be mistaken for a close-time rejection.
            if (!request.reported) request.completed = true
            closed &&
                pendingRequests.isEmpty() &&
                startingRequests.isEmpty() &&
                runningRequests.isEmpty()
        }
        if (completeNow) completeDrain()
    }

    private fun releaseRetainedBytes(request: AdmittedRequest) {
        synchronized(lock) {
            releaseRetainedBytesLocked(request)
        }
    }

    private fun releaseRetainedBytesLocked(request: AdmittedRequest) {
        if (request.retainedBytesReleased) return
        request.retainedBytesReleased = true
        retainedBytesInUse -= request.retainedBytes.toLong()
        check(retainedBytesInUse >= 0L) {
            "PeerExchange retained-byte accounting became negative after releasing " +
                "${request.retainedBytes} bytes; current total=$retainedBytesInUse"
        }
    }

    private fun completeDrain() {
        if (drainFuture.complete(null)) {
            supervisorJob.cancel()
        }
    }
}

/**
 * Keeps the normal [Host] API while making host stop own admitted gossip work.
 */
private class PeerExchangeLifecycleHost(
    private val delegate: Host,
    private val requestScope: PeerExchangeRequestScope,
    private val announcementScope: OneShotGossipScope,
) : Host by delegate {
    private val stopFuture = AtomicReference<CompletableFuture<Void>?>(null)

    override fun stop(): CompletableFuture<Void> {
        val result = CompletableFuture<Void>()
        if (!stopFuture.compareAndSet(null, result)) {
            return stopFuture.get()!!
        }

        val announcementDrain = try {
            announcementScope.close(finishRefusals = false)
        } catch (failure: Throwable) {
            CompletableFuture.failedFuture(failure)
        }
        val requestDrain = try {
            requestScope.closeForHostStop()
        } catch (failure: Throwable) {
            CompletableFuture.failedFuture(failure)
        }
        val hostStop = try {
            delegate.stop()
        } catch (failure: Throwable) {
            CompletableFuture.failedFuture(failure)
        }
        hostStop.whenComplete { _, _ -> announcementScope.finishRefusals() }
        CompletableFuture.allOf(hostStop, requestDrain, announcementDrain).whenComplete { _, failure ->
            if (failure == null) result.complete(null)
            else result.completeExceptionally(failure)
        }
        return result
    }
}

/**
 * Fallback for callers that construct [RpcServerMessageHandler] directly. The connection, rather
 * than the one-shot stream, owns this coordinator, so a stream close still cannot cancel an
 * admitted apply. Factory-created server hosts pass their host-owned coordinator explicitly.
 */
private fun peerExchangeRequestScopeForConnection(stream: Stream): PeerExchangeRequestScope {
    val requestScope = PeerExchangeRequestScope()
    stream.connection.closeFuture().whenComplete { _, _ -> requestScope.close() }
    return requestScope
}

/**
 * Process-wide scope for fire-and-forget gossip-handler work that must outlive
 * the stream that delivered the message.
 *
 * PeerExchange REQUESTS are not launched here: their response is an
 * acknowledgement that the receiver has applied the incoming peer list, so
 * request-side `gossipHandler.onPeersReceived` runs on the isolated
 * [peerExchangeRequestDispatcher] before the response is written. PeerExchange
 * RESPONSES have no response of their own to acknowledge, so their peer-list
 * processing may still run here after the substream is closed.
 *
 * Launching fire-and-forget follow-up work into this top-level scope decouples
 * it from the stream's lifetime so it actually completes. SupervisorJob
 * ensures one misbehaving handler does not poison sibling handlers, and the
 * same `rpcRequestDispatcher` is used so handler concurrency is still bounded.
 */
private val gossipFollowUpScope: kotlinx.coroutines.CoroutineScope =
    kotlinx.coroutines.CoroutineScope(rpcRequestDispatcher + kotlinx.coroutines.SupervisorJob())

/**
 * Hands one-way gossip application work to its dedicated host executor. The parsed
 * message outlives its delivering child. The event loop returns its frame lease after admission
 * into the host's bounded per-peer queue and closes the child. Interaction callbacks belong to
 * the same ordered application work: they may enter the registry.
 */
private enum class OneShotGossipDispatch { COMPLETE }

private fun dispatchOneShotGossip(
    message: Any,
    gossipHandler: GossipHandler?,
    stream: Stream,
    announcementScope: OneShotGossipScope,
    inboundMessage: Any,
    onFailure: (Throwable) -> Unit,
): OneShotGossipDispatch? {
    val apply: (String) -> Unit = when (message) {
        is GossipProtocol.ServiceAnnouncement -> fun(peerId: String) {
            try {
                gossipHandler?.onServiceAnnouncement(message)
            } catch (e: Exception) {
                debugLogErr { "[GOSSIP] onServiceAnnouncement handler threw for ${message.serviceUrl} from $peerId: ${e.message}" }
            }
        }
        is GossipProtocol.ServiceWithdrawal -> fun(peerId: String) {
            debugLog { "[DIRECT-GOSSIP] Received service withdrawal via direct connection: '${message.serviceIdentifier}' from $peerId" }
            try {
                gossipHandler?.onServiceWithdrawal(message)
            } catch (e: Exception) {
                debugLogErr { "[GOSSIP] onServiceWithdrawal handler threw for ${message.serviceIdentifier} from $peerId: ${e.message}" }
            }
        }
        is GossipProtocol.PeerAnnouncement -> fun(peerId: String) {
            try {
                gossipHandler?.onPeerAnnouncement(message)
            } catch (e: Exception) {
                debugLogErr { "[GOSSIP] onPeerAnnouncement handler threw from $peerId: ${e.message}" }
            }
        }
        is GossipProtocol.TldResolverAnnouncement -> fun(peerId: String) {
            try {
                gossipHandler?.onTldResolverAnnouncement(message)
            } catch (e: Exception) {
                debugLogErr { "[GOSSIP] onTldResolverAnnouncement handler threw for ${message.descriptor.tld} from $peerId: ${e.message}" }
            }
        }
        is RelayProtocol.RelayAnnouncement -> fun(peerId: String) {
            try {
                gossipHandler?.onRelayAnnouncement(message)
            } catch (e: Exception) {
                debugLogErr { "[GOSSIP] onRelayAnnouncement handler threw from $peerId: ${e.message}" }
            }
        }
        is RelayProtocol.RelayWithdrawal -> fun(peerId: String) {
            try {
                gossipHandler?.onRelayWithdrawal(message)
            } catch (e: Exception) {
                debugLogErr { "[GOSSIP] onRelayWithdrawal handler threw from $peerId: ${e.message}" }
            }
        }
        is LinkStateAdvertisement -> fun(peerId: String) {
            try {
                gossipHandler?.onLinkStateAdvertisement(message)
            } catch (e: Exception) {
                debugLogErr { "[GOSSIP] onLinkStateAdvertisement handler threw from $peerId: ${e.message}" }
            }
        }
        else -> return null
    }
    val retainedBytes = when (inboundMessage) {
        is ParseBudgetedInboundMessage -> inboundMessage.retainedBytesEstimate
        is ByteBuf -> inboundMessage.readableBytes().toLong() * Libp2pRpcProtocol.PARSE_AMPLIFICATION
        // Direct decoded inputs use the same JSON estimate and attachment charge as wire frames.
        is Libp2pRpcProtocol.MessageFrame -> inboundMessage.json.toString().toByteArray(StandardCharsets.UTF_8).size.toLong() *
            Libp2pRpcProtocol.PARSE_AMPLIFICATION + inboundMessage.attachments.sumOf { it.size.toLong() }
        else -> 1L
    }
    val authenticatedPeerId = stream.remotePeerId().toBase58()
    val peerId = authenticatedPeerId.takeLast(8)
    val withdrawal = message is GossipProtocol.ServiceWithdrawal || message is RelayProtocol.RelayWithdrawal
    val managedWithdrawal = withdrawal && inboundMessage is ParseBudgetedInboundMessage
    announcementScope.admit(authenticatedPeerId, retainedBytes, apply = {
        withAnnouncementPeerMutation(authenticatedPeerId, stream.connection.closeFuture()) {
            gossipHandler?.recordAuthenticatedInteractionCompatible(
                authenticatedPeerId,
                gossipHandler.classifyAuthenticatedInteractionCompatible(message),
            )
            apply(peerId)
        }
    }, reportFailure = onFailure, onRefused = { reason, peerQueueFull ->
        debugLogErr { "[GOSSIP] Refused announcement from $authenticatedPeerId: $reason" }
        if (peerQueueFull) {
            withAnnouncementPeerMutation(authenticatedPeerId, stream.connection.closeFuture()) {
                gossipHandler?.recordAuthenticatedInteractionCompatible(authenticatedPeerId, PeerInteractionSeverity.SEVERE)
            }
        }
        val explanation = if (withdrawal && !managedWithdrawal) {
            "$reason; this decoded input is refused immediately when withdrawal capacity is full"
        } else reason
        announcementScope.reportRefusal(AnnouncementAdmissionRefusedEffect(authenticatedPeerId, peerQueueFull, explanation, withdrawal))
    }, withdrawal = withdrawal)
    return OneShotGossipDispatch.COMPLETE
}

/**
 * Factory for creating libp2p Host instances with the RPC protocol.
 */
object Libp2pHostFactory {

    /**
     * Per-host inbound substream admission controls (issue #294), keyed by the
     * built [Host]. Populated by the host builders below (registered as a
     * `streamPreHandler` visitor) so callers and tests can inspect live-substream
     * counts via [inboundAdmissionControlFor].
     *
     * WEAK KEYS AND VALUES are essential: this is a side-lookup for inspecting a host's admission
     * control WHILE THE HOST IS ALIVE — it must never be the thing that keeps either side
     * reachable after [io.libp2p.core.Host.stop]. A strong map here (the original
     * `ConcurrentHashMap`) retained every host this singleton factory ever built — and
     * transitively its whole netty event-loop-group / buffer graph — for the JVM
     * lifetime, since nothing ever removed the entry on stop(). In a long-lived service
     * (or a shared-JVM test suite) that grows the heap without bound and the resulting GC
     * pauses intermittently blow tight teardown budgets (e.g.
     * testMalformedJsonDoesNotKillConnection's `clientHost.stop().get(2)`). An admission
     * controller also retains its owner's effect handlers, and those handlers may
     * legitimately capture the Host while consulting diagnostics. A strong value would then make
     * a captured Host keep its own weak key alive through this map. The live Host pipeline owns
     * the controller, so the diagnostic value can be weak without shortening live effect delivery.
     * [java.util.WeakHashMap] is not thread-safe and only get/put are used here (never iteration),
     * so a synchronized wrapper suffices.
     */
    private val inboundAdmissionControls:
        MutableMap<Host, java.lang.ref.WeakReference<InboundSubstreamAdmissionControl>> =
        java.util.Collections.synchronizedMap(java.util.WeakHashMap())

    /** Weak host lookup for the aggregate PeerExchange admission diagnostics owned by that host. */
    private val peerExchangeAdmissionScopes: MutableMap<Host, PeerExchangeRequestScope> =
        java.util.Collections.synchronizedMap(java.util.WeakHashMap())

    /**
     * Returns the [InboundSubstreamAdmissionControl] guarding [host]'s inbound
     * substreams, or null if [host] was not built by this factory.
     */
    fun inboundAdmissionControlFor(host: Host): InboundSubstreamAdmissionControl? =
        inboundAdmissionControls[host]?.get()

    /**
     * Returns aggregate PeerExchange admission diagnostics for [host], or null when [host] was not
     * created by [createServerHost]. The weak lookup does not extend the host's lifetime.
     */
    fun peerExchangeAdmissionSnapshotFor(host: Host): PeerExchangeAdmissionSnapshot? =
        peerExchangeAdmissionScopes[host]?.snapshot()

    /**
     * Generates a random Ed25519 private key using [sharedKeyGenSecureRandom],
     * avoiding the per-call `new SecureRandom()` seeding cost that
     * [generateKeyPair] pays on its default path.
     *
     * The `bits` parameter is ignored by Ed25519 (key size is fixed at 32 bytes);
     * we pass 0 positionally to stay compatible with libp2p's default regardless
     * of whether the named arg convention in `generateKeyPair` changes.
     */
    private fun generateRandomEd25519Key(): io.libp2p.core.crypto.PrivKey {
        return generateKeyPair(KeyType.ED25519, 0, sharedKeyGenSecureRandom).first
    }

    /**
     * Generates a deterministic Ed25519 private key from a seed string.
     * The same seed will always produce the same key (and thus the same peer ID).
     *
     * Uses the SHA-256 hash of the seed as the 32-byte Ed25519 private key seed,
     * which guarantees the same seed always produces the same peer ID.
     *
     * @param seed The seed string to derive the key from
     * @return The private key
     */
    fun generateKeyFromSeed(seed: String): io.libp2p.core.crypto.PrivKey {
        // Hash the seed to get exactly 32 bytes for Ed25519 private key
        val seedBytes = java.security.MessageDigest.getInstance("SHA-256")
            .digest(seed.toByteArray(Charsets.UTF_8))

        // Create Ed25519 private key directly from the seed bytes using BouncyCastle
        val privateKeyParams = org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters(seedBytes, 0)
        val publicKeyParams = privateKeyParams.generatePublicKey()

        // Convert to libp2p key format
        val privateKeyBytes = privateKeyParams.encoded
        val publicKeyBytes = publicKeyParams.encoded

        // Create libp2p Ed25519 private key (64 bytes = 32 private + 32 public)
        val combinedBytes = privateKeyBytes + publicKeyBytes
        return io.libp2p.crypto.keys.unmarshalEd25519PrivateKey(combinedBytes)
    }

    /**
     * Creates a new libp2p Host with the given configuration.
     *
     * @param listenAddresses Multiaddresses to listen on (e.g., "/ip4/0.0.0.0/tcp/0")
     * @param protocols Protocol IDs to support
     * @param keyPair Optional key pair for the host identity
     */
    fun createHost(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        protocols: List<String> = listOf(Libp2pRpcProtocol.PROTOCOL_ID),
        keyPair: io.libp2p.core.crypto.PrivKey? = null
    ): Host {
        val admission = InboundSubstreamAdmissionControl(
            MAX_INBOUND_SUBSTREAMS_PER_CONNECTION,
            MAX_INBOUND_SUBSTREAMS_GLOBAL,
            SystemClock(),
            MAX_BACKGROUND_INBOUND_SUBSTREAMS_PER_CONNECTION,
        )
        return host {
            identity {
                // Pre-materialize the key (either caller-supplied or a random
                // Ed25519 generated with the shared SecureRandom) and hand it
                // back via the factory. libp2p's default `random(KeyType.ED25519)`
                // path would otherwise construct a fresh `new SecureRandom()`
                // here — see [sharedKeyGenSecureRandom] for why that matters.
                val resolvedKey = keyPair ?: generateRandomEd25519Key()
                factory = { resolvedKey }
            }

            transports {
                +::TcpTransport
            }

            secureChannels {
                add(::NoiseXXSecureChannel)
            }

            muxers {
                // Prefer Yamux: unlike mplex it has credit/window flow control and an
                // ackBacklogLimit, bounding inbound-substream heap growth at the protocol
                // layer (the recurring ContainerNursery OOM root cause). mplex is retained
                // as a fallback so already-deployed mplex-only peers still negotiate a
                // muxer — this additive ordering prevents partitioning the live url://
                // network. Once the whole fleet advertises Yamux, mplex can be dropped.
                + StreamMuxerProtocol.getYamux()
                + StreamMuxerProtocol.Mplex
            }

            network {
                for (addr in listenAddresses) {
                    listen(addr)
                }
            }

            protocols {
                +Ping()
                +Identify()
                if (protocols.any {
                        it == Libp2pRpcProtocol.PROTOCOL_ID ||
                            it == Libp2pRpcProtocol.PROTOCOL_ID_V11
                    }) {
                    +Libp2pRpcBinding()
                }
                +RelayClientProtocolBinding() // Enables connecting to relay servers as a client
            }

            connectionHandlers {
                // One close-reason record per root connection, reported to this builder's scope.
                +ConnectionCloseReasonRecorder()
            }

            debug {
                // Inbound substream admission control (issue #294): cap live inbound
                // substreams per connection / globally, resetting excess substreams
                // before the multistream Negotiator builds heavy scaffolding.
                streamPreHandler.addHandler(RootLinkStreamObserver())
                streamPreHandler.addHandler(admission)
            }
        }.also { inboundAdmissionControls[it] = java.lang.ref.WeakReference(admission) }
    }

    /**
     * Creates a new libp2p Host with relay protocol support.
     *
     * @param listenAddresses Multiaddresses to listen on
     * @param relayService The relay service to handle relay protocol connections
     */
    fun createHostWithRelay(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        relayService: RelayService,
        keyPair: io.libp2p.core.crypto.PrivKey? = null
    ): Host {
        val admission = InboundSubstreamAdmissionControl(
            MAX_INBOUND_SUBSTREAMS_PER_CONNECTION,
            MAX_INBOUND_SUBSTREAMS_GLOBAL,
            SystemClock(),
            MAX_BACKGROUND_INBOUND_SUBSTREAMS_PER_CONNECTION,
        )
        return host {
            identity {
                // Pre-materialize the key (either caller-supplied or a random
                // Ed25519 generated with the shared SecureRandom) and hand it
                // back via the factory. libp2p's default `random(KeyType.ED25519)`
                // path would otherwise construct a fresh `new SecureRandom()`
                // here — see [sharedKeyGenSecureRandom] for why that matters.
                val resolvedKey = keyPair ?: generateRandomEd25519Key()
                factory = { resolvedKey }
            }

            transports {
                +::TcpTransport
            }

            secureChannels {
                add(::NoiseXXSecureChannel)
            }

            muxers {
                // Prefer Yamux: unlike mplex it has credit/window flow control and an
                // ackBacklogLimit, bounding inbound-substream heap growth at the protocol
                // layer (the recurring ContainerNursery OOM root cause). mplex is retained
                // as a fallback so already-deployed mplex-only peers still negotiate a
                // muxer — this additive ordering prevents partitioning the live url://
                // network. Once the whole fleet advertises Yamux, mplex can be dropped.
                + StreamMuxerProtocol.getYamux()
                + StreamMuxerProtocol.Mplex
            }

            network {
                for (addr in listenAddresses) {
                    listen(addr)
                }
            }

            protocols {
                +Ping()
                +Identify()
                +Libp2pRpcBinding()
                +RelayProtocolBinding(relayService)
                // Client-side relay is handled by RelayProtocolBinding (direct RelayService)
            }

            connectionHandlers {
                // One close-reason record per root connection, reported to this builder's scope.
                +ConnectionCloseReasonRecorder()
            }

            debug {
                // Inbound substream admission control (issue #294): cap live inbound
                // substreams per connection / globally, resetting excess substreams
                // before the multistream Negotiator builds heavy scaffolding.
                streamPreHandler.addHandler(RootLinkStreamObserver())
                streamPreHandler.addHandler(admission)
            }
        }.also { inboundAdmissionControls[it] = java.lang.ref.WeakReference(admission) }
    }

    /**
     * Creates a new libp2p Host with deferred relay protocol support.
     *
     * This allows creating the Host before the RelayService is available.
     * Call [DeferredRelayHandler.setRelayService] after the host is started
     * to enable relay functionality.
     *
     * @param listenAddresses Multiaddresses to listen on
     * @param deferredHandler The deferred handler for relay streams
     */
    fun createHostWithDeferredRelay(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        deferredHandler: DeferredRelayHandler,
        keyPair: io.libp2p.core.crypto.PrivKey? = null,
        includeDefaultRpcBinding: Boolean = true
    ): Host {
        val admission = InboundSubstreamAdmissionControl(
            MAX_INBOUND_SUBSTREAMS_PER_CONNECTION,
            MAX_INBOUND_SUBSTREAMS_GLOBAL,
            SystemClock(),
            MAX_BACKGROUND_INBOUND_SUBSTREAMS_PER_CONNECTION,
        )
        return host {
            identity {
                // Pre-materialize the key (either caller-supplied or a random
                // Ed25519 generated with the shared SecureRandom) and hand it
                // back via the factory. libp2p's default `random(KeyType.ED25519)`
                // path would otherwise construct a fresh `new SecureRandom()`
                // here — see [sharedKeyGenSecureRandom] for why that matters.
                val resolvedKey = keyPair ?: generateRandomEd25519Key()
                factory = { resolvedKey }
            }

            transports {
                +::TcpTransport
            }

            secureChannels {
                add(::NoiseXXSecureChannel)
            }

            muxers {
                // Prefer Yamux: unlike mplex it has credit/window flow control and an
                // ackBacklogLimit, bounding inbound-substream heap growth at the protocol
                // layer (the recurring ContainerNursery OOM root cause). mplex is retained
                // as a fallback so already-deployed mplex-only peers still negotiate a
                // muxer — this additive ordering prevents partitioning the live url://
                // network. Once the whole fleet advertises Yamux, mplex can be dropped.
                + StreamMuxerProtocol.getYamux()
                + StreamMuxerProtocol.Mplex
            }

            network {
                for (addr in listenAddresses) {
                    listen(addr)
                }
            }

            protocols {
                +Ping()
                +Identify()
                if (includeDefaultRpcBinding) {
                    +Libp2pRpcBinding()
                }
                +DeferredRelayProtocolBinding(deferredHandler)
                // Client-side relay is handled by DeferredRelayProtocolBinding (unified protocol)
            }

            connectionHandlers {
                // One close-reason record per root connection, reported to this builder's scope.
                +ConnectionCloseReasonRecorder()
            }

            debug {
                // Inbound substream admission control (issue #294): cap live inbound
                // substreams per connection / globally, resetting excess substreams
                // before the multistream Negotiator builds heavy scaffolding.
                streamPreHandler.addHandler(RootLinkStreamObserver())
                streamPreHandler.addHandler(admission)
            }
        }.also { inboundAdmissionControls[it] = java.lang.ref.WeakReference(admission) }
    }

    /**
     * Creates a Host configured as a server that can accept incoming RPC requests.
     *
     * @param listenAddresses Multiaddresses to listen on
     * @param requestHandler Handler for incoming RPC requests
     * @param keyPair Optional key pair for deterministic peer ID
     * @param deferredRelayHandler Optional handler for incoming relay streams. If provided, the host can
     *        act as a relay server and accept registrations. Call setRelayService() on the handler once
     *        a RelayService is created.
     * @param gossipHandler Optional handler for incoming gossip messages. If provided, service announcements
     *        and peer exchanges will be dispatched to this handler.
     */
    fun createServerHost(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        requestHandler: RpcRequestHandler,
        keyPair: io.libp2p.core.crypto.PrivKey? = null,
        deferredRelayHandler: DeferredRelayHandler? = null,
        gossipHandler: GossipHandler? = null,
        idleTimeoutSeconds: Long = RPC_STREAM_IDLE_TIMEOUT_SECONDS,
        onDirectPeerContact: ((String) -> Unit)? = null
    ): Host = createServerHost(
        listenAddresses = listenAddresses,
        requestHandler = requestHandler,
        keyPair = keyPair,
        deferredRelayHandler = deferredRelayHandler,
        gossipHandler = gossipHandler,
        idleTimeoutSeconds = idleTimeoutSeconds,
        onDirectPeerContact = onDirectPeerContact,
        reconciliationClock = SystemClock(),
    )

    /** Creates a server host with an explicit clock for pending response-write reconciliation. */
    fun createServerHost(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        requestHandler: RpcRequestHandler,
        keyPair: io.libp2p.core.crypto.PrivKey? = null,
        deferredRelayHandler: DeferredRelayHandler? = null,
        gossipHandler: GossipHandler? = null,
        idleTimeoutSeconds: Long = RPC_STREAM_IDLE_TIMEOUT_SECONDS,
        onDirectPeerContact: ((String) -> Unit)? = null,
        reconciliationClock: Clock,
    ): Host = createServerHost(
        listenAddresses, requestHandler, keyPair, deferredRelayHandler, gossipHandler,
        idleTimeoutSeconds, onDirectPeerContact, reconciliationClock, SystemClock(),
    )

    /** Creates a server whose RPC read-idle expiry is driven by [idleClock]. */
    fun createServerHost(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        requestHandler: RpcRequestHandler,
        keyPair: io.libp2p.core.crypto.PrivKey? = null,
        deferredRelayHandler: DeferredRelayHandler? = null,
        gossipHandler: GossipHandler? = null,
        idleTimeoutSeconds: Long = RPC_STREAM_IDLE_TIMEOUT_SECONDS,
        onDirectPeerContact: ((String) -> Unit)? = null,
        reconciliationClock: Clock = SystemClock(),
        idleClock: Clock,
    ): Host {
        // Create a default handler if none provided - this enables all server hosts to act as relays
        val relayHandler = deferredRelayHandler ?: DeferredRelayHandler()

        val admission = InboundSubstreamAdmissionControl(
            MAX_INBOUND_SUBSTREAMS_PER_CONNECTION,
            MAX_INBOUND_SUBSTREAMS_GLOBAL,
            SystemClock(),
            MAX_BACKGROUND_INBOUND_SUBSTREAMS_PER_CONNECTION,
        )
        val requestScope = PeerExchangeRequestScope()
        val announcementScope = OneShotGossipScope()
        return try {
            val delegate = host {
            identity {
                // Pre-materialize the key (either caller-supplied or a random
                // Ed25519 generated with the shared SecureRandom) and hand it
                // back via the factory. libp2p's default `random(KeyType.ED25519)`
                // path would otherwise construct a fresh `new SecureRandom()`
                // here — see [sharedKeyGenSecureRandom] for why that matters.
                val resolvedKey = keyPair ?: generateRandomEd25519Key()
                factory = { resolvedKey }
            }

            transports {
                +::TcpTransport
            }

            secureChannels {
                add(::NoiseXXSecureChannel)
            }

            muxers {
                // Prefer Yamux: unlike mplex it has credit/window flow control and an
                // ackBacklogLimit, bounding inbound-substream heap growth at the protocol
                // layer (the recurring ContainerNursery OOM root cause). mplex is retained
                // as a fallback so already-deployed mplex-only peers still negotiate a
                // muxer — this additive ordering prevents partitioning the live url://
                // network. Once the whole fleet advertises Yamux, mplex can be dropped.
                + StreamMuxerProtocol.getYamux()
                + StreamMuxerProtocol.Mplex
            }

            network {
                for (addr in listenAddresses) {
                    listen(addr)
                }
            }

            protocols {
                +Ping()
                +Identify()
                // Use unified binding that handles both initiator (outgoing) and responder (incoming) roles
                // This ensures incoming gossip messages are properly handled by checking stream.connection.isInitiator
                +UnifiedRpcProtocolBinding(
                    requestHandler,
                    gossipHandler,
                    idleTimeoutSeconds,
                    onDirectPeerContact,
                    requestScope,
                    reconciliationClock,
                    idleClock,
                    announcementScope,
                )
                +DeferredRelayProtocolBinding(relayHandler) // Enables both connecting to relays AND accepting relay registrations
            }

            connectionHandlers {
                // One close-reason record per root connection, reported to this builder's scope.
                +ConnectionCloseReasonRecorder()
            }

            debug {
                // Publish the reconciliation clock on the physical root before any selected
                // protocol can create its outbox, including an incoming relay stream.
                beforeSecureHandler.addHandler(object : io.libp2p.core.ChannelVisitor<Connection> {
                    override fun visit(channel: Connection) {
                        val root = (channel as? io.libp2p.transport.implementation.P2PChannelOverNetty)?.nettyChannel
                            ?: throw IllegalStateException(
                                "Installing the awaited-response reconciliation clock requires a libp2p " +
                                    "connection backed by a Netty channel (P2PChannelOverNetty), but " +
                                    "connection $channel is a ${channel.javaClass.name}"
                            )
                        root.attr(AWAITED_RESPONSE_RECONCILIATION_CLOCK_ATTR).setIfAbsent(reconciliationClock)
                        root.attr(RPC_READ_IDLE_CLOCK_ATTR).setIfAbsent(idleClock)
                    }
                })
                // Inbound substream admission control (issue #294): cap live inbound
                // substreams per connection / globally, resetting excess substreams
                // before the multistream Negotiator builds heavy scaffolding.
                streamPreHandler.addHandler(RootLinkStreamObserver())
                streamPreHandler.addHandler(admission)
            }
            }
            PeerExchangeLifecycleHost(delegate, requestScope, announcementScope).also {
                inboundAdmissionControls[it] = java.lang.ref.WeakReference(admission)
                peerExchangeAdmissionScopes[it] = requestScope
            }
        } catch (failure: Throwable) {
            requestScope.close()
            announcementScope.close()
            throw failure
        }
    }

    /**
     * Creates a Host configured as a server that can accept incoming RPC requests.
     * Returns both the Host and the DeferredRelayHandler so the caller can set up the RelayService.
     *
     * @param listenAddresses Multiaddresses to listen on
     * @param requestHandler Handler for incoming RPC requests
     * @param keyPair Optional key pair for deterministic peer ID
     * @param gossipHandler Optional handler for incoming gossip messages. If provided, service announcements
     *        and peer exchanges will be dispatched to this handler.
     * @return Pair of (Host, DeferredRelayHandler)
     */
    fun createServerHostWithRelayHandler(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        requestHandler: RpcRequestHandler,
        keyPair: io.libp2p.core.crypto.PrivKey? = null,
        gossipHandler: GossipHandler? = null,
        idleTimeoutSeconds: Long = RPC_STREAM_IDLE_TIMEOUT_SECONDS
    ): Pair<Host, DeferredRelayHandler> = createServerHostWithRelayHandler(
        listenAddresses = listenAddresses,
        requestHandler = requestHandler,
        keyPair = keyPair,
        gossipHandler = gossipHandler,
        idleTimeoutSeconds = idleTimeoutSeconds,
        reconciliationClock = SystemClock(),
    )

    /** Creates a relay-enabled server host with an explicit response-write reconciliation clock. */
    fun createServerHostWithRelayHandler(
        listenAddresses: List<String> = listOf("/ip4/0.0.0.0/tcp/0"),
        requestHandler: RpcRequestHandler,
        keyPair: io.libp2p.core.crypto.PrivKey? = null,
        gossipHandler: GossipHandler? = null,
        idleTimeoutSeconds: Long = RPC_STREAM_IDLE_TIMEOUT_SECONDS,
        reconciliationClock: Clock,
    ): Pair<Host, DeferredRelayHandler> {
        val relayHandler = DeferredRelayHandler()
        val host = createServerHost(
            listenAddresses = listenAddresses,
            requestHandler = requestHandler,
            keyPair = keyPair,
            deferredRelayHandler = relayHandler,
            gossipHandler = gossipHandler,
            idleTimeoutSeconds = idleTimeoutSeconds,
            reconciliationClock = reconciliationClock,
        )
        return Pair(host, relayHandler)
    }
}

private data class PublicAddressObservationSnapshot(val address: String, val count: Int)

/**
 * Utility for discovering public IP addresses using the libp2p Identify protocol.
 *
 * When peers connect to us, the Identify protocol (`/ipfs/id/1.0.0`) reports what
 * address they observe us as. This allows NAT-ed nodes to discover their public address
 * without requiring external STUN servers.
 *
 * The [getMostObservedIp] method is always non-blocking — it returns the best known
 * public IP (explicit > observed via Identify) without any external network queries.
 * On initial startup before any peers are contacted, the public IP may be unknown;
 * once a peer connection is established and Identify runs (via [queryObservedAddress]),
 * the observed address becomes available.
 */
object PublicAddressDiscovery {

    private val observedAddresses = ConcurrentHashMap<String, Int>() // address -> count
    private val lock = ReentrantLock()
    @Volatile private var mostObservedAddress: PublicAddressObservationSnapshot? = null


    /**
     * Records an observed address reported by a peer.
     * The most frequently observed address is likely our public address.
     *
     * Loopback addresses (127.0.0.1, ::1) are filtered out because they cannot be
     * reached by external peers. This prevents nodes from announcing loopback
     * addresses via gossip, which would cause connection failures when remote
     * peers try to connect.
     *
     * **Testing Note**: This filtering means that local testing setups where multiple
     * nodes run on localhost at different ports cannot rely on gossip-based address
     * discovery. For local testing of announcement propagation, consider:
     * - Using host aliases in /etc/hosts (e.g., node1.local, node2.local pointing to 127.0.0.1)
     * - Setting up a virtualized network environment (Docker networks, VMs, etc.)
     * - Manually configuring peer addresses in your test code rather than relying on gossip discovery
     *
     * @param address The observed address (what the peer sees us as)
     */
    fun recordObservedAddress(address: Multiaddr) {
        val addrStr = address.toString()
        // Only track addresses that look like public addresses (not localhost, not circuit relay, not wildcard)
        // Filter out:
        // - /127.0.0.1/ : IPv4 loopback (unreachable from other machines)
        // - /0.0.0.0/   : IPv4 wildcard (unspecified)
        // - /::/        : IPv6 wildcard (unspecified)
        // - /::1/       : IPv6 loopback (unreachable from other machines)
        // - /p2p-circuit/ : circuit relay addresses (not direct observations)
        if (!addrStr.contains("/127.0.0.1/") &&
            !addrStr.contains("/0.0.0.0/") &&
            !addrStr.contains("/p2p-circuit/") &&
            !addrStr.contains("/::/") &&
            !addrStr.contains("/::1/") &&
            (addrStr.contains("/ip4/") || addrStr.contains("/ip6/"))) {
            val count = lock.withLock {
                val updatedCount = observedAddresses.compute(addrStr) { _, count -> (count ?: 0) + 1 }!!
                val current = mostObservedAddress
                if (updatedCount == Int.MIN_VALUE && current?.address == addrStr) {
                    // Preserve the existing Int count ordering if a counter wraps.
                    mostObservedAddress = observedAddresses.maxByOrNull { it.value }?.let {
                        PublicAddressObservationSnapshot(it.key, it.value)
                    }
                } else if (current == null || updatedCount > current.count) {
                    mostObservedAddress = PublicAddressObservationSnapshot(addrStr, updatedCount)
                }
                updatedCount
            }
            if (urlProtocolDebugLogging) {
                val output = System.out
                output.println("[IDENTIFY] Recorded observed address: $addrStr (count: $count)")
                val failed = output.checkError()
                if (Thread.currentThread().isInterrupted) {
                    throw java.io.InterruptedIOException(
                        "Interrupted while writing observed-address debug output for $addrStr (count: $count)"
                    )
                }
                check(!failed) {
                    "Failed to write observed-address debug output for $addrStr (count: $count)"
                }
            }
        }
    }

    /**
     * Records an observed address from a string.
     */
    fun recordObservedAddress(address: String) {
        val parsed = try {
            Multiaddr(address)
        } catch (e: Exception) {
            // Invalid address strings are ignored; recording and output failures must propagate.
            return
        }
        recordObservedAddress(parsed)
    }

    /**
     * Returns the most frequently observed public address, if any.
     */
    fun getMostObservedAddress(): Multiaddr? =
        mostObservedAddress?.address?.let {
            try { Multiaddr(it) } catch (e: Exception) { null }
        }

    /**
     * Returns just the IP portion of the most observed address (e.g., "198.199.106.165").
     *
     * This method is non-blocking. It checks (in priority order):
     * 1. Explicit public IP (set via [setExplicitPublicIp])
     * 2. Most frequently observed address from connected peers (via Identify protocol)
     *
     * If no public IP is known yet (e.g., before any peer connections), returns null.
     * The public IP becomes available after the first peer connection, when the
     * Identify protocol reports our observed address (via [queryObservedAddress]).
     */
    fun getMostObservedIp(): String? {
        // Priority 1: Explicit public IP
        explicitPublicIp?.let { return it }

        // Priority 2: Peer-observed address (Identify protocol)
        val addr = getMostObservedAddress()?.toString()
        if (addr != null) {
            // Extract IP from format like /ip4/198.199.106.165/tcp/40619
            val ip4Match = Regex("/ip4/([^/]+)/").find(addr)
            if (ip4Match != null) return ip4Match.groupValues[1]
            val ip6Match = Regex("/ip6/([^/]+)/").find(addr)
            if (ip6Match != null) return ip6Match.groupValues[1]
        }

        return null
    }

    /**
     * Returns all observed addresses with their observation counts.
     */
    fun getAllObservedAddresses(): Map<String, Int> {
        lock.withLock {
            return observedAddresses.toMap()
        }
    }

    /**
     * Clears all recorded observations. Useful for resetting after network changes.
     */
    fun clear() {
        lock.withLock {
            observedAddresses.clear()
            mostObservedAddress = null
        }
    }

    // Explicit public IP set via setExplicitPublicIp()
    @Volatile
    private var explicitPublicIp: String? = null

    /**
     * Sets an explicit public IP address to use for announce addresses.
     * This overrides observed addresses from the Identify protocol.
     *
     * @param ip The public IP address (e.g., "198.199.106.165")
     */
    fun setExplicitPublicIp(ip: String?) {
        explicitPublicIp = ip
        if (ip != null) {
            debugLog { "[PUBLIC-IP] Set explicit public IP: $ip" }
        } else {
            debugLog { "[PUBLIC-IP] Cleared explicit public IP" }
        }
    }

    /**
     * Gets the explicit public IP address if set.
     *
     * @return The explicit public IP, or null if not set
     */
    fun getExplicitPublicIp(): String? = explicitPublicIp

    /**
     * Lowest-priority source used by [getEffectiveAddresses] to resolve a wildcard listen address
     * when neither an explicit public IP nor an Identify observation is available yet: this node's own
     * routable (non-loopback, non-link-local, non-private) local-interface IPv4, or null if it has
     * none. Defaults to enumerating the host's real network interfaces; injectable so tests can supply
     * a deterministic value without depending on the machine's actual interfaces.
     *
     * Returning a globally-routable address only (private/CGNAT ranges rejected) is what makes this
     * safe as a fallback: a NAT'd node, whose NIC holds only an RFC-1918 address, gets null here and
     * stays relay-only — it does not advertise an unreachable private address.
     */
    @Volatile
    var routableLocalIpv4Provider: () -> String? = ::enumerateRoutableLocalIpv4

    private fun enumerateRoutableLocalIpv4(): String? =
        try {
            java.net.NetworkInterface.getNetworkInterfaces().asSequence()
                .filter { runCatching { it.isUp && !it.isLoopback }.getOrDefault(false) }
                .flatMap { it.inetAddresses.asSequence() }
                .filterIsInstance<java.net.Inet4Address>()
                .mapNotNull { it.hostAddress?.substringBefore('%') }
                .firstOrNull { isRoutableIpv4(it) }
        } catch (e: Exception) {
            null
        }

    /**
     * True iff [ip] is a globally-routable IPv4 address — i.e. NOT loopback (127/8), link-local
     * (169.254/16), CGNAT (100.64/10), or RFC-1918 private (10/8, 172.16/12, 192.168/16). Only such an
     * address is useful to advertise to remote peers.
     */
    private fun isRoutableIpv4(ip: String): Boolean {
        val octets = ip.split(".")
        if (octets.size != 4) return false
        val o = octets.map { it.toIntOrNull() ?: return false }
        if (o.any { it !in 0..255 }) return false
        return when {
            o[0] == 127 -> false                       // loopback
            o[0] == 169 && o[1] == 254 -> false         // link-local
            o[0] == 10 -> false                         // private 10/8
            o[0] == 172 && o[1] in 16..31 -> false      // private 172.16/12
            o[0] == 192 && o[1] == 168 -> false         // private 192.168/16
            o[0] == 100 && o[1] in 64..127 -> false     // CGNAT 100.64/10
            o[0] == 0 -> false                          // "this host"
            else -> true
        }
    }


    /**
     * Gets effective addresses for a host by replacing wildcard addresses with the observed public IP.
     *
     * For example, if we're listening on /ip4/0.0.0.0/tcp/40619 and peers observe us as
     * /ip4/198.199.106.165/tcp/40619, this returns the public address.
     *
     * This method is non-blocking. If no explicit IP and no Identify observation is available, it
     * resolves the wildcard against this node's own routable local-interface IPv4
     * ([routableLocalIpv4Provider]); only if that is also absent (e.g. a NAT'd node whose NIC holds
     * only a private IP) are wildcard addresses filtered out entirely, leaving non-wildcard addresses
     * (e.g. relay addresses). After the first peer connection establishes an Identify observation,
     * subsequent calls prefer the observed public address.
     *
     * Loopback addresses (127.0.0.1, ::1) are filtered out because they cannot be
     * reached by external peers. See [recordObservedAddress] for testing workarounds.
     *
     * @param listenAddresses The addresses the host is listening on
     * @param peerId The host's peer ID (to append /p2p/ suffix)
     * @return List of effective addresses with wildcards replaced (loopback addresses excluded)
     */
    fun getEffectiveAddresses(listenAddresses: List<Multiaddr>, peerId: String): List<String> {
        // Priority: explicit IP > observed IP via Identify > this node's own routable local interface
        // IP (all non-blocking). The local-interface fallback is LAST so it never overrides an
        // explicit IP or an Identify observation — a NAT'd node (whose NIC holds only a private IP)
        // returns null here and correctly stays relay-only until Identify learns its public IP. But a
        // host with a routable IP directly on its interface (e.g. a cloud droplet) can advertise a
        // reachable direct address from its very FIRST announcement, instead of being relay-only until
        // an outbound dial happens to populate the Identify observation — a race that left
        // register-and-wait providers (e.g. a netlab worker) unreachable when a peer health-checked
        // them inside that window.
        val publicIp = explicitPublicIp ?: getMostObservedIp() ?: routableLocalIpv4Provider()
        return listenAddresses.mapNotNull { addr ->
            var addrStr = addr.toString()

            // Filter out loopback addresses - they cannot be reached by external peers
            // and would cause connection failures if announced via gossip
            if (addrStr.contains("/127.0.0.1/") || addrStr.contains("/::1/")) {
                return@mapNotNull null
            }

            // If we have a public IP and this is a wildcard address, replace it
            if (publicIp != null) {
                when {
                    addrStr.contains("/ip4/0.0.0.0/") -> {
                        addrStr = addrStr.replace("/ip4/0.0.0.0/", "/ip4/$publicIp/")
                    }
                    addrStr.contains("/ip6/::/") -> {
                        // For IPv6 wildcard, replace with observed IPv4 if available
                        // (most servers have IPv4 public addresses)
                        addrStr = addrStr.replace("/ip6/::/", "/ip4/$publicIp/")
                    }
                }
            } else {
                // No public IP known - filter out wildcard addresses entirely
                // They're useless without being resolved to a real address
                if (addrStr.contains("/ip4/0.0.0.0/") || addrStr.contains("/ip6/::/")) {
                    return@mapNotNull null
                }
            }

            // Add peer ID suffix if not already present
            if (!addrStr.contains("/p2p/")) {
                addrStr = "$addrStr/p2p/$peerId"
            }

            addrStr
        }
    }
}

/**
 * Queries the Identify protocol on a connected peer to discover our observed address.
 *
 * After connecting to a peer, call this to learn what address they see us as.
 * This is useful for discovering our public IP when behind NAT or when listening on 0.0.0.0.
 *
 * @param host The local host
 * @param remotePeerId The peer ID to query (base58 encoded)
 * @param remoteMultiaddr Optional multiaddr for the remote peer
 * @return The observed address string, or null if unavailable
 */
fun queryObservedAddress(host: Host, remotePeerId: String, remoteMultiaddr: Multiaddr? = null): String? {
    return try {
        val peerId = io.libp2p.core.PeerId.fromBase58(remotePeerId)

        // Use provided multiaddr or find one from existing connections
        val addr = remoteMultiaddr ?: run {
            val connection = host.network.connections.find {
                it.secureSession().remoteId.toBase58() == remotePeerId
            } ?: return null
            connection.remoteAddress()
        }

        // Dial the Identify protocol on the peer
        val streamFuture = host.newStream<IdentifyController>(
            listOf("/ipfs/id/1.0.0"),
            peerId,
            addr
        )

        // Get the controller and query the Identify message
        val controller = streamFuture.controller.get(10, TimeUnit.SECONDS)
        val identifyMsg = controller.id().get(10, TimeUnit.SECONDS)

        // Extract the observed address
        val observedAddrBytes = identifyMsg.observedAddr
        if (observedAddrBytes != null && !observedAddrBytes.isEmpty) {
            // Deserialize multiaddr from protobuf bytes
            val observedAddr = Multiaddr.deserialize(observedAddrBytes.toByteArray())
            val observedAddrStr = observedAddr.toString()

            // Record this observed address for future use (explicitly use String version to avoid ambiguity)
            PublicAddressDiscovery.recordObservedAddress(observedAddrStr)

            debugLog { "[IDENTIFY] Peer $remotePeerId observes us as: $observedAddrStr" }
            return observedAddrStr
        }

        null
    } catch (e: Exception) {
        debugLog { "[IDENTIFY] Failed to query observed address from $remotePeerId: ${e.message}" }
        null
    }
}

/**
 * Queries the Identify protocol on a peer after making a connection and records the observed address.
 * This is a convenience function that should be called after successful connections.
 *
 * @param host The local host
 * @param remotePeerId The peer ID we connected to (base58 encoded)
 * @param remoteMultiaddr The multiaddr we used to connect
 */
fun queryAndRecordObservedAddress(host: Host, remotePeerId: String, remoteMultiaddr: Multiaddr) {
    // Run in a background thread to not block the caller
    thread(name = "identify-query-$remotePeerId", isDaemon = true) {
        try {
            queryObservedAddress(host, remotePeerId, remoteMultiaddr)
        } catch (e: Exception) {
            // Ignore errors - this is best-effort
        }
    }
}

/**
 * Configuration for explicit announce addresses.
 *
 * Use this when you know your public IP and want to announce it directly,
 * rather than relying on Identify protocol discovery.
 */
object AnnounceAddressConfig {

    private var explicitAddresses: List<String> = emptyList()

    /**
     * Sets explicit announce addresses.
     * These will be used instead of (or in addition to) listen addresses.
     *
     * @param addresses List of multiaddresses to announce (e.g., "/ip4/198.199.106.165/tcp/40619")
     */
    fun setAnnounceAddresses(addresses: List<String>) {
        explicitAddresses = addresses.toList()
        debugLog { "[ANNOUNCE] Configured explicit announce addresses: $addresses" }
    }

    /**
     * Gets the configured explicit announce addresses.
     */
    fun getAnnounceAddresses(): List<String> = explicitAddresses

    /**
     * Returns true if explicit announce addresses are configured.
     */
    fun hasExplicitAddresses(): Boolean = explicitAddresses.isNotEmpty()

    /**
     * Gets effective addresses for announcement, combining explicit addresses
     * with listen addresses (replacing wildcards with observed IP if available).
     *
     * @param listenAddresses The addresses the host is listening on
     * @param peerId The host's peer ID
     * @return List of addresses suitable for announcement
     */
    fun getEffectiveAnnounceAddresses(listenAddresses: List<Multiaddr>, peerId: String): List<String> {
        // If explicit addresses are configured, use them
        if (hasExplicitAddresses()) {
            return explicitAddresses.map { addr ->
                if (!addr.contains("/p2p/")) "$addr/p2p/$peerId" else addr
            }
        }

        // Otherwise, use PublicAddressDiscovery to replace wildcards
        return PublicAddressDiscovery.getEffectiveAddresses(listenAddresses, peerId)
    }
}

/**
 * Controller for managing an RPC stream with proper bidirectional communication.
 */
interface Libp2pRpcController {
    val input: InputStream
    val output: OutputStream

    /**
     * The libp2p protocol id multistream-select negotiated for this stream —
     * either [Libp2pRpcProtocol.PROTOCOL_ID_V11] ("/aicli-rpc/1.1.0") or
     * [Libp2pRpcProtocol.PROTOCOL_ID] ("/aicli-rpc/1.0.0") — or null when it
     * could not be determined.
     *
     * Senders consult this to decide how to encode ByteArray request params:
     * raw out-of-band binary attachments on 1.1.0, or base64-in-JSON on 1.0.0
     * (or when null). Server-side (NoOp) controllers report null.
     */
    val negotiatedProtocolId: String? get() = null

    fun close()
}

/**
 * Uses the bounded frame writer when the controller is backed by a Netty/libp2p stream and keeps
 * the legacy aggregate-output behavior for every other [Libp2pRpcController] implementation.
 *
 * This is deliberately an internal capability dispatch rather than a method on the published
 * controller interface. Implementations compiled against earlier UrlProtocol releases therefore
 * remain binary-compatible and continue through the aggregate fallback.
 */
private fun interface RpcControllerFrameWriter {
    fun write(jsonBytes: ByteArray, attachments: List<ByteArray>)
}

private fun interface RpcControllerParentCloseRegistrar {
    fun completeAfterParentClose(completion: () -> Unit)
}

private val rpcControllerFrameWriters = WeakIdentityRegistry<
    Libp2pRpcController, java.lang.ref.WeakReference<RpcControllerFrameWriter>>()
private val rpcControllerParentCloseRegistrars = WeakIdentityRegistry<
    Libp2pRpcController, java.lang.ref.WeakReference<RpcControllerParentCloseRegistrar>>()
private val rpcControllerFrameAdmissions = WeakIdentityRegistry<Libp2pRpcController, FrameAdmission>()

internal fun rpcControllerFrameAdmission(controller: Libp2pRpcController): FrameAdmission =
    rpcControllerFrameAdmissions.getOrPut(controller) { FrameAdmission() }

internal fun closeRpcControllerFrameAdmission(controller: Libp2pRpcController, cause: IOException? = null) {
    val admission = rpcControllerFrameAdmission(controller)
    if (cause == null) admission.close() else admission.close(cause)
}

private fun registerRpcControllerFrameWriter(
    controller: Libp2pRpcController,
    writer: RpcControllerFrameWriter
) {
    rpcControllerFrameWriters[controller] = java.lang.ref.WeakReference(writer)
}

private fun registerRpcControllerParentCloseRegistrar(
    controller: Libp2pRpcController,
    registrar: RpcControllerParentCloseRegistrar,
) {
    rpcControllerParentCloseRegistrars[controller] = java.lang.ref.WeakReference(registrar)
}

internal fun completeRpcResponseAfterParentClose(
    controller: Libp2pRpcController,
    completion: () -> Unit,
) {
    val registrar = rpcControllerParentCloseRegistrars[controller]?.get()
    if (registrar == null) {
        completion()
    } else {
        registrar.completeAfterParentClose(completion)
    }
}

internal fun withRpcControllerRawOutput(
    controller: Libp2pRpcController,
    write: (OutputStream) -> Unit,
) {
    val output = controller.output
    if (rpcControllerFrameWriters[controller]?.get() != null) {
        // Native output already shares its stream admission with segmented writes. Adding
        // another frame owner here would outlive the native observer notification scope.
        write(output)
    } else {
        rpcControllerFrameAdmission(controller).withFrame { write(output) }
    }
}

internal fun writeRpcControllerMessage(
    controller: Libp2pRpcController,
    json: JSONObject,
    attachments: List<ByteArray>
) {
    // Encoding can call caller-owned JSONString values, including reentrant protocol close.
    // Neither the real controller nor a compatibility controller may hold output ownership here.
    writeRpcControllerMessage(controller, jsonWireBytes(json), attachments)
}

/** Like the [JSONObject] overload, for a message whose JSON is already [jsonBytes]. */
internal fun writeRpcControllerMessage(
    controller: Libp2pRpcController,
    jsonBytes: ByteArray,
    attachments: List<ByteArray>
) {
    val frameWriter = rpcControllerFrameWriters[controller]?.get()
    if (frameWriter != null) {
        frameWriter.write(jsonBytes, attachments)
    } else {
        val output = controller.output
        rpcControllerFrameAdmission(controller).withFrame {
            // Only the admitted writer materializes a complete compatibility frame. The state
            // monitor is released before invoking any supplied output method.
            val frameSize = 4 + jsonBytes.size + if (attachments.isEmpty()) 0 else
                4 + attachments.sumOf { 4 + it.size }
            val frame = ByteArrayOutputStream(frameSize)
            Libp2pRpcProtocol.writeEncodedMessageStreamingAttachments(frame, jsonBytes, attachments)
            frame.writeTo(output)
            output.flush()
        }
    }
}

/**
 * Client-side binding for RPC connections, announcing BOTH the attachment-capable
 * /aicli-rpc/1.1.0 and the legacy /aicli-rpc/1.0.0 protocols. multistream-select
 * negotiates the best the peer also supports; the negotiated id is threaded into
 * the [NettyStreamController] so the sender can pick the wire encoding.
 *
 * A SINGLE binding matching both ids is required for the initiator:
 * Host.newStream(protocols) selects ONE registered binding whose descriptor
 * matches any offered protocol and then uses only that binding's matcher to
 * accept the server's selection. Two single-protocol bindings would let
 * newStream pick the 1.0.0 binding and then reject a 1.1.0 selection with
 * NoSuchLocalProtocolException.
 */
class Libp2pRpcBinding : ProtocolBinding<Libp2pRpcController> {
    override val protocolDescriptor = ProtocolDescriptor(
        listOf(Libp2pRpcProtocol.PROTOCOL_ID_V11, Libp2pRpcProtocol.PROTOCOL_ID)
    )

    override fun initChannel(
        ch: io.libp2p.core.P2PChannel,
        selectedProtocol: String
    ): CompletableFuture<Libp2pRpcController> {
        val stream = ch as? Stream
            ?: return CompletableFuture.failedFuture(IllegalArgumentException("Expected Stream"))
        return CompletableFuture.completedFuture(NettyStreamController(stream, selectedProtocol))
    }
}

/**
 * No-op controller returned for server-side NIO streams.
 * Server-side streams are handled by [RpcServerMessageHandler] in the Netty pipeline,
 * so there is no need for client-facing input/output streams.
 */
private object NoOpRpcController : Libp2pRpcController {
    override val input: InputStream get() = error("Server-side NIO handler has no input stream")
    override val output: OutputStream get() = error("Server-side NIO handler has no output stream")
    override fun close() {}
}

/**
 * Monotonic suffix that disambiguates [ServiceClientConnection.connectionId] across
 * two server-side connections from the same remote peer (or after a reconnection),
 * so a captured push sender never aliases a later connection.
 */
private val serverConnectionIdCounter = java.util.concurrent.atomic.AtomicLong(0)

private fun nextServerConnectionId(): Long = serverConnectionIdCounter.incrementAndGet()

/**
 * Shared daemon executor that runs registered [ServiceClientConnection.onClose] listeners away
 * from transport threads. Libp2p close publication starts on a Netty event loop, while TCP close
 * publication starts on a connection reader or the caller of `TcpServer.stop()`; none of those
 * threads may wait for application callbacks. The once-only flag is still flipped synchronously
 * under each connection's close lock before tasks are submitted. A handful of threads that time
 * out when idle isolate a slow listener from other connection handling, and the unbounded queue
 * prevents rejected work from falling back onto a transport thread. Listeners are still expected
 * to be fast — see [ServiceClientConnection.onClose].
 */
internal val closeListenerDispatcher: java.util.concurrent.ExecutorService = run {
    val threadCount = 4
    val counter = java.util.concurrent.atomic.AtomicLong(0)
    java.util.concurrent.ThreadPoolExecutor(
        threadCount, threadCount,
        60L, java.util.concurrent.TimeUnit.SECONDS,
        java.util.concurrent.LinkedBlockingQueue<Runnable>()
    ).apply {
        threadFactory = java.util.concurrent.ThreadFactory { r ->
            Thread(r, "url-conn-close-listener-${counter.incrementAndGet()}").apply { isDaemon = true }
        }
        allowCoreThreadTimeOut(true)
    }
}

/**
 * Off-event-loop executor for inbound JSON parse-memory admission. Its only users are the two JSON
 * pause-and-admit paths — [ParseBudgetedJsonFrameDecoder]'s 1.0.0 length-delimited frames and
 * [AttachmentRpcFrameDecoder]'s 1.1.0 JSON envelopes. Attachment frames do NOT use it: their
 * admission is callback-driven through `FrameAttachmentLease.acquireAsync` and occupies no thread.
 *
 * When a decoder's non-blocking [Libp2pRpcProtocol.FrameParseLease] fast path is refused, the
 * blocking retry must NOT run on the Netty event loop (that would stall every stream on the
 * connection — and can deadlock against an InputStream reader that owns the pool and needs this
 * event loop to feed it). The decoder therefore pauses reads and performs the blocking acquire
 * here, re-driving itself on the event loop once admitted. Threads time out when idle so the pool
 * costs nothing at rest; the queue is unbounded so an admission task is never rejected. At most one
 * admission is in flight per inbound substream, because the decoder short-circuits while
 * `awaitingAdmission` is set.
 */
private val jsonAdmissionExecutor: java.util.concurrent.ExecutorService = run {
    val counter = java.util.concurrent.atomic.AtomicLong(0)
    // BOUNDED pool with an unbounded QUEUE: a burst of substreams under pool pressure enqueues
    // admission tasks rather than spawning one platform thread per blocked substream (which would
    // convert the bounded byte budget into unbounded native thread/stack allocation). Several JSON
    // admissions can be granted concurrently (unlike a whole-pool attachment lease, a right-sized
    // JSON reservation is not exclusive), so up to threadCount of them may sit in
    // parseMemoryBudget.acquire at once and the rest queue.
    //
    // That queue cannot deadlock, because NOTHING the waiters depend on needs a thread from this
    // pool. Every reservation they are waiting to see released is released elsewhere: a completed
    // frame's lease is closed by the server handler's dispatch path or by handlerRemoved0 on
    // teardown, and a reservation held across a body that never finishes arriving is bounded by
    // JsonBodyArrivalGuard, whose watchdog runs on the shared stall scheduler and closes the
    // channel. So the pool always drains on its own and a queued admission eventually runs.
    // Idle threads are reaped.
    val threadCount = 8
    java.util.concurrent.ThreadPoolExecutor(
        threadCount, threadCount,
        60L, java.util.concurrent.TimeUnit.SECONDS,
        java.util.concurrent.LinkedBlockingQueue<Runnable>()
    ).apply {
        threadFactory = java.util.concurrent.ThreadFactory { r ->
            Thread(r, "url-json-admission-${counter.incrementAndGet()}").apply { isDaemon = true }
        }
        allowCoreThreadTimeOut(true)
    }
}

/** A decoded inbound body that retains its shared parse-memory lease through dispatch. */
internal class ParseBudgetedInboundMessage(
    val bodyBytes: ByteArray?,
    val messageFrame: Libp2pRpcProtocol.MessageFrame?,
    private val lease: AutoCloseable,
    val retainedBytesEstimate: Long,
) : AutoCloseable {
    constructor(
        bodyBytes: ByteArray?,
        messageFrame: Libp2pRpcProtocol.MessageFrame?,
        lease: Libp2pRpcProtocol.FrameParseLease,
    ) : this(bodyBytes, messageFrame, AutoCloseable { lease.close() },
        lease.frameBytes.toLong() * Libp2pRpcProtocol.PARSE_AMPLIFICATION)

    override fun close() { lease.close() }
}

/**
 * Minimum-progress and absolute-deadline guard for an inbound JSON body whose shared parse-memory
 * reservation is ALREADY held while the body itself is still arriving.
 *
 * Both inbound decoders size that reservation from the 4-byte length header, before the body is
 * complete, and release it when the frame completes or the handler leaves the pipeline. Nothing else
 * bounds the gap: the transport idle timer is reset by any byte, so a peer that declares a
 * pool-sized frame and then stops — or dribbles one byte at a time — retains the whole process pool
 * and starves every other inbound JSON frame. This is the same exposure the attachment path closes
 * with its stall watchdog, so it reuses that machinery verbatim (the shared scheduler, the injectable
 * clock, the minimum-progress timeout, and the throughput-derived absolute deadline) rather than
 * introducing another timeout knob.
 */
private class JsonBodyArrivalGuard {
    private var watchdog: java.util.concurrent.ScheduledFuture<*>? = null
    private val lastProgressMs = java.util.concurrent.atomic.AtomicLong(0L)
    private var lastProgressWriterIndex = 0
    private var armedAtMs = 0L

    /**
     * Arms the guard for a reservation held while [jsonLength] bytes of body are still arriving.
     * Idempotent while already armed. On a stall (or a sub-floor dribble past the absolute
     * deadline) it closes the channel, whose teardown releases the reservation.
     */
    fun arm(
        ctx: ChannelHandlerContext,
        lease: Libp2pRpcProtocol.FrameParseLease,
        jsonLength: Int,
        writerIndex: Int
    ) {
        if (watchdog != null) return
        val nowMs = Libp2pRpcProtocol.attachmentClock.currentTimeMillis()
        armedAtMs = nowMs
        lastProgressMs.set(nowMs)
        lastProgressWriterIndex = writerIndex
        val deadlineMs = Libp2pRpcProtocol.attachmentLeaseDeadlineMs(jsonLength.toLong())
        watchdog = Libp2pRpcProtocol.scheduleAttachmentStallWatchdog(Runnable {
            if (!lease.isHeld) return@Runnable
            val checkMs = Libp2pRpcProtocol.attachmentClock.currentTimeMillis()
            if (
                checkMs - lastProgressMs.get() > Libp2pRpcProtocol.ATTACHMENT_STALL_TIMEOUT_MS ||
                checkMs - armedAtMs > deadlineMs
            ) {
                ctx.channel().close()
            }
        })
    }

    /** Records growth of the buffered bytes as arrival progress, resetting the stall budget. */
    fun recordProgress(writerIndex: Int) {
        if (watchdog == null || writerIndex <= lastProgressWriterIndex) return
        lastProgressWriterIndex = writerIndex
        lastProgressMs.set(Libp2pRpcProtocol.attachmentClock.currentTimeMillis())
    }

    /** Disarms the guard once no reservation is held for an incomplete body. Idempotent. */
    fun disarm() {
        watchdog?.cancel(false)
        watchdog = null
        lastProgressWriterIndex = 0
    }
}

private data class RpcIdleCompletions(
    val count: Int,
    val completedAtNanos: Long,
    val parentPausedNanos: Long,
    val activityRevision: Long,
)

/** Identity is the timer generation, including clock registrations that return after cancellation. */
private class RpcIdleCheck(val deadlineMillis: Long, val rejectedSubmissions: Long = 0L) {
    val scheduled = AtomicReference<Scheduled?>()
}

/**
 * Read timeout for peer silence with neither pending RPC work nor a server-side read pause.
 *
 * The host clock schedules idle checks even while a channel is in manual-read mode. Child-owned pauses
 * retain the existing re-arm behavior, while a physical-parent admission pause contributes only
 * its observed duration and never renews the child's idle budget without child bytes arriving.
 */
private class PauseAwareReadTimeoutHandler(
    idleTimeoutSeconds: Long,
    private val clock: Clock
) : ChannelDuplexHandler() {
    private val idleTimeoutMillis = TimeUnit.SECONDS.toMillis(idleTimeoutSeconds)
    private val idleTimeoutNanos = TimeUnit.MILLISECONDS.toNanos(idleTimeoutMillis)
    // Completion publication has its own ownership, independent of the released request permit.
    // Only this bounded aggregate is written by completing threads; the loop drains it below.
    private val unappliedCompletions = AtomicReference<RpcIdleCompletions?>()
    @Volatile
    private var activityRevision = 0L
    // The loop owns activity accounting. Both the loop and clock may replace a timer ticket;
    // only the current ticket may submit a check or retain a newly registered callback.
    private val idleCheck = AtomicReference<RpcIdleCheck?>()
    /** All state below belongs to the child's event loop. Clock callbacks only enqueue work. */
    private val serverReadPauseOwners: MutableSet<Any> =
        java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Any, Boolean>())
    private var lastActivityAtNanos: Long = 0L
    private var parentPausedNanosAtLastActivity: Long = 0L
    private var stopped = false
    private var pendingRpcRequests = 0

    /** Pending handlers and their awaited response writes are activity, even without peer bytes. */
    fun onRpcRequestStarted(ctx: ChannelHandlerContext) {
        applyRpcCompletions(ctx)
        if (stopped) return
        pendingRpcRequests++
        // Keep the existing idle check as a reconciliation point if a completion's loop
        // submission is rejected. checkIdle never expires a child with pending handlers.
        if (idleCheck.get() == null) scheduleCheck(ctx, idleTimeoutMillis)
    }

    /** Publish before execute: a rejected notification must leave its completion owned. */
    fun recordRpcCompletion(ctx: ChannelHandlerContext) {
        unappliedCompletions.updateAndGet { previous ->
            val revision = activityRevision
            val nowNanos = TimeUnit.MILLISECONDS.toNanos(clock.currentTimeMillis())
            RpcIdleCompletions(
                (previous?.count ?: 0) + 1,
                nowNanos,
                parentPausedNanosThrough(ctx, nowNanos),
                revision,
            )
        }
    }

    /** Only the event loop applies completions and begins the final response's idle interval. */
    fun applyRpcCompletions(ctx: ChannelHandlerContext, rearmIdle: Boolean = true) {
        val completed = unappliedCompletions.getAndSet(null) ?: return
        if (stopped) return
        check(pendingRpcRequests >= completed.count) {
            "RPC idle accounting completed ${completed.count} requests but only $pendingRpcRequests were pending"
        }
        pendingRpcRequests -= completed.count
        if (pendingRpcRequests == 0) {
            // A later read or pause transition already owns a newer activity epoch. Compare
            // revisions rather than timestamps so a clock correction preserves that ordering.
            if (completed.activityRevision == activityRevision) {
                lastActivityAtNanos = completed.completedAtNanos
                parentPausedNanosAtLastActivity = completed.parentPausedNanos
                activityRevision++
            }
            cancelCheck()
            if (rearmIdle) scheduleCheck(ctx, remainingIdleMillis(ctx))
        }
        ctx.pipeline().context(RpcServerMessageHandler::class.java)?.let { serverContext ->
            (serverContext.handler() as RpcServerMessageHandler).resumeRequestAdmission(serverContext)
        }
    }

    override fun handlerAdded(ctx: ChannelHandlerContext) {
        recordActivity(ctx)
        if (ctx.channel().isActive) scheduleCheck(ctx, idleTimeoutMillis)
    }

    override fun channelActive(ctx: ChannelHandlerContext) {
        if (idleCheck.get() == null && !stopped) {
            recordActivity(ctx)
            scheduleCheck(ctx, idleTimeoutMillis)
        }
        ctx.fireChannelActive()
    }

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        applyRpcCompletions(ctx)
        recordActivity(ctx)
        ctx.fireChannelRead(msg)
    }

    override fun write(ctx: ChannelHandlerContext, msg: Any, promise: ChannelPromise) {
        applyRpcCompletions(ctx)
        ctx.write(msg, promise)
    }

    private fun recordActivity(ctx: ChannelHandlerContext) {
        activityRevision++
        val nowNanos = TimeUnit.MILLISECONDS.toNanos(clock.currentTimeMillis())
        lastActivityAtNanos = nowNanos
        parentPausedNanosAtLastActivity = parentPausedNanosThrough(ctx, nowNanos)
    }

    /** Each pause owner affects only this child; capacity waits do not renew its idle budget. */
    fun onServerReadPauseChanged(ctx: ChannelHandlerContext, owner: Any, paused: Boolean): Boolean {
        applyRpcCompletions(ctx)
        if (paused) serverReadPauseOwners.add(owner) else serverReadPauseOwners.remove(owner)
        recordActivity(ctx)
        return serverReadPauseOwners.isNotEmpty()
    }

    private fun scheduleCheck(ctx: ChannelHandlerContext, delayMillis: Long) {
        if (idleTimeoutMillis <= 0L || stopped || !ctx.channel().isOpen || ctx.executor().isShuttingDown) return
        // Admission resume can re-enter reads and arm a check before its caller returns.
        // Replacing that check must release its callback as well as invalidate its generation.
        val check = RpcIdleCheck(clock.currentTimeMillis() + delayMillis)
        idleCheck.getAndSet(check)?.scheduled?.getAndSet(null)?.cancel()
        armCheck(ctx, check, check.deadlineMillis)
    }

    private fun armCheck(ctx: ChannelHandlerContext, check: RpcIdleCheck, atMillis: Long) {
        val scheduled = clock.schedule(atMillis) {
            if (idleCheck.get() !== check) return@schedule
            if (!ctx.channel().isOpen || ctx.executor().isShuttingDown) {
                if (idleCheck.compareAndSet(check, null)) check.scheduled.getAndSet(null)?.cancel()
                return@schedule
            }
            try {
                ctx.executor().execute {
                    if (!idleCheck.compareAndSet(check, null)) return@execute
                    check.scheduled.getAndSet(null)?.cancel()
                    checkIdle(ctx)
                }
            } catch (rejection: java.util.concurrent.RejectedExecutionException) {
                if (!ctx.channel().isOpen || ctx.executor().isShuttingDown) {
                    if (idleCheck.compareAndSet(check, null)) check.scheduled.getAndSet(null)?.cancel()
                    return@schedule
                }
                // A full live queue cannot consume the timer's last wake-up. Keep its
                // deadline, without reading loop-owned activity or closing on the clock thread.
                val next = RpcIdleCheck(check.deadlineMillis, check.rejectedSubmissions + 1L)
                if (idleCheck.compareAndSet(check, next)) {
                    check.scheduled.getAndSet(null)?.cancel()
                    val nowMillis = clock.currentTimeMillis()
                    val remainingMillis = (check.deadlineMillis - nowMillis).coerceAtLeast(1L)
                    armCheck(ctx, next, nowMillis + remainingMillis)
                    // Report once per check; the ticket counts every rejected attempt.
                    if (check.rejectedSubmissions == 0L) {
                        System.err.println(
                            "[RpcIdleCheckSubmissionRejected] channel=${ctx.channel().id().asShortText()} " +
                                "deadlineMillis=${check.deadlineMillis}; the live task queue rejected the idle check; " +
                                "a clock callback remains scheduled; cause=${rejection.javaClass.name}: " +
                                (rejection.message ?: "no message")
                        )
                    }
                }
            }
        }
        check.scheduled.set(scheduled)
        // Cancellation or replacement may have won while schedule was returning. It owns
        // the ticket, so this late registration must not retain the handler until its deadline.
        if (idleCheck.get() !== check) check.scheduled.getAndSet(null)?.cancel()
    }

    private fun checkIdle(ctx: ChannelHandlerContext) {
        if (!ctx.channel().isActive || ctx.executor().isShuttingDown) {
            stopTimer()
            return
        }
        applyRpcCompletions(ctx, rearmIdle = false)
        if (stopped) return
        if (pendingRpcRequests > 0) {
            scheduleCheck(ctx, idleTimeoutMillis)
            return
        }
        if (serverReadPauseOwners.isNotEmpty() || !ctx.channel().config().isAutoRead) {
            recordActivity(ctx)
            scheduleCheck(ctx, idleTimeoutMillis)
            return
        }
        val remainingMillis = remainingIdleMillis(ctx)
        if (remainingMillis > 0L) {
            scheduleCheck(ctx, remainingMillis)
            return
        }
        stopTimer()
        try {
            ctx.fireExceptionCaught(ReadTimeoutException.INSTANCE)
        } finally {
            ctx.close()
        }
    }

    private fun remainingIdleMillis(ctx: ChannelHandlerContext): Long {
        val nowNanos = TimeUnit.MILLISECONDS.toNanos(clock.currentTimeMillis())
        if (nowNanos < lastActivityAtNanos) recordActivity(ctx)
        val parentPausedSinceLastActivity =
            (parentPausedNanosThrough(ctx, nowNanos) - parentPausedNanosAtLastActivity)
                .coerceAtLeast(0L)
        val readableIdleNanos =
            (nowNanos - lastActivityAtNanos - parentPausedSinceLastActivity).coerceAtLeast(0L)
        if (readableIdleNanos < idleTimeoutNanos) {
            val remainingNanos = idleTimeoutNanos - readableIdleNanos
            val remainingMillis = TimeUnit.NANOSECONDS.toMillis(remainingNanos)
            return remainingMillis.coerceAtLeast(1L)
        }
        return 0L
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        stopTimer()
        ctx.fireChannelInactive()
    }

    override fun handlerRemoved(ctx: ChannelHandlerContext) {
        stopTimer()
    }

    private fun stopTimer() {
        stopped = true
        unappliedCompletions.set(null)
        cancelCheck()
    }

    private fun cancelCheck() {
        idleCheck.getAndSet(null)?.scheduled?.getAndSet(null)?.cancel()
    }

    /** Admission records pauses in this host's idle clock domain, including ongoing pauses. */
    private fun parentPausedNanosThrough(ctx: ChannelHandlerContext, nowNanos: Long): Long {
        val parent = ctx.channel().parent() ?: return 0L
        val state = inboundPhysicalReadStateFor(parent)
        return synchronized(state) { state.pausedNanosThrough(nowNanos) }
    }
}

/**
 * Applies a server-owned read pause and keeps the pause-aware idle handler in sync.
 *
 * The pipeline lookup is intentionally optional so handlers used outside the unified RPC binding
 * retain their existing behavior. Each unified server decoder supplies a stable identity token, so
 * one decoder cannot release another decoder's pause while both are active.
 */
private fun ChannelHandlerContext.setRpcServerAutoRead(enabled: Boolean, owner: Any) {
    val pauseHandler = pipeline().get(PauseAwareReadTimeoutHandler::class.java)
    val anyServerPauseRemains = pauseHandler?.onServerReadPauseChanged(this, owner, !enabled)
    val shouldRead = anyServerPauseRemains?.not() ?: enabled
    channel().config().isAutoRead = shouldRead
}

/**
 * Length-prefixed v1.0 JSON decoder that reserves the shared parse pool after the length header
 * and before accepting the body. A contended acquire pauses this substream off the event loop, and
 * a reservation held across an incomplete body is bounded by [JsonBodyArrivalGuard].
 */
internal class ParseBudgetedJsonFrameDecoder : ByteToMessageDecoder() {
    private var lease: Libp2pRpcProtocol.FrameParseLease? = null
    private var awaitingAdmission = false
    private val arrivalGuard = JsonBodyArrivalGuard()
    private val admissionReadPauseOwner = Any()

    override fun decode(ctx: ChannelHandlerContext, input: ByteBuf, out: MutableList<Any>) {
        if (awaitingAdmission || input.readableBytes() < 4) return
        val base = input.readerIndex()
        val jsonLength = input.getInt(base)
        if (jsonLength <= 0 || jsonLength > Libp2pRpcProtocol.MAX_JSON_FRAME_BYTES) {
            throw CorruptedFrameException(
                "Invalid RPC JSON frame length: $jsonLength " +
                    "(must be 1..${Libp2pRpcProtocol.MAX_JSON_FRAME_BYTES})"
            )
        }
        val frameLease = lease ?: Libp2pRpcProtocol.FrameParseLease(jsonLength, libp2pRootConnectionChannel(ctx.channel())).also {
            lease = it
        }
        if (!frameLease.tryAcquire()) {
            pauseAndAdmit(ctx, frameLease)
            return
        }
        arrivalGuard.recordProgress(input.writerIndex())
        if (input.writerIndex() - (base + 4) < jsonLength) {
            // The reservation is held for a body that has not fully arrived. Bound that hold.
            arrivalGuard.arm(ctx, frameLease, jsonLength, input.writerIndex())
            return
        }
        arrivalGuard.disarm()

        val body = ByteArray(jsonLength)
        input.getBytes(base + 4, body)
        input.readerIndex(base + 4 + jsonLength)
        lease = null
        out.add(ParseBudgetedInboundMessage(body, null, frameLease))
    }

    private fun pauseAndAdmit(
        ctx: ChannelHandlerContext,
        frameLease: Libp2pRpcProtocol.FrameParseLease
    ) {
        awaitingAdmission = true
        ctx.setRpcServerAutoRead(false, admissionReadPauseOwner)
        jsonAdmissionExecutor.execute {
            var admitted = false
            var failure: Throwable? = null
            try {
                admitted = frameLease.acquire()
            } catch (caught: Throwable) {
                failure = caught
            }
            ctx.channel().eventLoop().execute {
                awaitingAdmission = false
                if (admitted && ctx.channel().isActive) {
                    ctx.setRpcServerAutoRead(true, admissionReadPauseOwner)
                    if (ctx.channel().config().isAutoRead) {
                        ctx.pipeline().fireChannelRead(io.netty.buffer.Unpooled.EMPTY_BUFFER)
                    }
                } else {
                    if (admitted) frameLease.close()
                    ctx.close()
                }
                failure?.let { ctx.fireExceptionCaught(it) }
            }
        }
    }

    override fun handlerRemoved0(ctx: ChannelHandlerContext) {
        arrivalGuard.disarm()
        lease?.close()
        lease = null
    }
}

private fun resumeBufferedRpcFrames(ctx: ChannelHandlerContext) {
    val pipeline = ctx.pipeline()
    if (pipeline.context(ParseBudgetedJsonFrameDecoder::class.java) == null &&
        pipeline.context(AttachmentRpcFrameDecoder::class.java) == null
    ) return
    // A decoder wake is not peer activity. Start after the idle observer, and leave public
    // handlers that already receive decoded frames alone when no RPC decoder is installed.
    val idleContext = pipeline.context(PauseAwareReadTimeoutHandler::class.java)
    if (idleContext == null) pipeline.fireChannelRead(Unpooled.EMPTY_BUFFER)
    else idleContext.fireChannelRead(Unpooled.EMPTY_BUFFER)
}

/**
 * Non-blocking Netty handler for server-side RPC stream message processing.
 *
 * Replaces the blocking thread-per-stream model (RpcStreamHandlerPool + handleStream while loop)
 * with a pipeline-based approach. Receives complete message frames from [LengthFieldBasedFrameDecoder],
 * parses JSON, and dispatches:
 * - RPC requests → coroutines on [rpcRequestDispatcher] for concurrent processing
 * - One-way gossip → callbacks on the host- or connection-owned announcement scope
 * - Gossip queries and peer exchanges → their existing response/apply dispatchers
 * - Effect responses → routed to [ControllerEffectPropagator]
 *
 * The per-connection [effectPropagator] doubles as the [ServiceClientConnection] handed to a
 * [ConnectionAwareServiceHandler]: it is the connection-scoped server→client push channel, and its
 * onClose listeners fire from [cleanup] on channelInactive / exceptionCaught.
 *
 * This handler runs on Netty's event loop. No OS threads are blocked waiting for data.
 * Threads are only allocated when there is application work to do (RPC or gossip handling).
 */
class RpcServerMessageHandler internal constructor(
    private val stream: Stream,
    private val requestHandler: RpcRequestHandler,
    private val gossipHandler: GossipHandler?,
    private val onDirectPeerContact: ((String) -> Unit)?,
    private val binaryResponseAttachments: Boolean,
    private val peerExchangeRequestScope: PeerExchangeRequestScope,
    private val readPauseObserver: RpcReadPauseObserver?,
    private val announcementScope: OneShotGossipScope = oneShotGossipScopeForConnection(stream),
) : SimpleChannelInboundHandler<Any>() {

    /** Preserves the pre-binary-response public constructor and its Kotlin default arguments. */
    @JvmOverloads
    constructor(
        stream: Stream,
        requestHandler: RpcRequestHandler,
        gossipHandler: GossipHandler? = null,
        onDirectPeerContact: ((String) -> Unit)? = null
    ) : this(
        stream,
        requestHandler,
        gossipHandler,
        onDirectPeerContact,
        false,
        peerExchangeRequestScopeForConnection(stream),
        null
    )

    private val admissionOrder = nextServiceConnectionAdmissionOrder()

    private val rpcScope = kotlinx.coroutines.CoroutineScope(
        rpcRequestDispatcher + kotlinx.coroutines.SupervisorJob()
    )
    private val activeForwardedResponses =
        ConcurrentHashMap.newKeySet<ForwardedStreamingBytecodeResponse>()
    private val pendingRpcRequests = AtomicInteger()
    private val requestAdmissionReadPauseOwner = Any()
    // Touched on this stream's event loop. It tracks the request-count pause independently of
    // other decoders that may briefly use the same channel's autoRead setting.
    private var requestAdmissionPaused = false
    @Volatile
    private var currentChannelHandlerContext: ChannelHandlerContext? = null

    private fun adjustPendingRpcRequests(delta: Int, ordinary: Boolean = true) {
        if (ordinary) pendingRpcRequests.addAndGet(delta)
        if (connectionClosed) return
        val ctx = currentChannelHandlerContext ?: return
        val channel = ctx.channel()
        if (!channel.isOpen) return
        val eventLoop = channel.eventLoop()
        // The outbox can retire queued responses while the loop winds down, before
        // termination. Idle/admission work no longer needs re-arming during shutdown;
        // permit release and the atomic pending count still settle before this notification.
        if (eventLoop.isShuttingDown) return
        val idleContext = ctx.pipeline().context(PauseAwareReadTimeoutHandler::class.java)
        val idleHandler = idleContext?.handler() as? PauseAwareReadTimeoutHandler
        idleHandler?.recordRpcCompletion(idleContext)
        try {
            eventLoop.execute {
                if (connectionClosed || !channel.isOpen) return@execute
                idleHandler?.applyRpcCompletions(idleContext)
                resumeRequestAdmission(ctx)
            }
        } catch (rejection: java.util.concurrent.RejectedExecutionException) {
            // The loop can begin shutdown (state 5) and reach its rejecting state 6
            // between the guard and submission. This notification has no work to re-arm
            // then; preserve rejections from a live loop, such as a full task queue.
            if (!eventLoop.isShuttingDown) throw rejection
        }
    }

    /** Also called by the idle handler when it reconciles a rejected completion on the loop. */
    internal fun resumeRequestAdmission(ctx: ChannelHandlerContext) {
        val channel = ctx.channel()
        if (connectionClosed || !channel.isOpen || channel.eventLoop().isShuttingDown) return
        if (pendingRpcRequests.get() <= 50 && requestAdmissionPaused) {
            val wasAutoRead = channel.config().isAutoRead
            requestAdmissionPaused = false
            ctx.setRpcServerAutoRead(true, requestAdmissionReadPauseOwner)
            readPauseObserver?.onReadPauseChanged(false)
            if (!wasAutoRead && channel.config().isAutoRead) {
                // Complete frames may already be in the decoder's cumulation. A socket read
                // alone cannot dispatch them when the peer is waiting for these responses.
                resumeBufferedRpcFrames(ctx)
                if (channel.config().isAutoRead) channel.read()
            }
        }
    }

    // === Connection lifecycle for the server→client push channel ===
    // A stable per-connection identity, plus a once-fired set of close listeners
    // that a ConnectionAwareServiceHandler can register interest in (via the
    // ServiceClientConnection handed to it). Fired from cleanup(), which runs on
    // channelInactive (graceful close / idle timeout) and exceptionCaught (abrupt
    // reset), so a service learns of BOTH orderly and abrupt connection death.
    private val connectionId: String =
        "libp2p-conn-${stream.remotePeerId().toBase58().takeLast(8)}-${nextServerConnectionId()}"
    private val closeLock = Any()
    @Volatile
    private var connectionClosed = false
    private val closeListeners = ArrayList<() -> Unit>()

    private fun registerCloseListener(listener: () -> Unit) {
        val fireNow = synchronized(closeLock) {
            if (connectionClosed) true else { closeListeners.add(listener); false }
        }
        // Fire outside the lock so a listener that re-enters (unlikely) can't deadlock.
        if (fireNow) {
            try {
                listener()
            } catch (e: Exception) {
                debugLogErr { "[RPC] onClose listener for $connectionId threw on immediate fire: ${e.message}" }
            }
        }
    }

    private fun fireCloseListeners() {
        val toFire = synchronized(closeLock) {
            if (connectionClosed) return
            connectionClosed = true
            val snapshot = ArrayList(closeListeners)
            closeListeners.clear()
            snapshot
        }
        // Dispatch each listener OFF the event loop (this method is called from channelInactive /
        // exceptionCaught, which run on the Netty event loop): a blocking listener run inline here
        // would stall the loop and freeze every connection sharing it. The once-only flag was set
        // synchronously above, so exactly-once holds regardless of dispatch timing.
        for (listener in toFire) {
            closeListenerDispatcher.execute {
                try {
                    listener()
                } catch (e: Exception) {
                    debugLogErr { "[RPC] onClose listener for $connectionId threw: ${e.message}" }
                }
            }
        }
    }

    private val effectPropagator = TransportDisconnectableControllerEffectPropagator(
        writeFn = { json -> writeRpcMessageReturningDelivered(stream, json) },
        connectionId = connectionId,
        isConnectionOpen = { !connectionClosed },
        closeListenerRegistrar = { listener -> registerCloseListener(listener) },
        remotePeerId = stream.remotePeerId().toBase58(),
        admissionOrder = admissionOrder,
        disconnectTransport = { stream.close() }
    )

    private val peerId: String by lazy {
        stream.remotePeerId().toBase58().takeLast(8)
    }

    override fun handlerAdded(ctx: ChannelHandlerContext) {
        val fullPeerId = stream.remotePeerId().toBase58()
        onDirectPeerContact?.invoke(fullPeerId)
    }

    override fun channelRead0(ctx: ChannelHandlerContext, msg: Any) {
        val budgetedMessage = msg as? ParseBudgetedInboundMessage
        val interleaveLargeResponseAttachments = when (msg) {
            is ParseBudgetedInboundMessage -> msg.messageFrame?.json?.opt(
                Libp2pRpcProtocol.INTERLEAVED_RESPONSE_CAPABILITY_FIELD,
            ) === true
            is Libp2pRpcProtocol.MessageFrame -> msg.json.opt(
                Libp2pRpcProtocol.INTERLEAVED_RESPONSE_CAPABILITY_FIELD,
            ) === true
            else -> false
        }
        try {
        val message = try {
            parseInboundMessage(msg) ?: return
        } catch (e: IllegalArgumentException) {
            gossipHandler?.recordAuthenticatedInteractionCompatible(
                stream.remotePeerId().toBase58(),
                PeerInteractionSeverity.SEVERE
            )
            // testUnknownMessageTypeDoesNotKillConnection: an unknown message
            // type must be ignored, leaving the substream open for subsequent
            // valid messages.
            debugLogErr { "[RPC] Ignoring unknown message type from $peerId: ${e.message}" }
            return
        } catch (e: org.json.JSONException) {
            gossipHandler?.recordAuthenticatedInteractionCompatible(
                stream.remotePeerId().toBase58(),
                PeerInteractionSeverity.SEVERE
            )
            debugLogErr { "[RPC] Ignoring malformed message from $peerId: ${e.message}" }
            return
        }
        // One-way gossip can enter resolver locks, registry publication, or lifetime actions.
        // Hand off every application callback together before the general interaction preamble.
        // The host-owned job survives immediate child close and rpcScope cancellation.
        val gossipDispatch = dispatchOneShotGossip(message, gossipHandler, stream, announcementScope, msg) { failure -> exceptionCaught(ctx, failure) }
        if (gossipDispatch != null) {
            // Child close is observable on another event loop before this method's finally.
            // Return parsing ownership first, so that close also marks the completed handoff.
            budgetedMessage?.close()
            closeStreamQuietly()
            return
        }
        // PeerExchange requests report the authenticated interaction after the admission attempt
        // below. This keeps the public callback a usable post-admission observation point for
        // lifecycle callers, while malformed messages and every other message type retain their
        // existing notification timing.
        val isPeerExchangeRequest = message is GossipProtocol.PeerExchange && message.isRequest
        if (!isPeerExchangeRequest) {
            gossipHandler?.recordAuthenticatedInteractionCompatible(
                stream.remotePeerId().toBase58(),
                gossipHandler.classifyAuthenticatedInteractionCompatible(message)
            )
        }

        when (message) {
            is Libp2pRpcProtocol.RpcRequest -> {
                // Do NOT close the substream after responding. RPC streams are
                // request/response from the production callers' perspective,
                // but the public test suite (and a small number of internal
                // call sites) reuses a single controller for back-to-back
                // RpcRequests on the same substream. Forcing a close here
                // would break those flows; the substream-leak fix targets the
                // dominant gossip path instead, and RPC traffic remains
                // bounded by ReadTimeoutHandler's idle close.
                val request = message
                // Classification must be quick and nonblocking: it runs before the ordinary
                // read-pause count, otherwise 100 parked polls stop this stream reading replies,
                // refusals and ordinary calls despite their independent admission allowances.
                var classificationFailure: Exception? = null
                val longPoll = try {
                    (requestHandler as? LongPollRpcRequestHandler)?.isLongPollRequest(request) == true
                } catch (failure: Exception) {
                    classificationFailure = failure
                    false
                }
                currentChannelHandlerContext = ctx
                val pending = if (longPoll) pendingRpcRequests.get() else pendingRpcRequests.incrementAndGet()
                ctx.pipeline().context(PauseAwareReadTimeoutHandler::class.java)?.let { idleContext ->
                    (idleContext.handler() as PauseAwareReadTimeoutHandler).onRpcRequestStarted(idleContext)
                }
                if (!longPoll && pending >= 100 && !requestAdmissionPaused) {
                    requestAdmissionPaused = true
                    ctx.setRpcServerAutoRead(false, requestAdmissionReadPauseOwner)
                    readPauseObserver?.onReadPauseChanged(true)
                }
                // Decide non-waiting long-poll admission before creating a coroutine. Excess
                // polls must not accumulate jobs retaining parsed requests on the dispatcher.
                val longPollPermit = if (longPoll && rpcLongPollRequestPermits.tryAcquire()) {
                    RpcRequestPermit {
                        try { rpcLongPollRequestPermits.release() }
                        finally { adjustPendingRpcRequests(-1, ordinary = false) }
                    }
                } else null
                if (longPoll && longPollPermit == null) {
                    // This token owns only pending/idle completion, not an admission slot.
                    val completionPermit = RpcRequestPermit { adjustPendingRpcRequests(-1, ordinary = false) }
                    try { rejectLongPollBeforeDispatch(stream, request, completionPermit) }
                    finally { completionPermit.releaseByHandler() }
                    return
                }
                val completionOwnedByPermit = AtomicBoolean(longPollPermit != null)
                val job = try { rpcScope.launch {
                    var failureReservation: AwaitedResponseFailureReservation? = null
                    var requestPermit: RpcRequestPermit? = longPollPermit
                    try {
                        if (!longPoll) {
                            rpcRequestPermits.acquire()
                            requestPermit = RpcRequestPermit {
                                try { rpcRequestPermits.release() }
                                finally { adjustPendingRpcRequests(-1) }
                            }
                            completionOwnedByPermit.set(true)
                        }
                        failureReservation = reserveAwaitedResponseFailureSignal(
                            stream,
                            AwaitedRpcResponseIdentity(
                                requestId = request.id,
                                method = request.method,
                                serviceIdentifier = request.method.substringBefore('/'),
                            ),
                            longPoll = longPoll,
                        ) {
                            framedRpcJsonBuffer(
                                awaitedResponseOutboxFullResponse(request.id).toJson()
                            )
                        }
                        if (streamAsChannel(stream) != null && failureReservation == null) {
                            debugLogErr {
                                "[RPC] Did not execute ${request.method} for $peerId because its " +
                                    "connection closed before completion capacity could be reserved"
                            }
                            return@launch
                        }
                        failureReservation?.requestPermit = requestPermit
                        failureReservation?.retainRequestPermitForFailureResponse = longPoll
                        val response = try {
                            classificationFailure?.let { throw it }
                            requestHandler.handleRequest(request, effectPropagator)
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            return@launch
                        } catch (e: Exception) {
                            debugLogErr { "[RPC] Request handler threw for ${request.method} from $peerId: ${e.message}" }
                            Libp2pRpcProtocol.RpcResponse(
                                id = request.id,
                                result = null,
                                error = applicationFailureRpcError(e)
                            )
                        }
                        val onEncodingFailure: (suspend (Throwable) -> String?)? = (requestHandler as? RpcResponseEncodingFailureHandler)?.let { owner ->
                            val callback: suspend (Throwable) -> String? = { failure ->
                                owner.onResponseEncodingFailure(request, response, effectPropagator, failure)
                            }
                            callback
                        }
                        val streaming = response.result as? StreamingBytecodeResponse
                        val forwarded = response.result as? ForwardedStreamingBytecodeResponse
                        val forwardedToTrack = if (response.error == null) forwarded else null
                        val leaseInterruptStatus = RpcEncodingInterruptStatus()
                        val lease = try {
                            if (forwardedToTrack != null) {
                                // The lease provider may suspend; cleanup must see the carrier first.
                                activeForwardedResponses.add(forwardedToTrack)
                                if (connectionClosed) {
                                    forwardedToTrack.close()
                                    leaseInterruptStatus.observeCurrentThread()
                                }
                            }
                            (requestHandler as? RpcResponseEncodingResourceHandler)?.let { owner ->
                                kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                                    owner.responseEncodingLease(request, response, effectPropagator)
                                }
                            }
                        } catch (failure: Throwable) {
                            leaseInterruptStatus.observe(failure)
                            try {
                                RpcEncodingResources().refuse(
                                    listOf(response.result, response.error?.data), failure,
                                )
                            } finally {
                                if (forwardedToTrack != null) activeForwardedResponses.remove(forwardedToTrack)
                            }
                            val encoded = encodeRpcEncodingFailureReply(response, request.method, failure, onEncodingFailure)
                            writeRpcResponseReturningOutcome(stream, response.id, encoded.jsonBytes, encoded.attachments, failureReservation)
                            return@launch
                        } finally {
                            // Tracking a closed forwarded response can interrupt without throwing.
                            // Preserve that state across the potentially suspending lease callback.
                            leaseInterruptStatus.restore()
                        }
                        val outcome = if (forwarded != null && response.error == null) {
                            try {
                                var encodingFailure: Throwable? = null
                                try {
                                    if (connectionClosed) forwarded.close()
                                    writeForwardedStreamingResponseReturningOutcome(
                                        stream, response.id, response.metadata, forwarded, failureReservation,
                                        binaryAttachments = binaryResponseAttachments,
                                        interleaveLargeAttachments = interleaveLargeResponseAttachments,
                                        notifyEncodingFailure = true,
                                        encodingLease = lease,
                                    )
                                } catch (refused: ForwardedResponseEncodingFailure) {
                                    encodingFailure = refused.encodingFailure
                                    throw refused
                                } finally {
                                    try {
                                        forwarded.close()
                                    } catch (closeFailure: Throwable) {
                                        val original = encodingFailure ?: throw closeFailure
                                        if (closeFailure !== original) original.addSuppressed(closeFailure)
                                    } finally {
                                        activeForwardedResponses.remove(forwarded)
                                    }
                                }
                            } catch (refused: ForwardedResponseEncodingFailure) {
                                // Writer ownership and the unread backend are released before cleanup.
                                val encoded = encodeRpcEncodingFailureReply(
                                    response, request.method, refused.encodingFailure, onEncodingFailure,
                                    defaultReason = {
                                        val failure = refused.encodingFailure
                                        "Internal server error: ${failure.javaClass.simpleName}: ${rpcEncodingFailureMessage(failure)}"
                                    },
                                )
                                writeRpcResponseReturningOutcome(
                                    stream, response.id, encoded.jsonBytes, encoded.attachments, failureReservation,
                                )
                            }
                        } else if (streaming != null && response.error == null && !binaryResponseAttachments) {
                            var encodingFrame = false
                            try {
                                encodingFrame = true
                                var preparedBuffer: io.netty.buffer.ByteBuf? = null
                                val responseBuffer = try {
                                    withRpcResponseEncodingLease(lease) {
                                        framedStreamingBytecodeBuffer(streaming).also { preparedBuffer = it }
                                    }
                                } catch (failure: Throwable) {
                                    preparedBuffer?.release()
                                    throw failure
                                }
                                encodingFrame = false
                                var handedToOutbox = false
                                try {
                                    withRpcFramingLock(stream) {
                                        handedToOutbox = true
                                        writeAwaitedResponseWithOutbox(stream, responseBuffer, failureReservation)
                                    }
                                } finally {
                                    if (!handedToOutbox) responseBuffer.release()
                                }
                            } catch (failure: Throwable) {
                                // Admission or delivery can fail after a response encoded; neither
                                // is an encoding refusal and neither notifies the response owner.
                                if (!encodingFrame) throw failure
                                val encoded = encodeRpcEncodingFailureReply(
                                    response, request.method, failure, onEncodingFailure,
                                )
                                writeRpcResponseReturningOutcome(
                                    stream, response.id, encoded.jsonBytes, encoded.attachments, failureReservation,
                                )
                            }
                        } else {
                            val encoded = encodeRpcResponseOrEncodingFailure(
                                if (streaming != null && response.error == null) streaming.toBinaryRpcResponse() else response,
                                request.method,
                                binaryResponseAttachments,
                                onEncodingFailure,
                                lease,
                            )
                            writeRpcResponseReturningOutcome(
                                stream,
                                response.id,
                                encoded.jsonBytes,
                                encoded.attachments,
                                failureReservation,
                                interleaveLargeAttachments = interleaveLargeResponseAttachments,
                            )
                        }
                        // Queue admission may end this coroutine, but the response owns its
                        // handler permit until the write completes or its buffer is released.
                        val admission = failureReservation?.awaitResponseAdmission()
                        if (admission == AwaitedResponseWriteOutcome.CONNECTION_CLOSED) {
                            debugLogErr {
                                "[RPC] Could not return awaited response for ${request.method} to " +
                                    "$peerId because its connection or stream ended while the " +
                                    "response waited for outbox space"
                            }
                        }
                        if (outcome == AwaitedResponseWriteOutcome.OUTBOX_FULL) {
                            debugLogErr {
                                "[RPC] Awaited response for ${request.method} to $peerId exceeded the " +
                                    "bounded response outbox; queued a per-request " +
                                    "$AWAITED_RESPONSE_OUTBOX_FULL_CODE response without closing the " +
                                    "shared logical stream"
                            }
                        } else if (outcome == AwaitedResponseWriteOutcome.CONNECTION_CLOSED) {
                            debugLogErr {
                                "[RPC] Could not return awaited response for ${request.method} to " +
                                    "$peerId because its connection was already closed"
                            }
                        }
                    } catch (e: Exception) {
                        debugLogErr { "[RPC] Failed to send response for ${request.method} to $peerId: ${e.message}" }
                    } finally {
                        try { failureReservation?.close() }
                        finally { requestPermit?.releaseByHandler() }
                    }
                } } catch (failure: Throwable) {
                    longPollPermit?.releaseByHandler()
                    if (!completionOwnedByPermit.get()) adjustPendingRpcRequests(-1)
                    throw failure
                }
                job.invokeOnCompletion {
                    // Cancellation before the body starts must also settle a pre-acquired poll
                    // slot. If its response already owns it, the handler release is a no-op.
                    longPollPermit?.releaseByHandler()
                    if (!completionOwnedByPermit.get()) adjustPendingRpcRequests(-1)
                }
            }
            is Libp2pRpcProtocol.ObservableSubscribe -> {
                // Long-lived subscription — leave the stream open so the server
                // can push observable updates over its lifetime. The closing
                // handshake is driven by the subscription's lifecycle, not by
                // the inbound message that registered it.
            }
            is Libp2pRpcProtocol.EffectResponse -> {
                // Routed back to the in-flight RPC handler. Closing here would
                // race with its awaited response write and silently drop replies.
                effectPropagator.handleEffectResponse(message)
            }
            is GossipProtocol.ServiceQuery -> {
                // Service-query handlers and their response writes are allowed to block on
                // application work and stream backpressure. Running them on the Netty event loop
                // can deadlock a large attachment writer that holds the per-stream monitor while
                // waiting for that same loop to execute its progress marker.
                val query = message
                rpcScope.launch(rpcRequestDispatcher) {
                    val results = try {
                        gossipHandler?.onServiceQuery(query) ?: emptyList()
                    } catch (e: Exception) {
                        debugLogErr {
                            "[GOSSIP] onServiceQuery handler threw for pattern=${query.servicePattern} " +
                                "from $peerId: ${e.message}"
                        }
                        emptyList<ServiceInfo>()
                    }
                    val response = GossipProtocol.ServiceQueryResponse(
                        id = query.id,
                        services = results
                    )
                    val delivered = try {
                        writeRpcMessageReturningDelivered(stream, response.toJson())
                    } catch (e: Exception) {
                        debugLogErr { "[GOSSIP] Failed to write ServiceQuery response to $peerId: ${e.message}" }
                        false
                    }
                    if (!delivered) {
                        debugLogErr {
                            "[GOSSIP] ServiceQuery response to $peerId was dropped because the " +
                                "stream was unwritable; closing the stream"
                        }
                    }
                    closeStreamAfterResponseQuietly("ServiceQuery")
                }
            }
            is GossipProtocol.PeerExchange -> {
                if (message.isRequest) {
                    val request = message
                    val retainedBytes = request.estimatedRetainedBytes()
                    val admissionAttempt = peerExchangeRequestScope.admit(retainedBytes) {
                        handlePeerExchangeRequest(request)
                    }
                    // Severity inspection runs after the request enters the admission state
                    // machine. Settle the returned handle afterward while the same scope lock
                    // arbitrates host close; a pending request canceled by close is therefore not
                    // reported as admitted. An outright rejection has no handle and retains the
                    // existing interaction notification so saturation observers can see it.
                    val severity = gossipHandler?.classifyAuthenticatedInteractionCompatible(message)
                    val admitted = admissionAttempt.admission?.settle() == true
                    if (admissionAttempt.admission == null || admitted) {
                        gossipHandler?.recordAuthenticatedInteractionCompatible(
                            stream.remotePeerId().toBase58(),
                            severity ?: PeerInteractionSeverity.CLEAN
                        )
                    }
                    if (!admitted) {
                        val rejectionReason = admissionAttempt.rejectionReason
                            ?: "the host closed before the admitted request could be reported"
                        val warning = PeerExchangeAdmissionWarningEffect(
                            peerId = peerId,
                            requestRetainedBytes = retainedBytes,
                            aggregateRetainedBytes = admissionAttempt.retainedBytesInUse,
                            aggregateRetainedByteLimit =
                                PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET,
                            reason = rejectionReason
                        )
                        reportPeerExchangeAdmissionWarning(warning)
                        debugLogErr {
                            "[GOSSIP] PeerExchange request from $peerId was rejected: " +
                                "estimated retained bytes=$retainedBytes; " +
                                "aggregate retained bytes=${admissionAttempt.retainedBytesInUse}; " +
                                "aggregate retained-byte limit=" +
                                "$PEER_EXCHANGE_REQUEST_RETAINED_BYTES_BUDGET; $rejectionReason"
                        }
                        closeStreamQuietly()
                    }
                    peerExchangeRequestScope.recordAdmissionCompleted(admitted)
                } else {
                    val peersToProcess = message.peers
                    gossipFollowUpScope.launch {
                        try {
                            gossipHandler?.receivePeersCompatible(
                                peersToProcess,
                                stream.remotePeerId().toBase58()
                            )
                        } catch (e: Exception) {
                            debugLogErr { "[GOSSIP] onPeersReceived handler threw from $peerId: ${e.message}" }
                        }
                    }
                }
                if (!message.isRequest) {
                    closeStreamQuietly()
                }
            }
            else -> {
                // Unknown one-shot message — close so we don't leak a substream.
                closeStreamQuietly()
            }
        }
        } finally {
            budgetedMessage?.close()
        }
    }

    /**
     * Parses an inbound pipeline message into an RPC/gossip message object.
     *
     * The 1.0.0 pipeline (LengthFieldBasedFrameDecoder) delivers a raw [ByteBuf]
     * carrying just the JSON body, with no binary attachments. The
     * attachment-capable 1.1.0 pipeline ([AttachmentRpcFrameDecoder]) delivers a
     * fully-assembled [Libp2pRpcProtocol.MessageFrame] whose attachments let
     * [Libp2pRpcProtocol.parseMessage] resolve binary_ref markers straight back
     * to raw ByteArrays (no base64 round trip on the host).
     *
     * Returns null when a length-delimited 1.0.0 body cannot be turned into a
     * usable message — syntactically invalid JSON, or a body refused by the
     * structural caps — so the caller ignores the message and keeps the
     * connection open, preserving the testMalformedJsonDoesNotKillConnection
     * contract. Unknown message types and other JSON errors propagate to the
     * caller, which also ignores them.
     */
    private fun parseInboundMessage(msg: Any): Any? {
        return when (msg) {
            is ParseBudgetedInboundMessage -> when {
                msg.messageFrame != null -> Libp2pRpcProtocol.parseMessage(
                    msg.messageFrame.json,
                    msg.messageFrame.attachments
                )
                msg.bodyBytes != null -> {
                    val json = try {
                        Libp2pRpcProtocol.parseValidatedJsonBody(msg.bodyBytes)
                    } catch (e: org.json.JSONException) {
                        gossipHandler?.recordAuthenticatedInteractionCompatible(
                            stream.remotePeerId().toBase58(),
                            PeerInteractionSeverity.SEVERE
                        )
                        debugLogErr {
                            "[RPC] Ignoring malformed JSON message from $peerId: ${e.message}"
                        }
                        return null
                    } catch (e: java.io.IOException) {
                        // A structural refusal (nesting depth, string length, element count) is the
                        // same class of unusable body as syntactically invalid JSON, and the 1.0.0
                        // length-delimited framing resyncs cleanly at the next length prefix. Keep
                        // the documented lenient contract: ignore the message, keep the connection.
                        gossipHandler?.recordAuthenticatedInteractionCompatible(
                            stream.remotePeerId().toBase58(),
                            PeerInteractionSeverity.SEVERE
                        )
                        debugLogErr {
                            "[RPC] Ignoring structurally refused JSON message from $peerId: " +
                                "${e.message}"
                        }
                        return null
                    }
                    Libp2pRpcProtocol.parseMessage(json)
                }
                else -> null
            }
            is Libp2pRpcProtocol.MessageFrame ->
                Libp2pRpcProtocol.parseMessage(msg.json, msg.attachments)
            is ByteBuf -> {
                val jsonString = msg.toString(StandardCharsets.UTF_8)
                val json = try {
                    parseJsonWireString(jsonString)
                } catch (e: org.json.JSONException) {
                    gossipHandler?.recordAuthenticatedInteractionCompatible(
                        stream.remotePeerId().toBase58(),
                        PeerInteractionSeverity.SEVERE
                    )
                    debugLogErr { "[RPC] Ignoring malformed JSON message from $peerId: ${e.message}" }
                    return null
                }
                Libp2pRpcProtocol.parseMessage(json)
            }
            else -> null
        }
    }

    private fun handlePeerExchangeRequest(message: GossipProtocol.PeerExchange) {
        try {
            gossipHandler?.receivePeersCompatible(
                message.peers,
                stream.remotePeerId().toBase58()
            )
        } catch (e: Exception) {
            debugLogErr {
                "[GOSSIP] onPeersReceived handler threw while applying PeerExchange request " +
                    "from $peerId; closing without success ack: ${e.message}"
            }
            closeStreamQuietly()
            return
        }
        val submittedPeerIds = message.peers.mapTo(mutableSetOf()) { it.peerId }
        // A bounded response may acknowledge records submitted in this request and may also
        // return the responder's own self record. The latter is not third-party disclosure: the
        // Noise session cryptographically authenticates this exact responder identity, and lets a
        // caller that reached us directly refresh our advertised listen addresses without first
        // submitting a fabricated record for us. Every other requested ID remains constrained to
        // the submitted set, preserving the no-unrelated-peer-exfiltration boundary.
        val authenticatedResponderPeerId = stream.connection.secureSession().localId.toBase58()
        val allowedResponsePeerIds = submittedPeerIds + authenticatedResponderPeerId
        val requestedPeerIds = message.requestedResponsePeerIds?.intersect(allowedResponsePeerIds)
        val ourPeers = try {
            if (requestedPeerIds == null) {
                gossipHandler?.onPeerExchangeRequest() ?: emptyList()
            } else if (gossipHandler is ProjectedPeerExchangeHandler) {
                gossipHandler.onPeerExchangeRequest(
                    requestedPeerIds,
                    stream.remotePeerId().toBase58()
                )
            } else {
                gossipHandler?.onPeerExchangeRequest()?.filter { it.peerId in requestedPeerIds }
                    ?: emptyList()
            }
        } catch (e: Exception) {
            debugLogErr { "[GOSSIP] onPeerExchangeRequest handler threw from $peerId: ${e.message}" }
            emptyList<PeerInfo>()
        }
        val response = GossipProtocol.PeerExchange(
            id = message.id,
            peers = ourPeers,
            isRequest = false
        )
        val delivered = try {
            writeRpcMessageReturningDelivered(stream, response.toJson())
        } catch (e: Exception) {
            debugLogErr { "[GOSSIP] Failed to write PeerExchange response to $peerId: ${e.message}" }
            false
        }
        if (!delivered) {
            debugLogErr {
                "[GOSSIP] PeerExchange response to $peerId was dropped because the stream was unwritable; " +
                    "closing so the requester observes failure instead of a false success"
            }
        }
        // writeAndFlush only queues the frame. This handler runs on the host-owned request
        // dispatcher, not the Netty event loop, so wait on the existing bounded write budget for
        // the ordered closeWrite barrier before tearing down the stream. Closing immediately can
        // discard the last queued response when the event loop is busy, which makes a handled
        // PeerExchange request look like an empty EOF to the caller.
        closeStreamAfterResponseQuietly("PeerExchange")
    }

    private fun closeStreamQuietly() {
        try { stream.close() } catch (_: Exception) {}
    }

    private fun closeStreamAfterResponseQuietly(responseType: String) {
        try {
            stream.closeWrite().get(
                WRITE_BACKPRESSURE_DELIVERY_WAIT_MS,
                TimeUnit.MILLISECONDS
            )
        } catch (failure: Exception) {
            if (failure is InterruptedException) Thread.currentThread().interrupt()
            toss(
                RpcResponseCloseBarrierFailureEffect(
                    responseType = responseType,
                    peerId = stream.remotePeerId().toBase58(),
                    barrierTimeoutMillis = WRITE_BACKPRESSURE_DELIVERY_WAIT_MS,
                    cause = failure
                )
            )
        } finally {
            closeStreamQuietly()
        }
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        cleanup()
    }

    override fun handlerRemoved(ctx: ChannelHandlerContext) {
        cleanup()
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        if (cause is ReadTimeoutException) {
            // Idle timeout — no data received for the configured duration
            debugLog { "[RPC] Idle timeout for stream from $peerId, closing" }
        } else {
            debugLogErr { "[RPC] Exception on stream from $peerId: ${cause.message}" }
        }
        ctx.close()
        cleanup()
    }

    private fun cleanup() {
        // The client connection is dead (channelInactive / exceptionCaught): notify any
        // ConnectionAwareServiceHandler that registered interest via onClose BEFORE we cancel
        // in-flight handlers, so a connection-scoped subscription lease is reaped promptly on
        // both graceful close and abrupt reset. Idempotent (fires exactly once).
        fireCloseListeners()
        // Cancel in-flight handlers and return immediately. Previously this used
        // runBlocking { withTimeoutOrNull(10_000) { children.forEach { join() } } }
        // to "wait for in-flight handlers to flush their responses before the
        // stream closes" — but cleanup() is called from Netty's event loop
        // (channelInactive / exceptionCaught), so the runBlocking parked the
        // event loop for up to 10 s. Under the substream-cleanup load this
        // change creates (every responded substream now closes immediately),
        // that 10 s ceiling cascades across other channels sharing the loop
        // and starves every connection. The "wait for response writes" goal
        // is also moot: the stream we're cleaning up just closed, so any
        // pending response write would fail to reach the peer either way.
        // A forwarding coroutine can be inside a blocking socket InputStream.read, which
        // coroutine cancellation cannot interrupt. Closing the transport-owned response closes
        // that inner socket and lets the writer unwind immediately.
        for (response in activeForwardedResponses) {
            try {
                response.close()
            } catch (failure: Exception) {
                debugLogErr {
                    "[RPC] Failed to close an active forwarded response for $peerId: " +
                        "${failure.message}"
                }
            }
        }
        rpcScope.cancel()
    }
}

/**
 * A readiness notification keeps frame retirement on its loop even when both task queues are
 * full. One pipe belongs to each TCP/NIO loop, rather than to each attachment or connection.
 * One byte wakes the loop for a batch of decisions. There is no periodic task, retry, or
 * reservation release on the watchdog thread.
 */
private val attachmentRetirementMailboxes =
    java.util.concurrent.ConcurrentHashMap<io.netty.channel.EventLoop, AttachmentRetirementMailbox>()

private fun attachmentRetirementMailbox(loop: io.netty.channel.EventLoop): AttachmentRetirementMailbox {
    check(loop.inEventLoop()) { "Attachment retirement registration must run on the owning event loop" }
    attachmentRetirementMailboxes[loop]?.let { return it }
    val ioLoop = loop as? io.netty.channel.IoEventLoop
        ?: error("Attachment retirement requires an I/O event loop, but received ${loop.javaClass.name}")
    check(ioLoop.isCompatible(io.netty.channel.nio.NioIoHandle::class.java)) {
        "Attachment retirement requires the TCP NIO handler, but received ${loop.javaClass.name}"
    }
    // All registrations for this key run on that same loop. No map monitor covers pipe I/O.
    return AttachmentRetirementMailbox(ioLoop).also { mailbox ->
        attachmentRetirementMailboxes[loop] = mailbox
        loop.terminationFuture().addListener { attachmentRetirementMailboxes.remove(loop, mailbox) }
    }
}

private class AttachmentRetirementMailbox(
    private val loop: io.netty.channel.IoEventLoop,
) : io.netty.channel.nio.NioIoHandle {
    private val pipe = java.nio.channels.Pipe.open()
    private val owners = java.util.concurrent.ConcurrentHashMap.newKeySet<AttachmentRetirementNotification>()
    private val pending = java.util.concurrent.ConcurrentLinkedQueue<AttachmentRetirementNotification>()
    private val closed = AtomicBoolean()
    private val signalPending = AtomicBoolean()
    private val signalWriters = java.util.concurrent.atomic.AtomicInteger()
    private val pipeClosed = AtomicBoolean()
    private val readSignal = java.nio.ByteBuffer.allocate(1)

    init {
        var registered = false
        try {
            pipe.sink().configureBlocking(false)
            pipe.source().configureBlocking(false)
            val result = loop.register(this)
            check(result.isSuccess) { "Cannot register attachment retirement notification: ${result.cause()}" }
            result.getNow().submit(io.netty.channel.nio.NioIoOps.READ)
            registered = true
        } finally {
            if (!registered) {
                try { pipe.sink().close() } finally { pipe.source().close() }
            }
        }
    }

    override fun selectableChannel(): java.nio.channels.SelectableChannel = pipe.source()

    fun register(onDecision: () -> Unit, onShutdown: () -> Unit): AttachmentRetirementNotification {
        check(loop.inEventLoop() && !closed.get()) { "Cannot register a frame on a closed attachment retirement mailbox" }
        return AttachmentRetirementNotification(this, onDecision, onShutdown).also { owners.add(it) }
    }

    fun signal(owner: AttachmentRetirementNotification) {
        pending.add(owner)
        if (closed.get()) return // On-loop shutdown already owns every registered frame.
        signalWriters.incrementAndGet()
        try {
            // Shutdown cannot close the pipe while this writer owns it. A late writer sees
            // closed before touching I/O; the last in-flight writer completes pipe cleanup.
            if (!closed.get() && signalPending.compareAndSet(false, true)) {
                check(pipe.sink().write(java.nio.ByteBuffer.wrap(byteArrayOf(1))) == 1) {
                    "The attachment retirement pipe must accept its single pending notification"
                }
            }
        } finally {
            if (signalWriters.decrementAndGet() == 0 && closed.get()) closePipe()
        }
    }

    fun remove(owner: AttachmentRetirementNotification) {
        owners.remove(owner)
    }

    override fun handle(registration: io.netty.channel.IoRegistration, event: io.netty.channel.IoEvent) {
        if (closed.get()) return
        readSignal.clear()
        if (pipe.source().read(readSignal) <= 0) return
        signalPending.set(false)
        // This registration is already on the loop, so the scheduled heap needs no slot in
        // either bounded queue. Deliver after ordinary task processing can make progress.
        loop.schedule({
            while (true) {
                val owner = pending.poll() ?: break
                owner.deliver()
            }
        }, 0L, TimeUnit.NANOSECONDS)
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        var failure: Throwable? = null
        try {
            // Netty closes registered I/O handles on the loop before terminating it. Even a
            // deregistered transport's decoder still owns input and must be torn down here.
            owners.toList().forEach { owner ->
                try {
                    owner.shutdown()
                } catch (caught: Throwable) {
                    val first = failure
                    if (first == null) failure = caught else first.addSuppressed(caught)
                }
            }
        } finally {
            owners.clear()
            pending.clear()
            if (signalWriters.get() == 0) closePipe()
        }
        failure?.let { throw it }
    }

    private fun closePipe() {
        if (!pipeClosed.compareAndSet(false, true)) return
        try { pipe.sink().close() } finally { pipe.source().close() }
    }
}

private class AttachmentRetirementNotification(
    private val mailbox: AttachmentRetirementMailbox,
    onDecision: () -> Unit,
    onShutdown: () -> Unit,
) : AutoCloseable {
    private val actions = AtomicReference<Pair<() -> Unit, () -> Unit>?>(onDecision to onShutdown)

    fun signal() { if (actions.get() != null) mailbox.signal(this) }
    fun deliver() { actions.get()?.first?.invoke() }
    fun shutdown() { actions.getAndSet(null)?.second?.invoke() }
    override fun close() {
        actions.set(null)
        mailbox.remove(this)
    }
}

/**
 * Netty inbound decoder for the attachment-capable RPC wire format (protocol
 * /aicli-rpc/1.1.0). Mirrors [Libp2pRpcProtocol.readMessageFrameFromStream] but
 * operates on a Netty [ByteBuf]. Once a full JSON body is buffered, parsing is
 * admitted through [Libp2pRpcProtocol]'s global parse-memory budget; under
 * large-frame pressure that can park the channel's event-loop thread briefly,
 * deliberately applying transport backpressure instead of allocating another
 * multi-MB body and parser graph.
 *
 * One logical message on the wire:
 * ```
 * [4 bytes: json length][json bytes]
 *   // only when the JSON contains binary_ref markers:
 *   [4 bytes: attachment count]
 *   [4 bytes: attachment length][attachment bytes] ...
 * ```
 * A message whose JSON carries no binary_ref markers is the compact frame
 * `[4 bytes: json length][json bytes]`, byte-identical to the 1.0.0 wire — so a
 * 1.1.0 request carrying no ByteArray param is indistinguishable from a 1.0.0
 * request and is read by the same code path.
 *
 * Emits a [Libp2pRpcProtocol.MessageFrame]. A corrupt frame header
 * (negative/oversized JSON length or attachment count) throws
 * [CorruptedFrameException] to fail the desynchronised stream. Malformed or
 * structurally-abusive JSON (rejected by the parser-safety caps in
 * [Libp2pRpcProtocol.parseValidatedJsonBody], enforced *before* the org.json
 * parse to avoid amplification) ALSO throws [CorruptedFrameException] here —
 * unlike the lenient length-delimited 1.0.0 handler, a 1.1.0 frame may be
 * followed by attachment framing whose length is only known from the parsed
 * JSON, so an unparseable frame has no safe skip length and the stream must fail
 * rather than risk reading the trailing attachment bytes as the next message.
 *
 * Partial reads are handled by computing offsets with absolute getInt/getBytes
 * and only advancing the reader index once the entire message is buffered; an
 * incomplete arrival simply returns and is retried when more bytes land.
 */
internal class AttachmentRpcFrameDecoder(
    private val childPauseHoldsWholeConnection: Boolean,
) : ByteToMessageDecoder() {
    // JSON bodies use the same process-wide parse pool as the legacy responder. For ordinary
    // no-attachment messages, ownership transfers to RpcServerMessageHandler through admission.
    private var jsonLease: Libp2pRpcProtocol.FrameParseLease? = null
    // The lease for the attachment frame currently being decoded. A single-attachment frame
    // reserves its validated body size from the process pool; an interleaved multi-attachment
    // frame reserves the whole pool because its total is not knowable before bodies arrive. Both
    // forms also hold the root physical connection's one-frame turn. A fresh lease is created for
    // every frame because consecutive frames on one stream can have different reservation sizes.
    private var lease: Libp2pRpcProtocol.FrameAttachmentLease? = null
    // True while an asynchronous admission acquire is in flight and reads
    // are paused (autoRead=false). decode() short-circuits so no further bytes accumulate until
    // the scheduler grants the lease and the event loop re-enables reads.
    private var awaitingAdmission = false
    // A JSON parser on another stream may temporarily use capacity that this attachment declared
    // but has not received. While that borrow is live this decoder keeps its already-buffered bytes
    // but must not accept or request another body read. Several borrows can be live at once, and a
    // borrow can outlive the lease generation it was taken against, so outstanding pause requests
    // are COUNTED: reads resume only when the last one has been matched by its resume. Both fields
    // are touched only on this channel's event loop.
    private var borrowPauseRequests = 0
    private var borrowPaused = false
    private val admissionReadPauseOwner = Any()
    private val borrowReadPauseOwner = Any()
    // Bounds a JSON parse reservation held while its body is still arriving, exactly as the
    // attachment stall watchdog below bounds a held attachment reservation.
    private val jsonArrivalGuard = JsonBodyArrivalGuard()
    // Minimum-progress stall watchdog for the currently-held lease. A peer that stops (or trickles
    // just slowly enough to keep resetting the 120s idle timer) would retain its process permits
    // and block every later attachment frame on the same physical connection. If no NEW bytes
    // arrive for ATTACHMENT_STALL_TIMEOUT_MS the watchdog closes the channel (-> handlerRemoved0
    // releases the lease). Any inbound byte resets the deadline, so a slow-but-progressing transfer
    // is never aborted.
    private var stallWatchdog: java.util.concurrent.ScheduledFuture<*>? = null
    private var stallRetirement: AttachmentRetirementNotification? = null
    private val lastStallProgressMs = java.util.concurrent.atomic.AtomicLong(0L)
    // A server-owned borrow pause cannot count as a peer's failure to make progress.
    // The absolute frame deadline continues running while reads are paused.
    @Volatile
    private var stallClockSuspendedByBorrow = false
    private var lastProgressWriterIndex = 0
    // Compute an allowance only when a new length header is validated. Partial decodes walk
    // earlier headers again, but cannot replace this frame's allowance with a smaller prefix.
    // Cancelled watchdogs keep their original cell and acquisition time across frame turnover.
    private var validatedAttachmentDeadlineMs = java.util.concurrent.atomic.AtomicLong(0L)
    private var validatedAttachmentLengthCount = 0
    // True only while this decoder owns continuation of a held or awaited attachment frame. A
    // child decoder must never re-arm a physical parent merely because that parent happens to be
    // in manual-read mode for another owner.
    private var ownsPhysicalReadRearm = false

    override fun decode(ctx: ChannelHandlerContext, input: ByteBuf, out: MutableList<Any>) {
        try {
            decodeFrame(ctx, input, out)
        } catch (failure: Throwable) {
            closeCurrentFrameLease()
            throw failure
        }
    }

    private fun decodeFrame(ctx: ChannelHandlerContext, input: ByteBuf, out: MutableList<Any>) {
        // While an asynchronous admission acquire is pending, do not examine further.
        if (awaitingAdmission || borrowPaused) return
        if (lease?.isHeld == true) ownsPhysicalReadRearm = true
        // If we hold the lease, any growth in buffered bytes since the last check is progress.
        if (lease?.isHeld == true && input.writerIndex() > lastProgressWriterIndex) {
            lastProgressWriterIndex = input.writerIndex()
            lastStallProgressMs.set(Libp2pRpcProtocol.attachmentClock.currentTimeMillis())
        }
        if (input.readableBytes() < 4) return
        val base = input.readerIndex()
        val end = input.writerIndex()
        val jsonLen = input.getInt(base)
        if (jsonLen <= 0 || jsonLen > MAX_JSON_FRAME_BYTES) {
            throw CorruptedFrameException(
                "Invalid RPC JSON frame length: $jsonLen (must be 1..$MAX_JSON_FRAME_BYTES)"
            )
        }
        val currentJsonLease = if (lease?.isHeld == true) {
            null
        } else {
            jsonLease ?: Libp2pRpcProtocol.FrameParseLease(jsonLen, libp2pRootConnectionChannel(ctx.channel())).also { jsonLease = it }
        }
        if (currentJsonLease != null && !currentJsonLease.tryAcquire()) {
            pauseAndAdmitJson(ctx, currentJsonLease)
            return
        }
        if (currentJsonLease != null) {
            jsonArrivalGuard.recordProgress(end)
            if (end - (base + 4) < jsonLen) {
                // This frame's JSON reservation is held for a body that has not fully arrived.
                jsonArrivalGuard.arm(ctx, currentJsonLease, jsonLen, end)
                return // wait for the full JSON body
            }
            jsonArrivalGuard.disarm()
        } else if (end - (base + 4) < jsonLen) {
            // An attachment lease is already held for this frame; its own stall watchdog and
            // absolute deadline bound the wait for these bytes.
            return
        }

        // Parse the JSON envelope. The body is bounded by MAX_JSON_FRAME_BYTES and the structural
        // caps, and its parse-memory reservation was taken above from the length header. Only the
        // non-blocking fast path runs on this event loop: when it is refused, the decoder pauses
        // reads and completes the blocking acquire on the admission pool instead of parking the loop
        // against the same pool an InputStream attachment reader may hold (the same-host deadlock
        // class). The attachment lease below is the separate admission bound for attachment bodies.
        val json = run {
            val jsonBytes = ByteArray(jsonLen)
            input.getBytes(base + 4, jsonBytes)
            try {
                Libp2pRpcProtocol.parseValidatedJsonBody(jsonBytes)
            } catch (e: Exception) {
                jsonLease = null
                jsonArrivalGuard.disarm()
                currentJsonLease?.close()
                // A 1.1.0 frame may be followed by attachment framing whose length is derivable
                // ONLY from the parsed JSON; an unparseable frame has no safe resync point, so
                // fail the stream (unlike the lenient length-delimited 1.0.0 handler).
                throw CorruptedFrameException(
                    "Unparseable JSON in a 1.1.0 RPC frame (jsonLen=$jsonLen); cannot determine " +
                        "attachment framing length to resync the stream: ${e.message}"
                )
            }
        }

        if (!Libp2pRpcProtocol.jsonContainsBinaryRefs(json)) {
            input.skipBytes(4 + jsonLen)
            jsonLease = null
            jsonArrivalGuard.disarm()
            out.add(
                ParseBudgetedInboundMessage(
                    null,
                    Libp2pRpcProtocol.MessageFrame(json, emptyList()),
                    checkNotNull(currentJsonLease) {
                        "A no-attachment JSON frame must retain its parse-memory lease"
                    }
                )
            )
            return
        }

        // Attachment frames retain their existing whole-pool lease. Release the right-sized JSON
        // reservation before that exclusive acquire so two permit classes are never held while
        // waiting on each other.
        jsonLease = null
        jsonArrivalGuard.disarm()
        currentJsonLease?.close()

        // Withdrawals may carry ignored extension attachments. Their retained JSON still needs
        // its conservative charge after decode, even when the extension body is only one byte.
        val withdrawalFrame = json.optString("type") == GossipProtocol.TYPE_SERVICE_WITHDRAW ||
            json.optString("type") == GossipProtocol.TYPE_RELAY_WITHDRAW
        val retainedJsonBytes = if (withdrawalFrame) jsonLen.toLong() * Libp2pRpcProtocol.PARSE_AMPLIFICATION else 0L

        // Attachments follow: [4 count] then count * ([4 len][bytes]).
        var cursor = base + 4 + jsonLen
        if (end - cursor < 4) return
        val count = input.getInt(cursor)
        if (count < 0 || count > MAX_ATTACHMENTS) {
            throw CorruptedFrameException("Invalid RPC attachment count: $count (max $MAX_ATTACHMENTS)")
        }
        // The declared count must equal the envelope's binary references, and those references
        // must form an exact bijection with 0..count-1 — both validated as soon as the count
        // field arrives, before any body is examined, so extra/unreferenced/duplicate-indexed
        // attachments are declined without waiting for their bytes.
        val binaryReferenceCount = Libp2pRpcProtocol.countBinaryRefs(json)
        if (count != binaryReferenceCount) {
            throw CorruptedFrameException(
                Libp2pRpcProtocol.attachmentCountMismatchMessage(count, binaryReferenceCount)
            )
        }
        try {
            Libp2pRpcProtocol.validateBinaryRefIndices(json, count)
        } catch (e: java.io.IOException) {
            throw CorruptedFrameException(e.message)
        }

        cursor += 4

        // For one attachment, the complete frame aggregate is known from the first validated
        // length header, so reserve exactly that many process permits (capped at the whole pool).
        // For multiple interleaved attachments, reserve the whole pool once before the first body:
        // their aggregate cannot be learned without retaining earlier bodies, and incrementally
        // growing a reservation would allow hold-and-wait.
        val frameLease = lease ?: run {
            val firstAttachmentLength = if (end - cursor >= 4) {
                input.getInt(cursor).also { attachmentLength ->
                    validateAttachmentLength(attachmentLength)
                    if (attachmentLength.toLong() > Libp2pRpcProtocol.MAX_ATTACHMENT_AGGREGATE_BYTES) {
                        throw CorruptedFrameException(
                            Libp2pRpcProtocol.attachmentAggregateLimitMessage(attachmentLength.toLong(), count)
                        )
                    }
                }
            } else null
            if (count == 1 && firstAttachmentLength == null) return
            // Admission can publish this lease to borrowers before the header is re-driven.
            validatedAttachmentLengthCount = if (firstAttachmentLength == null) 0 else 1
            validatedAttachmentDeadlineMs = java.util.concurrent.atomic.AtomicLong(
                Libp2pRpcProtocol.attachmentLeaseDeadlineMs(firstAttachmentLength?.toLong() ?: 0L)
            )
            val created = if (count == 1) {
                Libp2pRpcProtocol.FrameAttachmentLease.forKnownSize(
                    attachmentBytes = checkNotNull(firstAttachmentLength).toLong() + retainedJsonBytes,
                    connectionGate = attachmentFrameTurnFor(ctx.channel())
                )
            } else {
                Libp2pRpcProtocol.FrameAttachmentLease.forUnknownSize(
                    attachmentFrameTurnFor(ctx.channel())
                )
            }
            created.installBorrowReadController(
                pauseHeldPhysicalConnection =
                    if (childPauseHoldsWholeConnection) libp2pRootConnectionChannel(ctx.channel()) else null,
            ) { paused, completed ->
                setBorrowReadPaused(ctx, paused, completed)
            }
            lease = created
            created
        }
        val admitted = frameLease.tryAcquire()
        if (!admitted) {
            pauseAndAdmit(ctx, frameLease)
            return
        }
        // The decoder now owns continuation of this admitted partial frame. Publish that
        // ownership before returning from decode so a channelReadComplete callback can safely
        // re-arm the physical parent for the next body bytes.
        ownsPhysicalReadRearm = true
        startStallWatchdog(ctx, frameLease)

        // Walk the interleaved [4 len][bytes] headers, validating each individual length and the
        // RUNNING declared aggregate against MAX_ATTACHMENT_AGGREGATE_BYTES (rejecting an
        // oversized declaration before its body accumulates). Partial arrivals return and are
        // retried; the lease stays held (bounding what has accumulated).
        var declaredAttachmentBytes = 0L
        var retainedAttachmentBytes = 0L
        val attachmentOffsets = IntArray(count)
        val attachmentLengths = IntArray(count)
        for (i in 0 until count) {
            if (end - cursor < 4) {
                frameLease.updateRetainedAttachmentBytes(retainedAttachmentBytes + retainedJsonBytes)
                return
            }
            val attLen = input.getInt(cursor)
            validateAttachmentLength(attLen)
            declaredAttachmentBytes += attLen.toLong()
            if (declaredAttachmentBytes > Libp2pRpcProtocol.MAX_ATTACHMENT_AGGREGATE_BYTES) {
                throw CorruptedFrameException(
                    Libp2pRpcProtocol.attachmentAggregateLimitMessage(declaredAttachmentBytes, count)
                )
            }
            // Each interleaved header contributes once. Re-reading an earlier length must leave
            // the allowance from the already validated later headers intact.
            if (i >= validatedAttachmentLengthCount) {
                validatedAttachmentDeadlineMs.set(
                    Libp2pRpcProtocol.attachmentLeaseDeadlineMs(declaredAttachmentBytes)
                )
                validatedAttachmentLengthCount = i + 1
            }
            cursor += 4
            attachmentOffsets[i] = cursor
            attachmentLengths[i] = attLen
            retainedAttachmentBytes += minOf(attLen, (end - cursor).coerceAtLeast(0)).toLong()
            frameLease.updateRetainedAttachmentBytes(retainedAttachmentBytes + retainedJsonBytes)
            if (end - cursor < attLen) return // lease covers it; wait for the body bytes
            cursor += attLen
        }

        // The whole message is buffered and every bound validated. Copy each attachment out and
        // emit; RELEASE (not close) the lease once the frame is handed off — this decoder
        // instance is reused for the NEXT message on the same stream, so the lease must be
        // reusable. Only teardown (handlerRemoved0) permanently closes it.
        val attachments = ArrayList<ByteArray>(count)
        var transferred = false
        try {
            for (i in 0 until count) {
                val att = ByteArray(attachmentLengths[i])
                if (attachmentLengths[i] > 0) {
                    input.getBytes(attachmentOffsets[i], att)
                }
                attachments.add(att)
            }
            input.readerIndex(cursor) // commit: consume the whole message
            val frame = Libp2pRpcProtocol.MessageFrame(json, attachments)
            if (withdrawalFrame) {
                val owner = frameLease.retainMemoryAfterFrame(retainedJsonBytes + declaredAttachmentBytes)
                try {
                    out.add(ParseBudgetedInboundMessage(null, frame, owner, retainedJsonBytes + declaredAttachmentBytes))
                    transferred = true
                } catch (failure: Throwable) {
                    owner.close()
                    throw failure
                }
            } else out.add(frame)
        } finally {
            cancelStallWatchdog()
            validatedAttachmentDeadlineMs = java.util.concurrent.atomic.AtomicLong(0L)
            validatedAttachmentLengthCount = 0
            lastProgressWriterIndex = 0
            ownsPhysicalReadRearm = false
            lease = null
            if (!transferred) frameLease.release()
        }
    }

    override fun channelReadComplete(ctx: ChannelHandlerContext) {
        super.channelReadComplete(ctx)
        if (
            !ownsPhysicalReadRearm || awaitingAdmission || borrowPaused ||
            lease?.isHeld != true || !ctx.channel().isActive
        ) {
            return
        }
        // A MuxChannel forwards channelReadComplete to this child but does not necessarily issue
        // another physical read. Continue a partial admitted frame, but only if this decoder owns
        // the continuation and the inbound-substream cap is not the reason the physical parent is
        // paused.
        requestPhysicalRead(ctx)
    }

    private fun requestPhysicalRead(ctx: ChannelHandlerContext) {
        if (!ownsPhysicalReadRearm) {
            return
        }
        if (awaitingAdmission) {
            return
        }
        if (borrowPaused) {
            return
        }
        if (lease?.isHeld != true) {
            return
        }
        // Another decoder or the request-admission handler may still own the child-channel pause.
        // Do not re-arm the physical parent until this channel's coordinator has released it.
        if (!ctx.channel().config().isAutoRead) {
            return
        }
        val parent = ctx.channel().parent()
        if (parent == null || parent is io.netty.channel.ServerChannel) {
            ctx.channel().read()
            return
        }
        if (!parent.config().isAutoRead) {
            requestPhysicalReadIfAdmissionAllows(parent) {
                if (!parent.config().isAutoRead) parent.read()
            }
        }
    }

    private fun validateAttachmentLength(attachmentLength: Int) {
        if (attachmentLength < 0 || attachmentLength > MAX_ATTACHMENT_BYTES) {
            throw CorruptedFrameException(
                "Invalid RPC attachment length: $attachmentLength " +
                    "(must be 0..$MAX_ATTACHMENT_BYTES)"
            )
        }
    }

    /**
     * Starts the minimum-progress stall watchdog for the lease we just acquired (idempotent while
     * one is already running). Runs on the shared watchdog scheduler, NOT the event loop; on a
     * no-progress stall it asks the event loop to close the channel only while this frame still
     * owns the lease. Channel teardown (handlerRemoved0) releases the lease.
     */
    private fun startStallWatchdog(
        ctx: ChannelHandlerContext,
        watchedLease: Libp2pRpcProtocol.FrameAttachmentLease
    ) {
        if (stallWatchdog != null) return
        lastProgressWriterIndex = 0 // reset; decode() updates lastStallProgressMs on real growth
        val nowMs = Libp2pRpcProtocol.attachmentClock.currentTimeMillis()
        lastStallProgressMs.set(nowMs)
        val leaseAcquiredAtMs = nowMs
        val watchedDeadlineMs = validatedAttachmentDeadlineMs
        val expiredAt = { checkMs: Long ->
            (!stallClockSuspendedByBorrow &&
                checkMs - lastStallProgressMs.get() > Libp2pRpcProtocol.ATTACHMENT_STALL_TIMEOUT_MS) ||
                checkMs - leaseAcquiredAtMs > watchedDeadlineMs.get()
        }
        val retirementPending = AtomicBoolean(false)
        val decisionTime = java.util.concurrent.atomic.AtomicLong()
        val retirement = try {
            attachmentRetirementMailbox(ctx.channel().eventLoop()).register({
            try {
                // The decoder and its cumulation have one owner: this loop. Teardown discards
                // the input before handlerRemoved0 returns the corresponding reservation.
                if (lease === watchedLease && watchedLease.isHeld && expiredAt(decisionTime.get())) {
                    discardRetiredFrame(ctx, watchedLease)
                }
            } finally {
                retirementPending.set(false)
            }
            }, {
                discardRetiredFrame(ctx, watchedLease)
            })
        } catch (failure: Throwable) {
            discardRetiredFrame(ctx, watchedLease)
            throw failure
        }
        stallRetirement = retirement
        stallWatchdog = Libp2pRpcProtocol.scheduleAttachmentStallWatchdog(Runnable {
            if (!watchedLease.isHeld) return@Runnable
            val checkMs = Libp2pRpcProtocol.attachmentClock.currentTimeMillis()
            if (expiredAt(checkMs) && retirementPending.compareAndSet(false, true)) {
                decisionTime.set(checkMs)
                retirement.signal()
            }
        })
    }

    private fun discardRetiredFrame(
        ctx: ChannelHandlerContext,
        watchedLease: Libp2pRpcProtocol.FrameAttachmentLease,
    ) {
        if (lease !== watchedLease) return
        // Removing an ordinary decoder forwards unread input. An expired frame instead owns
        // a discard: make it unreadable first, then let Netty release its cumulation before
        // handlerRemoved0 closes the lease. This does not depend on a later close callback
        // finding room in a task queue, including during loop shutdown.
        val input = internalBuffer()
        input.skipBytes(input.readableBytes())
        ctx.pipeline().remove(this)
        ctx.channel().close()
    }

    private fun cancelStallWatchdog() {
        stallRetirement?.close()
        stallRetirement = null
        stallWatchdog?.cancel(false)
        stallWatchdog = null
    }

    /**
     * Pauses channel reads and asynchronously waits for this physical connection's frame turn and
     * fixed process reservation. Both waits use callback queues and occupy no admission worker. On
     * success, re-enables reads and re-drives the decoder on the event loop so
     * buffered/subsequent bytes are processed. On failure or close, the channel is closed; the
     * lease's close-safe acquisition returns any resources it wins after teardown, and
     * handlerRemoved0 closes the lease.
     */
    private fun pauseAndAdmit(
        ctx: ChannelHandlerContext,
        pendingLease: Libp2pRpcProtocol.FrameAttachmentLease
    ) {
        ownsPhysicalReadRearm = true
        awaitingAdmission = true
        ctx.setRpcServerAutoRead(false, admissionReadPauseOwner)
        pendingLease.acquireAsync { admitted, failure ->
            val finishAdmission = Runnable {
                awaitingAdmission = false
                if (admitted && ctx.channel().isActive && lease === pendingLease) {
                    // The lease is now held; arm the stall watchdog before resuming reads so a
                    // peer that stalls after admission cannot pin the pool indefinitely.
                    startStallWatchdog(ctx, pendingLease)
                    // A JSON frame elsewhere may have borrowed this frame's declared-but-unarrived
                    // headroom while admission was in flight, pausing these reads. Resuming here
                    // would read out from under a live borrow; the borrower's own resume re-enables
                    // reads and re-drives this decoder, so simply leave them paused.
                    // Release this decoder's admission pause even when a borrower still owns a
                    // separate pause. The coordinator keeps autoRead disabled until both owners
                    // have released it; the borrower will re-drive the decoder when it resumes.
                    ctx.setRpcServerAutoRead(true, admissionReadPauseOwner)
                    if (!borrowPaused && ctx.channel().config().isAutoRead) {
                        // Re-drive so this decoder re-runs on bytes ALREADY cumulated before the
                        // pause. EMPTY_BUFFER is an unreleasable singleton. If the physical parent
                        // is manually read, re-arm that parent as well; a libp2p MuxChannel's child
                        // read operation is otherwise a no-op.
                        ctx.pipeline().fireChannelRead(io.netty.buffer.Unpooled.EMPTY_BUFFER)
                        requestPhysicalRead(ctx)
                    }
                } else {
                    // Admission failed/interrupted or the channel died while waiting. If we did
                    // win the lease for a now-dead channel, release it (handlerRemoved0 also
                    // closes, but this covers the pre-removal window).
                    if (admitted) pendingLease.close()
                    ctx.close()
                }
                if (failure != null) {
                    ctx.fireExceptionCaught(failure)
                }
            }
            try {
                ctx.channel().eventLoop().execute(finishAdmission)
            } catch (schedulingFailure: Throwable) {
                if (admitted) pendingLease.close()
                ctx.close()
                if (failure != null) schedulingFailure.addSuppressed(failure)
                ctx.fireExceptionCaught(schedulingFailure)
            }
        }
    }

    private fun pauseAndAdmitJson(
        ctx: ChannelHandlerContext,
        currentJsonLease: Libp2pRpcProtocol.FrameParseLease
    ) {
        awaitingAdmission = true
        ctx.setRpcServerAutoRead(false, admissionReadPauseOwner)
        jsonAdmissionExecutor.execute {
            var admitted = false
            var failure: Throwable? = null
            try {
                admitted = currentJsonLease.acquire()
            } catch (caught: Throwable) {
                failure = caught
            }
            ctx.channel().eventLoop().execute {
                awaitingAdmission = false
                if (admitted && ctx.channel().isActive) {
                    // As in pauseAndAdmit: a live borrow against this decoder's attachment lease
                    // owns the pause, and its resume re-drives us. Do not read out from under it.
                    // Release the admission owner independently of any live borrow owner.
                    ctx.setRpcServerAutoRead(true, admissionReadPauseOwner)
                    if (!borrowPaused && ctx.channel().config().isAutoRead) {
                        ctx.pipeline().fireChannelRead(io.netty.buffer.Unpooled.EMPTY_BUFFER)
                    }
                } else {
                    if (admitted) currentJsonLease.close()
                    ctx.close()
                }
                failure?.let { ctx.fireExceptionCaught(it) }
            }
        }
    }

    /**
     * Applies one borrower's pause or resume request to this decoder's reads.
     *
     * Requests are COUNTED rather than latched. Borrow accounting lives on the lease, but the pause
     * lives on this decoder, and the two do not share a lifetime: several JSON frames can borrow at
     * once, and a borrow taken against one lease generation can be released after this decoder has
     * moved on to the next. Counting is what makes "resume only when NO live borrow still needs the
     * pause" a property of the decoder rather than of whichever lease happened to answer last. Every
     * successful pause request is matched by exactly one resume request from its borrower, so the
     * count returns to zero; it is clamped at zero so a resume arriving after teardown reset it is
     * harmless.
     */
    private fun setBorrowReadPaused(
        ctx: ChannelHandlerContext,
        paused: Boolean,
        completed: (Throwable?) -> Unit
    ) {
        val applyState = Runnable {
            val wasBorrowPaused = borrowPaused
            borrowPauseRequests = (borrowPauseRequests + if (paused) 1 else -1).coerceAtLeast(0)
            borrowPaused = borrowPauseRequests > 0
            try {
                if (borrowPaused && !wasBorrowPaused) {
                    stallClockSuspendedByBorrow = true
                    ctx.setRpcServerAutoRead(false, borrowReadPauseOwner)
                } else if (!borrowPaused && wasBorrowPaused) {
                    lastStallProgressMs.set(Libp2pRpcProtocol.attachmentClock.currentTimeMillis())
                    stallClockSuspendedByBorrow = false
                    ctx.setRpcServerAutoRead(true, borrowReadPauseOwner)
                }
                if (
                    !borrowPaused && wasBorrowPaused && ctx.channel().isActive &&
                    ctx.channel().config().isAutoRead && !awaitingAdmission
                ) {
                    ctx.pipeline().fireChannelRead(io.netty.buffer.Unpooled.EMPTY_BUFFER)
                    if (lease?.isHeld == true) requestPhysicalRead(ctx)
                }
                completed(null)
            } catch (failure: Throwable) {
                completed(failure)
                ctx.fireExceptionCaught(failure)
                ctx.close()
            }
        }
        if (ctx.channel().eventLoop().inEventLoop()) {
            applyState.run()
        } else {
            try {
                ctx.channel().eventLoop().execute(applyState)
            } catch (failure: Throwable) {
                // The event loop is gone, so this request never reaches the count. The borrower
                // still issues its matching resume, which the clamp absorbs; the decoder is being
                // torn down (handlerRemoved0 zeroes the count) so its read state no longer matters.
                completed(failure)
                ctx.fireExceptionCaught(failure)
                ctx.close()
            }
        }
    }

    override fun handlerRemoved0(ctx: ChannelHandlerContext) {
        // Permanently close the lease when this decoder leaves the pipeline (channel close,
        // pipeline teardown). Idempotent, and a racing asynchronous grant returns its resources
        // itself after observing the closed lease.
        closeCurrentFrameLease()
    }

    private fun closeCurrentFrameLease() {
        cancelStallWatchdog()
        validatedAttachmentDeadlineMs = java.util.concurrent.atomic.AtomicLong(0L)
        validatedAttachmentLengthCount = 0
        jsonArrivalGuard.disarm()
        lastProgressWriterIndex = 0
        ownsPhysicalReadRearm = false
        borrowPauseRequests = 0
        borrowPaused = false
        stallClockSuspendedByBorrow = false
        val currentLease = lease
        lease = null
        currentLease?.close()
        jsonLease?.close()
        jsonLease = null
    }

    private companion object {
        // Mirrors the 1.0.0 server pipeline's LengthFieldBasedFrameDecoder(10_000_000, ...)
        // and readJsonFrame's 10 MB JSON cap.
        const val MAX_JSON_FRAME_BYTES = 10_000_000
        // Mirrors readMessageFrameFromStream's attachment bounds
        // (Libp2pRpcProtocol.MAX_ATTACHMENTS / MAX_SINGLE_ATTACHMENT_BYTES).
        const val MAX_ATTACHMENTS = Libp2pRpcProtocol.MAX_ATTACHMENTS
        const val MAX_ATTACHMENT_BYTES = Libp2pRpcProtocol.MAX_SINGLE_ATTACHMENT_BYTES
    }
}

/**
 * Unified RPC binding handling both initiator (client) and responder (server)
 * roles, announcing BOTH /aicli-rpc/1.1.0 (attachment-capable) and
 * /aicli-rpc/1.0.0 (base64). multistream-select negotiates the best common
 * version with no extra round trip; the negotiated id selects the responder
 * pipeline and is reported via [Libp2pRpcController.negotiatedProtocolId].
 *
 * - Initiator: returns a [NettyStreamController] carrying the negotiated id.
 * - Responder on 1.1.0: ReadTimeout -> [AttachmentRpcFrameDecoder] -> [RpcServerMessageHandler]
 *   (ByteArray request params arrive as raw binary attachments).
 * - Responder on 1.0.0: ReadTimeout -> LengthFieldBasedFrameDecoder -> [RpcServerMessageHandler]
 *   (unchanged legacy/base64 pipeline).
 *
 * A SINGLE multi-protocol binding is required for the initiator role; see the
 * note on [Libp2pRpcBinding].
 */
class UnifiedRpcProtocolBinding(
    private val requestHandler: RpcRequestHandler,
    private val gossipHandler: GossipHandler? = null,
    private val idleTimeoutSeconds: Long = RPC_STREAM_IDLE_TIMEOUT_SECONDS,
    private val onDirectPeerContact: ((String) -> Unit)? = null
) : ProtocolBinding<Libp2pRpcController> {
    private var reconciliationClock: Clock = SystemClock()
    private var idleClock: Clock = SystemClock()

    /**
     * Uses [reconciliationClock] as a fallback for raw host DSL roots without a configured clock.
     * Host factories publish their root clock before protocol initialization, and that root value
     * remains authoritative for every outbox on the connection. Checks do not expire writes on
     * live connections unless protocol close already owns their paused output.
     */
    constructor(
        requestHandler: RpcRequestHandler,
        reconciliationClock: Clock,
        gossipHandler: GossipHandler? = null,
        idleTimeoutSeconds: Long = RPC_STREAM_IDLE_TIMEOUT_SECONDS,
        onDirectPeerContact: ((String) -> Unit)? = null,
    ) : this(requestHandler, gossipHandler, idleTimeoutSeconds, onDirectPeerContact) {
        this.reconciliationClock = reconciliationClock
    }

    /** One aggregate budget for every incoming stream using this direct binding. */
    private var peerExchangeRequestScope: PeerExchangeRequestScope = PeerExchangeRequestScope()
    private var announcementScope = OneShotGossipScope()
    private var readPauseObserver: RpcReadPauseObserver? = null
    private val lifecycleAttached = AtomicBoolean(false)

    /**
     * Creates a binding with an observer for the request-admission pause transition.
     *
     * The observer is called only for the 100-pending-request pause and its matching resume. The
     * normal four-argument constructor remains unchanged for existing callers.
     */
    constructor(
        requestHandler: RpcRequestHandler,
        gossipHandler: GossipHandler?,
        idleTimeoutSeconds: Long,
        onDirectPeerContact: ((String) -> Unit)?,
        readPauseObserver: RpcReadPauseObserver
    ) : this(requestHandler, gossipHandler, idleTimeoutSeconds, onDirectPeerContact) {
        this.readPauseObserver = readPauseObserver
    }

    /** Retains the existing JVM constructor for already compiled callers. */
    internal constructor(
        requestHandler: RpcRequestHandler,
        gossipHandler: GossipHandler?,
        idleTimeoutSeconds: Long,
        onDirectPeerContact: ((String) -> Unit)?,
        peerExchangeRequestScope: PeerExchangeRequestScope,
        reconciliationClock: Clock,
    ) : this(
        requestHandler, gossipHandler, idleTimeoutSeconds, onDirectPeerContact,
        peerExchangeRequestScope, reconciliationClock, SystemClock(),
    )

    internal constructor(
        requestHandler: RpcRequestHandler,
        gossipHandler: GossipHandler?,
        idleTimeoutSeconds: Long,
        onDirectPeerContact: ((String) -> Unit)?,
        peerExchangeRequestScope: PeerExchangeRequestScope,
        reconciliationClock: Clock,
        idleClock: Clock,
        announcementScope: OneShotGossipScope = OneShotGossipScope(),
    ) : this(requestHandler, gossipHandler, idleTimeoutSeconds, onDirectPeerContact) {
        this.announcementScope = announcementScope
        this.peerExchangeRequestScope = peerExchangeRequestScope
        this.reconciliationClock = reconciliationClock
        this.idleClock = idleClock
    }

    /**
     * Wrap a host that was built with this public binding so its stop operation owns and joins the
     * binding's aggregate PeerExchange and one-way announcement drains. The returned host must be used in place of
     * [delegate]; stopping the unwrapped delegate cannot join a protocol binding's request work
     * because the underlying libp2p Host API has no protocol-lifecycle callback.
     */
    fun withHostLifecycle(delegate: Host): Host {
        check(lifecycleAttached.compareAndSet(false, true)) {
            "UnifiedRpcProtocolBinding can be attached to only one host lifecycle"
        }
        return PeerExchangeLifecycleHost(delegate, peerExchangeRequestScope, announcementScope)
    }

    /** Returns this binding's aggregate PeerExchange admission diagnostics. */
    fun peerExchangeAdmissionSnapshot(): PeerExchangeAdmissionSnapshot =
        peerExchangeRequestScope.snapshot()

    override val protocolDescriptor = ProtocolDescriptor(
        listOf(Libp2pRpcProtocol.PROTOCOL_ID_V11, Libp2pRpcProtocol.PROTOCOL_ID)
    )

    override fun initChannel(
        ch: io.libp2p.core.P2PChannel,
        selectedProtocol: String
    ): CompletableFuture<Libp2pRpcController> {
        val stream = ch as? Stream
            ?: return CompletableFuture.failedFuture(IllegalArgumentException("Expected Stream"))

        // stream.isInitiator (stream-level, NOT connection-level): in a multiplexed
        // connection either side can open streams; using connection.isInitiator
        // would start client mode for a peer-opened stream and silently drop
        // inbound gossip. Apply explicit WriteBufferWaterMark so
        // writeFramedBufferWithBackpressure has a meaningful isWritable to gate on.
        streamAsChannel(stream)?.let {
            awaitedResponseOutboxFor(it, installHandler = false, reconciliationClock = reconciliationClock)
        }
        configureWriteBackpressure(stream)
        return if (stream.isInitiator) {
            // We initiated this stream - we're the client wanting a controller.
            CompletableFuture.completedFuture(NettyStreamController(stream, selectedProtocol))
        } else {
            // Remote peer initiated this stream - set up the non-blocking pipeline.
            // PauseAwareReadTimeoutHandler first so it sees ALL raw reads (partial arrivals reset
            // the idle timer) without treating a server-owned manual-read pause as peer silence.
            stream.pushHandler(PauseAwareReadTimeoutHandler(idleTimeoutSeconds, idleClock))
            if (selectedProtocol == Libp2pRpcProtocol.PROTOCOL_ID_V11) {
                // Attachment-capable framing: ByteArray request params arrive as raw
                // binary attachments instead of base64-in-JSON. Emits MessageFrames.
                stream.pushHandler(AttachmentRpcFrameDecoder(
                    childPauseHoldsWholeConnection =
                        stream.connection.muxerSession() !is io.libp2p.mux.yamux.YamuxHandler,
                ))
            } else {
                // Legacy 1.0.0 framing: 4-byte big-endian length prefix; ByteArrays are
                // base64-in-JSON. Emits ByteBufs. (Unchanged from before 1.1.0.)
                stream.pushHandler(ParseBudgetedJsonFrameDecoder())
            }
            stream.pushHandler(
                RpcServerMessageHandler(
                    stream,
                    requestHandler,
                    gossipHandler,
                    onDirectPeerContact,
                    binaryResponseAttachments = selectedProtocol == Libp2pRpcProtocol.PROTOCOL_ID_V11,
                    peerExchangeRequestScope = peerExchangeRequestScope,
                    readPauseObserver = readPauseObserver,
                    announcementScope = announcementScope,
                )
            )
            CompletableFuture.completedFuture(NoOpRpcController)
        }
    }
}

/**
 * Protocol binding for relay connections (server-side).
 */
class RelayProtocolBinding(
    private val relayService: RelayService
) : StrictProtocolBinding<Unit>(
    RelayProtocol.PROTOCOL_ID,
    RelayServerProtocol(relayService)
)

/**
 * Protocol binding for relay connections using a deferred handler.
 * Uses unified protocol that handles both initiator (client) and responder (server) roles.
 * This allows registering the protocol before the RelayService is created.
 */
class DeferredRelayProtocolBinding(
    handler: DeferredRelayHandler
) : StrictProtocolBinding<RelayMessageSender>(
    RelayProtocol.PROTOCOL_ID,
    UnifiedRelayProtocol(handler)
)

/**
 * Protocol binding for relay connections (client-side).
 * Returns a RelayStreamController for bidirectional communication.
 */
class RelayClientProtocolBinding : StrictProtocolBinding<RelayStreamController>(
    RelayProtocol.PROTOCOL_ID,
    RelayClientProtocol()
)

/**
 * Deferred handler for relay streams.
 * Streams are queued until a RelayService is set, then forwarded to it.
 *
 * Returns a CompletableFuture that completes with the RelayMessageSender
 * created by the RelayService, allowing callers to reuse the same sender
 * instead of creating a duplicate (which would interfere with data reception).
 *
 * Thread-safety: Uses a lock to ensure that handleStream and setRelayService
 * are atomic with respect to each other, preventing a race condition where
 * streams could be lost if they arrive during service initialization.
 */
class DeferredRelayHandler {

    private val lock = java.util.concurrent.locks.ReentrantLock()
    private var relayService: RelayService? = null
    private val pendingStreams = java.util.concurrent.ConcurrentLinkedQueue<Pair<Stream, CompletableFuture<RelayMessageSender>>>()

    /**
     * Sets the RelayService to handle streams.
     * Any pending streams will be forwarded immediately and their futures completed.
     *
     * After this method returns, all future calls to handleStream will forward
     * directly to the service (no queuing).
     */
    fun setRelayService(service: RelayService) {
        publishRelayService(service).invoke()
    }

    // Publication changes only local state. The caller runs the returned dispatch outside
    // its admission monitor because handling pending streams can invoke supplied code.
    internal fun publishRelayService(service: RelayService): () -> Unit {
        lock.lock()
        try {
            this.relayService = service
        } finally {
            lock.unlock()
        }
        return { dispatchPendingStreams(service) }
    }

    private fun dispatchPendingStreams(service: RelayService) {
        // Process any pending streams AFTER releasing the lock.
        // This is safe because once relayService is set, no new streams will be queued.
        while (true) {
            val (stream, future) = pendingStreams.poll() ?: break
            try {
                val sender = service.handleIncomingStream(stream)
                future.complete(sender)
            } catch (e: Exception) {
                future.completeExceptionally(e)
            }
        }
    }

    /**
     * Handles an incoming stream.
     * If RelayService is set, forwards immediately and returns the controller.
     * Otherwise, queues for later and returns a future that will complete when processed.
     *
     * Thread-safe: The lock only guards the check-and-act on relayService and the
     * pending queue. handleIncomingStream is called outside the lock to avoid
     * serializing Netty pipeline setup across all incoming streams.
     */
    fun handleStream(stream: Stream): CompletableFuture<RelayMessageSender> {
        debugLog { "[RELAY-DEBUG] DeferredRelayHandler.handleStream called, remotePeer=${stream.remotePeerId()}" }
        lock.lock()
        try {
            val service = relayService
            if (service != null) {
                // Capture non-null reference; unlock before calling handleIncomingStream
                // to avoid serializing Netty pipeline setup across all incoming streams.
                lock.unlock()
                debugLog { "[RELAY-DEBUG] Forwarding to RelayService.handleIncomingStream" }
                val sender = service.handleIncomingStream(stream)
                return CompletableFuture.completedFuture(sender)
            } else {
                debugLog { "[RELAY-DEBUG] No RelayService yet, queuing stream" }
                val future = CompletableFuture<RelayMessageSender>()
                pendingStreams.offer(Pair(stream, future))
                return future
            }
        } finally {
            if (lock.isHeldByCurrentThread) {
                lock.unlock()
            }
        }
    }
}

/**
 * Server-side relay protocol implementation using a deferred handler.
 */
class DeferredRelayServerProtocol(
    private val handler: DeferredRelayHandler
) : io.libp2p.core.P2PChannelHandler<Unit> {
    override fun initChannel(ch: io.libp2p.core.P2PChannel): CompletableFuture<Unit> {
        debugLog { "[RELAY-DEBUG] DeferredRelayServerProtocol.initChannel called" }
        val stream = ch as? Stream
            ?: return CompletableFuture.failedFuture(IllegalArgumentException("Expected Stream"))
        debugLog { "[RELAY-DEBUG] Received stream from peer: ${stream.remotePeerId()}" }
        handler.handleStream(stream)
        return CompletableFuture.completedFuture(Unit)
    }
}

/**
 * Client-side relay protocol implementation.
 * Returns a RelayStreamController for bidirectional communication with the relay.
 */
class RelayClientProtocol : io.libp2p.core.P2PChannelHandler<RelayStreamController> {
    override fun initChannel(ch: io.libp2p.core.P2PChannel): CompletableFuture<RelayStreamController> {
        val stream = ch as? Stream
            ?: return CompletableFuture.failedFuture(IllegalArgumentException("Expected Stream"))
        val controller = RelayStreamController(stream)
        return CompletableFuture.completedFuture(controller)
    }
}

/**
 * Unified relay protocol implementation that handles both initiator (client) and responder (server) roles.
 * When we initiate a stream (client), returns RelayStreamController.
 * When we receive an incoming stream (server), forwards to the handler.
 *
 * This solves the problem of having two separate protocol bindings for the same protocol ID,
 * which caused ClassCastException when the wrong handler was invoked.
 */
class UnifiedRelayProtocol(
    private val handler: DeferredRelayHandler
) : io.libp2p.core.P2PChannelHandler<RelayMessageSender> {
    override fun initChannel(ch: io.libp2p.core.P2PChannel): CompletableFuture<RelayMessageSender> {
        val stream = ch as? Stream
            ?: return CompletableFuture.failedFuture(IllegalArgumentException("Expected Stream"))

        // Check if we initiated this STREAM (not connection) to determine our role.
        // CRITICAL: Use stream.isInitiator (stream-level) instead of stream.connection.isInitiator.
        // See UnifiedRpcProtocolBinding.initChannel for detailed explanation.
        return if (stream.isInitiator) {
            // We initiated this stream - we're the client wanting a controller
            // Returns RelayStreamController (which implements RelayMessageSender) for client-side use.
            // Callers that need the full RelayStreamController (for readMessage()) cast the result.
            debugLog { "[RELAY-DEBUG] UnifiedRelayProtocol: Initiator mode, returning controller for peer ${stream.remotePeerId()}" }
            val controller = RelayStreamController(stream)
            CompletableFuture.completedFuture(controller)
        } else {
            // Remote peer initiated this stream - set up NIO pipeline via handler.
            // Returns a StreamRelayMessageSender (write-only, no blocking reader thread).
            debugLog { "[RELAY-DEBUG] UnifiedRelayProtocol: Responder mode, handling stream from peer ${stream.remotePeerId()}" }
            handler.handleStream(stream)
        }
    }
}

/**
 * Server-side relay protocol implementation.
 */
class RelayServerProtocol(
    private val relayService: RelayService
) : io.libp2p.core.P2PChannelHandler<Unit> {
    override fun initChannel(ch: io.libp2p.core.P2PChannel): CompletableFuture<Unit> {
        val stream = ch as? Stream
            ?: return CompletableFuture.failedFuture(IllegalArgumentException("Expected Stream"))
        relayService.handleIncomingStream(stream)
        return CompletableFuture.completedFuture(Unit)
    }
}

/** Stored failure data stays private; callers own their exception and suppression list. */
private class RawStreamFailure(
    val message: String,
    val cause: Throwable?,
    val causedByLocalClose: Boolean = false,
)

private fun rawStreamException(failure: RawStreamFailure): IOException =
    IOException(failure.message, failure.cause)

/** Only live raw writes are retained; the first transport failure is terminal for this output. */
private class RawStreamWrites(val clock: Clock, val closeStalledStream: (IOException) -> Unit) {
    val lock = Any()
    val pending = LinkedHashSet<RawStreamWrite>()
    var accepting = true
    var failure: RawStreamFailure? = null
    var progressAtMillis = 0L
    @Volatile var connectionProgress: RawStreamProgressRegistry? = null
    var stall: RawStreamStall? = null
    val retiredStalls = ArrayList<RawStreamStall>()
}

private class RawStreamStall {
    val registration = AtomicReference<RawStreamStallRegistration?>()
}

private class RawStreamStallRegistration {
    val scheduled = AtomicReference<Scheduled?>()
}

private enum class RawStreamWriteState(val terminal: Boolean) {
    REGISTERED(false), SUBMITTED(false), COMPLETED(true), FAILED(true), CANCELLED(true),
}

private class RawStreamWrite {
    val waiters = HashSet<CountDownLatch>()
    @Volatile var state = RawStreamWriteState.REGISTERED
    @Volatile var failure: RawStreamFailure? = null
}

private fun rawStreamWriteClock(stream: Stream): Clock = streamAsChannel(stream)?.let {
    libp2pRootConnectionChannel(it).attr(AWAITED_RESPONSE_RECONCILIATION_CLOCK_ATTR).get()
} ?: SystemClock()

/** Detach the timer atomically with the last terminal write, before a new writer can enter. */
private fun retireIdleRawStreamStallLocked(writes: RawStreamWrites) {
    if (writes.pending.none { it.state == RawStreamWriteState.SUBMITTED }) {
        writes.stall?.let { writes.retiredStalls.add(it) }
        writes.stall = null
    }
}

/** Timer cancellation never runs while the write-state monitor is held. */
private fun cancelIdleRawStreamStall(writes: RawStreamWrites) {
    val retired = synchronized(writes.lock) {
        writes.retiredStalls.toList().also { writes.retiredStalls.clear() }
    }
    retired.forEach { it.registration.getAndSet(null)?.scheduled?.getAndSet(null)?.cancel() }
}

private fun recordRawStreamProgress(writes: RawStreamWrites) {
    val now = writes.clock.currentTimeMillis()
    synchronized(writes.lock) {
        if (writes.stall != null && writes.accepting) writes.progressAtMillis = maxOf(writes.progressAtMillis, now)
    }
}

/** One timer belongs to the controller's submitted writes, never to an individual flush. */
private fun armRawStreamStall(writes: RawStreamWrites) {
    val now = writes.clock.currentTimeMillis()
    val ticket = synchronized(writes.lock) {
        if (writes.stall != null || !writes.accepting ||
            writes.pending.none { it.state == RawStreamWriteState.SUBMITTED }) return
        RawStreamStall().also {
            writes.progressAtMillis = now
            writes.stall = it
        }
    }
    scheduleRawStreamStall(writes, ticket, now + Libp2pRpcProtocol.ATTACHMENT_STALL_TIMEOUT_MS)
}

private fun scheduleRawStreamStall(writes: RawStreamWrites, ticket: RawStreamStall, atMillis: Long) {
    val registration = RawStreamStallRegistration()
    ticket.registration.getAndSet(registration)?.scheduled?.getAndSet(null)?.cancel()
    val scheduled = writes.clock.schedule(atMillis) {
        if (!ticket.registration.compareAndSet(registration, null)) return@schedule
        val now = writes.clock.currentTimeMillis()
        var nextAt: Long? = null
        var stalled: IOException? = null
        synchronized(writes.lock) {
            if (writes.stall !== ticket) return@schedule
            val deadline = maxOf(writes.progressAtMillis,
                writes.connectionProgress?.peerProgressAtMillis?.get() ?: writes.progressAtMillis,
            ) + Libp2pRpcProtocol.ATTACHMENT_STALL_TIMEOUT_MS
            if (now < deadline) {
                nextAt = deadline
            } else {
                stalled = IOException(
                    "Raw stream write made no transport progress for ${Libp2pRpcProtocol.ATTACHMENT_STALL_TIMEOUT_MS}ms"
                )
                // Select one terminal result and release every waiter before requesting close.
                failRawStreamWritesLocked(writes, RawStreamFailure(
                    "Raw stream transport write failed (java.io.IOException)", stalled,
                ))
                writes.stall = null
            }
        }
        nextAt?.let { scheduleRawStreamStall(writes, ticket, it) }
        stalled?.let {
            cancelIdleRawStreamStall(writes)
            writes.closeStalledStream(it)
        }
    }
    registration.scheduled.set(scheduled)
    val active = synchronized(writes.lock) { writes.stall === ticket }
    if (!active || ticket.registration.get() !== registration) {
        registration.scheduled.getAndSet(null)?.cancel()
    }
}

private val RAW_STREAM_PROGRESS_ATTR = AttributeKey.valueOf<RawStreamProgressRegistry>(
    "foundation.url.protocol.rawStreamProgress"
)
private val RAW_STREAM_ENCODING_OWNER = ThreadLocal<RawStreamWrites?>()

private class RawStreamProgressRegistry(val clock: Clock, val yamux: Boolean) {
    // No peer progress has been observed; the injected clock may start before zero.
    val peerProgressAtMillis = AtomicLong(Long.MIN_VALUE)
    val children = ConcurrentHashMap<io.libp2p.etc.util.netty.mux.MuxId, RawStreamWrites>()
}

private fun retainRawStreamFailureDetail(writes: RawStreamWrites, failure: Throwable) {
    synchronized(writes.lock) {
        val first = writes.failure?.cause
        if (first != null && first !== failure && first.suppressed.none { it === failure }) first.addSuppressed(failure)
    }
}

/**
 * The frame identifies the child before encoding; the socket promise reports accepted bytes
 * after encoding. The scoped owner crosses only the synchronous outbound encoder chain.
 */
private fun installRawStreamProgressObserver(root: io.netty.channel.Channel, registry: RawStreamProgressRegistry) {
    val pipeline = root.pipeline()
    val mux = pipeline.context(io.libp2p.mux.yamux.YamuxHandler::class.java)
        ?: pipeline.context(io.libp2p.mux.mplex.MplexHandler::class.java) ?: return
    pipeline.addBefore(mux.name(), "foundation.url.protocol.rawFrameProgress", object : ChannelDuplexHandler() {
        override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
            if (msg is io.libp2p.mux.yamux.YamuxFrame &&
                msg.type == io.libp2p.mux.yamux.YamuxType.WINDOW_UPDATE && msg.length > 0L) {
                val now = registry.clock.currentTimeMillis()
                registry.peerProgressAtMillis.getAndUpdate { old -> maxOf(old, now) }
            }
            ctx.fireChannelRead(msg)
        }
        override fun write(ctx: ChannelHandlerContext, msg: Any, promise: ChannelPromise) {
            val id = when (msg) {
                is io.libp2p.mux.yamux.YamuxFrame -> if (
                    msg.type == io.libp2p.mux.yamux.YamuxType.DATA && msg.data?.isReadable == true
                ) msg.id else null
                is io.libp2p.mux.mplex.MplexFrame -> if (msg.data?.isReadable == true) msg.id else null
                else -> null
            }
            val owner = id?.let { registry.children[it] }?.takeIf { writes ->
                synchronized(writes.lock) { writes.stall != null && writes.accepting }
            }
            if (owner != null) promise.addListener { completed ->
                if (completed.isSuccess) recordRawStreamProgress(owner)
                else completed.cause()?.let { retainRawStreamFailureDetail(owner, it) }
            }
            val previous = RAW_STREAM_ENCODING_OWNER.get()
            RAW_STREAM_ENCODING_OWNER.set(owner)
            try {
                ctx.write(msg, promise)
            } finally {
                if (previous == null) RAW_STREAM_ENCODING_OWNER.remove() else RAW_STREAM_ENCODING_OWNER.set(previous)
            }
        }
    })
    pipeline.addFirst("foundation.url.protocol.rawSocketProgress", object : ChannelDuplexHandler() {
        override fun write(ctx: ChannelHandlerContext, msg: Any, promise: ChannelPromise) {
            val owner = RAW_STREAM_ENCODING_OWNER.get()
            if ((owner == null && registry.yamux) || msg !is ByteBuf) {
                ctx.write(msg, promise)
                return
            }
            val byteCount = msg.readableBytes()
            val physical = io.netty.channel.DefaultChannelProgressivePromise(ctx.channel(), ImmediateEventExecutor.INSTANCE)
            physical.addListener(object : io.netty.channel.ChannelProgressiveFutureListener {
                private val acceptedBytes = AtomicLong()
                override fun operationProgressed(future: io.netty.channel.ChannelProgressiveFuture, progress: Long, total: Long) {
                    val previous = acceptedBytes.getAndUpdate { old -> maxOf(old, progress) }
                    if (progress > previous) {
                        owner?.let { recordRawStreamProgress(it) }
                        if (!registry.yamux) {
                            val now = registry.clock.currentTimeMillis()
                            registry.peerProgressAtMillis.getAndUpdate { old -> maxOf(old, now) }
                        }
                    }
                }
                override fun operationComplete(future: io.netty.channel.ChannelProgressiveFuture) {
                    if (future.isSuccess) {
                        if (!registry.yamux && byteCount > 0) {
                            val now = registry.clock.currentTimeMillis()
                            registry.peerProgressAtMillis.getAndUpdate { old -> maxOf(old, now) }
                        }
                        promise.trySuccess()
                    } else {
                        val failure = future.cause() ?: IOException("Raw socket write failed without a cause")
                        owner?.let { retainRawStreamFailureDetail(it, failure) }
                        promise.tryFailure(failure)
                    }
                }
            })
            if (!promise.isVoid) promise.addListener { original ->
                if (original.isCancelled) physical.cancel(false)
            }
            ctx.write(msg, physical)
        }
    })
}

/** A root owns peer credit progress; child ownership still attributes individual socket writes. */
private fun observeRawStreamProgress(stream: Stream, writes: RawStreamWrites): AutoCloseable? {
    val child = streamAsChannel(stream) as? io.libp2p.etc.util.netty.mux.MuxChannel<*> ?: return null
    val root = libp2pRootConnectionChannel(child)
    val attr = root.attr(RAW_STREAM_PROGRESS_ATTR)
    val registry = synchronized(attr) {
        attr.get() ?: RawStreamProgressRegistry(
            writes.clock, root.pipeline().context(io.libp2p.mux.yamux.YamuxHandler::class.java) != null,
        ).also {
            installRawStreamProgressObserver(root, it)
            attr.set(it)
        }
    }
    writes.connectionProgress = registry
    registry.children[child.id] = writes
    return AutoCloseable { registry.children.remove(child.id, writes) }
}

private fun beginRawStreamWrite(writes: RawStreamWrites): RawStreamWrite {
    return synchronized(writes.lock) {
        writes.failure?.let { throw rawStreamException(it) }
        if (!writes.accepting) throw IOException("Stream closed")
        RawStreamWrite().also { writes.pending.add(it) }
    }
}

/** Claim submission before calling the transport, without holding the lock during that call. */
private fun submitRawStreamWrite(writes: RawStreamWrites, write: RawStreamWrite) {
    synchronized(writes.lock) {
        write.failure?.let { throw rawStreamException(it) }
        check(write.state == RawStreamWriteState.REGISTERED) {
            "Raw stream write cannot be submitted from state ${write.state}"
        }
        write.state = RawStreamWriteState.SUBMITTED
    }
    armRawStreamStall(writes)
    synchronized(writes.lock) { write.failure?.let { throw rawStreamException(it) } }
}

/** Each write removes its own entry only when it reaches a terminal state. Caller holds lock. */
private fun finishRawStreamWriteLocked(
    writes: RawStreamWrites,
    write: RawStreamWrite,
    state: RawStreamWriteState,
    failure: RawStreamFailure?,
) {
    if (write.state.terminal) return
    check(state.terminal)
    write.failure = failure
    write.state = state
    writes.pending.remove(write)
    retireIdleRawStreamStallLocked(writes)
    write.waiters.forEach { it.countDown() }
    write.waiters.clear()
}

/** Close cancels unsubmitted writes and reports unfinished submissions to their waiters. */
private fun stopRawStreamWrites(writes: RawStreamWrites): Pair<RawStreamFailure?, Boolean> {
    val result = synchronized(writes.lock) {
        val earlierFailure = writes.failure?.takeUnless { it.causedByLocalClose }
        val hadSubmittedWrites = writes.pending.any { it.state == RawStreamWriteState.SUBMITTED }
        failRawStreamWritesLocked(writes, RawStreamFailure(
            "Stream closed before pending raw writes completed", null, causedByLocalClose = true,
        ))
        earlierFailure to hadSubmittedWrites
    }
    cancelIdleRawStreamStall(writes)
    return result
}

private fun failRawStreamWrites(writes: RawStreamWrites, failure: RawStreamFailure) {
    synchronized(writes.lock) { failRawStreamWritesLocked(writes, failure) }
    cancelIdleRawStreamStall(writes)
}

private fun failRawStreamWritesLocked(writes: RawStreamWrites, failure: RawStreamFailure) {
    writes.accepting = false
    if (writes.pending.any { it.state == RawStreamWriteState.SUBMITTED } && writes.failure == null) writes.failure = failure
    val firstFailure = writes.failure ?: failure
    val firstCause = firstFailure.cause
    val laterCause = failure.cause
    if (firstCause != null && laterCause != null && firstCause !== laterCause &&
        firstCause.suppressed.none { it === laterCause }) firstCause.addSuppressed(laterCause)
    writes.pending.toList().forEach { write ->
        if (write.state == RawStreamWriteState.REGISTERED) {
            // Submission must observe cancellation even before physical child closure.
            val cancelled = if (failure.causedByLocalClose) {
                RawStreamFailure("Stream closed", null, causedByLocalClose = true)
            } else firstFailure
            finishRawStreamWriteLocked(writes, write, RawStreamWriteState.CANCELLED, cancelled)
        } else {
            finishRawStreamWriteLocked(writes, write, RawStreamWriteState.FAILED, firstFailure)
        }
    }
}

private fun completeRawStreamWrite(writes: RawStreamWrites, write: RawStreamWrite, failure: Throwable?) {
    val now = if (failure == null) writes.clock.currentTimeMillis() else 0L
    synchronized(writes.lock) {
        if (write.state.terminal) {
            val firstCause = writes.failure?.cause
            if (failure != null && firstCause != null && failure !== firstCause &&
                firstCause.suppressed.none { it === failure }) firstCause.addSuppressed(failure)
        } else if (write.state == RawStreamWriteState.REGISTERED) {
            // Admission failure belongs only to this caller, not to earlier submitted bytes.
            finishRawStreamWriteLocked(writes, write, RawStreamWriteState.CANCELLED, null)
        } else if (failure == null) {
            writes.progressAtMillis = maxOf(writes.progressAtMillis, now)
            finishRawStreamWriteLocked(writes, write, RawStreamWriteState.COMPLETED, null)
        } else {
            failRawStreamWritesLocked(writes, RawStreamFailure(
                "Raw stream transport write failed (${failure::class.java.name})", failure,
            ))
        }
    }
    cancelIdleRawStreamStall(writes)
}

private fun rawStreamEventLoopWaitFailure(stream: Stream): IOException? =
    if (streamAsChannel(stream)?.eventLoop()?.inEventLoop() == true ||
        io.netty.util.internal.ThreadExecutorMap.currentExecutor()?.inEventLoop() == true
    ) IOException(
        "Cannot wait for pending raw stream writes on the stream event loop; call flush or close from a worker thread"
    ) else null

/** No frame, read or tracking lock is held while a transport result is awaited. */
private fun awaitRawStreamWrites(writes: RawStreamWrites, stream: Stream) {
    val pending = synchronized(writes.lock) {
        writes.failure?.let { throw rawStreamException(it) }
        writes.pending.toList()
    }
    if (pending.isNotEmpty()) rawStreamEventLoopWaitFailure(stream)?.let { throw it }
    // Push any transport-buffered bytes before waiting for their actual result.
    if (pending.isNotEmpty()) streamAsChannel(stream)?.flush()
    for (write in pending) {
        val wake = CountDownLatch(1)
        val registered = synchronized(writes.lock) {
            if (write.state.terminal) false else write.waiters.add(wake)
        }
        try {
            if (registered) wake.await()
            write.failure?.let { throw rawStreamException(it) }
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            throw IOException("Interrupted while waiting for pending raw stream writes", interrupted)
        } finally {
            synchronized(writes.lock) { write.waiters.remove(wake) }
        }
    }
    synchronized(writes.lock) { writes.failure?.let { throw rawStreamException(it) } }
}

/**
 * Controller that bridges a libp2p Stream to Java IO streams using Netty handlers.
 * Used for client-side streams where blocking read/write is acceptable.
 */
class NettyStreamController(
    private val stream: Stream,
    override val negotiatedProtocolId: String? = null
) : Libp2pRpcController, RootLinkDiagnosticSource {
    override val rootLinkDiagnostics: RootLinkDiagnostics get() = stream.connection.rootLinkDiagnostics()
    internal val rootLinkChannel: io.netty.channel.Channel?
        get() = (stream.connection as? io.libp2p.transport.implementation.P2PChannelOverNetty)?.nettyChannel

    private val closed = AtomicBoolean(false)
    private val rawWrites = RawStreamWrites(rawStreamWriteClock(stream)) { failure ->
        try {
            close()
        } catch (cleanup: Throwable) {
            // close reports the stall already stored for its callers; retain distinct cleanup.
            if (cleanup.cause !== failure && cleanup !== failure) failure.addSuppressed(cleanup)
            else cleanup.suppressed.forEach { if (it !== failure) failure.addSuppressed(it) }
        }
    }
    private val rawProgressRegistration = AtomicReference<AutoCloseable?>()
    private val parseBudgetCancellation = ParseBudgetCancellation()
    // Use ArrayDeque of ByteArray chunks instead of ConcurrentLinkedQueue<Byte>
    // to avoid creating one Node object per byte (which caused OOM with 7.7M nodes)
    private val readChunks = ArrayDeque<ByteArray>()
    private var currentChunk: ByteArray? = null
    private var currentOffset = 0
    // S1 owns this prefix until admission succeeds and body consumption starts. Close handlers
    // inspect it to distinguish a complete buffered frame from a body that can never finish.
    private var pendingFrameLength: Int? = null
    private var terminalReadFailure: IOException? = null
    private var messageReader: Thread? = null
    private val messageReaderWaiters = HashSet<java.util.concurrent.CountDownLatch>()
    private val readLock = ReentrantLock()
    private val dataAvailable = readLock.newCondition()

    private val _input = NettyInputStream()
    private val _output = NettyOutputStream()
    private val parentCloseRegistration = AtomicReference<ParentCloseRegistration?>(null)
    private val completeFrameWriter = RpcControllerFrameWriter { jsonBytes, attachments ->
        if (closed.get()) throw StreamClosedBeforeWriteException(
            "libp2p stream ${streamAsChannel(stream)?.id()?.asLongText() ?: stream} to peer ${stream.remotePeerId()}"
        )
        // The inner admission covers both this segmented writer and NettyOutputStream raw
        // writes. Its notification scope dispatches observers after frame ownership ends.
        if (!writeEncodedRpcMessageReturningDelivered(stream, jsonBytes, attachments, reportNonAdmission = true)) {
            throw droppedWriteFailure()
        }
    }

    /**
     * A write the backpressure wait dropped because this stream closed underneath it reports the
     * close; only a stream that is still open was dropped for staying unwritable.
     */
    private fun droppedWriteFailure(): IOException =
        if (closed.get() || streamAsChannel(stream)?.isActive == false) IOException("Stream closed")
        else IOException(RPC_WRITE_DROPPED_UNWRITABLE_MESSAGE)
    private val parentCloseRegistrar = RpcControllerParentCloseRegistrar { completion ->
        stream.connection.closeFuture().whenComplete { _, _ -> completion() }
        requestTransportRead()
    }

    override val input: InputStream get() = _input
    override val output: OutputStream get() = _output

    /**
     * Releases blocking readers when either this child stream or its parent transport dies.
     * Buffered bytes are intentionally preserved and drained before EOF (see NettyInputStream).
     * A reader failure is terminal for timed message reads, which report [terminalReadFailure]
     * before consuming any byte; the raw InputStream still drains bytes received before it.
     */
    private fun signalTransportClosed(failure: Throwable? = null) {
        rawProgressRegistration.getAndSet(null)?.close()
        failRawStreamWrites(rawWrites, RawStreamFailure(
            "Stream closed before pending raw writes completed", failure,
        ))
        try {
            // A sender parked on either admission reports the transport failure that ended the
            // stream, the same cause timed readers receive, rather than a generic close.
            closeFrameAdmissions(failure?.let {
                IOException("Stream closed: transport failed: ${it.message ?: it::class.java.name}", it)
            })
        } finally {
            releaseReadersOnTransportClose(failure)
        }
    }

    /** Closes the stream's frame turn and the controller's frame admission, each even if the other throws. */
    private fun closeFrameAdmissions(cause: IOException?) {
        try {
            if (cause == null) rpcStreamWriteLock(stream).close() else rpcStreamWriteLock(stream).close(cause)
        } finally {
            closeRpcControllerFrameAdmission(this, cause)
        }
    }

    private fun releaseReadersOnTransportClose(failure: Throwable?) {
        readLock.withLock {
            closed.set(true)
            if (failure != null && terminalReadFailure == null) {
                terminalReadFailure = if (failure is IOException) failure else IOException(
                    "Stream reader failed: ${failure.message ?: failure::class.java.simpleName}", failure,
                )
            }
            if (terminalReadFailure != null) {
                pendingFrameLength = null
                parseBudgetCancellation.cancel()
            } else if (pendingFrameLength?.let { calculateAvailable() < it } == true) {
                // Timed frames are terminal, but clean remote close still preserves unread
                // bytes for the raw InputStream API. Local close discards them explicitly.
                pendingFrameLength = null
                parseBudgetCancellation.cancel()
            }
            // Detach before waking readers so EOF cannot be observed while this closed child is
            // still retained by the parent registry. Setting [closed] first preserves the init
            // reconciliation when closure races registration publication.
            parentCloseRegistration.get()?.unregister()
            dataAvailable.signalAll()
        }
        // A retired server can close mux children just before the parent transport close reaches
        // this peer. If the caller disabled auto-read to create the backpressure, request one
        // parent read now so the root close is processed and the libp2p connection is removed
        // from its connection pool before a caller tries to reconnect.
        requestTransportRead()
    }

    init {
        registerRpcControllerFrameWriter(this, completeFrameWriter)
        registerRpcControllerParentCloseRegistrar(this, parentCloseRegistrar)
        // Apply explicit WriteBufferWaterMark to the mux substream so writes through
        // [_output] (NettyOutputStream → writeFramedBufferWithBackpressure) properly
        // observe channel.isWritable.
        configureWriteBackpressure(stream)
        rawProgressRegistration.set(observeRawStreamProgress(stream, rawWrites))
        if (closed.get()) rawProgressRegistration.getAndSet(null)?.close()
        // Add handler to receive data from the stream
        stream.pushHandler(object : SimpleChannelInboundHandler<ByteBuf>() {
            override fun channelRead0(ctx: ChannelHandlerContext, msg: ByteBuf) {
                val bytes = ByteArray(msg.readableBytes())
                msg.readBytes(bytes)

                readLock.withLock {
                    if (parseBudgetCancellation.isCancelled()) return
                    // Add the entire chunk, not individual bytes
                    readChunks.addLast(bytes)
                    dataAvailable.signalAll()
                }
            }

            override fun channelInactive(ctx: ChannelHandlerContext) {
                signalTransportClosed()
            }

            override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
                signalTransportClosed(cause)
                ctx.close()
            }
        })

        // A multiplexed child does not universally receive channelInactive when the parent
        // TCP/libp2p connection dies (the production Pending wedge left this reader parked
        // after the peer had no TCP connection at all). Treat the parent connection's lifecycle
        // as authoritative and explicitly wake this controller's blocking InputStream.
        //
        // Register through one shared listener per parent connection. CompletableFuture has no
        // API for removing a whenComplete dependent, so installing one callback per historical
        // child retains O(streams) completion nodes until a long-lived parent finally closes.
        // The shared registry holds children weakly, prunes collected references on every
        // registration, and removes child-driven or explicit closes immediately; parent-close
        // traversal is therefore proportional to live controllers rather than historical churn.
        val registration = registerForParentClose(stream.connection, this)
        parentCloseRegistration.set(registration)
        if (closed.get()) {
            registration.unregister()
        }
    }

    fun isClosed(): Boolean = closed.get()

    /**
     * Returns how many child controllers the shared parent-close registry currently tracks for
     * this controller's parent connection. This is a transport diagnostic: callers can verify
     * that stream churn is not accumulating closed children on a long-lived multiplexed parent.
     */
    fun parentCloseRegisteredChildCount(): Int =
        parentCloseRegistration.get()?.registeredChildCount() ?: 0

    override fun close() {
        val (earlierWriteFailure, hadSubmittedWrites) = stopRawStreamWrites(rawWrites)
        var failure: Throwable? = null
        try {
            closeFrameAdmissions(null)
        } catch (next: Throwable) {
            failure = next
        }
        // Explicit close releases its callers; it must never join transport work that
        // the caller may already have stopped forwarding. Earlier real failures still report.
        try {
            earlierWriteFailure?.let { throw rawStreamException(it) }
            if (hadSubmittedWrites) rawStreamEventLoopWaitFailure(stream)?.let { throw it }
        } catch (next: Throwable) {
            if (failure == null) failure = next else if (failure !== next) failure.addSuppressed(next)
        }
        try {
            closeReadersAndStream()
        } catch (next: Throwable) {
            if (failure == null) failure = next else if (failure !== next) failure.addSuppressed(next)
        }
        failure?.let { throw it }
    }

    private fun closeReadersAndStream() {
        rawProgressRegistration.getAndSet(null)?.close()
        parentCloseRegistration.get()?.unregister()
        val wasClosed = readLock.withLock {
            val alreadyClosed = closed.getAndSet(true)
            pendingFrameLength = null
            readChunks.clear()
            currentChunk = null
            currentOffset = 0
            parseBudgetCancellation.cancel()
            dataAvailable.signalAll()
            alreadyClosed
        }
        if (wasClosed) return
        stream.close()
    }

    private class ControllerReference(
        controller: NettyStreamController,
        queue: java.lang.ref.ReferenceQueue<NettyStreamController>,
    ) : java.lang.ref.WeakReference<NettyStreamController>(controller, queue)

    private class ParentCloseChildren {
        private val lock = Any()
        private val collectedControllers = java.lang.ref.ReferenceQueue<NettyStreamController>()
        private val children = LinkedHashSet<ControllerReference>()
        private var parentClosed = false

        fun register(controller: NettyStreamController): ParentCloseRegistration {
            val reference = ControllerReference(controller, collectedControllers)
            val closeImmediately = synchronized(lock) {
                pruneInactiveLocked()
                if (parentClosed || controller.isClosed()) {
                    true
                } else {
                    children.add(reference)
                    false
                }
            }
            if (closeImmediately) controller.signalTransportClosed()
            return ParentCloseRegistration(this, reference)
        }

        fun unregister(reference: ControllerReference) {
            synchronized(lock) {
                children.remove(reference)
                pruneInactiveLocked()
            }
            reference.clear()
        }

        fun signalParentClosed() {
            val controllers = synchronized(lock) {
                if (parentClosed) return
                parentClosed = true
                pruneInactiveLocked()
                children.mapNotNull { it.get() }.also { children.clear() }
            }
            controllers.forEach { it.signalTransportClosed() }
        }

        fun registeredChildCount(): Int = synchronized(lock) { children.size }

        private fun pruneInactiveLocked() {
            while (true) {
                val reference = collectedControllers.poll() as? ControllerReference ?: break
                children.remove(reference)
            }
            val iterator = children.iterator()
            while (iterator.hasNext()) {
                val reference = iterator.next()
                val controller = reference.get()
                if (controller == null || controller.isClosed()) {
                    iterator.remove()
                    reference.clear()
                }
            }
        }
    }

    private class ParentCloseRegistration(
        private val children: ParentCloseChildren,
        private val reference: ControllerReference,
    ) {
        private val registered = AtomicBoolean(true)

        fun unregister() {
            if (registered.compareAndSet(true, false)) {
                children.unregister(reference)
            }
        }
        fun registeredChildCount(): Int = children.registeredChildCount()
    }

    private companion object {
        private val parentRegistriesLock = Any()
        private val parentRegistries = WeakIdentityRegistry<Connection, ParentCloseChildren>()

        private fun registerForParentClose(
            connection: Connection,
            controller: NettyStreamController,
        ): ParentCloseRegistration {
            var installParentListener = false
            val children = synchronized(parentRegistriesLock) {
                parentRegistries[connection] ?: ParentCloseChildren().also {
                    parentRegistries[connection] = it
                    installParentListener = true
                }
            }
            val registration = children.register(controller)
            if (installParentListener) {
                connection.closeFuture().whenComplete { _, _ -> children.signalParentClosed() }
            }
            return registration
        }
    }

    /** Check if there's buffered data available without blocking */
    private fun hasBufferedData(): Boolean {
        return (currentChunk != null && currentOffset < currentChunk!!.size) || readChunks.isNotEmpty()
    }

    /** Read a single byte from the buffer, returning null if no data available */
    private fun readOneByte(): Byte? {
        val chunk = currentChunk
        if (chunk != null && currentOffset < chunk.size) {
            val b = chunk[currentOffset++]
            if (currentOffset >= chunk.size) {
                currentChunk = null
                currentOffset = 0
            }
            return b
        }
        if (readChunks.isNotEmpty()) {
            currentChunk = readChunks.removeFirst()
            currentOffset = 0
            return readOneByte()
        }
        return null
    }

    /** Read multiple bytes from the buffer, returning actual count read */
    private fun readMultipleBytes(b: ByteArray, off: Int, len: Int): Int {
        var count = 0
        while (count < len) {
            val chunk = currentChunk
            if (chunk != null && currentOffset < chunk.size) {
                val available = chunk.size - currentOffset
                val toRead = minOf(available, len - count)
                System.arraycopy(chunk, currentOffset, b, off + count, toRead)
                currentOffset += toRead
                count += toRead
                if (currentOffset >= chunk.size) {
                    currentChunk = null
                    currentOffset = 0
                }
            } else if (readChunks.isNotEmpty()) {
                currentChunk = readChunks.removeFirst()
                currentOffset = 0
            } else {
                break
            }
        }
        return count
    }

    /** Calculate total available bytes across all chunks */
    private fun calculateAvailable(): Int {
        var total = 0
        val chunk = currentChunk
        if (chunk != null) {
            total += chunk.size - currentOffset
        }
        for (c in readChunks) {
            total += c.size
        }
        return total
    }

    /**
     * A blocking controller read is an explicit request for inbound progress. When a caller has
     * disabled auto-read on the physical connection, drive one Netty read from the same blocking
     * path so a remote terminal close is observed even if no data frame is available first.
     * Netty coalesces the call onto the connection event loop; this does not create a worker or
     * add another buffer.
     */
    private fun requestTransportRead() {
        val connectionChannel =
            (stream.connection as? io.libp2p.transport.implementation.ConnectionOverNetty)
                ?.nettyChannel
            ?: return
        if (!connectionChannel.isOpen || connectionChannel.config().isAutoRead) return
        try {
            connectionChannel.read()
        } catch (_: Exception) {
            // A concurrent transport close is already the terminal outcome for this read.
        }
    }

    /**
     * Reads a length-prefixed JSON message with a deadline-based timeout.
     * Returns null if the timeout expires before a complete message is received,
     * allowing the caller to clean up idle connections. A clean remote close leaves complete
     * buffered frames readable; a local close discards them.
     *
     * Message format: 4-byte big-endian length prefix followed by UTF-8 JSON body.
     */
    fun readMessage(timeout: Long, unit: TimeUnit): JSONObject? =
        readMessage(timeout, unit, SystemClock())

    /** Uses one caller-owned clock for prefix, admission, and body deadlines. */
    fun readMessage(timeout: Long, unit: TimeUnit, clock: Clock): JSONObject? {
        val durationMs = unit.toMillis(timeout)
        val deadline = saturatedReadDeadline(clock.currentTimeMillis(), durationMs)
        return readMessageWithBudget(MessageReadBudget(deadline, durationMs, deadline, clock, false))
    }

    /**
     * Uses [idleTimeout] for first-byte and parse-memory waiting while the read is resumable.
     * Partial prefixes and bodies each use [frameTimeout] once their first byte is consumed.
     * [operationDeadlineMs] caps all waits in [clock] time. Admission expiry retains the prefix.
     * Expiry after partial byte consumption closes the stream and reports frame progress.
     */
    fun readMessage(
        idleTimeout: Long,
        frameTimeout: Long,
        unit: TimeUnit,
        clock: Clock = SystemClock(),
        operationDeadlineMs: Long = Long.MAX_VALUE,
    ): JSONObject? {
        require(idleTimeout >= 0L && frameTimeout >= 0L) {
            "Read budgets must be nonnegative, but idleTimeout=$idleTimeout and frameTimeout=$frameTimeout $unit"
        }
        val idleDeadline = minOf(
            saturatedReadDeadline(clock.currentTimeMillis(), unit.toMillis(idleTimeout)),
            operationDeadlineMs,
        )
        return readMessageWithBudget(MessageReadBudget(
            idleDeadline, unit.toMillis(frameTimeout), operationDeadlineMs, clock, true,
            pollBufferedFrame = unit.toMillis(idleTimeout) == 0L,
        ))
    }

    private fun readMessageWithBudget(budget: MessageReadBudget): JSONObject? {
        val clock = budget.clock
        check(readLock.withLock { messageReader !== Thread.currentThread() }) {
            "A message read cannot re-enter the same stream"
        }
        while (true) {
            val wake = java.util.concurrent.CountDownLatch(1)
            val acquired = readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled()) return null
                if (messageReader == null) {
                    messageReader = Thread.currentThread()
                    true
                } else {
                    messageReaderWaiters.add(wake)
                    false
                }
            }
            if (acquired) break
            parseBudgetCancellation.register(wake)
            var task: community.kotlin.clocks.simple.Scheduled? = null
            try {
                val remaining = remainingReadWaitMillis(budget.idleDeadlineMs, clock.currentTimeMillis())
                if (remaining <= 0L) return null
                // Wall-clock expiry uses the latch's timed wait so it cannot depend on a
                // shared timer callback. Injected clocks instead wake on explicit advancement.
                if (clock is SystemClock) wake.await(remaining, TimeUnit.MILLISECONDS)
                else {
                    task = clock.schedule(budget.idleDeadlineMs) { wake.countDown() }
                    if (clock.currentTimeMillis() < budget.idleDeadlineMs) wake.await()
                }
                readLock.withLock {
                    terminalReadFailure?.let { throw it }
                    if (parseBudgetCancellation.isCancelled()) return null
                }
                if (clock.currentTimeMillis() >= budget.idleDeadlineMs) return null
            } catch (failure: InterruptedException) {
                Thread.currentThread().interrupt()
                return null
            } finally {
                readLock.withLock { messageReaderWaiters.remove(wake) }
                parseBudgetCancellation.unregister(wake)
                task?.let(clock::unschedule)
            }
        }
        try {
            return readOwnedMessage(budget)
        } finally {
            readLock.withLock {
                messageReader = null
                messageReaderWaiters.forEach { it.countDown() }
            }
        }
    }

    private fun readOwnedMessage(budget: MessageReadBudget): JSONObject? {
        val clock = budget.clock
        val resumedLength = readLock.withLock {
            terminalReadFailure?.let { throw it }
            if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
            pendingFrameLength
        }
        val length = resumedLength ?: run {
            val lengthBytes = readBytesWithDeadline(4, budget) ?: return null
            ((lengthBytes[0].toInt() and 0xFF) shl 24) or
                ((lengthBytes[1].toInt() and 0xFF) shl 16) or
                ((lengthBytes[2].toInt() and 0xFF) shl 8) or
                (lengthBytes[3].toInt() and 0xFF)
        }
        if (length <= 0 || length > 10_000_000) {
            throw IOException("Invalid message length: $length")
        }

        readLock.withLock {
            terminalReadFailure?.let { throw it }
            if (parseBudgetCancellation.isCancelled()) return null
            if (closed.get() && calculateAvailable() < length) {
                pendingFrameLength = null
                parseBudgetCancellation.cancel()
                return null
            }
            // Publish before checking interruption: even a first call already consumed its
            // prefix. Every admission exit now leaves the same owned frame in S1.
            pendingFrameLength = length
            if (Thread.currentThread().isInterrupted) return null
        }
        budget.bodyLength = length
        val admissionStartedAt = if (budget.reportFrameExpiry) clock.currentTimeMillis() else null
        val admissionStartedBeforeDeadline = admissionStartedAt != null && admissionStartedAt < budget.idleDeadlineMs
        val beforeAdmissionExpiry = readLock.withLock {
            terminalReadFailure?.let { throw it }
            if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
            messageAdmissionFrameExpiry(budget, admissionStartedAt, calculateAvailable().toLong())
        }
        if (beforeAdmissionExpiry != null) {
            val failure = IOException(beforeAdmissionExpiry)
            endStreamForAbandonedFrame(failure)
            throw failure
        }
        val permits = try {
            Libp2pRpcProtocol.acquireParseBudgetUntilClosed(
                length, budget.idleDeadlineMs, clock, parseBudgetCancellation,
            )
                ?: return readLock.withLock {
                    terminalReadFailure?.let { throw it }
                    null
                }
        } catch (e: ParseBudgetDeadlineExceededException) {
            val admissionExpiry = readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled() || Thread.currentThread().isInterrupted) return null
                val admissionFailedAt = if (budget.reportFrameExpiry) clock.currentTimeMillis() else null
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled() || Thread.currentThread().isInterrupted) return null
                messageAdmissionFrameExpiry(budget, admissionFailedAt, calculateAvailable().toLong())
            }
            if (admissionExpiry != null) {
                val failure = IOException(admissionExpiry)
                endStreamForAbandonedFrame(failure)
                throw failure
            }
            return null
        } catch (e: IOException) {
            readLock.withLock { terminalReadFailure?.let { throw it } }
            if (e.cause is InterruptedException) return null
            throw e
        }
        try {
            val admissionExpiry = readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
                val admissionReturnedAt = if (budget.reportFrameExpiry) clock.currentTimeMillis() else null
                terminalReadFailure?.let { throw it }
                if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
                // Frame expiry wins over an idle-only admission miss for an incomplete frame.
                messageAdmissionFrameExpiry(budget, admissionReturnedAt, calculateAvailable().toLong())
                    ?.let { return@withLock it }
                // Check after admission's clock cleanup, before consuming a body byte. A grant
                // exactly at expiry may finish a complete buffered message; every later grant
                // leaves the retained prefix available to the next poll. A partial prefix that
                // completed past idle expiry may still take an immediate, non-waiting grant.
                if (admissionReturnedAt != null && (admissionReturnedAt >= budget.operationDeadlineMs ||
                    (admissionStartedBeforeDeadline && (admissionReturnedAt > budget.idleDeadlineMs ||
                        (admissionReturnedAt == budget.idleDeadlineMs && calculateAvailable() < length))))) {
                    Libp2pRpcProtocol.parseBudgetAdmissionExpired(length)
                    return null
                }
                // Keep the prefix until the first body copy. A clock failure or close before
                // that copy must not lose the length of an otherwise untouched body.
                null
            }
            if (admissionExpiry != null) {
                val failure = IOException(admissionExpiry)
                endStreamForAbandonedFrame(failure)
                throw failure
            }
            beginMessageBodyWait(budget)
            val bodyBytes = readBytesWithDeadline(length, budget) ?: run {
                readLock.withLock {
                    terminalReadFailure?.let { throw it }
                    // A partial read became terminal inside readBytesWithDeadline. With no consumed body
                    // bytes, the same prefix can instead be resumed by the next call.
                    if (closed.get() && calculateAvailable() < length) {
                        pendingFrameLength = null
                        readChunks.clear()
                        currentChunk = null
                        currentOffset = 0
                        parseBudgetCancellation.cancel()
                    } else if (!parseBudgetCancellation.isCancelled()) pendingFrameLength = length
                }
                return null
            }
            val parsed = Libp2pRpcProtocol.parseValidatedJsonBody(bodyBytes)
            readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled()) return null
                if (!Thread.currentThread().isInterrupted) return parsed
            }
            // Interruption during parsing abandons a frame whose bytes this call consumed. The
            // stream ends, exactly as for an interruption after the final copy: a later reader
            // must not silently receive the following frame in its place.
            endStreamForAbandonedFrame(null)
            return null
        } finally {
            Libp2pRpcProtocol.releaseParseBudget(permits)
        }
    }

    /**
     * Ends the stream after a read abandons a consumed frame, closing the transport only from the
     * call that performed the transition. A close failure is attached to [readFailure] when the
     * read already failed; otherwise it is the call's result, on every abandonment path alike.
     */
    private fun endStreamForAbandonedFrame(readFailure: Throwable?) {
        if (!abandonConsumedFrame()) return
        try {
            stream.close()
        } catch (closeFailure: Throwable) {
            if (readFailure == null) throw closeFailure
            if (readFailure !== closeFailure) readFailure.addSuppressed(closeFailure)
        }
    }

    /**
     * Ends the stream after a read abandons bytes it consumed (a partial frame, or a complete
     * frame refused after its copy). Returns true when this call is the one that closed it.
     */
    private fun abandonConsumedFrame(): Boolean = readLock.withLock {
        // Partial body storage belongs to this call's parse reservation. It cannot be
        // retained after releasing that reservation, nor treated as a fresh prefix.
        val newlyClosed = !closed.getAndSet(true)
        parentCloseRegistration.get()?.unregister()
        pendingFrameLength = null
        readChunks.clear()
        currentChunk = null
        currentOffset = 0
        parseBudgetCancellation.cancel()
        dataAvailable.signalAll()
        newlyClosed
    }

    private fun readBytesWithDeadline(count: Int, budget: MessageReadBudget): ByteArray? {
        val clock = budget.clock
        val result = ByteArray(count)
        var read = 0

        var readFailure: Throwable? = null
        var expiredAfterCopy = false
        try {
            readLock.withLock {
                terminalReadFailure?.let { throw it }
                while (read < count && !Thread.currentThread().isInterrupted) {
                    terminalReadFailure?.let { throw it }
                    // Once copying starts, buffered tail bytes cannot bypass the frame deadline.
                    // Admission's separate grant-at-expiry decision has already been settled.
                    if (budget.reportFrameExpiry && !messageReadCanConsumeBytes(budget)) break
                    // Try to read from current chunk
                    val chunk = currentChunk
                    if (chunk != null && currentOffset < chunk.size) {
                        val available = chunk.size - currentOffset
                        val toRead = minOf(available, count - read)
                        beginMessageByteCopy(budget)
                        terminalReadFailure?.let { throw it }
                        if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) break
                        // Once body bytes are consumed this invocation owns them. Remote close
                        // must no longer compare the full length against only the remaining tail.
                        if (budget.bodyLength != null) pendingFrameLength = null
                        System.arraycopy(chunk, currentOffset, result, read, toRead)
                        currentOffset += toRead
                        read += toRead
                        if (currentOffset >= chunk.size) {
                            currentChunk = null
                            currentOffset = 0
                        }
                    } else if (readChunks.isNotEmpty()) {
                        currentChunk = readChunks.removeFirst()
                        currentOffset = 0
                    } else if (closed.get()) {
                        // Drain buffered bytes before treating a clean remote close as EOF.
                        break
                    } else {
                        val remaining = remainingReadWaitMillis(messageReadDeadline(budget), clock.currentTimeMillis())
                        if (remaining <= 0) break
                        requestTransportRead()
                        try {
                            dataAvailable.await(remaining.coerceAtMost(100), TimeUnit.MILLISECONDS)
                        } catch (e: InterruptedException) {
                            Thread.currentThread().interrupt()
                            break
                        }
                    }
                }
            }
            if (read == count && budget.reportFrameExpiry && budget.bodyLength != null) {
                // A complete array copy may cross the frame or operation deadline.
                expiredAfterCopy = !messageReadCanConsumeBytes(budget)
            }
        } catch (failure: Throwable) {
            readFailure = failure
        }

        // Interruption may arrive during the last buffered copy of a body. A complete byte count
        // alone cannot make an interrupted read deliver the frame. A complete length prefix is
        // different: the caller publishes it as the retained prefix before honoring interruption,
        // so the next read resumes the same frame instead of losing the stream.
        if (readFailure == null && read == count && !expiredAfterCopy &&
            (budget.bodyLength == null || !Thread.currentThread().isInterrupted)) return result
        if (read > 0 || (readFailure == null && budget.reportFrameExpiry && budget.bodyLength != null &&
            !Thread.currentThread().isInterrupted && clock.currentTimeMillis() >= messageReadDeadline(budget))) {
            endStreamForAbandonedFrame(readFailure)
            readFailure?.let { throw it }
            if (budget.reportFrameExpiry && !Thread.currentThread().isInterrupted &&
                (expiredAfterCopy || clock.currentTimeMillis() >= messageReadDeadline(budget))) {
                throw IOException(messageFrameExpiryDescription(budget, read))
            }
        }
        readFailure?.let { throw it }
        return null
    }

    private inner class NettyInputStream : InputStream() {
        override fun read(): Int {
            readLock.withLock {
                while (!hasBufferedData() && !closed.get()) {
                    requestTransportRead()
                    try {
                        dataAvailable.await(100, TimeUnit.MILLISECONDS)
                    } catch (e: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return -1
                    }
                }

                if (!hasBufferedData() && closed.get()) {
                    return -1
                }

                return readOneByte()?.toInt()?.and(0xFF) ?: -1
            }
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0

            readLock.withLock {
                while (!hasBufferedData() && !closed.get()) {
                    requestTransportRead()
                    try {
                        dataAvailable.await(100, TimeUnit.MILLISECONDS)
                    } catch (e: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return -1
                    }
                }

                if (!hasBufferedData() && closed.get()) {
                    return -1
                }

                val count = readMultipleBytes(b, off, len)
                return if (count > 0) count else -1
            }
        }

        override fun available(): Int {
            readLock.withLock {
                return calculateAvailable()
            }
        }

        /**
         * Closing the input marks the stream closed and wakes any thread parked in [read]/[readAll]
         * so it observes EOF and unwinds — rather than the default [InputStream.close] no-op, which
         * would leave a blocked reader parked forever. This is what lets a caller holding only the
         * [InputStream] (e.g. the inbound attachment-frame stall watchdog in
         * [Libp2pRpcProtocol.readMessageFrameFromStream], which force-releases the shared attachment
         * pool and then closes the stream so the stalled peer's parked reader unwinds) evict a
         * reader that is blocked waiting for bytes a stalled peer will never send. Buffered bytes are
         * preserved (a normal drain-to-EOF still works); only the blocking-forever case changes.
         */
        override fun close() {
            signalTransportClosed()
        }
    }

    private inner class NettyOutputStream : OutputStream() {
        override fun write(b: Int) {
            write(byteArrayOf(b.toByte()), 0, 1)
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            if (closed.get()) throw StreamClosedBeforeWriteException(
                "libp2p stream ${streamAsChannel(stream)?.id()?.asLongText() ?: stream} to peer ${stream.remotePeerId()}"
            )
            if (len == 0) return
            withRpcFramingLock(stream) {
                val write = beginRawStreamWrite(rawWrites)
                try {
                    val buffer = Unpooled.wrappedBuffer(b, off, len)
                    val channel = streamAsChannel(stream)
                    val delivered = if (channel == null) {
                        try {
                            submitRawStreamWrite(rawWrites, write)
                            stream.writeAndFlushWithFuture(buffer).whenComplete { _, failure ->
                                completeRawStreamWrite(rawWrites, write, failure)
                            }
                            true
                        } catch (failure: Throwable) {
                            releaseIfRetained(buffer)
                            throw failure
                        }
                    } else writeFramedBufferWithBackpressure(
                        channel, buffer, WRITE_BACKPRESSURE_DELIVERY_WAIT_MS,
                        admitBoundedYamuxChildWrites = false,
                        nonAdmissionFailure = rpcFrameNonAdmissionFailure(stream, channel, len.toLong()),
                        writeBuffer = { bytes ->
                            submitRawStreamWrite(rawWrites, write)
                            // Completion must publish even if a caller or close callback occupies
                            // the event loop. No supplied callback runs under the tracking lock.
                            val result = DefaultChannelPromise(channel, ImmediateEventExecutor.INSTANCE)
                            result.addListener { completed ->
                                completeRawStreamWrite(rawWrites, write, if (completed.isSuccess) null else
                                    completed.cause() ?: IOException("Raw stream write failed without a cause"))
                            }
                            channel.writeAndFlush(bytes, result)
                        },
                    )
                    write.failure?.let { throw rawStreamException(it) }
                    if (!delivered) throw droppedWriteFailure()
                } catch (failure: Throwable) {
                    // A declined admission owns no bytes. It must not turn an earlier or later
                    // independent write into the same frame's failure.
                    completeRawStreamWrite(rawWrites, write, failure)
                    throw failure
                }
            }
        }

        override fun flush() = awaitRawStreamWrites(rawWrites, stream)

        override fun close() = this@NettyStreamController.close()
    }
}

/**
 * Effect propagator that sends effect requests and receives responses over a stream.
 *
 * @param writeFn Function that writes a JSON message to the underlying transport.
 *        For NIO server-side streams, this calls [writeRpcMessage].
 *        Thread-safety of writeFn is the caller's responsibility (Netty's writeAndFlush
 *        is inherently thread-safe).
 */
open class ControllerEffectPropagator @JvmOverloads constructor(
    // Returns whether the effect message was actually handed to the channel (true) or dropped by
    // writeFramedBufferWithBackpressure because the connection was unwritable (false). The awaited
    // effect-REQUEST path below must react to a drop; a dropped notification is best-effort.
    private val writeFn: (JSONObject) -> Boolean,
    // Connection-scoped push-channel context (see ServiceClientConnection). Defaulted, and the
    // constructor is @JvmOverloads, so the legacy single-arg <init>(Function1) JVM descriptor is
    // preserved and external callers compiled against 0.0.325 stay source AND binary compatible; the
    // server message handler passes the real connection identity, writability and close-registrar.
    override val connectionId: String = "detached",
    // Reads whether the underlying connection is still writable. Defaults to always-open for the
    // context-less case; the real transport supplies a live check driven by channelInactive.
    private val isConnectionOpen: () -> Boolean = { true },
    // Registers a listener to be invoked once when the connection dies. Defaults to firing
    // immediately (the context-less connection is treated as already gone). The real transport
    // records the listener and fires it from its cleanup() on channelInactive/exceptionCaught.
    private val closeListenerRegistrar: (() -> Unit) -> Unit = { it() },
    // Authenticated remote libp2p peer id for server-side connections. Transports
    // without a cryptographic peer identity leave this null.
    override val remotePeerId: String? = null
) : EffectPropagator, ServiceClientConnection {

    private val pendingEffects = ConcurrentHashMap<String, PendingEffect>()

    override val isOpen: Boolean
        get() = isConnectionOpen()

    /**
     * Sends an unsolicited server→client frame to this specific connection over
     * the same backpressure-gated write path as an awaited RPC response. The
     * frame's `type` is validated first ([validatePushableFrame]) — a reserved or
     * missing type is a caller programming error and throws
     * [IllegalArgumentException] before any write. Otherwise the push fails loudly
     * (never silently drops) when the connection is closed or unwritable — see
     * [ServicePushException]. [writeFn] returns `false` when
     * [writeFramedBufferWithBackpressure] dropped the frame because the
     * connection was unwritable/closed; we surface that as an exception so a
     * connection-scoped subscription lease can reap on push failure instead of
     * leaking until a later sweep. This is the libp2p (backpressure-window-bounded)
     * transport variant of the per-transport semantics documented on
     * [ServiceClientConnection.push].
     */
    override fun push(frame: JSONObject) {
        // Reject reserved/typeless frames before touching the connection (caller programming error).
        validatePushableFrame(frame)
        if (!isConnectionOpen()) {
            throw ServicePushException(
                "Cannot push to connection $connectionId: the client connection is closed"
            )
        }
        val delivered = try {
            writeFn(frame)
        } catch (e: Exception) {
            throw ServicePushException(
                "Failed to push a server-initiated frame to connection $connectionId: ${e.message}",
                e
            )
        }
        if (!delivered) {
            throw ServicePushException(
                "Push of a server-initiated frame to connection $connectionId was dropped: the " +
                    "connection was unwritable (closed or its outbound buffer is saturated past the " +
                    "backpressure delivery window)"
            )
        }
    }

    override fun onClose(listener: () -> Unit) {
        closeListenerRegistrar(listener)
    }

    private class PendingEffect(
        val latch: CountDownLatch = CountDownLatch(1),
        val result: AtomicReference<Any?> = AtomicReference(null)
    )

    override suspend fun propagateRequestEffect(effectType: String, effectData: JSONObject): Any? {
        val id = Libp2pRpcProtocol.nextRequestId()
        val request = Libp2pRpcProtocol.EffectRequest(id, effectType, effectData, isNotification = false)

        val pending = PendingEffect()
        pendingEffects[id] = pending

        try {
            if (!writeFn(request.toJson())) {
                // The AWAITED effect request could not be sent: writeFramedBufferWithBackpressure
                // dropped it because the connection was unwritable (the same heap-bounding drop as the
                // response path). The peer never receives it and so can never answer it, so blocking
                // the 30s latch below would just stall this RPC handler for the full timeout waiting
                // for a reply that will never come (the same phantom-hang class as the dropped
                // response). Resolve it immediately as an unsent/unresolved effect (null) — the same
                // outcome as a latch timeout, but without the 30s stall.
                debugLogErr {
                    "[RPC] Awaited effect request '$effectType' (id=$id) was dropped (connection " +
                    "unwritable); resolving as unsent instead of blocking the 30s latch"
                }
                return null
            }

            val received = pending.latch.await(30, TimeUnit.SECONDS)
            return if (received) pending.result.get() else null
        } finally {
            pendingEffects.remove(id)
        }
    }

    override suspend fun propagateNotificationEffect(effectType: String, effectData: JSONObject) {
        val id = Libp2pRpcProtocol.nextRequestId()
        val request = Libp2pRpcProtocol.EffectRequest(id, effectType, effectData, isNotification = true)

        // Best-effort: a dropped notification is acceptable (no caller is awaiting a reply), so the
        // delivered/dropped result is intentionally ignored here.
        writeFn(request.toJson())
    }

    fun handleEffectResponse(response: Libp2pRpcProtocol.EffectResponse) {
        val pending = pendingEffects[response.id] ?: return
        pending.result.set(response.result)
        pending.latch.countDown()
    }
}

/**
 * Real server-side libp2p connections add transport retirement without changing the legacy public
 * [ControllerEffectPropagator] constructor or making context-less instances claim the capability.
 */
internal class TransportDisconnectableControllerEffectPropagator(
    writeFn: (JSONObject) -> Boolean,
    connectionId: String,
    isConnectionOpen: () -> Boolean,
    closeListenerRegistrar: (() -> Unit) -> Unit,
    remotePeerId: String?,
    override val admissionOrder: Long,
    private val disconnectTransport: () -> Unit,
) : ControllerEffectPropagator(
    writeFn = writeFn,
    connectionId = connectionId,
    isConnectionOpen = isConnectionOpen,
    closeListenerRegistrar = closeListenerRegistrar,
    remotePeerId = remotePeerId,
), DisconnectableServiceClientConnection, AdmissionOrderedServiceClientConnection {
    // Keep the JVM descriptor published before admission ordering. Legacy construction cannot
    // establish transport admission, so it reports unknown order instead of allocating one here.
    constructor(
        writeFn: (JSONObject) -> Boolean,
        connectionId: String,
        isConnectionOpen: () -> Boolean,
        closeListenerRegistrar: (() -> Unit) -> Unit,
        remotePeerId: String?,
        disconnectTransport: () -> Unit,
    ) : this(writeFn, connectionId, isConnectionOpen, closeListenerRegistrar, remotePeerId, 0L, disconnectTransport)

    private val disconnectStarted = AtomicBoolean(false)

    override fun disconnect() {
        if (disconnectStarted.compareAndSet(false, true)) {
            disconnectTransport()
        }
    }
}
