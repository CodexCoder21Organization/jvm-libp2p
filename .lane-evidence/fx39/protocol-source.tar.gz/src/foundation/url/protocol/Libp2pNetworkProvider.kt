package foundation.url.protocol

import io.libp2p.core.Connection
import io.libp2p.core.ConnectionHandler
import io.libp2p.core.Host
import io.libp2p.core.P2PChannel
import io.libp2p.core.PeerId
import io.libp2p.core.Stream
import io.libp2p.core.multiformats.Multiaddr
import io.libp2p.core.multistream.ProtocolBinding
import io.libp2p.core.multistream.ProtocolDescriptor
import io.libp2p.security.InvalidRemotePubKey
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.nio.channels.UnresolvedAddressException
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Production [NetworkProvider] backed by jvm-libp2p TCP, Noise, and Yamux/Mplex.
 *
 * [enableRelay] preserves the existing deferred relay protocol binding. RelayService and LAN
 * discovery remain deliberately libp2p-specific; [UrlProtocol] reaches the host only through the
 * narrow internal accessors below, never through [NetworkProvider].
 */
class Libp2pNetworkProvider(
    private val keySeed: String? = null,
    private val listenHost: String = "0.0.0.0",
    private val enableRelay: Boolean = true
) : RpcResponseReaderNetworkProvider {
    private val lock = Any()
    private val closed = AtomicBoolean(false)
    private val connectionListeners = CopyOnWriteArrayList<(NetworkConnectionEvent) -> Unit>()
    private val inboundBindings = ConcurrentHashMap<String, Libp2pNetworkProtocolBinding>()
    private val outboundBindings = ConcurrentHashMap<String, Libp2pNetworkProtocolBinding>()
    private val inboundExecutor: ExecutorService = Executors.newFixedThreadPool(
        maxOf(2, Runtime.getRuntime().availableProcessors().coerceAtMost(8))
    ) { runnable ->
        Thread(runnable, "Libp2pNetworkProvider-inbound").apply { isDaemon = true }
    }
    private val connectionCallbackExecutor: ExecutorService = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "Libp2pNetworkProvider-connection-callback").apply { isDaemon = true }
    }
    internal val deferredRelayHandler = DeferredRelayHandler()

    @Volatile
    private var host: Host? = null
    @Volatile
    private var requestedListenPort: Int? = null
    @Volatile
    private var actualListenPort: Int? = null

    override fun derivePeerId(keySeed: String): String {
        val privateKey = Libp2pHostFactory.generateKeyFromSeed(keySeed)
        return PeerId.fromPubKey(privateKey.publicKey()).toBase58()
    }

    override fun listen(port: Int): NetworkListenInfo {
        require(port in 0..65535) {
            "Cannot listen on network port $port: the port must be between 0 and 65535 inclusive."
        }
        val startedHost = ensureStarted(port)
        return NetworkListenInfo(
            peerId = startedHost.peerId.toBase58(),
            listenAddresses = startedHost.listenAddresses().map { it.toString() }
        )
    }

    override fun dial(
        peerId: String,
        address: String,
        protocolId: String,
        timeoutMs: Long
    ): RpcStream = dial(peerId, address, protocolId, RpcResponseReader.AUTOMATIC, timeoutMs)

    override fun dial(
        peerId: String,
        address: String,
        protocolId: String,
        responseReader: RpcResponseReader,
        timeoutMs: Long,
    ): RpcStream {
        require(peerId.isNotBlank()) { "Cannot dial a blank peer ID." }
        require(address.isNotBlank()) { "Cannot dial peer '$peerId' at a blank network address." }
        require(protocolId.isNotBlank()) { "Cannot dial peer '$peerId' with a blank protocol ID." }
        require(timeoutMs > 0) {
            "Cannot dial peer '$peerId' with timeoutMs=$timeoutMs: timeoutMs must be greater than 0."
        }

        val remotePeerId = validateDialPeerId(peerId)
        val remoteAddress = try {
            Multiaddr(address)
        } catch (e: Exception) {
            throw IllegalArgumentException("Cannot dial peer '$peerId': '$address' is not a valid libp2p multiaddress.", e)
        }

        val startedHost = ensureStarted(0)
        ensureOutboundBinding(startedHost, protocolId)
        // Every dial below occupies a socket until it connects or the kernel gives up on an
        // unanswered SYN. Admission control caps how many of those may exist at once so an
        // unreachable peer set cannot exhaust the process's sockets and event-loop threads.
        return OutboundDialAdmission.withDialPermit(peerId, address, timeoutMs) {
            val streamFuture = try {
                startedHost.newStream<Libp2pRpcController>(
                    listOf(protocolId),
                    remotePeerId,
                    remoteAddress
                )
            } catch (failure: Exception) {
                throw standardizedDialFailure(peerId, address, protocolId, timeoutMs, failure)
            }
            val controller = try {
                streamFuture.controller.get(timeoutMs, TimeUnit.MILLISECONDS)
            } catch (failure: Exception) {
                streamFuture.controller.cancel(true)
                // The stream exists before protocol selection completes. Read only this dial's
                // completed stream, so another link to the same peer cannot supply its identity.
                val stream = streamFuture.stream.takeIf {
                    it.isDone && !it.isCompletedExceptionally && !it.isCancelled
                }?.getNow(null)
                val linkDiagnostics = stream?.connection?.rootLinkDiagnostics()?.takeIf { snapshot ->
                    snapshot.initiatedBy != "not observed" ||
                        generateSequence<Throwable>(failure) { it.cause }.any {
                            it is io.libp2p.core.ConnectionClosedException
                        }
                }
                throw standardizedDialFailure(peerId, address, protocolId, timeoutMs, failure, linkDiagnostics)
            }
            Libp2pRpcStream(
                controller = controller,
                remotePeerId = peerId,
                serviceIdentifier = protocolId,
                readResponses = responseReader == RpcResponseReader.AUTOMATIC &&
                    (protocolId == Libp2pRpcProtocol.PROTOCOL_ID ||
                        protocolId == Libp2pRpcProtocol.PROTOCOL_ID_V11),
                // The dialed address is what tells a later transport failure whether this
                // connection went through a relay hop, and which one.
                remoteAddress = address
            )
        }
    }

    override fun registerInboundStreamHandler(
        protocolId: String,
        handler: (RpcStream) -> Unit
    ): AutoCloseable {
        require(protocolId.isNotBlank()) { "Cannot register an inbound stream handler for a blank protocol ID." }
        checkOpen()

        val binding = Libp2pNetworkProtocolBinding(protocolId, handler, inboundExecutor)
        synchronized(lock) {
            checkOpen()
            val previous = inboundBindings.put(protocolId, binding)
            host?.let { startedHost ->
                previous?.let { startedHost.removeProtocolHandler(it) }
                outboundBindings.remove(protocolId)?.let { startedHost.removeProtocolHandler(it) }
                startedHost.addProtocolHandler(binding)
            }
        }
        return AutoCloseable {
            if (inboundBindings.remove(protocolId, binding)) {
                synchronized(lock) {
                    host?.removeProtocolHandler(binding)
                }
            }
        }
    }

    override fun addConnectionListener(listener: (NetworkConnectionEvent) -> Unit): AutoCloseable {
        synchronized(lock) {
            checkOpen()
            connectionListeners.add(listener)
        }
        return AutoCloseable { connectionListeners.remove(listener) }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        val hostToStop = synchronized(lock) {
            host.also { host = null }
        }
        try {
            hostToStop?.stop()?.get(LIBP2P_HOST_STOP_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        } finally {
            inboundExecutor.shutdownNow()
            connectionCallbackExecutor.shutdownNow()
            inboundBindings.clear()
            outboundBindings.clear()
            connectionListeners.clear()
        }
    }

    /** Narrow libp2p-only bridge used by UrlProtocol relay and LAN-discovery wiring. */
    internal fun requireLibp2pHost(): Host = ensureStarted(0)

    /** Restores UrlProtocol's historical raw peer parsing before it examines address records. */
    internal fun parsePeerId(peerId: String): PeerId = PeerId.fromBase58(peerId)

    private fun validateDialPeerId(peerId: String): PeerId {
        return try {
            PeerId.fromBase58(peerId)
        } catch (e: Exception) {
            throw IllegalArgumentException(
                "Cannot dial peer '$peerId': the peer ID is not valid base58 libp2p identity data.",
                e
            )
        }
    }

    private fun ensureStarted(requestedPort: Int): Host {
        checkOpen()
        host?.let { existing ->
            validateRequestedPort(requestedPort)
            return existing
        }

        synchronized(lock) {
            checkOpen()
            host?.let { existing ->
                validateRequestedPort(requestedPort)
                return existing
            }

            val listenAddress = "/ip4/$listenHost/tcp/$requestedPort"
            val key = keySeed?.let { Libp2pHostFactory.generateKeyFromSeed(it) }
            val created = if (enableRelay) {
                Libp2pHostFactory.createHostWithDeferredRelay(
                    listenAddresses = listOf(listenAddress),
                    deferredHandler = deferredRelayHandler,
                    keyPair = key,
                    includeDefaultRpcBinding = false
                )
            } else {
                Libp2pHostFactory.createHost(
                    listenAddresses = listOf(listenAddress),
                    protocols = emptyList(),
                    keyPair = key
                )
            }

            created.addConnectionHandler(ConnectionHandler.create { connection ->
                publishConnectionLifecycle(connection)
            })
            inboundBindings.forEach { (_, binding) ->
                created.addProtocolHandler(binding)
            }
            try {
                created.start().get(30, TimeUnit.SECONDS)
            } catch (startFailure: Exception) {
                try {
                    created.stop().get(LIBP2P_HOST_STOP_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                } catch (stopFailure: Exception) {
                    startFailure.addSuppressed(stopFailure)
                }
                throw startFailure
            }
            val boundAddresses = created.listenAddresses().map { it.toString() }
            val boundPort = boundAddresses.firstNotNullOfOrNull { address ->
                Regex("/tcp/(\\d+)(?:/|$)").find(address)?.groupValues?.get(1)?.toIntOrNull()
            } ?: run {
                val failure = IllegalStateException(
                    "Libp2pNetworkProvider started for requested port $requestedPort but none of its listen addresses contained an actual TCP port: $boundAddresses"
                )
                try {
                    created.stop().get(LIBP2P_HOST_STOP_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                } catch (stopFailure: Exception) {
                    failure.addSuppressed(stopFailure)
                }
                throw failure
            }
            requestedListenPort = requestedPort
            actualListenPort = boundPort
            host = created
            return created
        }
    }

    private fun validateRequestedPort(requestedPort: Int) {
        val actualPort = actualListenPort ?: return
        val initialRequest = requestedListenPort ?: actualPort
        if (requestedPort != 0 && requestedPort != actualPort) {
            throw IllegalStateException(
                "Libp2pNetworkProvider is already listening on actual port $actualPort " +
                    "(initially requested port $initialRequest) and cannot also listen on requested port $requestedPort."
            )
        }
    }

    private fun publishConnectionLifecycle(connection: Connection) {
        val remotePeerId = connection.secureSession().remoteId.toBase58()
        publishEvent(NetworkConnectionEvent.Connected(remotePeerId))
        connection.closeFuture().whenComplete { _, _ ->
            publishEvent(NetworkConnectionEvent.Disconnected(remotePeerId))
        }
    }

    private fun publishEvent(event: NetworkConnectionEvent) {
        try {
            connectionCallbackExecutor.execute {
                connectionListeners.forEach { listener ->
                    try {
                        listener(event)
                    } catch (failure: Throwable) {
                        debugLog {
                            "Libp2pNetworkProvider connection listener failed while handling $event: " +
                                "${failure.javaClass.name}: ${failure.message}"
                        }
                    }
                }
            }
        } catch (rejected: RejectedExecutionException) {
            if (!closed.get()) {
                debugLog {
                    "Libp2pNetworkProvider could not dispatch connection event $event because " +
                        "its callback executor rejected the task: ${rejected.message}"
                }
            }
        }
    }

    private fun checkOpen() {
        check(!closed.get()) { "Libp2pNetworkProvider is closed and cannot perform network operations." }
    }

    private fun ensureOutboundBinding(startedHost: Host, protocolId: String) {
        if (inboundBindings.containsKey(protocolId)) {
            return
        }
        synchronized(lock) {
            checkOpen()
            if (inboundBindings.containsKey(protocolId)) return
            outboundBindings.computeIfAbsent(protocolId) {
                Libp2pNetworkProtocolBinding(protocolId, { stream -> stream.close() }, inboundExecutor).also {
                    startedHost.addProtocolHandler(it)
                }
            }
        }
    }

    private fun standardizedDialFailure(
        peerId: String,
        address: String,
        protocolId: String,
        timeoutMs: Long,
        failure: Exception,
        rootLinkDiagnostics: RootLinkDiagnostics? = null,
    ): IllegalStateException {
        val causes = generateSequence<Throwable>(failure) { it.cause }.toList()
        val message = when {
            causes.any { it is TimeoutException } ->
                "Timed out after $timeoutMs ms while dialing peer '$peerId' at address '$address' using protocol '$protocolId'."
            causes.any { it is InvalidRemotePubKey } ->
                "Failed to dial peer '$peerId' at address '$address' using protocol '$protocolId' within $timeoutMs ms because the live endpoint did not authenticate as peer '$peerId'."
            causes.any {
                it is IllegalArgumentException &&
                    it.message?.contains("for P2P doesn't match existing value") == true
            } ->
                "Failed to dial peer '$peerId' at address '$address' using protocol '$protocolId' within $timeoutMs ms because the live endpoint did not authenticate as peer '$peerId'."
            causes.any {
                it is ConnectException || it is NoRouteToHostException || it is UnresolvedAddressException
            } ->
                "Failed to dial peer '$peerId' at address '$address' using protocol '$protocolId' within $timeoutMs ms because the address was unreachable."
            else ->
                "Failed to dial peer '$peerId' at address '$address' using protocol '$protocolId' within $timeoutMs ms because connection or protocol negotiation failed."
        }
        val cause = (failure as? ExecutionException)?.cause ?: failure
        return IllegalStateException(message + (rootLinkDiagnostics?.let { " $it" } ?: ""), cause)
    }

    companion object {
        /**
         * Maximum number of outbound dials this process may have in flight at once, across every
         * [Libp2pNetworkProvider] instance it owns.
         *
         * A dial holds a socket from the moment it is issued until it connects or the kernel
         * abandons the unanswered SYN, so this constant is the ceiling on simultaneous half-open
         * outbound connections. 24 keeps ordinary gossip fan-out, peer exchange, and RPC dialing
         * overlapping freely (measured healthy meshes hold single-digit concurrent dials) while
         * capping the socket, file-descriptor, and event-loop cost of a peer set that has gone
         * unreachable.
         */
        const val MAX_CONCURRENT_OUTBOUND_DIALS = 24

        /**
         * Number of outbound dials currently in flight process-wide.
         *
         * Exposed as an operational diagnostic: it never exceeds
         * [MAX_CONCURRENT_OUTBOUND_DIALS], and a value pinned at that ceiling indicates dials are
         * being issued faster than they complete.
         */
        fun pendingOutboundDialCount(): Int = OutboundDialAdmission.pendingCount()
    }
}

private class Libp2pNetworkProtocolBinding(
    protocolId: String,
    private val handler: (RpcStream) -> Unit,
    private val executor: ExecutorService
) : ProtocolBinding<Libp2pRpcController> {
    override val protocolDescriptor = ProtocolDescriptor(protocolId)

    override fun initChannel(
        ch: P2PChannel,
        selectedProtocol: String
    ): CompletableFuture<Libp2pRpcController> {
        val stream = ch as? Stream
            ?: return CompletableFuture.failedFuture(
                IllegalArgumentException(
                    "Cannot initialize network protocol '$selectedProtocol': expected a libp2p Stream but received ${ch::class.qualifiedName}."
                )
            )
        val controller = NettyStreamController(stream, selectedProtocol)
        if (!stream.isInitiator) {
            val admissionOrder = nextServiceConnectionAdmissionOrder()
            val rpcStream = AdmittedRpcStream(Libp2pRpcStream(
                controller = controller,
                remotePeerId = stream.remotePeerId().toBase58(),
                serviceIdentifier = selectedProtocol,
                readResponses = false
            ), admissionOrder)
            try {
                executor.execute {
                    try {
                        handler(rpcStream)
                    } catch (failure: Throwable) {
                        rpcStream.close()
                        debugLog {
                            "Inbound network protocol handler failed for '$selectedProtocol': " +
                                "${failure.javaClass.name}: ${failure.message}"
                        }
                    }
                }
            } catch (e: Exception) {
                rpcStream.close()
                return CompletableFuture.failedFuture(e)
            }
        }
        return CompletableFuture.completedFuture(controller)
    }
}
