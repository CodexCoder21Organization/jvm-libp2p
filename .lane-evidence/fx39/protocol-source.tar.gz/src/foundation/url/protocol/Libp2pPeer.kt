package foundation.url.protocol

import io.libp2p.core.Host
import io.libp2p.core.PeerId
import io.libp2p.core.multiformats.Multiaddr
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Implementation of BootstrapPeer backed by a libp2p Host.
 *
 * This implementation uses jvm-libp2p for all peer-to-peer operations including:
 * - Peer discovery via mDNS and DHT
 * - NAT traversal via Circuit Relay v2 and AutoNAT
 * - Peer liveness checking via the Ping protocol
 *
 * @property host The libp2p Host instance (null for remote peers)
 * @property remotePeerId The peer ID for remote peers
 * @property remoteMultiaddrs The multiaddresses for remote peers
 * @property services The services this peer advertises
 * @property lastSeen The last seen timestamp
 */
class Libp2pPeer private constructor(
    private val host: Host?,
    private val remotePeerId: String,
    remoteMultiaddrs: List<String>,
    private val services: List<String>,
    private var lastSeen: Long
) : BootstrapPeer {

    private val addressOwnership = PeerAddressOwnership(remoteMultiaddrs)
    private val remoteMultiaddrs: List<String>
        get() = addressOwnership.addresses

    override val peerId: String
        get() = remotePeerId

    override val multiaddresses: List<String>
        get() = remoteMultiaddrs

    internal fun retainRegistryAddresses(addresses: List<String>) {
        addressOwnership.retain(remotePeerId, addresses)
    }

    override val advertisedServices: List<String>
        get() = services

    override val lastSeenTimestamp: Long
        get() = lastSeen

    override fun discoverPeers(maxPeers: Int): List<BootstrapPeer> {
        if (host == null) {
            // Remote peer - we need an active host to query it
            return emptyList()
        }

        // Use the peer discovery service to find peers
        // This would query the DHT or use peer exchange protocols
        val discovered = mutableListOf<BootstrapPeer>()

        try {
            // Connect to this peer and request its peer list via a custom protocol
            // In a full implementation, this would use a protocol like:
            // - libp2p's peer exchange (PX) in gossipsub
            // - Kademlia DHT findPeers
            // - Custom peer discovery protocol

            val peerIdObj = PeerId.fromBase58(remotePeerId)
            val multiaddr = remoteMultiaddrs.firstOrNull()?.let { Multiaddr(it) }

            if (multiaddr != null) {
                // For now, we return peers we've connected to
                // A full implementation would query the remote peer's routing table
                val connectedPeers = host.network.connections
                    .filter { it.secureSession().remoteId.toBase58() != remotePeerId }
                    .take(maxPeers)
                    .map { conn ->
                        val id = conn.secureSession().remoteId.toBase58()
                        val addrs = listOf(conn.remoteAddress().toString())
                        Libp2pPeer(
                            host = null,
                            remotePeerId = id,
                            remoteMultiaddrs = addrs,
                            services = emptyList(),
                            lastSeen = System.currentTimeMillis()
                        )
                    }

                discovered.addAll(connectedPeers)
                lastSeen = System.currentTimeMillis()
            }
        } catch (e: Exception) {
            // Failed to discover peers
        }

        return discovered
    }

    override fun requestIntroduction(targetPeerId: String): RendezvousInfo? {
        if (host == null) {
            return null
        }

        try {
            // Use Circuit Relay v2 to request a reservation
            // The relay peer would provide a voucher for connecting to the target

            // In a full implementation, this would:
            // 1. Connect to this peer as a relay
            // 2. Request a reservation for the target peer
            // 3. Get a signed voucher/token
            // 4. Return the circuit address

            val relayMultiaddr = remoteMultiaddrs.firstOrNull() ?: return null
            val circuitAddr = "/p2p/$peerId/p2p-circuit/p2p/$targetPeerId"

            return RendezvousInfo(
                relayPeerId = peerId,
                relayMultiaddress = relayMultiaddr,
                reservationVoucher = "", // Would be filled by actual relay protocol
                expiresAt = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(10),
                circuitAddress = circuitAddr
            )
        } catch (e: Exception) {
            return null
        }
    }

    override fun canRoute(serviceIdentifier: String): Boolean {
        if (serviceIdentifier.isBlank()) {
            return false
        }
        // Match is exact only. See PeerRegistry.findPeersForService for the rationale.
        return advertisedServices.contains(serviceIdentifier)
    }

    override fun ping(timeoutMs: Long): Boolean {
        if (host == null) {
            return false
        }

        return try {
            val peerIdObj = PeerId.fromBase58(remotePeerId)
            val addressText = remoteMultiaddrs.firstOrNull() ?: return false
            val multiaddr = Multiaddr(addressText)

            // A ping opens a real connection, so it costs a socket exactly like any other dial and
            // is subject to the same process-wide bound. PeerRegistry.findRouterForService pings
            // every advertiser of a service, so an unbounded ping path reintroduces the storm this
            // bound exists to prevent. This dial does not run through NetworkProvider.dial, so the
            // permit has to be taken here.
            OutboundDialAdmission.withDialPermit(remotePeerId, addressText, timeoutMs) {
                val stream = host.newStream<Any>(
                    listOf("/ipfs/id/1.0.0"),
                    peerIdObj,
                    multiaddr
                )
                stream.stream.get(timeoutMs, TimeUnit.MILLISECONDS)
            }
            lastSeen = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put("peerId", remotePeerId)
            put("multiaddresses", JSONArray(remoteMultiaddrs))
            put("advertisedServices", JSONArray(services))
            put("lastSeenTimestamp", lastSeen)
        }
    }

    companion object {
        /**
         * Creates a Libp2pPeer for a remote peer (without a local host).
         *
         * @param peerId The peer's ID (base58 encoded)
         * @param multiaddresses The peer's multiaddresses
         * @param advertisedServices Services the peer advertises
         * @param lastSeenTimestamp When the peer was last seen
         */
        fun remote(
            peerId: String,
            multiaddresses: List<String>,
            advertisedServices: List<String> = emptyList(),
            lastSeenTimestamp: Long = System.currentTimeMillis()
        ): Libp2pPeer {
            return Libp2pPeer(
                host = null,
                remotePeerId = peerId,
                remoteMultiaddrs = multiaddresses,
                services = advertisedServices,
                lastSeen = lastSeenTimestamp
            )
        }

        /**
         * Creates a Libp2pPeer backed by a local libp2p Host.
         *
         * @param host The local libp2p Host
         * @param advertisedServices Services this peer advertises
         */
        fun local(
            host: Host,
            advertisedServices: List<String> = emptyList()
        ): Libp2pPeer {
            val peerId = host.peerId.toBase58()
            val multiaddrs = host.listenAddresses().map { it.toString() }

            return Libp2pPeer(
                host = host,
                remotePeerId = peerId,
                remoteMultiaddrs = multiaddrs,
                services = advertisedServices,
                lastSeen = System.currentTimeMillis()
            )
        }

        /**
         * Deserializes a Libp2pPeer from a JSONObject.
         * This creates a remote peer (no local host).
         */
        fun fromJson(json: JSONObject): Libp2pPeer {
            val peerId = json.getString("peerId")

            val multiaddrs = mutableListOf<String>()
            val addrsArray = json.getJSONArray("multiaddresses")
            for (i in 0 until addrsArray.length()) {
                multiaddrs.add(addrsArray.getString(i))
            }

            val services = mutableListOf<String>()
            if (json.has("advertisedServices")) {
                val servicesArray = json.getJSONArray("advertisedServices")
                for (i in 0 until servicesArray.length()) {
                    services.add(servicesArray.getString(i))
                }
            }

            val lastSeen = json.optLong("lastSeenTimestamp", System.currentTimeMillis())

            return Libp2pPeer(
                host = null,
                remotePeerId = peerId,
                remoteMultiaddrs = multiaddrs,
                services = services,
                lastSeen = lastSeen
            )
        }
    }
}
