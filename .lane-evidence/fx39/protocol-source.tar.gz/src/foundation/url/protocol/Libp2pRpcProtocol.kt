package foundation.url.protocol

import community.kotlin.clocks.simple.Scheduled
import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import org.json.JSONObject
import org.json.JSONArray
import java.io.*
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Thrown by [Libp2pRpcProtocol.acquireParseBudgetByDeadline] when an inbound frame's parse-memory
 * reservation is still queued at the reading caller's deadline. No permits are held when this is
 * thrown. It is an [IOException] so the existing reader error paths carry it unchanged, and a
 * distinct type so a reader whose deadline is an idle poll (rather than a request budget) can tell
 * inbound admission contention apart from a genuine read failure.
 */
class ParseBudgetDeadlineExceededException(message: String) : IOException(message)

/**
 * Protocol for RPC communication over libp2p streams.
 *
 * This protocol supports:
 * - Request/Response messaging
 * - Streaming responses (for observables)
 * - Effect propagation (AlgebraicEffects)
 * - Bidirectional communication for effect handling
 *
 * Message format (with binary attachments):
 * - 4 bytes: JSON length (big-endian)
 * - N bytes: JSON-encoded message
 * - 4 bytes: number of binary attachments (big-endian)
 * - For each attachment:
 *   - 4 bytes: attachment length (big-endian)
 *   - M bytes: raw binary data
 *
 * ByteArray values in RPC params/results are sent as binary attachments
 * instead of base64-encoded JSON strings, avoiding ~33% encoding overhead
 * and catastrophic string copy amplification during JSON parsing.
 *
 * Protocol ID: /aicli-rpc/1.0.0
 */
object Libp2pRpcProtocol {
    const val PROTOCOL_ID = "/aicli-rpc/1.0.0"
    const val PROTOCOL_VERSION = "1.0.0"

    // Attachment-capable RPC protocol (request-path binary attachments).
    //
    // 1.0.0 sends ByteArray RPC *request* params as base64-in-JSON
    // ({"__type":"bytes","__value":"<base64>"}) — ~1.37x size blowup plus the
    // host-side base64 encode/decode CPU. 1.1.0 sends them as out-of-band raw
    // length-prefixed binary attachments ({"__type":"binary_ref","__index":N}),
    // exactly like the already-shipped response/bytecode attachment path.
    //
    // The two versions are bound side by side; multistream-select picks the best
    // common one with no extra round trip. 1.1.0 is offered first, so a peer that
    // only understands 1.0.0 transparently downgrades. Because the compact wire
    // frame (a request with no ByteArray param has an empty attachment list) is
    // byte-for-byte identical between the two versions, only requests that
    // actually carry a ByteArray differ on the wire.
    const val PROTOCOL_ID_V11 = "/aicli-rpc/1.1.0"
    const val PROTOCOL_VERSION_V11 = "1.1.0"

    // Message types
    const val TYPE_REQUEST = "request"
    const val TYPE_RESPONSE = "response"
    const val TYPE_STREAM_START = "stream_start"
    const val TYPE_STREAM_DATA = "stream_data"
    const val TYPE_STREAM_END = "stream_end"
    const val TYPE_EFFECT_REQUEST = "effect_request"
    const val TYPE_EFFECT_RESPONSE = "effect_response"
    const val TYPE_OBSERVABLE_SUBSCRIBE = "observable_subscribe"
    const val TYPE_OBSERVABLE_UNSUBSCRIBE = "observable_unsubscribe"
    const val TYPE_OBSERVABLE_INVALIDATION = "observable_invalidation"
    const val TYPE_OBSERVABLE_VALUE = "observable_value"
    const val TYPE_ERROR = "error"
    const val TYPE_PING = "ping"
    const val TYPE_PONG = "pong"

    /**
     * Additive v1.1 request capability and transport-only response frame types used to expose
     * complete wire-frame boundaries inside a large computed response. Older v1.1 responders
     * ignore the unknown top-level capability field and continue sending the legacy atomic frame.
     */
    internal const val INTERLEAVED_RESPONSE_CAPABILITY_FIELD =
        "foundation.url.protocol.interleaved-response-frames"
    internal const val TYPE_INTERLEAVED_RESPONSE_START = "interleaved_response_start"
    internal const val TYPE_INTERLEAVED_RESPONSE_CHUNK = "interleaved_response_chunk"
    internal const val INTERLEAVED_RESPONSE_JSON_FIELD = "responseJson"
    internal const val INTERLEAVED_RESPONSE_LENGTHS_FIELD = "attachmentLengths"
    internal const val INTERLEAVED_RESPONSE_ATTACHMENT_INDEX_FIELD = "attachmentIndex"
    internal const val INTERLEAVED_RESPONSE_ATTACHMENT_OFFSET_FIELD = "attachmentOffset"

    /**
     * The `type` values this transport reserves for its own request/response
     * correlation and control frames (every `TYPE_*` constant above).
     *
     * This is the single source of truth for "which message types are the
     * transport's own". A server-initiated push frame
     * ([ServiceClientConnection.push]) MUST NOT reuse any of these: the client's
     * RPC-stream reader correlates transport frames (notably [TYPE_RESPONSE]) by
     * `type`+`id`, so a push carrying e.g. `type="response"` with a colliding id
     * would be mistaken for an in-flight RPC response and spoof it. Push
     * validation ([validatePushableFrame]) rejects reserved types using this set.
     */
    val RESERVED_MESSAGE_TYPES: Set<String> = setOf(
        TYPE_REQUEST, TYPE_RESPONSE, TYPE_STREAM_START, TYPE_STREAM_DATA, TYPE_STREAM_END,
        TYPE_EFFECT_REQUEST, TYPE_EFFECT_RESPONSE, TYPE_OBSERVABLE_SUBSCRIBE,
        TYPE_OBSERVABLE_UNSUBSCRIBE, TYPE_OBSERVABLE_INVALIDATION, TYPE_OBSERVABLE_VALUE,
        TYPE_ERROR, TYPE_PING, TYPE_PONG, TYPE_INTERLEAVED_RESPONSE_START,
        TYPE_INTERLEAVED_RESPONSE_CHUNK
    )

    // Error codes
    const val ERROR_UNKNOWN_METHOD = "UNKNOWN_METHOD"
    const val ERROR_INVALID_PARAMS = "INVALID_PARAMS"
    const val ERROR_INTERNAL = "INTERNAL_ERROR"
    const val ERROR_TIMEOUT = "TIMEOUT"
    const val ERROR_UNAUTHORIZED = "UNAUTHORIZED"
    const val ERROR_EFFECT_UNHANDLED = "EFFECT_UNHANDLED"
    const val ERROR_CONCURRENT_HANDLER_LIMIT = "CONCURRENT_HANDLER_LIMIT"
    const val ERROR_RESPONSE_OUTBOX_FULL = "RESPONSE_OUTBOX_FULL"

    // JSON parsing safety limits (see readMessage / validateJsonStructure).
    //
    // org.json's JSONTokener is a recursive-descent parser with no built-in
    // depth, per-string-length, or element-count limits. A single inbound
    // message within the 10 MB framing cap can therefore exhaust the heap
    // of a small consumer (e.g. ContainerNursery's -Xmx128m default) by
    // triggering 5-10x parser amplification. These caps are enforced
    // before JSONObject construction.
    const val MAX_JSON_NESTING_DEPTH: Int = 64
    const val MAX_JSON_FRAME_BYTES: Int = 10_000_000
    // 8 MB per string field. Sized to accommodate legitimate base64-encoded
    // ByteArray payloads (e.g. JAR bytecode, multi-MB binary RPC results
    // round-tripped via {"__type":"bytes","__value":"<base64>"} markers —
    // a 6 MB ByteArray becomes a ~8 MB base64 string) while still
    // sitting under the 10 MB framing cap so adversarial single-string
    // payloads cannot fill the entire frame.
    const val MAX_JSON_STRING_LENGTH: Int = 8 * 1024 * 1024
    const val MAX_JSON_ELEMENT_COUNT: Int = 1_000_000 // total array elements + object keys

    // ---- Concurrent inbound-message parse-memory budget (production OOM 2026-06-29) ----
    //
    // Reading a message materializes its body (`ByteArray(length)`) and then JSON-parses
    // it (`String(bytes)` -> UTF-16 char[] ~2x, then `JSONObject(...)` recursive-descent
    // graph) — about 5-7x the wire size of transient heap. A SINGLE message is already
    // bounded (10 MB frame / 8 MB string / structural caps), but NOTHING bounded how many
    // messages are materialized+parsed CONCURRENTLY. Each inbound RPC stream has its own
    // reader thread, so a burst of large messages (e.g. ContainerNursery's UrlFacade
    // proxying build uploads/responses to url://localhost.tcp services at -Xmx128m) parses
    // them all at once and exhausts the heap. A production heap dump showed 12 concurrent
    // `TcpRpcStream-Reader` threads each parsing an ~8 MB message — 45 MB / 41% of a 128 MB
    // heap — driving repeated `OutOfMemoryError: Java heap space`.
    //
    // Fix: a global worst-case-footprint CONCURRENCY budget. Before a reader
    // materializes+parses a body it reserves 7x its wire length and releases those permits
    // afterwards, so concurrent parse memory is bounded — readers block (TCP backpressure)
    // instead of OOMing. Seven is the conservative end of the measured/documented 5-7x parser
    // amplification range. An estimate at or above the entire concurrency pool reserves that
    // pool exclusively, serializing large parses without treating the estimate as a hard
    // single-frame limit. The independent 10 MB wire cap and JSON structural caps remain the
    // single-frame safety bounds. The concurrency pool scales with the heap (maxMemory/16,
    // clamped) so it self-tunes: ~8 MB on CN's 128 MB heap, more on roomier consumers.
    const val PARSE_AMPLIFICATION: Int = 7

    @JvmField
    val MAX_CONCURRENT_PARSE_BYTES: Int =
        (Runtime.getRuntime().maxMemory() / 16L).coerceIn(8L * 1024 * 1024, 256L * 1024 * 1024).toInt()

    /**
     * Process-wide size-aware reservation scheduler shared by JSON parsing and RPC attachments.
     *
     * A fair multi-permit semaphore cannot admit a fitting small request behind an older request
     * that needs more permits than are currently free. Parking those requests in a fixed worker
     * pool adds a second queue that can fill entirely with non-fitting requests. This scheduler
     * keeps one callback queue instead: it grants the oldest request when it fits, otherwise lets
     * at most [MAX_BYPASSES_PER_BLOCKED_REQUEST] later fitting requests pass before reserving all
     * future releases for the blocked request. A whole-budget release gives one queued smaller
     * request first choice before another whole-budget request, so a run of exclusive frames cannot
     * indefinitely postpone smaller work.
     */
    internal class SizeAwareReservationScheduler(private val capacity: Int) {
        internal class Reservation internal constructor(
            internal val permits: Int,
            internal val continuation: Boolean,
            internal val onGranted: () -> Unit
        ) {
            private val state = java.util.concurrent.atomic.AtomicInteger(WAITING)

            internal fun grant(): Boolean = state.compareAndSet(WAITING, GRANTED)
            internal fun cancel(): Boolean = state.compareAndSet(WAITING, CANCELLED)
            internal fun isWaiting(): Boolean = state.get() == WAITING
            internal fun isCancelled(): Boolean = state.get() == CANCELLED

            private companion object {
                const val WAITING = 0
                const val GRANTED = 1
                const val CANCELLED = 2
            }
        }

        private val lock = Any()
        private val waiters = java.util.ArrayDeque<Reservation>()
        private var available = capacity
        private var blockedHead: Reservation? = null
        private var blockedHeadBypasses = 0
        private var preferSmallAfterExclusiveRelease = false

        internal fun newReservation(permits: Int, continuation: Boolean = false, onGranted: () -> Unit): Reservation {
            require(permits in 1..capacity) {
                "Memory reservation permits must be between 1 and $capacity, but were $permits"
            }
            return Reservation(permits, continuation, onGranted)
        }

        internal fun enqueue(reservation: Reservation) {
            val granted = synchronized(lock) {
                if (reservation.isWaiting()) waiters.addLast(reservation)
                drainLocked()
            }
            invokeGranted(granted)
        }

        internal fun cancel(reservation: Reservation): Boolean {
            var cancelled = false
            val granted = synchronized(lock) {
                if (reservation.cancel()) {
                    cancelled = true
                    waiters.remove(reservation)
                    if (blockedHead === reservation) resetBlockedHeadLocked()
                }
                drainLocked()
            }
            invokeGranted(granted)
            return cancelled
        }

        @Throws(InterruptedException::class)
        internal fun acquire(permits: Int, continuation: Boolean = false) {
            val granted = java.util.concurrent.CountDownLatch(1)
            val reservation = newReservation(permits, continuation) { granted.countDown() }
            enqueue(reservation)
            try {
                granted.await()
            } catch (failure: InterruptedException) {
                // If cancellation loses, grant already deducted the permits. Return them before
                // surfacing the interruption so a racing handoff cannot leak the process budget.
                if (!cancel(reservation)) release(permits)
                throw failure
            }
        }

        /**
         * Acquires [permits] for a caller that already carries a deadline, returning `false` when
         * [deadlineMs] (in [clock] time) passes before the reservation is
         * granted. A reader whose own contract is bounded must never wait here beyond that
         * contract: [acquire] waits forever, so a bounded reader that used it silently ignored its
         * deadline and unwound only when some outer deadline fired. On expiry the reservation is
         * cancelled, so it stops holding a queue position and stops reserving future releases as a
         * blocked head. A grant that wins the race against that cancellation is honored — the
         * permits are already deducted, so the caller owns them and must release them.
         */
        @Throws(InterruptedException::class)
        internal fun acquireByDeadline(
            permits: Int,
            deadlineMs: Long,
            continuation: Boolean = false,
            clock: Clock = SystemClock(),
            cancellation: ParseBudgetCancellation? = null,
        ): Boolean {
            val granted = java.util.concurrent.CountDownLatch(1)
            val reservation = newReservation(permits, continuation) { granted.countDown() }
            enqueue(reservation)
            cancellation?.register(granted)
            var deadlineTask: Scheduled? = null
            var failure: Throwable? = null
            try {
                val waitMs = remainingReadWaitMillis(deadlineMs, clock.currentTimeMillis())
                if (waitMs > 0L) {
                    if (clock is SystemClock) {
                        // Real deadlines must not depend on a shared timer callback being run.
                        granted.await(waitMs, java.util.concurrent.TimeUnit.MILLISECONDS)
                    } else if (reservation.isWaiting() && cancellation?.isCancelled() != true) {
                        deadlineTask = clock.schedule(deadlineMs) { granted.countDown() }
                        // Registration may race clock advancement; a past-due task need not fire
                        // until another advance, so do not miss the already-passed deadline.
                        if (clock.currentTimeMillis() < deadlineMs) granted.await()
                    } else {
                        // A grant already owns its permits even if its wake callback is still
                        // returning. Preserve interruption without waiting or adding a clock task.
                        granted.await(0L, java.util.concurrent.TimeUnit.MILLISECONDS)
                    }
                }
            } catch (waitFailure: Throwable) {
                failure = waitFailure
            }
            try {
                deadlineTask?.let(clock::unschedule)
            } catch (cleanupFailure: Throwable) {
                if (failure == null) failure = cleanupFailure
                else failure.addSuppressed(cleanupFailure)
            }
            cancellation?.unregister(granted)
            // Both clock paths resolve the same reservation. A grant that precedes cancellation
            // owns the permits even if the deadline also fired. The clock callback only wakes the
            // reader; it never changes ownership and is harmless if it arrives after unscheduling.
            val ownsPermits = !cancel(reservation)
            failure?.let { original ->
                if (ownsPermits) {
                    try {
                        release(permits)
                    } catch (releaseFailure: Throwable) {
                        original.addSuppressed(releaseFailure)
                    }
                }
                throw original
            }
            if (cancellation?.isCancelled() == true) {
                // A grant may already own permits when local close wakes this waiter.
                // Return them here before the caller records an acquired parse reservation.
                if (ownsPermits) release(permits)
                return false
            }
            return ownsPermits
        }

        internal fun tryAcquire(permits: Int): Boolean = synchronized(lock) {
            require(permits in 1..capacity) {
                "Memory reservation permits must be between 1 and $capacity, but were $permits"
            }
            removeCancelledHeadLocked()
            if (permits > available) return@synchronized false
            val head = waiters.peekFirst()
            if (head == null) {
                available -= permits
                return@synchronized true
            }
            if (head.permits <= available) {
                // A queued predecessor can run now. The callback drain owns that handoff.
                return@synchronized false
            }
            trackBlockedHeadLocked(head)
            if (blockedHeadBypasses >= MAX_BYPASSES_PER_BLOCKED_REQUEST) {
                return@synchronized false
            }
            available -= permits
            blockedHeadBypasses++
            true
        }

        internal fun isContended(permits: Int): Boolean = synchronized(lock) {
            permits > available || waiters.isNotEmpty()
        }

        internal fun availablePermitCount(): Int = synchronized(lock) { available }

        /** Returns the number of reservations still waiting in this scheduler's fair queue. */
        internal fun queuedWaiterCount(): Int = synchronized(lock) {
            waiters.count { it.isWaiting() }
        }

        /**
         * Grants [permits] only when they are free outright — enough is available AND nothing is
         * queued. Unlike [tryAcquire] this never spends one of a blocked head's bounded
         * [MAX_BYPASSES_PER_BLOCKED_REQUEST] bypasses, so a caller with a cheaper alternative can
         * take genuinely idle capacity while leaving that bypass budget to the fitting attachment
         * frames it exists to admit.
         */
        internal fun tryAcquireUncontended(permits: Int): Boolean = synchronized(lock) {
            require(permits in 1..capacity) {
                "Memory reservation permits must be between 1 and $capacity, but were $permits"
            }
            removeCancelledHeadLocked()
            if (permits > available || waiters.isNotEmpty()) return@synchronized false
            available -= permits
            true
        }

        internal fun release(permits: Int) {
            val granted = synchronized(lock) {
                require(permits in 1..capacity) {
                    "Memory reservation permits must be between 1 and $capacity, but were $permits"
                }
                check(available <= capacity - permits) {
                    "Memory reservation released $permits permits without a matching acquisition " +
                        "(available=$available, capacity=$capacity)"
                }
                available += permits
                if (permits == capacity) preferSmallAfterExclusiveRelease = true
                drainLocked()
            }
            invokeGranted(granted)
        }

        private fun drainLocked(): List<Reservation> {
            val granted = ArrayList<Reservation>()
            while (true) {
                removeCancelledHeadLocked()
                if (waiters.isEmpty()) {
                    resetBlockedHeadLocked()
                    return granted
                }

                // These reads finish assemblies whose leases prevent an older whole-pool
                // reader from fitting. Their finite continuation work must not spend the
                // bypass allowance for NEW admissions. New assemblies still use that allowance.
                val continuation = waiters.firstOrNull {
                    it.continuation && it.isWaiting() && it.permits <= available
                }
                if (continuation != null) {
                    waiters.remove(continuation)
                    if (continuation.grant()) {
                        available -= continuation.permits
                        granted.add(continuation)
                    }
                    continue
                }

                if (preferSmallAfterExclusiveRelease) {
                    val small = if (blockedHeadBypasses < MAX_BYPASSES_PER_BLOCKED_REQUEST) {
                        waiters.firstOrNull { waiter ->
                            waiter.isWaiting() && waiter.permits < capacity && waiter.permits <= available
                        }
                    } else {
                        null
                    }
                    preferSmallAfterExclusiveRelease = false
                    if (small != null) {
                        val head = waiters.peekFirst()
                        waiters.remove(small)
                        if (small.grant()) {
                            available -= small.permits
                            granted.add(small)
                            if (head != null && head !== small) {
                                trackBlockedHeadLocked(head)
                                blockedHeadBypasses =
                                    (blockedHeadBypasses + 1).coerceAtMost(
                                        MAX_BYPASSES_PER_BLOCKED_REQUEST
                                    )
                            } else {
                                resetBlockedHeadLocked()
                            }
                            continue
                        }
                    }
                }

                val head = waiters.peekFirst()
                if (!head.isWaiting()) {
                    waiters.removeFirst()
                    continue
                }
                if (head.permits <= available) {
                    waiters.removeFirst()
                    if (head.grant()) {
                        available -= head.permits
                        granted.add(head)
                    }
                    resetBlockedHeadLocked()
                    continue
                }

                trackBlockedHeadLocked(head)
                if (blockedHeadBypasses >= MAX_BYPASSES_PER_BLOCKED_REQUEST) return granted
                val fitting = waiters.asSequence()
                    .drop(1)
                    .firstOrNull { it.isWaiting() && it.permits <= available }
                    ?: return granted
                waiters.remove(fitting)
                if (fitting.grant()) {
                    available -= fitting.permits
                    blockedHeadBypasses++
                    granted.add(fitting)
                }
            }
        }

        private fun removeCancelledHeadLocked() {
            while (waiters.isNotEmpty() && !waiters.peekFirst().isWaiting()) {
                val removed = waiters.removeFirst()
                if (blockedHead === removed) resetBlockedHeadLocked()
            }
        }

        private fun trackBlockedHeadLocked(head: Reservation) {
            if (blockedHead !== head) {
                blockedHead = head
                blockedHeadBypasses = 0
            }
        }

        private fun resetBlockedHeadLocked() {
            blockedHead = null
            blockedHeadBypasses = 0
        }

        private fun invokeGranted(granted: List<Reservation>) {
            var firstFailure: Throwable? = null
            granted.forEach { reservation ->
                try {
                    reservation.onGranted()
                } catch (failure: Throwable) {
                    if (firstFailure == null) {
                        firstFailure = failure
                    } else {
                        firstFailure!!.addSuppressed(failure)
                    }
                }
            }
            firstFailure?.let { throw it }
        }

        private companion object {
            // A newly blocked large request gives a short burst of fitting work immediate service,
            // then the scheduler drains toward that request. The bound is an admission count, not a
            // wall-clock guess, so eventual progress is independent of machine speed.
            const val MAX_BYPASSES_PER_BLOCKED_REQUEST = 8
        }
    }

    /** Immutable monitoring snapshot of the process-wide inbound memory reservations. */
    data class ParseMemoryBudgetSnapshot(
        val bytesReserved: Long,
        val maxObservedBytesReserved: Long,
        val acquisitions: Long,
        val contendedAcquisitions: Long,
        val byteLimit: Int,
        val queuedWaiters: Int,
        val parsePoolAvailableBytes: Int,
        val deadlineExpirations: Long,
        val lastExpiredFrameBytes: Int?,
    )

    /**
     * One complete inbound-memory accounting domain. Normal protocol operations use
     * [processWideMemoryBudget]; explicit owners keep their scheduling and accounting together.
     */
    internal class MemoryBudget internal constructor() {
        internal val parseMemoryBudget =
            SizeAwareReservationScheduler(MAX_CONCURRENT_PARSE_BYTES)
        private val parseBytesReserved = AtomicLong(0L)
        private val memoryAccountingLock = Any()
        private var companionFrameBytesReserved = 0L
        internal val companionFrameTurn = java.util.concurrent.Semaphore(1, true)

        /**
         * Fair one-slot turn held for the whole life of a GROWABLE attachment-frame lease (the
         * sequential `[length][body]` reader, whose aggregate the wire does not reveal up front).
         *
         * At most one lease per process may hold pool bytes while waiting for more, which is what
         * makes incremental admission free of the fair-semaphore hold-and-wait two growing frames
         * would otherwise form. It costs no concurrency: the whole-pool lease this replaced already
         * admitted exactly one such frame at a time by taking every permit in the pool. Attachment
         * frames still serialize against each other; every OTHER inbound read is now bounded by the
         * pool's remaining capacity instead of by the transfer's duration.
         */
        internal val growableAttachmentFrameTurn = java.util.concurrent.Semaphore(1, true)
        internal val borrowLock = Any()
        internal val activeAttachmentLeases = LinkedHashSet<FrameAttachmentLease>()
        private val maxObservedParseBytesReserved = AtomicLong(0L)
        private val parseBudgetAcquisitions = AtomicLong(0L)
        private val contendedParseBudgetAcquisitions = AtomicLong(0L)
        private var deadlineExpirations = 0L
        private var lastExpiredFrameBytes: Int? = null

        // A valid ordinary frame can follow a start even when assemblies fill their allowance.
        // Only one such frame at a time may use this budget's compact lane.
        internal val companionFrameByteLimit: Int get() =
            MAX_JSON_FRAME_BYTES * PARSE_AMPLIFICATION + MAX_ATTACHMENT_AGGREGATE_BYTES -
                INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES

        internal fun snapshot(): ParseMemoryBudgetSnapshot = synchronized(memoryAccountingLock) {
            ParseMemoryBudgetSnapshot(
                bytesReserved = parseBytesReserved.get() + companionFrameBytesReserved,
                maxObservedBytesReserved = maxObservedParseBytesReserved.get(),
                acquisitions = parseBudgetAcquisitions.get(),
                contendedAcquisitions = contendedParseBudgetAcquisitions.get(),
                byteLimit = MAX_CONCURRENT_PARSE_BYTES + companionFrameByteLimit,
                queuedWaiters = parseMemoryBudget.queuedWaiterCount(),
                parsePoolAvailableBytes = parseMemoryBudget.availablePermitCount(),
                deadlineExpirations = deadlineExpirations,
                lastExpiredFrameBytes = lastExpiredFrameBytes,
            )
        }

        internal fun recordDeadlineExpiration(frameBytes: Int) = synchronized(memoryAccountingLock) {
            deadlineExpirations++
            lastExpiredFrameBytes = frameBytes
        }

        internal fun recordParseBudgetAcquired(permits: Int, contended: Boolean) =
            synchronized(memoryAccountingLock) {
                parseBudgetAcquisitions.incrementAndGet()
                if (contended) contendedParseBudgetAcquisitions.incrementAndGet()
                val reserved = parseBytesReserved.addAndGet(permits.toLong())
                check(reserved <= MAX_CONCURRENT_PARSE_BYTES.toLong()) {
                    "Inbound parse-memory accounting exceeded its permit pool: " +
                        "reservedBytes=$reserved, byteLimit=$MAX_CONCURRENT_PARSE_BYTES"
                }
                recordCombinedMemoryPeak()
            }

        private fun recordCombinedMemoryPeak() {
            val combined = parseBytesReserved.get() + companionFrameBytesReserved
            maxObservedParseBytesReserved.set(maxOf(maxObservedParseBytesReserved.get(), combined))
        }

        internal fun changeCompanionFrameCharge(delta: Long) = synchronized(memoryAccountingLock) {
            companionFrameBytesReserved += delta
            check(companionFrameBytesReserved in 0L..companionFrameByteLimit.toLong()) {
                "Inbound companion-frame accounting is outside its allowance: " +
                    "reservedBytes=$companionFrameBytesReserved, " +
                    "byteLimit=$companionFrameByteLimit"
            }
            recordCombinedMemoryPeak()
        }

        internal fun recordParseBudgetContention() {
            contendedParseBudgetAcquisitions.incrementAndGet()
        }

        internal fun recordBorrowedParseBudgetAcquired() {
            parseBudgetAcquisitions.incrementAndGet()
        }

        private fun recordParseBudgetReleased(permits: Int) =
            synchronized(memoryAccountingLock) {
                val reserved = parseBytesReserved.addAndGet(-permits.toLong())
                check(reserved >= 0L) {
                    "Inbound parse-memory accounting became negative after releasing permits: " +
                        "releasedBytes=$permits, reservedBytes=$reserved"
                }
            }

        private fun returnParseBudgetPermitsAfterAccounting(permits: Int) {
            val reserved = parseBytesReserved.get()
            val maximumReservedBeforeHandoff = MAX_CONCURRENT_PARSE_BYTES.toLong() - permits
            check(reserved <= maximumReservedBeforeHandoff) {
                "Inbound parse-memory permits cannot be returned before their accounting " +
                    "reservation is removed: returningPermits=$permits, " +
                    "reservedBytes=$reserved, " +
                    "maximumReservedBeforeHandoff=$maximumReservedBeforeHandoff, " +
                    "byteLimit=$MAX_CONCURRENT_PARSE_BYTES"
            }
            parseMemoryBudget.release(permits)
        }

        internal fun releaseAccountedParseBudget(permits: Int) {
            recordParseBudgetReleased(permits)
            returnParseBudgetPermitsAfterAccounting(permits)
        }
    }

    private val processWideMemoryBudget = MemoryBudget()

    internal fun processWideMemoryBudget(): MemoryBudget = processWideMemoryBudget

    private val parseMemoryBudget: SizeAwareReservationScheduler
        get() = processWideMemoryBudget.parseMemoryBudget
    private val companionFrameTurn: java.util.concurrent.Semaphore
        get() = processWideMemoryBudget.companionFrameTurn
    private val companionFrameByteLimit: Int
        get() = processWideMemoryBudget.companionFrameByteLimit
    private fun recordParseBudgetAcquired(permits: Int, contended: Boolean) =
        processWideMemoryBudget.recordParseBudgetAcquired(permits, contended)
    private fun changeCompanionFrameCharge(delta: Long) =
        processWideMemoryBudget.changeCompanionFrameCharge(delta)
    internal fun recordParseBudgetContention() =
        processWideMemoryBudget.recordParseBudgetContention()
    private fun recordBorrowedParseBudgetAcquired() =
        processWideMemoryBudget.recordBorrowedParseBudgetAcquired()
    private fun releaseAccountedParseBudget(permits: Int) =
        processWideMemoryBudget.releaseAccountedParseBudget(permits)

    /**
     * Returns process-wide parse-memory accounting for diagnostics and capacity monitoring.
     * Reading this snapshot does not acquire permits or change parser scheduling.
     */
    fun parseMemoryBudgetSnapshot(): ParseMemoryBudgetSnapshot = processWideMemoryBudget.snapshot()

    // ---- RPC v1.1 binary-attachment admission bounds ----
    //
    // The attachment framing ([4 count][4 len][bytes]...) historically enforced only
    // per-item bounds: at most MAX_ATTACHMENTS attachments of at most
    // MAX_SINGLE_ATTACHMENT_BYTES each — a nominal 100 GB per-frame allowance with no
    // aggregate cap, no participation in the shared parse-memory pool above, and no
    // check that the declared count matches the envelope's binary references. A single
    // binary_ref in the JSON is enough to enter attachment framing, after which a peer
    // could declare huge or extra attachments and exhaust a 128 MiB-heap consumer —
    // the exact class of remotely-triggered OOM the JSON path was hardened against
    // (2026-06-29). Attachments are raw bytes buffered exactly once (no JSON parse, so
    // no 7x amplification and no 10 MB JSON frame cap), hence their own accounting:
    //
    // 1. The DECLARED per-frame aggregate must stay under the heap-scaled
    //    MAX_ATTACHMENT_AGGREGATE_BYTES (maxMemory/4, clamped to
    //    [32 MiB, MAX_SINGLE_ATTACHMENT_BYTES]) — enforced incrementally as each
    //    length header is read, BEFORE that attachment's body is allocated, so an
    //    abusive declaration is declined promptly without buffering.
    // 2. The declared attachment count must equal the number of binary_ref markers in
    //    the JSON envelope AND those markers' __index values must form an exact bijection
    //    with 0..count-1 ([validateBinaryRefIndices]) — no duplicate, missing, negative,
    //    or out-of-range index. A count match alone is bypassable (e.g. two markers both
    //    at __index 0 with a declared count of 2), which would leave attachment 1
    //    buffered but never referenced.
    // 3. Every frame holds a process-budget reservation covering the bytes it will retain, taken
    //    before its first body is materialized and held through complete-frame assembly. The Netty
    //    decoder can read a single attachment's length before its body, so it reserves that
    //    validated length (capped at the whole pool); its physical connection also admits only one
    //    attachment frame at a time. The sequential InputStream reader cannot see its aggregate up
    //    front — interleaved [len][body] pairs do not reveal it — so it RAISES its reservation to
    //    the running declared aggregate before each body is allocated
    //    ([FrameAttachmentLease.growTo]) rather than reserving the whole pool and stalling every
    //    other inbound read in the process for the transfer's duration. Exactly one such growable
    //    frame runs at a time ([MemoryBudget.growableAttachmentFrameTurn]) and no other path grows
    //    a reservation while holding permits, so fair-semaphore hold-and-wait cannot form. Netty
    //    multi-attachment frames still reserve the whole pool and lend their unarrived headroom
    //    through [FrameAttachmentLease.borrowUnusedCapacity].
    const val MAX_ATTACHMENTS: Int = 1000
    const val MAX_SINGLE_ATTACHMENT_BYTES: Int = 100_000_000
    internal const val INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES: Int = 1024 * 1024

    /**
     * Bytes the sequential attachment-frame reader is admitted for before its first validated length
     * header: at that point it retains only the attachment-count word and the first length word.
     * Each body is charged as its length header validates it
     * ([FrameAttachmentLease.growTo]), so the frame holds the bytes it will really retain instead of
     * the whole pool. The initial admission still goes through the pool, so the frame takes its
     * place in the fair scheduler queue before it reads anything.
     */
    internal const val ATTACHMENT_FRAME_ADMISSION_RESERVE_BYTES: Int = 8

    @JvmField
    val MAX_ATTACHMENT_AGGREGATE_BYTES: Int =
        (Runtime.getRuntime().maxMemory() / 4L)
            .coerceIn(32L * 1024 * 1024, MAX_SINGLE_ATTACHMENT_BYTES.toLong()).toInt()

    /**
     * Maximum time an attachment frame may hold its process reservation and physical-connection
     * turn WITHOUT making read progress before it is treated as stalled. The lease is released and
     * the stream/channel is torn down, so a peer cannot retain shared memory or block all later
     * frames on its connection forever. This is a MINIMUM-PROGRESS budget, not an absolute
     * deadline: any inbound byte resets it, so a slow-but-progressing transfer is not aborted by
     * this guard; only a genuine no-progress stall trips it.
     */
    const val ATTACHMENT_STALL_TIMEOUT_MS: Long = 10_000L

    /** How often the stall watchdog re-checks progress. */
    private const val ATTACHMENT_STALL_CHECK_INTERVAL_MS: Long = 1_000L

    // ---- ABSOLUTE per-frame lease deadline (byte-dribbling slow-loris defense) ----
    //
    // The stall watchdog above is a MINIMUM-PROGRESS budget: any inbound byte resets it. That is
    // necessary (a legitimately slow-but-progressing large transfer must never be aborted) but it
    // is NOT sufficient on its own: one peer can enter attachment framing, acquire a process
    // reservation and its connection turn, then dribble one byte every ~9.9s — under the stall
    // threshold and under the 120s transport idle timeout — so NEITHER the stall watchdog NOR the
    // ReadTimeoutHandler ever fires. At ~1 byte / 9.9s a MAX_ATTACHMENT_AGGREGATE_BYTES frame takes
    // on the order of YEARS, retaining shared memory and blocking every later attachment frame on
    // that physical connection for the whole effectively-unbounded transfer.
    //
    // Fix: in ADDITION to (never replacing) the per-byte stall watchdog, impose an ABSOLUTE
    // deadline for how long a frame may hold its admission lease, derived from a floor throughput. A
    // frame declaring D aggregate bytes gets at least
    //   ceil(D / MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC) seconds
    // (floored at ATTACHMENT_MIN_LEASE_DEADLINE_MS so tiny frames still get a sane grace window).
    // The floor is deliberately conservative — 4 KiB/s — so any legitimate large-JAR transfer over
    // a genuinely slow-but-real link still completes with enormous margin (a 32 MiB frame gets
    // ~2.3 hours, a 100 MB frame ~7.1 hours; even a dial-up-class ~5 KiB/s link finishes with room
    // to spare), while a sub-floor dribble (fractions of a byte/sec, ~4 orders of magnitude below
    // the floor) is aborted: the admission lease is force-released and the stalled stream torn
    // down. The deadline is measured from lease acquisition against an injectable [Clock] so it is
    // deterministically unit-testable with a ManualClock, and it grows only as validated length
    // headers raise the running declared aggregate (itself capped by MAX_ATTACHMENT_AGGREGATE_BYTES),
    // so it is bounded and known incrementally as the frame is read.
    const val MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC: Long = 4L * 1024

    /**
     * Floor for the absolute per-frame lease deadline: even a frame declaring only a handful of
     * bytes may hold its admission lease for at least this long before the absolute deadline can trip,
     * so a momentary link hiccup on a small legitimate transfer is not misread as a loris. The
     * per-byte stall watchdog ([ATTACHMENT_STALL_TIMEOUT_MS]) still governs no-progress stalls
     * within this window.
     */
    const val ATTACHMENT_MIN_LEASE_DEADLINE_MS: Long = 60_000L

    /**
     * The absolute wall-clock budget (ms) a frame declaring [declaredAggregateBytes] of attachment
     * body may hold its admission lease, from lease acquisition, based on the floor throughput
     * [MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC] and floored at [ATTACHMENT_MIN_LEASE_DEADLINE_MS].
     * Grows as validated length headers raise the running declared aggregate; bounded because
     * [declaredAggregateBytes] is capped by [MAX_ATTACHMENT_AGGREGATE_BYTES].
     */
    fun attachmentLeaseDeadlineMs(declaredAggregateBytes: Long): Long {
        val throughputBudgetSeconds =
            (declaredAggregateBytes + MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC - 1) /
                MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC
        val throughputBudgetMs = throughputBudgetSeconds * 1000L
        return maxOf(ATTACHMENT_MIN_LEASE_DEADLINE_MS, throughputBudgetMs)
    }

    /**
     * The exact diagnostic for an RPC v1.1 frame force-aborted because it held its shared
     * attachment lease past its ABSOLUTE deadline while still dribbling below the floor throughput
     * [MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC]. Names the actual elapsed-hold, the deadline, the
     * declared aggregate, and the floor throughput so an operator can see exactly why it tripped.
     * Shared verbatim by both decode paths (as an [IOException] on the InputStream path, wrapped in
     * a diagnostic on the Netty path).
     */
    fun attachmentLeaseDeadlineExceededMessage(
        heldMs: Long,
        deadlineMs: Long,
        declaredAggregateBytes: Long
    ): String =
        "Inbound RPC attachment frame held the shared attachment pool past its absolute deadline " +
            "while transferring below the floor throughput: heldMs=$heldMs, deadlineMs=$deadlineMs, " +
            "declaredAttachmentBytes=$declaredAggregateBytes, " +
            "floorThroughputBytesPerSec=$MIN_ATTACHMENT_THROUGHPUT_BYTES_PER_SEC; released the shared " +
            "attachment pool and closed the stream"

    /**
     * Injectable clock for the attachment stall/deadline liveness logic. Defaults to
     * [SystemClock]; unit tests set a `ManualClock` so the absolute-deadline behavior is
     * deterministically testable without wall-clock sleeps. The watchdog scheduler still fires on
     * real wall time (its cadence), but the deadline DECISION reads this clock, so a test can
     * advance the clock past a frame's deadline and the next real watchdog tick force-releases.
     */
    @Volatile
    var attachmentClock: Clock = SystemClock()

    /**
     * Shared daemon scheduler for attachment-frame stall watchdogs. Each check only reads atomic
     * progress counters and closes a stalled channel, so one scheduler thread can service all
     * concurrently admitted frames. The thread times out when idle so it costs nothing at rest.
     */
    private val attachmentStallWatchdog: java.util.concurrent.ScheduledThreadPoolExecutor =
        java.util.concurrent.ScheduledThreadPoolExecutor(1) { r ->
            Thread(r, "url-attachment-stall-watchdog").apply { isDaemon = true }
        }.apply {
            setKeepAliveTime(30L, java.util.concurrent.TimeUnit.SECONDS)
            allowCoreThreadTimeOut(true)
            removeOnCancelPolicy = true
        }

    /**
     * Schedules a repeating attachment stall check on the shared watchdog (first run after
     * [ATTACHMENT_STALL_TIMEOUT_MS], then every check interval). The [check] runnable should
     * force-release/tear down if the frame has made no progress within the timeout. Cancel the
     * returned future when the frame completes. Used by the Netty [AttachmentRpcFrameDecoder],
     * which lives in another file; the InputStream reader schedules against the same executor
     * directly.
     */
    internal fun scheduleAttachmentStallWatchdog(check: Runnable): java.util.concurrent.ScheduledFuture<*> =
        attachmentStallWatchdog.scheduleWithFixedDelay(
            check,
            ATTACHMENT_STALL_CHECK_INTERVAL_MS,
            ATTACHMENT_STALL_CHECK_INTERVAL_MS,
            java.util.concurrent.TimeUnit.MILLISECONDS
        )

    /**
     * Reads exactly [bytes].size bytes from [input], invoking [onProgress] after each underlying
     * read that delivers at least one byte. The per-chunk progress callback lets a stall watchdog
     * distinguish a genuinely stalled peer (no bytes arriving) from a slow-but-progressing large
     * transfer. Throws [EOFException] if the stream ends early (identical message to [readFully]).
     */
    private fun readFullyWithProgress(input: InputStream, bytes: ByteArray, onProgress: () -> Unit) {
        var read = 0
        while (read < bytes.size) {
            val n = input.read(bytes, read, bytes.size - read)
            if (n == -1) throw EOFException("Stream closed while reading message data (read $read of ${bytes.size} bytes)")
            if (n > 0) {
                read += n
                onProgress()
            }
        }
    }

    /**
     * Fair, non-thread-blocking turnstile shared by every attachment decoder on one physical
     * connection. Waiting frames occupy only this bounded-by-stream-count queue; they do not occupy
     * platform threads while an earlier frame on the same connection drains.
     */
    internal class AttachmentFrameTurn {
        internal class Waiter internal constructor(
            internal val onGranted: () -> Unit
        ) {
            private val state = java.util.concurrent.atomic.AtomicInteger(WAITING)

            internal fun grant(): Boolean = state.compareAndSet(WAITING, GRANTED)
            internal fun cancel(): Boolean = state.compareAndSet(WAITING, CANCELLED)
            internal fun isWaiting(): Boolean = state.get() == WAITING

            private companion object {
                const val WAITING = 0
                const val GRANTED = 1
                const val CANCELLED = 2
            }
        }

        private val lock = Any()
        private val waiters = java.util.ArrayDeque<Waiter>()
        private var held = false

        internal fun newWaiter(onGranted: () -> Unit): Waiter = Waiter(onGranted)

        internal fun enqueue(waiter: Waiter) {
            var grantNow = false
            synchronized(lock) {
                if (!waiter.isWaiting()) return
                if (!held && waiters.isEmpty()) {
                    check(waiter.grant())
                    held = true
                    grantNow = true
                } else {
                    waiters.addLast(waiter)
                }
            }
            if (grantNow) waiter.onGranted()
        }

        internal fun cancel(waiter: Waiter): Boolean = synchronized(lock) {
            if (!waiter.cancel()) return@synchronized false
            waiters.remove(waiter)
            true
        }

        internal fun tryAcquire(): Boolean = synchronized(lock) {
            if (held || waiters.isNotEmpty()) {
                false
            } else {
                held = true
                true
            }
        }

        /**
         * Acquires the turn immediately or queues [waiter] while holding the same turn lock.
         * Unlike [enqueue], the immediate grant does not invoke the callback. This lets a caller
         * hand the turn to its next admission step without exposing a release-and-re-register
         * gap between the two steps.
         */
        internal fun tryAcquireOrEnqueue(waiter: Waiter): Boolean = synchronized(lock) {
            if (!waiter.isWaiting()) return@synchronized false
            if (!held && waiters.isEmpty()) {
                check(waiter.grant())
                held = true
                true
            } else {
                waiters.addLast(waiter)
                false
            }
        }

        @Throws(InterruptedException::class)
        internal fun acquire(): Unit {
            val granted = java.util.concurrent.CountDownLatch(1)
            val waiter = newWaiter { granted.countDown() }
            enqueue(waiter)
            try {
                granted.await()
            } catch (e: InterruptedException) {
                // If cancellation loses, this waiter was already granted the turn and must return it.
                if (!cancel(waiter)) release()
                throw e
            }
        }

        internal fun release() {
            var next: Waiter? = null
            synchronized(lock) {
                check(held) {
                    "Attachment-frame connection turn was released without a matching acquisition"
                }
                while (waiters.isNotEmpty()) {
                    val candidate = waiters.removeFirst()
                    if (candidate.grant()) {
                        next = candidate
                        break
                    }
                }
                if (next == null) held = false
            }
            next?.onGranted?.invoke()
        }
    }

    /**
     * A frame-scoped lease on the shared [parseMemoryBudget] scheduler.
     *
     * The public no-argument constructor reserves the whole pool outright, for callers that mean to
     * take exclusive admission. The Netty decoder can use [forKnownSize] after reading a single
     * attachment's validated length header, reserving that exact body size (capped at the whole
     * pool). It also supplies a fair one-frame gate shared by every stream on the same physical
     * connection. This keeps total admitted attachment bytes within the existing process pool while
     * preventing many streams on one connection from consuming every admission slot ahead of an
     * independent connection.
     *
     * The sequential InputStream reader reserves what its frame will actually retain, raising the
     * reservation through [growTo] as each validated length header reveals more. Incrementally
     * growing a reservation while retaining earlier bodies would reintroduce fair-semaphore
     * hold-and-wait — two frames could each retain one attachment and wait for permits only the
     * other frame can release — so exactly one lease per process may grow, serialized by
     * [MemoryBudget.growableAttachmentFrameTurn]. The Netty multi-attachment decoder still reserves
     * the whole pool in one acquisition ([forUnknownSize]) and lends its unarrived headroom through
     * [borrowUnusedCapacity] instead.
     *
     * State is guarded by an intrinsic lock so an acquire completing after [close] releases both
     * its process permits and physical-connection gate immediately. [release] and [close] are
     * idempotent.
     */
    class FrameAttachmentLease private constructor(
        initialPermits: Int,
        private val connectionGate: AttachmentFrameTurn?,
        private val preserveWholePoolInterruptionMessage: Boolean,
        private val continuation: Boolean = false,
        private val memoryBudget: MemoryBudget = processWideMemoryBudget,
        private val ownsGrowingFrameTurn: Boolean = false,
    ) {
        private data class AdmissionResult(
            val admitted: Boolean,
            val failure: Throwable?
        )

        private class PendingAdmission(
            var callback: ((Boolean, Throwable?) -> Unit)?
        ) {
            var result: AdmissionResult? = null
            var gateWaiter: AttachmentFrameTurn.Waiter? = null
            var budgetReservation: SizeAwareReservationScheduler.Reservation? = null
        }

        /**
         * One borrower's hold on capacity an attachment frame declared but has not received.
         *
         * Pausing the owner's reads is the price of the loan, and the pause is matched one-for-one
         * with a resume: this class always issues exactly one resume through the very controller
         * that issued its pause, whatever happened to the owning lease meanwhile. The decoder on the
         * other side counts those requests, so its reads resume only when NO borrow — against any
         * lease generation of that decoder — still needs the pause. Deciding the resume here, from
         * one lease's own borrow counters, would let a borrow against a superseded lease clear a
         * pause a live borrow against the current one still requires.
         */
        internal class BorrowedCapacity internal constructor(
            private val owner: FrameAttachmentLease,
            internal val permits: Int,
            private val readController: (Boolean, (Throwable?) -> Unit) -> Unit
        ) {
            private var released = false
            private var transferred = false

            internal fun markTransferred() {
                synchronized(owner.memoryBudget.borrowLock) {
                    if (!released) transferred = true
                }
            }

            internal fun release() {
                var releaseTransferredPermits = false
                synchronized(owner.memoryBudget.borrowLock) {
                    if (released) return
                    released = true
                    if (transferred) {
                        releaseTransferredPermits = true
                    } else {
                        owner.activeBorrows.remove(this)
                        owner.borrowedBytes -= permits
                        check(owner.borrowedBytes >= 0) {
                            "Attachment future-capacity borrowing became negative after releasing " +
                                "$permits bytes"
                        }
                    }
                }
                if (releaseTransferredPermits) {
                    // The owning lease closed while this loan was live, so it handed real pool
                    // permits over rather than capacity it no longer holds.
                    owner.memoryBudget.releaseAccountedParseBudget(permits)
                }
                readController.invoke(false) { }
            }
        }

        /**
         * Bytes this lease currently holds in the process pool. A completed decoder frame returns
         * unused permits at handoff; the sequential attachment reader's lease raises it through
         * [growTo] as validated length headers reveal how much the frame will really retain. Every
         * raise is a separate admission through the same scheduler, so the process total stays
         * bounded by [MAX_CONCURRENT_PARSE_BYTES]. Written only under [lock]; read by the borrowing
         * accounting under [MemoryBudget.borrowLock], hence volatile.
         */
        @Volatile
        private var permits: Int = initialPermits

        private val lock = Any()
        private var held: Boolean = false
        private var closed: Boolean = false
        private var connectionGateHeld: Boolean = false
        private var pendingAdmission: PendingAdmission? = null
        private class PendingGrowth(
            val reservation: SizeAwareReservationScheduler.Reservation,
            val finished: java.util.concurrent.CountDownLatch,
        )
        private var pendingGrowth: PendingGrowth? = null
        private var retainedAttachmentBytes: Int = 0
        private var borrowedBytes: Int = 0
        private var pendingBorrowBytes: Int = 0
        private val activeBorrows = LinkedHashSet<BorrowedCapacity>()
        private var borrowReadController: (((Boolean, (Throwable?) -> Unit) -> Unit))? = null
        // Mplex pauses hold the physical connection; Yamux pauses hold only the child.
        private var borrowPauseHeldConnection: Any? = null

        /** Whole-pool lease used by the sequential InputStream decoder and compatibility tests. */
        constructor() : this(MAX_CONCURRENT_PARSE_BYTES, null, true)

        init {
            require(permits in 1..MAX_CONCURRENT_PARSE_BYTES) {
                "Attachment-memory lease permits must be between 1 and " +
                    "$MAX_CONCURRENT_PARSE_BYTES, but were $permits"
            }
        }

        internal companion object {
            /**
             * Creates the growable lease the sequential InputStream decoder uses for a frame whose
             * aggregate the interleaved `[length][body]` wire does not reveal up front.
             *
             * It is admitted for [ATTACHMENT_FRAME_ADMISSION_RESERVE_BYTES] — all the frame retains
             * before its first validated length header — and then raised through [growTo] to the
             * running declared aggregate before each body is allocated, so the pool bytes a frame
             * holds match the bytes it will actually retain instead of the whole pool. The lease
             * owns [MemoryBudget.growableAttachmentFrameTurn] until terminal close, including while
             * initial admission is pending. The reader must close it if admission fails.
             */
            internal fun forGrowingFrame(
                memoryBudget: MemoryBudget = processWideMemoryBudget,
            ): FrameAttachmentLease {
                try {
                    memoryBudget.growableAttachmentFrameTurn.acquire()
                } catch (interruption: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw IOException(
                        "Interrupted while waiting for the inbound attachment frame turn " +
                            "(concurrencyBudget=$MAX_CONCURRENT_PARSE_BYTES)",
                        interruption
                    )
                }
                return try {
                    FrameAttachmentLease(
                        ATTACHMENT_FRAME_ADMISSION_RESERVE_BYTES,
                        null,
                        false,
                        memoryBudget = memoryBudget,
                        ownsGrowingFrameTurn = true,
                    )
                } catch (failure: Throwable) {
                    memoryBudget.growableAttachmentFrameTurn.release()
                    throw failure
                }
            }

            /** Creates one fixed-size lease for a frame whose aggregate is already known. */
            fun forKnownSize(
                attachmentBytes: Long,
                connectionGate: AttachmentFrameTurn,
                memoryBudget: MemoryBudget = processWideMemoryBudget,
            ): FrameAttachmentLease {
                val requiredPermits = attachmentBytes
                    .coerceAtLeast(1L)
                    .coerceAtMost(MAX_CONCURRENT_PARSE_BYTES.toLong())
                    .toInt()
                return FrameAttachmentLease(
                    requiredPermits,
                    connectionGate,
                    false,
                    memoryBudget = memoryBudget,
                )
            }

            /**
             * Reserves a known large-response assembly while leaving a bounded lane for compact
             * request/response parsing. A second large assembly still asks for more than that lane
             * and remains queued, while a small request needed to produce the next priority reply
             * can progress even when both in-process peers share this scheduler.
             */
            internal fun forInterleavedResponse(
                attachmentBytes: Long,
                memoryBudget: MemoryBudget = processWideMemoryBudget,
            ): FrameAttachmentLease {
                val maximumAssemblyPermits =
                    MAX_CONCURRENT_PARSE_BYTES - INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES
                require(attachmentBytes in 0L..maximumAssemblyPermits.toLong()) {
                    "Interleaved response attachment bytes must be between 0 and " +
                        "$maximumAssemblyPermits, but were $attachmentBytes"
                }
                val requiredPermits = attachmentBytes
                    .coerceAtLeast(1L)
                    .toInt()
                return FrameAttachmentLease(
                    requiredPermits,
                    null,
                    false,
                    memoryBudget = memoryBudget,
                )
            }

            /** Claims the single compact-frame lane left beside interleaved response assemblies. */
            internal fun forInterleavedCompactFrame(
                memoryBudget: MemoryBudget = processWideMemoryBudget,
            ): FrameAttachmentLease =
                FrameAttachmentLease(
                    INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES,
                    null,
                    false,
                    continuation = true,
                    memoryBudget = memoryBudget,
                )

            /** Whole-pool lease for an interleaved frame whose aggregate is not known up front. */
            fun forUnknownSize(
                connectionGate: AttachmentFrameTurn,
                memoryBudget: MemoryBudget = processWideMemoryBudget,
            ): FrameAttachmentLease =
                FrameAttachmentLease(
                    MAX_CONCURRENT_PARSE_BYTES,
                    connectionGate,
                    false,
                    memoryBudget = memoryBudget,
                )

            internal fun borrowUnusedCapacity(
                permits: Int,
                borrowerPhysicalConnection: Any,
                memoryBudget: MemoryBudget = processWideMemoryBudget,
            ): BorrowedCapacity? {
                val owner = synchronized(memoryBudget.borrowLock) {
                    memoryBudget.activeAttachmentLeases.firstOrNull { lease ->
                        lease.borrowReadController != null &&
                            lease.borrowPauseHeldConnection !== borrowerPhysicalConnection &&
                            lease.permits - lease.retainedAttachmentBytes - lease.borrowedBytes -
                                lease.pendingBorrowBytes >= permits
                    }?.also { it.pendingBorrowBytes += permits }
                } ?: return null

                val paused = java.util.concurrent.CountDownLatch(1)
                val pauseFailure = java.util.concurrent.atomic.AtomicReference<Throwable?>()
                val controller = synchronized(memoryBudget.borrowLock) {
                    owner.borrowReadController
                }
                if (controller == null) {
                    synchronized(memoryBudget.borrowLock) {
                        owner.pendingBorrowBytes -= permits
                    }
                    return null
                }
                try {
                    controller.invoke(true) { failure ->
                        pauseFailure.set(failure)
                        paused.countDown()
                    }
                    paused.await()
                    pauseFailure.get()?.let { throw it }
                } catch (interrupted: InterruptedException) {
                    Thread.currentThread().interrupt()
                    synchronized(memoryBudget.borrowLock) {
                        owner.pendingBorrowBytes -= permits
                    }
                    controller.invoke(false) { }
                    return null
                } catch (failure: Throwable) {
                    synchronized(memoryBudget.borrowLock) {
                        owner.pendingBorrowBytes -= permits
                    }
                    controller.invoke(false) { }
                    throw failure
                }

                val borrowed = synchronized(memoryBudget.borrowLock) {
                    val stillActive = memoryBudget.activeAttachmentLeases.contains(owner)
                    val stillFits = owner.permits - owner.retainedAttachmentBytes -
                        owner.borrowedBytes - (owner.pendingBorrowBytes - permits) >= permits
                    owner.pendingBorrowBytes -= permits
                    if (stillActive && stillFits) {
                        BorrowedCapacity(owner, permits, controller).also { capacity ->
                            owner.borrowedBytes += permits
                            owner.activeBorrows.add(capacity)
                        }
                    } else {
                        null
                    }
                }
                // A granted loan carries its pause forward until release(); an abandoned attempt
                // returns the pause it took right here. Either way the pause and its resume are
                // matched one-for-one, so the decoder's count — not one lease's counters — decides
                // when reads actually resume.
                if (borrowed == null) controller.invoke(false) { }
                return borrowed
            }
        }

        /**
         * Installs the callback that pauses and resumes the reads of the decoder feeding this
         * lease. Borrowers issue exactly one pause and exactly one matching resume per attempt, so
         * the controller must COUNT outstanding pause requests rather than latch a flag: several
         * borrows can be live at once, and successive leases of one decoder share it.
         */
        internal fun installBorrowReadController(
            pauseHeldPhysicalConnection: Any?,
            controller: (Boolean, (Throwable?) -> Unit) -> Unit,
        ) {
            synchronized(memoryBudget.borrowLock) {
                borrowPauseHeldConnection = pauseHeldPhysicalConnection
                borrowReadController = controller
            }
        }

        internal fun updateRetainedAttachmentBytes(bytes: Long) {
            synchronized(memoryBudget.borrowLock) {
                if (!memoryBudget.activeAttachmentLeases.contains(this)) return
                retainedAttachmentBytes = bytes
                    .coerceAtLeast(0L)
                    .coerceAtMost(permits.toLong())
                    .toInt()
            }
        }

        private fun registerBorrowableLease() {
            synchronized(memoryBudget.borrowLock) {
                retainedAttachmentBytes = 0
                memoryBudget.activeAttachmentLeases.add(this)
            }
        }

        private fun unregisterBorrowableLease(): Int {
            synchronized(memoryBudget.borrowLock) {
                memoryBudget.activeAttachmentLeases.remove(this)
                retainedAttachmentBytes = 0
                val transferred = borrowedBytes
                activeBorrows.forEach { it.markTransferred() }
                activeBorrows.clear()
                borrowedBytes = 0
                return permits - transferred
            }
        }

        /** Whether this frame's process reservation and connection turn are currently held. */
        val isHeld: Boolean get() = synchronized(lock) { held }

        /**
         * Blockingly acquires this frame's physical-connection turn and fixed process reservation,
         * unless already held. An acquire that completes after [close] gives both resources back.
         */
        fun acquire(): Boolean {
            synchronized(lock) {
                if (closed) return false
                if (held) return true
                check(pendingAdmission == null) {
                    "Cannot blockingly acquire an attachment lease while async admission is pending"
                }
            }
            var gateAcquired = false
            try {
                connectionGate?.acquire()
                gateAcquired = connectionGate != null
                memoryBudget.parseMemoryBudget.acquire(permits, continuation)
            } catch (e: InterruptedException) {
                var cleanupFailure: Throwable? = null
                try {
                    releaseResources(false, gateAcquired)
                } catch (failure: Throwable) {
                    cleanupFailure = failure
                }
                Thread.currentThread().interrupt()
                val interruption = IOException(
                    interruptionMessage(),
                    e
                )
                cleanupFailure?.let(interruption::addSuppressed)
                throw interruption
            }
            var releaseAcquiredResources = false
            val result = synchronized(lock) {
                if (closed || held) {
                    releaseAcquiredResources = true
                    held && !closed
                } else {
                    held = true
                    connectionGateHeld = gateAcquired
                    memoryBudget.recordParseBudgetAcquired(permits, false)
                    registerBorrowableLease()
                    true
                }
            }
            if (releaseAcquiredResources) releaseResources(true, gateAcquired, false)
            return result
        }

        /**
         * Raises this held lease's process reservation to [requiredPermits] in total, admitting only
         * the delta and only through the same size-aware scheduler, flagged as a continuation — the
         * scheduler's existing mechanism for a reservation that already retains bytes and has to
         * finish (see [SizeAwareReservationScheduler]).
         *
         * Only the sequential attachment-frame reader grows a lease, and only while it holds
         * [MemoryBudget.growableAttachmentFrameTurn], so at most one lease per process ever holds
         * pool bytes while waiting for more. Every other holder of pool bytes acquires once and
         * releases without asking for more, so this delta is always eventually granted and the
         * hold-and-wait deadlock two concurrently growing frames could form cannot arise.
         *
         * Throws [IOException] with the interrupted status preserved if the wait is interrupted, and
         * if the lease was released while the delta was queued. Either way it returns exactly what
         * it acquired and nothing else: permits already held stay with the lease and are returned by
         * [release]/[close] as usual.
         */
        internal fun growTo(requiredPermits: Int) {
            require(requiredPermits in 1..MAX_CONCURRENT_PARSE_BYTES) {
                "Attachment-memory lease permits must be between 1 and " +
                    "$MAX_CONCURRENT_PARSE_BYTES, but were $requiredPermits"
            }
            // A lease that is no longer held has been torn down from outside — the stall or
            // absolute-deadline watchdog force-releases it and closes the stream between bodies —
            // so this is an IOException the frame reader converts into the guard's own diagnostic,
            // never an IllegalStateException that would escape that translation.
            val heldBeforeGrowth = synchronized(lock) {
                if (!held || closed) null else permits
            } ?: throw IOException(
                "The inbound attachment-memory lease was released before growing it to " +
                    "$requiredPermits bytes (concurrencyBudget=$MAX_CONCURRENT_PARSE_BYTES)"
            )
            val additionalPermits = requiredPermits - heldBeforeGrowth
            if (additionalPermits <= 0) return
            val finished = java.util.concurrent.CountDownLatch(1)
            val reservation = memoryBudget.parseMemoryBudget.newReservation(
                additionalPermits, continuation = true
            ) { finished.countDown() }
            val growth = PendingGrowth(reservation, finished)
            val registered = synchronized(lock) {
                if (!held || closed) false else {
                    check(pendingGrowth == null) { "An attachment-memory lease already has queued growth" }
                    pendingGrowth = growth
                    true
                }
            }
            var growthKept = false
            try {
                if (registered) {
                    // Close can cancel between registration and enqueue. The scheduler does not
                    // enqueue cancelled reservations, and close also wakes this reader's latch.
                    memoryBudget.parseMemoryBudget.enqueue(reservation)
                    finished.await()
                    growthKept = synchronized(lock) {
                        if (held && !closed && !reservation.isCancelled()) {
                            permits += additionalPermits
                            // Publish the charge with the new held total. Close must never subtract
                            // a delta whose acquisition has not yet been recorded.
                            memoryBudget.recordParseBudgetAcquired(additionalPermits, false)
                            true
                        } else false
                    }
                }
                if (!growthKept) {
                    throw IOException(
                        "The inbound attachment-memory lease was released while growing it to " +
                            "$requiredPermits bytes (heldPermits=$heldBeforeGrowth, " +
                            "concurrencyBudget=$MAX_CONCURRENT_PARSE_BYTES)"
                    )
                }
            } catch (interruption: InterruptedException) {
                Thread.currentThread().interrupt()
                throw IOException(
                    "Interrupted while growing the inbound attachment-memory lease " +
                        "(heldPermits=$heldBeforeGrowth, requiredPermits=$requiredPermits, " +
                        "concurrencyBudget=$MAX_CONCURRENT_PARSE_BYTES)",
                    interruption
                )
            } finally {
                synchronized(lock) {
                    if (pendingGrowth === growth) pendingGrowth = null
                }
                // The reader alone returns an unclaimed grant. Close only cancels/wakes; if a
                // grant beat cancellation, this path returns its delta exactly once.
                if (!growthKept && !memoryBudget.parseMemoryBudget.cancel(reservation) &&
                    !reservation.isCancelled()
                ) {
                    memoryBudget.parseMemoryBudget.release(additionalPermits)
                }
            }
        }

        /**
         * Acquires the connection turn and fixed process reservation through callback queues.
         * Neither wait occupies a platform thread. Same-connection followers remain in
         * [AttachmentFrameTurn]'s queue, while independent fitting reservations can proceed through
         * the process-wide size-aware scheduler.
         */
        internal fun acquireAsync(
            onComplete: (Boolean, Throwable?) -> Unit
        ) {
            var admissionToStart: PendingAdmission? = null
            var immediateResult: AdmissionResult? = null
            synchronized(lock) {
                when {
                    closed -> immediateResult = AdmissionResult(false, null)
                    held -> immediateResult = AdmissionResult(true, null)
                    pendingAdmission != null -> {
                        val pending = pendingAdmission!!
                        check(pending.callback == null) {
                            "Attachment lease already has an async admission callback"
                        }
                        pending.callback = onComplete
                        pending.result?.let {
                            immediateResult = it
                            pending.callback = null
                        }
                    }
                    else -> {
                        val pending = PendingAdmission(onComplete)
                        pendingAdmission = pending
                        admissionToStart = pending
                    }
                }
            }
            immediateResult?.let { invokeCompletion(onComplete, it) }
            admissionToStart?.let(::startAsyncAdmission)
        }

        private fun startAsyncAdmission(admission: PendingAdmission) {
            val gate = checkNotNull(connectionGate) {
                "Async attachment admission requires a physical-connection turn"
            }
            lateinit var waiter: AttachmentFrameTurn.Waiter
            waiter = gate.newWaiter {
                onTurnGranted(admission, waiter)
            }
            val shouldRegister = synchronized(lock) {
                if (pendingAdmission === admission && !closed) {
                    admission.gateWaiter = waiter
                    true
                } else {
                    false
                }
            }
            if (!shouldRegister) return

            if (!gate.tryAcquireOrEnqueue(waiter)) return

            val shouldRequestBudget = synchronized(lock) {
                if (pendingAdmission === admission && !closed && admission.gateWaiter === waiter) {
                    admission.gateWaiter = null
                    connectionGateHeld = true
                    true
                } else {
                    false
                }
            }
            if (shouldRequestBudget) {
                beginBudgetAdmission(admission)
            } else {
                var cleanupFailure: Throwable? = null
                try {
                    releaseResources(false, true)
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
                try {
                    finishAdmission(admission, AdmissionResult(false, null))
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
                cleanupFailure?.let { throw it }
            }
        }

        private fun onTurnGranted(
            admission: PendingAdmission,
            waiter: AttachmentFrameTurn.Waiter
        ) {
            val shouldRequestBudget = synchronized(lock) {
                if (pendingAdmission === admission && !closed && admission.gateWaiter === waiter) {
                    admission.gateWaiter = null
                    connectionGateHeld = true
                    true
                } else {
                    if (admission.gateWaiter === waiter) admission.gateWaiter = null
                    false
                }
            }
            if (shouldRequestBudget) {
                beginBudgetAdmission(admission)
            } else {
                var cleanupFailure: Throwable? = null
                try {
                    releaseResources(false, true)
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
                try {
                    finishAdmission(admission, AdmissionResult(false, null))
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
                cleanupFailure?.let { throw it }
            }
        }

        private fun beginBudgetAdmission(admission: PendingAdmission) {
            if (memoryBudget.parseMemoryBudget.tryAcquire(permits)) {
                completeBudgetAdmission(admission, null)
                return
            }

            lateinit var reservation: SizeAwareReservationScheduler.Reservation
            reservation = memoryBudget.parseMemoryBudget.newReservation(permits) {
                completeBudgetAdmission(admission, reservation)
            }
            val shouldEnqueue = synchronized(lock) {
                if (pendingAdmission === admission && !closed && connectionGateHeld) {
                    admission.budgetReservation = reservation
                    true
                } else {
                    false
                }
            }
            if (shouldEnqueue) {
                memoryBudget.parseMemoryBudget.enqueue(reservation)
            } else {
                var releaseConnectionTurn = false
                synchronized(lock) {
                    if (pendingAdmission === admission && connectionGateHeld) {
                        connectionGateHeld = false
                        releaseConnectionTurn = true
                    }
                }
                var cleanupFailure: Throwable? = null
                if (releaseConnectionTurn) {
                    try {
                        releaseResources(false, true)
                    } catch (failure: Throwable) {
                        cleanupFailure = mergeFailure(cleanupFailure, failure)
                    }
                }
                try {
                    finishAdmission(admission, AdmissionResult(false, null))
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
                cleanupFailure?.let { throw it }
            }
        }

        private fun mergeFailure(first: Throwable?, next: Throwable): Throwable {
            if (first == null) return next
            first.addSuppressed(next)
            return first
        }

        private fun completeBudgetAdmission(
            admission: PendingAdmission,
            reservation: SizeAwareReservationScheduler.Reservation?
        ) {
            var releasePermits = false
            var releaseConnectionTurn = false
            val result = synchronized(lock) {
                val ownsAdmission = pendingAdmission === admission &&
                    (reservation == null || admission.budgetReservation === reservation)
                if (ownsAdmission && !closed && !held) {
                    admission.budgetReservation = null
                    held = true
                    memoryBudget.recordParseBudgetAcquired(permits, false)
                    registerBorrowableLease()
                    pendingAdmission = null
                    AdmissionResult(true, null)
                } else {
                    releasePermits = true
                    if (ownsAdmission) {
                        admission.budgetReservation = null
                        pendingAdmission = null
                    }
                    if (connectionGateHeld) {
                        connectionGateHeld = false
                        releaseConnectionTurn = true
                    }
                    AdmissionResult(false, null)
                }
            }
            var cleanupFailure: Throwable? = null
            if (releasePermits || releaseConnectionTurn) {
                try {
                    releaseResources(releasePermits, releaseConnectionTurn, false)
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
            }
            try {
                finishAdmission(admission, result)
            } catch (failure: Throwable) {
                cleanupFailure = mergeFailure(cleanupFailure, failure)
            }
            cleanupFailure?.let { throw it }
        }

        private fun finishAdmission(admission: PendingAdmission, result: AdmissionResult) {
            val callback = synchronized(lock) {
                if (admission.result != null) return@synchronized null
                admission.result = result
                if (pendingAdmission === admission) pendingAdmission = null
                admission.gateWaiter = null
                admission.budgetReservation = null
                admission.callback.also { admission.callback = null }
            }
            callback?.let { invokeCompletion(it, result) }
        }

        private fun invokeCompletion(
            callback: (Boolean, Throwable?) -> Unit,
            result: AdmissionResult
        ) {
            try {
                callback(result.admitted, result.failure)
            } catch (failure: Throwable) {
                if (result.admitted) {
                    try {
                        close()
                    } catch (cleanupFailure: Throwable) {
                        failure.addSuppressed(cleanupFailure)
                    }
                }
                throw failure
            }
        }

        /**
         * Non-blocking acquire for the Netty event loop. The connection turn remains FIFO. The
         * process scheduler may let this fitting reservation bypass an older non-fitting request,
         * subject to its bounded-bypass guarantee.
         */
        fun tryAcquire(): Boolean {
            val gate = connectionGate
            if (gate == null) {
                synchronized(lock) {
                    if (closed) return false
                    if (held) return true
                    check(pendingAdmission == null) {
                        "Attachment lease already has an async admission pending"
                    }
                }
                if (!memoryBudget.parseMemoryBudget.tryAcquire(permits)) return false
                var releaseAcquiredResources = false
                val result = synchronized(lock) {
                    if (closed || held) {
                        releaseAcquiredResources = true
                        held && !closed
                    } else {
                        held = true
                        memoryBudget.recordParseBudgetAcquired(permits, false)
                        registerBorrowableLease()
                        true
                    }
                }
                if (releaseAcquiredResources) releaseResources(true, false, false)
                return result
            }

            val admission = PendingAdmission(null)
            synchronized(lock) {
                if (closed) return false
                if (held) return true
                if (pendingAdmission != null) return false
                pendingAdmission = admission
            }
            startAsyncAdmission(admission)
            return synchronized(lock) {
                admission.result?.admitted == true
            }
        }

        /** Releases [permits] and the physical-connection turn, attempting both even if one fails. */
        private fun releaseResources(
            releasePermits: Boolean,
            releaseConnectionTurn: Boolean,
            accountedPermits: Boolean = true,
            permitCount: Int = permits
        ) {
            var firstFailure: Throwable? = null
            if (releasePermits) {
                try {
                    if (accountedPermits) {
                        memoryBudget.releaseAccountedParseBudget(permitCount)
                    } else {
                        memoryBudget.parseMemoryBudget.release(permitCount)
                    }
                } catch (failure: Throwable) {
                    firstFailure = failure
                }
            }
            if (releaseConnectionTurn) {
                try {
                    connectionGate!!.release()
                } catch (failure: Throwable) {
                    if (firstFailure == null) firstFailure = failure
                    else firstFailure!!.addSuppressed(failure)
                }
            }
            firstFailure?.let { throw it }
        }

        /**
         * Transfers a completed decoder frame with only its actual retained-byte reservation.
         * The decoder owns this call on its event loop until the returned owner is published.
         * Existing loans receive their own pool permits; pending loans see the removed lease and
         * resume without a grant. Return all other unused permits before handing off the frame.
         */
        internal fun retainMemoryAfterFrame(retainedBytes: Long): AutoCloseable {
            val owner = AutoCloseable { close() }
            var releaseTurn = false
            val unusedPermits = synchronized(lock) {
                check(held && !closed && closingThread == null && pendingAdmission == null) {
                    "Decoded attachment memory can transfer only from a held, fully admitted frame"
                }
                val unused = synchronized(memoryBudget.borrowLock) {
                    val retained = retainedBytes.coerceIn(1L, permits.toLong()).toInt()
                    check(retained <= permits - borrowedBytes) {
                        "Decoded attachment charge of $retained bytes overlaps $borrowedBytes " +
                            "borrowed bytes in a $permits-byte reservation"
                    }
                    val remaining = unregisterBorrowableLease()
                    permits = retained
                    remaining - retained
                }
                releaseTurn = connectionGateHeld
                connectionGateHeld = false
                unused
            }
            // Admission callbacks may re-enter channel teardown. No lease or borrow monitor is
            // held here, and unused bytes are returned before a close callback can publish close.
            releaseResources(unusedPermits > 0, releaseTurn, permitCount = unusedPermits)
            return owner
        }

        /** Releases this frame's process reservation and connection turn. Idempotent. */
        fun release() {
            var releaseConnectionTurn = false
            val releasePermits = synchronized(lock) {
                if (held) {
                    held = false
                    if (connectionGateHeld) {
                        connectionGateHeld = false
                        releaseConnectionTurn = true
                    }
                    true
                } else {
                    false
                }
            }
            if (releasePermits || releaseConnectionTurn) {
                val permitsToRelease = if (releasePermits) unregisterBorrowableLease() else 0
                releaseResources(
                    releasePermits = permitsToRelease > 0,
                    releaseConnectionTurn = releaseConnectionTurn,
                    permitCount = permitsToRelease
                )
            }
        }

        /**
         * Permanently closes the lease and releases every held admission resource. Every caller
         * returns only after that release is complete: a caller that finds the lease already
         * closing waits for the closing caller's cleanup instead of returning while the lease's
         * bytes are still recorded. The closing thread itself (re-entering from a callback this
         * close runs) returns at once.
         */
        fun close() {
            if (!beginClose()) {
                awaitCloseFinished()
                return
            }
            try {
                closeOnce()
            } finally {
                closeFinished.countDown()
            }
        }

        private val closeFinished = java.util.concurrent.CountDownLatch(1)
        @Volatile private var closingThread: Thread? = null

        private fun beginClose(): Boolean = synchronized(lock) {
            if (closingThread == null && !closed) {
                closingThread = Thread.currentThread()
                true
            } else {
                false
            }
        }

        private fun awaitCloseFinished() {
            if (closingThread === Thread.currentThread()) return
            var interrupted = false
            while (true) {
                try {
                    closeFinished.await()
                    break
                } catch (_: InterruptedException) {
                    interrupted = true
                }
            }
            if (interrupted) Thread.currentThread().interrupt()
        }

        private fun closeOnce() {
            var growthAtClose: PendingGrowth? = null
            var admissionAtClose: PendingAdmission? = null
            var waiterAtClose: AttachmentFrameTurn.Waiter? = null
            var budgetReservationAtClose: SizeAwareReservationScheduler.Reservation? = null
            var releaseHeldPermits = false
            var releaseHeldConnectionTurn = false
            var releasePendingConnectionTurn = false
            synchronized(lock) {
                if (closed) return
                closed = true
                admissionAtClose = pendingAdmission
                growthAtClose = pendingGrowth
                waiterAtClose = admissionAtClose?.gateWaiter
                budgetReservationAtClose = admissionAtClose?.budgetReservation
                if (held) {
                    held = false
                    if (connectionGateHeld) {
                        connectionGateHeld = false
                        releaseHeldConnectionTurn = true
                    }
                    releaseHeldPermits = true
                } else if (admissionAtClose != null &&
                    waiterAtClose == null &&
                    budgetReservationAtClose == null &&
                    connectionGateHeld
                ) {
                    connectionGateHeld = false
                    releasePendingConnectionTurn = true
                }
            }

            val growthToCancel = growthAtClose
            val admission = admissionAtClose
            val waiterToCancel = waiterAtClose
            val budgetReservationToCancel = budgetReservationAtClose
            var cleanupFailure: Throwable? = null
            if (growthToCancel != null) {
                try {
                    memoryBudget.parseMemoryBudget.cancel(growthToCancel.reservation)
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                } finally {
                    growthToCancel.finished.countDown()
                }
            }
            var finishAdmission = false
            if (budgetReservationToCancel != null) {
                var cancelled = false
                try {
                    cancelled = memoryBudget.parseMemoryBudget.cancel(budgetReservationToCancel)
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                    cancelled = budgetReservationToCancel.isCancelled()
                }
                if (cancelled) {
                    var releaseConnectionTurn = false
                    synchronized(lock) {
                        if (admission != null && pendingAdmission === admission &&
                            admission.budgetReservation === budgetReservationToCancel
                        ) {
                            admission.budgetReservation = null
                            pendingAdmission = null
                            if (connectionGateHeld) {
                                connectionGateHeld = false
                                releaseConnectionTurn = true
                            }
                        }
                    }
                    if (releaseConnectionTurn) {
                        try {
                            releaseResources(false, true)
                        } catch (failure: Throwable) {
                            cleanupFailure = mergeFailure(cleanupFailure, failure)
                        }
                    }
                    finishAdmission = admission != null
                }
            } else if (waiterToCancel != null && connectionGate!!.cancel(waiterToCancel)) {
                synchronized(lock) {
                    if (admission != null && pendingAdmission === admission &&
                        admission.gateWaiter === waiterToCancel
                    ) {
                        admission.gateWaiter = null
                        pendingAdmission = null
                    }
                }
                finishAdmission = admission != null
            }
            if (releasePendingConnectionTurn) {
                try {
                    releaseResources(false, true)
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
            }
            if (releasePendingConnectionTurn) finishAdmission = admission != null
            if (releaseHeldPermits || releaseHeldConnectionTurn) {
                try {
                    val permitsToRelease = if (releaseHeldPermits) unregisterBorrowableLease() else 0
                    releaseResources(
                        releasePermits = permitsToRelease > 0,
                        releaseConnectionTurn = releaseHeldConnectionTurn,
                        permitCount = permitsToRelease
                    )
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
            }
            if (finishAdmission && admission != null) {
                try {
                    finishAdmission(admission, AdmissionResult(false, null))
                } catch (failure: Throwable) {
                    cleanupFailure = mergeFailure(cleanupFailure, failure)
                }
            }
            // Only the close that changed closed from false to true reaches this point. Return
            // the turn after pool cleanup, before any input.close callback or blocked read must
            // return. A later reader finally is an idempotent close, never another turn release.
            if (ownsGrowingFrameTurn) memoryBudget.growableAttachmentFrameTurn.release()
            cleanupFailure?.let { throw it }
        }

        private fun interruptionMessage(): String =
            if (preserveWholePoolInterruptionMessage) {
                "Interrupted while waiting for the inbound attachment-memory lease " +
                    "(wholePoolPermits=$MAX_CONCURRENT_PARSE_BYTES)"
            } else {
                "Interrupted while waiting for the inbound attachment-memory lease " +
                    "(requestedPermits=$permits, concurrencyBudget=$MAX_CONCURRENT_PARSE_BYTES)"
            }
    }

    /**
     * The parse reservation a transport-owned reader takes for one JSON body. The reader hands it
     * to its transport before asking for pool admission, so the transport's close can close it
     * directly: once that close returns, the reservation is no longer recorded, and an admission
     * granted after the close gives its permits back unrecorded instead of recording them.
     * [close] releases under the reservation's own lock, so every caller of close returns only
     * after the release is complete.
     */
    internal class JsonFrameReservation internal constructor(
        private val memoryBudget: MemoryBudget,
        private val frameBytes: Int,
    ) : AutoCloseable {
        private val permits = parseBudgetPermits(frameBytes)
        private val lock = Any()
        private var held = false
        private var closed = false

        /**
         * Waits for pool admission and records it. Returns false, with nothing recorded and no
         * permits kept, when [close] ran first or ran while the admission was being granted.
         */
        fun acquire(): Boolean {
            synchronized(lock) {
                if (closed) return false
            }
            val worstCaseParseBytes = frameBytes.toLong().coerceAtLeast(1L) * PARSE_AMPLIFICATION.toLong()
            val contended = memoryBudget.parseMemoryBudget.isContended(permits)
            try {
                memoryBudget.parseMemoryBudget.acquire(permits)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                throw IOException(
                    "Interrupted while waiting for inbound parse-memory budget " +
                        "(frameBytes=$frameBytes, worstCaseParseBytes=$worstCaseParseBytes, " +
                        "parseAmplification=${PARSE_AMPLIFICATION}x, totalBudget=$MAX_CONCURRENT_PARSE_BYTES)",
                    e
                )
            }
            val recorded = synchronized(lock) {
                if (closed) {
                    false
                } else {
                    memoryBudget.recordParseBudgetAcquired(permits, contended)
                    held = true
                    true
                }
            }
            if (!recorded) memoryBudget.parseMemoryBudget.release(permits)
            return recorded
        }

        override fun close() {
            synchronized(lock) {
                if (closed) return
                closed = true
                if (held) {
                    held = false
                    memoryBudget.releaseAccountedParseBudget(permits)
                }
            }
        }
    }

    private fun jsonReservationClosed(frameBytes: Int): IOException = IOException(
        "The stream reading an inbound JSON frame (frameBytes=$frameBytes) was closed before " +
            "the frame's parse-memory reservation was admitted; the frame body was discarded unparsed"
    )

    private fun discardFully(input: InputStream, length: Int) {
        val scratch = ByteArray(minOf(length, 8192))
        var remaining = length
        while (remaining > 0) {
            val count = input.read(scratch, 0, minOf(remaining, scratch.size))
            if (count < 0) throw java.io.EOFException("Stream ended with $remaining of $length discarded JSON body bytes unread")
            remaining -= count
        }
    }

    /**
     * A frame-scoped reservation for one inbound JSON body. Netty decoders acquire it after the
     * length header and before accepting the body, then transfer ownership with the decoded frame
     * so parsing and peer-exchange admission remain covered by the same process-wide pool.
     */
    internal class FrameParseLease(
        val frameBytes: Int,
        private val physicalConnection: Any,
    ) {
        private val permits = parseBudgetPermits(frameBytes)
        private val lock = Any()
        private var held = false
        private var closed = false
        private var contentionRecorded = false
        private var borrowedCapacity: FrameAttachmentLease.BorrowedCapacity? = null

        val isHeld: Boolean get() = synchronized(lock) { held }

        fun tryAcquire(): Boolean {
            synchronized(lock) {
                if (closed) return false
                if (held) return true
            }
            // Idle pool capacity first: when nothing is reserved ahead of this frame there is no
            // reason to divert it off the event loop, and no reason to pause an unrelated
            // attachment transfer's reads to borrow. Take only UNCONTENDED capacity, though — a
            // bypassing acquire would spend a blocked head's bounded bypass budget, which exists
            // for the fitting ATTACHMENT frames that have no borrowing alternative. When the pool
            // is contended this frame falls to the blocking acquire below, which can pause an
            // attachment decoder and sublease its declared-but-unarrived headroom instead.
            if (!parseMemoryBudget.tryAcquireUncontended(permits)) {
                recordContentionOnce()
                return false
            }
            synchronized(lock) {
                if (closed || held) {
                    parseMemoryBudget.release(permits)
                    return held && !closed
                }
                held = true
                recordParseBudgetAcquired(permits, false)
                return true
            }
        }

        fun acquire(): Boolean {
            synchronized(lock) {
                if (closed) return false
                if (held) return true
            }
            // Idle pool capacity first, for the same reasons as the fast path above: borrowing
            // pauses an unrelated attachment transfer's reads, so it must never pre-empt capacity
            // the pool can supply outright — and taking it must not spend the bypass budget an
            // attachment frame would need. (This retries because the pool may have drained between
            // the refused fast path and this off-event-loop attempt.)
            if (parseMemoryBudget.tryAcquireUncontended(permits)) {
                synchronized(lock) {
                    if (closed || held) {
                        parseMemoryBudget.release(permits)
                        return held && !closed
                    }
                    held = true
                    recordParseBudgetAcquired(permits, false)
                    return true
                }
            }
            // The pool refused these permits: this frame is genuinely contending for the pool, and
            // only now is pausing an attachment transfer the cheaper option.
            recordContentionOnce()

            // Borrow only what an in-flight attachment frame declared but has not received. That
            // capacity is reserved, not retained, so lending it lets JSON make progress while the
            // pool is exhausted by reservations that hold no bytes yet.
            val borrowed = FrameAttachmentLease.borrowUnusedCapacity(permits, physicalConnection)
            if (borrowed != null) {
                synchronized(lock) {
                    if (closed || held) {
                        borrowed.release()
                        return held && !closed
                    }
                    held = true
                    borrowedCapacity = borrowed
                    recordBorrowedParseBudgetAcquired()
                    return true
                }
            }
            try {
                parseMemoryBudget.acquire(permits)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                throw IOException(
                    "Interrupted while waiting for an inbound JSON frame parse-memory lease " +
                        "(reservedBytes=$permits, totalBudget=$MAX_CONCURRENT_PARSE_BYTES)",
                    e
                )
            }
            synchronized(lock) {
                if (closed || held) {
                    parseMemoryBudget.release(permits)
                    return held && !closed
                }
                held = true
                recordParseBudgetAcquired(permits, false)
                return true
            }
        }

        private fun recordContentionOnce() {
            val shouldRecord = synchronized(lock) {
                if (closed || held || contentionRecorded) {
                    false
                } else {
                    contentionRecorded = true
                    true
                }
            }
            if (shouldRecord) recordParseBudgetContention()
        }

        fun close() {
            val borrowed = synchronized(lock) {
                closed = true
                if (!held) return
                held = false
                borrowedCapacity.also { borrowedCapacity = null }
            }
            if (borrowed != null) {
                borrowed.release()
            } else {
                releaseAccountedParseBudget(permits)
            }
        }
    }

    /**
     * The exact diagnostic for an RPC v1.1 frame whose declared attachment count differs from
     * the number of binary references in its JSON envelope. Shared verbatim by the InputStream
     * reader ([readMessageFrameFromStream], as an [IOException]) and the Netty decoder
     * (as a CorruptedFrameException) so consumers observe one stable message.
     */
    fun attachmentCountMismatchMessage(declaredAttachmentCount: Int, binaryReferenceCount: Int): String =
        "RPC binary attachment count does not match the JSON envelope: " +
            "declaredAttachmentCount=$declaredAttachmentCount, binaryReferenceCount=$binaryReferenceCount"

    /**
     * The exact diagnostic for an RPC v1.1 frame whose declared attachment bytes exceed
     * [MAX_ATTACHMENT_AGGREGATE_BYTES]. [declaredAttachmentBytes] is the running declared
     * total at the offending length header — the check fires before that attachment's body is
     * allocated. Shared verbatim by both decode paths, like [attachmentCountMismatchMessage].
     */
    fun attachmentAggregateLimitMessage(declaredAttachmentBytes: Long, attachmentCount: Int): String =
        "Inbound RPC binary attachments exceed the single-frame aggregate limit: " +
            "declaredAttachmentBytes=$declaredAttachmentBytes, " +
            "maxAttachmentBytes=$MAX_ATTACHMENT_AGGREGATE_BYTES, attachmentCount=$attachmentCount, " +
            "concurrencyBudget=$MAX_CONCURRENT_PARSE_BYTES"

    /**
     * Validates that the `binary_ref` markers in [json] reference exactly the attachment indices
     * `0 until declaredAttachmentCount` as a BIJECTION: every declared attachment is referenced
     * exactly once, and no reference is a duplicate, hole, negative, or out-of-range index. A
     * plain count match is insufficient — two markers both at `__index: 0` with a declared count
     * of 2 would satisfy a count check while leaving attachment 1 buffered but unreferenced (and
     * attachment 0 double-referenced). Called by BOTH decode paths after the count check and
     * before any attachment header/body is read, so a bijection violation is declined without
     * buffering any declared byte. Throws [IOException] with a descriptive diagnostic naming the
     * declared count and the offending index multiset on any violation.
     *
     * Assumes [countBinaryRefs]`(json) == declaredAttachmentCount` (the count check runs first);
     * this method additionally constrains the index VALUES, which the count does not.
     */
    fun validateBinaryRefIndices(json: JSONObject, declaredAttachmentCount: Int) {
        // Each entry is the RAW __index value verbatim (Int/Long/Double/String/null), so a
        // non-integer or overflowing index is reported literally and never coerced. Any single
        // malformed reference fails the whole frame with the raw offending value named.
        val rawIndices = ArrayList<Any?>(declaredAttachmentCount)
        collectBinaryRefRawIndices(json, rawIndices)

        val seen = BooleanArray(declaredAttachmentCount)
        var offendingRaw: Any? = null
        var offending = false
        for (raw in rawIndices) {
            val index = strictIntIndexOrNull(raw)
            if (index == null || index < 0 || index >= declaredAttachmentCount || seen[index]) {
                offending = true
                offendingRaw = raw
                break
            }
            seen[index] = true
        }
        if (offending || rawIndices.size != declaredAttachmentCount) {
            val rendered = if (offending) renderRawIndex(offendingRaw) else "<count mismatch>"
            throw IOException(
                "RPC binary attachment references are not a bijection with the declared " +
                    "attachments: declaredAttachmentCount=$declaredAttachmentCount, " +
                    "referencedIndices=${rawIndices.map { renderRawIndex(it) }}, " +
                    "offendingIndex=$rendered (each of 0..${declaredAttachmentCount - 1} must be " +
                    "referenced exactly once by an integer __index, with no duplicate, missing, " +
                    "non-integer, negative, or out-of-range value)"
            )
        }
    }

    /**
     * Interprets a raw JSON `__index` value as an exact, non-coerced [Int] in `0..Int.MAX_VALUE`,
     * or null if it is not a mathematically-integral value exactly representable as an Int:
     * rejects strings, fractional/NaN/infinite doubles, and any integer outside the Int range
     * (no `Number.intValue()` truncation or wraparound). org.json parses JSON numbers as Integer,
     * Long, Double, or BigInteger/BigDecimal; each is checked without lossy conversion.
     */
    private fun strictIntIndexOrNull(raw: Any?): Int? = when (raw) {
        is Int -> raw
        is Long -> if (raw in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) raw.toInt() else null
        is java.math.BigInteger ->
            if (raw.bitLength() < 32) raw.toInt() else null // fits a signed Int only if <32 bits
        is java.math.BigDecimal ->
            try { strictIntIndexOrNull(raw.intValueExact()) } catch (_: ArithmeticException) { null }
        is Double ->
            if (raw.isFinite() && raw == Math.floor(raw) &&
                raw >= Int.MIN_VALUE.toDouble() && raw <= Int.MAX_VALUE.toDouble()
            ) raw.toInt() else null
        is Float -> strictIntIndexOrNull(raw.toDouble())
        else -> null // String, Boolean, null, JSONObject, etc. are never a valid index
    }

    private fun renderRawIndex(raw: Any?): String = when (raw) {
        null -> "<missing>"
        is String -> "\"$raw\""
        else -> raw.toString()
    }

    private fun collectBinaryRefRawIndices(json: JSONObject, out: MutableList<Any?>) {
        for (key in json.keys()) {
            collectBinaryRefRawIndicesInValue(json.opt(key), out)
        }
    }

    private fun collectBinaryRefRawIndicesInValue(value: Any?, out: MutableList<Any?>) {
        when {
            value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BINARY_REF_TYPE_MARKER -> {
                // Capture the raw __index verbatim (JSONObject.NULL / absent -> null) so the
                // strict validator sees exactly what was on the wire.
                val rawIndex = value.opt(BINARY_REF_INDEX_KEY)
                out.add(if (rawIndex == JSONObject.NULL) null else rawIndex)
            }
            value is JSONObject -> collectBinaryRefRawIndices(value, out)
            value is JSONArray -> {
                for (i in 0 until value.length()) {
                    collectBinaryRefRawIndicesInValue(value.opt(i), out)
                }
            }
        }
    }

    /**
     * Reserves the worst-case transient parse footprint for a body of [bytes] wire bytes,
     * blocking until that budget is available. Estimates at or above the concurrency pool reserve
     * the whole pool, making that parse exclusive. Returns the number of permits actually reserved
     * — pass it back to [releaseParseBudget] in a `finally`. The independent
     * [MAX_JSON_FRAME_BYTES] limit rejects frames that are not safe to parse alone. If the waiter
     * is interrupted before acquisition, no permits are held and an [IOException] is thrown. Used
     * by the deadline-bounded readers (Libp2pHostFactory, RelayService) that allocate the body
     * themselves; the [InputStream] readers use [readBoundedJsonBody].
     */
    private fun parseBudgetPermits(bytes: Int): Int {
        // Long arithmetic is deliberate: an untrusted Int frame length multiplied by seven
        // exceeds Int.MAX_VALUE. PARSE_AMPLIFICATION is integral today, so this multiplication
        // is exactly ceil(bytes * amplification) without floating-point rounding risk.
        val worstCaseParseBytes = bytes.toLong().coerceAtLeast(1L) * PARSE_AMPLIFICATION.toLong()
        if (bytes <= 0) {
            throw IOException("Invalid message length: $bytes")
        }
        if (bytes > MAX_JSON_FRAME_BYTES) throw singleFrameLimitException(bytes, worstCaseParseBytes)
        return worstCaseParseBytes.coerceAtMost(MAX_CONCURRENT_PARSE_BYTES.toLong()).toInt()
    }

    fun acquireParseBudget(bytes: Int): Int = acquireParseBudget(bytes, processWideMemoryBudget)

    /**
     * The exact diagnostic for an inbound frame whose parse-memory reservation was still queued
     * when the reading caller's own deadline passed. Names the reservation that could not be
     * admitted and the process-wide budget it was queued against, so an operator reading one
     * failure can tell inbound admission contention apart from a slow or unreachable peer.
     */
    fun parseBudgetDeadlineMessage(frameBytes: Int, reservedPermits: Int): String =
        "Inbound parse-memory budget did not become available before the reading caller's " +
            "deadline: frameBytes=$frameBytes, " +
            "worstCaseParseBytes=${frameBytes.toLong().coerceAtLeast(1L) * PARSE_AMPLIFICATION}, " +
            "parseAmplification=${PARSE_AMPLIFICATION}x, reservedPermits=$reservedPermits, " +
            "totalBudget=$MAX_CONCURRENT_PARSE_BYTES"

    /**
     * Reserves the worst-case transient parse footprint for a body of [bytes] wire bytes on behalf
     * of a reader that is already bounded by a deadline, waiting only until [deadlineMs] (a
     * `System.currentTimeMillis()` value). Returns the permits reserved — pass them back to
     * [releaseParseBudget] in a `finally` — or throws [ParseBudgetDeadlineExceededException] if the
     * reservation is still queued when the deadline passes, in which case NO permits are held.
     *
     * Deadline-bounded readers must use this rather than [acquireParseBudget]: the untimed form
     * waits for as long as the pool stays saturated, so a reader with a contract of "return within
     * T" silently blocked far past T and unwound only when some outer deadline fired, turning
     * inbound admission contention into an unexplained stall at the caller's outermost budget.
     */
    fun acquireParseBudgetByDeadline(bytes: Int, deadlineMs: Long): Int =
        checkNotNull(acquireParseBudgetByDeadline(bytes, deadlineMs, processWideMemoryBudget))

    /**
     * Uses [clock]'s millisecond domain for [deadlineMs]; the caller retains ownership of the clock.
     * An immediate grant reads time once without scheduling a task. Only a queued wait schedules
     * a wake, which is cancelled before returning. Absolute expiry is checked before subtracting
     * times, and a positive remaining interval is saturated when it exceeds [Long.MAX_VALUE].
     */
    fun acquireParseBudgetByDeadline(bytes: Int, deadlineMs: Long, clock: Clock): Int =
        checkNotNull(acquireParseBudgetByDeadline(bytes, deadlineMs, processWideMemoryBudget, clock))

    internal fun acquireParseBudgetUntilClosed(
        bytes: Int,
        deadlineMs: Long,
        clock: Clock,
        cancellation: ParseBudgetCancellation,
    ): Int? = acquireParseBudgetByDeadline(bytes, deadlineMs, processWideMemoryBudget, clock, cancellation)

    private fun acquireParseBudgetByDeadline(
        bytes: Int,
        deadlineMs: Long,
        memoryBudget: MemoryBudget,
        clock: Clock = SystemClock(),
        cancellation: ParseBudgetCancellation? = null,
    ): Int? {
        val permits = parseBudgetPermits(bytes)
        val worstCaseParseBytes =
            bytes.toLong().coerceAtLeast(1L) * PARSE_AMPLIFICATION.toLong()
        val contended = memoryBudget.parseMemoryBudget.isContended(permits)
        val granted = try {
            memoryBudget.parseMemoryBudget.acquireByDeadline(
                permits, deadlineMs, clock = clock, cancellation = cancellation,
            )
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            throw IOException(
                "Interrupted while waiting for inbound parse-memory budget " +
                    "(frameBytes=$bytes, worstCaseParseBytes=$worstCaseParseBytes, " +
                    "parseAmplification=${PARSE_AMPLIFICATION}x, totalBudget=$MAX_CONCURRENT_PARSE_BYTES)",
                e
            )
        }
        if (!granted) {
            if (cancellation?.isCancelled() == true) return null
            memoryBudget.recordDeadlineExpiration(bytes)
            throw ParseBudgetDeadlineExceededException(parseBudgetDeadlineMessage(bytes, permits))
        }
        memoryBudget.recordParseBudgetAcquired(permits, contended)
        return permits
    }

    internal fun parseBudgetAdmissionExpired(bytes: Int): ParseBudgetDeadlineExceededException {
        processWideMemoryBudget.recordDeadlineExpiration(bytes)
        return ParseBudgetDeadlineExceededException(parseBudgetDeadlineMessage(bytes, parseBudgetPermits(bytes)))
    }

    private fun acquireParseBudget(bytes: Int, memoryBudget: MemoryBudget): Int {
        val permits = parseBudgetPermits(bytes)
        val worstCaseParseBytes =
            bytes.toLong().coerceAtLeast(1L) * PARSE_AMPLIFICATION.toLong()
        val contended = memoryBudget.parseMemoryBudget.isContended(permits)
        try {
            memoryBudget.parseMemoryBudget.acquire(permits)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            throw IOException(
                "Interrupted while waiting for inbound parse-memory budget " +
                    "(frameBytes=$bytes, worstCaseParseBytes=$worstCaseParseBytes, " +
                    "parseAmplification=${PARSE_AMPLIFICATION}x, totalBudget=$MAX_CONCURRENT_PARSE_BYTES)",
                e
            )
        }
        memoryBudget.recordParseBudgetAcquired(permits, contended)
        return permits
    }

    private fun singleFrameLimitException(
        frameBytes: Int,
        worstCaseParseBytes: Long =
            frameBytes.toLong().coerceAtLeast(1L) * PARSE_AMPLIFICATION.toLong()
    ): IOException = IOException(
        "Inbound JSON frame exceeds the single-frame wire limit: " +
            "frameBytes=$frameBytes, maxFrameBytes=$MAX_JSON_FRAME_BYTES, " +
            "worstCaseParseBytes=$worstCaseParseBytes, " +
            "parseAmplification=${PARSE_AMPLIFICATION}x, " +
            "concurrencyBudget=$MAX_CONCURRENT_PARSE_BYTES"
    )

    /** Releases [permits] previously reserved by [acquireParseBudget]. */
    fun releaseParseBudget(permits: Int) {
        releaseAccountedParseBudget(permits)
    }

    /**
     * Reads a [length]-byte body from [input] and JSON-parses it while holding a
     * parse-memory reservation, so concurrent large-message reads can't exhaust the heap.
     * The reservation is taken BEFORE the body is allocated (so blocked readers don't pin
     * their `ByteArray`s either) and released after parsing.
     */
    fun readBoundedJsonBody(input: InputStream, length: Int): JSONObject {
        val permits = acquireParseBudget(length)
        try {
            val bodyBytes = ByteArray(length)
            readFully(input, bodyBytes)
            return parseValidatedJsonBody(bodyBytes)
        } finally {
            releaseParseBudget(permits)
        }
    }

    private val requestIdCounter = AtomicLong(0)

    /**
     * Generates a unique request ID.
     */
    fun nextRequestId(): String = "req-${requestIdCounter.incrementAndGet()}"

    /**
     * Represents an RPC request message.
     */
    data class RpcRequest(
        val id: String,
        val method: String,
        val params: Map<String, Any?> = emptyMap(),
        val metadata: Map<String, String> = emptyMap()
    ) {
        @JvmOverloads
        fun toJson(attachments: MutableList<ByteArray>? = null): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_REQUEST)
                put("id", id)
                put("method", method)
                put("params", encodeParamsForJson(params, attachments))
                put("metadata", JSONObject(metadata))
            }
        }

        companion object {
            @JvmOverloads
            fun fromJson(json: JSONObject, attachments: List<ByteArray> = emptyList()): RpcRequest {
                val params: MutableMap<String, Any?>
                val paramsObj = json.optJSONObject("params")
                if (paramsObj != null) {
                    params = decodeParamsFromJson(paramsObj, attachments)
                } else {
                    params = mutableMapOf()
                }

                return RpcRequest(
                    id = json.getString("id"),
                    method = json.getString("method"),
                    params = params,
                    metadata = parseMetadataMap(json)
                )
            }
        }
    }

    /**
     * Represents an RPC response message.
     */
    data class RpcResponse @JvmOverloads constructor(
        val id: String,
        val result: Any? = null,
        val error: RpcError? = null,
        /**
         * Additive, backward-compatible response-metadata channel — the mirror of
         * [RpcRequest.metadata]. A flat, generic `String -> String` map that consumers use
         * to piggyback out-of-band information on a response without changing the result
         * shape. UrlResolver attaches HierarchicalClock entries here (e.g. `clock-timestamp`
         * and `clock-receipts`) so a serving clock can stamp its response and ship coverage
         * receipts; the field itself imposes no schema on the keys or values.
         *
         * Wire form: serialized as an optional JSON object under the `"metadata"` key.
         * [toJson] OMITS the field entirely when the map is empty (so the wire form stays
         * byte-identical to the pre-metadata format for the common case, and pre-metadata
         * readers — or any relay that parses and re-serializes a response — never observe a
         * spurious field). [fromJson]/[fromJsonRaw] tolerate its absence, decoding a missing
         * field to an empty map. Purely additive: no protocol-version negotiation is needed.
         */
        val metadata: Map<String, String> = emptyMap()
    ) {
        @JvmOverloads
        fun toJson(attachments: MutableList<ByteArray>? = null): JSONObject {
            return toJson(attachments, RpcEncodingResources())
        }

        internal fun toJson(attachments: MutableList<ByteArray>?, resources: RpcEncodingResources): JSONObject =
            resources.guard(listOf(result, error?.data)) {
                JSONObject().apply {
                    put("type", TYPE_RESPONSE)
                    put("id", id)
                    if (error != null) {
                        put("error", error.toJson(resources))
                    } else {
                        put("result", encodeResultForJson(result, attachments, resources) ?: JSONObject.NULL)
                    }
                    // Omit when empty so old readers / re-serializing relays see the legacy shape.
                    if (metadata.isNotEmpty()) {
                        put("metadata", JSONObject(metadata))
                    }
                }
            }

        companion object {
            @JvmOverloads
            fun fromJson(json: JSONObject, attachments: List<ByteArray> = emptyList()): RpcResponse {
                val errorObj = json.optJSONObject("error")
                val error = if (errorObj != null) RpcError.fromJson(errorObj) else null

                return RpcResponse(
                    id = json.getString("id"),
                    result = if (error == null) decodeResultFromJson(json.opt("result"), attachments) else null,
                    error = error,
                    metadata = parseMetadataMap(json)
                )
            }

            /**
             * Parses an RPC response from JSON WITHOUT decoding the result field.
             *
             * The result is kept as its raw org.json representation (JSONObject, JSONArray,
             * String, Number, etc.) instead of being decoded into Kotlin Maps/Lists/ByteArrays.
             * This is critical for forwarding/proxy use cases where the response will be
             * re-serialized without ContainerNursery needing to understand its contents.
             *
             * Without this, forwarding a response containing a 2MB ByteArray causes:
             * 1. Base64 decode: 2.4MB String → 1.8MB ByteArray (unnecessary allocation)
             * 2. JSONObject → HashMap conversion (unnecessary allocation)
             * 3. Base64 re-encode: 1.8MB ByteArray → 2.4MB String (unnecessary allocation)
             * Total: ~6.6MB of unnecessary intermediate objects per ByteArray field.
             *
             * With raw mode, the org.json value passes through as-is: zero additional allocation.
             */
            fun fromJsonRaw(json: JSONObject): RpcResponse {
                val errorObj = json.optJSONObject("error")
                val error = if (errorObj != null) RpcError.fromJson(errorObj) else null

                return RpcResponse(
                    id = json.getString("id"),
                    result = if (error == null) json.opt("result") else null,
                    error = error,
                    metadata = parseMetadataMap(json)
                )
            }

            fun success(id: String, result: Any?): RpcResponse = RpcResponse(id, result, null)
            fun error(id: String, code: String, message: String): RpcResponse =
                RpcResponse(id, null, RpcError(code, message))
        }
    }

    /**
     * Represents an RPC error.
     */
    data class RpcError(
        val code: String,
        val message: String,
        val data: Any? = null
    ) {
        fun toJson(): JSONObject {
            return toJson(RpcEncodingResources())
        }

        internal fun toJson(resources: RpcEncodingResources): JSONObject =
            resources.guard(data) {
                JSONObject().apply {
                    put("code", code)
                    put("message", message)
                    if (data != null && data !is RpcTransportFailure) {
                        // The data sits inside the message and error objects, so it may add at most
                        // MAX_JSON_NESTING_DEPTH - 2 levels before every receiver refuses the message.
                        requireWireJsonDepth(
                            ERROR_DATA_ENCLOSING_JSON_DEPTH +
                                renderedJsonDepth(data, MAX_JSON_NESTING_DEPTH - ERROR_DATA_ENCLOSING_JSON_DEPTH),
                            "data value of an error",
                        )
                        put("data", data)
                    }
                }
            }

        companion object {
            fun fromJson(json: JSONObject): RpcError {
                return RpcError(
                    code = json.getString("code"),
                    message = json.optString("message", ""),
                    data = json.opt("data")
                )
            }
        }
    }

    /**
     * Represents an AlgebraicEffect being propagated over the network.
     */
    data class EffectRequest(
        val id: String,
        val effectType: String,
        val effectData: JSONObject,
        val isNotification: Boolean
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_EFFECT_REQUEST)
                put("id", id)
                put("effectType", effectType)
                put("effectData", effectData)
                put("isNotification", isNotification)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): EffectRequest {
                return EffectRequest(
                    id = json.getString("id"),
                    effectType = json.getString("effectType"),
                    effectData = json.optJSONObject("effectData") ?: JSONObject(),
                    isNotification = json.optBoolean("isNotification", false)
                )
            }
        }
    }

    /**
     * Represents a response to an AlgebraicEffect.
     */
    data class EffectResponse(
        val id: String,
        val handled: Boolean,
        val result: Any? = null,
        val error: String? = null
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_EFFECT_RESPONSE)
                put("id", id)
                put("handled", handled)
                if (result != null) {
                    put("result", result)
                }
                if (error != null) {
                    put("error", error)
                }
            }
        }

        companion object {
            fun fromJson(json: JSONObject): EffectResponse {
                return EffectResponse(
                    id = json.getString("id"),
                    handled = json.getBoolean("handled"),
                    result = json.opt("result"),
                    error = json.optString("error", null)
                )
            }
        }
    }

    /**
     * Represents an observable subscription request.
     */
    data class ObservableSubscribe(
        val id: String,
        val observableId: String
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_OBSERVABLE_SUBSCRIBE)
                put("id", id)
                put("observableId", observableId)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): ObservableSubscribe {
                return ObservableSubscribe(
                    id = json.getString("id"),
                    observableId = json.getString("observableId")
                )
            }
        }
    }

    /**
     * Represents an observable invalidation notification.
     */
    data class ObservableInvalidation(
        val observableId: String,
        val timestamp: Long
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_OBSERVABLE_INVALIDATION)
                put("observableId", observableId)
                put("timestamp", timestamp)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): ObservableInvalidation {
                return ObservableInvalidation(
                    observableId = json.getString("observableId"),
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            }
        }
    }

    /**
     * Represents an observable value update.
     */
    data class ObservableValue(
        val observableId: String,
        val value: Any?,
        val timestamp: Long
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_OBSERVABLE_VALUE)
                put("observableId", observableId)
                put("value", value ?: JSONObject.NULL)
                put("timestamp", timestamp)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): ObservableValue {
                return ObservableValue(
                    observableId = json.getString("observableId"),
                    // toJson() writes a null value as JSONObject.NULL. Reading it back with opt()
                    // alone would hand the subscriber that sentinel instead of a Kotlin null, so a
                    // published null reads as a non-null object. Only the null sentinel is
                    // translated here: toJson() writes the value raw with no matching encode step,
                    // so a non-null value must reach subscribers exactly as org.json parsed it.
                    value = json.opt("value").takeIf { it != JSONObject.NULL },
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            }
        }
    }

    /**
     * Parses a message from JSON.
     * Also handles gossip message types for unified protocol handling.
     */
    @JvmOverloads
    fun parseMessage(json: JSONObject, attachments: List<ByteArray> = emptyList()): Any {
        val message = when (val type = json.getString("type")) {
            TYPE_REQUEST -> RpcRequest.fromJson(json, attachments)
            TYPE_RESPONSE -> RpcResponse.fromJson(json, attachments)
            TYPE_EFFECT_REQUEST -> EffectRequest.fromJson(json)
            TYPE_EFFECT_RESPONSE -> EffectResponse.fromJson(json)
            TYPE_OBSERVABLE_SUBSCRIBE -> ObservableSubscribe.fromJson(json)
            TYPE_OBSERVABLE_INVALIDATION -> ObservableInvalidation.fromJson(json)
            TYPE_OBSERVABLE_VALUE -> ObservableValue.fromJson(json)
            TYPE_PING -> PingMessage
            TYPE_PONG -> PongMessage
            // Also handle gossip message types for unified protocol handling
            GossipProtocol.TYPE_SERVICE_ANNOUNCE -> GossipProtocol.ServiceAnnouncement.fromJson(json)
            GossipProtocol.TYPE_SERVICE_WITHDRAW -> GossipProtocol.ServiceWithdrawal.fromJson(json)
            GossipProtocol.TYPE_SERVICE_QUERY -> GossipProtocol.ServiceQuery.fromJson(json)
            GossipProtocol.TYPE_SERVICE_QUERY_RESPONSE -> GossipProtocol.ServiceQueryResponse.fromJson(json)
            GossipProtocol.TYPE_PEER_EXCHANGE -> GossipProtocol.PeerExchange.fromJson(json)
            GossipProtocol.TYPE_PEER_ANNOUNCE -> GossipProtocol.PeerAnnouncement.fromJson(json)
            GossipProtocol.TYPE_RELAY_ANNOUNCE -> RelayProtocol.RelayAnnouncement.fromJson(json)
            GossipProtocol.TYPE_RELAY_WITHDRAW -> RelayProtocol.RelayWithdrawal.fromJson(json)
            GossipProtocol.TYPE_TLD_RESOLVER_ANNOUNCE -> GossipProtocol.TldResolverAnnouncement.fromJson(json)
            GossipProtocol.TYPE_LINK_STATE_ADVERTISEMENT -> LinkStateAdvertisement.fromJson(json)
            else -> throw IllegalArgumentException("Unknown message type: $type")
        }
        validateLibp2pWithdrawalPeerId(message)
        return message
    }

    object PingMessage {
        fun toJson(): JSONObject = JSONObject().apply { put("type", TYPE_PING) }
    }

    object PongMessage {
        fun toJson(): JSONObject = JSONObject().apply { put("type", TYPE_PONG) }
    }

    // =========================================================================
    // BYTE ARRAY ENCODING
    // =========================================================================

    private const val BYTE_ARRAY_TYPE_KEY = "__type"
    private const val BYTE_ARRAY_VALUE_KEY = "__value"
    private const val BYTE_ARRAY_TYPE_MARKER = "bytes"
    private const val BINARY_REF_TYPE_MARKER = "binary_ref"
    private const val BINARY_REF_INDEX_KEY = "__index"

    /**
     * Encodes a value for JSON serialization, converting ByteArrays to
     * binary attachment references `{"__type": "binary_ref", "__index": N}`.
     *
     * The actual binary data is collected in [attachments] and sent as raw
     * bytes after the JSON frame, avoiding base64 encoding overhead.
     *
     * This is called automatically during RPC request/response serialization,
     * making ByteArray support transparent to callers.
     *
     * Its depth budget assumes the value sits directly inside its message object (one level below
     * the top), as a response result does: a value whose JSON would then nest deeper than
     * [MAX_JSON_NESTING_DEPTH] (counting that object and the object carrying each byte array) is
     * refused with an [IllegalArgumentException], because every receiver would refuse the message.
     * A caller that places the value deeper must use the overload taking `enclosingJsonDepth`.
     */
    @JvmOverloads
    fun encodeValueForJson(value: Any?, attachments: MutableList<ByteArray>? = null): Any? =
        encodeValueForJson(value, attachments, RESULT_VALUE_ENCLOSING_JSON_DEPTH)

    /**
     * Like the two-argument overload, for a value that sits inside [enclosingJsonDepth] JSON objects
     * or arrays of its message (1 for a response result, 2 for a request parameter). Callers that
     * embed the encoded value deeper inside their own message must pass its real enclosing depth,
     * or the depth check below will let through values the receiver refuses.
     *
     * Every receiver refuses a message whose JSON nests deeper than [MAX_JSON_NESTING_DEPTH],
     * counting the envelope and the objects that carry byte arrays. A value that would exceed it is
     * refused here, at once, with an [IllegalArgumentException] naming the depth; sending it would
     * only make the receiver refuse the whole frame and close the stream. This bound also keeps the
     * recursive encoding of a very deep value from exhausting the thread's stack.
     */
    fun encodeValueForJson(
        value: Any?,
        attachments: MutableList<ByteArray>?,
        enclosingJsonDepth: Int,
    ): Any? {
        require(enclosingJsonDepth >= 0) {
            "enclosingJsonDepth must be zero or more, but was $enclosingJsonDepth."
        }
        val resources = RpcEncodingResources()
        return resources.guard(value) {
            encodeValueForJson(
                value,
                attachments,
                java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Any, Boolean>()),
                enclosingJsonDepth,
                resources,
            )
        }
    }

    // JSON levels around a value: the message object for a result; the message and params
    // objects for a request parameter.
    private const val RESULT_VALUE_ENCLOSING_JSON_DEPTH = 1
    private const val PARAM_VALUE_ENCLOSING_JSON_DEPTH = 2
    // An error's data sits inside the message and error objects.
    private const val ERROR_DATA_ENCLOSING_JSON_DEPTH = 2

    private fun requireWireJsonDepth(jsonDepth: Int, description: String) {
        if (jsonDepth > MAX_JSON_NESTING_DEPTH) {
            throw IllegalArgumentException(
                "Cannot encode RPC value: a $description would sit at JSON nesting depth $jsonDepth " +
                    "of its message, but receivers refuse messages nested deeper than " +
                    "MAX_JSON_NESTING_DEPTH=$MAX_JSON_NESTING_DEPTH (counting the message envelope " +
                    "and the objects that carry byte arrays)."
            )
        }
    }

    /**
     * Checks the exact JSON bytes of an outgoing message against the limits every receiver enforces
     * before parsing ([MAX_JSON_FRAME_BYTES], [MAX_JSON_NESTING_DEPTH], [MAX_JSON_STRING_LENGTH],
     * [MAX_JSON_ELEMENT_COUNT]), so a message a receiver would refuse (closing the stream) is refused
     * by its sender instead, with an [IllegalArgumentException] carrying the receiver's reason.
     */
    internal fun checkJsonWireStructure(jsonBytes: ByteArray) {
        val refusal = try {
            if (jsonBytes.size > MAX_JSON_FRAME_BYTES) {
                throw IOException(
                    "Refused JSON message: ${jsonBytes.size} JSON bytes exceed " +
                        "MAX_JSON_FRAME_BYTES=$MAX_JSON_FRAME_BYTES"
                )
            }
            validateJsonStructure(jsonBytes)
            null
        } catch (receiverWouldRefuse: IOException) {
            receiverWouldRefuse
        }
        if (refusal != null) {
            throw IllegalArgumentException(
                "Cannot send RPC message: every receiver would refuse it. ${refusal.message}",
                refusal,
            )
        }
    }

    /** Whether org.json's writer renders [value] as a nested JSON object or array. */
    private fun rendersAsJsonContainer(value: Any?): Boolean =
        value is JSONObject || value is JSONArray || value is Map<*, *> || value is Collection<*> ||
            (value != null && value.javaClass.isArray)

    /**
     * The JSON nesting depth org.json's writer produces for [root] (0 for a scalar, 1 for a flat
     * object or array), stopping once it exceeds [limit].
     *
     * It follows every child the writer renders as nested JSON: [JSONObject] and [JSONArray], and the
     * Kotlin/Java [Map]s, [Collection]s, object arrays, and primitive arrays a raw tree may hold. It
     * traversal stops at the receiver's fixed depth bound, so a very deep (or self-containing)
     * tree cannot reach the writer, which would recurse without bound. Leaves are written exactly
     * as org.json always writes them. Not measured here: a [org.json.JSONString]'s text, and the
     * levels org.json adds when it converts an object inside a Map, Collection, or array by
     * reflection (as a Java bean); [checkJsonWireStructure] checks the written bytes for both.
     */
    private fun renderedJsonDepth(root: Any?, limit: Int, locateCycles: Boolean = false): Int {
        val active = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Any, Boolean>())
        fun visit(node: Any?, depth: Int): Int {
            // JSONString takes precedence over container wrapping in org.json's writer.
            if (node is org.json.JSONString || !rendersAsJsonContainer(node)) return depth - 1
            if (depth > limit) return depth
            if (!active.add(node!!)) {
                if (!locateCycles) return limit + 1
                val kind = when (node) {
                    is JSONObject -> "a JSONObject"
                    is JSONArray -> "a JSONArray"
                    is Map<*, *> -> "a Map"
                    is Collection<*> -> "a Collection"
                    else -> "an object Array"
                }
                throw RpcValuePathFailure(RpcValueEncodingException("",
                    "is $kind that contains itself or an ancestor container, which JSON cannot represent."))
            }
            var deepest = depth
            fun child(value: Any?, key: String? = null, index: Int = -1) {
                val found = try { visit(value, depth + 1) }
                catch (failure: RpcValuePathFailure) {
                    val suffix = if (key == null) "[$index]" else rpcFieldPathSuffix(key)
                    failure.path = boundedRpcFieldPath(suffix + failure.path)
                    throw failure
                }
                if (found > deepest) deepest = found
            }
            try {
                when (node) {
                    is JSONObject -> for (key in node.keySet()) {
                        child(node.opt(key), key)
                        if (deepest > limit) break
                    }
                    is JSONArray -> for (index in 0 until node.length()) {
                        child(node.opt(index), index = index)
                        if (deepest > limit) break
                    }
                    is Map<*, *> -> for ((key, value) in node) {
                        // Render a caller's map key only if the cycle actually goes through it.
                        val found = try { visit(value, depth + 1) }
                        catch (failure: RpcValuePathFailure) {
                            val keyText = try { key.toString() } catch (diagnostic: Throwable) {
                                if (diagnostic !== failure.original) failure.original.addSuppressed(diagnostic)
                                "<${key?.javaClass?.name ?: "null"}>"
                            }
                            failure.path = boundedRpcFieldPath(rpcFieldPathSuffix(keyText) + failure.path)
                            throw failure
                        }
                        if (found > deepest) deepest = found
                        if (deepest > limit) break
                    }
                    is Collection<*> -> for ((index, value) in node.withIndex()) {
                        child(value, index = index)
                        if (deepest > limit) break
                    }
                    is Array<*> -> for ((index, value) in node.withIndex()) {
                        child(value, index = index)
                        if (deepest > limit) break
                    }
                }
                return deepest
            } finally { active.remove(node) }
        }
        return visit(root, 1)
    }

    private fun encodeValueForJson(
        value: Any?,
        attachments: MutableList<ByteArray>?,
        activeContainers: MutableSet<Any>,
        enclosingJsonDepth: Int,
        resources: RpcEncodingResources,
        locateFailure: Boolean = false,
    ): Any? {
        // The JSON level a container (or byte-array carrier object) made from this value occupies.
        val valueJsonDepth = enclosingJsonDepth + 1
        return when (value) {
            null -> null
            is StreamingBytecodeResponse -> throw IllegalStateException(
                "StreamingBytecodeResponse for implementation '${value.implClassName}' " +
                    "(requestId='${value.requestId}', ${value.jarBytes.size} JAR bytes) reached " +
                    "RpcResponse.toJson()/encodeValueForJson. This marker MUST be intercepted by " +
                    "the stream-write site (TcpServer.handleConnection or " +
                    "Libp2pHostFactory.writeStreamingBytecodeMessage) and streamed via " +
                    "writeStreamingBytecodeResponse — it must never be JSON-serialized through the " +
                    "generic envelope path, which would silently corrupt the bytecode response."
            )
            is ForwardedStreamingBytecodeResponse -> {
                val refusal = IllegalStateException(
                    "ForwardedStreamingBytecodeResponse for implementation '${value.implClassName}' " +
                        "(${value.jarLength} JAR bytes) reached RpcResponse.toJson()/encodeValueForJson. " +
                        "This response must be intercepted by the RPC stream-write site so its " +
                        "attachment can be relayed without first being buffered."
                )
                // The owning encoding guard releases the entire refused graph, including
                // siblings that this traversal has not reached yet.
                throw refusal
            }
            is ByteArray -> {
                requireWireJsonDepth(valueJsonDepth, "byte array")
                if (attachments != null) {
                    val index = attachments.size
                    attachments.add(value)
                    JSONObject().apply {
                        put(BYTE_ARRAY_TYPE_KEY, BINARY_REF_TYPE_MARKER)
                        put(BINARY_REF_INDEX_KEY, index)
                    }
                } else {
                    // Fallback: base64 encoding when no attachment list is provided
                    JSONObject().apply {
                        put(BYTE_ARRAY_TYPE_KEY, BYTE_ARRAY_TYPE_MARKER)
                        put(BYTE_ARRAY_VALUE_KEY, Base64.getEncoder().encodeToString(value))
                    }
                }
            }
            is Map<*, *> -> {
                requireWireJsonDepth(valueJsonDepth, "Map")
                withActiveContainer(value, "Map", activeContainers) {
                    val encoded = JSONObject()
                    for ((k, v) in value) {
                        // org.json removes the key outright when a null is put, which would erase the
                        // difference between "the caller passed null" and "the caller omitted this
                        // entry". Write an explicit JSON null so the receiver decodes it back as null.
                        val key = try {
                            k.toString()
                        } catch (failure: Throwable) {
                            if (!locateFailure) throw failure
                            rethrowFatalJvmError(failure)
                            // Describing this key already failed; never call it again for the path.
                            throw RpcValuePathFailure(failure, rpcFieldPathSuffix("<${k?.javaClass?.name ?: "null"}>"))
                        }
                        val child = try {
                            encodeValueForJson(v, attachments, activeContainers, valueJsonDepth, resources, locateFailure)
                        } catch (failure: RpcValuePathFailure) {
                            failure.path = boundedRpcFieldPath(rpcFieldPathSuffix(key) + failure.path)
                            throw failure
                        }
                        encoded.put(key, child ?: JSONObject.NULL)
                    }
                    encoded
                }
            }
            // Collections and object arrays must be traversed for the same reason maps are: without
            // this, a nested ByteArray never becomes a binary attachment and org.json's generic
            // wrapping renders it inline as an array of numbers, so the receiver decodes a
            // List<Int> instead of the ByteArray that was sent.
            is Collection<*> -> {
                requireWireJsonDepth(valueJsonDepth, "Collection")
                withActiveContainer(value, "Collection", activeContainers) {
                    val encoded = JSONArray()
                    for ((index, element) in value.withIndex()) {
                        val child = try {
                            encodeValueForJson(element, attachments, activeContainers, valueJsonDepth, resources, locateFailure)
                        } catch (failure: RpcValuePathFailure) {
                            failure.path = boundedRpcFieldPath("[$index]" + failure.path)
                            throw failure
                        }
                        encoded.put(child ?: JSONObject.NULL)
                    }
                    encoded
                }
            }
            is Array<*> -> {
                requireWireJsonDepth(valueJsonDepth, "object Array")
                withActiveContainer(value, "object Array", activeContainers) {
                    val encoded = JSONArray()
                    for ((index, element) in value.withIndex()) {
                        val child = try {
                            encodeValueForJson(element, attachments, activeContainers, valueJsonDepth, resources, locateFailure)
                        } catch (failure: RpcValuePathFailure) {
                            failure.path = boundedRpcFieldPath("[$index]" + failure.path)
                            throw failure
                        }
                        encoded.put(child ?: JSONObject.NULL)
                    }
                    encoded
                }
            }
            is java.io.InputStream -> {
                // Streaming HTTP transport returns an InputStream. Read to String
                // for JSON serialization. This is fine for normal-sized responses;
                // huge responses should not go through P2P RPC.
                resources.readText(value)
            }
            // A raw org.json value, such as a result a forwarder relayed with sendRequestRaw, carries
            // its byte arrays as base64 markers. When the destination accepts binary attachments,
            // send them as attachments: left as text, a relayed byte array is a third larger and
            // travels as one JSON frame that cannot use the chunked large-response path. A message
            // carries at most MAX_ATTACHMENTS attachments, so a value with more markers than the
            // message has room left for keeps its inline base64 form, which the receiver decodes to
            // the same ByteArray values; converting it would make the whole message unsendable.
            is JSONObject, is JSONArray -> {
                requireWireJsonDepth(
                    enclosingJsonDepth + renderedJsonDepth(value, MAX_JSON_NESTING_DEPTH - enclosingJsonDepth, locateCycles = locateFailure),
                    "raw JSON value",
                )
                if (attachments == null) {
                    value
                } else {
                    val room = MAX_ATTACHMENTS - attachments.size
                    val markers = countBase64ByteArrayMarkers(value, room + 1)
                    if (markers in 1..room) base64ByteArrayMarkersToAttachments(value, attachments) else value
                }
            }
            // org.json writes a primitive array (IntArray, DoubleArray, ...) as a JSON array.
            else -> if (value?.javaClass?.isArray == true) {
                requireWireJsonDepth(valueJsonDepth, "primitive array")
                value
            } else {
                if (!locateFailure) encodeLeafForJson(value) else try {
                    encodeLeafForJson(value)
                } catch (failure: Throwable) {
                    rethrowFatalJvmError(failure)
                    throw RpcValuePathFailure(failure)
                }
            }
        }
    }

    /**
     * A leaf exactly as org.json's writer would render it, with any other object turned into its
     * `toString()` text here, while it is being encoded, rather than later inside the writer. The
     * wire bytes are unchanged (the writer quotes that same text), but an exception the object's
     * `toString()` throws now fails the encoding, so a server answers that request with an error
     * instead of sending nothing. A `toString()` that recurses without bound still overflows the
     * stack: that is a defect of the value's own `toString()`, and it is not caught.
     */
    private fun encodeLeafForJson(value: Any?): Any? = when {
        value == null -> null
        // The writer writes any value equal to null (JSONObject.NULL among them) as `null`.
        value.equals(null) -> JSONObject.NULL
        value is Number || value is Boolean || value is Enum<*> || value is org.json.JSONString ||
            value is String -> value
        else -> value.toString()
    }

    private fun isBase64ByteArrayMarker(value: JSONObject): Boolean =
        value.optString(BYTE_ARRAY_TYPE_KEY) == BYTE_ARRAY_TYPE_MARKER &&
            value.opt(BYTE_ARRAY_VALUE_KEY) is String

    /**
     * Counts the base64 byte-array markers in a raw org.json tree, stopping once [limit] is reached,
     * so a tree with very many markers is not scanned beyond what the caller needs to decide.
     */
    private fun countBase64ByteArrayMarkers(value: Any?, limit: Int): Int {
        var count = 0
        fun visit(node: Any?) {
            if (count >= limit) return
            when (node) {
                is JSONObject -> if (isBase64ByteArrayMarker(node)) {
                    count++
                } else {
                    for (key in node.keys()) {
                        visit(node.opt(key))
                        if (count >= limit) return
                    }
                }
                is JSONArray -> for (index in 0 until node.length()) {
                    visit(node.opt(index))
                    if (count >= limit) return
                }
            }
        }
        visit(value)
        return count
    }

    /**
     * Copies a raw org.json tree, replacing each base64 byte-array marker with a binary attachment
     * reference. Receivers decode both forms to the same ByteArray, so the conversion changes only
     * the wire representation.
     */
    private fun base64ByteArrayMarkersToAttachments(value: Any?, attachments: MutableList<ByteArray>): Any? =
        when {
            value is JSONObject && isBase64ByteArrayMarker(value) -> {
                val bytes = try {
                    Base64.getDecoder().decode(value.getString(BYTE_ARRAY_VALUE_KEY))
                } catch (_: IllegalArgumentException) {
                    // Not valid base64: send the marker unchanged so the receiver reports the same
                    // decode error it would have reported before, rather than failing this write.
                    null
                }
                if (bytes == null) {
                    value
                } else {
                    val index = attachments.size
                    attachments.add(bytes)
                    JSONObject().apply {
                        put(BYTE_ARRAY_TYPE_KEY, BINARY_REF_TYPE_MARKER)
                        put(BINARY_REF_INDEX_KEY, index)
                    }
                }
            }
            value is JSONObject -> JSONObject().also { copy ->
                for (key in value.keys()) {
                    copy.put(key, base64ByteArrayMarkersToAttachments(value.opt(key), attachments))
                }
            }
            value is JSONArray -> JSONArray().also { copy ->
                for (index in 0 until value.length()) {
                    copy.put(base64ByteArrayMarkersToAttachments(value.opt(index), attachments))
                }
            }
            else -> value
        }

    private fun <T> withActiveContainer(
        value: Any,
        description: String,
        activeContainers: MutableSet<Any>,
        block: () -> T
    ): T {
        if (!activeContainers.add(value)) {
            throw IllegalArgumentException(
                "Cannot encode cyclic RPC value: a $description contains itself or an ancestor container."
            )
        }
        return try {
            block()
        } finally {
            activeContainers.remove(value)
        }
    }

    /**
     * Decodes a value from JSON deserialization, converting byte-array markers
     * and binary attachment references back to ByteArray instances. Fractional
     * numbers parsed by org.json are normalized from BigDecimal to Double so they
     * remain JVM primitive-wrapper values at RPC and sandbox boundaries.
     *
     * Supports both legacy base64-encoded markers (`{"__type":"bytes","__value":"..."}`)
     * and new binary attachment references (`{"__type":"binary_ref","__index":N}`).
     */
    @JvmOverloads
    fun decodeValueFromJson(value: Any?, attachments: List<ByteArray>? = null): Any? {
        return when {
            value == null || value == JSONObject.NULL -> null
            value is java.math.BigDecimal -> value.toDouble()
            value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BINARY_REF_TYPE_MARKER -> {
                val index = value.getInt(BINARY_REF_INDEX_KEY)
                attachments?.getOrNull(index)
                    ?: throw IOException("Binary attachment index $index out of range (${attachments?.size ?: 0} attachments)")
            }
            value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BYTE_ARRAY_TYPE_MARKER -> {
                Base64.getDecoder().decode(value.getString(BYTE_ARRAY_VALUE_KEY))
            }
            value is JSONObject -> {
                val decoded = mutableMapOf<String, Any?>()
                for (key in value.keys()) {
                    decoded[key] = decodeValueFromJson(value.opt(key), attachments)
                }
                decoded
            }
            value is JSONArray -> {
                (0 until value.length()).map { decodeValueFromJson(value.opt(it), attachments) }
            }
            else -> value
        }
    }

    /**
     * Encodes a params map for JSON serialization, converting any ByteArray values
     * to binary attachment references.
     */
    private fun encodeParamsForJson(params: Map<String, Any?>, attachments: MutableList<ByteArray>? = null): JSONObject {
        val encoded = JSONObject()
        for ((key, value) in params) {
            // An explicitly-null parameter must stay on the wire as a present key holding a JSON
            // null. org.json's put() deletes the key when handed a Kotlin null, which would make an
            // explicit null indistinguishable from an omitted argument at the service.
            encoded.put(key, encodeValueForJson(value, attachments, PARAM_VALUE_ENCLOSING_JSON_DEPTH) ?: JSONObject.NULL)
        }
        return encoded
    }

    /**
     * Decodes a params JSONObject, converting any byte-array markers back to ByteArray.
     */
    private fun decodeParamsFromJson(paramsObj: JSONObject, attachments: List<ByteArray>): MutableMap<String, Any?> {
        val params = mutableMapOf<String, Any?>()
        for (key in paramsObj.keys()) {
            params[key] = decodeValueFromJson(paramsObj.opt(key), attachments)
        }
        return params
    }

    /**
     * Encodes a result value for JSON serialization.
     * If the result is a Map, encodes any ByteArray values within it.
     * If the result is itself a ByteArray, encodes it directly.
     */
    private fun encodeResultForJson(
        result: Any?,
        attachments: MutableList<ByteArray>?,
        resources: RpcEncodingResources,
    ): Any? = try {
        encodeValueForJson(
            result,
            attachments,
            java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Any, Boolean>()),
            RESULT_VALUE_ENCLOSING_JSON_DEPTH,
            resources,
            locateFailure = true,
        )
    } catch (failure: RpcValuePathFailure) {
        throw rpcValueEncodingFailure(boundedRpcFieldPath("result" + failure.path), failure.original)
    }

    /**
     * Decodes a result value from JSON, restoring ByteArray instances.
     */
    private fun decodeResultFromJson(result: Any?, attachments: List<ByteArray>): Any? {
        return decodeValueFromJson(result, attachments)
    }

    /**
     * Encodes a message with binary attachments to bytes for transmission.
     *
     * Wire format:
     * ```
     * [4 bytes: json_length][json_bytes][4 bytes: num_attachments]
     * [4 bytes: attachment_0_length][attachment_0_bytes]
     * [4 bytes: attachment_1_length][attachment_1_bytes]
     * ...
     * ```
     *
     * @throws org.json.JSONException if [json] cannot be serialized — for example when it holds a
     *   [org.json.JSONString] whose `toJSONString` throws. `JSONObject.toString` swallows such a
     *   failure and returns `null`, which reached callers here as a `NullPointerException` naming
     *   nothing. The serializer's own exception is raised instead: its message names the key that
     *   could not be written, and the original failure stays on its cause chain.
     */
    @JvmOverloads
    fun encodeMessage(json: JSONObject, attachments: List<ByteArray> = emptyList()): ByteArray {
        val jsonBytes = jsonWireBytes(json)
        if (attachments.isEmpty()) {
            // No attachments: use the compact format (just length + json) for
            // backward compatibility with readers that don't understand attachments
            // (e.g., RelayStreamController.readMessage).
            val buffer = ByteBuffer.allocate(4 + jsonBytes.size)
            buffer.putInt(jsonBytes.size)
            buffer.put(jsonBytes)
            return buffer.array()
        }
        var totalSize = 4 + jsonBytes.size + 4
        for (attachment in attachments) {
            totalSize += 4 + attachment.size
        }
        val buffer = ByteBuffer.allocate(totalSize)
        buffer.putInt(jsonBytes.size)
        buffer.put(jsonBytes)
        buffer.putInt(attachments.size)
        for (attachment in attachments) {
            buffer.putInt(attachment.size)
            buffer.put(attachment)
        }
        return buffer.array()
    }

    /**
     * Writes a message with optional binary attachments to an output stream.
     */
    @JvmOverloads
    fun writeMessage(output: OutputStream, json: JSONObject, attachments: List<ByteArray> = emptyList()) {
        val bytes = encodeMessage(json, attachments)
        output.write(bytes)
        output.flush()
    }

    /**
     * Attachment-aware writer for an already-serialized output lane. Unlike [writeMessage], this
     * emits each frame segment directly and never aggregate-copies the attachment arrays. The
     * caller must hold the lane's write lock for the entire call so another frame cannot interleave.
     */
    internal fun writeMessageStreamingAttachments(
        output: OutputStream,
        json: JSONObject,
        attachments: List<ByteArray>
    ) {
        writeEncodedMessageStreamingAttachments(
            output,
            jsonWireBytes(json),
            attachments
        )
    }

    /**
     * Emits the same wire frame as [writeMessageStreamingAttachments] for a JSON body the caller has
     * already serialized. A caller that queues a frame for a later write can therefore charge its
     * exact size against a byte budget at queue time without serializing the JSON twice and without
     * aggregate-copying the attachment arrays. The caller must hold the lane's write lock for the
     * entire call so another frame cannot interleave.
     */
    internal fun writeEncodedMessageStreamingAttachments(
        output: OutputStream,
        jsonBytes: ByteArray,
        attachments: List<ByteArray>
    ) {
        val dataOutput = DataOutputStream(output)
        dataOutput.writeInt(jsonBytes.size)
        dataOutput.write(jsonBytes)
        if (attachments.isNotEmpty()) {
            dataOutput.writeInt(attachments.size)
            for (attachment in attachments) {
                dataOutput.writeInt(attachment.size)
                dataOutput.write(attachment)
            }
        }
        dataOutput.flush()
    }

    /**
     * Result of reading a message from the wire, containing the JSON message
     * and any binary attachments.
     */
    data class MessageFrame(
        val json: JSONObject,
        val attachments: List<ByteArray>
    )

    /**
     * Reads a single length-prefixed JSON body from an input stream (compact format only).
     *
     * NOTE: despite its name this reader does NOT read the binary-attachment framing that
     * encodeMessage writes after the JSON (the length prefix covers only the JSON), so it
     * always returns zero attachments and would strand any attachment bytes in the stream.
     * Use readMessageFrameFromStream (or the convenience readMessage) for any message that may
     * carry attachments; this method is kept only for the compact/no-attachment path.
     */
    fun readMessageFrame(input: InputStream): MessageFrame {
        // Read the length prefix
        val lengthBytes = ByteArray(4)
        readFully(input, lengthBytes)
        val totalLength = ByteBuffer.wrap(lengthBytes).int
        // 10 MB framing cap (matches readJsonFrame and the deadline readers). A single
        // message must never be large enough to OOM a small heap on its own — a 100 MB
        // body alone exceeds CN's -Xmx128m.
        if (totalLength <= 0) {
            throw IOException("Invalid message length: $totalLength")
        }
        if (totalLength > MAX_JSON_FRAME_BYTES) throw singleFrameLimitException(totalLength)

        // Reserve parse-memory BEFORE allocating/parsing the body so concurrent large reads
        // can't exhaust the heap (see MAX_CONCURRENT_PARSE_BYTES).
        val permits = acquireParseBudget(totalLength)
        try {
            // Read the entire message body (which may contain JSON + attachment framing)
            val bodyBytes = ByteArray(totalLength)
            readFully(input, bodyBytes)

            // The first part is always JSON. Try to find where JSON ends by parsing it.
            // For backward compatibility, if the body is exactly JSON with no extra bytes,
            // treat it as a legacy message with no attachments.
            // Enforce the JSON structural-safety caps (#259) BEFORE constructing the JSONObject,
            // matching the pre-binary-attachments read path (parseValidatedJsonBody). A
            // structural violation throws IOException (distinct from JSONException) so it
            // surfaces to the caller as a rejection rather than being masked below.
            validateJsonStructure(bodyBytes)
            val jsonString = String(bodyBytes, StandardCharsets.UTF_8)
            return try {
                val json = parseJsonWireString(jsonString)
                // Entire body was valid JSON — legacy format, no attachments
                MessageFrame(json, emptyList())
            } catch (e: org.json.JSONException) {
                // Body is longer than the JSON — contains attachment framing after the JSON.
                // This shouldn't happen with our format since we use a separate length prefix
                // for the JSON portion when attachments are present.
                throw IOException("Invalid message format: failed to parse JSON body", e)
            }
        } finally {
            releaseParseBudget(permits)
        }
    }

    private class InterleavedFrameCapacity(
        private val memoryBudget: MemoryBudget,
    ) : AutoCloseable {
        val lease = FrameAttachmentLease.forInterleavedCompactFrame(memoryBudget)
        private val lock = Any()
        private var closed = false
        private var turnHeld = false
        private var extraBytes = 0L

        fun acquire() {
            try {
                memoryBudget.companionFrameTurn.acquire()
            } catch (failure: InterruptedException) {
                Thread.currentThread().interrupt()
                throw IOException("Interrupted while waiting for the interleaved frame reader turn", failure)
            }
            synchronized(lock) {
                if (closed) {
                    memoryBudget.companionFrameTurn.release()
                    throw IOException("The interleaved frame reader was closed before admission")
                }
                turnHeld = true
            }
            if (!lease.acquire()) throw IOException("The interleaved frame reader was closed during admission")
        }

        fun cover(jsonBytes: Int, attachmentBytes: Long, interleavedChunk: Boolean = false) {
            val requiredBytes = jsonBytes.toLong() * PARSE_AMPLIFICATION + attachmentBytes
            if (interleavedChunk && requiredBytes > INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES) {
                throw IOException(
                    "Interleaved response chunk requires $requiredBytes retained bytes " +
                        "(JSON and attachments), exceeding the compact-frame lane " +
                        INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES,
                )
            }
            val requiredExtra = (requiredBytes - INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES)
                .coerceAtLeast(0L)
            check(requiredExtra <= memoryBudget.companionFrameByteLimit) {
                "Inbound frame requires $requiredBytes retained bytes, exceeding its frame allowance"
            }
            synchronized(lock) {
                if (closed || !lease.isHeld) throw IOException("The interleaved frame reader is closed")
                if (requiredExtra > extraBytes) {
                    memoryBudget.changeCompanionFrameCharge(requiredExtra - extraBytes)
                    extraBytes = requiredExtra
                }
            }
        }

        override fun close() {
            synchronized(lock) {
                if (closed) return
                closed = true
                memoryBudget.changeCompanionFrameCharge(-extraBytes)
                extraBytes = 0L
                try {
                    lease.close()
                } finally {
                    if (turnHeld) {
                        turnHeld = false
                        memoryBudget.companionFrameTurn.release()
                    }
                }
            }
        }
    }

    /**
     * Reads a message frame that may include binary attachments.
     *
     * When attachments are present, the wire format is:
     * ```
     * [4 bytes: json_length][json_bytes][4 bytes: num_attachments]
     * [4 bytes: att_0_length][att_0_bytes]...
     * ```
     *
     * When no attachments are present (compact format):
     * ```
     * [4 bytes: json_length][json_bytes]
     * ```
     *
     * Since the compact format is indistinguishable from the first part of the
     * attachment format at the 4-byte length prefix level, we use a marker in the
     * JSON to detect the presence of attachments.
     */
    fun readMessageFrameFromStream(input: InputStream): MessageFrame =
        readMessageFrameFromStream(input, retainedAttachmentLeaseBeforeJson = { null }) { null }

    /**
     * Reads one frame while the caller may already retain an interleaved-response assembly lease.
     * After its length prefix arrives, a single process-wide frame turn owns the compact lane and
     * any companion allowance needed by a valid ordinary frame. Combined JSON and destination
     * bytes are covered before allocation. Ownership survives dispatch and can be closed directly
     * by the caller without waiting for a parked transport reader.
     */
    internal fun readMessageFrameFromStream(
        input: InputStream,
        retainedAttachmentLeaseBeforeJson: () -> FrameAttachmentLease?,
        onInterleavedResponseStart: ((JSONObject) -> Unit)? = null,
        onFrameCapacityChanged: ((AutoCloseable?) -> Unit)? = null,
        onMessageFrame: ((MessageFrame) -> Unit)? = null,
        memoryBudget: MemoryBudget = processWideMemoryBudget,
        onGrowingFrameLease: ((FrameAttachmentLease) -> Unit)? = null,
        onJsonReservation: ((JsonFrameReservation) -> Unit)? = null,
        retainedAttachmentLeaseForJson: (JSONObject) -> FrameAttachmentLease?,
    ): MessageFrame {
        val jsonLength = readJsonFrameLength(input)
        val retainedLeaseBeforeJson = retainedAttachmentLeaseBeforeJson()
        if (retainedLeaseBeforeJson != null && !retainedLeaseBeforeJson.isHeld) {
            throw IOException("The retained attachment lease for an interleaved response is not held")
        }
        val frameCapacity = retainedLeaseBeforeJson?.let {
            InterleavedFrameCapacity(memoryBudget)
        }
        try {
            onFrameCapacityChanged?.invoke(frameCapacity)
            frameCapacity?.acquire()
            frameCapacity?.cover(jsonLength, 0L)
            val frame = checkNotNull(readMessageFrameFromStream(
                input,
                jsonLength,
                frameCapacity,
                onInterleavedResponseStart,
                memoryBudget,
                retainedAttachmentLeaseForJson,
                onGrowingFrameLease = onGrowingFrameLease,
                onJsonReservation = onJsonReservation,
            )) { "The ordinary frame reader cannot transfer attachment ownership" }
            onMessageFrame?.invoke(frame)
            return frame
        } finally {
            try { frameCapacity?.close() }
            finally { onFrameCapacityChanged?.invoke(null) }
        }
    }

    /**
     * Reads one frame for a transport that owns its reader thread. [onGrowingFrameLease] receives
     * the frame's growable attachment lease, and [onJsonReservation] the frame's JSON parse
     * reservation, before either asks for any pool admission, so the transport's close can close
     * them directly: a closed transport's reader then can neither record a new admission nor keep
     * one after the close returns.
     */
    internal fun readMessageFrameFromStream(
        input: InputStream,
        selectSingleAttachmentConsumer: ((JSONObject) -> SingleAttachmentStreamConsumer?)?,
        onGrowingFrameLease: ((FrameAttachmentLease) -> Unit)? = null,
        onJsonReservation: ((JsonFrameReservation) -> Unit)? = null,
    ): MessageFrame? = readMessageFrameFromStream(
        input, readJsonFrameLength(input), null, null, processWideMemoryBudget, { null },
        selectSingleAttachmentConsumer, onGrowingFrameLease, onJsonReservation,
    )

    private fun readMessageFrameFromStream(
        input: InputStream,
        jsonLength: Int,
        frameCapacity: InterleavedFrameCapacity?,
        onInterleavedResponseStart: ((JSONObject) -> Unit)?,
        memoryBudget: MemoryBudget,
        retainedAttachmentLeaseForJson: (JSONObject) -> FrameAttachmentLease?,
        selectSingleAttachmentConsumer: ((JSONObject) -> SingleAttachmentStreamConsumer?)? = null,
        onGrowingFrameLease: ((FrameAttachmentLease) -> Unit)? = null,
        onJsonReservation: ((JsonFrameReservation) -> Unit)? = null,
    ): MessageFrame? {
        val json = readJsonFrame(
            input,
            jsonLength,
            frameCapacity != null,
            onInterleavedResponseStart,
            memoryBudget,
            onJsonReservation,
        )

        val interleavedChunk = json.optString("type", "") == TYPE_INTERLEAVED_RESPONSE_CHUNK
        frameCapacity?.cover(jsonLength, 0L, interleavedChunk)

        // Check if this message has binary attachments by looking for binary_ref markers
        // in the JSON. If binary_ref markers exist, attachments follow.
        if (!jsonContainsBinaryRefs(json)) {
            return MessageFrame(json, emptyList())
        }

        // Select provisionally before any further blocking IO: a withheld count or length must
        // not retain an uncharged parsed header. Publication still requires full validation below.
        val streamConsumer = if (selectSingleAttachmentConsumer != null && countBinaryRefs(json) == 1) {
            selectSingleAttachmentConsumer.invoke(json)
        } else null
        val transferLease = streamConsumer?.let { ForwardedTransferLease.acquire(jsonLength) }
        // A selected header owns a forwarding lease before the length is known. Its reader needs
        // the same existing stall/lifetime guards as a body, independently of any request deadline.
        val headerClock = attachmentClock
        val headerAdmittedAt = headerClock.currentTimeMillis()
        val headerProgressAt = java.util.concurrent.atomic.AtomicLong(headerAdmittedAt)
        val headerFinished = java.util.concurrent.atomic.AtomicBoolean(false)
        val headerWatchdog = transferLease?.let { lease ->
            scheduleAttachmentStallWatchdog {
                val now = headerClock.currentTimeMillis()
                if ((now - headerProgressAt.get() > ATTACHMENT_STALL_TIMEOUT_MS ||
                        now - headerAdmittedAt > attachmentLeaseDeadlineMs(0)) &&
                    headerFinished.compareAndSet(false, true)) {
                    lease.close()
                    try { input.close() } catch (failure: Throwable) {
                        rethrowFatalJvmError(failure)
                        debugLogErr { "Could not close a stalled forwarding header: ${failure.message}" }
                    }
                }
            }
        }
        val headerProgress = { headerProgressAt.set(headerClock.currentTimeMillis()) }
        val numAttachments = try {
            val attachmentCountBytes = ByteArray(4)
            readFullyWithProgress(input, attachmentCountBytes, headerProgress)
            val count = ByteBuffer.wrap(attachmentCountBytes).int
            if (count < 0 || count > MAX_ATTACHMENTS) {
                throw IOException("Invalid attachment count: $count")
            }
            validateBinaryAttachmentEnvelope(json, count)
            count
        } catch (failure: Throwable) {
            headerFinished.set(true)
            headerWatchdog?.cancel(false)
            transferLease?.close()
            throw failure
        }

        if (streamConsumer != null && transferLease != null && numAttachments == 1) {
            var sourceOwnsLease = false
            try {
                val lengthBytes = ByteArray(4)
                readFullyWithProgress(input, lengthBytes, headerProgress)
                val attachmentLength = ByteBuffer.wrap(lengthBytes).int
                if (attachmentLength < 0 || attachmentLength > MAX_SINGLE_ATTACHMENT_BYTES) {
                    throw IOException("Invalid attachment length: $attachmentLength")
                }
                if (attachmentLength.toLong() > MAX_ATTACHMENT_AGGREGATE_BYTES) {
                    throw IOException(attachmentAggregateLimitMessage(attachmentLength.toLong(), 1))
                }
                headerFinished.set(true)
                headerWatchdog?.cancel(false)
                val attachmentInput = FramedAttachmentInputStream(input, attachmentLength, checkNotNull(transferLease))
                sourceOwnsLease = true
                try {
                    streamConsumer.accept(attachmentLength, attachmentInput)
                    attachmentInput.awaitFinished()
                } catch (failure: Throwable) {
                    try {
                        attachmentInput.close()
                    } catch (closeFailure: Throwable) {
                        failure.addSuppressed(closeFailure)
                    }
                    throw failure
                }
                return null
            } finally {
                headerFinished.set(true)
                headerWatchdog?.cancel(false)
                if (!sourceOwnsLease) transferLease?.close()
            }
        }
        headerFinished.set(true)
        headerWatchdog?.cancel(false)
        // Unsupported shapes and responses beyond streaming capacity use the ordinary reader without retaining
        // the provisional forwarding reservation while waiting for its materialization capacity.
        transferLease?.close()

        // The wire interleaves [4 len][bytes] pairs, so this reader cannot know the frame's total
        // attachment size before reading its bodies. It therefore reserves what the frame will
        // ACTUALLY retain, raising the reservation to the running declared aggregate before each
        // body is allocated (FrameAttachmentLease.growTo) — never the whole pool, which used to
        // serialize every other inbound read in the process (a 200-byte RPC reply included) behind
        // the entire duration of any attachment transfer.
        //
        // Growing a reservation while retaining earlier bodies would reintroduce fair-semaphore
        // hold-and-wait — two concurrent multi-attachment frames each waiting for growth only the
        // other could release — so the growable lease is held under a process-wide fair one-slot
        // turn: at most one frame per process holds pool bytes while waiting for more, and every
        // other pool holder acquires once and releases without asking for more. That costs no
        // concurrency, because the whole-pool lease this replaced already admitted exactly one
        // attachment frame at a time by taking every permit. The running declared aggregate is
        // still checked against MAX_ATTACHMENT_AGGREGATE_BYTES at each length header so an
        // oversized declaration is rejected before its body is allocated, and a frame declaring
        // more than the whole pool still reserves the pool exclusively (the pool is a concurrency
        // budget, not a single-frame limit — see MAX_CONCURRENT_PARSE_BYTES — and legitimate
        // over-pool JAR transfers must still complete).
        val clock = attachmentClock
        val retainedAssemblyLease = retainedAttachmentLeaseForJson(json)
        if (retainedAssemblyLease != null && !retainedAssemblyLease.isHeld) {
            throw IOException("The retained attachment lease for an interleaved response is not held")
        }
        val ownsGrowableLease = frameCapacity == null && retainedAssemblyLease == null
        val lease = when {
            frameCapacity != null -> frameCapacity.lease
            ownsGrowableLease -> FrameAttachmentLease.forGrowingFrame(memoryBudget)
            else -> FrameAttachmentLease.forInterleavedCompactFrame(memoryBudget)
        }
        if (frameCapacity == null) {
            try {
                // Publish before admission: an owner that closes the lease from here on settles
                // the admission itself (an acquire completing after close gives its permits back
                // unrecorded), so no admission outlives the owner's close.
                if (ownsGrowableLease) onGrowingFrameLease?.invoke(lease)
                lease.acquire()
            } catch (failure: Throwable) {
                try { lease.close() }
                catch (cleanupFailure: Throwable) { failure.addSuppressed(cleanupFailure) }
                throw failure
            }
        }
        // Every held attachment-frame lease needs both existing progress guards, including the
        // compact lease used while an interleaved response assembly remains retained:
        //
        // 1. MINIMUM-PROGRESS stall watchdog: if no inbound byte arrives for
        //    ATTACHMENT_STALL_TIMEOUT_MS the frame is treated as a no-progress stall. Any byte
        //    resets it, so a slow-but-progressing transfer is never aborted here.
        // 2. ABSOLUTE per-frame deadline: even a frame that keeps dribbling ONE byte just under the
        //    stall threshold (so guard 1 never fires) may hold the whole pool only until its
        //    absolute deadline — derived from the floor throughput and the running DECLARED
        //    aggregate (attachmentLeaseDeadlineMs). This closes the byte-dribbling slow-loris that
        //    guard 1 alone leaves open. The deadline is measured against the injectable
        //    [attachmentClock] from lease acquisition, so it is deterministically testable.
        //
        // Started only AFTER the lease is held (never during an admission wait). On either trip the
        // lease is force-released (freeing the pool immediately) and the stream is best-effort
        // closed so the parked reader unwinds.
        val leaseAcquiredAtMs = clock.currentTimeMillis()
        val lastProgressAtMs = java.util.concurrent.atomic.AtomicLong(leaseAcquiredAtMs)
        // Running declared aggregate, published for the watchdog so the absolute deadline grows as
        // validated length headers raise the declared total (bounded by MAX_ATTACHMENT_AGGREGATE_BYTES).
        val declaredAggregateForDeadline = java.util.concurrent.atomic.AtomicLong(0L)
        val stalled = java.util.concurrent.atomic.AtomicBoolean(false)
        val deadlineExceeded = java.util.concurrent.atomic.AtomicBoolean(false)
        val watchdog = attachmentStallWatchdog.scheduleWithFixedDelay({
            val nowMs = clock.currentTimeMillis()
            val declared = declaredAggregateForDeadline.get()
            val deadlineMs = attachmentLeaseDeadlineMs(declared)
            when {
                nowMs - lastProgressAtMs.get() > ATTACHMENT_STALL_TIMEOUT_MS -> {
                    stalled.set(true)
                    if (frameCapacity != null) frameCapacity.close() else lease.close()
                    try { input.close() } catch (_: Throwable) { /* best-effort reader eviction */ }
                }
                nowMs - leaseAcquiredAtMs > deadlineMs -> {
                    deadlineExceeded.set(true)
                    if (frameCapacity != null) frameCapacity.close() else lease.close()
                    try { input.close() } catch (_: Throwable) { /* best-effort reader eviction */ }
                }
            }
        }, ATTACHMENT_STALL_CHECK_INTERVAL_MS, ATTACHMENT_STALL_CHECK_INTERVAL_MS, java.util.concurrent.TimeUnit.MILLISECONDS)
        val onProgress = { lastProgressAtMs.set(clock.currentTimeMillis()) }
        try {
            var declaredAttachmentBytes = 0L
            var retainedAttachmentBytes = 0L
            val attachments = ArrayList<ByteArray>(numAttachments)
            for (i in 0 until numAttachments) {
                val lenBytes = ByteArray(4)
                readFullyWithProgress(input, lenBytes, onProgress)
                val attachmentLength = ByteBuffer.wrap(lenBytes).int
                if (attachmentLength < 0 || attachmentLength > MAX_SINGLE_ATTACHMENT_BYTES) {
                    throw IOException("Invalid attachment length: $attachmentLength")
                }
                declaredAttachmentBytes += attachmentLength.toLong()
                if (declaredAttachmentBytes > MAX_ATTACHMENT_AGGREGATE_BYTES) {
                    throw IOException(attachmentAggregateLimitMessage(declaredAttachmentBytes, numAttachments))
                }
                // One boundary accounts both retained JSON and ALL destination arrays before
                // the next allocation; a new body never borrows its JSON model's charge.
                frameCapacity?.cover(jsonLength, declaredAttachmentBytes, interleavedChunk)
                // Charge the pool for the bytes this frame is about to retain, and only those. A
                // declaration at or above the pool clamps to the whole pool, which is the same
                // exclusive admission the pool's documented policy gives any over-pool estimate.
                if (ownsGrowableLease) {
                    lease.growTo(
                        declaredAttachmentBytes
                            .coerceAtLeast(1L)
                            .coerceAtMost(MAX_CONCURRENT_PARSE_BYTES.toLong())
                            .toInt()
                    )
                }
                // Publish the (validated, capped) running aggregate so the absolute-deadline
                // watchdog can size this frame's budget from it.
                declaredAggregateForDeadline.set(declaredAttachmentBytes)
                val attachmentData = ByteArray(attachmentLength)
                if (attachmentLength > 0) {
                    readFullyWithProgress(input, attachmentData, onProgress)
                }
                attachments.add(attachmentData)
                retainedAttachmentBytes += attachmentLength.toLong()
                lease.updateRetainedAttachmentBytes(retainedAttachmentBytes)
            }
            return MessageFrame(json, attachments)
        } catch (e: IOException) {
            // If the watchdog tore the stream down, surface a clear diagnostic naming which guard
            // tripped rather than the incidental "stream closed" from the forced close.
            if (deadlineExceeded.get()) {
                throw IOException(
                    attachmentLeaseDeadlineExceededMessage(
                        heldMs = clock.currentTimeMillis() - leaseAcquiredAtMs,
                        deadlineMs = attachmentLeaseDeadlineMs(declaredAggregateForDeadline.get()),
                        declaredAggregateBytes = declaredAggregateForDeadline.get()
                    ),
                    e
                )
            }
            if (stalled.get()) {
                throw IOException(
                    "Inbound RPC attachment frame stalled with no read progress for " +
                        "${ATTACHMENT_STALL_TIMEOUT_MS}ms; released the shared attachment pool and " +
                        "closed the stream",
                    e
                )
            }
            throw e
        } finally {
            watchdog.cancel(false)
            if (frameCapacity == null) lease.close()
        }
    }

    /**
     * Checks if a JSONObject tree contains any binary_ref markers.
     */
    internal fun jsonContainsBinaryRefs(json: JSONObject): Boolean {
        for (key in json.keys()) {
            val value = json.opt(key)
            when {
                value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BINARY_REF_TYPE_MARKER -> return true
                value is JSONObject && jsonContainsBinaryRefs(value) -> return true
                value is JSONArray && arrayContainsBinaryRefs(value) -> return true
            }
        }
        return false
    }

    /** Applies the ordinary v1.1 exact-reference invariant to a transported envelope. */
    internal fun validateBinaryAttachmentEnvelope(json: JSONObject, attachmentCount: Int) {
        val binaryReferenceCount = countBinaryRefs(json)
        if (attachmentCount != binaryReferenceCount) {
            throw IOException(
                attachmentCountMismatchMessage(attachmentCount, binaryReferenceCount)
            )
        }
        validateBinaryRefIndices(json, attachmentCount)
    }

    private fun arrayContainsBinaryRefs(array: JSONArray): Boolean {
        for (i in 0 until array.length()) {
            val value = array.opt(i)
            when {
                value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BINARY_REF_TYPE_MARKER -> return true
                value is JSONObject && jsonContainsBinaryRefs(value) -> return true
                value is JSONArray && arrayContainsBinaryRefs(value) -> return true
            }
        }
        return false
    }

    /**
     * Counts the `binary_ref` markers in a JSONObject tree — the number of attachments the
     * envelope actually references. The attachment decoders compare this against the frame's
     * declared attachment count and decline mismatches (see
     * [attachmentCountMismatchMessage]); the encoder emits exactly one attachment per marker,
     * so any difference means a corrupt or abusive frame. Mirrors the traversal of
     * [jsonContainsBinaryRefs].
     */
    fun countBinaryRefs(json: JSONObject): Int {
        var count = 0
        for (key in json.keys()) {
            count += countBinaryRefsInValue(json.opt(key))
        }
        return count
    }

    private fun countBinaryRefsInValue(value: Any?): Int = when {
        value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BINARY_REF_TYPE_MARKER -> 1
        value is JSONObject -> countBinaryRefs(value)
        value is JSONArray -> {
            var arrayCount = 0
            for (i in 0 until value.length()) {
                arrayCount += countBinaryRefsInValue(value.opt(i))
            }
            arrayCount
        }
        else -> 0
    }

    /**
     * Reads a message from an input stream (convenience wrapper).
     *
     * Returns a JSONObject with any binary attachment references resolved inline:
     * `{"__type":"binary_ref","__index":N}` markers are replaced with
     * `{"__type":"bytes","__value":"<base64>"}` markers so that callers using
     * the old API (without explicit attachment handling) still get correct data.
     */
    fun readMessage(input: InputStream): JSONObject {
        // Use the attachment-aware reader: encodeMessage frames a message that has attachments
        // as [json_length][json][num_attachments][att framing...], where the length prefix
        // covers only the JSON. readMessageFrame treats the prefix as the whole body, so it can
        // never see the attachment framing (leaving binary_ref markers unresolved AND stranding
        // the attachment bytes in the stream). readMessageFrameFromStream reads the framing
        // correctly; for a compact message (no binary refs) it returns the JSON with no
        // attachments, identical to the previous behavior.
        val frame = readMessageFrameFromStream(input)
        if (frame.attachments.isNotEmpty()) {
            resolveBinaryRefsToBase64(frame.json, frame.attachments)
        }
        return frame.json
    }

    /**
     * Walks a JSONObject tree and replaces `binary_ref` markers with `bytes`
     * markers (base64-encoded), resolving the references against the provided
     * attachment list. This allows callers that use [readMessage] (which returns
     * only a JSONObject) to still decode ByteArray values correctly.
     */
    fun resolveBinaryRefsToBase64(json: JSONObject, attachments: List<ByteArray>) {
        val keys = ArrayList<String>()
        val iter = json.keys()
        while (iter.hasNext()) keys.add(iter.next())
        for (key in keys) {
            val value = json.opt(key)
            when {
                value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BINARY_REF_TYPE_MARKER -> {
                    val index = value.getInt(BINARY_REF_INDEX_KEY)
                    val data = attachments.getOrNull(index) ?: continue
                    json.put(key, JSONObject().apply {
                        put(BYTE_ARRAY_TYPE_KEY, BYTE_ARRAY_TYPE_MARKER)
                        put(BYTE_ARRAY_VALUE_KEY, Base64.getEncoder().encodeToString(data))
                    })
                }
                value is JSONObject -> resolveBinaryRefsToBase64(value, attachments)
                value is JSONArray -> resolveBinaryRefsInArray(value, attachments)
            }
        }
    }

    private fun resolveBinaryRefsInArray(array: JSONArray, attachments: List<ByteArray>) {
        for (i in 0 until array.length()) {
            val value = array.opt(i)
            when {
                value is JSONObject && value.optString(BYTE_ARRAY_TYPE_KEY) == BINARY_REF_TYPE_MARKER -> {
                    val index = value.getInt(BINARY_REF_INDEX_KEY)
                    val data = attachments.getOrNull(index) ?: continue
                    array.put(i, JSONObject().apply {
                        put(BYTE_ARRAY_TYPE_KEY, BYTE_ARRAY_TYPE_MARKER)
                        put(BYTE_ARRAY_VALUE_KEY, Base64.getEncoder().encodeToString(data))
                    })
                }
                value is JSONObject -> resolveBinaryRefsToBase64(value, attachments)
                value is JSONArray -> resolveBinaryRefsInArray(value, attachments)
            }
        }
    }

    /** Reads and validates the JSON frame's length prefix. */
    private fun readJsonFrameLength(input: InputStream): Int {
        val lengthBytes = ByteArray(4)
        readFully(input, lengthBytes)

        val length = ByteBuffer.wrap(lengthBytes).int
        if (length <= 0) {
            throw IOException("Invalid message length: $length")
        }
        if (length > MAX_JSON_FRAME_BYTES) throw singleFrameLimitException(length)
        return length
    }

    private fun readJsonFrame(
        input: InputStream,
        length: Int,
        compactFrameLeaseHeld: Boolean,
        onInterleavedResponseStart: ((JSONObject) -> Unit)?,
        memoryBudget: MemoryBudget = processWideMemoryBudget,
        onJsonReservation: ((JsonFrameReservation) -> Unit)? = null,
    ): JSONObject {
        val reservation = if (compactFrameLeaseHeld || onJsonReservation == null) {
            null
        } else {
            JsonFrameReservation(memoryBudget, length)
        }
        val permits = if (compactFrameLeaseHeld || reservation != null) {
            null
        } else {
            acquireParseBudget(length, memoryBudget)
        }
        try {
            if (reservation != null) {
                // Hand over before admission: the owner's close settles the reservation itself.
                onJsonReservation!!.invoke(reservation)
                if (!reservation.acquire()) {
                    // The owner closed before admission. The body is drained in small pieces
                    // rather than allocated, so the closed stream still consumes the frame that
                    // was already arriving without holding parse memory for it.
                    discardFully(input, length)
                    throw jsonReservationClosed(length)
                }
            }
            val bodyBytes = ByteArray(length)
            readFully(input, bodyBytes)
            val json = parseValidatedJsonBody(bodyBytes)
            if (onInterleavedResponseStart != null &&
                json.optString("type", "") == TYPE_INTERLEAVED_RESPONSE_START
            ) {
                if (jsonContainsBinaryRefs(json)) {
                    throw IOException("An interleaved response start frame must not carry attachments")
                }
                // The outer JSON remains covered until nested parse/destination admission has
                // either transferred ownership to an assembly or rejected the response.
                onInterleavedResponseStart(json)
            }
            return json
        } finally {
            try { reservation?.close() }
            finally { if (permits != null) memoryBudget.releaseAccountedParseBudget(permits) }
        }
    }

    /**
     * Parses a JSON body after enforcing structural safety limits.
     *
     * Called from every length-prefixed message reader in the protocol
     * — `Libp2pRpcProtocol.readMessage`, `NettyStreamController.readMessage`,
     * `RelayStreamController.readMessage` — so that the underlying
     * `org.json` recursive-descent parser cannot be targeted by
     * adversarial payloads regardless of which transport delivered the
     * bytes.
     *
     * Throws `IOException` with a descriptive message if the body
     * violates `MAX_JSON_NESTING_DEPTH`, `MAX_JSON_STRING_LENGTH`, or
     * `MAX_JSON_ELEMENT_COUNT`. On success, returns the fully-parsed
     * JSONObject.
     */
    fun parseValidatedJsonBody(bodyBytes: ByteArray): JSONObject {
        validateJsonStructure(bodyBytes)
        val jsonString = String(bodyBytes, StandardCharsets.UTF_8)
        return parseJsonWireString(jsonString)
    }

    /**
     * Scans a JSON body for structural safety limits before handing it to
     * org.json. Throws IOException with a descriptive message on the first
     * violation; returns silently if the body is within all configured
     * caps.
     *
     * Byte-level scanning is safe because every JSON structural character
     * (`{` `}` `[` `]` `"` `\` `,`) is single-byte ASCII (≤ 0x7F) and UTF-8
     * encodes all non-ASCII codepoints with high-bit continuation bytes
     * (≥ 0x80) that cannot collide with structural ASCII.
     */
    private fun validateJsonStructure(bytes: ByteArray) {
        var depth = 0
        var inString = false
        var escape = false
        var stringStart = -1
        var elementCount = 0
        for (i in bytes.indices) {
            val b = bytes[i].toInt() and 0xFF
            if (inString) {
                if (escape) {
                    escape = false
                    continue
                }
                when (b) {
                    '\\'.code -> escape = true
                    '"'.code -> {
                        val stringLen = i - stringStart - 1
                        if (stringLen > MAX_JSON_STRING_LENGTH) {
                            throw IOException(
                                "Refused JSON message: string field length $stringLen exceeds " +
                                "MAX_JSON_STRING_LENGTH=$MAX_JSON_STRING_LENGTH bytes"
                            )
                        }
                        inString = false
                    }
                }
            } else {
                when (b) {
                    '"'.code -> {
                        inString = true
                        stringStart = i
                    }
                    '['.code, '{'.code -> {
                        depth++
                        if (depth > MAX_JSON_NESTING_DEPTH) {
                            throw IOException(
                                "Refused JSON message: nesting depth $depth exceeds " +
                                "MAX_JSON_NESTING_DEPTH=$MAX_JSON_NESTING_DEPTH"
                            )
                        }
                    }
                    ']'.code, '}'.code -> {
                        if (depth > 0) depth--
                    }
                    ','.code -> {
                        elementCount++
                        if (elementCount > MAX_JSON_ELEMENT_COUNT) {
                            throw IOException(
                                "Refused JSON message: element count $elementCount exceeds " +
                                "MAX_JSON_ELEMENT_COUNT=$MAX_JSON_ELEMENT_COUNT"
                            )
                        }
                    }
                }
            }
        }
        if (inString) {
            val unterminatedLen = bytes.size - stringStart - 1
            if (unterminatedLen > MAX_JSON_STRING_LENGTH) {
                throw IOException(
                    "Refused JSON message: unterminated string field length $unterminatedLen " +
                    "exceeds MAX_JSON_STRING_LENGTH=$MAX_JSON_STRING_LENGTH bytes"
                )
            }
        }
    }

    /**
     * Reads exactly [bytes.size] bytes from [input], throwing EOFException if the stream ends early.
     */
    private fun readFully(input: InputStream, bytes: ByteArray) {
        var read = 0
        while (read < bytes.size) {
            val n = input.read(bytes, read, bytes.size - read)
            if (n == -1) throw EOFException("Stream closed while reading message data (read $read of ${bytes.size} bytes)")
            read += n
        }
    }
}

/** Carries one original failure while each unwinding caller adds its own bounded segment. */
private class RpcValuePathFailure(val original: Throwable, var path: String = "") :
    RuntimeException(null, original, false, false)

/**
 * Decodes the optional additive `"metadata"` object (a flat `String -> String` map) shared
 * by [Libp2pRpcProtocol.RpcRequest] and [Libp2pRpcProtocol.RpcResponse]. Tolerant of an
 * absent or non-object field — a missing `"metadata"` decodes to an empty map — so
 * pre-metadata writers, and any relay that omits the field, deserialize cleanly. Kept as a
 * single package-level helper so request and response decoding can never drift.
 */
private fun parseMetadataMap(json: JSONObject): Map<String, String> {
    val metadataObj = json.optJSONObject("metadata") ?: return emptyMap()
    val metadata = LinkedHashMap<String, String>()
    for (key in metadataObj.keys()) {
        metadata[key] = metadataObj.optString(key)
    }
    return metadata
}

/**
 * Handler interface for processing RPC requests on the server side.
 */
interface RpcRequestHandler {
    /**
     * Handles an incoming RPC request.
     *
     * @param request The incoming request
     * @param effectHandler Handler for effects that need to be propagated to the client
     * @return The response to send back
     */
    suspend fun handleRequest(
        request: Libp2pRpcProtocol.RpcRequest,
        effectHandler: EffectPropagator
    ): Libp2pRpcProtocol.RpcResponse
}

/**
 * Interface for propagating AlgebraicEffects over the network.
 */
interface EffectPropagator {
    /**
     * Sends a RequestEffect to the remote peer and waits for a response.
     *
     * @param effectType The type name of the effect
     * @param effectData The serialized effect data
     * @return The result of handling the effect, or null if unhandled
     */
    suspend fun propagateRequestEffect(effectType: String, effectData: JSONObject): Any?

    /**
     * Sends a NotificationEffect to the remote peer.
     *
     * @param effectType The type name of the effect
     * @param effectData The serialized effect data
     */
    suspend fun propagateNotificationEffect(effectType: String, effectData: JSONObject)
}

/**
 * Interface for subscribing to remote observables.
 */
interface RemoteObservableSubscriber {
    /**
     * Subscribes to invalidation notifications for a remote observable.
     *
     * @param observableId The ID of the observable to subscribe to
     * @param onInvalidation Callback when the observable is invalidated
     * @param onValue Callback when a new value is available
     */
    fun subscribe(
        observableId: String,
        onInvalidation: (Long) -> Unit,
        onValue: (Any?, Long) -> Unit
    )

    /**
     * Unsubscribes from a remote observable.
     *
     * @param observableId The ID of the observable to unsubscribe from
     */
    fun unsubscribe(observableId: String)
}
