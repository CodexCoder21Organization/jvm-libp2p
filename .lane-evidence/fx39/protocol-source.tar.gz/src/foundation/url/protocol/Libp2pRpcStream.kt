package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.logging.MessageSeverity
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.toss
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import okio.utf8Size
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/**
 * Tossed once per transport-level RPC failure, naming the peer — and, when the connection is
 * relayed, the relay hop — that carried the failing request.
 *
 * A lost response frame or a failed request write is reported to the caller as a plain
 * `Stream closed` / `Failed to send request` error, which says nothing about which connection
 * produced it. On a relayed connection the destination peer is not the only suspect: the relay hop
 * carries the same bytes and can drop them. Without this attribution a repeated transport failure
 * cannot be tied to a specific peer or relay, so the same class of loss reads identically whether
 * one relay is dropping frames or the destination service is at fault.
 *
 * Exactly one effect is emitted per failed request — one when a request's write fails, and one
 * when a request loses its response to a stream that ended. A request that receives its response
 * emits nothing, so this never runs on the happy path.
 *
 * @property serviceIdentifier The service (protocol path) the failing stream was opened for.
 * @property remotePeerId The destination peer of the failing stream.
 * @property relayPeerId The relay hop carrying the stream, or null when the connection is direct.
 * @property requestId The request that failed.
 * @property transportCause The underlying transport failure, or null when the stream ended without
 *   one (the remote closed while the request was still in flight).
 */
class RpcTransportFailureEffect(
    val serviceIdentifier: String,
    val remotePeerId: String,
    val relayPeerId: String?,
    val requestId: String,
    val transportCause: Throwable?,
    val rootLinkDiagnostics: RootLinkDiagnostics?,
) : NotificationEffect(
    "RPC request '$requestId' for service '$serviceIdentifier' failed at the transport carried by " +
        "peer '$remotePeerId' " +
        (relayPeerId?.let { "via relay '$it'" } ?: "over a direct connection") +
        ": " +
        (transportCause?.let { "${it.javaClass.name}: ${it.message ?: "no message"}" }
            ?: "the remote closed the stream without sending a response") +
        "." + (rootLinkDiagnostics?.let { " $it" } ?: ""),
    MessageSeverity.WARNING,
    transportCause,
) {
    constructor(serviceIdentifier: String, remotePeerId: String, relayPeerId: String?, requestId: String,
        transportCause: Throwable?) : this(serviceIdentifier, remotePeerId, relayPeerId, requestId, transportCause, null)
}

/**
 * Extracts the relay hop from a dialed libp2p multiaddress.
 *
 * A relayed address names the relay before the circuit marker and the destination after it, as in
 * `/ip4/10.0.0.1/tcp/4001/p2p/<relay>/p2p-circuit/p2p/<destination>`. A direct address has no
 * circuit marker and therefore no relay hop.
 */
private fun relayPeerIdOfMultiaddress(multiaddress: String?): String? {
    if (multiaddress == null) return null
    val circuitIndex = multiaddress.indexOf("/p2p-circuit")
    if (circuitIndex < 0) return null
    val segments = multiaddress.substring(0, circuitIndex).trim('/').split('/')
    val peerSegment = segments.indexOfLast { it == "p2p" || it == "ipfs" }
    if (peerSegment < 0 || peerSegment + 1 >= segments.size) return null
    return segments[peerSegment + 1].takeIf { it.isNotBlank() }
}

/**
 * Reports [effect] to the caller and always leaves a stderr record.
 *
 * Called on the requesting thread, so a caller that installed a handler receives the effect. A
 * caller that installed none still gets the stderr line: a diagnostic must never become the reason
 * a request fails differently.
 */
private fun reportTransportFailure(effect: RpcTransportFailureEffect) {
    System.err.println("[Libp2pRpcStream] ${effect.message}")
    try {
        toss(effect)
    } catch (unhandled: UnhandledNotificationEffect) {
        if (unhandled.effect !== effect) throw unhandled
        // Swallowed deliberately: no handler is installed for this notification and the stderr
        // record above is the durable report. Rethrowing would convert a transport diagnostic
        // into a different failure for the caller than the one that actually occurred.
    }
}

/** Terminal resource ownership and physical child close can be claimed by different callers. */
private fun closeRpcControllerOnce(controller: Libp2pRpcController, closeStarted: AtomicBoolean) {
    if (closeStarted.compareAndSet(false, true)) controller.close()
}

private const val MAX_DIRECT_INTERLEAVED_RESPONSE_ASSEMBLIES = 64
private const val MAX_REJECTED_INTERLEAVED_RESPONSE_STATES = 64
private const val MAX_REJECTED_INTERLEAVED_RESPONSE_STATE_BYTES = 1024 * 1024

private fun appendCleanupFailure(primary: Throwable?, failure: Throwable): Throwable {
    if (primary == null) return failure
    if (primary !== failure) primary.addSuppressed(failure)
    return primary
}

/**
 * Runs each close once and reports the same aggregate to every concurrent or later caller.
 * A close nested on the active closing thread returns directly so it cannot wait on itself.
 */
private class RememberingCloseable(
    private vararg val resources: AutoCloseable,
) : AutoCloseable {
    private val closeStarted = AtomicBoolean(false)
    private val closeFinished = CountDownLatch(1)
    private val closeFailure = AtomicReference<Throwable?>(null)
    private val closingThread = AtomicReference<Thread?>(null)

    override fun close() {
        if (closeStarted.compareAndSet(false, true)) {
            val currentThread = Thread.currentThread()
            closingThread.set(currentThread)
            var failure: Throwable? = null
            try {
                resources.forEach { resource ->
                    try {
                        resource.close()
                    } catch (closeFailure: Throwable) {
                        failure = appendCleanupFailure(failure, closeFailure)
                    }
                }
                closeFailure.set(failure)
            } finally {
                closingThread.compareAndSet(currentThread, null)
                closeFinished.countDown()
            }
        } else if (closingThread.get() !== Thread.currentThread()) {
            var interrupted = false
            while (true) {
                try {
                    closeFinished.await()
                    break
                } catch (_: InterruptedException) {
                    interrupted = true
                }
            }
            if (interrupted) Thread.currentThread().interrupt()
        }
        closeFailure.get()?.let { failure -> throw failure }
    }
}

private fun exactDirectInterleavedIntOrNull(raw: Any?): Int? = when (raw) {
    is Byte -> raw.toInt()
    is Short -> raw.toInt()
    is Int -> raw
    is Long -> if (raw in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) raw.toInt() else null
    is java.math.BigInteger -> if (
        raw >= java.math.BigInteger.valueOf(Int.MIN_VALUE.toLong()) &&
        raw <= java.math.BigInteger.valueOf(Int.MAX_VALUE.toLong())
    ) raw.toInt() else null
    is java.math.BigDecimal -> try {
        raw.intValueExact()
    } catch (_: ArithmeticException) {
        null
    }
    is Double -> if (
        raw.isFinite() &&
        raw == Math.floor(raw) &&
        raw >= Int.MIN_VALUE.toDouble() &&
        raw <= Int.MAX_VALUE.toDouble()
    ) raw.toInt() else null
    is Float -> exactDirectInterleavedIntOrNull(raw.toDouble())
    else -> null
}

private fun readDirectInterleavedChunkPosition(
    json: org.json.JSONObject,
    field: String,
    description: String,
): Int {
    val raw = json.opt(field)
    return exactDirectInterleavedIntOrNull(raw) ?: throw IOException(
        "$description $field must be an exact 32-bit integer, but was " +
            renderDirectInterleavedJsonValue(raw),
    )
}

private fun renderDirectInterleavedJsonValue(raw: Any?): String = when (raw) {
    null, org.json.JSONObject.NULL -> "null"
    is String -> org.json.JSONObject.quote(raw)
    else -> raw.toString()
}

private fun readDirectInterleavedAttachmentLengths(
    json: org.json.JSONObject,
    responseId: String,
): IntArray {
    val lengthsJson = json.optJSONArray(
        Libp2pRpcProtocol.INTERLEAVED_RESPONSE_LENGTHS_FIELD
    ) ?: throw IOException(
        "Interleaved response start '$responseId' is missing attachment lengths"
    )
    if (lengthsJson.length() !in 1..Libp2pRpcProtocol.MAX_ATTACHMENTS) {
        throw IOException(
            "Interleaved response '$responseId' declares ${lengthsJson.length()} " +
                "attachments; the allowed range is 1..${Libp2pRpcProtocol.MAX_ATTACHMENTS}"
        )
    }
    val lengths = IntArray(lengthsJson.length())
    var aggregate = 0L
    for (index in lengths.indices) {
        val rawLength = lengthsJson.opt(index)
        val length = exactDirectInterleavedIntOrNull(rawLength)
        if (
            length == null ||
            length !in 0..Libp2pRpcProtocol.MAX_SINGLE_ATTACHMENT_BYTES
        ) {
            throw IOException(
                "Interleaved response '$responseId' attachment length $index must be " +
                    "an integer in 0.." +
                    "${Libp2pRpcProtocol.MAX_SINGLE_ATTACHMENT_BYTES}, but was " +
                    renderDirectInterleavedJsonValue(rawLength)
            )
        }
        aggregate += length.toLong()
        if (aggregate > Libp2pRpcProtocol.MAX_ATTACHMENT_AGGREGATE_BYTES) {
            throw IOException(
                "Interleaved response '$responseId' declares $aggregate attachment " +
                    "bytes, exceeding the aggregate limit " +
                    Libp2pRpcProtocol.MAX_ATTACHMENT_AGGREGATE_BYTES
            )
        }
        lengths[index] = length
    }
    return lengths
}

/**
 * An accounting and scheduling domain for memory retained while direct RPC streams decode frames
 * and assemble interleaved responses.
 *
 * Pass one instance to each [Libp2pRpcStream] that should share a memory domain. Constructing a
 * separate instance partitions those streams from UrlProtocol's process-wide default, which is
 * useful when an embedding application owns several independent workloads. Streams constructed
 * without an explicit budget continue to share the process-wide domain.
 */
class RpcStreamMemoryBudgets internal constructor(
    internal val inboundMemoryBudget: Libp2pRpcProtocol.MemoryBudget,
) {
    /** Creates an independent RPC stream memory domain. */
    constructor() : this(Libp2pRpcProtocol.MemoryBudget())

    internal data class Admission(
        val reservation: Reservation?,
        val availableBytes: Int,
        val activeAssemblies: Int,
    )

    internal data class Snapshot(
        val availableBytes: Int,
        val activeAssemblies: Int,
    )

    internal inner class Reservation internal constructor(val bytes: Int) : AutoCloseable {
        private val closed = AtomicBoolean(false)

        override fun close() {
            if (closed.compareAndSet(false, true)) release(bytes)
        }
    }

    internal val byteLimit: Int =
        (Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES -
            Libp2pRpcProtocol.INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES).coerceAtLeast(1)

    private var reservedBytes = 0
    private var activeAssemblies = 0

    @Synchronized
    internal fun tryReserve(bytes: Long): Admission {
        val available = byteLimit - reservedBytes
        if (
            bytes > available ||
            activeAssemblies >= MAX_DIRECT_INTERLEAVED_RESPONSE_ASSEMBLIES
        ) {
            return Admission(null, available, activeAssemblies)
        }
        reservedBytes += bytes.toInt()
        activeAssemblies++
        return Admission(Reservation(bytes.toInt()), byteLimit - reservedBytes, activeAssemblies)
    }

    @Synchronized
    internal fun snapshot(): Snapshot = Snapshot(
        availableBytes = byteLimit - reservedBytes,
        activeAssemblies = activeAssemblies,
    )

    @Synchronized
    private fun release(bytes: Int) {
        reservedBytes -= bytes
        activeAssemblies--
        check(reservedBytes >= 0 && activeAssemblies >= 0) {
            "Direct interleaved response accounting became negative: " +
                "reservedBytes=$reservedBytes, activeAssemblies=$activeAssemblies"
        }
    }

    /** Returns read-only accounting for frame parsing in this memory domain. */
    fun parseMemoryBudgetSnapshot(): Libp2pRpcProtocol.ParseMemoryBudgetSnapshot =
        inboundMemoryBudget.snapshot()

    internal companion object {
        val processWide = RpcStreamMemoryBudgets(
            Libp2pRpcProtocol.processWideMemoryBudget(),
        )
    }
}

/**
 * Implementation of [RpcStream] that wraps a libp2p stream controller.
 *
 * This class provides bidirectional RPC communication over a libp2p stream,
 * handling request/response correlation and background message reading.
 *
 * @property controller The underlying libp2p stream controller.
 * @property remotePeerId The peer ID of the remote service provider.
 * @property serviceIdentifier The service identifier this stream is connected to.
 * @property headers Optional headers to include with requests.
 * @property remoteAddress The multiaddress this stream was dialed at, when the caller knows it.
 *   A relayed address names the relay hop, which [relayPeerId] exposes so a transport failure can
 *   be attributed to the connection that carried it.
 * @property memoryBudgets The accounting domain for decoded frames and retained interleaved
 *   responses. The full public constructor accepts a separate domain; other construction shares
 *   UrlProtocol's process-wide domain.
 */
class Libp2pRpcStream private constructor(
    private val controller: Libp2pRpcController,
    override val remotePeerId: String,
    override val serviceIdentifier: String,
    private val headers: Map<String, String>,
    private val readResponses: Boolean,
    private val remoteAddress: String?,
    private val retainedResourceScope: RpcStreamRetainedResourceScope?,
    private val memoryBudgets: RpcStreamMemoryBudgets,
) : RpcResponseReaderOwnership, RootLinkDiagnosticSource {
    override val rootLinkDiagnostics: RootLinkDiagnostics?
        get() = (controller as? RootLinkDiagnosticSource)?.rootLinkDiagnostics


    /** Creates a stream with its reply reader selected before any input read can start. */
    constructor(
        controller: Libp2pRpcController,
        remotePeerId: String,
        serviceIdentifier: String,
        responseReader: RpcResponseReader,
        headers: Map<String, String> = emptyMap(),
        remoteAddress: String? = null,
        retainedResourceScope: RpcStreamRetainedResourceScope? = null,
        memoryBudgets: RpcStreamMemoryBudgets = RpcStreamMemoryBudgets.processWide,
    ) : this(
        controller, remotePeerId, serviceIdentifier, headers,
        responseReader == RpcResponseReader.AUTOMATIC,
        remoteAddress, retainedResourceScope, memoryBudgets,
    )

    override val ownsResponseReader: Boolean get() = readResponses

    // The address-carrying forms are separate overloads rather than an extra defaulted parameter
    // on the constructors below: a defaulted parameter changes the full-arity JVM signature, so
    // appending one would break callers already compiled against the published artifact.
    constructor(
        controller: Libp2pRpcController,
        remotePeerId: String,
        serviceIdentifier: String,
        headers: Map<String, String> = emptyMap()
    ) : this(
        controller,
        remotePeerId,
        serviceIdentifier,
        headers,
        true,
        null,
        null,
        RpcStreamMemoryBudgets.processWide,
    )

    constructor(
        controller: Libp2pRpcController,
        remotePeerId: String,
        serviceIdentifier: String,
        headers: Map<String, String>,
        remoteAddress: String?
    ) : this(
        controller,
        remotePeerId,
        serviceIdentifier,
        headers,
        true,
        remoteAddress,
        null,
        RpcStreamMemoryBudgets.processWide,
    )

    /**
     * Creates a stream whose retained response resources also participate in
     * [retainedResourceScope]. Existing constructors use only UrlProtocol's built-in bounds.
     */
    constructor(
        controller: Libp2pRpcController,
        remotePeerId: String,
        serviceIdentifier: String,
        headers: Map<String, String>,
        remoteAddress: String?,
        retainedResourceScope: RpcStreamRetainedResourceScope,
    ) : this(
        controller,
        remotePeerId,
        serviceIdentifier,
        headers,
        true,
        remoteAddress,
        retainedResourceScope,
        RpcStreamMemoryBudgets.processWide,
    )

    /**
     * Creates a stream in [memoryBudgets]' accounting domain. Supplying one domain to several
     * streams makes them share its frame and interleaved-response bounds; supplying separate
     * domains partitions those workloads. The default preserves the process-wide sharing used by
     * the existing constructors.
     *
     * [retainedResourceScope] optionally adds application-owned reservations to the same response
     * lifetimes; it does not replace the built-in [memoryBudgets] accounting.
     */
    constructor(
        controller: Libp2pRpcController,
        remotePeerId: String,
        serviceIdentifier: String,
        headers: Map<String, String>,
        remoteAddress: String?,
        retainedResourceScope: RpcStreamRetainedResourceScope? = null,
        memoryBudgets: RpcStreamMemoryBudgets = RpcStreamMemoryBudgets.processWide,
    ) : this(
        controller,
        remotePeerId,
        serviceIdentifier,
        headers,
        true,
        remoteAddress,
        retainedResourceScope,
        memoryBudgets,
    )

    internal constructor(
        controller: Libp2pRpcController,
        remotePeerId: String,
        serviceIdentifier: String,
        readResponses: Boolean
    ) : this(
        controller,
        remotePeerId,
        serviceIdentifier,
        emptyMap(),
        readResponses,
        null,
        null,
        RpcStreamMemoryBudgets.processWide,
    )

    internal constructor(
        controller: Libp2pRpcController,
        remotePeerId: String,
        serviceIdentifier: String,
        readResponses: Boolean,
        remoteAddress: String?
    ) : this(
        controller,
        remotePeerId,
        serviceIdentifier,
        emptyMap(),
        readResponses,
        remoteAddress,
        null,
        RpcStreamMemoryBudgets.processWide,
    )

    override val relayPeerId: String? = relayPeerIdOfMultiaddress(remoteAddress)

    private val closed = AtomicBoolean(false)
    private val controllerCloseStarted = AtomicBoolean(false)
    private val terminalResponseMessage = AtomicReference("Stream closed")
    private val pendingRequests = ConcurrentHashMap<String, PendingRequest>()
    private class InterleavedAdmissionRejected(
        val responseId: String,
        val expectedLengths: IntArray,
        message: String,
    ) : IOException(message)

    /**
     * One upgraded v1.1 large response assembled from complete, independently schedulable frames.
     * A combined JSON-parse and destination-byte lease is acquired before parsing or allocation and remains held
     * until the original response is complete or the stream ends. The assembly budget leaves a
     * separate 1 MiB compact-frame lane; per-chunk temporary arrays are bounded to that lane and
     * read without a second whole-pool acquisition that would wait on the assembly itself.
     */
    private class InterleavedResponseAssembly private constructor(
        val responseId: String,
        val responseJson: org.json.JSONObject,
        private val expectedLengths: IntArray,
        val lease: Libp2pRpcProtocol.FrameAttachmentLease,
        val attachments: List<ByteArray>,
        private val reservation: RpcStreamMemoryBudgets.Reservation,
        private val scopedReservation: AutoCloseable?,
    ) : AutoCloseable {
        private var attachmentIndex = 0
        private var attachmentOffset = 0
        private var closed = false

        init {
            advancePastEmptyAttachments()
        }

        fun append(json: org.json.JSONObject, frameAttachments: List<ByteArray>): Boolean {
            check(!closed) { "Cannot append to closed interleaved response '$responseId'" }
            if (frameAttachments.size != 1) {
                throw IOException(
                    "Interleaved response chunk '$responseId' must carry exactly one binary " +
                        "attachment, but carried ${frameAttachments.size}"
                )
            }
            val declaredIndex = readDirectInterleavedChunkPosition(
                json,
                Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_INDEX_FIELD,
                "Interleaved response chunk '$responseId'",
            )
            val declaredOffset = readDirectInterleavedChunkPosition(
                json,
                Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_OFFSET_FIELD,
                "Interleaved response chunk '$responseId'",
            )
            if (declaredIndex != attachmentIndex || declaredOffset != attachmentOffset) {
                throw IOException(
                    "Interleaved response chunk '$responseId' arrived out of order: expected " +
                        "attachment $attachmentIndex at offset $attachmentOffset, but received " +
                        "attachment $declaredIndex at offset $declaredOffset"
                )
            }
            if (attachmentIndex >= attachments.size) {
                throw IOException("Interleaved response '$responseId' received bytes after completion")
            }
            val chunk = frameAttachments.single()
            val remaining = expectedLengths[attachmentIndex] - attachmentOffset
            if (chunk.isEmpty() || chunk.size > remaining) {
                throw IOException(
                    "Interleaved response chunk '$responseId' has ${chunk.size} bytes, but " +
                        "$remaining bytes remain in attachment $attachmentIndex"
                )
            }
            chunk.copyInto(attachments[attachmentIndex], destinationOffset = attachmentOffset)
            attachmentOffset += chunk.size
            if (attachmentOffset == expectedLengths[attachmentIndex]) {
                attachmentIndex++
                attachmentOffset = 0
                advancePastEmptyAttachments()
            }
            return attachmentIndex == attachments.size
        }

        private fun advancePastEmptyAttachments() {
            while (
                attachmentIndex < expectedLengths.size &&
                expectedLengths[attachmentIndex] == 0
            ) {
                attachmentIndex++
            }
        }

        fun abandonedState(): RejectedInterleavedResponse = RejectedInterleavedResponse(
            responseId = responseId,
            expectedLengths = expectedLengths.copyOf(),
            attachmentIndex = attachmentIndex,
            attachmentOffset = attachmentOffset,
        )

        override fun close() {
            if (closed) return
            closed = true
            var failure: Throwable? = null
            try {
                lease.close()
            } catch (leaseFailure: Throwable) {
                failure = leaseFailure
            }
            try {
                reservation.close()
            } catch (reservationFailure: Throwable) {
                if (failure == null) failure = reservationFailure
                else failure.addSuppressed(reservationFailure)
            }
            try {
                scopedReservation?.close()
            } catch (scopedReservationFailure: Throwable) {
                failure = appendCleanupFailure(failure, scopedReservationFailure)
            }
            failure?.let { throw it }
        }

        companion object {
            fun fromStartFrame(
                json: org.json.JSONObject,
                retainedResourceScope: RpcStreamRetainedResourceScope?,
                memoryBudgets: RpcStreamMemoryBudgets,
            ): InterleavedResponseAssembly {
                val responseId = json.optString("id", "")
                if (responseId.isEmpty()) {
                    throw IOException("Interleaved response start frame is missing its response id")
                }
                val lengths = readDirectInterleavedAttachmentLengths(json, responseId)
                val aggregate = lengths.sumOf { length -> length.toLong() }
                val encodedResponse = json.optString(
                    Libp2pRpcProtocol.INTERLEAVED_RESPONSE_JSON_FIELD,
                    "",
                )
                if (encodedResponse.isEmpty()) {
                    throw IOException("Interleaved response start '$responseId' has no response JSON")
                }
                // Size UTF-8 without creating a second copy of the retained nested string.
                // One admission covers parsing and destinations; growing separate leases here
                // could wait for the reader's own unfinished assembly.
                val aggregateBytes = aggregate +
                    encodedResponse.utf8Size() * Libp2pRpcProtocol.PARSE_AMPLIFICATION
                val admission = memoryBudgets.tryReserve(aggregateBytes)
                val reservation = admission.reservation ?: throw InterleavedAdmissionRejected(
                    responseId = responseId,
                    expectedLengths = lengths,
                    message = admissionFailureMessage(
                        responseId,
                        aggregateBytes,
                        admission.availableBytes,
                        admission.activeAssemblies,
                        memoryBudgets.byteLimit,
                    ),
                )
                var lease: Libp2pRpcProtocol.FrameAttachmentLease? = null
                return try {
                    lease = Libp2pRpcProtocol.FrameAttachmentLease.forInterleavedResponse(
                        aggregateBytes,
                        memoryBudgets.inboundMemoryBudget,
                    )
                    if (!lease.tryAcquire()) {
                        val budget = memoryBudgets.snapshot()
                        val parseBudget = memoryBudgets.parseMemoryBudgetSnapshot()
                        val parseAvailable = (
                            Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES -
                                Libp2pRpcProtocol.INTERLEAVED_RESPONSE_COMPACT_PARSE_RESERVE_BYTES -
                                parseBudget.bytesReserved
                            ).coerceAtLeast(0L)
                        throw InterleavedAdmissionRejected(
                            responseId = responseId,
                            expectedLengths = lengths,
                            message = admissionFailureMessage(
                                responseId,
                                aggregateBytes,
                                minOf(budget.availableBytes + aggregateBytes, parseAvailable).toInt(),
                                budget.activeAssemblies - 1,
                                memoryBudgets.byteLimit,
                            ),
                        )
                    }
                    val responseJson = try {
                        Libp2pRpcProtocol.parseValidatedJsonBody(
                            encodedResponse.toByteArray(StandardCharsets.UTF_8)
                        )
                    } catch (failure: org.json.JSONException) {
                        // Keep malformed embedded JSON on the reader's IOException path. Letting
                        // JSONException escape ends the reader thread before it can publish the
                        // transport cause to the waiting caller.
                        throw IOException(
                            "Interleaved response start '$responseId' contains invalid response JSON",
                            failure,
                        )
                    }
                    val actualResponseType = responseJson.optString("type", "")
                    val actualResponseId = responseJson.optString("id", "")
                    if (
                        actualResponseType != Libp2pRpcProtocol.TYPE_RESPONSE ||
                        actualResponseId != responseId
                    ) {
                        throw IOException(
                            "Interleaved response start '$responseId' requires an RPC response " +
                                "envelope with type '${Libp2pRpcProtocol.TYPE_RESPONSE}' and id " +
                                "'$responseId', but received type '$actualResponseType' and id " +
                                "'$actualResponseId'"
                        )
                    }
                    Libp2pRpcProtocol.validateBinaryAttachmentEnvelope(
                        responseJson,
                        lengths.size,
                    )
                    val attachments = lengths.map { length -> ByteArray(length) }
                    // Destinations are allocated at admission, not as bytes arrive.
                    lease.updateRetainedAttachmentBytes(aggregateBytes)
                    val scopedReservation = retainedResourceScope?.retainInterleavedResponse(
                        responseId,
                        aggregateBytes,
                    )
                    InterleavedResponseAssembly(
                        responseId,
                        responseJson,
                        lengths,
                        lease,
                        attachments,
                        reservation,
                        scopedReservation,
                    )
                } catch (failure: Throwable) {
                    try {
                        lease?.close()
                    } catch (cleanupFailure: Throwable) {
                        failure.addSuppressed(cleanupFailure)
                    }
                    try {
                        reservation.close()
                    } catch (cleanupFailure: Throwable) {
                        failure.addSuppressed(cleanupFailure)
                    }
                    throw failure
                }
            }

            private fun admissionFailureMessage(
                responseId: String,
                requiredBytes: Long,
                availableBytes: Int,
                activeAssemblies: Int,
                byteLimit: Int,
            ): String =
                "Interleaved response '$responseId' requires $requiredBytes retained bytes (attachments and response JSON), " +
                    "but the direct response assembly budget has $availableBytes of " +
                    "$byteLimit bytes available across " +
                    "$activeAssemblies active " +
                    "${if (activeAssemblies == 1) "assembly" else "assemblies"}. " +
                    "The response was rejected before parsing its response JSON or allocating its attachments."
        }
    }

    private class RejectedInterleavedStateLimitExceeded(message: String) : IOException(message)

    private class RejectedInterleavedResponse(
        val responseId: String,
        expectedLengths: IntArray? = null,
        private var attachmentIndex: Int = 0,
        private var attachmentOffset: Int = 0,
    ) {
        private var expectedLengths: IntArray? = expectedLengths

        val retainedBookkeepingBytes: Long
            get() = responseId.length.toLong() * 2L +
                (expectedLengths?.size?.toLong() ?: 0L) * 4L

        init {
            advancePastEmptyAttachments()
        }

        val isComplete: Boolean
            get() = expectedLengths?.let { attachmentIndex == it.size } ?: false

        val awaitsStart: Boolean
            get() = expectedLengths == null

        fun acceptStart(lengths: IntArray) {
            check(expectedLengths == null) {
                "Rejected interleaved response '$responseId' already received its start frame"
            }
            expectedLengths = lengths
            advancePastEmptyAttachments()
        }

        fun discard(json: org.json.JSONObject, frameAttachments: List<ByteArray>) {
            val lengths = expectedLengths ?: throw IOException(
                "Rejected interleaved response chunk '$responseId' has no start frame"
            )
            if (frameAttachments.size != 1) {
                throw IOException(
                    "Rejected interleaved response chunk '$responseId' must carry exactly one " +
                        "binary attachment, but carried ${frameAttachments.size}"
                )
            }
            val declaredIndex = readDirectInterleavedChunkPosition(
                json,
                Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_INDEX_FIELD,
                "Rejected interleaved response chunk '$responseId'",
            )
            val declaredOffset = readDirectInterleavedChunkPosition(
                json,
                Libp2pRpcProtocol.INTERLEAVED_RESPONSE_ATTACHMENT_OFFSET_FIELD,
                "Rejected interleaved response chunk '$responseId'",
            )
            if (declaredIndex != attachmentIndex || declaredOffset != attachmentOffset) {
                throw IOException(
                    "Rejected interleaved response chunk '$responseId' arrived out of order: " +
                        "expected attachment $attachmentIndex at offset $attachmentOffset, but " +
                        "received attachment $declaredIndex at offset $declaredOffset"
                )
            }
            if (attachmentIndex >= lengths.size) {
                throw IOException(
                    "Rejected interleaved response '$responseId' received bytes after completion"
                )
            }
            val chunkSize = frameAttachments.single().size
            val remaining = lengths[attachmentIndex] - attachmentOffset
            if (chunkSize == 0 || chunkSize > remaining) {
                throw IOException(
                    "Rejected interleaved response chunk '$responseId' has $chunkSize bytes, but " +
                        "$remaining bytes remain in attachment $attachmentIndex"
                )
            }
            attachmentOffset += chunkSize
            if (attachmentOffset == lengths[attachmentIndex]) {
                attachmentIndex++
                attachmentOffset = 0
                advancePastEmptyAttachments()
            }
        }

        private fun advancePastEmptyAttachments() {
            val lengths = expectedLengths ?: return
            while (
                attachmentIndex < lengths.size &&
                lengths[attachmentIndex] == 0
            ) {
                attachmentIndex++
            }
        }
    }

    private val interleavedResponseAssemblies =
        HashMap<String, InterleavedResponseAssembly>()
    private val rejectedInterleavedResponses =
        HashMap<String, RejectedInterleavedResponse>()
    private var rejectedInterleavedResponseStateBytes = 0L
    private val interleavedResponseStateLock = Any()
    private var interleavedFrameCapacity: AutoCloseable? = null

    private fun updateInterleavedFrameCapacity(capacity: AutoCloseable?) {
        if (capacity != null) {
            val scopedReservation = retainedResourceScope?.retainInterleavedFrameCapacity()
            val trackedCapacity = if (scopedReservation == null) {
                capacity
            } else {
                RememberingCloseable(capacity, scopedReservation)
            }
            val detachedCapacity = synchronized(interleavedResponseStateLock) {
                if (closed.get()) {
                    trackedCapacity
                } else {
                    interleavedFrameCapacity = trackedCapacity
                    null
                }
            }
            detachedCapacity?.close()
            return
        }

        val trackedCapacity = synchronized(interleavedResponseStateLock) {
            interleavedFrameCapacity
        } ?: return
        trackedCapacity.close()
        synchronized(interleavedResponseStateLock) {
            if (interleavedFrameCapacity === trackedCapacity) {
                interleavedFrameCapacity = null
            }
        }
    }

    /** Immutable diagnostics for response assembly and abandoned-response discard state. */
    data class InterleavedResponseStateSnapshot(
        val activeAssemblies: Int,
        val rejectedResponses: Int,
        val rejectedResponseBytes: Long,
    )

    /**
     * Returns this stream's current interleaved-response accounting without changing reader state.
     */
    fun interleavedResponseStateSnapshot(): InterleavedResponseStateSnapshot =
        synchronized(interleavedResponseStateLock) {
            InterleavedResponseStateSnapshot(
                activeAssemblies = interleavedResponseAssemblies.size,
                rejectedResponses = rejectedInterleavedResponses.size,
                rejectedResponseBytes = rejectedInterleavedResponseStateBytes,
            )
        }

    private fun retainRejectedInterleavedResponse(rejected: RejectedInterleavedResponse) {
        val retainedAfterAdd =
            rejectedInterleavedResponseStateBytes + rejected.retainedBookkeepingBytes
        if (
            rejectedInterleavedResponses.size >= MAX_REJECTED_INTERLEAVED_RESPONSE_STATES ||
            retainedAfterAdd > MAX_REJECTED_INTERLEAVED_RESPONSE_STATE_BYTES
        ) {
            throw RejectedInterleavedStateLimitExceeded(
                "Interleaved response '${rejected.responseId}' cannot retain chunk-discard " +
                    "state because this stream already retains " +
                    "${rejectedInterleavedResponses.size} of " +
                    "$MAX_REJECTED_INTERLEAVED_RESPONSE_STATES allowed rejected responses and " +
                    "$rejectedInterleavedResponseStateBytes of " +
                    "$MAX_REJECTED_INTERLEAVED_RESPONSE_STATE_BYTES allowed bookkeeping bytes; " +
                    "the new state requires ${rejected.retainedBookkeepingBytes} bytes"
            )
        }
        rejectedInterleavedResponses[rejected.responseId] = rejected
        rejectedInterleavedResponseStateBytes = retainedAfterAdd
    }

    private fun removeRejectedInterleavedResponse(responseId: String) {
        val removed = rejectedInterleavedResponses.remove(responseId) ?: return
        rejectedInterleavedResponseStateBytes -= removed.retainedBookkeepingBytes
        check(rejectedInterleavedResponseStateBytes >= 0L) {
            "Rejected interleaved response bookkeeping became negative after removing " +
                "'$responseId': retainedBytes=$rejectedInterleavedResponseStateBytes"
        }
    }

    private fun acceptRejectedInterleavedResponseStart(
        rejected: RejectedInterleavedResponse,
        lengths: IntArray,
    ) {
        val retainedBefore = rejected.retainedBookkeepingBytes
        val retainedAfter = retainedBefore + lengths.size.toLong() * 4L
        val streamRetainedAfter =
            rejectedInterleavedResponseStateBytes - retainedBefore + retainedAfter
        if (streamRetainedAfter > MAX_REJECTED_INTERLEAVED_RESPONSE_STATE_BYTES) {
            throw RejectedInterleavedStateLimitExceeded(
                "Interleaved response '${rejected.responseId}' cannot retain chunk-discard " +
                    "state because this stream would retain $streamRetainedAfter of " +
                    "$MAX_REJECTED_INTERLEAVED_RESPONSE_STATE_BYTES allowed bookkeeping bytes"
            )
        }
        rejected.acceptStart(lengths)
        rejectedInterleavedResponseStateBytes = streamRetainedAfter
    }

    private fun abandonRequest(requestId: String, pending: PendingRequest) {
        // Removing the pending entry first makes start admission and abandonment deterministic:
        // a start already under the state lock completes and is removed below, while a later
        // start sees the bounded discard marker installed below.
        pendingRequests.remove(requestId, pending)
        var stateLimitFailure: RejectedInterleavedStateLimitExceeded? = null
        var detachedAssembly: InterleavedResponseAssembly? = null
        synchronized(interleavedResponseStateLock) {
            if (!closed.get()) {
                try {
                    val assembly = interleavedResponseAssemblies.remove(requestId)
                    if (assembly != null) {
                        val rejected = assembly.abandonedState()
                        detachedAssembly = assembly
                        if (!rejected.isComplete) retainRejectedInterleavedResponse(rejected)
                    } else if (
                        pending.response.get() == null &&
                        !rejectedInterleavedResponses.containsKey(requestId)
                    ) {
                        retainRejectedInterleavedResponse(RejectedInterleavedResponse(requestId))
                    }
                } catch (failure: RejectedInterleavedStateLimitExceeded) {
                    stateLimitFailure = failure
                    // Publish the complete terminal outcome and clear all discard bookkeeping
                    // before another close or caller can observe the stream. The controller close
                    // remains outside this lock.
                    closedLocally.set(true)
                    terminalResponseMessage.compareAndSet("Stream closed", failure.message)
                    closed.set(true)
                    rejectedInterleavedResponses.clear()
                    rejectedInterleavedResponseStateBytes = 0L
                }
            }
        }
        try {
            detachedAssembly?.close()
        } catch (closeFailure: Throwable) {
            val limitFailure = stateLimitFailure
            if (limitFailure == null) throw closeFailure
            limitFailure.addSuppressed(closeFailure)
        }
        stateLimitFailure?.let { failure ->
            closeForRejectedInterleavedStateLimit(failure)
            throw failure
        }
    }

    private data class InterleavedResponsesToClose(
        val firstClose: Boolean,
        val frameCapacity: AutoCloseable?,
        val assemblies: List<InterleavedResponseAssembly>,
    )

    private data class InterleavedResponsesCloseResult(
        val firstClose: Boolean,
        val failure: Throwable?,
    )

    private fun closeDetachedInterleavedAssembly(assembly: InterleavedResponseAssembly) {
        var failure: Throwable? = null
        try {
            assembly.close()
        } catch (closeFailure: Throwable) {
            failure = closeFailure
        }
        failure?.let { throw it }
    }

    private fun closeInterleavedResponses(
        terminalMessage: String? = null,
        onTerminalState: () -> Unit = {},
        closeControllerBeforeResources: Boolean = false,
    ): InterleavedResponsesCloseResult {
        val detached = synchronized(interleavedResponseStateLock) {
            if (terminalMessage != null) {
                terminalResponseMessage.compareAndSet("Stream closed", terminalMessage)
            }
            val firstClose = closed.compareAndSet(false, true)
            val frameCapacity = interleavedFrameCapacity
            interleavedFrameCapacity = null
            val assemblies = interleavedResponseAssemblies.values.toList()
            interleavedResponseAssemblies.clear()
            rejectedInterleavedResponses.clear()
            rejectedInterleavedResponseStateBytes = 0L
            InterleavedResponsesToClose(firstClose, frameCapacity, assemblies)
        }
        var cleanupFailure: Throwable? = null
        fun attemptClose(close: () -> Unit) {
            try {
                close()
            } catch (failure: Throwable) {
                cleanupFailure = appendCleanupFailure(cleanupFailure, failure)
            }
        }
        // Claim native close ownership before releasing a deadline caller. Its automatic
        // stream cleanup must not become the first closer and run controller cleanup itself.
        // Publish the timeout before closing admission can wake a waiting writer as well.
        onTerminalState()
        // A native writer wakes only when its child closes. Deadline cleanup must do that
        // before any retained-resource hook can block, throw, or re-enter this stream.
        if (closeControllerBeforeResources) {
            attemptClose { closeRpcControllerOnce(controller, controllerCloseStarted) }
        }
        attemptClose { closeRpcControllerFrameAdmission(controller) }
        detached.frameCapacity?.let { frameCapacity ->
            attemptClose { frameCapacity.close() }
        }
        detached.assemblies.forEach { assembly ->
            attemptClose { closeDetachedInterleavedAssembly(assembly) }
        }
        return InterleavedResponsesCloseResult(detached.firstClose, cleanupFailure)
    }

    private fun closeForRejectedInterleavedStateLimit(
        failure: RejectedInterleavedStateLimitExceeded,
    ) {
        closedLocally.set(true)
        try {
            closeInterleavedResponses(failure.message).failure?.let { closeFailure ->
                appendCleanupFailure(failure, closeFailure)
            }
        } catch (closeFailure: Exception) {
            appendCleanupFailure(failure, closeFailure)
        }
        try {
            closeRpcControllerOnce(controller, controllerCloseStarted)
        } catch (closeFailure: Exception) {
            failure.addSuppressed(closeFailure)
        }
        readerThread?.interrupt()
    }

    /** The transport failure that ended the reader, retained so a lost request can name it. */
    private val readerTransportCause = AtomicReference<Throwable?>(null)

    /**
     * Set when this side closed the stream. A request cancelled by a local close is not a
     * transport failure and must not be attributed to the peer or its relay.
     */
    private val closedLocally = AtomicBoolean(false)

    // The reader's in-flight growable attachment-frame lease and JSON parse reservation, handed
    // over before either asks for pool admission so that close() settles them itself instead of
    // leaving them to a reader that close() does not wait for.
    private val activeGrowingFrameLease = AtomicReference<Libp2pRpcProtocol.FrameAttachmentLease?>(null)
    private val activeJsonReservation = AtomicReference<Libp2pRpcProtocol.JsonFrameReservation?>(null)

    private val readerThread: Thread?

    // Every field the reader loop touches is declared above this block on purpose. Property
    // initializers run in declaration order, so a field declared below it is still null while
    // the reader thread started here is already running, and a controller whose input is
    // already at end of stream reaches the reader's cleanup path immediately.
    init {
        readerThread = if (readResponses) {
            thread(name = "Libp2pRpcStream-Reader", isDaemon = true) {
                runReaderLoop()
            }
        } else {
            null
        }
    }

    private data class PendingRequest(
        val latch: CountDownLatch,
        val response: AtomicReference<Libp2pRpcProtocol.RpcResponse?> = AtomicReference(null),
        /** A retiring-root terminal response is released only after the parent close completes. */
        val completeAfterParentClose: AtomicBoolean = AtomicBoolean(false),
        /**
         * Set by the reader when this request's response was lost to a transport failure rather
         * than answered, and the loss was not this side's own [close]. The requesting thread reads
         * it to report the failure from a context that can actually reach the caller's effect
         * handlers; the reader thread cannot.
         */
        val lostToTransportFailure: AtomicBoolean = AtomicBoolean(false),
        /** Identity observed when the deadline wins, before its child cleanup changes the live inventory. */
        val timeoutRootLinkDiagnostics: AtomicReference<RootLinkDiagnostics?> = AtomicReference(null),
        /** The getter failure published before the timed-out flag, independently of later close failures. */
        val timeoutDiagnosticFailure: AtomicReference<Throwable?> = AtomicReference(null),
        /** A timeout callback's diagnostic or close failure reaches the waiting caller after wake-up. */
        val timeoutCleanupFailure: AtomicReference<Throwable?> = AtomicReference(null),
        /** Selects whether a close failure belongs to the caller result or a later transport report. */
        val timeoutFailureLock: Any = Any(),
        var timeoutResultSelected: Boolean = false,
    )

    override val input: InputStream
        get() = controller.input.let { input ->
            if (serviceIdentifier == GossipProtocol.PROTOCOL_ID) {
                GossipInputStream(input, ::validateLibp2pWithdrawalPeerId)
            } else input
        }

    override val output: OutputStream = object : OutputStream() {
        override fun write(value: Int) {
            withRpcControllerRawOutput(controller) { it.write(value) }
        }
        override fun write(bytes: ByteArray, offset: Int, length: Int) {
            withRpcControllerRawOutput(controller) { it.write(bytes, offset, length) }
        }
        override fun flush() {
            withRpcControllerRawOutput(controller) { it.flush() }
        }
        override fun close() = this@Libp2pRpcStream.close()
    }

    override val isOpen: Boolean
        get() = !closed.get()

    override fun sendRequest(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        sendRequest(request, DEFAULT_RESPONSE_TIMEOUT_MS, DEFAULT_RESPONSE_CLOCK)

    internal fun sendRequest(
        request: Libp2pRpcProtocol.RpcRequest,
        responseTimeoutMs: Long,
        clock: Clock
    ): Libp2pRpcProtocol.RpcResponse {
        require(responseTimeoutMs > 0L) {
            "responseTimeoutMs must be greater than zero, but was $responseTimeoutMs."
        }
        check(readResponses) {
            "Cannot use sendRequest on raw network protocol stream '$serviceIdentifier'; read and write the RpcStream input/output directly."
        }
        if (closed.get()) {
            return closedResponse(request.id)
        }

        val pending = PendingRequest(CountDownLatch(1))
        pendingRequests[request.id] = pending
        val timedOut = AtomicBoolean(false)
        val timeoutTask = clock.schedule(clock.currentTimeMillis() + responseTimeoutMs) {
            if (pendingRequests.remove(request.id, pending)) {
                try {
                    pending.timeoutRootLinkDiagnostics.set(rootLinkDiagnostics)
                } catch (failure: Throwable) {
                    pending.timeoutDiagnosticFailure.set(failure)
                    pending.timeoutCleanupFailure.set(failure)
                }
                try {
                    close(closeControllerBeforeResources = true) {
                        // Terminal state is already published; arbitrary cleanup has not begun.
                        timedOut.set(true)
                        pending.latch.countDown()
                    }
                } catch (failure: Throwable) {
                    val reportLateFailure = synchronized(pending.timeoutFailureLock) {
                        if (pending.timeoutResultSelected) {
                            true
                        } else {
                            pending.timeoutCleanupFailure.set(
                                appendCleanupFailure(pending.timeoutCleanupFailure.get(), failure)
                            )
                            false
                        }
                    }
                    if (reportLateFailure) {
                        reportTransportFailure(
                            RpcTransportFailureEffect(
                                serviceIdentifier = serviceIdentifier,
                                remotePeerId = remotePeerId,
                                relayPeerId = relayPeerId,
                                requestId = request.id,
                                transportCause = failure,
                                rootLinkDiagnostics = pending.timeoutRootLinkDiagnostics.get(),
                            )
                        )
                    }
                } finally {
                    pending.latch.countDown()
                }
            }
        }
        var requestAbandonedForInterruption = false
        var primaryFailure: Throwable? = null

        // Re-check closed after registering to avoid TOCTOU race: the reader thread
        // may have exited and drained pendingRequests between our first check and
        // the put above, so this entry would never be completed.
        if (closed.get()) {
            clock.unschedule(timeoutTask)
            pendingRequests.remove(request.id)
            return closedResponse(request.id)
        }

        try {
            val supportsAttachments = controller.negotiatedProtocolId == Libp2pRpcProtocol.PROTOCOL_ID_V11
            val attachments = if (supportsAttachments) mutableListOf<ByteArray>() else null
            val json = request.toJson(attachments)
            try {
                if (supportsAttachments) {
                    // This is a top-level extension field rather than public request metadata.
                    // An older v1.1 server ignores it without exposing a transport detail to the
                    // application handler, while an upgraded server can safely split a large
                    // response into complete frames.
                    json.put(Libp2pRpcProtocol.INTERLEAVED_RESPONSE_CAPABILITY_FIELD, true)
                }
                // Refuse, before anything is written, a request every receiver would refuse (and
                // close the stream over): the caller gets an IllegalArgumentException naming why.
                val jsonBytes = jsonWireBytes(json)
                Libp2pRpcProtocol.checkJsonWireStructure(jsonBytes)
                writeRpcControllerMessage(controller, jsonBytes, attachments ?: emptyList())
            } catch (e: java.io.IOException) {
                primaryFailure = e
                pendingRequests.remove(request.id)
                if (timedOut.get()) {
                    // The deadline publishes its snapshot/getter failure before timedOut.
                    // Take any close failure already recorded, without waiting for user cleanup.
                    val timeoutFailure = synchronized(pending.timeoutFailureLock) {
                        pending.timeoutResultSelected = true
                        pending.timeoutCleanupFailure.get()
                    }
                    val timeoutCause = timeoutFailure?.let { failure -> appendCleanupFailure(failure, e) } ?: e
                    if (pending.timeoutDiagnosticFailure.get() != null) throw timeoutCause
                    return timeoutResponse(request, responseTimeoutMs, pending.timeoutRootLinkDiagnostics.get(), timeoutCause)
                }
                // A write that failed because this side closed the stream underneath it is this
                // caller's own cancellation, not the peer's transport failure, and naming the peer
                // for it would put false hops into the very report used to find a bad one. The
                // lost-response path below applies the same rule.
                if (!closedLocally.get()) {
                    // The returned error keeps its established wording; the attribution that names
                    // which connection dropped the write goes to the report, not the caller's
                    // message.
                    reportTransportFailure(
                        RpcTransportFailureEffect(
                            serviceIdentifier = serviceIdentifier,
                            remotePeerId = remotePeerId,
                            relayPeerId = relayPeerId,
                            requestId = request.id,
                            transportCause = e,
                            rootLinkDiagnostics = rootLinkDiagnostics,
                        )
                    )
                }
                return localTransportFailureResponse(
                    request.id,
                    "Failed to send request: ${e.message}",
                    RpcTransportFailure.Phase.REQUEST_WRITE,
                    e,
                    rootLinkDiagnostics = rootLinkDiagnostics,
                )
            }

            // The caller's Clock owns the whole response budget. A ManualClock therefore cannot
            // expire because wall time passed, and a budget above the historical 30-second default
            // remains usable end to end. The scheduled callback closes the controller as well as
            // releasing this latch before controller cleanup: a reader parked in an attachment
            // frame still unwinds on physical child close and releases its whole-pool lease.
            pending.latch.await()
            if (timedOut.get()) {
                pendingRequests.remove(request.id)
                val timeoutFailure = synchronized(pending.timeoutFailureLock) {
                    pending.timeoutResultSelected = true
                    pending.timeoutCleanupFailure.get()
                }
                if (pending.timeoutDiagnosticFailure.get() != null) throw checkNotNull(timeoutFailure)
                return timeoutResponse(request, responseTimeoutMs, pending.timeoutRootLinkDiagnostics.get(), timeoutFailure)
            }

            if (pending.lostToTransportFailure.get()) {
                // Reported here rather than on the reader thread: this is the thread the caller
                // owns, so an installed effect handler can actually receive it. The returned
                // error keeps its established wording; the attribution goes to the report.
                reportTransportFailure(
                    RpcTransportFailureEffect(
                        serviceIdentifier = serviceIdentifier,
                        remotePeerId = remotePeerId,
                        relayPeerId = relayPeerId,
                        requestId = request.id,
                        transportCause = readerTransportCause.get(),
                        rootLinkDiagnostics = rootLinkDiagnostics,
                    )
                )
            }

            return pending.response.get() ?: localTransportFailureResponse(
                request.id,
                "Response was null",
                RpcTransportFailure.Phase.RESPONSE_READ,
                null,
            )
        } catch (interrupted: InterruptedException) {
            primaryFailure = interrupted
            requestAbandonedForInterruption = true
            try {
                abandonRequest(request.id, pending)
            } catch (cleanupFailure: Throwable) {
                interrupted.addSuppressed(cleanupFailure)
            }
            Thread.currentThread().interrupt()
            throw interrupted
        } catch (failure: Throwable) {
            primaryFailure = failure
            throw failure
        } finally {
            var cleanupFailure: Throwable? = null
            // A controller may translate an interrupted write into IOException.
            if (
                Thread.currentThread().isInterrupted &&
                !requestAbandonedForInterruption
            ) {
                try {
                    abandonRequest(request.id, pending)
                } catch (failure: Throwable) {
                    cleanupFailure = failure
                }
            }
            try {
                clock.unschedule(timeoutTask)
            } catch (failure: Throwable) {
                val earlierCleanupFailure = cleanupFailure
                if (earlierCleanupFailure == null) {
                    cleanupFailure = failure
                } else {
                    earlierCleanupFailure.addSuppressed(failure)
                }
            }
            pendingRequests.remove(request.id)
            cleanupFailure?.let { failure ->
                val primary = primaryFailure
                if (primary == null) throw failure
                primary.addSuppressed(failure)
            }
        }
    }

    private fun closedResponse(requestId: String): Libp2pRpcProtocol.RpcResponse =
        localTransportFailureResponse(
            requestId,
            terminalResponseMessage.get(),
            RpcTransportFailure.Phase.CONNECTION_CLOSED,
            readerTransportCause.get(),
            rootLinkDiagnostics = rootLinkDiagnostics,
        )

    private fun timeoutResponse(
        request: Libp2pRpcProtocol.RpcRequest,
        responseTimeoutMs: Long,
        linkDiagnostics: RootLinkDiagnostics?,
        cause: Throwable? = null,
    ): Libp2pRpcProtocol.RpcResponse = localTransportFailureResponse(
        request.id,
        "Request timed out after $responseTimeoutMs ms",
        RpcTransportFailure.Phase.RESPONSE_TIMEOUT,
        cause,
        Libp2pRpcProtocol.ERROR_TIMEOUT,
        rootLinkDiagnostics = linkDiagnostics,
    )

    override suspend fun sendRequestAsync(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse {
        // For now, delegate to synchronous version
        // TODO: Implement true async with coroutines
        return sendRequest(request)
    }

    private fun runReaderLoop() {
        // Retained so the terminating transport failure can be named in the report below. Without
        // it the cause was discarded at the catch and every lost response looked identical.
        var transportCause: Throwable? = null
        try {
            while (!closed.get()) {
                try {
                    Libp2pRpcProtocol.readMessageFrameFromStream(
                        controller.input,
                        {
                            synchronized(interleavedResponseStateLock) {
                                interleavedResponseAssemblies.values.firstOrNull()?.lease
                            }
                        },
                        onInterleavedResponseStart = { json ->
                            handleIncomingMessage(json, emptyList())
                        },
                        onFrameCapacityChanged = ::updateInterleavedFrameCapacity,
                        onMessageFrame = { frame ->
                            if (frame.json.optString("type", "") !=
                                Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_START
                            ) {
                                handleIncomingMessage(frame.json, frame.attachments)
                            }
                        },
                        memoryBudget = memoryBudgets.inboundMemoryBudget,
                        onGrowingFrameLease = ::publishGrowingFrameLease,
                        onJsonReservation = ::publishJsonReservation,
                    ) { json ->
                        synchronized(interleavedResponseStateLock) {
                            when (json.optString("type", "")) {
                                Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_CHUNK -> {
                                    val id = json.optString("id", "")
                                    interleavedResponseAssemblies[id]?.lease
                                        ?: if (rejectedInterleavedResponses.containsKey(id)) {
                                            interleavedResponseAssemblies.values.firstOrNull()?.lease
                                        } else {
                                            null
                                        }
                                }
                                // A compact binary response is at most the sender's 1 MiB single-frame
                                // threshold. Charge its temporary body to the lane deliberately left
                                // beside the active assembly so small ByteArray replies can pass too.
                                Libp2pRpcProtocol.TYPE_RESPONSE ->
                                    interleavedResponseAssemblies.values.firstOrNull()?.lease
                                else -> null
                            }
                        }
                    }
                } catch (e: java.io.EOFException) {
                    // Stream closed by remote side
                    transportCause = e
                    break
                } catch (e: java.io.IOException) {
                    if (!closed.get()) {
                        // Unexpected error
                        transportCause = e
                        break
                    }
                } finally {
                    activeGrowingFrameLease.set(null)
                    activeJsonReservation.set(null)
                }
            }
        } finally {
            var terminalCleanupFailure: Throwable? = null
            var closeResult: InterleavedResponsesCloseResult? = null
            fun recordCleanupFailure(failure: Throwable) {
                terminalCleanupFailure = appendCleanupFailure(terminalCleanupFailure, failure)
            }

            try {
                val result = closeInterleavedResponses()
                closeResult = result
                result.failure?.let { failure ->
                    recordCleanupFailure(failure)
                }
            } catch (failure: Throwable) {
                recordCleanupFailure(failure)
            }

            if (closeResult?.firstClose == true) {
                try {
                    closeRpcControllerOnce(controller, controllerCloseStarted)
                } catch (failure: Throwable) {
                    recordCleanupFailure(failure)
                }
            }

            // Publish the terminating cause before releasing anyone, so a request thread that
            // wakes to a lost response can name what ended its stream.
            try {
                readerTransportCause.set(transportCause)
            } catch (failure: Throwable) {
                recordCleanupFailure(failure)
            }

            // Complete any pending requests with error
            try {
                for ((id, pending) in pendingRequests) {
                    var completeLatch = false
                    try {
                        // A response can be parsed just before EOF reaches this cleanup path. Preserve
                        // that completed response; replacing it with Stream closed races the request
                        // thread after its latch has already been released.
                        val lost = pending.response.compareAndSet(
                            null,
                            closedResponse(id)
                        )
                        // Only a request that genuinely lost its response is a transport failure. A close
                        // with nothing in flight, or one that raced an already-parsed response, reports
                        // nothing, which keeps this off the happy path.
                        //
                        // Whether the loss is attributable is decided here, at the instant it is recorded,
                        // rather than by the requesting thread once it wakes: a close() landing inside that
                        // wake-up window would otherwise suppress a report for a request the remote had
                        // already lost.
                        if (lost && !closedLocally.get()) pending.lostToTransportFailure.set(true)
                        completeLatch = lost || !pending.completeAfterParentClose.get()
                    } catch (failure: Throwable) {
                        recordCleanupFailure(failure)
                        // If recording the terminal response itself fails, no later parent-close
                        // callback can be relied on to release this caller.
                        completeLatch = true
                    }
                    if (completeLatch) {
                        try {
                            pending.latch.countDown()
                        } catch (failure: Throwable) {
                            recordCleanupFailure(failure)
                        }
                    }
                }
            } catch (failure: Throwable) {
                recordCleanupFailure(failure)
            } finally {
                try {
                    pendingRequests.clear()
                } catch (failure: Throwable) {
                    recordCleanupFailure(failure)
                }
            }
            terminalCleanupFailure?.let { failure ->
                throw failure
            }
        }
    }

    private fun handleIncomingMessage(json: org.json.JSONObject, attachments: List<ByteArray>) {
        if (closed.get()) return
        val type = json.optString("type", "")
        if (type == Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_START) {
            handleInterleavedResponseStart(json, attachments)
            return
        }

        // Parse the public response before taking the interleaved-state lock. The locked section
        // only publishes state and detaches resources; parsing and every resulting close or caller
        // completion remain outside it.
        val parsedResponse = if (type == Libp2pRpcProtocol.TYPE_RESPONSE) {
            Libp2pRpcProtocol.RpcResponse.fromJson(json, attachments)
        } else {
            null
        }
        val actions = synchronized(interleavedResponseStateLock) {
            if (closed.get()) emptyList()
            else handleIncomingMessageWhileLocked(json, attachments, parsedResponse)
        }
        actions.forEach { action -> action() }
    }

    private data class PreparedInterleavedResponseStart(
        val assembly: InterleavedResponseAssembly? = null,
        val rejection: InterleavedAdmissionRejected? = null,
    )

    private fun handleInterleavedResponseStart(
        json: org.json.JSONObject,
        attachments: List<ByteArray>,
    ) {
        if (attachments.isNotEmpty()) {
            throw IOException("An interleaved response start frame must not carry attachments")
        }
        val id = json.optString("id", "")
        val handledWithoutPreparation = synchronized(interleavedResponseStateLock) {
            if (closed.get()) {
                true
            } else {
                val abandonedBeforeStart = rejectedInterleavedResponses[id]
                    ?.takeIf { rejected -> rejected.awaitsStart }
                if (abandonedBeforeStart != null) {
                    val lengths = readDirectInterleavedAttachmentLengths(json, id)
                    acceptRejectedInterleavedResponseStart(abandonedBeforeStart, lengths)
                    if (abandonedBeforeStart.isComplete) {
                        removeRejectedInterleavedResponse(id)
                    }
                    true
                } else {
                    if (!pendingRequests.containsKey(id)) {
                        throw IOException("Interleaved response start '$id' has no pending request")
                    }
                    if (
                        interleavedResponseAssemblies.containsKey(id) ||
                        rejectedInterleavedResponses.containsKey(id)
                    ) {
                        throw IOException("Interleaved response '$id' started more than once")
                    }
                    false
                }
            }
        }
        if (handledWithoutPreparation) return

        // Preparation can allocate and can release a partially acquired lease on failure. Keep all
        // of that work outside the stream-state lock, then re-check the state before publishing it.
        val prepared = try {
            PreparedInterleavedResponseStart(
                assembly = InterleavedResponseAssembly.fromStartFrame(
                    json,
                    retainedResourceScope,
                    memoryBudgets,
                )
            )
        } catch (rejected: InterleavedAdmissionRejected) {
            PreparedInterleavedResponseStart(rejection = rejected)
        } catch (failure: Throwable) {
            throw failure
        }
        var assemblyPublished = false
        val actions = try {
            synchronized(interleavedResponseStateLock) {
                val assembly = prepared.assembly
                if (closed.get()) {
                    if (assembly == null) emptyList()
                    else listOf({ assembly.close() })
                } else {
                    val abandonedDuringPreparation = rejectedInterleavedResponses[id]
                        ?.takeIf { rejected -> rejected.awaitsStart }
                    if (abandonedDuringPreparation != null) {
                        val lengths = prepared.rejection?.expectedLengths
                            ?: readDirectInterleavedAttachmentLengths(json, id)
                        acceptRejectedInterleavedResponseStart(
                            abandonedDuringPreparation,
                            lengths,
                        )
                        if (abandonedDuringPreparation.isComplete) {
                            removeRejectedInterleavedResponse(id)
                        }
                        if (assembly == null) emptyList()
                        else listOf({ assembly.close() })
                    } else {
                        if (!pendingRequests.containsKey(id)) {
                            throw IOException(
                                "Interleaved response start '$id' has no pending request"
                            )
                        }
                        if (
                            interleavedResponseAssemblies.containsKey(id) ||
                            rejectedInterleavedResponses.containsKey(id)
                        ) {
                            throw IOException("Interleaved response '$id' started more than once")
                        }

                        val rejected = prepared.rejection
                        if (rejected != null) {
                            val discarded = RejectedInterleavedResponse(
                                rejected.responseId,
                                rejected.expectedLengths,
                            )
                            if (!discarded.isComplete) {
                                retainRejectedInterleavedResponse(discarded)
                            }
                            val pending = pendingRequests[rejected.responseId]
                            if (pending == null) {
                                emptyList()
                            } else {
                                pending.response.set(
                                    localTransportFailureResponse(
                                        rejected.responseId,
                                        rejected.message
                                            ?: "Direct response assembly admission failed.",
                                        RpcTransportFailure.Phase.RESPONSE_READ,
                                        null,
                                    )
                                )
                                listOf({ pending.latch.countDown() })
                            }
                        } else {
                            check(assembly != null) {
                                "Prepared interleaved response start '$id' has no outcome"
                            }
                            if (assembly.attachments.all { attachment -> attachment.isEmpty() }) {
                                listOf(
                                    { assembly.close() },
                                    {
                                        handleIncomingMessage(
                                            assembly.responseJson,
                                            assembly.attachments,
                                        )
                                    },
                                )
                            } else {
                                interleavedResponseAssemblies[id] = assembly
                                assemblyPublished = true
                                emptyList()
                            }
                        }
                    }
                }
            }
        } catch (failure: Throwable) {
            val assembly = prepared.assembly
            if (assembly != null && !assemblyPublished) {
                try {
                    assembly.close()
                } catch (closeFailure: Throwable) {
                    failure.addSuppressed(closeFailure)
                }
            }
            throw failure
        }
        actions.forEach { action -> action() }
    }

    private fun handleIncomingMessageWhileLocked(
        json: org.json.JSONObject,
        attachments: List<ByteArray>,
        parsedResponse: Libp2pRpcProtocol.RpcResponse?,
    ): List<() -> Unit> {
        val actions = mutableListOf<() -> Unit>()
        val type = json.optString("type", "")
        if (type == Libp2pRpcProtocol.TYPE_INTERLEAVED_RESPONSE_CHUNK) {
            val id = json.optString("id", "")
            val assembly = interleavedResponseAssemblies[id]
            if (assembly != null) {
                if (assembly.append(json, attachments)) {
                    interleavedResponseAssemblies.remove(id)
                    actions += { assembly.close() }
                    actions += {
                        handleIncomingMessage(assembly.responseJson, assembly.attachments)
                    }
                }
            } else {
                val rejected = rejectedInterleavedResponses[id]
                    ?: throw IOException("Interleaved response chunk '$id' has no start frame")
                rejected.discard(json, attachments)
                if (rejected.isComplete) removeRejectedInterleavedResponse(id)
            }
        } else if (type == Libp2pRpcProtocol.TYPE_RESPONSE) {
            val id = json.optString("id", "")
            // A terminal response may replace an admitted large transfer when its writer cannot
            // continue. Release that partial assembly before exposing the terminal outcome.
            interleavedResponseAssemblies.remove(id)?.let { assembly ->
                actions += { assembly.close() }
            }
            removeRejectedInterleavedResponse(id)
            val pending = pendingRequests[id]
            if (pending != null) {
                val response = checkNotNull(parsedResponse) {
                    "Parsed response is required for terminal RPC response '$id'"
                }
                val rootRetiring =
                    response.metadata[AWAITED_RESPONSE_ROOT_RETIRING_METADATA_KEY] ==
                        AWAITED_RESPONSE_ROOT_RETIRING_METADATA_TRUE
                val publicResponse = if (
                    AWAITED_RESPONSE_ROOT_RETIRING_METADATA_KEY in response.metadata
                ) {
                    response.copy(
                        metadata = response.metadata - AWAITED_RESPONSE_ROOT_RETIRING_METADATA_KEY
                    )
                } else {
                    response
                }
                // The response now belongs to the pending caller. Release frame storage before
                // waking that caller, so a completed request observes terminal accounting.
                interleavedFrameCapacity?.let { capacity ->
                    actions += { capacity.close() }
                }
                interleavedFrameCapacity = null
                if (rootRetiring) {
                    recordRemoteRootRetirement(controller, response.error?.message
                        ?: "The remote reported that the root link is retiring.")
                    // Stalled-root retirement writes every terminal response before closing the
                    // physical connection. Do not expose one of those responses while the old
                    // root is still selectable by Host.newStream; its close future is the same
                    // predicate jvm-libp2p's connection pool uses to exclude it. The response is
                    // already parsed and retained, so completing after parent close cannot turn it
                    // into the bare end-of-stream outcome this terminal frame replaces.
                    pending.completeAfterParentClose.set(true)
                    pending.response.set(publicResponse)
                    actions += {
                        completeRpcResponseAfterParentClose(controller) {
                            pending.latch.countDown()
                        }
                    }
                } else {
                    pending.response.set(publicResponse)
                    actions += { pending.latch.countDown() }
                }
            }
        }
        // Other message types are ignored
        return actions
    }

    private fun publishGrowingFrameLease(lease: Libp2pRpcProtocol.FrameAttachmentLease) {
        activeGrowingFrameLease.set(lease)
        // close() sets `closed` before it reads the published lease, so either it sees this lease
        // or this check sees `closed`; a lease published after close() looked is closed here.
        if (closed.get()) lease.close()
    }

    private fun publishJsonReservation(reservation: Libp2pRpcProtocol.JsonFrameReservation) {
        activeJsonReservation.set(reservation)
        if (closed.get()) reservation.close()
    }

    override fun close() {
        close {}
    }

    private fun close(
        closeControllerBeforeResources: Boolean = false,
        onTerminalState: () -> Unit,
    ) {
        closedLocally.set(true)
        val closeResult = closeInterleavedResponses(
            onTerminalState = onTerminalState,
            closeControllerBeforeResources = closeControllerBeforeResources,
        )
        var cleanupFailure = closeResult.failure
        // Every close caller settles the reader's handed-over admissions; each close below
        // returns only after its release is complete.
        try {
            activeJsonReservation.get()?.close()
        } catch (failure: Throwable) {
            cleanupFailure = appendCleanupFailure(cleanupFailure, failure)
        }
        try {
            activeGrowingFrameLease.get()?.close()
        } catch (failure: Throwable) {
            cleanupFailure = appendCleanupFailure(cleanupFailure, failure)
        }
        if (closeResult.firstClose) {
            if (!closeControllerBeforeResources) {
                try {
                    closeRpcControllerOnce(controller, controllerCloseStarted)
                } catch (failure: Throwable) {
                    cleanupFailure = appendCleanupFailure(cleanupFailure, failure)
                }
            }
            try {
                readerThread?.interrupt()
            } catch (failure: Throwable) {
                cleanupFailure = appendCleanupFailure(cleanupFailure, failure)
            }
        }
        cleanupFailure?.let { failure -> throw failure }
    }

    private companion object {
        const val DEFAULT_RESPONSE_TIMEOUT_MS = 30_000L
        val DEFAULT_RESPONSE_CLOCK: Clock = SystemClock()
    }
}
