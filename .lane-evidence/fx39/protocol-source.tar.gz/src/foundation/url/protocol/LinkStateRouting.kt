package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.util.PriorityQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

/**
 * A link-state advertisement carrying only the origin node's directly observed
 * adjacencies. Other nodes flood this unchanged and compute their own SPF table.
 */
data class LinkStateAdvertisement(
    val originPeerId: String,
    val sequenceNumber: Long,
    val links: List<Link>,
    val timestampMs: Long = System.currentTimeMillis(),
    val ttlMs: Long = DEFAULT_LSA_TTL_MS
) {
    data class Link(
        val peerId: String,
        val cost: Long
    ) {
        init {
            require(peerId.isNotBlank()) {
                "Invalid link-state link peer ID: peer ID must not be blank."
            }
            require(cost > 0) {
                "Invalid link-state link cost for peer '$peerId': cost was $cost, but link costs must be positive."
            }
        }

        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("peerId", peerId)
                put("cost", cost)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): Link {
                val peerId = json.optString("peerId", "")
                val cost = json.optLong("cost", Long.MIN_VALUE)
                if (peerId.isBlank()) {
                    throw IllegalArgumentException(
                        "Invalid link-state link JSON: field 'peerId' was blank or missing, but every link must name a peer."
                    )
                }
                if (cost <= 0) {
                    throw IllegalArgumentException(
                        "Invalid link-state link JSON for peer '$peerId': field 'cost' was $cost, but link costs must be positive."
                    )
                }
                return Link(peerId, cost)
            }
        }
    }

    init {
        require(originPeerId.isNotBlank()) {
            "Invalid link-state advertisement origin: originPeerId must not be blank."
        }
        require(sequenceNumber >= 0) {
            "Invalid link-state advertisement from '$originPeerId': sequenceNumber was $sequenceNumber, but it must be non-negative."
        }
        require(ttlMs > 0) {
            "Invalid link-state advertisement from '$originPeerId': ttlMs was $ttlMs, but it must be positive."
        }
        require(links.size <= DEFAULT_MAX_LINKS_PER_ADVERTISEMENT) {
            "Invalid link-state advertisement from '$originPeerId': links contained ${links.size} " +
                "entries, but at most $DEFAULT_MAX_LINKS_PER_ADVERTISEMENT direct links are accepted."
        }
    }

    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("type", GossipProtocol.TYPE_LINK_STATE_ADVERTISEMENT)
            put("originPeerId", originPeerId)
            put("sequenceNumber", sequenceNumber)
            put("links", JSONArray(links.map { it.toJson() }))
            put("timestampMs", timestampMs)
            put("ttlMs", ttlMs)
        }
    }

    fun isExpired(nowMs: Long): Boolean = nowMs - timestampMs >= ttlMs

    companion object {
        const val DEFAULT_LSA_TTL_MS = 5 * 60 * 1000L
        const val DEFAULT_MAX_LINKS_PER_ADVERTISEMENT = 256

        fun fromJson(json: JSONObject): LinkStateAdvertisement {
            val originPeerId = json.optString("originPeerId", "")
            if (originPeerId.isBlank()) {
                throw IllegalArgumentException(
                    "Invalid link-state advertisement JSON: field 'originPeerId' was blank or missing, but every LSA must name its origin."
                )
            }
            if (!json.has("sequenceNumber")) {
                throw IllegalArgumentException(
                    "Invalid link-state advertisement JSON from '$originPeerId': field 'sequenceNumber' was missing, but every LSA must carry a sequence number."
                )
            }
            val sequenceNumber = json.getLong("sequenceNumber")
            if (sequenceNumber < 0) {
                throw IllegalArgumentException(
                    "Invalid link-state advertisement JSON from '$originPeerId': field 'sequenceNumber' was $sequenceNumber, but it must be non-negative."
                )
            }
            val linksArray = json.optJSONArray("links") ?: JSONArray()
            if (linksArray.length() > DEFAULT_MAX_LINKS_PER_ADVERTISEMENT) {
                throw IllegalArgumentException(
                    "Invalid link-state advertisement JSON from '$originPeerId': field 'links' contained " +
                        "${linksArray.length()} entries, but at most " +
                        "$DEFAULT_MAX_LINKS_PER_ADVERTISEMENT direct links are accepted."
                )
            }
            val links = (0 until linksArray.length()).map { Link.fromJson(linksArray.getJSONObject(it)) }
            val timestampMs = json.optLong("timestampMs", System.currentTimeMillis())
            val ttlMs = json.optLong("ttlMs", DEFAULT_LSA_TTL_MS)
            return LinkStateAdvertisement(originPeerId, sequenceNumber, links, timestampMs, ttlMs)
        }
    }
}

data class LinkStateAdvertisementDecision(
    val accepted: Boolean,
    val shouldReflood: Boolean
)

/**
 * Clock-driven SPF table for link-state routing. The table stores the newest
 * LSA per origin and computes hop-by-hop next hops using Dijkstra.
 */
class LinkStateRoutingTable(
    private val localPeerId: String,
    private val clock: Clock = SystemClock(),
    private val lsaTtlMs: Long = LinkStateAdvertisement.DEFAULT_LSA_TTL_MS,
    private val maxAdvertisements: Int = DEFAULT_MAX_ADVERTISEMENTS,
    private val maxLinksPerAdvertisement: Int = LinkStateAdvertisement.DEFAULT_MAX_LINKS_PER_ADVERTISEMENT,
    private val maxAcceptedTtlMs: Long = DEFAULT_MAX_ACCEPTED_TTL_MS,
    private val futureTimestampToleranceMs: Long = DEFAULT_FUTURE_TIMESTAMP_TOLERANCE_MS,
    private val maxSequenceAdvance: Long = DEFAULT_MAX_SEQUENCE_ADVANCE
) {
    init {
        require(maxLinksPerAdvertisement in 1..LinkStateAdvertisement.DEFAULT_MAX_LINKS_PER_ADVERTISEMENT) {
            "Invalid link-state routing maxLinksPerAdvertisement: value was $maxLinksPerAdvertisement, " +
                "but it must be between 1 and " +
                "${LinkStateAdvertisement.DEFAULT_MAX_LINKS_PER_ADVERTISEMENT}."
        }
    }

    private val lock = ReentrantReadWriteLock()
    private val localSequenceNumber = AtomicLong(clock.currentTimeMillis().coerceAtLeast(0L))
    private val advertisements = ConcurrentHashMap<String, LinkStateAdvertisement>()
    private var localLinks: List<LinkStateAdvertisement.Link> = emptyList()
    private var cachedNextHops: Map<String, String> = emptyMap()

    fun setLocalLinks(links: List<LinkStateAdvertisement.Link>): LinkStateAdvertisement {
        val normalizedLinks = normalizeLocalLinks(links)
        return lock.write {
            localLinks = normalizedLinks
            originateLocalAdvertisementLocked()
        }
    }

    /**
     * Takes and installs one implementation-owned local link snapshot while holding the same write
     * lock that allocates its version. The snapshot callback must only read in-memory relay state;
     * transport writes and caller callbacks run after this method returns.
     */
    internal fun updateLocalLinks(
        force: Boolean,
        linksSnapshot: () -> List<LinkStateAdvertisement.Link>,
    ): LinkStateAdvertisement? = lock.write {
        val normalizedLinks = normalizeLocalLinks(linksSnapshot())
        if (!force && localLinks == normalizedLinks) return@write null
        localLinks = normalizedLinks
        originateLocalAdvertisementLocked()
    }

    private fun normalizeLocalLinks(
        links: List<LinkStateAdvertisement.Link>,
    ): List<LinkStateAdvertisement.Link> {
        require(links.size <= maxLinksPerAdvertisement) {
            "Cannot set local links for '$localPeerId': received ${links.size} entries, but this " +
                "routing table accepts at most $maxLinksPerAdvertisement direct links per origin."
        }
        return links.sortedWith(compareBy<LinkStateAdvertisement.Link> { it.peerId }.thenBy { it.cost })
    }

    fun refreshLocalAdvertisement(): LinkStateAdvertisement {
        return lock.write {
            originateLocalAdvertisementLocked()
        }
    }

    private fun originateLocalAdvertisementLocked(): LinkStateAdvertisement {
        val nextSequence = localSequenceNumber.updateAndGet { previous ->
            val candidate = previous + 1
            if (candidate == Long.MIN_VALUE) 0L else candidate
        }
        val lsa = LinkStateAdvertisement(
            originPeerId = localPeerId,
            sequenceNumber = nextSequence,
            links = localLinks,
            timestampMs = clock.currentTimeMillis(),
            ttlMs = lsaTtlMs
        )
        advertisements[localPeerId] = lsa
        recomputeLocked()
        return lsa
    }

    fun processAdvertisement(lsa: LinkStateAdvertisement): LinkStateAdvertisementDecision {
        return lock.write {
            if (lsa.links.size > maxLinksPerAdvertisement) {
                return@write LinkStateAdvertisementDecision(accepted = false, shouldReflood = false)
            }
            val now = clock.currentTimeMillis()
            if (lsa.timestampMs > now + futureTimestampToleranceMs) {
                return@write LinkStateAdvertisementDecision(accepted = false, shouldReflood = false)
            }
            val boundedLsa = lsa.copy(ttlMs = minOf(lsa.ttlMs, maxAcceptedTtlMs))
            if (boundedLsa.isExpired(now)) {
                return@write LinkStateAdvertisementDecision(accepted = false, shouldReflood = false)
            }
            val existing = advertisements[boundedLsa.originPeerId]
            if (existing != null && !existing.isExpired(now)) {
                if (!isSequenceNewer(boundedLsa.sequenceNumber, existing.sequenceNumber, maxSequenceAdvance)) {
                    return@write LinkStateAdvertisementDecision(accepted = false, shouldReflood = false)
                }
            } else if (boundedLsa.sequenceNumber > now + maxSequenceAdvance) {
                return@write LinkStateAdvertisementDecision(accepted = false, shouldReflood = false)
            }
            advertisements[boundedLsa.originPeerId] = boundedLsa
            evictOverflowLocked(now)
            recomputeLocked()
            LinkStateAdvertisementDecision(accepted = true, shouldReflood = boundedLsa.originPeerId != localPeerId)
        }
    }

    fun expireStaleAdvertisements(): Int {
        return lock.write {
            val now = clock.currentTimeMillis()
            val before = advertisements.size
            advertisements.entries.removeIf { it.value.isExpired(now) }
            val removed = before - advertisements.size
            if (removed > 0) {
                recomputeLocked()
            }
            removed
        }
    }

    fun nextHopFor(destinationPeerId: String): String? {
        expireStaleAdvertisements()
        return lock.read { cachedNextHops[destinationPeerId] }
    }

    fun nextHopTable(): Map<String, String> {
        expireStaleAdvertisements()
        return lock.read { cachedNextHops.toSortedMap() }
    }

    fun advertisementsSnapshot(): List<LinkStateAdvertisement> {
        expireStaleAdvertisements()
        return lock.read { advertisements.values.sortedBy { it.originPeerId } }
    }

    private fun recomputeLocked() {
        val graph = mutableMapOf<String, MutableList<LinkStateAdvertisement.Link>>()
        val byOrigin = advertisements.toMap()
        for (lsa in byOrigin.values) {
            for (link in lsa.links) {
                // Non-crypto origin-forgery mitigation: only use an edge when both endpoint LSAs
                // claim it. TODO: add cryptographic LSA origin authentication in a follow-up.
                val reciprocal = byOrigin[link.peerId]?.links?.firstOrNull { it.peerId == lsa.originPeerId }
                    ?: continue
                val cost = maxOf(link.cost, reciprocal.cost)
                addGraphLink(graph, lsa.originPeerId, link.peerId, cost)
                addGraphLink(graph, link.peerId, lsa.originPeerId, cost)
            }
        }
        graph.computeIfAbsent(localPeerId) { mutableListOf() }

        data class QueueEntry(val peerId: String, val distance: Long, val firstHop: String)
        val bestDistance = mutableMapOf(localPeerId to 0L)
        val bestFirstHop = mutableMapOf<String, String>()
        val queue = PriorityQueue<QueueEntry>(
            compareBy<QueueEntry> { it.distance }.thenBy { it.firstHop }.thenBy { it.peerId }
        )

        for (link in graph[localPeerId].orEmpty().sortedWith(compareBy<LinkStateAdvertisement.Link> { it.cost }.thenBy { it.peerId })) {
            if (recordBetterPath(link.peerId, link.cost, link.peerId, bestDistance, bestFirstHop)) {
                queue.add(QueueEntry(link.peerId, link.cost, link.peerId))
            }
        }

        while (queue.isNotEmpty()) {
            val current = queue.poll()
            if (bestDistance[current.peerId] != current.distance || bestFirstHop[current.peerId] != current.firstHop) {
                continue
            }
            for (link in graph[current.peerId].orEmpty().sortedWith(compareBy<LinkStateAdvertisement.Link> { it.cost }.thenBy { it.peerId })) {
                if (link.peerId == localPeerId) continue
                // Link costs come off the network and are only required to be positive, so a
                // remote peer can advertise a cost near Long.MAX_VALUE. Adding two of those wraps
                // past Long.MAX_VALUE into a negative distance, which recordBetterPath reads as
                // the shortest path available: the expensive route then wins for its own
                // destination and, once relaxed further, replaces the first hop of a directly
                // connected neighbour too. Saturate instead, so a path that expensive is never
                // preferred over a finite one.
                val newDistance = if (link.cost > Long.MAX_VALUE - current.distance) {
                    Long.MAX_VALUE
                } else {
                    current.distance + link.cost
                }
                if (recordBetterPath(link.peerId, newDistance, current.firstHop, bestDistance, bestFirstHop)) {
                    queue.add(QueueEntry(link.peerId, newDistance, current.firstHop))
                }
            }
        }
        cachedNextHops = bestFirstHop.toSortedMap()
    }

    private fun evictOverflowLocked(now: Long) {
        advertisements.entries.removeIf { it.value.isExpired(now) }
        if (advertisements.size <= maxAdvertisements) return
        val victims = advertisements.values
            .filter { it.originPeerId != localPeerId }
            .sortedWith(compareBy<LinkStateAdvertisement> { it.timestampMs }.thenBy { it.originPeerId })
            .take(advertisements.size - maxAdvertisements)
        for (victim in victims) {
            advertisements.remove(victim.originPeerId, victim)
        }
    }

    companion object {
        const val DEFAULT_MAX_ADVERTISEMENTS = 4096
        const val DEFAULT_MAX_ACCEPTED_TTL_MS = LinkStateAdvertisement.DEFAULT_LSA_TTL_MS
        const val DEFAULT_FUTURE_TIMESTAMP_TOLERANCE_MS = 30_000L
        const val DEFAULT_MAX_SEQUENCE_ADVANCE = 1_000_000L
    }
}

private fun isSequenceNewer(newSequence: Long, existingSequence: Long, maxSequenceAdvance: Long): Boolean {
    val diff = newSequence - existingSequence
    if (diff > 0 && diff <= maxSequenceAdvance) return true
    return existingSequence >= Long.MAX_VALUE - maxSequenceAdvance && newSequence <= maxSequenceAdvance
}

private fun addGraphLink(
    graph: MutableMap<String, MutableList<LinkStateAdvertisement.Link>>,
    fromPeerId: String,
    toPeerId: String,
    cost: Long
) {
    val links = graph.computeIfAbsent(fromPeerId) { mutableListOf() }
    val existingIndex = links.indexOfFirst { it.peerId == toPeerId }
    if (existingIndex == -1) {
        links.add(LinkStateAdvertisement.Link(toPeerId, cost))
    } else if (cost < links[existingIndex].cost) {
        links[existingIndex] = LinkStateAdvertisement.Link(toPeerId, cost)
    }
}

private fun recordBetterPath(
    peerId: String,
    distance: Long,
    firstHop: String,
    bestDistance: MutableMap<String, Long>,
    bestFirstHop: MutableMap<String, String>
): Boolean {
    val existingDistance = bestDistance[peerId]
    val existingFirstHop = bestFirstHop[peerId]
    val better = existingDistance == null ||
        distance < existingDistance ||
        (distance == existingDistance && (existingFirstHop == null || firstHop < existingFirstHop))
    if (!better) return false
    bestDistance[peerId] = distance
    bestFirstHop[peerId] = firstHop
    return true
}
