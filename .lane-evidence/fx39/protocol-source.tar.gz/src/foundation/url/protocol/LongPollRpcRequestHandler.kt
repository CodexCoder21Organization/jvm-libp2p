package foundation.url.protocol

/**
 * Optional server-side declaration of requests that wait for a change rather than return a
 * current value. Implement this on the [RpcRequestHandler] passed to the host factory or binding;
 * wrappers must forward the declaration to the handler that knows the request's service and path.
 * Existing handlers remain ordinary regardless of their method names.
 *
 * Declared requests share [MAX_CONCURRENT_REQUESTS] process-wide slots, separate from the 64
 * ordinary slots. A slot includes suspended handler work and its response until delivery or
 * release. Suspension must use coroutine suspension rather than blocking a request thread.
 * Excess requests never invoke [handleRequest] and return [NOT_STARTED_ERROR_CODE]. Only that
 * explicit error proves admission did not start the handler; a lost connection does not.
 */
interface LongPollRpcRequestHandler : RpcRequestHandler {
    /**
     * Classifies a request before admission. Must be quick, nonblocking, and free of side effects;
     * the caller has not acquired a handler slot yet. Do not trust a client-supplied flag.
     */
    fun isLongPollRequest(request: Libp2pRpcProtocol.RpcRequest): Boolean

    companion object {
        /** Matches UrlResolver's chosen parked-request allowance; independent of ordinary work. */
        const val MAX_CONCURRENT_REQUESTS = 192
        const val NOT_STARTED_ERROR_CODE = "LONG_POLL_NOT_STARTED"
        const val NOT_STARTED_ERROR_MESSAGE =
            "Long-poll request was not started because all $MAX_CONCURRENT_REQUESTS process-wide long-poll slots are held " +
                "by handlers or undelivered responses; retrying the same read is safe."
    }
}
