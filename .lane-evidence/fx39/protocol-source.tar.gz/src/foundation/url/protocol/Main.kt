package foundation.url.protocol

/**
 * UrlProtocol does not have a standalone executable.
 *
 * Every UrlProtocol instance participates as a relay by default.
 * There is no dedicated relay service - the relay functionality is
 * built into every node in the P2P network.
 *
 * To use UrlProtocol, create an instance in your application:
 * ```kotlin
 * val protocol = UrlProtocol.withDefaultBootstrapPeers()
 * protocol.startRelayService()
 * ```
 *
 * Or use UrlResolver which manages UrlProtocol for you:
 * ```kotlin
 * val resolver = UrlResolver()
 * val info = resolver.joinNetwork()
 * ```
 */
fun main() {
    println("UrlProtocol does not have a standalone executable.")
    println()
    println("Every UrlProtocol instance participates as a relay by default.")
    println("There is no dedicated relay service.")
    println()
    println("To participate in the url:// network, use UrlResolver:")
    println("  val resolver = UrlResolver()")
    println("  val info = resolver.joinNetwork()")
    println()
    println("All nodes automatically:")
    println("  - Participate in gossip protocol")
    println("  - Act as relays for other peers")
    println("  - Discover peers through peer exchange")
}
