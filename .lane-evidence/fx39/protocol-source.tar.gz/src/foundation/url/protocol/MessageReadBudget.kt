package foundation.url.protocol

import community.kotlin.clocks.simple.Clock

/** Deadlines belong to one read invocation; partial body storage never escapes that invocation. */
internal class MessageReadBudget(
    val idleDeadlineMs: Long,
    val frameBudgetMs: Long,
    val operationDeadlineMs: Long,
    val clock: Clock,
    val reportFrameExpiry: Boolean,
    val pollBufferedFrame: Boolean = false,
) {
    var frameDeadlineMs: Long? = if (reportFrameExpiry) null else operationDeadlineMs
    var bodyLength: Int? = null
    var bodyStarted: Boolean = false
}

internal fun messageReadDeadline(budget: MessageReadBudget): Long =
    budget.frameDeadlineMs ?: budget.idleDeadlineMs

internal fun messageReadCanConsumeBytes(budget: MessageReadBudget): Boolean {
    val now = budget.clock.currentTimeMillis()
    if (now < messageReadDeadline(budget)) return true
    return budget.frameDeadlineMs == null && budget.pollBufferedFrame && now < budget.operationDeadlineMs
}

internal fun beginMessageFrame(budget: MessageReadBudget) {
    if (budget.frameDeadlineMs == null) {
        budget.frameDeadlineMs = minOf(
            saturatedReadDeadline(budget.clock.currentTimeMillis(), budget.frameBudgetMs),
            budget.operationDeadlineMs,
        )
    }
}

internal fun beginMessageBodyWait(budget: MessageReadBudget) {
    if (budget.reportFrameExpiry) budget.frameDeadlineMs = null
    beginMessageFrame(budget)
}

internal fun beginMessageByteCopy(budget: MessageReadBudget) {
    if (budget.bodyLength != null && !budget.bodyStarted) {
        budget.bodyStarted = true
        // Admission and waiting for the first body byte have consumed no body storage. Once
        // copying begins the entire body gets its caller-supplied allowance, with the same cap.
        if (budget.reportFrameExpiry) budget.frameDeadlineMs = null
    }
    beginMessageFrame(budget)
}

internal fun saturatedReadDeadline(now: Long, durationMs: Long): Long =
    if (durationMs > 0 && now > Long.MAX_VALUE - durationMs) Long.MAX_VALUE
    else now + durationMs.coerceAtLeast(0L)

/** Compares absolute times before subtracting, saturating a positive interval that cannot fit. */
internal fun remainingReadWaitMillis(deadlineMs: Long, nowMs: Long): Long = when {
    nowMs >= deadlineMs -> 0L
    nowMs < 0L && deadlineMs > Long.MAX_VALUE + nowMs -> Long.MAX_VALUE
    else -> deadlineMs - nowMs
}

internal fun messageFrameExpiryDescription(budget: MessageReadBudget, received: Int): String {
    val length = budget.bodyLength
    val progress = if (length == null) "declared body length unknown, received $received of 4 prefix bytes"
        else "declared body length $length bytes, received $received body bytes"
    val operation = if (budget.operationDeadlineMs == Long.MAX_VALUE) "none"
        else budget.operationDeadlineMs.toString()
    return "Frame read expired: $progress; frame budget ${budget.frameBudgetMs}ms, operation deadline $operation."
}

/** An incomplete prefix-owned frame cannot become an admission miss after its frame allowance. */
internal fun messageAdmissionFrameExpiry(
    budget: MessageReadBudget,
    nowMs: Long?,
    availableBodyBytes: Long,
): String? {
    val deadline = budget.frameDeadlineMs ?: return null
    val length = budget.bodyLength ?: return null
    if (!budget.reportFrameExpiry || nowMs == null || nowMs < deadline || availableBodyBytes >= length) {
        return null
    }
    return messageFrameExpiryDescription(budget, 0)
}
