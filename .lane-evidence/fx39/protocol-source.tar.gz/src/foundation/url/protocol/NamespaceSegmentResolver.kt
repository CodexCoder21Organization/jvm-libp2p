package foundation.url.protocol

import java.nio.file.NoSuchFileException
import java.util.concurrent.ConcurrentHashMap

/**
 * Represents a particular step/segment when resolving a host name in the url:// namespace.
 *
 * Each resolver handles one segment of a hierarchical namespace and can provide
 * child resolvers for subsequent segments. Resolvers also support retrieving
 * typed objects at paths within their namespace.
 *
 * ## Resolution Model
 *
 * Namespace resolution follows a hierarchical model where each segment of a dotted
 * name (e.g., "com.example.service") is resolved by a corresponding resolver:
 *
 * ```
 * Root Resolvers (hard-coded)
 *     └── "com" resolver
 *             └── "example" resolver (via getChildSegmentResolver)
 *                     └── "service" resolver (via getChildSegmentResolver)
 * ```
 *
 * ## Example Usage
 *
 * ```kotlin
 * // Register a root resolver
 * NamespaceSegmentResolver.registerRootResolver("myns", MyNamespaceResolver())
 *
 * // Resolve a full namespace path
 * val resolver = NamespaceSegmentResolver.resolve("myns.subsystem.component")
 *
 * // Get a typed object from the resolved namespace
 * val service: MyService = resolver.getObject("path/to/object", MyService::class.java)
 *
 * // Using the reified extension for cleaner Kotlin code
 * val service: MyService = resolver.getObject("path/to/object")
 * ```
 *
 * ## Implementing a Resolver
 *
 * ```kotlin
 * class MyResolver : NamespaceSegmentResolver {
 *     private val children = mapOf(
 *         "child1" to Child1Resolver(),
 *         "child2" to Child2Resolver()
 *     )
 *
 *     override fun getChildSegmentResolver(segment: String): NamespaceSegmentResolver {
 *         return children[segment]
 *             ?: throw NoSuchFileException("No child resolver for segment: $segment")
 *     }
 *
 *     override fun <T : Any> getObject(path: String, type: Class<T>): T {
 *         val obj = lookupObject(path)
 *             ?: throw NoSuchFileException("No object at path: $path")
 *         if (!type.isInstance(obj)) {
 *             throw ClassCastException(
 *                 "Object at '$path' is ${obj::class.java.name}, not ${type.name}"
 *             )
 *         }
 *         return type.cast(obj)
 *     }
 * }
 * ```
 *
 * @see UrlProtocol
 */
interface NamespaceSegmentResolver {

    /**
     * Gets the child resolver for the next segment in the namespace.
     *
     * This method is called when traversing a hierarchical namespace like
     * "com.example.service". Each segment ("com", "example", "service")
     * is resolved by calling this method on the parent resolver.
     *
     * @param segment The next segment name to resolve. This is a single
     *                segment of the namespace, not a dotted path.
     * @return The resolver for the child segment.
     * @throws NoSuchFileException if no child exists with the given segment name.
     *         The exception message should include the segment name for debugging.
     */
    fun getChildSegmentResolver(segment: String): NamespaceSegmentResolver

    /**
     * Gets an object at the given path, cast to the specified type.
     *
     * The path is relative to this resolver's namespace position. The path
     * format is implementation-specific but typically uses "/" as a separator
     * for sub-paths within the current segment.
     *
     * @param T The expected type of the object.
     * @param path The path to the object, relative to this resolver's namespace.
     *             An empty string or "/" typically refers to the resolver's root object.
     * @param type The expected class of the object.
     * @return The object at the path, cast to the specified type.
     * @throws NoSuchFileException if no object exists at the given path.
     *         The exception message should include the path for debugging.
     * @throws ClassCastException if the object at the path cannot be cast to
     *         the specified type. The exception message should include both
     *         the actual type and expected type for debugging.
     */
    fun <T : Any> getObject(path: String, type: Class<T>): T

    companion object {
        /**
         * Registry of root-level namespace resolvers.
         *
         * These resolvers handle the first segment of any namespace path.
         * For example, a path "myns.subsystem" would first look up "myns"
         * in this registry.
         */
        private val rootResolvers = ConcurrentHashMap<String, NamespaceSegmentResolver>()

        /**
         * Registers a root-level namespace resolver.
         *
         * Root resolvers are the entry points for namespace resolution.
         * They handle the first segment of any dotted namespace path.
         *
         * @param segment The root segment name (e.g., "com", "org", "myns").
         * @param resolver The resolver to handle this root segment.
         */
        fun registerRootResolver(segment: String, resolver: NamespaceSegmentResolver) {
            rootResolvers[segment] = resolver
        }

        /**
         * Unregisters a root-level namespace resolver.
         *
         * @param segment The root segment name to unregister.
         * @return The previously registered resolver, or null if none was registered.
         */
        fun unregisterRootResolver(segment: String): NamespaceSegmentResolver? {
            return rootResolvers.remove(segment)
        }

        /**
         * Gets the root resolver for the given segment.
         *
         * @param segment The root segment name to look up.
         * @return The resolver for this root segment.
         * @throws NoSuchFileException if no root resolver is registered for the segment.
         */
        fun getRootResolver(segment: String): NamespaceSegmentResolver {
            return rootResolvers[segment]
                ?: throw NoSuchFileException(
                    "No root resolver registered for segment '$segment'. " +
                        "Registered roots: ${rootResolvers.keys.sorted().joinToString(", ")}"
                )
        }

        /**
         * Checks if a root resolver is registered for the given segment.
         *
         * @param segment The root segment name to check.
         * @return True if a resolver is registered for this segment.
         */
        fun hasRootResolver(segment: String): Boolean {
            return rootResolvers.containsKey(segment)
        }

        /**
         * Gets all registered root segment names.
         *
         * @return Set of all registered root segment names.
         */
        fun getRegisteredRootSegments(): Set<String> {
            return rootResolvers.keys.toSet()
        }

        /**
         * Resolves a full namespace path starting from the root.
         *
         * The namespace path is split by "." (dots) and each segment is
         * resolved in sequence. The first segment must match a registered
         * root resolver, and each subsequent segment is resolved via
         * [getChildSegmentResolver].
         *
         * @param namespace The full dotted namespace path (e.g., "com.example.service").
         * @return The resolver for the final segment of the path.
         * @throws NoSuchFileException if the namespace path is empty, if no root
         *         resolver is registered for the first segment, or if any segment
         *         in the path cannot be resolved.
         */
        fun resolve(namespace: String): NamespaceSegmentResolver {
            val segments = namespace.split(".").filter { it.isNotBlank() }

            if (segments.isEmpty()) {
                throw NoSuchFileException(
                    "Cannot resolve empty namespace path. Provide a dotted path like 'root.child.subchild'."
                )
            }

            var resolver = getRootResolver(segments[0])
            for (i in 1 until segments.size) {
                resolver = resolver.getChildSegmentResolver(segments[i])
            }
            return resolver
        }

        /**
         * Resolves a namespace path and retrieves an object of the specified type.
         *
         * This is a convenience method that combines [resolve] with [getObject].
         *
         * @param T The expected type of the object.
         * @param namespace The full dotted namespace path.
         * @param path The path to the object within the resolved namespace.
         * @param type The expected class of the object.
         * @return The object at the path, cast to the specified type.
         * @throws NoSuchFileException if the namespace cannot be resolved or
         *         if no object exists at the path.
         * @throws ClassCastException if the object cannot be cast to the specified type.
         */
        fun <T : Any> resolveAndGet(namespace: String, path: String, type: Class<T>): T {
            val resolver = resolve(namespace)
            return resolver.getObject(path, type)
        }

        /**
         * Clears all registered root resolvers.
         *
         * This is primarily useful for testing to reset state between tests.
         */
        fun clearAllRootResolvers() {
            rootResolvers.clear()
        }
    }
}

/**
 * Gets an object at the given path, with the type inferred from the call site.
 *
 * This is a convenience extension that uses Kotlin's reified type parameters
 * to avoid explicitly passing the class object.
 *
 * Example:
 * ```kotlin
 * val service: MyService = resolver.getObject("path/to/service")
 * ```
 *
 * @param T The expected type of the object (inferred from usage).
 * @param path The path to the object.
 * @return The object at the path, cast to the inferred type.
 * @throws NoSuchFileException if no object exists at the path.
 * @throws ClassCastException if the object cannot be cast to the expected type.
 */
inline fun <reified T : Any> NamespaceSegmentResolver.getObject(path: String): T {
    return getObject(path, T::class.java)
}

/**
 * Resolves a namespace path and retrieves an object with the type inferred.
 *
 * This is a convenience extension for [NamespaceSegmentResolver.Companion.resolveAndGet]
 * that uses Kotlin's reified type parameters.
 *
 * Example:
 * ```kotlin
 * val service: MyService = NamespaceSegmentResolver.resolveAndGet("com.example.service", "/api")
 * ```
 *
 * @param T The expected type of the object (inferred from usage).
 * @param namespace The full dotted namespace path.
 * @param path The path to the object within the resolved namespace.
 * @return The object at the path, cast to the inferred type.
 */
inline fun <reified T : Any> NamespaceSegmentResolver.Companion.resolveAndGet(
    namespace: String,
    path: String
): T {
    return resolveAndGet(namespace, path, T::class.java)
}
