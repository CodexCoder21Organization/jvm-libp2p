package foundation.url.protocol

/**
 * Network seam beneath [UrlProtocol].
 *
 * Implementations provide only the five network capabilities consumed by the protocol layer:
 * deterministic identity derivation, listening, dialing, inbound protocol handlers, and
 * connection lifecycle events. Transport-specific types must not appear on this surface, but the
 * string values are provider-interpreted rather than provider-neutral wire formats: peer IDs are
 * opaque provider identities and addresses are opaque provider addresses. The default
 * [Libp2pNetworkProvider] interprets them as base58 libp2p peer IDs and libp2p multiaddresses.
 */
interface NetworkProvider : AutoCloseable {
    /** Derives the stable node identity associated with [keySeed]. */
    fun derivePeerId(keySeed: String): String

    /**
     * Starts listening on [port] (`0` selects a provider-assigned port) and reports the bound node.
     * Implementations must make this operation thread-safe and idempotent: concurrent and repeated
     * calls for the same effective listener return the same bound node without creating duplicates.
     */
    fun listen(port: Int = 0): NetworkListenInfo

    /**
     * Opens [protocolId] to [peerId] at [address], failing when the connection and protocol
     * negotiation have not completed within [timeoutMs].
     *
     * [peerId] and [address] are opaque strings interpreted by this provider. Implementations must
     * validate their own identity/address formats and include the supplied values in failures.
     */
    fun dial(
        peerId: String,
        address: String,
        protocolId: String,
        timeoutMs: Long = 30_000L
    ): RpcStream

    /**
     * Registers the handler invoked for peer-initiated streams negotiating [protocolId].
     * The handler owns each delivered stream and must close it when processing is complete.
     * Closing the returned registration unregisters the handler for future streams; streams
     * already delivered to the handler remain owned by that handler.
     */
    fun registerInboundStreamHandler(
        protocolId: String,
        handler: (RpcStream) -> Unit
    ): AutoCloseable

    /** Registers a listener for authenticated transport connection lifecycle events. */
    fun addConnectionListener(listener: (NetworkConnectionEvent) -> Unit): AutoCloseable
}

/** Identity and addresses produced by [NetworkProvider.listen]. */
data class NetworkListenInfo(
    val peerId: String,
    val listenAddresses: List<String>
)

/** A transport connection event containing no provider-specific types. */
sealed class NetworkConnectionEvent {
    abstract val remotePeerId: String

    data class Connected(override val remotePeerId: String) : NetworkConnectionEvent()
    data class Disconnected(override val remotePeerId: String) : NetworkConnectionEvent()
}
