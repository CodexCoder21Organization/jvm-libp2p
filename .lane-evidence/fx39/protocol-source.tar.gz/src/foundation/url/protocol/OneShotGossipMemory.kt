package foundation.url.protocol

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

// This allowance is separate from transient parsing and shared by every host. Retained work
// keeps its conservative parser footprint charged until the callback and reporting finish.
private val oneShotGossipRetainedBytes = AtomicLong()
private val oneShotWithdrawalRetainedBytes = AtomicLong()
internal class OneShotGossipReservation(
    private val bytes: Long,
    private val owner: AtomicLong = oneShotGossipRetainedBytes,
) : AutoCloseable {
    private val released = AtomicBoolean()

    override fun close() {
        if (!released.compareAndSet(false, true)) return
        val remaining = owner.addAndGet(-bytes)
        check(remaining >= 0L) {
            "One-way work retained-byte ownership became negative after returning $bytes bytes; remaining=$remaining"
        }
    }
}

internal fun reserveOneShotGossipBytes(bytes: Long): OneShotGossipReservation? {
    val limit = Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES.toLong()
    if (bytes <= 0L) return null
    // Like parsing, the allowance bounds concurrent work rather than imposing a second wire
    // size limit. A single legal large frame takes the whole pool and runs exclusively.
    val charge = bytes.coerceAtMost(limit)
    val reservation = OneShotGossipReservation(charge)
    while (true) {
        val used = oneShotGossipRetainedBytes.get()
        if (used > limit - charge) return null
        if (oneShotGossipRetainedBytes.compareAndSet(used, used + charge)) return reservation
    }
}

// Completed withdrawals must not keep parser permits while registry work waits. This separate
// process-wide allowance is shared across hosts; the host also bounds each authenticated peer.
internal fun reserveOneShotWithdrawalBytes(bytes: Long): OneShotGossipReservation? {
    val limit = Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES.toLong()
    if (bytes <= 0L || bytes > limit) return null
    val reservation = OneShotGossipReservation(bytes, oneShotWithdrawalRetainedBytes)
    while (true) {
        val used = oneShotWithdrawalRetainedBytes.get()
        if (used > limit - bytes) return null
        if (oneShotWithdrawalRetainedBytes.compareAndSet(used, used + bytes)) return reservation
    }
}
