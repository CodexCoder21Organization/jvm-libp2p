package foundation.url.protocol

import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Process-wide bound on how many outbound peer dials may be in flight at once.
 *
 * Every dial that has been issued but not yet completed holds an operating-system socket in
 * SYN-SENT until it connects or the SYN retransmission schedule gives up (a two-minute wait on
 * Linux defaults for a destination that no longer answers). Gossip fan-out issues one dial per
 * known peer per message, and the registry retains up to [PeerRegistry.MAX_REGISTRY_PEERS] peers,
 * so without a bound a single process can hold thousands of simultaneous half-open sockets to
 * hosts that no longer exist — consuming file descriptors, kernel connection-table entries, and
 * the event-loop threads that service them.
 *
 * The bound is process-wide rather than per-provider because the resource being protected (socket
 * table, file descriptors, event-loop threads) is process-wide.
 */
internal object OutboundDialAdmission {
    private val permits = Semaphore(Libp2pNetworkProvider.MAX_CONCURRENT_OUTBOUND_DIALS, true)
    private val pending = AtomicInteger(0)

    /** Number of dials currently holding an admission permit. */
    fun pendingCount(): Int = pending.get()

    /**
     * Runs [dial] while holding one of the [Libp2pNetworkProvider.MAX_CONCURRENT_OUTBOUND_DIALS]
     * admission permits.
     *
     * Waits at most [timeoutMs] for a permit, which is the same budget the caller already allots
     * to the dial itself: a caller that would have given up on an unresponsive destination after
     * [timeoutMs] is no worse off giving up after waiting that long for capacity. Saturation is
     * reported as a dial failure so existing best-effort callers (gossip fan-out, peer exchange)
     * take their normal failure path instead of blocking indefinitely.
     */
    fun <T> withDialPermit(peerId: String, address: String, timeoutMs: Long, dial: () -> T): T {
        val acquired = try {
            permits.tryAcquire(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (interruption: InterruptedException) {
            Thread.currentThread().interrupt()
            throw OutboundDialAdmissionException(
                "Interrupted while waiting for outbound dial capacity to dial peer '$peerId' at " +
                    "'$address'.",
                interruption
            )
        }
        if (!acquired) {
            throw OutboundDialAdmissionException(
                "Cannot dial peer '$peerId' at '$address': all " +
                    "${Libp2pNetworkProvider.MAX_CONCURRENT_OUTBOUND_DIALS} outbound dial slots " +
                    "for this process were still occupied after waiting ${timeoutMs}ms. " +
                    "Outbound dials are bounded so unreachable peers cannot accumulate half-open " +
                    "sockets; retry once in-flight dials complete."
            )
        }
        pending.incrementAndGet()
        try {
            return dial()
        } finally {
            pending.decrementAndGet()
            permits.release()
        }
    }
}

/**
 * Thrown when an outbound dial cannot be admitted because the process-wide concurrent dial bound
 * is saturated. Callers that treat dialing as best effort handle this like any other dial failure.
 */
class OutboundDialAdmissionException(
    message: String,
    cause: Throwable? = null
) : RuntimeException(message, cause)
