package foundation.url.protocol

import java.util.concurrent.CountDownLatch

/** A controller's terminal read transition wakes admission without interrupting caller threads. */
internal class ParseBudgetCancellation {
    private val lock = Any()
    private var cancelled = false
    private val waiters = HashSet<CountDownLatch>()

    fun register(waiter: CountDownLatch) = synchronized(lock) {
        if (cancelled) waiter.countDown() else waiters.add(waiter)
        Unit
    }

    fun unregister(waiter: CountDownLatch) = synchronized(lock) {
        waiters.remove(waiter)
        Unit
    }

    fun isCancelled(): Boolean = synchronized(lock) { cancelled }

    fun cancel() = synchronized(lock) {
        cancelled = true
        // These are scheduler latches, not caller callbacks; waking them cannot re-enter close.
        waiters.forEach { it.countDown() }
        waiters.clear()
    }
}
