package foundation.url.protocol

import java.util.concurrent.atomic.AtomicReference

/** Keeps a built-in descriptor's first accepted address snapshot stable across registries. */
internal class PeerAddressOwnership(addresses: List<String>) {
    private class State(val addresses: List<String>, val accepted: Boolean)
    private val state = AtomicReference(State(addresses, false))

    val addresses: List<String>
        get() = state.get().addresses

    fun retain(peerId: String, addresses: List<String>) {
        val previous = state.get()
        if (!previous.accepted && state.compareAndSet(previous, State(addresses, true))) return
        // Another registry may have accepted this very descriptor while we prepared its data.
        // Reusing equal routes is safe; replacing its already accepted routes is not.
        check(state.get().addresses == addresses) {
            "Peer '$peerId' changed its multiaddresses while registry admission was reading them"
        }
    }
}
