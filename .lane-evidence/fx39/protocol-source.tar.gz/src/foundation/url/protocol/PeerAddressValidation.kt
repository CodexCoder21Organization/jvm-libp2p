package foundation.url.protocol

import io.libp2p.core.multiformats.Protocol
import java.net.Inet6Address
import java.net.InetAddress
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.toss

/**
 * Structural validation for peer multiaddresses learned at runtime.
 *
 * Peer addresses reach [PeerRegistry] from three third-party-controlled sources: PeerExchange
 * responses, PeerAnnouncement gossip, and ServiceAnnouncement gossip. None of those sources is
 * authenticated evidence that the address is dialable — the announcing peer simply asserts it.
 * Before this validation existed, every asserted address was stored verbatim and every stored
 * address was later dialed, so a single malformed or structurally undialable entry became a
 * permanent outbound connection attempt repeated on every gossip fan-out.
 *
 * The rules below reject only addresses that can NEVER identify a reachable TCP peer, so a
 * legitimate peer is never dropped:
 *
 * - A multiaddress the transport itself cannot parse into host/port components.
 * - A `tcp` component whose port is not a number or cannot exist (outside 0..65535).
 * - IPv4 `0.0.0.0/8` — the "this network" block. `0.0.0.0` in particular is a wildcard LISTEN
 *   address that a peer can advertise by accident when it reports its own bind address instead
 *   of its observed address.
 * - IPv4 `169.254.0.0/16` — link-local autoconfiguration; never routed off-link.
 * - IPv4 `224.0.0.0/4` — multicast; not a unicast peer.
 * - IPv4 `240.0.0.0/4` — reserved, including the `255.255.255.255` limited-broadcast address.
 * - IPv6 `::` (unspecified) and `ff00::/8` (multicast), for the same reasons.
 * - More than one `p2p-circuit` component. A relay path may cross one circuit; embedding an
 *   already-relayed path inside another relay path cannot identify a usable dial target.
 *
 * Deliberately NOT rejected:
 *
 * - Loopback (`127.0.0.0/8`, `::1`). Multiple mesh JVMs legitimately share one host and dial each
 *   other over loopback, and the registry cannot distinguish a peer's self-reported loopback
 *   address from a genuinely co-located peer.
 * - Private ranges (`10/8`, `172.16/12`, `192.168/16`). Peers on the same private network
 *   legitimately advertise these.
 * - Addresses whose final octet is 0 or 255. These look like network/broadcast addresses only
 *   under an ASSUMED /24 netmask. Cloud providers allocate blocks larger than /24 (a /23 such as
 *   104.131.162.0/23 makes 104.131.162.255 and 104.131.163.0 ordinary host addresses), and the
 *   registry has no way to learn a remote network's mask. Such addresses belonging to dead hosts
 *   are removed by dial-failure eviction, not by guessing at netmasks here.
 * - `dns4`/`dns6`/`dnsaddr` components, and relay (`p2p-circuit`) addresses carrying no IP
 *   component: there is nothing structural to check.
 * - Addresses that are not multiaddresses at all. The registry is transport-agnostic and holds
 *   peers reached over other transports, whose addresses have their own syntax (the in-memory
 *   fabric uses `memory://<peerId>`). Only the transport that owns such an address can judge it,
 *   so applying IP rules to it would reject a perfectly reachable peer.
 */
internal fun isDialablePeerMultiaddress(address: String): Boolean =
    peerMultiaddressRejectionReason(address) == null

/**
 * Returns a human-readable reason the multiaddress can never identify a reachable TCP peer, or
 * null when the address passes structural validation.
 */
internal fun peerMultiaddressRejectionReason(address: String): String? {
    if (address.isBlank()) {
        return "the address is blank"
    }
    if (!address.startsWith("/")) {
        // Not a multiaddress. Another transport owns this address form and is the only layer that
        // can decide whether it is reachable; the IP rules below do not apply to it.
        return null
    }

    val components = address.split('/').drop(1)
    if (components.isEmpty()) {
        return "the multiaddress '$address' has no components"
    }
    nestedCircuitPeerMultiaddressRejectionReason(address, components)?.let { return it }

    var index = 0
    while (index < components.size) {
        val protocolName = components[index]
        val protocol = Protocol.get(protocolName)
            ?: return "the multiaddress '$address' uses unknown protocol '$protocolName'"
        val value = if (protocol.hasValue) components.getOrNull(index + 1) else null
        if (protocol.hasValue && value == null) {
            return "the '$protocolName' component of '$address' has no value"
        }
        if (protocol.isPath) {
            if (components.drop(index + 1).all { it.isBlank() }) {
                return "the path component '$protocolName' of '$address' has no path value"
            }
            return null
        }
        when (protocol) {
            Protocol.IP4 -> {
                ipv4RejectionReason(value!!)?.let { return "$it (in '$address')" }
            }
            Protocol.IP6 -> {
                ipv6RejectionReason(value!!)?.let { return "$it (in '$address')" }
            }
            Protocol.TCP, Protocol.UDP -> {
                if (value!!.isEmpty() || value.any { !it.isDigit() }) {
                    return "the '$protocolName' port '$value' in '$address' is not a number"
                }
                val port = value.toIntOrNull()
                    ?: return "the '$protocolName' port '$value' in '$address' is not a number"
                // Port 0 is accepted deliberately: peers whose listener has not yet bound
                // announce it, and the address is repaired by a later announcement. Only a port
                // that cannot exist is rejected.
                if (port !in 0..65535) {
                    return "the '$protocolName' port $port in '$address' is outside the representable " +
                        "range 0..65535"
                }
            }
            else -> Unit
        }
        index += if (protocol.hasValue) 2 else 1
    }
    return null
}

internal fun nestedCircuitPeerMultiaddressRejectionReason(address: String): String? {
    if (!address.startsWith("/")) return null
    return nestedCircuitPeerMultiaddressRejectionReason(address, address.split('/').drop(1))
}

private fun nestedCircuitPeerMultiaddressRejectionReason(
    address: String,
    components: List<String>,
): String? {
    var circuitCount = 0
    var index = 0
    while (index < components.size) {
        val protocolName = components[index]
        val protocol = Protocol.get(protocolName) ?: break
        if (protocolName == "p2p-circuit") circuitCount++
        // A path protocol owns the remainder of the address. Slash-delimited text inside that
        // path is data, not a sequence of further multiaddress protocol components.
        if (protocol.isPath) break
        index += if (protocol.hasValue) 2 else 1
    }
    return if (circuitCount > 1) {
        "the multiaddress '$address' contains $circuitCount '/p2p-circuit/' components; " +
            "relay circuit addresses may contain at most one"
    } else {
        null
    }
}

internal fun filterNestedCircuitPeerMultiaddresses(
    peerId: String,
    addresses: List<String>,
    acceptanceContext: String,
): List<String> = addresses.filter { address ->
    val reason = nestedCircuitPeerMultiaddressRejectionReason(address)
    if (reason != null) {
        reportPeerMultiaddressRejection(peerId, address, acceptanceContext, reason)
    }
    reason == null
}

internal fun reportPeerMultiaddressRejection(
    peerId: String,
    address: String,
    acceptanceContext: String,
    reason: String,
) {
    val effect = PeerMultiaddressRejectedWarningEffect(peerId, address, acceptanceContext, reason)
    try {
        toss(effect)
    } catch (unhandled: UnhandledNotificationEffect) {
        // Rejected network input remains safely dropped when the application has no warning
        // handler. Only this exact notification is optional; unrelated unhandled effects propagate.
        if (unhandled.effect !== effect) throw unhandled
    }
}

private fun ipv4RejectionReason(host: String): String? {
    val octetTexts = host.split('.')
    if (octetTexts.size != 4) {
        return "the IPv4 address '$host' does not have exactly four octets"
    }
    val octets = octetTexts.map { text ->
        if (text.isEmpty() || text.any { !it.isDigit() }) {
            return "the IPv4 address '$host' has a non-numeric octet '$text'"
        }
        val octet = text.toIntOrNull()
            ?: return "the IPv4 address '$host' has a non-numeric octet '$text'"
        if (octet !in 0..255) {
            return "the IPv4 address '$host' has an octet $octet outside 0..255"
        }
        octet
    }
    return when {
        octets[0] == 0 ->
            "the IPv4 address '$host' is in the unroutable 0.0.0.0/8 'this network' block"
        octets[0] == 169 && octets[1] == 254 ->
            "the IPv4 address '$host' is a link-local 169.254.0.0/16 address that is never " +
                "routed off-link"
        octets[0] in 224..239 ->
            "the IPv4 address '$host' is a multicast 224.0.0.0/4 address, not a unicast peer"
        octets[0] >= 240 ->
            "the IPv4 address '$host' is in the reserved 240.0.0.0/4 block (which includes the " +
                "255.255.255.255 limited-broadcast address)"
        else -> null
    }
}

private fun ipv6RejectionReason(host: String): String? {
    if (!host.contains(':')) {
        return "the IPv6 address '$host' contains no ':' separator"
    }
    val parsed = try {
        InetAddress.getByName(host)
    } catch (_: Exception) {
        null
    }
    if (parsed !is Inet6Address) {
        return "the IPv6 address '$host' is not a valid IPv6 literal"
    }
    val bytes = parsed.address
    if (bytes.all { it.toInt() == 0 }) {
        return "the IPv6 address '$host' is the unspecified address '::', which is not dialable"
    }
    if ((bytes[0].toInt() and 0xff) == 0xff) {
        return "the IPv6 address '$host' is a multicast ff00::/8 address, not a unicast peer"
    }
    return null
}
