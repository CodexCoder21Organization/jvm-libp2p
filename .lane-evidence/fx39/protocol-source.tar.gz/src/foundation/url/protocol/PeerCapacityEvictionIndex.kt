package foundation.url.protocol

import java.util.Comparator
import java.util.TreeSet
import java.util.TreeMap

private fun validatePeerCapacityEvictionEntry(entry: PeerCapacityEvictionEntry) {
    require(entry.tier in 0..3) {
        "Peer capacity tier for '${entry.peerId}' must be in 0..3, but was ${entry.tier}."
    }
    require(entry.family == 0 || entry.family == 32 || entry.family == 64) {
        "Peer capacity address family for '${entry.peerId}' must be 0, 32, or 64, " +
            "but was ${entry.family}."
    }
}

/** Evidence, then positive-score caller history, precede address population at every index level. */
private fun comparePeerCapacityEvidence(
    left: PeerCapacityEvictionEntry,
    right: PeerCapacityEvictionEntry,
): Int {
    val successOrder = left.hasSuccessfulObservation.compareTo(right.hasSuccessfulObservation)
    if (successOrder != 0) return successOrder

    val scoreOrder = left.localScore.compareTo(right.localScore)
    if (scoreOrder != 0) return scoreOrder

    val tenureOrder = left.witnessedTenureMs.compareTo(right.witnessedTenureMs)
    if (tenureOrder != 0) return tenureOrder

    // Zero-score peers keep their existing evidence and diversity ordering, regardless of origin.
    if (left.tier == 0) return 0
    return left.hasCallerOrigin.compareTo(right.hasCallerOrigin)
}

/** Negative means [left] is the weaker, earlier eviction candidate. */
private fun comparePeerCapacityVictims(
    left: PeerCapacityEvictionEntry,
    right: PeerCapacityEvictionEntry,
): Int {
    val evidenceOrder = comparePeerCapacityEvidence(left, right)
    if (evidenceOrder != 0) return evidenceOrder

    val sequenceOrder = left.insertionSequence.compareTo(right.insertionSequence)
    if (sequenceOrder != 0) return sequenceOrder

    // Larger peer IDs are weaker, so they sort first among otherwise equal records.
    return right.peerId.compareTo(left.peerId)
}

/**
 * Immutable metadata retained for one peer by [PeerCapacityEvictionIndex].
 *
 * The keys are already canonicalized by the registry. In particular, IPv4 and IPv6 prefixes are
 * represented by fixed-width numeric hexadecimal strings, while family `0` represents no address.
 */
internal data class PeerCapacityEvictionEntry(
    val peerId: String,
    val tier: Int,
    val family: Int,
    val blockKey: String,
    val addressKey: String,
    val localScore: Double,
    val witnessedTenureMs: Long,
    val insertionSequence: Long,
    val hasCallerOrigin: Boolean = false,
    val hasSuccessfulObservation: Boolean = false,
)

internal data class PeerCapacityEvictionIndexState(
    val work: Long,
    val entries: Int,
    val nodes: Int,
)

/**
 * Incremental capacity-victim selection over the live peer set.
 *
 * Callers serialize mutations and selection. This class has no locks and never calls caller code.
 * Every nonempty group caches its population and selected descendant. Evidence is compared before
 * population, so every cached descendant has the weakest evidence in its group. Its parent `TreeSet` is
 * detached before either cached value changes and reattached after the child state is current.
 * Empty groups are removed as soon as their last peer leaves.
 *
 * `nodeCount` counts peer-record and group objects: for `n` peers, `a` address groups, `b` block
 * groups, `f` family groups, and `t` active tiers, it is exactly `n + a + b + f + t`. Each peer
 * adds two live index memberships (one ID-map entry and one leaf-tree entry); each address, block,
 * and family group adds two (one parent-map entry and one parent-tree entry); each active tier adds
 * one root-array slot. A tier and family group each own a map and a `TreeSet`, a block group owns
 * a map and a `TreeSet`, an address group owns its entry `TreeSet`, and one peer-ID map exists while
 * the index is nonempty. These secondary references and containers are constant per live object,
 * so they are also O(n). The fixed four-slot root array and implementation-specific backing
 * capacity are excluded. Empty groups and historical or lazy-deletion records are never retained.
 *
 * `workCount` counts every ordered-set comparator invocation, each candidate/group head visit, and
 * each selection. It also counts every key-map comparator invocation and the fixed root-slot visits
 * used to locate the lowest nonempty tier. The counter is cumulative for this index instance.
 */
internal class PeerCapacityEvictionIndex {
    private class TierGroup(
        familyKeyOrder: Comparator<Int>,
        familyOrder: Comparator<FamilyGroup>,
    ) {
        val familiesByKey = TreeMap<Int, FamilyGroup>(familyKeyOrder)
        val familiesByPopulation = TreeSet(familyOrder)
        var population: Int = 0
        var victim: PeerCapacityEvictionEntry? = null
    }

    private class FamilyGroup(
        blockKeyOrder: Comparator<String>,
        blockOrder: Comparator<BlockGroup>,
    ) {
        val blocksByKey = TreeMap<String, BlockGroup>(blockKeyOrder)
        val blocksByPopulation = TreeSet(blockOrder)
        var population: Int = 0
        var victim: PeerCapacityEvictionEntry? = null
    }

    private class BlockGroup(
        addressKeyOrder: Comparator<String>,
        addressOrder: Comparator<AddressGroup>,
    ) {
        val addressesByKey = TreeMap<String, AddressGroup>(addressKeyOrder)
        val addressesByPopulation = TreeSet(addressOrder)
        var population: Int = 0
        var victim: PeerCapacityEvictionEntry? = null
    }

    private class AddressGroup(entryOrder: Comparator<PeerCapacityEvictionEntry>) {
        val entriesByVictim = TreeSet(entryOrder)
        var population: Int = 0
        var victim: PeerCapacityEvictionEntry? = null
    }

    private val roots = arrayOfNulls<TierGroup>(4)
    private var entriesByPeerId: TreeMap<String, PeerCapacityEvictionEntry>? = null
    private var liveEntryCount = 0
    private var activeTierCount = 0
    private var liveFamilyGroupCount = 0
    private var liveBlockGroupCount = 0
    private var liveAddressGroupCount = 0
    private var accumulatedWorkCount = 0L

    private val entryOrder = Comparator<PeerCapacityEvictionEntry> { left, right ->
        // One comparator call and visits to both ordered candidates.
        accumulatedWorkCount += 3L
        comparePeerCapacityVictims(left, right)
    }

    private val addressOrder = Comparator<AddressGroup> { left, right ->
        compareChildren(left.population, left.victim, right.population, right.victim)
    }

    private val blockOrder = Comparator<BlockGroup> { left, right ->
        compareChildren(left.population, left.victim, right.population, right.victim)
    }

    private val familyOrder = Comparator<FamilyGroup> { left, right ->
        compareChildren(left.population, left.victim, right.population, right.victim)
    }

    private val peerIdKeyOrder = Comparator<String> { left, right ->
        countKeyComparison()
        left.compareTo(right)
    }

    private val familyKeyOrder = Comparator<Int> { left, right ->
        countKeyComparison()
        left.compareTo(right)
    }

    private val blockKeyOrder = Comparator<String> { left, right ->
        countKeyComparison()
        left.compareTo(right)
    }

    private val addressKeyOrder = Comparator<String> { left, right ->
        countKeyComparison()
        left.compareTo(right)
    }

    internal val entryCount: Int
        get() = liveEntryCount

    internal val workCount: Long
        get() = accumulatedWorkCount

    internal val nodeCount: Long
        get() = liveEntryCount.toLong() +
            liveAddressGroupCount +
            liveBlockGroupCount +
            liveFamilyGroupCount +
            activeTierCount

    /**
     * Returns the indexed metadata so an observation can update its score and tenure while
     * preserving the caller-origin tie-break used after positive-score evidence.
     */
    fun entry(peerId: String): PeerCapacityEvictionEntry? = entriesByPeerId?.get(peerId)

    /** Replaces any current record with this peer ID, then inserts the new metadata. */
    fun upsert(entry: PeerCapacityEvictionEntry) {
        validatePeerCapacityEvictionEntry(entry)

        val byPeerId = entriesByPeerId ?: TreeMap<String, PeerCapacityEvictionEntry>(peerIdKeyOrder).also {
            entriesByPeerId = it
        }
        val previous = byPeerId.put(entry.peerId, entry)
        if (previous != null) removeEntryGroups(previous)
        insertEntryGroups(entry)
    }

    private fun insertAbsentEntry(entry: PeerCapacityEvictionEntry) {
        val byPeerId = entriesByPeerId ?: TreeMap<String, PeerCapacityEvictionEntry>(peerIdKeyOrder).also {
            entriesByPeerId = it
        }
        check(byPeerId.put(entry.peerId, entry) == null) {
            "Peer '${entry.peerId}' was already present in the capacity index before absent insertion."
        }

        insertEntryGroups(entry)
    }

    private fun insertEntryGroups(entry: PeerCapacityEvictionEntry) {
        val tier = roots[entry.tier] ?: TierGroup(familyKeyOrder, familyOrder).also {
            roots[entry.tier] = it
            activeTierCount++
        }
        val family = tier.familiesByKey[entry.family] ?: FamilyGroup(blockKeyOrder, blockOrder).also {
            tier.familiesByKey[entry.family] = it
            liveFamilyGroupCount++
        }
        val block = family.blocksByKey[entry.blockKey] ?: BlockGroup(addressKeyOrder, addressOrder).also {
            family.blocksByKey[entry.blockKey] = it
            liveBlockGroupCount++
        }
        val address = block.addressesByKey[entry.addressKey] ?: AddressGroup(entryOrder).also {
            block.addressesByKey[entry.addressKey] = it
            liveAddressGroupCount++
        }

        detachPath(tier, family, block, address)

        check(address.entriesByVictim.add(entry)) {
            "Peer '${entry.peerId}' was already present in its capacity address group after upsert removal."
        }
        address.population++
        address.victim = firstCandidate(address.entriesByVictim)

        block.addressesByPopulation.add(address)
        block.population++
        block.victim = firstAddressChildVictim(block.addressesByPopulation)

        family.blocksByPopulation.add(block)
        family.population++
        family.victim = firstBlockChildVictim(family.blocksByPopulation)

        tier.familiesByPopulation.add(family)
        tier.population++
        tier.victim = firstFamilyChildVictim(tier.familiesByPopulation)

        liveEntryCount++
    }

    /** Removes a peer and every group that becomes empty. Returns whether the peer was present. */
    fun remove(peerId: String): Boolean {
        val byPeerId = entriesByPeerId ?: return false
        val entry = byPeerId.remove(peerId) ?: return false
        removeEntryGroups(entry)
        if (liveEntryCount == 0) entriesByPeerId = null
        return true
    }

    private fun removeEntryGroups(entry: PeerCapacityEvictionEntry) {
        val tier = checkNotNull(roots[entry.tier]) {
            "Peer '${entry.peerId}' has no live tier group ${entry.tier}."
        }
        val family = checkNotNull(tier.familiesByKey[entry.family]) {
            "Peer '${entry.peerId}' has no live family group ${entry.family}."
        }
        val block = checkNotNull(family.blocksByKey[entry.blockKey]) {
            "Peer '${entry.peerId}' has no live block group '${entry.blockKey}'."
        }
        val address = checkNotNull(block.addressesByKey[entry.addressKey]) {
            "Peer '${entry.peerId}' has no live address group '${entry.addressKey}'."
        }

        detachPath(tier, family, block, address)

        check(address.entriesByVictim.remove(entry)) {
            "Peer '${entry.peerId}' was missing from its capacity address group."
        }
        address.population--
        address.victim = if (address.population == 0) null else firstCandidate(address.entriesByVictim)

        if (address.population == 0) {
            check(block.addressesByKey.remove(entry.addressKey) === address)
            liveAddressGroupCount--
        } else {
            block.addressesByPopulation.add(address)
        }

        block.population--
        block.victim = if (block.population == 0) null else {
            firstAddressChildVictim(block.addressesByPopulation)
        }
        if (block.population == 0) {
            check(family.blocksByKey.remove(entry.blockKey) === block)
            liveBlockGroupCount--
        } else {
            family.blocksByPopulation.add(block)
        }

        family.population--
        family.victim = if (family.population == 0) null else {
            firstBlockChildVictim(family.blocksByPopulation)
        }
        if (family.population == 0) {
            check(tier.familiesByKey.remove(entry.family) === family)
            liveFamilyGroupCount--
        } else {
            tier.familiesByPopulation.add(family)
        }

        tier.population--
        tier.victim = if (tier.population == 0) null else {
            firstFamilyChildVictim(tier.familiesByPopulation)
        }
        if (tier.population == 0) {
            check(tier.familiesByKey.isEmpty())
            check(roots[entry.tier] === tier)
            roots[entry.tier] = null
            activeTierCount--
        }

        liveEntryCount--
    }

    /**
     * Returns up to [count] victims in pop order while restoring the exact same live entries.
     * The caller must serialize this operation with mutations.
     */
    fun victims(count: Int): List<String> {
        require(count >= 0) {
            "Peer capacity victim count must be zero or greater, but was $count."
        }
        val selectedCount = minOf(count, liveEntryCount)
        if (selectedCount == 0) return emptyList()

        val temporarilyRemoved = ArrayList<PeerCapacityEvictionEntry>(selectedCount - 1)
        val peerIds = ArrayList<String>(selectedCount)
        try {
            for (index in 0 until selectedCount) {
                val victim = checkNotNull(selectVictim()) {
                    "The capacity index contained $liveEntryCount peers but could not select a victim."
                }
                peerIds.add(victim.peerId)
                if (index + 1 < selectedCount) {
                    // Keep the final selected record indexed; this also makes victims(1) read-only.
                    check(remove(victim.peerId)) {
                        "Selected capacity victim '${victim.peerId}' could not be removed from the index."
                    }
                    temporarilyRemoved.add(victim)
                }
            }
        } finally {
            for (entry in temporarilyRemoved) {
                // Selection is serialized and invokes no callbacks, so these entries are still
                // absent. Replacing them would repeat an unnecessary peer-ID removal search.
                insertAbsentEntry(entry)
            }
        }
        return peerIds
    }

    /** Detach every live ordered child before any population or cached head on the path changes. */
    private fun detachPath(
        tier: TierGroup,
        family: FamilyGroup,
        block: BlockGroup,
        address: AddressGroup,
    ) {
        if (family.population > 0) {
            check(tier.familiesByPopulation.remove(family))
        }
        if (block.population > 0) {
            check(family.blocksByPopulation.remove(block))
        }
        if (address.population > 0) {
            check(block.addressesByPopulation.remove(address))
        }
    }

    private fun selectVictim(): PeerCapacityEvictionEntry? {
        var tier: TierGroup? = null
        for (tierNumber in roots.indices) {
            accumulatedWorkCount++ // Visit one of the fixed root slots.
            val candidate = roots[tierNumber]
            if (candidate != null) {
                accumulatedWorkCount++ // Select the lowest nonempty tier.
                tier = candidate
                break
            }
        }
        val selectedTier = tier ?: return null
        accumulatedWorkCount += 2L // Read the cached tier victim and select it.
        return checkNotNull(selectedTier.victim) {
            "A nonempty capacity tier had no cached victim."
        }
    }

    private fun <T> firstCandidate(ordered: TreeSet<T>): T {
        check(ordered.isNotEmpty()) { "Cannot select a candidate from an empty capacity index group." }
        accumulatedWorkCount += 2L // Visit the set head and select that candidate.
        return ordered.first()
    }

    private fun firstAddressChildVictim(ordered: TreeSet<AddressGroup>): PeerCapacityEvictionEntry {
        val child = firstCandidate(ordered)
        accumulatedWorkCount++ // Read the selected child's cached victim head.
        return checkNotNull(child.victim)
    }

    private fun firstBlockChildVictim(ordered: TreeSet<BlockGroup>): PeerCapacityEvictionEntry {
        val child = firstCandidate(ordered)
        accumulatedWorkCount++ // Read the selected child's cached victim head.
        return checkNotNull(child.victim)
    }

    private fun firstFamilyChildVictim(ordered: TreeSet<FamilyGroup>): PeerCapacityEvictionEntry {
        val child = firstCandidate(ordered)
        accumulatedWorkCount++ // Read the selected child's cached victim head.
        return checkNotNull(child.victim)
    }

    private fun compareChildren(
        leftPopulation: Int,
        leftVictim: PeerCapacityEvictionEntry?,
        rightPopulation: Int,
        rightVictim: PeerCapacityEvictionEntry?,
    ): Int {
        accumulatedWorkCount += 3L // One comparator call and visits to both child candidates.
        // TreeSet compares a new root with itself. A peer belongs to only one child at each
        // level, so identical nonnull heads also identify the same child without reading it.
        if (leftVictim != null && leftVictim === rightVictim) return 0
        accumulatedWorkCount += 2L // Read both cached victim heads before comparing population.
        val left = checkNotNull(leftVictim) { "A nonempty capacity group had no cached victim." }
        val right = checkNotNull(rightVictim) { "A nonempty capacity group had no cached victim." }
        val evidenceOrder = comparePeerCapacityEvidence(left, right)
        if (evidenceOrder != 0) return evidenceOrder

        val populationOrder = rightPopulation.compareTo(leftPopulation)
        if (populationOrder != 0) return populationOrder

        return comparePeerCapacityVictims(left, right)
    }

    private fun countKeyComparison() {
        accumulatedWorkCount++
    }
}
