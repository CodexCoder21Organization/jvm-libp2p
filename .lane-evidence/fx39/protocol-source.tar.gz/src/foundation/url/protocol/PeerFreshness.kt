package foundation.url.protocol

import org.json.JSONObject

/** Source-declared peer evidence with a remaining lifetime that can be consumed at each forwarding step. */
data class PeerFreshness(
    val observerPeerId: String,
    val observationId: String,
    val remainingLifetimeMillis: Long,
) {
    init {
        require(observerPeerId.isNotBlank()) { "observerPeerId must not be blank" }
        require(observationId.isNotBlank()) { "observationId must not be blank" }
        require(remainingLifetimeMillis >= 0L) {
            "remainingLifetimeMillis must be non-negative, but was $remainingLifetimeMillis"
        }
    }

    fun agedBy(elapsedMillis: Long): PeerFreshness {
        require(elapsedMillis >= 0L) { "elapsedMillis must be non-negative, but was $elapsedMillis" }
        val remaining = if (elapsedMillis >= remainingLifetimeMillis) {
            0L
        } else {
            remainingLifetimeMillis - elapsedMillis
        }
        return copy(remainingLifetimeMillis = remaining)
    }

    fun toJson(): JSONObject = JSONObject()
        .put("observerPeerId", observerPeerId)
        .put("observationId", observationId)
        .put("remainingLifetimeMillis", remainingLifetimeMillis)

    companion object {
        /** Longer optional identifiers are treated as absent evidence, preserving the enclosing routes. */
        const val MAX_IDENTIFIER_CHARACTERS = 1024

        fun fromJson(json: JSONObject?): PeerFreshness? {
            if (json == null) return null
            val observerPeerId = json.opt("observerPeerId") as? String ?: return null
            val observationId = json.opt("observationId") as? String ?: return null
            if (observerPeerId.length > MAX_IDENTIFIER_CHARACTERS ||
                observationId.length > MAX_IDENTIFIER_CHARACTERS) return null
            val lifetimeValue = json.opt("remainingLifetimeMillis") as? Number ?: return null
            val lifetime = lifetimeValue.toString().toLongOrNull() ?: return null
            if (observerPeerId.isBlank() || observationId.isBlank() || lifetime < 0L) return null
            return PeerFreshness(observerPeerId, observationId, lifetime)
        }
    }
}

internal fun peerFreshnessDataClassHash(vararg values: Any?): Int {
    if (values.isEmpty()) return 0
    var result = values[0]?.hashCode() ?: 0
    for (index in 1 until values.size) {
        result = 31 * result + (values[index]?.hashCode() ?: 0)
    }
    return result
}
