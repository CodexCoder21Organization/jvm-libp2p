package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import java.util.PriorityQueue
import java.util.concurrent.atomic.AtomicLong

internal data class PeerFreshnessTimeSample(
    val nowMillis: Long,
    val order: Long,
    val wallMillis: Long,
    val precedingCompletionOrder: Long,
    val epoch: Any,
    val timeline: PeerClockTimeline
)

internal class PeerClockTimeline {
    private var epoch = Any()
    private var completedOrder = Long.MIN_VALUE
    private var observedOrder = Long.MIN_VALUE
    private var observedMillis: Long? = null

    @Synchronized
    fun beginRead(): Pair<Any, Long> = epoch to completedOrder

    @Synchronized
    fun completeRead(start: Pair<Any, Long>, now: Long, wall: Long): PeerFreshnessTimeSample {
        val order = peerTimeSampleOrder.getAndIncrement()
        completedOrder = order
        var sampleEpoch = start.first
        if (sampleEpoch === epoch) {
            val previous = observedMillis
            val overlappingSmaller = previous != null && now < previous && start.second < observedOrder
            if (!overlappingSmaller) {
                if (previous != null && now < previous) {
                    epoch = Any()
                    sampleEpoch = epoch
                }
                observedMillis = now
                observedOrder = order
            }
        }
        return PeerFreshnessTimeSample(now, order, wall, start.second, sampleEpoch, this)
    }

    @Synchronized
    fun isCurrent(sampleEpoch: Any): Boolean = sampleEpoch === epoch
}

private data class PeerWindowTime(val nowMillis: Long, val isCurrentEpoch: Boolean)

private val peerTimeSampleOrder = AtomicLong()
private val systemPeerClockKey = Any()
private val peerActionTimes = ThreadLocal<java.util.IdentityHashMap<Any, PeerPreparedTime>>()
private val peerPersistenceTimeDepth = ThreadLocal<Int>()
private val releasedPeerClocks = java.lang.ref.ReferenceQueue<Clock>()
private val completedPeerClockTimes = java.util.concurrent.ConcurrentHashMap<
    PeerClockIdentity, PeerClockTimeline
>()
private val completedSystemPeerClockTime = PeerClockTimeline()

private data class PeerRegistryActionTime(
    val wallMillis: Long,
    val elapsed: PeerFreshnessTimeSample
)

private enum class PeerTimeScope(val differentClockMessage: String) {
    ACTION(
        "Cannot sample a different Clock while a PeerLifetime.runIfActive action is executing; " +
            "run this operation after the active action returns"
    ),
    PERSISTENCE(
        "Cannot sample a different Clock while a peer persistence operation is executing; " +
            "run this operation after the persistence operation returns"
    )
}

private data class PeerPreparedTime(val time: PeerRegistryActionTime, val scope: PeerTimeScope)

private fun <T> withPeerTimeScope(
    key: Any,
    time: PeerRegistryActionTime,
    scope: PeerTimeScope,
    action: () -> T
): T {
    val previous = peerActionTimes.get()
    peerActionTimes.set(java.util.IdentityHashMap<Any, PeerPreparedTime>().also {
        it[key] = PeerPreparedTime(time, scope)
    })
    try {
        return action()
    } finally {
        if (previous == null) peerActionTimes.remove() else peerActionTimes.set(previous)
    }
}

internal fun checkPeerCallbackCanWait(monitor: String) {
    check((peerPersistenceTimeDepth.get() ?: 0) == 0) {
        "A storage callback cannot wait for $monitor while peer persistence ownership is held; " +
            "run this operation after the persistence operation returns"
    }
}

private class PeerClockIdentity(clock: Clock) : java.lang.ref.WeakReference<Clock>(clock, releasedPeerClocks) {
    private val identityHash = System.identityHashCode(clock)

    override fun hashCode(): Int = identityHash

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PeerClockIdentity) return false
        val current = get() ?: return false
        return current === other.get()
    }
}

private fun completedPeerClockTime(clock: Clock): PeerClockTimeline {
    var released = releasedPeerClocks.poll()
    while (released != null) {
        if (released is PeerClockIdentity) completedPeerClockTimes.remove(released)
        released = releasedPeerClocks.poll()
    }
    val key = peerClockKey(clock)
    if (key === systemPeerClockKey) return completedSystemPeerClockTime
    return completedPeerClockTimes.computeIfAbsent(PeerClockIdentity(key as Clock)) { PeerClockTimeline() }
}

private fun peerClockKey(clock: Clock): Any = when (clock) {
    is PeerRegistryClock -> clock.sourceKey
    is SystemClock -> systemPeerClockKey
    else -> clock
}

private fun preparedPeerActionTime(clock: Clock): PeerRegistryActionTime? {
    val times = peerActionTimes.get() ?: return null
    return times[peerClockKey(clock)]?.time
        ?: throw IllegalStateException(times.values.first().scope.differentClockMessage)
}

private fun capturePeerClockTime(clock: Clock): PeerRegistryActionTime {
    preparedPeerActionTime(clock)?.let { return it }
    val completed = completedPeerClockTime(clock)
    val start = completed.beginRead()
    val wallMillis = clock.currentTimeMillis()
    val elapsedMillis = if (clock is SystemClock) System.nanoTime() / 1_000_000L else wallMillis
    return PeerRegistryActionTime(
        wallMillis,
        completed.completeRead(start, elapsedMillis, wallMillis)
    )
}

// Action scope ends on return. Outside ownership, callbacks read the source again;
// the completion metadata never substitutes another read's value.
internal class PeerRegistryClock(private val source: Clock) : Clock by source {
    val sourceKey: Any = peerClockKey(source)

    override fun currentTimeMillis(): Long =
        preparedPeerActionTime(source)?.wallMillis ?: sampleSource().wallMillis

    fun sampleFreshnessTime(): PeerFreshnessTimeSample =
        preparedPeerActionTime(source)?.elapsed ?: sampleSource().elapsed

    fun <T> withActionSample(
        action: () -> T,
        withPreparedScope: (() -> T) -> T
    ): T {
        if (preparedPeerActionTime(source) != null) return withPreparedScope(action)
        val sample = sampleSource()
        return withPreparedScope {
            withPeerTimeScope(sourceKey, sample, PeerTimeScope.ACTION, action)
        }
    }

    fun <T> withPreparedSample(sample: PeerFreshnessTimeSample, action: () -> T): T {
        val previousDepth = peerPersistenceTimeDepth.get() ?: 0
        peerPersistenceTimeDepth.set(previousDepth + 1)
        try {
            if (preparedPeerActionTime(source) != null) return action()
            return withPeerTimeScope(
                sourceKey, PeerRegistryActionTime(sample.wallMillis, sample), PeerTimeScope.PERSISTENCE, action
            )
        } finally {
            if (previousDepth == 0) peerPersistenceTimeDepth.remove()
            else peerPersistenceTimeDepth.set(previousDepth)
        }
    }

    private fun sampleSource(): PeerRegistryActionTime = capturePeerClockTime(source)
}

internal fun peerRegistryWallTimeMillis(clock: Clock): Long =
    preparedPeerActionTime(clock)?.wallMillis ?: when (clock) {
        is PeerRegistryClock -> clock.currentTimeMillis()
        else -> capturePeerClockTime(clock).wallMillis
    }

internal fun samplePeerFreshnessTime(clock: Clock): PeerFreshnessTimeSample =
    preparedPeerActionTime(clock)?.elapsed ?: when (clock) {
        is PeerRegistryClock -> clock.sampleFreshnessTime()
        else -> capturePeerClockTime(clock).elapsed
    }

/** An immutable view of the best retained evidence and its change version. */
data class PeerFreshnessWindowSnapshot(
    val freshness: PeerFreshness?,
    val version: Long
)

internal data class PeerFreshnessHistoryEntry(
    val freshness: PeerFreshness,
    val retentionMillis: Long
)

internal data class PeerFreshnessHistorySnapshot(
    val freshness: PeerFreshness?,
    val entries: List<PeerFreshnessHistoryEntry>
)

/**
 * Keeps bounded, process-local freshness evidence and recent removal history for peer ids.
 *
 * Freshness values are durations, not timestamps from another machine. Senders must consume time
 * spent forwarding a value; this window subtracts the measured exchange duration and then ages the
 * accepted duration using elapsed time. The default [SystemClock] path uses JVM monotonic time;
 * injected clocks drive deterministic tests and must advance with elapsed time. It never compares
 * remote wall clocks. The finite [maxLifetimeMillis] horizon assumes senders follow that duration
 * rule.
 *
 * The same subject, observer, and observation token is kept until its first-acceptance horizon
 * ends, so receiving that token again cannot extend either its expiry or its retention. New token
 * histories and per-peer removal records are declined when an explicit [maxEntries] limit is full; existing records
 * are not discarded to make room. If a removal record cannot fit, a single process-local hold
 * pauses legacy admission for all peer ids for that removal interval. Imported freshness never
 * clears removal history. If an injected clock moves backward, usable imported durations expire
 * and retained token history and removal holds get a fresh conservative retention interval. Exact
 * duration aging depends on the supplied clock advancing with elapsed time. The registry persists
 * token identities and restores them with zero usable duration; removal holds stay process-local.
 * Token history lasts for the longer of the reader horizon
 * and the first declared source remainder. A release-time queue handles differing source horizons;
 * removal markers retain their fixed interval and renewed markers move to the end of their order.
 */
class PeerFreshnessWindow(
    private val clock: Clock = SystemClock(),
    val maxLifetimeMillis: Long = 300_000L,
    val maxEntries: Int? = null
) {
    private data class TokenKey(
        val subjectPeerId: String,
        val observerPeerId: String,
        val observationId: String
    )

    private data class TokenRecord(
        val expiresAtMillis: Long,
        val releaseAtMillis: Long,
        val retentionMillis: Long
    )

    private data class TokenExpiry(val key: TokenKey, val releaseAtMillis: Long)

    private data class SubjectState(
        val tokens: MutableSet<TokenKey> = LinkedHashSet(),
        var bestToken: TokenKey? = null,
        var bestExpiryAtMillis: Long? = null,
        var bestFreshness: PeerFreshness? = null,
        var version: Long = 0L
    )

    private val lock = Any()
    private val tokenRecords = LinkedHashMap<TokenKey, TokenRecord>()
    private val tokenExpiries = PriorityQueue<TokenExpiry>(compareBy { it.releaseAtMillis })
    private val subjectStates = HashMap<String, SubjectState>()
    private val removalMarkers = LinkedHashMap<String, Long>()
    private val pendingRemovalMarkers = LinkedHashSet<String>()
    private var pendingGlobalLegacyHold = false
    private var globalLegacyHoldUntilMillis: Long? = null
    private var lastObservedEpoch: Any? = null
    private var lastObservedTimeMillis: Long? = null
    private var lastObservedSampleOrder = Long.MIN_VALUE
    private var lastVersion = 0L

    init {
        require(maxLifetimeMillis > 0L) {
            "maxLifetimeMillis must be greater than zero, but was $maxLifetimeMillis"
        }
        require(maxEntries == null || maxEntries > 0) {
            "maxEntries must be greater than zero, but was $maxEntries"
        }
    }

    /**
     * Accepts imported evidence for [subjectPeerId] and returns the current immutable view.
     *
     * A null result means this subject has no retained history. Evidence with no duration left
     * after [exchangeElapsedMillis], or new evidence that cannot fit within the configured bound,
     * is not accepted. A known token returns the existing view without changing its expiry.
     */
    fun accept(
        subjectPeerId: String,
        freshness: PeerFreshness,
        exchangeElapsedMillis: Long = 0L
    ): PeerFreshnessWindowSnapshot? {
        require(subjectPeerId.isNotBlank()) { "subjectPeerId must not be blank" }
        require(exchangeElapsedMillis >= 0L) {
            "exchangeElapsedMillis must be non-negative, but was $exchangeElapsedMillis"
        }

        val receivedAtTimeSample = sampleTime()
        return acceptFromReceipt(
            subjectPeerId = subjectPeerId,
            freshness = freshness,
            exchangeElapsedMillis = exchangeElapsedMillis,
            receivedAtElapsedMillis = receivedAtTimeSample.nowMillis,
            timeSample = sampleTime(),
            receivedAtTimeSample = receivedAtTimeSample
        )
    }

    internal fun acceptFromReceipt(
        subjectPeerId: String,
        freshness: PeerFreshness,
        exchangeElapsedMillis: Long,
        receivedAtElapsedMillis: Long,
        timeSample: PeerFreshnessTimeSample,
        receivedAtTimeSample: PeerFreshnessTimeSample? = null
    ): PeerFreshnessWindowSnapshot? {
        require(subjectPeerId.isNotBlank()) { "subjectPeerId must not be blank" }
        require(exchangeElapsedMillis >= 0L) {
            "exchangeElapsedMillis must be non-negative, but was $exchangeElapsedMillis"
        }

        return synchronized(lock) {
            val observed = observeTime(timeSample)
            val now = observed.nowMillis
            if (observed.isCurrentEpoch) purgeExpired(now)
            if (!observed.isCurrentEpoch ||
                (receivedAtTimeSample != null && receivedAtTimeSample.epoch !== timeSample.epoch)) {
                return@synchronized snapshotAt(subjectPeerId, now, usableDuration = false)
            }
            val key = TokenKey(subjectPeerId, freshness.observerPeerId, freshness.observationId)
            if (tokenRecords.containsKey(key)) {
                return@synchronized snapshotAt(subjectPeerId, now)
            }

            val elapsedSinceReceiptMillis = nonNegativeElapsedSince(receivedAtElapsedMillis, now)
            val totalElapsedMillis = saturatingAddNonNegative(
                exchangeElapsedMillis,
                elapsedSinceReceiptMillis
            )
            val afterExchange = if (totalElapsedMillis >= freshness.remainingLifetimeMillis) {
                0L
            } else {
                freshness.remainingLifetimeMillis - totalElapsedMillis
            }
            if (afterExchange <= 0L) {
                return@synchronized snapshotAt(subjectPeerId, now)
            }

            val acceptedLifetime = minOf(afterExchange, maxLifetimeMillis)
            val expiresAt = saturatingAddNonNegative(now, acceptedLifetime)
            if (expiresAt <= now || (maxEntries != null && entryCount() >= maxEntries)) {
                return@synchronized snapshotAt(subjectPeerId, now)
            }

            val retentionMillis = maxOf(maxLifetimeMillis, freshness.remainingLifetimeMillis)
            val record = TokenRecord(
                expiresAtMillis = expiresAt,
                releaseAtMillis = saturatingAddNonNegative(now, retentionMillis),
                retentionMillis = retentionMillis
            )
            tokenRecords[key] = record
            tokenExpiries.add(TokenExpiry(key, record.releaseAtMillis))

            val subjectState = subjectStates.getOrPut(subjectPeerId) { SubjectState() }
            subjectState.tokens.add(key)
            val currentBestExpiry = subjectState.bestExpiryAtMillis
            if (currentBestExpiry == null || expiresAt > currentBestExpiry) {
                subjectState.bestToken = key
                subjectState.bestExpiryAtMillis = expiresAt
                subjectState.bestFreshness = freshness.copy(remainingLifetimeMillis = acceptedLifetime)
                subjectState.version = nextVersion()
            }

            snapshotAt(subjectPeerId, now)
        }
    }

    /** Returns an immutable snapshot; expired retained evidence has zero remaining lifetime. */
    fun snapshot(subjectPeerId: String): PeerFreshnessWindowSnapshot? =
        snapshotAtTime(subjectPeerId, sampleTime())

    internal fun snapshotAtTime(
        subjectPeerId: String,
        timeSample: PeerFreshnessTimeSample
    ): PeerFreshnessWindowSnapshot? = synchronized(lock) {
        require(subjectPeerId.isNotBlank()) { "subjectPeerId must not be blank" }
        val observed = observeTime(timeSample)
        val now = observed.nowMillis
        if (observed.isCurrentEpoch) purgeExpired(now)
        snapshotAt(subjectPeerId, now, observed.isCurrentEpoch)
    }

    /** Copies all retained identities for this subject without exporting elapsed-clock instants. */
    internal fun historySnapshot(
        subjectPeerId: String,
        timeSample: PeerFreshnessTimeSample
    ): PeerFreshnessHistorySnapshot = synchronized(lock) {
        val observed = observeTime(timeSample)
        val now = observed.nowMillis
        if (observed.isCurrentEpoch) purgeExpired(now)
        val state = subjectStates[subjectPeerId]
        PeerFreshnessHistorySnapshot(
            freshness = snapshotAt(subjectPeerId, now, observed.isCurrentEpoch)?.freshness,
            entries = state?.tokens?.map { key ->
                val record = tokenRecords.getValue(key)
                PeerFreshnessHistoryEntry(
                    PeerFreshness(key.observerPeerId, key.observationId, 0L),
                    record.retentionMillis
                )
            }.orEmpty()
        )
    }

    internal fun retainedSubjectIds(timeSample: PeerFreshnessTimeSample): List<String> = synchronized(lock) {
        val observed = observeTime(timeSample)
        val now = observed.nowMillis
        if (observed.isCurrentEpoch) purgeExpired(now)
        subjectStates.keys.toList()
    }

    /** Unknown elapsed-clock continuity consumes duration and restarts each original history interval. */
    internal fun restoreHistory(
        subjectPeerId: String,
        history: List<PeerFreshnessHistoryEntry>?,
        provenance: PeerFreshness?,
        timeSample: PeerFreshnessTimeSample
    ) = synchronized(lock) {
        val observed = observeTime(timeSample)
        val now = observed.nowMillis
        if (observed.isCurrentEpoch) purgeExpired(now)
        // Older files have the identity but no original source horizon. The largest representable
        // interval keeps that identity known without guessing a shorter source policy.
        val entries = history ?: provenance?.let {
            listOf(PeerFreshnessHistoryEntry(it, Long.MAX_VALUE))
        }.orEmpty()
        for (entry in entries) {
            val key = TokenKey(subjectPeerId, entry.freshness.observerPeerId, entry.freshness.observationId)
            if (tokenRecords.containsKey(key)) continue
            val retention = maxOf(maxLifetimeMillis, entry.retentionMillis)
            val record = TokenRecord(now, saturatingAddNonNegative(now, retention), retention)
            tokenRecords[key] = record
            tokenExpiries.add(TokenExpiry(key, record.releaseAtMillis))
            subjectStates.getOrPut(subjectPeerId) { SubjectState() }.tokens.add(key)
        }
        val state = subjectStates[subjectPeerId]
        val hint = provenance ?: entries.firstOrNull()?.freshness
        if (state != null && hint != null) {
            state.bestToken = TokenKey(subjectPeerId, hint.observerPeerId, hint.observationId)
            state.bestExpiryAtMillis = now
            state.bestFreshness = hint.copy(remainingLifetimeMillis = 0L)
            state.version = nextVersion()
        }
    }

    /** Records an actual local removal and retains its marker for one configured lifetime. */
    fun recordRemoved(peerId: String) = recordRemovedAt(peerId, sampleTime())

    internal fun recordRemovedAt(peerId: String, timeSample: PeerFreshnessTimeSample): Unit = synchronized(lock) {
        require(peerId.isNotBlank()) { "peerId must not be blank" }
        val observed = observeTime(timeSample)
        val now = observed.nowMillis
        if (observed.isCurrentEpoch) purgeExpired(now)
        val releaseAt = saturatingAddNonNegative(now, maxLifetimeMillis)
        val retainedPeerId = String(peerId.toCharArray())

        if (removalMarkers.remove(peerId) != null) {
            removalMarkers[retainedPeerId] = releaseAt
            if (observed.isCurrentEpoch) pendingRemovalMarkers.remove(peerId)
            else pendingRemovalMarkers.add(retainedPeerId)
        } else if ((maxEntries == null || entryCount() < maxEntries)) {
            removalMarkers[retainedPeerId] = releaseAt
            if (!observed.isCurrentEpoch) pendingRemovalMarkers.add(retainedPeerId)
        } else {
            if (!observed.isCurrentEpoch) pendingGlobalLegacyHold = true
            val currentHold = globalLegacyHoldUntilMillis
            globalLegacyHoldUntilMillis = if (currentHold == null || releaseAt > currentHold) {
                releaseAt
            } else {
                currentHold
            }
        }
    }

    /**
     * Reports whether a legacy value may add a peer that is absent from the caller's registry.
     * This is a read-only policy check: repeating it never extends a removal marker.
     */
    fun canAcceptLegacy(peerId: String): Boolean = canAcceptLegacyAt(peerId, sampleTime())

    internal fun canAcceptLegacyAt(peerId: String, timeSample: PeerFreshnessTimeSample): Boolean = synchronized(lock) {
        require(peerId.isNotBlank()) { "peerId must not be blank" }
        val observed = observeTime(timeSample)
        val now = observed.nowMillis
        if (observed.isCurrentEpoch) purgeExpired(now)
        val underGlobalHold = globalLegacyHoldUntilMillis?.let { it > now } == true
        val underPeerHold = removalMarkers[peerId]?.let { it > now } == true
        !underGlobalHold && !underPeerHold && (maxEntries == null || entryCount() < maxEntries)
    }

    private fun snapshotAt(subjectPeerId: String, now: Long, usableDuration: Boolean = true): PeerFreshnessWindowSnapshot? {
        val state = subjectStates[subjectPeerId] ?: return null
        val bestFreshness = state.bestFreshness
        val bestExpiryAt = state.bestExpiryAtMillis
        val freshness = if (bestFreshness == null || bestExpiryAt == null) {
            null
        } else {
            bestFreshness.copy(
                remainingLifetimeMillis = if (usableDuration) positiveDurationUntil(bestExpiryAt, now) else 0L
            )
        }
        return PeerFreshnessWindowSnapshot(freshness = freshness, version = state.version)
    }

    private fun purgeExpired(now: Long) {
        // A removal sampled in an earlier epoch begins its interval at the next current sample.
        for (peerId in pendingRemovalMarkers) {
            if (removalMarkers.remove(peerId) != null) {
                removalMarkers[peerId] = saturatingAddNonNegative(now, maxLifetimeMillis)
            }
        }
        pendingRemovalMarkers.clear()
        if (pendingGlobalLegacyHold) {
            globalLegacyHoldUntilMillis = maxOf(
                globalLegacyHoldUntilMillis ?: Long.MIN_VALUE,
                saturatingAddNonNegative(now, maxLifetimeMillis)
            )
            pendingGlobalLegacyHold = false
        }
        while (tokenExpiries.peek()?.releaseAtMillis?.let { it <= now } == true) {
            val expiry = tokenExpiries.remove()
            val key = expiry.key
            tokenRecords.remove(key) ?: continue
            val state = subjectStates[key.subjectPeerId] ?: continue
            state.tokens.remove(key)
            if (state.bestToken == key) state.bestToken = null
            if (state.tokens.isEmpty()) subjectStates.remove(key.subjectPeerId)
        }

        val markerIterator = removalMarkers.entries.iterator()
        while (markerIterator.hasNext()) {
            if (markerIterator.next().value > now) break
            markerIterator.remove()
        }

        if (globalLegacyHoldUntilMillis?.let { it <= now } == true) {
            globalLegacyHoldUntilMillis = null
        }
    }

    internal fun sampleTime(): PeerFreshnessTimeSample = samplePeerFreshnessTime(clock)

    private fun observeTime(timeSample: PeerFreshnessTimeSample): PeerWindowTime {
        val current = timeSample.nowMillis
        val previous = lastObservedTimeMillis
        // Earlier reads keep their own source value, but cannot age this epoch's records.
        if (!timeSample.timeline.isCurrent(timeSample.epoch)) {
            if (lastObservedEpoch == null) {
                // A first removal or restored record still needs rebasing on its first current sample.
                lastObservedEpoch = timeSample.epoch
                lastObservedTimeMillis = current
            }
            return PeerWindowTime(previous ?: current, false)
        }
        val changedEpoch = lastObservedEpoch != null && lastObservedEpoch !== timeSample.epoch
        // A smaller result overlapping an observed completion cannot move that timeline back.
        // A larger returned value always contributes, whichever completion reaches us first.
        if (!changedEpoch && previous != null && current < previous &&
            (timeSample.order < lastObservedSampleOrder ||
                timeSample.precedingCompletionOrder < lastObservedSampleOrder)) {
            return PeerWindowTime(previous, true)
        }
        lastObservedEpoch = timeSample.epoch
        lastObservedSampleOrder = maxOf(lastObservedSampleOrder, timeSample.order)
        if (changedEpoch || (previous != null && current < previous)) {
            val resetReleaseAt = saturatingAddNonNegative(current, maxLifetimeMillis)
            tokenExpiries.clear()
            for (entry in tokenRecords.entries) {
                val releaseAt = saturatingAddNonNegative(current, entry.value.retentionMillis)
                entry.setValue(entry.value.copy(
                    expiresAtMillis = current,
                    releaseAtMillis = releaseAt
                ))
                tokenExpiries.add(TokenExpiry(entry.key, releaseAt))
            }
            for (entry in removalMarkers.entries) {
                entry.setValue(resetReleaseAt)
            }
            for (state in subjectStates.values) {
                state.bestFreshness?.let { bestFreshness ->
                    state.bestExpiryAtMillis = current
                    state.bestFreshness = bestFreshness.copy(remainingLifetimeMillis = 0L)
                }
            }
            if (globalLegacyHoldUntilMillis != null) {
                globalLegacyHoldUntilMillis = resetReleaseAt
            }
        }
        lastObservedTimeMillis = current
        return PeerWindowTime(current, true)
    }

    private fun entryCount(): Int = tokenRecords.size + removalMarkers.size

    private fun nextVersion(): Long {
        check(lastVersion < Long.MAX_VALUE) { "Peer freshness change version limit was reached" }
        lastVersion += 1L
        return lastVersion
    }

}

/** Uses elapsed JVM time for the default system clock and the supplied time for injected clocks. */
internal fun peerFreshnessTimeMillis(clock: Clock): Long = samplePeerFreshnessTime(clock).nowMillis

private fun saturatingAddNonNegative(value: Long, duration: Long): Long =
    if (value > Long.MAX_VALUE - duration) Long.MAX_VALUE else value + duration

private fun nonNegativeElapsedSince(receivedAtElapsedMillis: Long, nowElapsedMillis: Long): Long {
    if (nowElapsedMillis < receivedAtElapsedMillis) return Long.MAX_VALUE
    val elapsedMillis = nowElapsedMillis - receivedAtElapsedMillis
    return if (elapsedMillis < 0L) Long.MAX_VALUE else elapsedMillis
}

private fun positiveDurationUntil(deadline: Long, now: Long): Long {
    if (deadline <= now) return 0L
    return if (now < 0L && deadline > Long.MAX_VALUE + now) {
        Long.MAX_VALUE
    } else {
        deadline - now
    }
}

/** An exchange crossing a Clock epoch cannot supply a usable elapsed duration. */
internal fun peerFreshnessElapsedMillis(start: PeerFreshnessTimeSample, end: PeerFreshnessTimeSample): Long =
    if (start.timeline !== end.timeline || start.epoch !== end.epoch || !end.timeline.isCurrent(end.epoch)) {
        Long.MAX_VALUE
    } else {
        nonNegativeElapsedSince(start.nowMillis, end.nowMillis)
    }
