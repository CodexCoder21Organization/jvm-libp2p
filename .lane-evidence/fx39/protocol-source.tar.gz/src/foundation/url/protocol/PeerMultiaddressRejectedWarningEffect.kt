package foundation.url.protocol

import community.kotlin.logging.MessageSeverity
import kotlinx.algebraiceffects.NotificationEffect

/** Reports one peer multiaddress rejected at a named protocol trust boundary. */
class PeerMultiaddressRejectedWarningEffect(
    val peerId: String,
    val address: String,
    val acceptanceContext: String,
    val reason: String,
) : NotificationEffect(
    "Peer '$peerId' multiaddress '$address' was rejected $acceptanceContext: $reason",
    MessageSeverity.WARNING,
)
