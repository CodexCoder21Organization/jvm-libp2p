package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.util.Collections
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

enum class PeerCheckOutcome {
    SUCCESS,
    FAILURE
}

data class PeerCheckObservation(
    val timestampMs: Long,
    val outcome: PeerCheckOutcome
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", timestampMs)
        .put("outcome", outcome.name.lowercase())

    companion object {
        fun fromJson(json: JSONObject): PeerCheckObservation = PeerCheckObservation(
            timestampMs = json.getLong("t"),
            outcome = when (val outcome = json.getString("outcome")) {
                "success" -> PeerCheckOutcome.SUCCESS
                "failure" -> PeerCheckOutcome.FAILURE
                else -> throw IllegalArgumentException(
                    "Peer check outcome must be 'success' or 'failure', but was '$outcome'"
                )
            }
        )
    }
}

enum class PeerReachabilityOutcome {
    DIRECT,
    RELAY_ONLY
}

data class PeerReachabilityObservation(
    val timestampMs: Long,
    val outcome: PeerReachabilityOutcome
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", timestampMs)
        .put("outcome", when (outcome) {
            PeerReachabilityOutcome.DIRECT -> "direct"
            PeerReachabilityOutcome.RELAY_ONLY -> "relayOnly"
        })

    companion object {
        fun fromJson(json: JSONObject): PeerReachabilityObservation = PeerReachabilityObservation(
            timestampMs = json.getLong("t"),
            outcome = when (val outcome = json.getString("outcome")) {
                "direct" -> PeerReachabilityOutcome.DIRECT
                "relayOnly" -> PeerReachabilityOutcome.RELAY_ONLY
                else -> throw IllegalArgumentException(
                    "Peer reachability outcome must be 'direct' or 'relayOnly', but was '$outcome'"
                )
            }
        )
    }
}

enum class PeerInteractionSeverity(val value: Double) {
    CLEAN(0.0),
    MILD(0.2),
    MODERATE(0.5),
    SEVERE(1.0)
}

data class PeerInteractionObservation(
    val timestampMs: Long,
    val severity: PeerInteractionSeverity
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", timestampMs)
        .put("severity", severity.value)

    companion object {
        fun fromJson(json: JSONObject): PeerInteractionObservation {
            val value = json.getDouble("severity")
            val severity = PeerInteractionSeverity.entries.firstOrNull { it.value == value }
                ?: throw IllegalArgumentException(
                    "Peer interaction severity must be one of 0.0, 0.2, 0.5, or 1.0, but was $value"
                )
            return PeerInteractionObservation(json.getLong("t"), severity)
        }
    }
}

data class PeerRecommendationObservation(
    val recommendedPeerId: String,
    val firstSharedAtMs: Long,
    val lastSharedAtMs: Long,
    val wasNovel: Boolean,
    val lastKnownBase: Double?,
    val lastSharedSequence: Long = 0L
) {
    fun toJson(): JSONObject = JSONObject()
        .put("firstSharedAt", firstSharedAtMs)
        .put("lastSharedAt", lastSharedAtMs)
        .put("wasNovel", wasNovel)
        .put("lastSharedSequence", lastSharedSequence)
        .apply {
            if (lastKnownBase != null) {
                put("lastKnownBase", lastKnownBase)
            }
        }

    companion object {
        fun fromJson(peerId: String, json: JSONObject): PeerRecommendationObservation =
            PeerRecommendationObservation(
                recommendedPeerId = peerId,
                firstSharedAtMs = json.getLong("firstSharedAt"),
                lastSharedAtMs = json.getLong("lastSharedAt"),
                wasNovel = json.getBoolean("wasNovel"),
                lastKnownBase = if (json.has("lastKnownBase") && !json.isNull("lastKnownBase")) {
                    json.getDouble("lastKnownBase")
                } else {
                    null
                },
                lastSharedSequence = json.optLong("lastSharedSequence", 0L)
            )
    }
}

/**
 * Legacy contact-event shape retained for source and persisted-data compatibility.
 *
 * New score computation uses [PeerCheckObservation]. An event whose
 * [selfWasOnline] value is false is deliberately not added to that series.
 */
data class PeerContactEvent(
    val timestampMs: Long,
    val success: Boolean,
    val selfWasOnline: Boolean
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("timestampMs", timestampMs)
        put("success", success)
        put("selfWasOnline", selfWasOnline)
    }

    companion object {
        fun fromJson(json: JSONObject): PeerContactEvent = PeerContactEvent(
            timestampMs = json.getLong("timestampMs"),
            success = json.getBoolean("success"),
            selfWasOnline = json.getBoolean("selfWasOnline")
        )
    }
}

/**
 * Immutable score input for one peer.
 *
 * The aggregate fields remain available for source compatibility and scheduling
 * backoff. Scores are derived only from the bounded observation series.
 */
data class PeerObservationSnapshot(
    val peerId: String,
    val firstSeenMs: Long,
    val successCount: Int,
    val failCount: Int,
    val failWhileSelfOnlineCount: Int,
    val lastSuccessMs: Long,
    val lastFailMs: Long,
    val consecutiveFailures: Int,
    val lastObservedAtMs: Long? = listOf(lastSuccessMs, lastFailMs)
        .filter { it != 0L }
        .maxOrNull(),
    val lastSuccessfulObservationAtMs: Long? = lastSuccessMs.takeIf { it != 0L },
    val vouchPrior: Double? = null,
    val checks: List<PeerCheckObservation> = emptyList(),
    val reachability: List<PeerReachabilityObservation> = emptyList(),
    val interactions: List<PeerInteractionObservation> = emptyList(),
    val recommendations: Map<String, PeerRecommendationObservation> = emptyMap()
)

private const val PEER_OBSERVATION_SERIES_LIMIT = 64
private const val PEER_OBSERVATION_CHUNK_SIZE = 8

/**
 * Immutable bounded list whose append copies one chunk and the small chunk index.
 *
 * Published snapshots can safely retain older instances because appends never mutate shared
 * chunks. Eight 8-entry chunks keep both copies bounded while avoiding a 64-entry defensive copy
 * for every observation mutation.
 */
private class ImmutableBoundedObservationList<T> private constructor(
    private val chunks: Array<Array<Any?>?>,
    private val firstIndex: Int,
    override val size: Int,
) : java.util.AbstractList<T>() {
    override fun get(index: Int): T {
        if (index !in indices) {
            throw IndexOutOfBoundsException(
                "Observation index must be between 0 and ${size - 1}, but was $index",
            )
        }
        val position = (firstIndex + index) % PEER_OBSERVATION_SERIES_LIMIT
        @Suppress("UNCHECKED_CAST")
        return chunks[position / PEER_OBSERVATION_CHUNK_SIZE]!![
            position % PEER_OBSERVATION_CHUNK_SIZE
        ] as T
    }

    fun appended(value: T): ImmutableBoundedObservationList<T> {
        val insertionIndex = if (size < PEER_OBSERVATION_SERIES_LIMIT) {
            (firstIndex + size) % PEER_OBSERVATION_SERIES_LIMIT
        } else {
            firstIndex
        }
        val nextFirstIndex = if (size < PEER_OBSERVATION_SERIES_LIMIT) {
            firstIndex
        } else {
            (firstIndex + 1) % PEER_OBSERVATION_SERIES_LIMIT
        }
        val chunkIndex = insertionIndex / PEER_OBSERVATION_CHUNK_SIZE
        val nextChunks = chunks.copyOf()
        val nextChunk = chunks[chunkIndex]?.copyOf()
            ?: arrayOfNulls(PEER_OBSERVATION_CHUNK_SIZE)
        nextChunk[insertionIndex % PEER_OBSERVATION_CHUNK_SIZE] = value
        nextChunks[chunkIndex] = nextChunk
        return ImmutableBoundedObservationList(
            chunks = nextChunks,
            firstIndex = nextFirstIndex,
            size = minOf(size + 1, PEER_OBSERVATION_SERIES_LIMIT),
        )
    }

    companion object {
        fun <T> from(values: List<T>): ImmutableBoundedObservationList<T> {
            var result = ImmutableBoundedObservationList<T>(
                chunks = arrayOfNulls(
                    PEER_OBSERVATION_SERIES_LIMIT / PEER_OBSERVATION_CHUNK_SIZE,
                ),
                firstIndex = 0,
                size = 0,
            )
            values.takeLast(PEER_OBSERVATION_SERIES_LIMIT).forEach { value ->
                result = result.appended(value)
            }
            return result
        }
    }
}

/**
 * Bounded, persisted score evidence for one peer.
 */
class PeerObservationRecord(
    val peerId: String,
    firstSeenMs: Long,
    initialSuccessCount: Int = 0,
    initialFailCount: Int = 0,
    initialFailWhileSelfOnlineCount: Int = 0,
    initialLastSuccessMs: Long = 0L,
    initialLastFailMs: Long = 0L,
    initialConsecutiveFailures: Int = 0,
    initialEvents: List<PeerContactEvent> = emptyList(),
    initialLastObservedAtMs: Long? = null,
    initialLastSuccessfulObservationAtMs: Long? = null,
    initialVouchPrior: Double? = null,
    initialChecks: List<PeerCheckObservation> = emptyList(),
    initialReachability: List<PeerReachabilityObservation> = emptyList(),
    initialInteractions: List<PeerInteractionObservation> = emptyList(),
    initialRecommendations: Map<String, PeerRecommendationObservation> = emptyMap(),
    initialDiscoveredAtMs: Long = firstSeenMs,
    initialFirstSeenAtMs: Long? = firstSeenMs,
    initialLastCreditedCleanInteractionBucket: Long? = initialInteractions
        .filter { it.severity == PeerInteractionSeverity.CLEAN }
        .maxOfOrNull {
            Math.floorDiv(it.timestampMs, PeerObservationLog.CLEAN_INTERACTION_BUCKET_MS)
        }
) {
    @Volatile
    internal var snapshotPublicationListener:
        ((snapshot: PeerObservationSnapshot, publish: () -> Unit) -> Unit)? = null

    val discoveredAtMs: Long = initialDiscoveredAtMs
    private var firstAuthenticatedObservationAtMs: Long? = initialFirstSeenAtMs
    val firstSeenMs: Long
        @Synchronized get() = firstAuthenticatedObservationAtMs ?: discoveredAtMs
    private var successCount: Int = initialSuccessCount
    private var failCount: Int = initialFailCount
    private var failWhileSelfOnlineCount: Int = initialFailWhileSelfOnlineCount
    private var lastSuccessMs: Long = initialLastSuccessMs
    private var lastFailMs: Long = initialLastFailMs
    private var consecutiveFailures: Int = initialConsecutiveFailures
    private var lastObservedAtMs: Long? = initialLastObservedAtMs
        ?: listOf(initialLastSuccessMs, initialLastFailMs).filter { it != 0L }.maxOrNull()
    private var lastSuccessfulObservationAtMs: Long? = initialLastSuccessfulObservationAtMs
        ?: initialLastSuccessMs.takeIf { it != 0L }
    // Event identity also distinguishes successful observations at equal or backward clock times.
    internal var successfulObservationVersion: Any = Any()
        private set
    private var sourceFreshness = PeerSourceFreshnessState(null)
    private var vouchPrior: Double? = initialVouchPrior
    private var checks = ImmutableBoundedObservationList.from(initialChecks)
    private var reachability = ImmutableBoundedObservationList.from(initialReachability)
    private var interactions = ImmutableBoundedObservationList.from(initialInteractions)
    private var lastCreditedCleanInteractionBucket =
        initialLastCreditedCleanInteractionBucket
    private val recommendations =
        LinkedHashMap(initialRecommendations.entries
            .sortedBy { it.key }
            .associate { it.key to it.value })
    private var recommendationSequence =
        initialRecommendations.values.maxOfOrNull { it.lastSharedSequence } ?: 0L

    init {
        if (
            initialVouchPrior != null &&
            initialVouchPrior !in PeerObservationLog.COLD_CONTACT_PRIOR..PeerObservationLog.MAX_VOUCH_PRIOR
        ) {
            throw IllegalArgumentException(
                "Vouch prior for peer '$peerId' must be between " +
                    "${PeerObservationLog.COLD_CONTACT_PRIOR} and " +
                    "${PeerObservationLog.MAX_VOUCH_PRIOR} inclusive, but was $initialVouchPrior"
            )
        }
        initialRecommendations.values.forEach { recommendation ->
            val base = recommendation.lastKnownBase
            if (base != null && base !in 0.0..1.0) {
                throw IllegalArgumentException(
                    "Last-known base score for referred peer " +
                        "'${recommendation.recommendedPeerId}' must be between 0.0 and 1.0 " +
                        "inclusive, but was $base"
                )
            }
        }
        if (initialChecks.isEmpty() && initialEvents.isNotEmpty()) {
            initialEvents.takeLast(MAX_SERIES_ENTRIES).forEach { event ->
                if (event.success || event.selfWasOnline) {
                    checks = checks.appended(
                        PeerCheckObservation(
                            event.timestampMs,
                            if (event.success) PeerCheckOutcome.SUCCESS else PeerCheckOutcome.FAILURE
                        )
                    )
                }
            }
        }
        evictRecommendationsIfNeeded()
    }

    private var publishedRecommendations: Map<String, PeerRecommendationObservation> =
        Collections.unmodifiableMap(TreeMap(recommendations))

    @Volatile
    private var publishedSnapshot = buildSnapshot()

    companion object {
        const val MAX_SERIES_ENTRIES = PEER_OBSERVATION_SERIES_LIMIT

        @Deprecated("Use MAX_SERIES_ENTRIES")
        const val MAX_EVENTS = MAX_SERIES_ENTRIES

        fun fromJson(json: JSONObject): PeerObservationRecord {
            val recentEvents = json.optJSONArray("recentEvents") ?: JSONArray()
            val legacyEvents = (0 until recentEvents.length()).map {
                PeerContactEvent.fromJson(recentEvents.getJSONObject(it))
            }
            val checks = json.optJSONArray("checks").toCheckObservations()
            val reachability = json.optJSONArray("reachability").toReachabilityObservations()
            val interactions = json.optJSONArray("interactions").toInteractionObservations()
            val recommendationsJson = json.optJSONObject("recommendations") ?: JSONObject()
            val recommendations = recommendationsJson.keys().asSequence().associateWith { peerId ->
                PeerRecommendationObservation.fromJson(
                    peerId,
                    recommendationsJson.getJSONObject(peerId)
                )
            }
            val storedFirstSeenMs = json.optLong(
                "firstSeenAt",
                json.optLong("firstSeenMs", json.optLong("discoveredAt", 0L))
            )
            val firstAuthenticatedObservationAtMs =
                if (json.has("discoveredAt")) {
                    json.optNullableLong("firstSeenAt")
                } else {
                    (
                        checks.map { it.timestampMs } +
                            reachability.map { it.timestampMs } +
                            interactions.map { it.timestampMs } +
                            recommendations.values.map { it.firstSharedAtMs } +
                            listOf(
                                json.optLong("lastSuccessMs", 0L),
                                json.optLong("lastFailMs", 0L)
                            ).filter { it != 0L }
                        ).minOrNull()
                }
            return PeerObservationRecord(
                peerId = json.getString("peerId"),
                firstSeenMs = storedFirstSeenMs,
                initialSuccessCount = json.optInt("successCount", 0),
                initialFailCount = json.optInt("failCount", 0),
                initialFailWhileSelfOnlineCount = json.optInt("failWhileSelfOnlineCount", 0),
                initialLastSuccessMs = json.optLong("lastSuccessMs", 0L),
                initialLastFailMs = json.optLong("lastFailMs", 0L),
                initialConsecutiveFailures = json.optInt("consecutiveFailures", 0),
                initialEvents = legacyEvents,
                initialLastObservedAtMs = json.optNullableLong("lastObservedAt"),
                initialLastSuccessfulObservationAtMs =
                    json.optNullableLong("lastSuccessfulObservationAt"),
                initialVouchPrior = if (json.has("vouchPrior") && !json.isNull("vouchPrior")) {
                    json.getDouble("vouchPrior")
                } else {
                    null
                },
                initialChecks = checks,
                initialReachability = reachability,
                initialInteractions = interactions,
                initialRecommendations = recommendations,
                initialDiscoveredAtMs = json.optLong("discoveredAt", storedFirstSeenMs),
                initialFirstSeenAtMs = firstAuthenticatedObservationAtMs,
                initialLastCreditedCleanInteractionBucket =
                    json.optNullableLong("lastCreditedCleanInteractionBucket")
                        ?: interactions
                            .filter { it.severity == PeerInteractionSeverity.CLEAN }
                            .maxOfOrNull {
                                Math.floorDiv(
                                    it.timestampMs,
                                    PeerObservationLog.CLEAN_INTERACTION_BUCKET_MS
                                )
                            }
            ).also { record ->
                val persistedId = json.optString("sourceObservationId", "")
                if (persistedId.isNotBlank()) {
                    record.sourceFreshness = PeerSourceFreshnessState(null, persistedId)
                }
            }
        }

        private fun JSONArray?.toCheckObservations(): List<PeerCheckObservation> {
            if (this == null) return emptyList()
            return (0 until length()).map { PeerCheckObservation.fromJson(getJSONObject(it)) }
        }

        private fun JSONArray?.toReachabilityObservations(): List<PeerReachabilityObservation> {
            if (this == null) return emptyList()
            return (0 until length()).map {
                PeerReachabilityObservation.fromJson(getJSONObject(it))
            }
        }

        private fun JSONArray?.toInteractionObservations(): List<PeerInteractionObservation> {
            if (this == null) return emptyList()
            return (0 until length()).map {
                PeerInteractionObservation.fromJson(getJSONObject(it))
            }
        }

        private fun JSONObject.optNullableLong(key: String): Long? =
            if (has(key) && !isNull(key)) getLong(key) else null
    }

    fun recordContact(event: PeerContactEvent) { recordContact(event, null) }

    @Synchronized
    internal fun recordContact(event: PeerContactEvent, observedElapsedMillis: Long?) {
        if (!event.success && !event.selfWasOnline) {
            return
        }
        markFirstAuthenticatedObservation(event.timestampMs)
        checks = checks.appended(
            PeerCheckObservation(
                event.timestampMs,
                if (event.success) PeerCheckOutcome.SUCCESS else PeerCheckOutcome.FAILURE
            ),
        )
        lastObservedAtMs = event.timestampMs
        if (event.success) {
            successCount++
            lastSuccessMs = event.timestampMs
            lastSuccessfulObservationAtMs = event.timestampMs
            successfulObservationVersion = Any()
            sourceFreshness = PeerSourceFreshnessState(observedElapsedMillis)
            consecutiveFailures = 0
        } else {
            failCount++
            failWhileSelfOnlineCount++
            lastFailMs = event.timestampMs
            consecutiveFailures++
        }
        publishSnapshot()
    }

    fun recordReachability(timestampMs: Long, outcome: PeerReachabilityOutcome) { recordReachability(timestampMs, outcome, null) }

    @Synchronized
    internal fun recordReachability(timestampMs: Long, outcome: PeerReachabilityOutcome, observedElapsedMillis: Long?) {
        markFirstAuthenticatedObservation(timestampMs)
        reachability = reachability.appended(PeerReachabilityObservation(timestampMs, outcome))
        lastObservedAtMs = timestampMs
        lastSuccessfulObservationAtMs = timestampMs
        successfulObservationVersion = Any()
        sourceFreshness = PeerSourceFreshnessState(observedElapsedMillis)
        publishSnapshot()
    }

    fun recordInteraction(timestampMs: Long, severity: PeerInteractionSeverity) { recordInteraction(timestampMs, severity, null) }

    @Synchronized
    internal fun recordInteraction(timestampMs: Long, severity: PeerInteractionSeverity, observedElapsedMillis: Long?) {
        markFirstAuthenticatedObservation(timestampMs)
        if (severity == PeerInteractionSeverity.CLEAN) {
            val bucket = Math.floorDiv(timestampMs, PeerObservationLog.CLEAN_INTERACTION_BUCKET_MS)
            if (lastCreditedCleanInteractionBucket == bucket) {
                lastObservedAtMs = timestampMs
                lastSuccessfulObservationAtMs = timestampMs
                successfulObservationVersion = Any()
                sourceFreshness = PeerSourceFreshnessState(observedElapsedMillis)
                publishSnapshot()
                return
            }
            lastCreditedCleanInteractionBucket = bucket
        }
        interactions = interactions.appended(PeerInteractionObservation(timestampMs, severity))
        lastObservedAtMs = timestampMs
        lastSuccessfulObservationAtMs = timestampMs
        successfulObservationVersion = Any()
        sourceFreshness = PeerSourceFreshnessState(observedElapsedMillis)
        publishSnapshot()
    }

    fun recordRecommendation(
        recommendedPeerId: String,
        timestampMs: Long,
        wasNovel: Boolean,
        lastKnownBase: Double?
    ) { recordRecommendation(recommendedPeerId, timestampMs, wasNovel, lastKnownBase, null) }

    @Synchronized
    internal fun recordRecommendation(
        recommendedPeerId: String,
        timestampMs: Long,
        wasNovel: Boolean,
        lastKnownBase: Double?,
        observedElapsedMillis: Long?
    ) {
        markFirstAuthenticatedObservation(timestampMs)
        if (recommendedPeerId == peerId) {
            lastObservedAtMs = timestampMs
            lastSuccessfulObservationAtMs = timestampMs
            successfulObservationVersion = Any()
            sourceFreshness = PeerSourceFreshnessState(observedElapsedMillis)
            publishSnapshot()
            return
        }
        if (lastKnownBase != null && lastKnownBase !in 0.0..1.0) {
            publishSnapshot()
            throw IllegalArgumentException(
                "Last-known base score for referred peer '$recommendedPeerId' must be " +
                    "between 0.0 and 1.0 inclusive, but was $lastKnownBase"
            )
        }
        recommendationSequence++
        val previous = recommendations[recommendedPeerId]
        recommendations[recommendedPeerId] = PeerRecommendationObservation(
            recommendedPeerId = recommendedPeerId,
            firstSharedAtMs = previous?.firstSharedAtMs ?: timestampMs,
            lastSharedAtMs = timestampMs,
            wasNovel = previous?.wasNovel ?: wasNovel,
            lastKnownBase = lastKnownBase ?: previous?.lastKnownBase,
            lastSharedSequence = recommendationSequence
        )
        lastObservedAtMs = timestampMs
        lastSuccessfulObservationAtMs = timestampMs
        successfulObservationVersion = Any()
        sourceFreshness = PeerSourceFreshnessState(observedElapsedMillis)
        evictRecommendationsIfNeeded()
        publishedRecommendations = Collections.unmodifiableMap(TreeMap(recommendations))
        publishSnapshot()
    }

    @Synchronized
    fun setVouchPrior(prior: Double) {
        if (prior !in PeerObservationLog.COLD_CONTACT_PRIOR..PeerObservationLog.MAX_VOUCH_PRIOR) {
            throw IllegalArgumentException(
                "Vouch prior for peer '$peerId' must be between " +
                    "${PeerObservationLog.COLD_CONTACT_PRIOR} and " +
                    "${PeerObservationLog.MAX_VOUCH_PRIOR} inclusive, but was $prior"
            )
        }
        if (lastObservedAtMs != null) {
            return
        }
        val updatedPrior = maxOf(vouchPrior ?: Double.NEGATIVE_INFINITY, prior)
        if (updatedPrior != vouchPrior) {
            vouchPrior = updatedPrior
            publishSnapshot()
        }
    }

    @Synchronized
    fun refreshRecommendationBases(baseScores: Map<String, Double>) {
        var changed = false
        for ((recommendedPeerId, previous) in recommendations) {
            val refreshedBase = baseScores[recommendedPeerId] ?: continue
            if (previous.lastKnownBase != refreshedBase) {
                recommendations[recommendedPeerId] =
                    previous.copy(lastKnownBase = refreshedBase)
                changed = true
            }
        }
        evictRecommendationsIfNeeded()
        if (changed) {
            publishedRecommendations = Collections.unmodifiableMap(TreeMap(recommendations))
            publishSnapshot()
        }
    }

    /**
     * True when this record differs from an unvouched cold-contact prior: it holds a vouch,
     * authenticated check, reachability or interaction observation, recommendation, or legacy
     * success/failure count.
     *
     * Answers the same question as inspecting a [snapshot], without allocating the snapshot's
     * defensive copies of every bounded series. Callers that only need to know *whether* a peer
     * has moved off the cold-contact priors (eviction ranking, for example) must use this rather
     * than snapshotting, because they ask it once per peer per pass.
     */
    @Synchronized
    internal fun hasScoreEvidence(): Boolean =
        vouchPrior != null ||
            checks.isNotEmpty() ||
            reachability.isNotEmpty() ||
            interactions.isNotEmpty() ||
            recommendations.isNotEmpty() ||
            successCount != 0 ||
            failCount != 0

    /**
     * Returns the immutable snapshot for the current record version.
     *
     * Mutations publish a fresh snapshot before releasing the record monitor. Unchanged reads are
     * one volatile lookup and do not copy the bounded evidence collections.
     */
    fun snapshot(): PeerObservationSnapshot = publishedSnapshot

    private fun publishSnapshot() {
        val nextSnapshot = buildSnapshot()
        val publish = { publishedSnapshot = nextSnapshot }
        snapshotPublicationListener?.invoke(nextSnapshot, publish) ?: publish()
    }

    private fun buildSnapshot(): PeerObservationSnapshot = PeerObservationSnapshot(
        peerId = peerId,
        firstSeenMs = firstSeenMs,
        successCount = successCount,
        failCount = failCount,
        failWhileSelfOnlineCount = failWhileSelfOnlineCount,
        lastSuccessMs = lastSuccessMs,
        lastFailMs = lastFailMs,
        consecutiveFailures = consecutiveFailures,
        lastObservedAtMs = lastObservedAtMs,
        lastSuccessfulObservationAtMs = lastSuccessfulObservationAtMs,
        vouchPrior = vouchPrior,
        checks = checks,
        reachability = reachability,
        interactions = interactions,
        recommendations = publishedRecommendations
    )

    private var sourceSampleVersion: Any = Any()

    @Synchronized
    internal fun captureSourceFreshnessVersion(): Pair<Any, Any> = sourceFreshness to sourceSampleVersion

    @Synchronized
    internal fun sampleSourceFreshness(
        version: Pair<Any, Any>, observerPeerId: String, now: Long, lifetimeMillis: Long
    ): PeerFreshness? {
        if (sourceFreshness !== version.first || sourceSampleVersion !== version.second) return null
        if (lastSuccessfulObservationAtMs == null) return null
        sourceSampleVersion = Any()
        return samplePeerSourceFreshness(sourceFreshness, observerPeerId, now, lifetimeMillis)
    }

    @Synchronized
    fun toJson(): JSONObject = JSONObject().apply {
        put("schemaVersion", 2)
        put("sourceObservationId", sourceFreshness.observationId)
        put("peerId", peerId)
        put("discoveredAt", discoveredAtMs)
        put("firstSeenAt", firstAuthenticatedObservationAtMs ?: JSONObject.NULL)
        put("firstSeenMs", firstSeenMs)
        put("successCount", successCount)
        put("failCount", failCount)
        put("failWhileSelfOnlineCount", failWhileSelfOnlineCount)
        put("lastSuccessMs", lastSuccessMs)
        put("lastFailMs", lastFailMs)
        put("consecutiveFailures", consecutiveFailures)
        put("lastObservedAt", lastObservedAtMs ?: JSONObject.NULL)
        put("lastSuccessfulObservationAt", lastSuccessfulObservationAtMs ?: JSONObject.NULL)
        put("vouchPrior", vouchPrior ?: JSONObject.NULL)
        put("checks", JSONArray(checks.map { it.toJson() }))
        put("reachability", JSONArray(reachability.map { it.toJson() }))
        put("interactions", JSONArray(interactions.map { it.toJson() }))
        put(
            "lastCreditedCleanInteractionBucket",
            lastCreditedCleanInteractionBucket ?: JSONObject.NULL
        )
        put("recommendations", JSONObject().apply {
            recommendations.toSortedMap().forEach { (recommendedPeerId, observation) ->
                put(recommendedPeerId, observation.toJson())
            }
        })
    }

    private fun evictRecommendationsIfNeeded() {
        while (recommendations.size > MAX_SERIES_ENTRIES) {
            val victim = recommendations.values.minWithOrNull(
                compareBy<PeerRecommendationObservation>(
                    { if (it.lastKnownBase == null) 0 else 1 },
                    { it.lastSharedAtMs },
                    { it.lastSharedSequence },
                    { it.recommendedPeerId }
                )
            ) ?: return
            recommendations.remove(victim.recommendedPeerId)
        }
    }

    private fun markFirstAuthenticatedObservation(timestampMs: Long) {
        if (firstAuthenticatedObservationAtMs == null) {
            firstAuthenticatedObservationAtMs = timestampMs
        }
    }

}

/**
 * Tracks whether this node has recently proved its own connectivity.
 */
class SelfOnlineTracker(private val clock: Clock) {
    private val lastSuccessfulContactMs = AtomicReference<Long?>(null)

    companion object {
        const val SELF_OFFLINE_THRESHOLD_MS = 60_000L
    }

    fun reportSuccessfulContact() {
        reportSuccessfulContact(peerRegistryWallTimeMillis(clock))
    }

    internal fun reportSuccessfulContact(timestampMs: Long) {
        lastSuccessfulContactMs.updateAndGet { previous ->
            if (previous == null || timestampMs > previous) timestampMs else previous
        }
    }

    internal fun reportSuccessfulContactAt(timestampMs: Long) {
        reportSuccessfulContact(timestampMs)
    }

    fun isSelfOnline(): Boolean {
        val lastContact = lastSuccessfulContactMs.get() ?: return false
        val now = peerRegistryWallTimeMillis(clock)
        if (now <= lastContact) return true
        val elapsed = now - lastContact
        return elapsed >= 0L && elapsed <= SELF_OFFLINE_THRESHOLD_MS
    }

    internal fun isSelfOnlineAt(timestampMs: Long): Boolean {
        val lastContact = lastSuccessfulContactMs.get() ?: return false
        if (timestampMs <= lastContact) return true
        val elapsed = timestampMs - lastContact
        return elapsed >= 0L && elapsed <= SELF_OFFLINE_THRESHOLD_MS
    }
}

internal data class PeerBootstrapScorePopulation(
    val snapshots: Map<String, PeerObservationSnapshot>,
    val shapes: Map<String, PeerBootstrapScoreShape?>
)

internal data class IncrementalBootstrapScoreState(
    val uniformShape: PeerBootstrapScoreShape,
    val changedShapes: Map<String, PeerBootstrapScoreShape>,
    val populationSize: Int
)

private fun capacityEntryWithEvidence(
    entry: PeerCapacityEvictionEntry,
    snapshot: PeerObservationSnapshot?,
    scorer: PeerScorer,
): PeerCapacityEvictionEntry {
    val score = snapshot?.let { scorer.scoreComponents(it).bootstrapScore } ?: 0.0
    val tier = when {
        score == 0.0 -> 0
        snapshot?.lastSuccessfulObservationAtMs != null -> 2
        else -> 1
    }
    val tenure = snapshot?.lastSuccessfulObservationAtMs
        ?.let { (it - snapshot.firstSeenMs).coerceAtLeast(0L) } ?: 0L
    return entry.copy(
        tier = tier,
        localScore = score,
        witnessedTenureMs = tenure,
        hasSuccessfulObservation = snapshot?.lastSuccessfulObservationAtMs != null,
    )
}

/**
 * Thread-safe registry of bounded score evidence.
 */
internal class PeerSuccessfulEvidence(
    val record: PeerObservationRecord?,
    val version: Any?,
    val memberEvidenceVersion: Any
)

class PeerObservationLog(private val clock: Clock = SystemClock()) {
    private val records = ConcurrentHashMap<String, PeerObservationRecord>()
    private val provisionalRegistryRecords = ConcurrentHashMap<String, PeerObservationRecord>()
    private val scoreShapeScorer = PeerScorer(clock)
    private val scoreShapeLock = Any()
    private val capacityEvictionIndex = PeerCapacityEvictionIndex()
    // Bounded by retained registry membership, including candidates captured before add publication.
    private val evidenceVersionsByRegistryMember = HashMap<String, Any>()
    private val scoreShapeByPeer = mutableMapOf<String, PeerBootstrapScoreShape?>()
    private val scoreShapeCounts = mutableMapOf<PeerBootstrapScoreShape, Int>()
    private val changedScoreShapePeerIds = mutableSetOf<String>()
    private var unsupportedScoreShapeCount = 0
    private val registryMemberIds = mutableSetOf<String>()
    private var registryMembersMissingRecords = 0
    val selfOnlineTracker = SelfOnlineTracker(clock)

    companion object {
        const val CLEAN_INTERACTION_BUCKET_MS = 15L * 60L * 1000L
        const val COLD_CONTACT_PRIOR = 0.25
        const val MAX_VOUCH_PRIOR = 0.55

        fun vouchPriorFor(introducerOstracismScore: Double): Double {
            if (introducerOstracismScore !in 0.0..1.0) {
                throw IllegalArgumentException(
                    "Introducer ostracism score must be between 0.0 and 1.0 inclusive, " +
                        "but was $introducerOstracismScore"
                )
            }
            return COLD_CONTACT_PRIOR + 0.3 * introducerOstracismScore
        }

        fun fromJson(json: JSONObject, clock: Clock = SystemClock()): PeerObservationLog {
            val log = PeerObservationLog(clock)
            val recordsJson = json.optJSONObject("records") ?: return log
            for (peerId in recordsJson.keys()) {
                val recordJson = recordsJson.getJSONObject(peerId)
                log.installRecord(PeerObservationRecord.fromJson(recordJson))
            }
            return log
        }
    }

    fun observePeer(peerId: String, vouchPrior: Double? = null) {
        if (vouchPrior != null) {
            requireValidVouchPrior(peerId, vouchPrior)
        }
        val record = getOrCreate(peerId)
        if (vouchPrior != null) {
            record.setVouchPrior(vouchPrior)
        }
    }

    /** A first insertion can release its record only until another caller acquires it. */
    internal fun observeProvisionalRegistryPeer(peerId: String): ((Boolean) -> Unit)? {
        val timestampMs = peerRegistryWallTimeMillis(clock)
        val created = PeerObservationRecord(
            peerId = peerId,
            firstSeenMs = timestampMs,
            initialDiscoveredAtMs = timestampMs,
            initialFirstSeenAtMs = null
        )
        synchronized(scoreShapeLock) {
            if (records.containsKey(peerId)) return null
            // Publish the marker first so a fast-path reader cannot borrow an unmarked record.
            provisionalRegistryRecords[peerId] = created
            records[peerId] = created
            attachScoreShapeTracking(created)
        }
        return { committed ->
            synchronized(scoreShapeLock) {
                if (provisionalRegistryRecords[peerId] === created) {
                    if (!committed && records[peerId] === created) removePeer(peerId)
                    provisionalRegistryRecords.remove(peerId, created)
                }
            }
        }
    }

    // Admission sampled the injected clock before taking any registry guards.
    internal fun observePeerAt(peerId: String, discoveredAtMs: Long) {
        getOrCreate(peerId, discoveredAtMs)
    }

    fun observeVouchedPeer(peerId: String, introducerOstracismScore: Double) {
        observePeer(peerId, vouchPriorFor(introducerOstracismScore))
    }

    fun recordSuccess(peerId: String) {
        val timestampMs = peerRegistryWallTimeMillis(clock)
        selfOnlineTracker.reportSuccessfulContact()
        getOrCreate(peerId, timestampMs).recordContact(
            PeerContactEvent(timestampMs, success = true, selfWasOnline = true),
            peerFreshnessTimeMillis(clock)
        )
        markSuccessfulObservationCompleted(peerId)
    }

    internal fun recordSuccessAt(peerId: String, timestampMs: Long) {
        selfOnlineTracker.reportSuccessfulContactAt(timestampMs)
        getOrCreate(peerId, timestampMs).recordContact(
            PeerContactEvent(timestampMs, success = true, selfWasOnline = true)
        )
        markSuccessfulObservationCompleted(peerId)
    }

    fun recordFailure(peerId: String) {
        if (!selfOnlineTracker.isSelfOnline()) {
            return
        }
        getOrCreate(peerId).recordContact(
            PeerContactEvent(peerRegistryWallTimeMillis(clock), success = false, selfWasOnline = true)
        )
    }

    internal fun recordFailureAt(peerId: String, timestampMs: Long) {
        if (!selfOnlineTracker.isSelfOnlineAt(timestampMs)) {
            return
        }
        getOrCreate(peerId, timestampMs).recordContact(
            PeerContactEvent(timestampMs, success = false, selfWasOnline = true)
        )
    }

    fun recordDirectReachability(peerId: String) {
        selfOnlineTracker.reportSuccessfulContact()
        getOrCreate(peerId).recordReachability(
            peerRegistryWallTimeMillis(clock),
            PeerReachabilityOutcome.DIRECT,
            peerFreshnessTimeMillis(clock)
        )
        markSuccessfulObservationCompleted(peerId)
    }

    fun recordRelayOnlyReachability(peerId: String) {
        selfOnlineTracker.reportSuccessfulContact()
        getOrCreate(peerId).recordReachability(
            peerRegistryWallTimeMillis(clock),
            PeerReachabilityOutcome.RELAY_ONLY,
            peerFreshnessTimeMillis(clock)
        )
        markSuccessfulObservationCompleted(peerId)
    }

    fun recordAuthenticatedInteraction(peerId: String, severity: PeerInteractionSeverity) {
        val timestampMs = peerRegistryWallTimeMillis(clock)
        val record = synchronized(scoreShapeLock) {
            // Removal uses this owner too. Capture this generation before leaving it; a
            // detached record cannot publish evidence into a replacement for the same ID.
            if (!isCurrentAnnouncementPeerMutation(peerId)) return
            getOrCreate(peerId, timestampMs)
        }
        selfOnlineTracker.reportSuccessfulContact(timestampMs)
        record.recordInteraction(timestampMs, severity, peerFreshnessTimeMillis(clock))
        markSuccessfulObservationCompleted(peerId)
    }

    fun recordRecommendation(
        recommenderPeerId: String,
        recommendedPeerId: String,
        wasNovel: Boolean,
        lastKnownBase: Double? = null
    ) {
        if (lastKnownBase != null && lastKnownBase !in 0.0..1.0) {
            throw IllegalArgumentException(
                "Last-known base score for referred peer '$recommendedPeerId' must be " +
                    "between 0.0 and 1.0 inclusive, but was $lastKnownBase"
            )
        }
        getOrCreate(recommenderPeerId).recordRecommendation(
            recommendedPeerId,
            peerRegistryWallTimeMillis(clock),
            wasNovel,
            lastKnownBase,
            peerFreshnessTimeMillis(clock)
        )
        selfOnlineTracker.reportSuccessfulContact()
        markSuccessfulObservationCompleted(recommenderPeerId)
    }

    private fun markSuccessfulObservationCompleted(peerId: String) {
        synchronized(scoreShapeLock) {
            // A clear can detach the record selected by an in-flight observation. Its completed
            // success must still invalidate a confirmation captured after that clear.
            if (evidenceVersionsByRegistryMember.containsKey(peerId)) {
                evidenceVersionsByRegistryMember[peerId] = Any()
            }
        }
    }

    /** Samples a local observation's remaining duration without treating descriptor receipt as evidence. */
    fun getSourceFreshness(peerId: String, observerPeerId: String, lifetimeMillis: Long = 300_000L): PeerFreshness? {
        require(lifetimeMillis >= 0L) { "lifetimeMillis must be non-negative, but was $lifetimeMillis" }
        require(observerPeerId.isNotBlank()) { "observerPeerId must not be blank" }
        val record = records[peerId] ?: return null
        val version = record.captureSourceFreshnessVersion()
        val now = peerFreshnessTimeMillis(clock)
        val sample = record.sampleSourceFreshness(version, observerPeerId, now, lifetimeMillis)
        return sample.takeIf { records[peerId] === record }
    }

    fun getSnapshot(peerId: String): PeerObservationSnapshot? = records[peerId]?.snapshot()

    internal fun captureSuccessfulEvidence(peerId: String): PeerSuccessfulEvidence {
        val record = records[peerId]
        if (record == null) {
            return synchronized(scoreShapeLock) {
                PeerSuccessfulEvidence(null, null,
                    evidenceVersionsByRegistryMember.getOrPut(peerId) { Any() })
            }
        }
        // Join an in-flight writer so its event version and published observation agree at capture.
        return synchronized(record) {
            synchronized(scoreShapeLock) {
                PeerSuccessfulEvidence(record, record.successfulObservationVersion,
                    evidenceVersionsByRegistryMember.getOrPut(peerId) { Any() })
            }
        }
    }

    // The registry may end a lifetime and transfer completion state here, but must not call any
    // peer-map method: its bucket must already be held, and its map update follows guard release.
    // Cleanup, callbacks, clock reads and descriptor properties stay outside these guards.
    internal fun <T : Any> commitIfSuccessfulEvidenceUnchanged(
        peerId: String,
        evidence: PeerSuccessfulEvidence,
        commit: () -> T
    ): T? {
        val record = evidence.record
        if (record == null) {
            return synchronized(scoreShapeLock) {
                if (records[peerId] != null ||
                    evidenceVersionsByRegistryMember[peerId] !== evidence.memberEvidenceVersion) {
                    null
                } else {
                    commit()
                }
            }
        }
        return synchronized(record) {
            synchronized(scoreShapeLock) {
                if (records[peerId] !== record ||
                    record.successfulObservationVersion !== evidence.version ||
                    evidenceVersionsByRegistryMember[peerId] !== evidence.memberEvidenceVersion) {
                    null
                } else {
                    commit()
                }
            }
        }
    }

    /**
     * True when [peerId] has a record holding authenticated evidence. Unknown peers are false.
     *
     * This is the allocation-free form of `getSnapshot(peerId)?.let { ... }` for callers that only
     * need the boolean.
     */
    internal fun hasScoreEvidence(peerId: String): Boolean =
        records[peerId]?.hasScoreEvidence() ?: false

    fun getRecordJson(peerId: String): JSONObject? = records[peerId]?.toJson()

    fun getAllSnapshots(): Map<String, PeerObservationSnapshot> =
        records.entries
            .sortedBy { it.key }
            .associate { it.key to it.value.snapshot() }

    /**
     * Returns one coherent observation population and its cached per-record score inputs.
     *
     * While a registry population is active, every record mutation publishes its snapshot and
     * replacement score shape while holding [scoreShapeLock], so eviction cannot pair a new
     * observation with an older cached shape.
     */
    internal fun getBootstrapScorePopulation(): PeerBootstrapScorePopulation =
        synchronized(scoreShapeLock) {
            PeerBootstrapScorePopulation(
                snapshots = records.toSortedMap()
                    .mapValues { (_, record) -> record.snapshot() },
                shapes = scoreShapeByPeer.toSortedMap()
            )
        }

    /**
     * Recomputes every score and retains the observed referred peers' current base
     * scores in each recommendation ledger. The retained values remain available
     * if those referred peers later leave the bounded observation set.
     */
    fun scoreAllComponents(
        scorer: PeerScorer = PeerScorer(clock)
    ): Map<String, PeerScoreComponents> {
        val snapshots = getAllSnapshots()
        val scores = scorer.scoreAllComponents(snapshots)
        refreshRecommendationBases(snapshots, scores)
        return scores
    }

    internal fun refreshRecommendationBases(
        snapshots: Map<String, PeerObservationSnapshot>,
        scores: Map<String, PeerScoreComponents>
    ) {
        val observedBaseScores = scores
            .filterKeys { snapshots.getValue(it).lastObservedAtMs != null }
            .mapValues { it.value.baseScore }
        records.toSortedMap().values.forEach { record ->
            record.refreshRecommendationBases(observedBaseScores)
        }
    }

    fun removePeer(peerId: String) {
        synchronized(scoreShapeLock) {
            if (evidenceVersionsByRegistryMember.containsKey(peerId)) {
                evidenceVersionsByRegistryMember[peerId] = Any()
            }
            val removed = records.remove(peerId) ?: return
            provisionalRegistryRecords.remove(peerId, removed)
            removed.snapshotPublicationListener = null
            if (peerId in registryMemberIds) {
                registryMembersMissingRecords++
            }
            removeTrackedScoreShape(peerId)
            capacityEvictionIndex.entry(peerId)?.let { entry ->
                capacityEvictionIndex.upsert(entry.copy(
                    tier = 0,
                    localScore = 0.0,
                    witnessedTenureMs = 0L,
                    hasSuccessfulObservation = false,
                ))
            }
        }
    }

    internal fun upsertCapacityEvictionEntry(entry: PeerCapacityEvictionEntry) {
        synchronized(scoreShapeLock) {
            if (entry.peerId !in registryMemberIds) return
            capacityEvictionIndex.upsert(
                capacityEntryWithEvidence(entry, records[entry.peerId]?.snapshot(), scoreShapeScorer)
            )
        }
    }

    internal fun capacityEvictionVictimIds(count: Int): List<String> =
        synchronized(scoreShapeLock) { capacityEvictionIndex.victims(count) }

    internal fun capacityEvictionIndexState(): PeerCapacityEvictionIndexState =
        synchronized(scoreShapeLock) {
            PeerCapacityEvictionIndexState(
                capacityEvictionIndex.workCount,
                capacityEvictionIndex.entryCount,
                Math.toIntExact(capacityEvictionIndex.nodeCount),
            )
        }

    fun hasPeer(peerId: String): Boolean = records.containsKey(peerId)

    fun importRecords(other: PeerObservationLog) {
        for (record in other.records.values) {
            // Observation records publish changes to one owning log's aggregate score index.
            // Copy imported state instead of sharing a mutable record between two logs.
            installRecord(PeerObservationRecord.fromJson(record.toJson()))
        }
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("schemaVersion", 2)
        put("records", JSONObject().apply {
            records.toSortedMap().forEach { (peerId, record) ->
                put(peerId, record.toJson())
            }
        })
    }

    private fun getOrCreate(
        peerId: String,
        discoveredAtMs: Long = peerRegistryWallTimeMillis(clock)
    ): PeerObservationRecord {
        records[peerId]?.let { record ->
            if (provisionalRegistryRecords[peerId] !== record && records[peerId] === record) return record
            synchronized(scoreShapeLock) {
                // Rollback may have won since the first read. Never hand out its detached record.
                records[peerId]?.let { current ->
                    provisionalRegistryRecords.remove(peerId, current)
                    return current
                }
            }
        }
        val created = PeerObservationRecord(
            peerId = peerId,
            firstSeenMs = discoveredAtMs,
            initialDiscoveredAtMs = discoveredAtMs,
            initialFirstSeenAtMs = null
        )
        return synchronized(scoreShapeLock) {
            val existing = records.putIfAbsent(peerId, created)
            if (existing != null) {
                provisionalRegistryRecords.remove(peerId, existing)
                existing
            } else {
                attachScoreShapeTracking(created)
                created
            }
        }
    }

    internal fun hasUniformPositiveBootstrapScore(): Boolean =
        synchronized(scoreShapeLock) {
            if (
                registryMemberIds.isEmpty() ||
                registryMembersMissingRecords != 0 ||
                records.size != registryMemberIds.size ||
                scoreShapeByPeer.size != records.size ||
                unsupportedScoreShapeCount != 0 ||
                scoreShapeCounts.size != 1
            ) {
                return@synchronized false
            }
            val shape = scoreShapeCounts.keys.single()
            scoreShapeScorer.bootstrapScoreForTiedPopulation(shape, scoreShapeByPeer.size) > 0.0
        }

    internal fun getBootstrapScoreShape(peerId: String): PeerBootstrapScoreShape? =
        synchronized(scoreShapeLock) { scoreShapeByPeer[peerId] }

    /**
     * Returns the bounded aggregate needed by the exact incremental duplicate-address index.
     *
     * The fast path is deliberately limited to recommendation-free populations with one shared
     * exact score shape. Other populations retain full ranking. Changed peers remain dirty until a
     * supported population is observed, so a temporary unsupported state cannot leave the index
     * stale when it later becomes eligible.
     */
    internal fun consumeIncrementalBootstrapScoreState(): IncrementalBootstrapScoreState? =
        synchronized(scoreShapeLock) {
            if (
                registryMemberIds.isEmpty() ||
                registryMembersMissingRecords != 0 ||
                records.size != registryMemberIds.size ||
                scoreShapeByPeer.size != records.size ||
                unsupportedScoreShapeCount != 0 ||
                scoreShapeCounts.size != 1
            ) {
                return@synchronized null
            }
            val changedShapes = changedScoreShapePeerIds.mapNotNull { peerId ->
                scoreShapeByPeer[peerId]?.let { peerId to it }
            }.toMap()
            changedScoreShapePeerIds.clear()
            IncrementalBootstrapScoreState(
                uniformShape = scoreShapeCounts.keys.single(),
                changedShapes = changedShapes,
                populationSize = scoreShapeByPeer.size
            )
        }

    /**
     * Tracks the membership population for which the registry may use its tied-score eviction
     * index. Observation records remain publicly mutable, so score uniformity is safe only when
     * this population and the record population are exactly the same set.
     */
    internal fun registerRegistryMember(peerId: String) {
        synchronized(scoreShapeLock) {
            val activateTracking = registryMemberIds.isEmpty()
            if (registryMemberIds.add(peerId)) {
                // Capture can precede score-population registration; preserve that proof's epoch.
                evidenceVersionsByRegistryMember.putIfAbsent(peerId, Any())
                if (!records.containsKey(peerId)) {
                    registryMembersMissingRecords++
                }
                if (activateTracking) {
                    // Record listeners also publish through scoreShapeLock while tracking is
                    // inactive. Rebuilding here therefore starts from one coherent population;
                    // the next mutation cannot publish until its replacement shape is ready.
                    records.toSortedMap().values.forEach { record ->
                        replaceTrackedScoreShape(record.snapshot())
                    }
                }
            }
        }
    }

    internal fun unregisterRegistryMember(peerId: String) {
        synchronized(scoreShapeLock) {
            capacityEvictionIndex.remove(peerId)
            evidenceVersionsByRegistryMember.remove(peerId)
            if (registryMemberIds.remove(peerId) && !records.containsKey(peerId)) {
                registryMembersMissingRecords--
            }
            if (registryMemberIds.isEmpty()) {
                clearTrackedScoreShapes()
            }
        }
    }

    private fun installRecord(record: PeerObservationRecord) {
        synchronized(scoreShapeLock) {
            if (records.putIfAbsent(record.peerId, record) == null) {
                attachScoreShapeTracking(record)
            }
        }
    }

    private fun attachScoreShapeTracking(record: PeerObservationRecord) {
        record.snapshotPublicationListener = { snapshot, publish ->
            synchronized(scoreShapeLock) {
                if (records[snapshot.peerId] === record) {
                    // Publish the record and its aggregate score shape under the same lock. This
                    // prevents eviction from seeing a new score with the old shape, or vice versa.
                    publish()
                    if (registryMemberIds.isNotEmpty()) {
                        replaceTrackedScoreShape(snapshot)
                    }
                } else {
                    publish()
                }
            }
        }
        synchronized(scoreShapeLock) {
            if (records[record.peerId] === record) {
                if (record.peerId in registryMemberIds) {
                    registryMembersMissingRecords--
                }
                if (registryMemberIds.isNotEmpty()) {
                    replaceTrackedScoreShape(record.snapshot())
                }
            }
        }
    }

    private fun replaceTrackedScoreShape(snapshot: PeerObservationSnapshot) {
        if (snapshot.peerId in registryMemberIds) {
            capacityEvictionIndex.entry(snapshot.peerId)?.let { entry ->
                capacityEvictionIndex.upsert(capacityEntryWithEvidence(entry, snapshot, scoreShapeScorer))
            }
        }
        removeTrackedScoreShape(snapshot.peerId)
        val shape = scoreShapeScorer.bootstrapScoreShape(snapshot)
        scoreShapeByPeer[snapshot.peerId] = shape
        changedScoreShapePeerIds.add(snapshot.peerId)
        if (shape == null) {
            unsupportedScoreShapeCount++
        } else {
            scoreShapeCounts[shape] = (scoreShapeCounts[shape] ?: 0) + 1
        }
    }

    private fun removeTrackedScoreShape(peerId: String) {
        if (!scoreShapeByPeer.containsKey(peerId)) return
        val previous = scoreShapeByPeer.remove(peerId)
        changedScoreShapePeerIds.remove(peerId)
        if (previous == null) {
            unsupportedScoreShapeCount--
            return
        }
        val previousCount = scoreShapeCounts.getValue(previous)
        if (previousCount == 1) {
            scoreShapeCounts.remove(previous)
        } else {
            scoreShapeCounts[previous] = previousCount - 1
        }
    }

    private fun clearTrackedScoreShapes() {
        scoreShapeByPeer.clear()
        scoreShapeCounts.clear()
        changedScoreShapePeerIds.clear()
        unsupportedScoreShapeCount = 0
    }

    private fun requireValidVouchPrior(peerId: String, vouchPrior: Double) {
        if (vouchPrior !in COLD_CONTACT_PRIOR..MAX_VOUCH_PRIOR) {
            throw IllegalArgumentException(
                "Vouch prior for peer '$peerId' must be between $COLD_CONTACT_PRIOR and " +
                    "$MAX_VOUCH_PRIOR inclusive, but was $vouchPrior"
            )
        }
    }

}

private class PeerSourceFreshnessState(
    val observedElapsedMillis: Long?,
    val observationId: String = java.util.UUID.randomUUID().toString(),
    var lastSampleMillis: Long? = observedElapsedMillis,
    var lifetimeCapMillis: Long = Long.MAX_VALUE,
    var expired: Boolean = observedElapsedMillis == null
)

private fun samplePeerSourceFreshness(
    state: PeerSourceFreshnessState,
    observerPeerId: String,
    now: Long,
    lifetimeMillis: Long
): PeerFreshness {
    val observed = state.observedElapsedMillis
    val previous = state.lastSampleMillis
    if (previous != null && now < previous) state.expired = true
    state.lastSampleMillis = now
    val elapsed = if (observed != null && now >= observed) now - observed else -1L
    state.lifetimeCapMillis = minOf(state.lifetimeCapMillis, lifetimeMillis)
    if (elapsed >= state.lifetimeCapMillis) state.expired = true
    val remaining = if (state.expired || elapsed < 0L) 0L else state.lifetimeCapMillis - elapsed
    return PeerFreshness(observerPeerId, state.observationId, remaining)
}
