package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import kotlin.random.Random

/**
 * Maintains the peer health-check backoff schedule.
 *
 * Check intervals follow exponential backoff:
 * `min(5min × 2^min(failures, 10) × jitter[0.8, 1.2], 6h)`.
 * Reputation no longer removes peers at score or calendar thresholds. The
 * registry cap and score-ranked eviction/allocation are wired separately.
 */
class PeerPruner(
    @Suppress("UNUSED_PARAMETER") scorer: PeerScorer,
    private val clock: Clock = SystemClock(),
    private val jitterFactor: () -> Double = {
        Random.Default.nextDouble(MIN_CHECK_JITTER, MAX_CHECK_JITTER)
    }
) {
    companion object {
        const val PROTECTED_RECENT_COUNT = 10
        const val PROTECTED_STABLE_COUNT = 10

        /** Grace period is 25% of the peer's total known age. */
        const val GRACE_RATIO = 0.25

        /** Grace period capped at 7 days. */
        const val MAX_GRACE_PERIOD_MS = 7L * 24 * 60 * 60 * 1000

        /** Peers known for less than this are considered ephemeral. */
        const val EPHEMERAL_AGE_THRESHOLD_MS = 2L * 60 * 60 * 1000

        /** Ephemeral peers need this many consecutive failures to be pruned. */
        const val EPHEMERAL_FAILURE_THRESHOLD = 3

        /** Peers below this score with no recent success are pruned. */
        const val LOW_SCORE_THRESHOLD = 0.3

        /** "No recent success" means no success in this window. */
        const val UNRESPONSIVE_THRESHOLD_MS = 24L * 60 * 60 * 1000

        /** Minimum age and reliability to qualify for "most stable" protection. */
        const val STABLE_MIN_AGE_MS = 24L * 60 * 60 * 1000
        const val STABLE_MIN_RELIABILITY = 0.7

        /** Base check interval for healthy peers. */
        const val BASE_CHECK_INTERVAL_MS = 5L * 60 * 1000

        /** Maximum check interval after repeated failures. */
        const val MAX_CHECK_INTERVAL_MS = 6L * 60 * 60 * 1000

        const val MIN_CHECK_JITTER = 0.8
        const val MAX_CHECK_JITTER = 1.2
        const val MAX_BACKOFF_EXPONENT = 10
    }

    /**
     * Determines which peers should be pruned.
     *
     * @param snapshots Observation snapshots for all tracked peers.
     * @param currentPeerIds All peer IDs currently in the registry.
     * @return Set of peer IDs that should be pruned.
     */
    fun determinePeersToPrune(
        @Suppress("UNUSED_PARAMETER")
        snapshots: Map<String, PeerObservationSnapshot>,
        @Suppress("UNUSED_PARAMETER")
        currentPeerIds: Set<String>
    ): Set<String> {
        // Deliberately consume neither score nor time here. PEER_MANAGEMENT.md
        // replaces threshold pruning with score-proportional starvation and
        // score-ranked eviction at the fixed registry cap.
        return emptySet()
    }

    /**
     * Calculates the next check interval for a peer using exponential backoff.
     *
     * Each consecutive failure doubles the base interval, the exponent saturates at
     * [MAX_BACKOFF_EXPONENT], and jitter is applied before the
     * [MAX_CHECK_INTERVAL_MS] cap.
     *
     * @param consecutiveFailures Number of consecutive ping failures.
     * @return Interval in milliseconds before the next check is due.
     */
    fun nextCheckInterval(consecutiveFailures: Int): Long {
        val jitter = jitterFactor()
        if (jitter !in MIN_CHECK_JITTER..MAX_CHECK_JITTER) {
            throw IllegalArgumentException(
                "Peer health-check jitter factor must be between $MIN_CHECK_JITTER and " +
                    "$MAX_CHECK_JITTER inclusive, but was $jitter"
            )
        }
        val exponent = consecutiveFailures.coerceIn(0, MAX_BACKOFF_EXPONENT)
        val backoff = BASE_CHECK_INTERVAL_MS * (1L shl exponent)
        return (backoff * jitter).toLong().coerceAtMost(MAX_CHECK_INTERVAL_MS)
    }

    /**
     * Returns the IDs of the [count] peers with the most recent successful contact.
     *
     * Only considers peers that have been successfully contacted at least once
     * (lastSuccessMs > 0). Peers that have never been successfully contacted should
     * not receive "recently contacted" protection.
     */
    fun findMostRecentPeers(
        snapshots: Map<String, PeerObservationSnapshot>,
        count: Int
    ): Set<String> {
        return snapshots.entries
            .filter { it.value.lastSuccessMs > 0L }
            .sortedByDescending { it.value.lastSuccessMs }
            .take(count)
            .map { it.key }
            .toSet()
    }

    /**
     * Returns the IDs of the [count] most stable peers — those with high scores,
     * sufficient age, and good reliability.
     */
    fun findMostStablePeers(
        snapshots: Map<String, PeerObservationSnapshot>,
        scores: Map<String, Double>,
        count: Int
    ): Set<String> {
        val now = clock.currentTimeMillis()
        return snapshots.entries
            .filter { (_, snap) ->
                val age = now - snap.firstSeenMs
                val adjustedTotal = snap.successCount + snap.failWhileSelfOnlineCount
                val reliability = if (adjustedTotal > 0) {
                    snap.successCount.toDouble() / adjustedTotal
                } else {
                    0.5
                }
                age >= STABLE_MIN_AGE_MS && reliability >= STABLE_MIN_RELIABILITY
            }
            .sortedByDescending { (peerId, _) -> scores[peerId] ?: 0.0 }
            .take(count)
            .map { it.key }
            .toSet()
    }

}
