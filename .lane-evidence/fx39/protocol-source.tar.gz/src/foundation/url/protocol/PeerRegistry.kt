package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.logging.MessageSeverity
import foundation.url.protocol.simulation.SimulatedPeer
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.captureEffectHandlerContext
import kotlinx.algebraiceffects.toss
import kotlinx.algebraiceffects.withEffectHandlerContext
import okio.FileSystem
import okio.Path
import okio.Path.Companion.toPath
import okio.buffer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.util.Collections
import java.util.PriorityQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.locks.ReentrantLock
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.withLock

private class PeerLifetimeClockPreparation(
    val previous: PeerLifetimeClockPreparation?,
    var completedEntries: Long = 0
)

private class RegistryAddressSnapshotPeer(
    private val delegate: BootstrapPeer,
    override val peerId: String,
    override val multiaddresses: List<String>,
    private val serializedMetadata: String
) : BootstrapPeer by delegate {
    override fun toJson(): JSONObject = JSONObject(serializedMetadata).apply {
        put("peerId", peerId)
        put("multiaddresses", JSONArray(multiaddresses))
        put("advertisedServices", JSONArray(advertisedServices))
        put("lastSeenTimestamp", lastSeenTimestamp)
    }
}

private fun captureRegistryPeerMetadata(peer: BootstrapPeer): String {
    val serialized = peer.toJson()
    val extraFields = serialized.keySet().filter {
        it != "peerId" && it != "multiaddresses" &&
            it != "advertisedServices" && it != "lastSeenTimestamp"
    }
    // Text owns nested metadata too, and each later result gets its own JSON containers.
    return JSONObject(serialized, *extraFields.toTypedArray()).toString()
}

private class RegistryPeerAddPreparation {
    var serialized: String? = null
    var committed = false
}

private fun needsRegistryPeerMetadata(peer: BootstrapPeer): Boolean =
    peer !is RegistryAddressSnapshotPeer && peer !is Libp2pPeer && peer !is TestPeer

private fun retainRegistryAddresses(
    peerId: String,
    peer: BootstrapPeer,
    addresses: List<String>,
    serializedMetadata: String?
): BootstrapPeer =
    when (peer) {
        is RegistryAddressSnapshotPeer -> peer
        is Libp2pPeer -> peer.also { it.retainRegistryAddresses(addresses) }
        is TestPeer -> peer.also { it.retainRegistryAddresses(addresses) }
        is SimulatedPeer -> peer.also {
            it.retainRegistryAddresses(peerId, addresses, checkNotNull(serializedMetadata) {
                "Custom metadata for peer '$peerId' must be captured before registry admission"
            })
        }
        else -> RegistryAddressSnapshotPeer(peer, peerId, addresses, checkNotNull(serializedMetadata) {
            "Custom metadata for peer '$peerId' must be captured before registry admission"
        })
    }

private const val IMPORTED_PEER_FRESHNESS_HISTORY = "importedPeerFreshnessHistory"
private const val PEER_FRESHNESS_HISTORY_DIRECTORY = "peer-freshness-history"

private fun peerFreshnessHistoryToJson(entries: List<PeerFreshnessHistoryEntry>): JSONArray =
    JSONArray(entries.map { it.freshness.toJson().put("retentionMillis", it.retentionMillis) })

private fun peerFreshnessHistoryFromJson(array: JSONArray?): List<PeerFreshnessHistoryEntry>? {
    if (array == null) return null
    return (0 until array.length()).mapNotNull { index ->
        val json = array.optJSONObject(index) ?: return@mapNotNull null
        val freshness = PeerFreshness.fromJson(json) ?: return@mapNotNull null
        val retention = json.optLong("retentionMillis", 0L)
        if (retention <= 0L) null else PeerFreshnessHistoryEntry(freshness, retention)
    }
}

// Global order, with unused guards skipped: lifetime -> record persistence -> dial outcome
// -> publication -> capacity -> peer stripe -> peer-map bucket -> freshness window
// -> observation record -> observation score. Service-index buckets and quarantine are leaves.
// A lifetime action never acquires another lifetime monitor. Admission prepares caller
// collections/JSON/time before publication, then checks its revision. The publication coordinator
// is never retained across transaction acquisition or a wait for a lifetime. Removal joins only
// its own lifetime's record writes and dispatches callbacks after releasing transaction guards.
// History ownership is separate from lifetime record ownership and covers history operations only.
// Primary record intents publish outside history ownership; storage callbacks cannot wait for an
// occupied lifecycle or persistence owner. Neither persistence path reacquires a lifecycle monitor.
// The caller-supplied Clock is a leaf: it is never sampled while any registry guard is held.
// Active lifetime actions reuse a clock sample prepared before entering their monitor.
// Persistence bodies also share their prepared sample with synchronous storage callbacks.
private const val PEER_MUTATION_LOCK_COUNT = 256
private fun peerMutationLockIndex(peerId: String): Int {
    val hash = peerId.hashCode()
    return (hash xor (hash ushr 16)) and (PEER_MUTATION_LOCK_COUNT - 1)
}

/**
 * Top-level reports attached by one operation; caller graphs are never inspected.
 * Reused originals may acquire reciprocal links. Composition terminates because it
 * only retains the supplied objects; standard JVM printing handles repeated references.
 */
internal class PeerFailureOwner {
    val attachments = java.util.IdentityHashMap<Throwable, MutableSet<Throwable>>()
}

private fun appendPeerFailureIfSafe(primary: Throwable, secondary: Throwable, owner: PeerFailureOwner) {
    if (primary === secondary) return
    val attached = owner.attachments.getOrPut(primary) {
        Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
    }
    if (attached.add(secondary)) primary.addSuppressed(secondary)
}

private fun preservePrimaryFailure(
    primary: Throwable,
    secondary: Throwable,
    owner: PeerFailureOwner = currentPeerFailureOwner(),
): Throwable = combinePeerFailures(primary, secondary, owner)

private fun combinePeerFailures(primary: Throwable, secondary: Throwable, owner: PeerFailureOwner): Throwable {
    if (primary === secondary) return primary
    if (secondary is Error && primary !is Error) return combinePeerFailures(secondary, primary, owner)
    appendPeerFailureIfSafe(primary, secondary, owner)
    return primary
}

private fun retainPeerPublicationFailure(
    primary: Throwable?,
    failure: Throwable,
    owner: PeerFailureOwner,
): Throwable = if (primary == null) failure else combinePeerFailures(primary, failure, owner)

// Keep completion failures on an owned report before an original Error can ignore attachments.
private fun retainPeerRemovalFailure(
    primary: Throwable?,
    failure: Throwable,
    report: PeerPersistenceException,
    owner: PeerFailureOwner,
): Throwable {
    if (primary != null && primary !== failure) {
        appendPeerFailureIfSafe(report, primary, owner)
        appendPeerFailureIfSafe(report, failure, owner)
    }
    return retainPeerPublicationFailure(primary, failure, owner)
}

class PeerPersistenceException(
    message: String,
    cause: Throwable? = null
) : RuntimeException(message, cause)

class PeerPersistenceWarningEffect(
    val failure: PeerPersistenceException
) : NotificationEffect(
    failure.message ?: "Peer persistence failed without an error message",
    MessageSeverity.WARNING,
    failure
)

private data class RankedIpAddress(
    val familyBits: Int,
    val bytes: ByteArray
) {
    override fun equals(other: Any?): Boolean =
        other is RankedIpAddress && familyBits == other.familyBits && bytes.contentEquals(other.bytes)

    override fun hashCode(): Int = 31 * familyBits + bytes.contentHashCode()
}

/**
 * Incremental index of addresses already chosen by the greedy bootstrap walk. A longest-prefix
 * query replaces a scan of every previously selected peer while returning the same nearest-address
 * distance used by the original implementation.
 */
private class SelectedIpPrefixIndex {
    private class Node {
        var zero: Node? = null
        var one: Node? = null
    }

    private val roots = mutableMapOf<Int, Node>()

    fun add(address: RankedIpAddress) {
        var node = roots.getOrPut(address.familyBits) { Node() }
        repeat(address.familyBits) { bitIndex ->
            val byteIndex = bitIndex / 8
            val bitMask = 1 shl (7 - bitIndex % 8)
            node = if ((address.bytes[byteIndex].toInt() and bitMask) == 0) {
                node.zero ?: Node().also { node.zero = it }
            } else {
                node.one ?: Node().also { node.one = it }
            }
        }
    }

    fun longestSharedPrefix(address: RankedIpAddress): Int? {
        var node = roots[address.familyBits] ?: return null
        var matched = 0
        while (matched < address.familyBits) {
            val byteIndex = matched / 8
            val bitMask = 1 shl (7 - matched % 8)
            val next = if ((address.bytes[byteIndex].toInt() and bitMask) == 0) {
                node.zero
            } else {
                node.one
            } ?: break
            node = next
            matched++
        }
        return matched
    }
}

private fun diversityBlockKey(address: RankedIpAddress): Long {
    val prefixBytes = if (address.familyBits == 32) 2 else 4
    var prefix = 0L
    repeat(prefixBytes) { index ->
        prefix = (prefix shl 8) or (address.bytes[index].toLong() and 0xffL)
    }
    return (address.familyBits.toLong() shl 32) or prefix
}

private data class BootstrapRankingContext(
    val peers: List<BootstrapPeer>,
    val scores: Map<String, PeerScoreComponents>,
    val addressesByPeer: Map<String, List<RankedIpAddress>>,
    val insertionSequenceByPeer: Map<String, Long>
)

private data class BootstrapRankingResult(
    val ranking: List<BootstrapPeer>,
    val lastPeer: BootstrapPeer?
)

data class PeerRegistryEvictionWorkDiagnostics internal constructor(
    val rankingCandidateVisits: Long,
    val getAllPeersCandidateCopies: Long,
    val duplicateIpv4FallbackCandidateVisits: Long,
    val incrementalIndexWork: Long,
    val incrementalIndexEntries: Int,
    val incrementalIndexNodes: Int
) {
    constructor(
        rankingCandidateVisits: Long,
        getAllPeersCandidateCopies: Long,
        duplicateIpv4FallbackCandidateVisits: Long = 0L
    ) : this(
        rankingCandidateVisits = rankingCandidateVisits,
        getAllPeersCandidateCopies = getAllPeersCandidateCopies,
        duplicateIpv4FallbackCandidateVisits = duplicateIpv4FallbackCandidateVisits,
        incrementalIndexWork = 0L,
        incrementalIndexEntries = 0,
        incrementalIndexNodes = 0
    )

    // Retain the published three-argument copy and copy$default methods for compiled callers.
    fun copy(
        rankingCandidateVisits: Long = this.rankingCandidateVisits,
        getAllPeersCandidateCopies: Long = this.getAllPeersCandidateCopies,
        duplicateIpv4FallbackCandidateVisits: Long = this.duplicateIpv4FallbackCandidateVisits
    ): PeerRegistryEvictionWorkDiagnostics = PeerRegistryEvictionWorkDiagnostics(
        rankingCandidateVisits = rankingCandidateVisits,
        getAllPeersCandidateCopies = getAllPeersCandidateCopies,
        duplicateIpv4FallbackCandidateVisits = duplicateIpv4FallbackCandidateVisits,
        incrementalIndexWork = incrementalIndexWork,
        incrementalIndexEntries = incrementalIndexEntries,
        incrementalIndexNodes = incrementalIndexNodes
    )
}

/** Identifies who supplied one accepted [PeerRegistry.addPeer] mutation. */
enum class PeerRegistryAddOrigin {
    /** A direct application call through the original additive API. */
    CALLER,

    /** A peer or service record learned from a remote provider catalog or gossip message. */
    CATALOG,

    /** A peer learned through peer exchange, LAN discovery, or another discovery walk. */
    DISCOVERY,

    /** A relay learned or restored by relay discovery, registration, or failover. */
    RELAY,

    /** A peer record restored from this registry's persistent store. */
    PERSISTENCE
}

/**
 * The minimum provenance retained for one peer's current registry lifetime.
 *
 * [hasCallerOrigin] is monotonic for a retained lifetime: after any direct application add it stays
 * true across later catalog, discovery, relay, and persistence refreshes. [lastAcceptedOrigin]
 * records the origin of the most recently accepted add. Removal clears the state; a later re-add
 * starts a new lifetime. Both fields are persisted, except that restoration itself becomes the
 * current PERSISTENCE origin while preserving the stored caller-history bit.
 */
data class PeerRegistryPeerOriginState(
    val hasCallerOrigin: Boolean,
    val lastAcceptedOrigin: PeerRegistryAddOrigin
)

/**
 * A registry snapshot captured before checking whether a peer should be removed.
 * A route change, explicit caller refresh or successful local observation invalidates it.
 */
class PeerRemovalCandidate internal constructor(
    val peerId: String,
    val peer: BootstrapPeer,
    val lifetime: PeerLifetime,
    internal val successfulEvidence: PeerSuccessfulEvidence,
    internal val routeEvidenceVersion: Any,
    internal val importedEvidenceVersion: Long?
)

internal class PeerRemovalRouteEvidence(
    val addresses: Map<String, Int>,
    val version: Any = Any()
)

private inline fun <T> withPeerLifetimeMonitor(
    monitor: Any,
    admission: ReentrantLock,
    completed: () -> Unit,
    onWait: () -> Unit = {},
    action: () -> T
): T = withPeerPersistenceNotifications {
    enterPeerLifetimeMonitor(monitor, admission, completed, onWait, action)
}

private inline fun <T> enterPeerLifetimeMonitor(
    monitor: Any,
    admission: ReentrantLock,
    completed: () -> Unit,
    onWait: () -> Unit,
    action: () -> T
): T {
    while (true) {
        if (admission.tryLock()) {
            try {
                return synchronized(monitor) {
                    try {
                        action()
                    } finally {
                        completed()
                    }
                }
            } finally {
                admission.unlock()
            }
        }
        checkPeerCallbackCanWait("PeerLifetime.lifecycleLock")
        onWait()
        // Join the current monitor owner, then try admission again. No caller
        // time is read here, and the action validates its prepared version.
        synchronized(monitor) { }
    }
}

/**
 * Stable identity for one continuous retained lifetime of [peerId] in a [PeerRegistry].
 *
 * A registry refresh keeps the same token. Any removal ends it, including public removal,
 * capacity eviction, dial-failure eviction, and pruning; a later re-add receives a new token with
 * a higher [generation]. [runIfActive] is ordered with removal: its action either finishes before
 * removal callbacks begin, or returns `false` without running after removal has won. This lets a
 * caller publish peer-scoped state without a check-then-write race against cleanup.
 *
 * [onRemoval] callbacks registered before removal begins run synchronously exactly once when this
 * lifetime ends, unless their subscription was closed first. Those captured callbacks finish
 * before the registry publishes a later lifetime for the same peer ID. A callback registered after
 * removal begins runs immediately on its registering thread and is not part of that ordered
 * handoff, so it may overlap the captured callbacks or finish after a later lifetime is published.
 * Registry removal for this peer and creation of any new peer from inside [runIfActive] are rejected
 * because either operation could end this lifetime before the active action returns. An action may
 * nest another action for this same lifetime; acquiring a different lifetime through an action,
 * active removal subscription, removal or persistence is rejected before waiting for its monitor.
 * Callbacks run
 * without registry locks and may make bounded calls to the same registry. A callback-context add of
 * any peer whose prior removal callbacks are unfinished is rejected immediately instead of waiting
 * on a handoff that the callback may itself be responsible for finishing. If unrelated work for an
 * earlier peer in the same removal batch throws a fatal [Throwable], this lifetime's captured
 * callbacks still run before its handoff finishes. The original fatal failure remains primary;
 * callback and handoff failures from the rest of the batch are attached to it as suppressed
 * failures.
 */
class PeerLifetime internal constructor(
    val peerId: String,
    val generation: Long,
    private val registryIdentity: Any,
    private val withPersistenceOwnership: (() -> Unit, () -> Unit) -> Unit,
    private val withActionClockSample: (() -> Boolean) -> Boolean
) {
    private val clockPreparation = ThreadLocal<PeerLifetimeClockPreparation>()
    private val lifecycleLock = Any()
    private val lifecycleAdmission = ReentrantLock()
    @Volatile
    private var active = true
    private var activeActionThread: Thread? = null
    private var activeActionDepth = 0
    @Volatile private var completedMonitorVersion = 0L
    // Every owner completes this transition before releasing the monitor, including
    // subscription changes and active-state reads. A waiting prepared operation can
    // therefore distinguish its sample from time prepared after the latest owner.
    private val monitorCompleted: () -> Unit = {
        completedMonitorVersion++
        var preparation = clockPreparation.get()
        while (preparation != null) {
            preparation.completedEntries++
            preparation = preparation.previous
        }
    }
    private var nextListenerId = 0L
    private var removalListeners = LinkedHashMap<Long, () -> Unit>()

    companion object {
        private val activeActionStack = ThreadLocal<MutableList<PeerLifetime>>()

        internal fun activeActionForRegistry(registryIdentity: Any): PeerLifetime? =
            activeActionStack.get()?.asReversed()?.firstOrNull {
                it.registryIdentity === registryIdentity
            }
    }

    /**
     * Runs [action] only while this lifetime is active.
     *
     * Removal waits for a running action before invoking removal callbacks. Once removal has begun,
     * this method returns `false` and does not invoke [action]. An active action for a different
     * lifetime on this thread causes an [IllegalStateException] before any lifecycle wait.
     * Exceptions from [action] propagate.
     */
    fun runIfActive(action: () -> Unit): Boolean {
        if (!active) return false
        rejectNestedLifetimeAcquisition("run a lifetime action")
        while (true) {
            val versionBeforePreparation = completedMonitorVersion
            val previousPreparation = clockPreparation.get()
            val preparation = PeerLifetimeClockPreparation(previousPreparation)
            clockPreparation.set(preparation)
            var joinedOwner = false
            try {
                val result = withActionClockSample {
                    if (previousPreparation == null) clockPreparation.remove()
                    else clockPreparation.set(previousPreparation)
                    val preparedVersion = completedMonitorVersion
                    if (preparedVersion - versionBeforePreparation != preparation.completedEntries) {
                        joinedOwner = true
                        false
                    } else withPeerLifetimeMonitor(
                        lifecycleLock, lifecycleAdmission, monitorCompleted, onWait = { joinedOwner = true }
                    ) {
                        if (joinedOwner || completedMonitorVersion != preparedVersion) {
                            joinedOwner = true
                            false
                        } else if (!active) {
                            false
                        } else {
                            activeActionThread = Thread.currentThread()
                            activeActionDepth++
                            val actionStack = activeActionStack.get() ?: mutableListOf<PeerLifetime>().also {
                                activeActionStack.set(it)
                            }
                            actionStack.add(this)
                            try {
                                action()
                                true
                            } finally {
                                check(actionStack.removeAt(actionStack.lastIndex) === this) {
                                    "PeerLifetime.runIfActive action stack changed before the action returned"
                                }
                                if (actionStack.isEmpty()) activeActionStack.remove()
                                activeActionDepth--
                                if (activeActionDepth == 0) activeActionThread = null
                            }
                        }
                    }
                }
                if (!joinedOwner) return result
            } finally {
                if (previousPreparation == null) clockPreparation.remove()
                else clockPreparation.set(previousPreparation)
            }
            // Discard the scope after any intervening owner. Preparation on the next
            // pass runs outside every guard and after the monitor wait just completed.
            if (!active) return false
            checkPeerCallbackCanWait("PeerLifetime.lifecycleLock")
        }
    }
    /**
     * Registers [callback] for this lifetime's removal and returns a subscription that can cancel
     * the callback before removal. A callback registered before removal begins runs once before the
     * registry permits the same peer ID to publish a new lifetime. A callback registered after
     * removal begins runs immediately on this thread and is not joined to the in-progress handoff.
     * Exceptions from captured callbacks propagate after every captured callback was given its one
     * invocation. If another peer's work in the same removal batch throws a fatal [Throwable], this
     * callback still runs before the handoff permits a new lifetime, and any callback failure is
     * suppressed onto that original fatal failure.
     */
    fun onRemoval(callback: () -> Unit): AutoCloseable {
        if (!active) {
            callback()
            return AutoCloseable { }
        }
        rejectNestedLifetimeAcquisition("register a removal callback")
        var invokeImmediately = false
        var listenerId: Long? = null
        withPeerLifetimeMonitor(lifecycleLock, lifecycleAdmission, monitorCompleted) {
            if (active) {
                listenerId = nextListenerId++
                removalListeners[listenerId!!] = callback
            } else {
                invokeImmediately = true
            }
        }
        if (invokeImmediately) callback()
        return AutoCloseable {
            listenerId?.let { id ->
                if (!active) return@let
                rejectNestedLifetimeAcquisition("close a removal subscription")
                withPeerLifetimeMonitor(lifecycleLock, lifecycleAdmission, monitorCompleted) {
                    removalListeners.remove(id)
                }
            }
        }
    }

    // The body is a registry-owned membership transaction, never caller code. It acquires the
    // registry locks only after this lifetime wait, rechecks identity/capacity, and then ends the
    // lifetime using the supplied operation while those short mutation locks are held.
    internal fun <T> beginRemoval(
        prepare: () -> Unit,
        commit: (() -> PeerLifetimeRemoval) -> T
    ): T? {
        if (!active) return null
        rejectNestedLifetimeAcquisition("remove registry membership")
        while (true) {
            val versionBeforePreparation = completedMonitorVersion
            val previousPreparation = clockPreparation.get()
            val preparation = PeerLifetimeClockPreparation(previousPreparation)
            clockPreparation.set(preparation)
            try {
                prepare()
            } finally {
                if (previousPreparation == null) clockPreparation.remove()
                else clockPreparation.set(previousPreparation)
            }
            val preparedVersion = completedMonitorVersion
            // Monitor entries completed by this callback belong to its preparation.
            // Any other completed owner requires fresh preparation before committing.
            if (preparedVersion - versionBeforePreparation != preparation.completedEntries) continue
            var joinedOwner = false
            val result = withPeerLifetimeMonitor(
                lifecycleLock, lifecycleAdmission, monitorCompleted, onWait = { joinedOwner = true }
            ) {
                if (!active) return null
                if (joinedOwner || completedMonitorVersion != preparedVersion) {
                    joinedOwner = true
                    null
                } else {
                    rejectRemovalFromActiveActionOnCurrentThread()
                    commit {
                        check(active) { "Peer '$peerId' lifetime generation $generation was ended twice" }
                        active = false
                        val callbacks = removalListeners.values
                        removalListeners = LinkedHashMap()
                        PeerLifetimeRemoval(peerId, generation, callbacks, withPersistenceOwnership)
                    }
                }
            }
            if (!joinedOwner) return result
        }
    }

    internal fun persistIfActive(prepare: () -> Unit, action: () -> Unit) {
        if (!active) return
        rejectNestedLifetimeAcquisition("persist a record")
        if (!withPeerLifetimeMonitor(lifecycleLock, lifecycleAdmission, monitorCompleted) { active }) return
        withPersistenceOwnership(prepare) {
            // Never reacquire lifecycleLock under persistence ownership: an active action can saveAll.
            // Removal joins this admitted write after marking inactive and releasing its locks.
            if (active) action()
        }
    }

    internal fun isActionOnCurrentThread(): Boolean =
        activeActionStack.get()?.any { it === this } == true

    internal fun rejectNestedLifetimeAcquisition(operation: String) {
        val owner = activeActionStack.get()?.asReversed()?.firstOrNull { it !== this } ?: return
        throw IllegalStateException(
            "Cannot $operation for peer '$peerId' while the PeerLifetime.runIfActive action " +
                "for peer '${owner.peerId}' is executing on the same thread; finish the action " +
                "before acquiring another peer's lifetime"
        )
    }

    internal fun rejectRemovalFromActiveActionOnCurrentThread() {
        rejectNestedLifetimeAcquisition("remove registry membership")
        if (activeActionThread === Thread.currentThread()) {
            throw IllegalStateException(
                "Cannot remove peer '$peerId' from PeerRegistry while its " +
                    "PeerLifetime.runIfActive action is executing on the same thread; " +
                    "finish the action before mutating that peer's registry membership"
            )
        }
    }

    internal fun newPeerAddReentrancyFailure(incomingPeerId: String): IllegalStateException =
        IllegalStateException(
            "Cannot add new peer '$incomingPeerId' to PeerRegistry while the " +
                "PeerLifetime.runIfActive action for peer '$peerId' is executing on the same " +
                "thread; adding a new peer may evict the active peer at registry capacity, so " +
                "finish the action before adding it"
        )
    internal fun unpublishedPeerRefreshReentrancyFailure(incomingPeerId: String) =
        IllegalStateException(
            "Cannot refresh peer '$incomingPeerId' in PeerRegistry because it is retained but unpublished " +
                "while the PeerLifetime.runIfActive action for peer '$peerId' is executing on the same " +
                "thread; a lifetime action may not refresh a retained but unpublished peer, so " +
                "finish the action before refreshing it"
        )

}

internal class PeerLifetimeRemoval(
    private val peerId: String,
    private val generation: Long,
    private val callbacks: Collection<() -> Unit>,
    private val withPersistenceOwnership: (() -> Unit, () -> Unit) -> Unit
) {
    fun awaitPersistence() {
        withPersistenceOwnership({}) {
            // Acquiring the lock is the wait: a persistence operation that began before removal
            // holds it until its final-file move has returned.
        }
    }

    fun invokeCallbacks(owner: PeerFailureOwner, retainFailure: (Throwable) -> Unit): Throwable? {
        val failures = mutableListOf<Throwable>()
        callbacks.forEach { callback ->
            try {
                callback()
            } catch (failure: Throwable) {
                failures += failure
                // Capture the original before the callback wrapper hides its type.
                retainFailure(failure)
            }
        }
        if (failures.isEmpty()) return null

        val primaryFailure = failures.first()
        val aggregateFailure = IllegalStateException(
            "A removal callback failed for peer '$peerId' lifetime generation $generation",
            primaryFailure,
        )
        failures.drop(1).forEach { failure ->
            appendPeerFailureIfSafe(primaryFailure, failure, owner)
            // Retain every callback occurrence independently of the caller's suppression policy.
            aggregateFailure.addSuppressed(failure)
        }
        return aggregateFailure
    }
}

// Orders history capture and history-file writes across membership generations.
// References include callers waiting for storage, so a later writer cannot use a different owner.
private class PeerHistoryPersistenceOwnership {
    val lock = ReentrantLock()
    var references = 0
}

private class PeerPersistenceNotificationScope {
    val notifications = mutableListOf<(Throwable?) -> Unit>()
    val failureOwner = PeerFailureOwner()
}

private val peerPersistenceNotifications = ThreadLocal<PeerPersistenceNotificationScope>()

private fun currentPeerFailureOwner(): PeerFailureOwner =
    peerPersistenceNotifications.get()?.failureOwner ?: PeerFailureOwner()

// The outermost owner on this thread dispatches only after every nested owner has left.
// Remove its state before calling handlers, so re-entry owns a separate, complete scope.
private inline fun <T> withPeerPersistenceNotifications(action: () -> T): T {
    if (peerPersistenceNotifications.get() != null) return action()
    val scope = PeerPersistenceNotificationScope()
    peerPersistenceNotifications.set(scope)
    var primary: Throwable? = null
    try {
        return action()
    } catch (failure: Throwable) {
        primary = failure
        throw failure
    } finally {
        peerPersistenceNotifications.remove()
        val owner = scope.failureOwner
        var reportFailure: Throwable? = primary
        scope.notifications.forEach { notification ->
            try {
                notification(primary)
            } catch (failure: Throwable) {
                reportFailure = retainPeerPublicationFailure(reportFailure, failure, owner)
            }
        }
        // A handler Error takes priority over an earlier storage Exception after delivery ends.
        if (reportFailure !== primary) reportFailure?.let { throw it }
    }
}

private fun afterPeerPersistenceOwnership(notification: (Throwable?) -> Unit) {
    val scope = peerPersistenceNotifications.get()
    if (scope == null) notification(null) else {
        val handlers = captureEffectHandlerContext()
        scope.notifications.add { primary ->
            withEffectHandlerContext(handlers) { notification(primary) }
        }
    }
}

private fun retainDisplacedPeerFailure(
    report: PeerPersistenceException,
    promotedFailure: Throwable,
    primary: Throwable?,
    owner: PeerFailureOwner
) {
    if (promotedFailure is Error && primary != null && primary !is Error) {
        // The registry-owned report accepts attachments even when the supplied Error does not.
        appendPeerFailureIfSafe(report, primary, owner)
    }
}

private fun withPeerHistoryPersistenceOwnership(
    owners: ConcurrentHashMap<String, PeerHistoryPersistenceOwnership>,
    peerId: String,
    prepare: () -> Unit = {},
    action: () -> Unit
) {
    val owner = checkNotNull(owners.compute(peerId) { _, current ->
        (current ?: PeerHistoryPersistenceOwnership()).also { it.references++ }
    })
    try {
        withPeerPersistenceLock(owner.lock, prepare, action)
    } finally {
        owners.compute(peerId) { _, current ->
            check(current === owner) { "Persistence ownership changed for peer '$peerId'" }
            owner.references--
            if (owner.references == 0) null else owner
        }
    }
}

private fun withPeerPersistenceLock(
    lock: ReentrantLock,
    prepare: () -> Unit,
    action: () -> Unit
) {
    while (true) {
        prepare()
        if (lock.tryLock()) {
            withPeerPersistenceNotifications {
                try {
                    action()
                } finally {
                    lock.unlock()
                }
            }
            return
        }
        // Join the current owner without retaining it across caller time preparation.
        checkPeerCallbackCanWait("peer persistence owner")
        lock.withLock { }
    }
}

private class PeerPersistenceUpdate(val content: String?)

private class PeerPersistenceUpdates(
    @Volatile var latest: PeerPersistenceUpdate,
    var owners: Int = 0
)

private class PeerQuarantine(val expiryMs: Long)

private class PendingDialRemoval(
    val lifetime: PeerLifetime?,
    val quarantine: PeerQuarantine
) {
    val membershipFinished = java.util.concurrent.CompletableFuture<Unit>()
    var postRemovalLifetime: PeerLifetime? = null
    var postRemovalQuarantine: PeerQuarantine? = null
}

private data class PeerRemovalResult(
    val removed: Boolean,
    val completion: PeerRemovalCompletion? = null,
    val publicationFailure: Throwable? = null,
)

private class PeerRemovalCompletion(
    val peerId: String,
    private val lifetimeRemoval: PeerLifetimeRemoval
) {
    private val callbacksFinished = CountDownLatch(1)

    fun awaitCallbacks() {
        if (callbacksFinished.count != 0L) {
            checkPeerCallbackCanWait("peer removal callbacks for '$peerId'")
        }
        var interrupted = false
        while (true) {
            try {
                callbacksFinished.await()
                break
            } catch (_: InterruptedException) {
                interrupted = true
            }
        }
        if (interrupted) Thread.currentThread().interrupt()
    }

    fun awaitPersistence() = lifetimeRemoval.awaitPersistence()

    fun invokeCallbacks(owner: PeerFailureOwner, retainFailure: (Throwable) -> Unit): Throwable? =
        lifetimeRemoval.invokeCallbacks(owner, retainFailure)

    fun finish() {
        callbacksFinished.countDown()
    }
}

private data class BootstrapRankingState(
    val peer: BootstrapPeer,
    val score: Double,
    // Cached upper bound. Every selected peer can only lower diversity utility, so a stale
    // value remains safe for lazy priority-queue ordering until this candidate reaches the top.
    var utility: Double,
    var evaluatedAtSelectedCount: Int,
    // Ordering and diversity inputs resolved once per candidate. The greedy walk compares each
    // candidate against the queue O(n) times, so resolving these per comparison instead would
    // repeat the same score, sequence, and address lookups O(n^2) times.
    val insertionSequence: Long,
    val addresses: List<RankedIpAddress>
)

private class RankedIpv4PeerTrieNode(
    val depth: Int,
    val parent: RankedIpv4PeerTrieNode? = null
) {
    var zero: RankedIpv4PeerTrieNode? = null
    var one: RankedIpv4PeerTrieNode? = null
    var peer: BootstrapPeer? = null
    var bestPeer: BootstrapPeer? = null
}

private data class RankedIpv4PeerRegion(
    val root: RankedIpv4PeerTrieNode,
    val commonPrefixBits: Int,
    val bestPeer: BootstrapPeer
)

private fun rankedAddressBit(address: RankedIpAddress, bitIndex: Int): Int {
    val byteIndex = bitIndex / 8
    val bitMask = 1 shl (7 - bitIndex % 8)
    return if ((address.bytes[byteIndex].toInt() and bitMask) == 0) 0 else 1
}

private fun rankedIpv4AddressKey(address: RankedIpAddress): Long =
    address.bytes.fold(0L) { key, byte -> (key shl 8) or (byte.toLong() and 0xffL) }

private fun parsePeerIpAddresses(multiaddresses: List<String>): List<RankedIpAddress> {
    val result = ArrayList<RankedIpAddress>()
    val seen = HashSet<RankedIpAddress>()
    for (address in multiaddresses) {
        val components = address.split('/')
        for (index in 0 until components.lastIndex) {
            val host = components[index + 1]
            val parsed = when (components[index]) {
                "ip4" -> {
                    val octets = host.split('.')
                    if (octets.size != 4) continue
                    val bytes = ByteArray(4)
                    var valid = true
                    for (octetIndex in bytes.indices) {
                        val octet = octets[octetIndex].toIntOrNull()
                        if (octet == null || octet !in 0..255) { valid = false; break }
                        bytes[octetIndex] = octet.toByte()
                    }
                    if (valid) RankedIpAddress(32, bytes) else null
                }
                "ip6" -> if (
                    !host.contains(':') ||
                    host.any {
                        !it.isDigit() && it.lowercaseChar() !in 'a'..'f' && it != ':' && it != '.'
                    }
                ) {
                    null
                } else {
                    try {
                        val bytes = InetAddress.getByName(host).address
                        if (bytes.size == 16) RankedIpAddress(64, bytes.copyOfRange(0, 8)) else null
                    } catch (_: Exception) {
                        null
                    }
                }
                else -> null
            }
            // These immutable binary keys already encode family and prefix. Formatting every
            // byte as decimal text just to deduplicate it repeats avoidable work on each add.
            if (parsed != null && seen.add(parsed)) result.add(parsed)
        }
    }
    return result
}

private fun capacityEvictionEntry(
    peerId: String,
    addresses: List<RankedIpAddress>,
    insertionSequence: Long,
    hasCallerOrigin: Boolean
): PeerCapacityEvictionEntry {
    val address = addresses.minWithOrNull(Comparator { left, right ->
        val familyComparison = left.familyBits.compareTo(right.familyBits)
        if (familyComparison != 0) {
            familyComparison
        } else {
            var byteComparison = 0
            var index = 0
            while (index < minOf(left.bytes.size, right.bytes.size) && byteComparison == 0) {
                byteComparison = (left.bytes[index].toInt() and 0xff)
                    .compareTo(right.bytes[index].toInt() and 0xff)
                index++
            }
            if (byteComparison != 0) byteComparison else left.bytes.size.compareTo(right.bytes.size)
        }
    })
    if (address == null) {
        return PeerCapacityEvictionEntry(
            peerId = peerId,
            tier = 0,
            family = 0,
            blockKey = "",
            addressKey = "",
            localScore = 0.0,
            witnessedTenureMs = 0L,
            insertionSequence = insertionSequence,
            hasCallerOrigin = hasCallerOrigin
        )
    }

    val hexDigits = "0123456789abcdef"
    val addressKey = buildString(address.bytes.size * 2) {
        address.bytes.forEach { byte ->
            val value = byte.toInt() and 0xff
            append(hexDigits[value ushr 4])
            append(hexDigits[value and 0x0f])
        }
    }
    val prefixByteCount = when (address.familyBits) {
        32 -> 2
        64 -> 4
        else -> error("Unsupported ranked address family ${address.familyBits}")
    }
    return PeerCapacityEvictionEntry(
        peerId = peerId,
        tier = 0,
        family = address.familyBits,
        blockKey = addressKey.take(prefixByteCount * 2),
        addressKey = addressKey,
        localScore = 0.0,
        witnessedTenureMs = 0L,
        insertionSequence = insertionSequence,
        hasCallerOrigin = hasCallerOrigin
    )
}

private fun sameRankedAddressSet(
    left: List<RankedIpAddress>,
    right: List<RankedIpAddress>
): Boolean =
    left.size == right.size &&
        left.indices.all { index ->
            left[index].familyBits == right[index].familyBits &&
                left[index].bytes.contentEquals(right[index].bytes)
        }

private class PendingAnnouncementPeerAdd {
    val commitLock = java.util.concurrent.locks.ReentrantLock()
    @Volatile var cancelled = false
    // Counted only inside pendingAnnouncementPeerAdds.compute.
    var users = 0
}

/**
 * Registry for managing discovered and bootstrap peers.
 *
 * The PeerRegistry handles:
 * - Storing known peers in memory
 * - Persisting peers to disk for future bootstrap
 * - Discovering new peers through the network
 * - Finding peers that can route to specific services
 * - Intelligent pruning with peer scoring and exponential backoff
 *
 * This class is thread-safe and can be accessed concurrently from multiple threads.
 *
 * @property filesystem The filesystem to use for persistence (defaults to system filesystem)
 * @property peersDirectory The directory to store peer files (null for in-memory only)
 * @property clock Clock abstraction for testable time-dependent logic (defaults to system clock)
 */
class PeerRegistry(
    private val filesystem: FileSystem = FileSystem.SYSTEM,
    private val peersDirectory: Path? = null,
    clock: Clock = SystemClock()
) {
    private val registryClock = PeerRegistryClock(clock)

    // Unique instance ID for debugging
    private val instanceId = java.util.UUID.randomUUID().toString().takeLast(8)

    // Use ConcurrentHashMap for thread-safe access
    private val lifetimeRegistryIdentity = Any()
    private val peers = ConcurrentHashMap<String, BootstrapPeer>()
    private val peerLifetimes = ConcurrentHashMap<String, PeerLifetime>()
    private val pendingAnnouncementPeerAdds = ConcurrentHashMap<String, PendingAnnouncementPeerAdd>()
    private val peerHistoryPersistenceOwners = ConcurrentHashMap<String, PeerHistoryPersistenceOwnership>()
    private val peerOriginStates = ConcurrentHashMap<String, PeerRegistryPeerOriginState>()
    // One entry per retained member, serialized by its mutation stripe. Receipt metadata is not
    // liveness: only accepted route changes and explicit caller refreshes advance this revision.
    private val peerRemovalRouteEvidence = ConcurrentHashMap<String, PeerRemovalRouteEvidence>()
    // Installed under the same-peer mutation stripe before an old generation becomes absent.
    // A re-add that reaches the stripe after removal must wait for callback dispatch to complete,
    // but waits without holding any registry lock.
    private val peerRemovalHandoffs = ConcurrentHashMap<String, PeerRemovalCompletion>()
    private class RemovalCallbackContext {
        @Volatile
        var active: Boolean = true
    }
    private val removalCallbackContext = object : InheritableThreadLocal<RemovalCallbackContext?>() {
        override fun childValue(parentValue: RemovalCallbackContext?): RemovalCallbackContext? =
            parentValue
    }
    private val peerLifetimeGeneration = java.util.concurrent.atomic.AtomicLong(1L)
    // Keyed reads include accepted pending members, as before. The bounded list advances only
    // when a closed capacity batch is complete. Each root owns membership and its service index.
    private val acceptedSnapshot = AtomicReference(RegistrySnapshot())
    private val publishedSnapshot = AtomicReference(RegistrySnapshot())
    private val publishedPeersSnapshot: RegistrySnapshot get() = publishedSnapshot.get()
    // Additions omitted because the published snapshot was already at capacity. Guarded by
    // capacityEvictionLock. A full publication appends the surviving entries from this exact set
    // instead of copying the whole peers map into a staging map to rediscover them.
    private val unpublishedPeerIds = HashSet<String>()
    // Published IDs removed while an over-capacity add batch is closed. The full publisher applies
    // these exact removals to the immutable snapshot rather than scanning every retained peer to
    // rediscover the one that left.
    private val unpublishedRemovalIds = LinkedHashSet<String>()
    // Existing published peers refreshed while a batch is closed. Tracking the exact IDs preserves
    // the prior full-publication behavior without re-reading every peer in the snapshot.
    private val unpublishedRefreshIds = LinkedHashSet<String>()
    private val peerImportedProvenance = ConcurrentHashMap<String, PeerFreshness>()
    private val peerFreshnessWindow = PeerFreshnessWindow(registryClock)
    private val observationLog = PeerObservationLog(registryClock)
    private val scorer = PeerScorer(registryClock)
    private val peerPersistenceUpdates = ConcurrentHashMap<String, PeerPersistenceUpdates>()
    private val persistenceFailureLock = Any()
    private val persistenceFailures = ArrayList<PeerPersistenceException>()
    // Keep 64 recent runtime reports as diagnostic context even when peer identities
    // change. Startup reports stay separate so runtime activity cannot displace them.
    private val runtimePersistenceFailures = java.util.ArrayDeque<PeerPersistenceException>()

    // Tracks when each peer was last directly reachable (without relay), as epoch milliseconds.
    // This is a per-observer property: it reflects reachability from THIS node's perspective.
    // A peer is considered "directly reachable" if we successfully connected to it without
    // using a circuit relay within the last DIRECT_REACHABILITY_TTL_MS milliseconds.
    private val directReachability = ConcurrentHashMap<String, Long>()

    // Tracks the first time we observed each peer (epoch milliseconds, by this registry's
    // clock). Drives the longevity component of the eviction score so that long-tenured
    // peers are preferred over freshly-discovered ones when the registry is at capacity.
    // Distinct from [PeerObservationRecord.firstSeenMs]; this legacy sidecar remains the
    // input to the pre-step-4 registry-retention path.
    private val firstSeenAt = ConcurrentHashMap<String, Long>()
    private val rankedAddresses = ConcurrentHashMap<String, List<RankedIpAddress>>()

    // Monotonic insertion/refresh sequence per peer: a higher number means the peer was added
    // or re-announced more recently. It breaks final ties in capacity eviction and public
    // bootstrap ranking, putting newer peers earlier and therefore evicting the oldest tied peer.
    //
    // Without a visibility-ordered tie-breaker, equal candidates were ordered by
    // ConcurrentHashMap iteration. A concurrent add could then lose a newly visible tied peer
    // while older equal peers remained. The sequence is stamped as the last action inside the
    // addPeer compute lambda so it reflects the order in which peers became visible.
    private val insertionSequence = ConcurrentHashMap<String, Long>()
    private val insertionSequenceCounter = java.util.concurrent.atomic.AtomicLong(0L)
    private val evictionRankingCandidateVisits = java.util.concurrent.atomic.AtomicLong(0L)
    private val duplicateIpv4FallbackCandidateVisits = java.util.concurrent.atomic.AtomicLong(0L)
    private val coldEqualAddressCandidateVisits = java.util.concurrent.atomic.AtomicLong(0L)
    private val getAllPeersCandidateCopies = java.util.concurrent.atomic.AtomicLong(0L)
    private val fullSnapshotStagingMapCandidateCopies =
        java.util.concurrent.atomic.AtomicLong(0L)
    private val publicationGateExclusiveAcquisitions = java.util.concurrent.atomic.AtomicLong(0L)
    private val capacityEvictionLock = Any()
    private val concurrentAddPublicationGate = ReentrantReadWriteLock(true)
    private val addPublicationCoordinator = ReentrantLock()
    private val addPublicationAdvanced = addPublicationCoordinator.newCondition()
    private var addPublicationInProgress = false
    private val membershipVersion = java.util.concurrent.atomic.AtomicLong(0L)
    @Volatile
    private var publishedMembershipVersion = 0L
    private val peerMutationLocks = Array(PEER_MUTATION_LOCK_COUNT) { ReentrantLock() }

    // Peers evicted for repeated dial failure, mapped to the epoch millisecond (by this
    // registry's clock) at which they may be learned again.
    //
    // Eviction alone does not stop a dead peer from being dialed: the mesh keeps gossiping it, so
    // the next PeerExchange response or PeerAnnouncement re-adds it within seconds and the next
    // fan-out dials it again. The quarantine window is what converts eviction into an actual
    // reduction in outbound dials — it makes the eviction stick for
    // [DIAL_FAILURE_QUARANTINE_MS] regardless of how often the address is re-advertised.
    private val quarantineLock = Any()
    private val quarantinedUntilMs = LinkedHashMap<String, PeerQuarantine>()

    // Consecutive failed dials per peer, counted by this registry. This is deliberately separate
    // from PeerObservationLog's consecutiveFailures, which counts maintenance-ping outcomes on a
    // backoff schedule; a dial storm is driven by send-path dials that the ping schedule never
    // observes.
    private val consecutiveDialFailures = ConcurrentHashMap<String, Int>()
    // Dial outcomes for one peer must be applied in completion order. In particular, a success
    // that completes after the threshold failure must not clear quarantine and then be followed
    // by that older failure's delayed removePeer call. A fixed stripe array provides that ordering
    // without retaining one lock object for every peer identity ever observed.
    private val dialOutcomeLocks = Array(DIAL_OUTCOME_LOCK_STRIPES) { Any() }
    private val pendingDialRemovals = ConcurrentHashMap<String, PendingDialRemoval>()

    init {
        // Load persisted peers from disk if directory is provided
        withPeerPersistenceNotifications {
            if (peersDirectory != null) {
                migrateV1PersistenceIfNeeded()
                loadPersistedPeers()
                loadPersistedPeerFreshnessHistory()
            }
        }
    }

    /**
     * The number of peers in the registry.
     */
    val size: Int
        get() = acceptedSnapshot.get().size

    /**
     * The number of distinct service identifiers currently retained in the lookup index.
     */
    val serviceCount: Int
        get() = acceptedSnapshot.get().serviceCount

    /**
     * Provides read access to the observation log for external consumers
     * that need to inspect peer history or record additional observations.
     */
    fun getObservationLog(): PeerObservationLog = observationLog

    /**
     * Returns reports recorded during loading or migration, later storage reconciliation,
     * and persistence-warning handler failures. All loading and migration reports remain;
     * runtime reports (including handler reports) retain only the latest 64, oldest first.
     * Every runtime storage report still emits its warning effect. Returns a separate snapshot.
     * Valid peer records remain available when a sibling record is malformed.
     */
    fun getPersistenceFailures(): List<PeerPersistenceException> =
        synchronized(persistenceFailureLock) {
            persistenceFailures.toList() + runtimePersistenceFailures.toList()
        }

    /**
     * Returns capacity-index state and peer-list snapshot work counters.
     *
     * The legacy ranking and fallback counters remain available for compatibility and stay at
     * zero now that capacity selection uses the incremental observation-log index. A peer-list
     * candidate copy counts a reference copied into a persistent index node or examined while
     * comparing service-catalog paths in accepted and published snapshots (including failed CAS attempts);
     * unchanged reads copy nothing. Callers can compare diagnostics snapshots without depending on
     * speed.
     */
    fun getEvictionWorkDiagnostics(): PeerRegistryEvictionWorkDiagnostics {
        val indexState = observationLog.capacityEvictionIndexState()
        return PeerRegistryEvictionWorkDiagnostics(
            rankingCandidateVisits = evictionRankingCandidateVisits.get(),
            getAllPeersCandidateCopies = getAllPeersCandidateCopies.get(),
            duplicateIpv4FallbackCandidateVisits = duplicateIpv4FallbackCandidateVisits.get(),
            incrementalIndexWork = indexState.work,
            incrementalIndexEntries = indexState.entries,
            incrementalIndexNodes = indexState.nodes
        )
    }

    /** Returns the retained legacy counter for the retired cold equal-address fallback. */
    fun getColdEqualAddressCandidateVisits(): Long = coldEqualAddressCandidateVisits.get()

    /** Returns how many members were copied into temporary full-snapshot staging maps. */
    fun getFullSnapshotStagingMapCandidateCopies(): Long =
        fullSnapshotStagingMapCandidateCopies.get()

    /**
     * Returns how many completed over-capacity add batches entered the fair publication gate.
     *
     * Below-capacity additions and removals publish without this gate. Callers can subtract two
     * readings to verify that ordinary membership churn does not enter the eviction-only path.
     */
    fun getPublicationGateExclusiveAcquisitions(): Long =
        publicationGateExclusiveAcquisitions.get()

    /**
     * Returns provenance for [peerId]'s current retained lifetime, or null when it is absent.
     *
     * [PeerRegistryPeerOriginState.hasCallerOrigin] is the authoritative resolver-facing contract:
     * true means this retained lifetime has direct caller authorship; false means every accepted
     * source was network-derived or persistence restoration.
     */
    fun getPeerOriginState(peerId: String): PeerRegistryPeerOriginState? =
        acceptedSnapshot.get().entry(peerId)?.origin

    internal fun getPeerWithOriginState(
        peerId: String
    ): Pair<BootstrapPeer, PeerRegistryPeerOriginState>? =
        acceptedSnapshot.get().entry(peerId)?.let { it.peer to it.origin }

    /**
     * Records that a peer was directly reachable (without relay) at the current time.
     *
     * This should be called when a direct (non-circuit-relay) connection or ping succeeds.
     * The timestamp is used by [isDirectlyReachable] to determine if the peer is currently
     * considered directly reachable.
     *
     * @param peerId The peer that was directly reached.
     */
    fun recordDirectReachability(peerId: String) {
        directReachability[peerId] = registryClock.currentTimeMillis()
        observationLog.recordDirectReachability(peerId)
    }

    fun recordRelayOnlyReachability(peerId: String) {
        observationLog.recordRelayOnlyReachability(peerId)
    }

    /**
     * Checks whether a peer was directly reachable (without relay) within the recent window.
     *
     * A peer is considered directly reachable if [recordDirectReachability] was called
     * for it within the last [DIRECT_REACHABILITY_TTL_MS] milliseconds. This is a
     * per-observer property — it reflects reachability from this node's perspective,
     * not a global property of the peer.
     *
     * @param peerId The peer to check.
     * @return true if the peer was directly reachable within the TTL window.
     */
    fun isDirectlyReachable(peerId: String): Boolean {
        val lastDirectMs = directReachability[peerId] ?: return false
        return registryClock.currentTimeMillis() - lastDirectMs < DIRECT_REACHABILITY_TTL_MS
    }

    /**
     * Returns the timestamp (epoch milliseconds) of the last successful direct connection
     * to the given peer, or null if no direct connection has been recorded.
     *
     * @param peerId The peer to query.
     * @return Epoch milliseconds of last direct connection, or null.
     */
    fun getLastDirectConnectionMs(peerId: String): Long? = directReachability[peerId]

    /**
     * Records that an outbound dial to a peer failed.
     * When this peer is retained and this node has recent successful contact evidence, the failure enters the same
     * bounded, rank-decayed score history as successful dials.
     *
     * After [MAX_CONSECUTIVE_DIAL_FAILURES] consecutive failures with no intervening success, the
     * peer is removed from the registry and quarantined for [DIAL_FAILURE_QUARANTINE_MS], during
     * which [addPeer] will not re-learn it from gossip. This is what bounds outbound dialing
     * against a peer set that has gone away: the registry is dialed once per gossip fan-out, so a
     * peer that can never be reached would otherwise be dialed for as long as any other node keeps
     * advertising it.
     *
     * @param peerId The peer whose dial failed.
     * @return true if this failure evicted and quarantined the peer.
     */
    fun recordDialFailure(peerId: String): Boolean {
        val expectedQuarantine = synchronized(quarantineLock) { quarantinedUntilMs[peerId] }
        val timestampMs = registryClock.currentTimeMillis()
        val pending = synchronized(dialOutcomeLock(peerId)) {
            peerMutationLocks[peerMutationLockIndex(peerId)].withLock {
                val currentLifetime = peerLifetimes[peerId]
                val preceding = pendingDialRemovals[peerId]
                val currentQuarantine = synchronized(quarantineLock) { quarantinedUntilMs[peerId] }
                if ((preceding != null && preceding.lifetime === currentLifetime) ||
                    (currentQuarantine != null &&
                        (currentQuarantine !== expectedQuarantine || isQuarantinedAt(peerId, timestampMs)))) {
                    return false
                }
                val failures = (consecutiveDialFailures[peerId] ?: 0) + 1
                val lifetime = peerLifetimes[peerId]
                if (failures >= MAX_CONSECUTIVE_DIAL_FAILURES) {
                    lifetime?.rejectRemovalFromActiveActionOnCurrentThread()
                }
                if (lifetime != null) {
                    observationLog.recordFailureAt(peerId, timestampMs)
                }
                if (failures < MAX_CONSECUTIVE_DIAL_FAILURES) {
                    consecutiveDialFailures[peerId] = failures
                    return false
                }
                consecutiveDialFailures.remove(peerId)
                PendingDialRemoval(lifetime, quarantinePeerAt(peerId, timestampMs)).also {
                    pendingDialRemovals[peerId] = it
                }
            }
        }
        val removal = try {
            pending.lifetime?.let { removePeerMembership(peerId, it) }
                ?: PeerRemovalResult(removed = false)
        } finally {
            synchronized(dialOutcomeLock(peerId)) {
                peerMutationLocks[peerMutationLockIndex(peerId)].withLock {
                    pending.postRemovalLifetime = peerLifetimes[peerId]
                    pending.postRemovalQuarantine = synchronized(quarantineLock) {
                        quarantinedUntilMs[peerId]
                    }
                    pendingDialRemovals.remove(peerId, pending)
                    pending.membershipFinished.complete(Unit)
                }
            }
        }
        completeRemovals(listOf(removal))
        return true
    }

    /**
     * Records a successful dial. Ordinary callers join an already-decided threshold removal.
     * Success inside that exact lifetime's action applies before removal and cannot cancel it.
     * A joined outcome cannot clear quarantine or observations belonging to a replacement lifetime.
     */
    fun recordDialSuccess(peerId: String) {
        val timestampMs = registryClock.currentTimeMillis()
        val pending = synchronized(dialOutcomeLock(peerId)) {
            val removal = pendingDialRemovals[peerId]
            if (removal?.lifetime?.isActionOnCurrentThread() == true) {
                // This action must return before removal can finish. Its observation belongs only
                // to this retained generation and is erased by the already-decided removal.
                observationLog.recordSuccessAt(peerId, timestampMs)
                return
            }
            if (removal == null) {
                peerMutationLocks[peerMutationLockIndex(peerId)].withLock {
                    applyDialSuccessUnderOutcomeLock(peerId, timestampMs)
                }
                return
            }
            removal
        }
        // Completion, like the lifecycle wait, must be joined outside every registry lock.
        pending.membershipFinished.join()
        val completedAtMs = registryClock.currentTimeMillis()
        synchronized(dialOutcomeLock(peerId)) {
            peerMutationLocks[peerMutationLockIndex(peerId)].withLock {
                val current = peerLifetimes[peerId]
                if (current !== pending.postRemovalLifetime) return
                val sameOutcome = synchronized(quarantineLock) {
                    val quarantine = quarantinedUntilMs[peerId]
                    quarantine === pending.postRemovalQuarantine &&
                        (quarantine == null || quarantine === pending.quarantine)
                }
                if (sameOutcome) applyDialSuccessUnderOutcomeLock(peerId, completedAtMs)
            }
        }
    }

    private fun applyDialSuccessUnderOutcomeLock(peerId: String, timestampMs: Long) {
        consecutiveDialFailures.remove(peerId)
        synchronized(quarantineLock) { quarantinedUntilMs.remove(peerId) }
        observationLog.recordSuccessAt(peerId, timestampMs)
    }

    private fun dialOutcomeLock(peerId: String): Any =
        dialOutcomeLocks[(peerId.hashCode() and Int.MAX_VALUE) % dialOutcomeLocks.size]

    /**
     * Checks whether a peer is currently quarantined after repeated dial failures.
     *
     * A quarantined peer is not retained by [addPeer], so it is neither dialed nor shared with
     * other nodes until its quarantine expires.
     *
     * @param peerId The peer to check.
     * @return true if the peer is quarantined and the quarantine has not yet expired.
     */
    fun isQuarantined(peerId: String): Boolean {
        while (true) {
            val expected = synchronized(quarantineLock) { quarantinedUntilMs[peerId] } ?: return false
            val timestampMs = registryClock.currentTimeMillis()
            val retained = synchronized(quarantineLock) {
                if (quarantinedUntilMs[peerId] !== expected) {
                    null
                } else if (timestampMs >= expected.expiryMs) {
                    quarantinedUntilMs.remove(peerId)
                    false
                } else {
                    true
                }
            }
            if (retained != null) return retained
        }
    }

    private fun isQuarantinedAt(peerId: String, timestampMs: Long): Boolean {
        synchronized(quarantineLock) {
            val expiryMs = quarantinedUntilMs[peerId] ?: return false
            if (timestampMs >= expiryMs.expiryMs) {
                quarantinedUntilMs.remove(peerId)
                return false
            }
            return true
        }
    }

    /**
     * The number of peers currently quarantined after repeated dial failures.
     *
     * Exposed as an operational diagnostic so a node can report how much of the advertised mesh it
     * has determined to be unreachable.
     */
    val quarantinedPeerCount: Int
        get() {
            while (true) {
                val expected = synchronized(quarantineLock) { LinkedHashMap(quarantinedUntilMs) }
                val timestampMs = registryClock.currentTimeMillis()
                val count = synchronized(quarantineLock) {
                    if (quarantinedUntilMs.size != expected.size ||
                        expected.any { (peerId, quarantine) -> quarantinedUntilMs[peerId] !== quarantine }) {
                        null
                    } else {
                        pruneExpiredQuarantinesLocked(timestampMs)
                        quarantinedUntilMs.size
                    }
                }
                if (count != null) return count
            }
        }

    private fun quarantinePeerAt(peerId: String, now: Long): PeerQuarantine {
        val expiry = if (now > Long.MAX_VALUE - DIAL_FAILURE_QUARANTINE_MS) {
            Long.MAX_VALUE
        } else {
            now + DIAL_FAILURE_QUARANTINE_MS
        }
        val quarantine = PeerQuarantine(expiry)
        synchronized(quarantineLock) {
            pruneExpiredQuarantinesLocked(now)
            quarantinedUntilMs.remove(peerId)
            quarantinedUntilMs[peerId] = quarantine
            while (quarantinedUntilMs.size > MAX_QUARANTINED_PEERS) {
                val iterator = quarantinedUntilMs.entries.iterator()
                if (!iterator.hasNext()) break
                iterator.next()
                iterator.remove()
            }
        }
        return quarantine
    }

    private fun pruneExpiredQuarantinesLocked(now: Long) {
        val iterator = quarantinedUntilMs.entries.iterator()
        while (iterator.hasNext()) {
            if (now >= iterator.next().value.expiryMs) {
                iterator.remove()
            }
        }
    }

    /**
     * Adds a peer to the registry.
     *
     * If the peer already exists, its data is merged:
     * - Multiaddresses are combined and deduplicated (new addresses prioritized, max 20)
     * - Services are combined and deduplicated
     * - The most recent lastSeenTimestamp is used
     *
     * This preserves alternate routing paths (e.g., direct IP + circuit relay) for failover.
     *
     * @param peer The peer to add.
     * @param persist Whether to persist this peer to disk.
     * @param replaceServices If true, replaces the peer's services with the incoming peer's services
     *                        instead of merging them. Use this when handling service withdrawal.
     */
    fun addPeer(peer: BootstrapPeer, persist: Boolean = true, replaceServices: Boolean = false) {
        addPeer(
            peer = peer,
            origin = PeerRegistryAddOrigin.CALLER,
            persist = persist,
            replaceServices = replaceServices
        )
    }

    /**
     * Adds a peer while recording the mutation's authoritative [origin].
     *
     * UrlProtocol-owned catalog, discovery, relay, and persistence paths use this overload. Direct
     * callers can continue using the original signature, which records [PeerRegistryAddOrigin.CALLER].
     */
    fun addPeer(
        peer: BootstrapPeer,
        origin: PeerRegistryAddOrigin,
        persist: Boolean = true,
        replaceServices: Boolean = false
    ) {
        addPeerWithRestoredCallerHistory(
            peer = peer,
            origin = origin,
            persist = persist,
            replaceServices = replaceServices,
            restoredHasCallerOrigin = false
        )
    }

    /**
     * Accepts a received descriptor independently of explicit application additions.
     * [freshness] is usable only for a response sampled for the caller's exchange;
     * [exchangeElapsedMillis] includes the entire request-to-receipt interval.
     * Unsolicited or legacy records must pass null freshness.
     */
    fun addImportedPeer(
        peer: BootstrapPeer,
        freshness: PeerFreshness?,
        exchangeElapsedMillis: Long,
        origin: PeerRegistryAddOrigin = PeerRegistryAddOrigin.CATALOG,
        persist: Boolean = true,
        replaceServices: Boolean = false
    ) {
        val receivedAtTimeSample = if (freshness == null) null else peerFreshnessWindow.sampleTime()
        addImportedPeer(peer, freshness, exchangeElapsedMillis, origin, persist, replaceServices,
            receivedAtTimeSample?.nowMillis ?: 0L, receivedAtTimeSample)
    }

    /** Carries the receive boundary across authorization and preparation within this module. */
    internal fun addImportedPeer(
        peer: BootstrapPeer,
        freshness: PeerFreshness?,
        exchangeElapsedMillis: Long,
        origin: PeerRegistryAddOrigin = PeerRegistryAddOrigin.CATALOG,
        persist: Boolean = true,
        replaceServices: Boolean = false,
        receivedAtElapsedMillis: Long,
        receivedAtTimeSample: PeerFreshnessTimeSample? = null
    ) {
        require(exchangeElapsedMillis >= 0L) {
            "exchangeElapsedMillis must be non-negative, but was $exchangeElapsedMillis"
        }
        addPeerWithRestoredCallerHistory(peer, origin, persist, replaceServices,
            restoredHasCallerOrigin = false,
            importedRecord = PeerImportedRecord(
                freshness = freshness,
                exchangeElapsedMillis = exchangeElapsedMillis,
                receivedAtElapsedMillis = receivedAtElapsedMillis,
                receivedAtTimeSample = receivedAtTimeSample
            ))
    }

    /** Returns source evidence after consuming residence time; receipt never counts as local success. */
    fun getImportedPeerFreshness(peerId: String): PeerFreshness? =
        peerFreshnessWindow.snapshot(peerId)?.freshness ?: peerImportedProvenance[peerId]

    private fun addPeerWithRestoredCallerHistory(
        peer: BootstrapPeer,
        origin: PeerRegistryAddOrigin,
        persist: Boolean,
        replaceServices: Boolean,
        restoredHasCallerOrigin: Boolean,
        replacePeer: Boolean = false,
        importedRecord: PeerImportedRecord? = null
    ) {
        // A peer this node has repeatedly failed to dial stays out of the registry for the
        // duration of its quarantine, however often the rest of the mesh re-advertises it.
        // Without this gate, eviction is undone by the next gossip message and the peer is dialed
        // again on the following fan-out.
        if (isQuarantined(peer.peerId)) {
            return
        }

        // Addresses arrive from third-party assertions (PeerExchange, PeerAnnouncement,
        // ServiceAnnouncement) and every retained address is later dialed. Drop the ones that can
        // never identify a reachable TCP peer at ingestion, so they never become dial targets.
        val validatedPeer = withDialableAddresses(peer, origin)
        if (validatedPeer == null) {
            debugLog {
                "[REGISTRY-$instanceId] addPeer ${peer.peerId.takeLast(8)}: REJECTED, no dialable " +
                    "multiaddress among ${peer.multiaddresses}"
            }
            return
        }
        addValidatedPeer(
            peer = validatedPeer,
            origin = origin,
            persist = persist,
            replaceServices = replaceServices,
            restoredHasCallerOrigin = restoredHasCallerOrigin,
            replacePeer = replacePeer,
            importedRecord = importedRecord
        )
    }

    internal fun restorePeerAfterFailedRelayRegistration(
        peer: BootstrapPeer,
        originState: PeerRegistryPeerOriginState
    ) {
        addPeerWithRestoredCallerHistory(
            peer = peer,
            origin = originState.lastAcceptedOrigin,
            persist = true,
            replaceServices = true,
            restoredHasCallerOrigin = originState.hasCallerOrigin,
            replacePeer = true
        )
    }

    /**
     * Returns [peer] with structurally undialable multiaddresses removed, or null when the peer is
     * new and no address survives validation.
     *
     * An already-known peer is retained even if an incoming announcement carries only rejected
     * addresses: its previously validated addresses remain usable, and dropping it would let one
     * bad announcement erase a working peer.
     */
    private fun withDialableAddresses(
        peer: BootstrapPeer,
        origin: PeerRegistryAddOrigin,
    ): BootstrapPeer? {
        val dialable = peer.multiaddresses.filter { address ->
            val reason = peerMultiaddressRejectionReason(address)
            if (reason != null && nestedCircuitPeerMultiaddressRejectionReason(address) != null) {
                reportPeerMultiaddressRejection(
                    peer.peerId,
                    address,
                    "during ${origin.name} peer-registry acceptance",
                    reason,
                )
            }
            reason == null
        }
        if (dialable.size == peer.multiaddresses.size) {
            return peer
        }
        // A peer announced with no usable address at all (only blanks) is a pre-existing shape the
        // registry has always retained — it can still be reached once a later announcement carries
        // an address. Only an announcement whose addresses were actually rejected as undialable
        // disqualifies a new peer.
        val statedAddresses = peer.multiaddresses.filter { it.isNotBlank() }
        if (dialable.isEmpty() && statedAddresses.isEmpty()) {
            return Libp2pPeer.remote(
                peerId = peer.peerId,
                multiaddresses = emptyList(),
                advertisedServices = peer.advertisedServices,
                lastSeenTimestamp = peer.lastSeenTimestamp
            )
        }
        if (dialable.isEmpty()) {
            return if (peers.containsKey(peer.peerId)) {
                Libp2pPeer.remote(
                    peerId = peer.peerId,
                    multiaddresses = emptyList(),
                    advertisedServices = peer.advertisedServices,
                    lastSeenTimestamp = peer.lastSeenTimestamp
                )
            } else {
                null
            }
        }
        return Libp2pPeer.remote(
            peerId = peer.peerId,
            multiaddresses = dialable,
            advertisedServices = peer.advertisedServices,
            lastSeenTimestamp = peer.lastSeenTimestamp
        )
    }

    private fun addValidatedPeer(
        peer: BootstrapPeer,
        origin: PeerRegistryAddOrigin,
        persist: Boolean,
        replaceServices: Boolean,
        restoredHasCallerOrigin: Boolean,
        replacePeer: Boolean,
        importedRecord: PeerImportedRecord? = null
    ) {
        val peerId = peer.peerId
        rejectUnpublishedAddFromActiveAction(peerId)
        // Commit outcome belongs to this call; cancellation may be shared with other callers.
        val metadata = RegistryPeerAddPreparation()
        // The reservation spans caller preparation without retaining a registry guard. Removal
        // can cancel a first insertion or a refresh that would otherwise retry as a new member.
        val pendingAdd = if (hasCurrentAnnouncementPeerMutation(peerId)) {
            pendingAnnouncementPeerAdds.compute(peerId) { _, current ->
                val pending = current?.takeUnless { it.cancelled } ?: PendingAnnouncementPeerAdd()
                pending.users++
                pending
            }
        } else null
        var finishProvisionalObservation: ((Boolean) -> Unit)? = null
        try {
            if (pendingAdd != null) {
                // This samples the clock before taking the observation owner, with no registry
                // guard held. Its record can be borrowed by independent public evidence writers.
                finishProvisionalObservation = observationLog.observeProvisionalRegistryPeer(peerId)
            }
            while (true) {
                if (pendingAdd?.cancelled == true || !isCurrentAnnouncementPeerMutation(peerId)) return
                peerRemovalHandoffs[peerId]?.let { handoff ->
                    rejectCallbackReaddOfUnfinishedPeer(peerId)
                    handoff.awaitCallbacks()
                }
                if (
                    tryAddValidatedPeer(
                        peer = peer,
                        metadata = metadata,
                        pendingAdd = pendingAdd,
                        origin = origin,
                        persist = persist,
                        replaceServices = replaceServices,
                        restoredHasCallerOrigin = restoredHasCallerOrigin,
                        replacePeer = replacePeer,
                        importedRecord = importedRecord
                    )
                ) return
            }
        } finally {
            try {
                finishProvisionalObservation?.invoke(metadata.committed)
            } finally {
                if (pendingAdd != null) {
                    pendingAnnouncementPeerAdds.computeIfPresent(peerId) { _, current ->
                        if (current !== pendingAdd) current
                        else if (--current.users == 0) null else current
                    }
                }
            }
        }
    }

    private fun rejectUnpublishedAddFromActiveAction(peerId: String) {
        val action = PeerLifetime.activeActionForRegistry(lifetimeRegistryIdentity) ?: return
        if (!peers.containsKey(peerId)) throw action.newPeerAddReentrancyFailure(peerId)
        if (publishedPeersSnapshot.entry(peerId) == null) {
            throw action.unpublishedPeerRefreshReentrancyFailure(peerId)
        }
    }

    private fun rejectCallbackReaddOfUnfinishedPeer(peerId: String) {
        if (removalCallbackContext.get()?.active == true) {
            throw IllegalStateException(
                "Cannot add peer '$peerId' from a PeerLifetime removal callback while that " +
                    "peer still has unfinished removal callbacks; return from the callback " +
                    "before re-adding the peer"
            )
        }
    }

    /** Returns false when an older generation installed a callback handoff first. */
    private fun tryAddValidatedPeer(
        peer: BootstrapPeer,
        metadata: RegistryPeerAddPreparation,
        pendingAdd: PendingAnnouncementPeerAdd?,
        origin: PeerRegistryAddOrigin,
        persist: Boolean,
        replaceServices: Boolean,
        restoredHasCallerOrigin: Boolean,
        replacePeer: Boolean,
        importedRecord: PeerImportedRecord?
    ): Boolean {
        val peerId = peer.peerId
        val peerShortId = peerId.takeLast(8)
        val incomingServices = peer.advertisedServices

        val expectedPeer = peers[peerId]
        val expectedLifetime = peerLifetimes[peerId]
        val expectedSequence = insertionSequence[peerId]
        if (persist && peersDirectory != null) {
            expectedLifetime?.rejectNestedLifetimeAcquisition("persist a record")
        }
        rejectUnpublishedAddFromActiveAction(peerId)
        // Caller preparation is outside publication, stripe, bucket and observation guards.
        // Commit below verifies the exact peer, lifetime and revision before using these values.
        val mergedPeerResult = if (expectedPeer != null && !replacePeer) {
            // Merge multiaddresses: new ones first (likely more recent), then existing
            // Deduplicate, intern each multiaddr string so equal-content copies share
            // heap with downstream readers (relay-debug log lines, gossip outbound,
            // retry loops), and cap at maximum to prevent unbounded growth.
            //
            // Interning is the load-bearing fix for the 2026-05-27 ContainerNursery
            // OOM on 198.199.106.165 (heap dump java_pid648304.hprof). The hprof
            // showed 9-43 LIVE String copies of every multiaddr text in the live
            // heap — same bytes, distinct String objects. Each gossip event parsed
            // a fresh String from incoming protobuf and every downstream snapshot
            // (logging, outbound gossip, retry list) duplicated it again. With
            // String.intern() the JVM string pool collapses them to one canonical
            // reference per distinct content, capping retention at O(distinct
            // multiaddrs in the mesh) regardless of how many readers snapshot.
            val mergedAddresses = (peer.multiaddresses + expectedPeer.multiaddresses)
                .map { it.intern() }
                .distinct()
                .take(MAX_MULTIADDRESSES_PER_PEER)

            // Handle services based on replaceServices flag
            val finalServices = if (replaceServices) {
                // Replace mode: use only the incoming peer's services
                // This is used for service withdrawal to prevent re-adding withdrawn services
                debugLog { "[REGISTRY-$instanceId] addPeer $peerShortId: REPLACE existing=${expectedPeer.advertisedServices}, incoming=$incomingServices" }
                incomingServices
            } else {
                // Merge mode (default): combine both sets
                val merged = (expectedPeer.advertisedServices + peer.advertisedServices).distinct()
                debugLog { "[REGISTRY-$instanceId] addPeer $peerShortId: MERGE existing=${expectedPeer.advertisedServices}, incoming=$incomingServices, merged=$merged" }
                merged
            }

            // Use the most recent timestamp
            val mergedTimestamp = if (importedRecord != null) expectedPeer.lastSeenTimestamp
            else maxOf(expectedPeer.lastSeenTimestamp, peer.lastSeenTimestamp)

            Libp2pPeer.remote(
                peerId = peerId,
                multiaddresses = mergedAddresses,
                advertisedServices = finalServices,
                lastSeenTimestamp = mergedTimestamp
            )
        } else if (expectedPeer == null) {
            debugLog { "[REGISTRY-$instanceId] addPeer $peerShortId: NEW peer, services=$incomingServices" }
            // Keep built-in identity and behavior; preparation below owns a bounded prefix.
            peer
        } else {
            debugLog {
                "[REGISTRY-$instanceId] addPeer $peerShortId: RESTORE retained peer after " +
                    "failed relay registration"
            }
            peer
        }

        // Prepare caller data before installing any admission sidecar. In particular, a
        // failed collection traversal must not leave a lifetime for an absent map entry.
        val statedAddresses = mergedPeerResult.multiaddresses
        val statedRoutes = statedAddresses.asSequence().take(MAX_MULTIADDRESSES_PER_PEER)
            .groupingBy { it }.eachCount()
        val acceptedAddresses = Collections.unmodifiableList(
            statedAddresses.asSequence().take(MAX_MULTIADDRESSES_PER_PEER).toList()
        )
        val routes = acceptedAddresses.groupingBy { it }.eachCount()
        check(statedRoutes == routes && acceptedAddresses.all { isDialablePeerMultiaddress(it) }) {
            "Peer '${peerId}' changed its multiaddresses while registry admission was reading them"
        }
        val acceptedIpAddresses = parsePeerIpAddresses(acceptedAddresses)
        val proposedServices = mergedPeerResult.advertisedServices.toSet()
        val previousServices = acceptedSnapshot.get().entry(peerId)?.services
        val indexedServices = (previousServices ?: RegistryServiceCatalog()).prepared(proposedServices)
        if (needsRegistryPeerMetadata(mergedPeerResult) && metadata.serialized == null) {
            metadata.serialized = captureRegistryPeerMetadata(mergedPeerResult)
        }
        val expectedQuarantine = synchronized(quarantineLock) { quarantinedUntilMs[peerId] }
        val acceptedAt = registryClock.currentTimeMillis()
        val freshnessTime = if (importedRecord == null) null else peerFreshnessWindow.sampleTime()

        var computedPeer: BootstrapPeer? = null
        var computedCapacityEntry: PeerCapacityEvictionEntry? = null
        var computedSnapshotEntry: RegistrySnapshotEntry? = null
        var acceptedLifetime: PeerLifetime? = null
        var rejectedDuringMerge = false
        var completedMembershipVersion = 0L
        var ownPublicationComplete = false
        // Shared access keeps unrelated merge and service-index work concurrent. A fair exclusive
        // publication pass below waits for the current merge batch, prevents later adds from
        // continually barging ahead of it, and therefore always sees a complete eviction index.
        val concurrentAddLock = concurrentAddPublicationGate.readLock()
        concurrentAddLock.lock()
        try {
            // The fixed-size striped lock orders same-peer generations without retaining one lock
            // per peer forever. Removal keeps the same stripe until the old membership is no longer
            // visible and all of its sidecars are cleared; this add therefore cannot publish a new
            // generation whose sidecars an older removal can delete.
            val peerMutationLock = peerMutationLocks[peerMutationLockIndex(peerId)]
            peerMutationLock.lock()
            var commitLockHeld = false
            try {
                if (!isCurrentAnnouncementPeerMutation(peerId)) return true
                // The first wait in addValidatedPeer is only a fast path. Recheck after taking the
                // same stripe used to install a removal handoff so a removal cannot slip between
                // that check and publication of this generation.
                if (peerRemovalHandoffs.containsKey(peerId)) {
                    rejectCallbackReaddOfUnfinishedPeer(peerId)
                    return false
                }
                if (peers[peerId] !== expectedPeer ||
                    peerLifetimes[peerId] !== expectedLifetime ||
                    insertionSequence[peerId] != expectedSequence ||
                    acceptedSnapshot.get().entry(peerId)?.services !== previousServices) return false
                if (synchronized(quarantineLock) {
                        quarantinedUntilMs[peerId] !== expectedQuarantine
                    }) return false
                rejectUnpublishedAddFromActiveAction(peerId)
                if (importedRecord != null) {
                    val evidence = importedRecord.freshness?.let {
                        peerFreshnessWindow.acceptFromReceipt(
                            subjectPeerId = peerId,
                            freshness = it,
                            exchangeElapsedMillis = importedRecord.exchangeElapsedMillis,
                            receivedAtElapsedMillis = importedRecord.receivedAtElapsedMillis,
                            timeSample = checkNotNull(freshnessTime),
                            receivedAtTimeSample = importedRecord.receivedAtTimeSample
                        )
                    }
                    if (!peers.containsKey(peerId)) {
                        val accepted = if (importedRecord.freshness == null) {
                            peerFreshnessWindow.canAcceptLegacyAt(peerId, checkNotNull(freshnessTime))
                        } else {
                            (evidence?.freshness?.remainingLifetimeMillis ?: 0L) > 0L
                        }
                        if (!accepted) return true
                    }
                }
                // Use compute() for thread-safe atomic merge operation
                // CRITICAL: Update service index INSIDE compute() to ensure atomicity.
                // Previously, the service index was updated AFTER compute() returned,
                // creating a race window where findPeersForService() could return stale results.
                computedPeer = peers.compute(peerId) { _, existingPeer ->
                    if (existingPeer == null) {
                        PeerLifetime.activeActionForRegistry(lifetimeRegistryIdentity)?.let {
                            activeLifetime ->
                            throw activeLifetime.newPeerAddReentrancyFailure(peerId)
                        }
                    }
                    // Re-check while serialized with every add/remove of this peer. An add can pass
                    // the fast check above just before a concurrent failure quarantines and removes
                    // the peer; without this check it could then run second and restore the peer.
                    if (isQuarantinedAt(peerId, acceptedAt)) {
                        rejectedDuringMerge = true
                        return@compute existingPeer
                    }

                    pendingAdd?.commitLock?.lock()
                    commitLockHeld = pendingAdd != null
                    if (pendingAdd?.cancelled == true || !isCurrentAnnouncementPeerMutation(peerId)) {
                        rejectedDuringMerge = true
                        return@compute existingPeer
                    }
                    val acceptedPeer = retainRegistryAddresses(
                        peerId, mergedPeerResult, acceptedAddresses, metadata.serialized
                    )

                    // Removal uses the same peer stripe; publish observation before retained membership.
                    observationLog.observePeerAt(peerId, acceptedAt)
                    // A newly retained generation starts without the removed generation's failures.
                    if (existingPeer == null) consecutiveDialFailures.remove(peerId)

                    // Stamp the insertion/refresh sequence as the LAST action before compute() installs
                    // this peer into the peers map (the install is atomic under the bin lock, so the peer
                    // becomes visible to concurrent readers/evictions immediately after the lambda returns).
                    // It MUST be assigned here, not before compute(): the heavy merge/intern/service-index
                    // work above takes long enough that, if the sequence were stamped first, the global
                    // counter could advance far while this peer was still invisible — leaving a just-added
                    // peer with a stale (low) sequence that a concurrent eviction would treat as old and
                    // remove (observed as ~1/12800 in testPeerRegistryJustAddedPeerSurvivesConcurrentEviction).
                    // Assigned at end-of-compute, the sequence reflects visibility order. Updated on every
                    // add so a re-announced peer wins an otherwise exact ranking tie over older peers.
                    firstSeenAt.putIfAbsent(peerId, acceptedAt)
                    if (existingPeer == null) {
                        val recordPersistenceLock = ReentrantLock()
                        val actionClock = registryClock
                        val lifetime = PeerLifetime(
                            peerId = peerId,
                            generation = peerLifetimeGeneration.getAndIncrement(),
                            registryIdentity = lifetimeRegistryIdentity,
                            withPersistenceOwnership = { prepare, action ->
                                withPeerPersistenceLock(recordPersistenceLock, prepare, action)
                            },
                            withActionClockSample = { action ->
                                actionClock.withActionSample(action) { preparedScope ->
                                    withPeerPersistenceNotifications(preparedScope)
                                }
                            }
                        )
                        check(peerLifetimes.putIfAbsent(peerId, lifetime) == null) {
                            "Peer '$peerId' had no retained membership but still had a current lifetime"
                        }
                    }
                    val previousOriginState = peerOriginStates[peerId]
                    val acceptedOriginState = PeerRegistryPeerOriginState(
                        hasCallerOrigin =
                            previousOriginState?.hasCallerOrigin == true ||
                                restoredHasCallerOrigin ||
                                origin == PeerRegistryAddOrigin.CALLER,
                        lastAcceptedOrigin = origin
                    )
                    peerOriginStates[peerId] = acceptedOriginState
                    val previousEvidence = peerRemovalRouteEvidence[peerId]
                    if (previousEvidence == null || previousEvidence.addresses != routes ||
                        origin == PeerRegistryAddOrigin.CALLER) {
                        peerRemovalRouteEvidence[peerId] = PeerRemovalRouteEvidence(routes)
                    }
                    val sequence = insertionSequenceCounter.getAndIncrement()
                    computedCapacityEntry = capacityEvictionEntry(
                        peerId = peerId,
                        addresses = acceptedIpAddresses,
                        insertionSequence = sequence,
                        hasCallerOrigin = acceptedOriginState.hasCallerOrigin
                    )
                    // No descriptor getter or clock read follows this accepted-version stamp.
                    rankedAddresses[peerId] = acceptedIpAddresses
                    insertionSequence[peerId] = sequence
                    computedSnapshotEntry = RegistrySnapshotEntry(peerId, acceptedPeer, indexedServices,
                        checkNotNull(peerLifetimes[peerId]), acceptedOriginState, sequence)

                    acceptedPeer
                }
                if (!rejectedDuringMerge) {
                    metadata.committed = true
                    importedRecord?.freshness?.let {
                        peerImportedProvenance[peerId] = it.agedBy(Long.MAX_VALUE)
                    }
                    val entry = checkNotNull(computedSnapshotEntry)
                    updateAcceptedSnapshot { current, work -> current.put(entry, work) }
                    checkNotNull(computedPeer) {
                        "Peer '$peerShortId' was not computed after its accepted registry mutation"
                    }
                    acceptedLifetime = checkNotNull(peerLifetimes[peerId]) {
                        "Peer '$peerId' was accepted without a current lifetime"
                    }
                }
            } finally {
                if (commitLockHeld) pendingAdd!!.commitLock.unlock()
                peerMutationLock.unlock()
            }
            if (rejectedDuringMerge) return true
            synchronized(capacityEvictionLock) {
                // A concurrent refresh of the same peer may have won after this compute. Index only
                // the value that is still installed; that later operation owns the index otherwise.
                val installedPeer = computedPeer?.takeIf { peers[peerId] === it }
                if (installedPeer != null && !rejectedDuringMerge) {
                    val capacityEntry = checkNotNull(computedCapacityEntry) {
                        "Installed peer '$peerId' had no computed capacity eviction metadata"
                    }
                    // A same-ID refresh can reuse the very same BootstrapPeer instance. The
                    // sequence check also prevents an older compute from replacing metadata
                    // installed by a later refresh after both computes release the peer stripe.
                    if (insertionSequence[peerId] == capacityEntry.insertionSequence) {
                        observationLog.registerRegistryMember(peerId)
                        observationLog.upsertCapacityEvictionEntry(capacityEntry)
                    }
                }
                completedMembershipVersion = membershipVersion.incrementAndGet()
                ownPublicationComplete = if (peerLifetimes[peerId] !== acceptedLifetime) {
                    // This accepted mutation was removed before publication. It does not inherit
                    // a replacement generation's outstanding add-publication obligation.
                    true
                } else {
                    publishCompletedPeerSnapshotWithinCapacityUnderCapacityLock(
                        peerId = peerId,
                        visiblePeer = peers[peerId]
                    )
                }
                if (ownPublicationComplete && unpublishedPeerIds.isEmpty()) {
                    publishedMembershipVersion = completedMembershipVersion
                }
            }
        } finally {
            concurrentAddLock.unlock()
        }

        debugLog { "[REGISTRY-$instanceId] addPeer $peerShortId: accepted peer snapshot updated" }
        if (rejectedDuringMerge) return true

        checkNotNull(computedPeer) {
            "Peer '$peerShortId' was not computed even though addPeer completed without an error"
        }
        val lifetime = checkNotNull(acceptedLifetime) {
            "Peer '$peerShortId' completed an accepted add without a lifetime"
        }

        if (!ownPublicationComplete) publishCompletedAdd(completedMembershipVersion)
        if (persist && peersDirectory != null) {
            persistCurrentPeerIfLifetimeActive(peerId, lifetime)
        }
        return true
    }

    /**
     * Publishes one closed batch of completed additions.
     *
     * Only the thread that closes the current batch enters the fair gate exclusively. Other
     * completed additions wait for that publication instead of lining up for their own exclusive
     * pass. Once the publisher has queued, the fair gate prevents later additions from entering
     * ahead of it, so the published membership version covers every earlier completed addition.
     */
    private fun publishCompletedAdd(requiredMembershipVersion: Long) {
        var isPublisher = false
        val removals = mutableListOf<PeerRemovalResult>()
        addPublicationCoordinator.lock()
        try {
            while (publishedMembershipVersion < requiredMembershipVersion) {
                if (!addPublicationInProgress) {
                    addPublicationInProgress = true
                    isPublisher = true
                    break
                }
                addPublicationAdvanced.awaitUninterruptibly()
            }
        } finally {
            addPublicationCoordinator.unlock()
        }
        if (!isPublisher) return

        val publicationLock = concurrentAddPublicationGate.writeLock()
        var publicationFailure: Throwable? = null
        try {
            var completedVersion = 0L
            var completedUnpublished = emptyMap<String, PeerLifetime>()
            var victims = emptyList<PeerLifetime>()
            publicationLock.lock()
            publicationGateExclusiveAcquisitions.incrementAndGet()
            try {
                synchronized(capacityEvictionLock) {
                    completedVersion = membershipVersion.get()
                    // A removed pending ID has no generation left to publish. Retire it while
                    // the gate excludes replacement adds, rather than stranding its obligation.
                    unpublishedPeerIds.removeAll { !peerLifetimes.containsKey(it) }
                    completedUnpublished = unpublishedPeerIds.mapNotNull { peerId ->
                        peerLifetimes[peerId]?.let { peerId to it }
                    }.toMap()
                    val count = peers.size - MAX_REGISTRY_PEERS
                    if (count > 0) {
                        val selectedPeerIds = observationLog.capacityEvictionVictimIds(count)
                        victims = selectedPeerIds.mapNotNull { peerLifetimes[it] }
                        check(victims.size == count) {
                            "PeerRegistry requires $count eviction candidates for ${peers.size} " +
                                "retained peers but selected ${victims.size} lifetimes"
                        }
                    }
                }
            } finally {
                publicationLock.unlock()
            }
            // The closed batch owns only its captured pending generations. Later additions can
            // merge while a victim is active, but join the next publication. No second exclusive
            // gate acquisition is needed to publish this batch's now-bounded survivors.
            victims.forEach { victim ->
                val removal = removePeerMembership(victim.peerId, victim, onlyIfOverCapacity = true)
                if (removal.removed) removals += removal
            }
            synchronized(capacityEvictionLock) {
                publishPeersSnapshotUnderCapacityLock(completedUnpublished)
                publishedMembershipVersion = maxOf(publishedMembershipVersion, completedVersion)
            }
        } catch (failure: Throwable) {
            publicationFailure = failure
        } finally {
            addPublicationCoordinator.lock()
            try {
                addPublicationInProgress = false
                addPublicationAdvanced.signalAll()
            } finally {
                addPublicationCoordinator.unlock()
            }
        }
        // Preparation remains outside notification ownership. Completion and capacity
        // publication compose under the same owner before handlers can re-enter.
        completeRemovals(removals, publicationFailure)
    }

    /**
     * Adds multiple peers to the registry.
     *
     * @param peers The peers to add.
     * @param persist Whether to persist these peers to disk.
     */
    fun addPeers(peers: List<BootstrapPeer>, persist: Boolean = true) {
        for (peer in peers) {
            addPeer(peer, persist)
        }
    }

    /**
     * Removes a peer from the registry.
     *
     * @param peerId The ID of the peer to remove.
     */
    fun removePeer(peerId: String) {
        val removal = removePeerMembership(peerId)
        completeRemovals(listOf(removal))
    }

    /**
     * Removes [peerId] only while [expectedLifetime] is still its current retained lifetime.
     *
     * The lifetime comparison and membership removal are one atomic same-peer mutation. A stale
     * or absent lifetime returns `false` without changing the current peer. A successful removal
     * has the same callback, persistence, and membership-publication behavior as [removePeer].
     */
    fun removePeer(peerId: String, expectedLifetime: PeerLifetime): Boolean {
        val removal = removePeerMembership(peerId, expectedLifetime)
        completeRemovals(listOf(removal))
        return removal.removed
    }

    /** Captures the retained peer before a confirming check performed outside registry locks. */
    fun getPeerRemovalCandidate(peerId: String): PeerRemovalCandidate? {
        val freshnessTime = peerFreshnessWindow.sampleTime()
        peerMutationLocks[peerMutationLockIndex(peerId)].withLock {
            val peer = peers[peerId] ?: return null
            val lifetime = peerLifetimes[peerId] ?: return null
            val routeEvidence = checkNotNull(peerRemovalRouteEvidence[peerId]) {
                "Peer '$peerId' is retained without its route evidence"
            }
            return PeerRemovalCandidate(peerId, peer, lifetime,
                observationLog.captureSuccessfulEvidence(peerId), routeEvidence.version,
                peerFreshnessWindow.snapshotAtTime(peerId, freshnessTime)?.version)
        }
    }

    /**
     * Removes a captured peer only if its lifetime, routes, caller refresh and successful evidence are unchanged.
     * Callbacks and persistence follow the same completion contract as [removePeer].
     */
    fun removePeer(candidate: PeerRemovalCandidate): Boolean {
        val removal = removePeerMembership(candidate.peerId, candidate.lifetime, candidate = candidate)
        completeRemovals(listOf(removal))
        return removal.removed
    }

    private fun removePeerMembership(
        peerId: String,
        expectedLifetime: PeerLifetime? = null,
        onlyIfOverCapacity: Boolean = false,
        candidate: PeerRemovalCandidate? = null
    ): PeerRemovalResult {
        if (expectedLifetime == null) {
            // A refused removal must not cancel the caller's valid prepared refresh. Recheck the
            // actual lifetime below as well: a first insertion may commit during cancellation.
            peerLifetimes[peerId]?.rejectRemovalFromActiveActionOnCurrentThread()
            pendingAnnouncementPeerAdds[peerId]?.let { pending ->
                // Staging runs caller code without this lock. A removal can cancel it even
                // before a lifetime exists. A commit holds it only through map installation.
                pending.commitLock.withLock { pending.cancelled = true }
            }
        }
        val currentLifetime = peerLifetimes[peerId]
            ?: return PeerRemovalResult(removed = false)
        if (expectedLifetime != null && currentLifetime !== expectedLifetime) {
            return PeerRemovalResult(removed = false)
        }
        currentLifetime.rejectRemovalFromActiveActionOnCurrentThread()
        lateinit var freshnessTime: PeerFreshnessTimeSample
        // L is joined before D/C/S. No registry lock is held while caller code finishes its action.
        val removal = currentLifetime.beginRemoval(prepare = {
            freshnessTime = peerFreshnessWindow.sampleTime()
        }) { endLifetime ->
            synchronized(dialOutcomeLock(peerId)) {
                synchronized(capacityEvictionLock) {
                    peerMutationLocks[peerMutationLockIndex(peerId)].withLock {
                        if (peerLifetimes[peerId] !== currentLifetime ||
                            !peers.containsKey(peerId) ||
                            (candidate != null &&
                                (peerRemovalRouteEvidence[peerId]?.version !== candidate.routeEvidenceVersion ||
                                    peerFreshnessWindow.snapshotAtTime(peerId, freshnessTime)?.version != candidate.importedEvidenceVersion)) ||
                            (onlyIfOverCapacity && peers.size <= MAX_REGISTRY_PEERS)) {
                            return@withLock PeerRemovalResult(removed = false)
                        }
                        // This first decision owns no bucket. A colliding admission may hold B
                        // while it waits for E, so release E before joining that bucket.
                        if (candidate != null && observationLog.commitIfSuccessfulEvidenceUnchanged(
                                peerId, candidate.successfulEvidence
                            ) { true } != true) {
                            return@withLock PeerRemovalResult(removed = false)
                        }
                        val prepareMembershipRemoval = {
                            val lifetimeRemoval = endLifetime()
                            val completion = PeerRemovalCompletion(peerId, lifetimeRemoval)
                            check(peerRemovalHandoffs.putIfAbsent(peerId, completion) == null) {
                                "Peer '$peerId' already had an unfinished removal callback handoff"
                            }
                            completion
                        }
                        var committedCompletion: PeerRemovalCompletion? = null
                        // S -> B -> E, never E -> B. Recheck after acquiring B: a success or
                        // record change during the bucket wait refuses this removal. The guarded
                        // closure ends the lifetime only; compute removes the entry after E exits.
                        peers.computeIfPresent(peerId) { _, retainedPeer ->
                            val prepared = if (candidate == null) {
                                prepareMembershipRemoval()
                            } else {
                                observationLog.commitIfSuccessfulEvidenceUnchanged(
                                    peerId, candidate.successfulEvidence, prepareMembershipRemoval
                                )
                            }
                            if (prepared == null) {
                                retainedPeer
                            } else {
                                committedCompletion = prepared
                                null
                            }
                        }
                        val completion = committedCompletion
                            ?: return@withLock PeerRemovalResult(removed = false)
                        // Admission uses this stripe too, so no received descriptor can enter
                        // between membership removal and its process-local removal interval.
                        // Keep clock sampling outside the successful-observation commit guard.
                        peerFreshnessWindow.recordRemovedAt(peerId, freshnessTime)
                        updateAcceptedSnapshot { current, work -> current.remove(peerId, work) }
                        observationLog.unregisterRegistryMember(peerId)

                        // ConcurrentHashMap readers may continue seeing the old value while a compute lambda is
                        // running. Clear sidecars only after compute returns and membership removal is visible.
                        // The stripe prevents a same-peer re-add until cleanup finishes, so this ordering also
                        // prevents an older removal from deleting the next generation's sidecars.
                        observationLog.removePeer(peerId)
                        peerImportedProvenance.remove(peerId)
                        peerOriginStates.remove(peerId)
                        peerRemovalRouteEvidence.remove(peerId)
                        directReachability.remove(peerId)
                        firstSeenAt.remove(peerId)
                        insertionSequence.remove(peerId)
                        rankedAddresses.remove(peerId)
                        consecutiveDialFailures.remove(peerId)
                        check(peerLifetimes.remove(peerId, currentLifetime)) {
                            "Peer '$peerId' lifetime changed while its membership was being removed"
                        }

                        val completedVersion = membershipVersion.incrementAndGet()
                        var removalPublicationFailure: Throwable? = null
                        if (onlyIfOverCapacity) {
                            // The closed add publisher must install its eviction, refreshes, and
                            // surviving additions as one snapshot. Publishing this victim here
                            // would expose a removal-only value before the batch snapshot is ready.
                            unpublishedRefreshIds.remove(peerId)
                            if ((publishedPeersSnapshot.entry(peerId) != null)) {
                                unpublishedRemovalIds.add(peerId)
                            }
                        } else {
                            removalPublicationFailure = publishRemovedPeerSnapshotUnderCapacityLock(peerId)
                        }
                        if (unpublishedPeerIds.isEmpty()) {
                            publishedMembershipVersion = completedVersion
                        }
                        PeerRemovalResult(removed = true, completion = completion,
                            publicationFailure = removalPublicationFailure)
                    }
                }
            }
        } ?: PeerRemovalResult(removed = false)
        if (removal.removed) {
            addPublicationCoordinator.withLock { addPublicationAdvanced.signalAll() }
        }
        return removal
    }

    // A warning may re-enter the registry, so finish every handoff in this batch before delivery.
    private fun completeRemovals(
        removals: List<PeerRemovalResult>,
        capacityPublicationFailure: Throwable? = null
    ): Unit = withPeerPersistenceNotifications {
        val owner = currentPeerFailureOwner()
        val retainedCompletion = PeerPersistenceException("Additional peer removal completion failures")
        var hasCallbackFailure = false
        val retainCallbackFailure: (Throwable) -> Unit = { failure ->
            hasCallbackFailure = true
            appendPeerFailureIfSafe(retainedCompletion, failure, owner)
        }
        val publicationFailure = removals.mapNotNull { removal ->
            removal.publicationFailure
        }.reduceOrNull { primary, secondary -> retainPeerRemovalFailure(primary, secondary, retainedCompletion, owner) }
        var firstFailure: Throwable? = null
        var abortFailure: Throwable? = null
        val completions = removals.mapNotNull { it.completion }
        var completionIndex = 0
        while (completionIndex < completions.size && abortFailure == null) {
            val completion = completions[completionIndex]
            try {
                completion.awaitPersistence()
                invokeRemovalCallbacks(completion, owner, retainCallbackFailure)?.let { failure ->
                    firstFailure = retainPeerRemovalFailure(firstFailure, failure, retainedCompletion, owner)
                }
                removePersistedPeer(completion.peerId, owner)?.let { failure ->
                    firstFailure = retainPeerRemovalFailure(firstFailure, failure, retainedCompletion, owner)
                }
            } catch (failure: Throwable) {
                abortFailure = failure
            } finally {
                finishRemovalHandoff(completion)?.let { failure ->
                    if (abortFailure == null) {
                        abortFailure = retainPeerRemovalFailure(null, failure, retainedCompletion, owner)
                    } else if (abortFailure !== failure) {
                        abortFailure = retainPeerRemovalFailure(abortFailure, failure, retainedCompletion, owner)
                    }
                }
                completionIndex++
            }
        }
        abortFailure?.let { initialAbort ->
            var abort = retainPeerRemovalFailure(null, initialAbort, retainedCompletion, owner)
            firstFailure?.let { prior ->
                if (prior !== abort) abort = retainPeerRemovalFailure(abort, prior, retainedCompletion, owner)
            }
            while (completionIndex < completions.size) {
                val completion = completions[completionIndex]
                try {
                    completion.awaitPersistence()
                    invokeRemovalCallbacks(completion, owner, retainCallbackFailure)?.let { failure ->
                        if (failure !== abort) abort = retainPeerRemovalFailure(abort, failure, retainedCompletion, owner)
                    }
                } catch (failure: Throwable) {
                    if (failure !== abort) abort = retainPeerRemovalFailure(abort, failure, retainedCompletion, owner)
                }
                try {
                    removePersistedPeer(completion.peerId, owner)?.let { failure ->
                        if (failure !== abort) abort = retainPeerRemovalFailure(abort, failure, retainedCompletion, owner)
                    }
                } catch (failure: Throwable) {
                    if (failure !== abort) abort = retainPeerRemovalFailure(abort, failure, retainedCompletion, owner)
                } finally {
                    finishRemovalHandoff(completion)?.let { failure ->
                        if (failure !== abort) abort = retainPeerRemovalFailure(abort, failure, retainedCompletion, owner)
                    }
                    completionIndex++
                }
            }
            abortFailure = abort
        }
        val completedFailure = abortFailure ?: firstFailure
        val completionFailure = publicationFailure?.let { primary ->
            completedFailure?.let { retainPeerRemovalFailure(primary, it, retainedCompletion, owner) } ?: primary
        } ?: completedFailure
        val hasRetainedCompletion = owner.attachments.containsKey(retainedCompletion)
        val needsCapacityReport = capacityPublicationFailure != null &&
            completionFailure != null && completionFailure !== capacityPublicationFailure
        if (completionFailure != null &&
            ((completionFailure is Error && hasRetainedCompletion) || hasCallbackFailure || needsCapacityReport)) {
            val context = if (capacityPublicationFailure == null) "peer removals" else
                "peer removals during capacity publication"
            val report = PeerPersistenceException("Failed to complete $context", completionFailure)
            if (hasRetainedCompletion) appendPeerFailureIfSafe(report, retainedCompletion, owner)
            retainDisplacedPeerFailure(report, completionFailure, capacityPublicationFailure, owner)
            afterPeerPersistenceOwnership { displacedPrimary ->
                try {
                    publishPersistenceFailure(report, owner = owner)
                } catch (handlerFailure: Throwable) {
                    val handlerContext = if (capacityPublicationFailure == null) "peer removals" else
                        "capacity publication"
                    val handlerReport = reportPersistenceFailure(
                        "Failed to report persistence issue during $handlerContext",
                        handlerFailure,
                        notify = false,
                        owner = owner
                    )
                    retainDisplacedPeerFailure(handlerReport, handlerFailure, displacedPrimary, owner)
                    throw retainPeerPublicationFailure(handlerReport, handlerFailure, owner)
                }
            }
        }
        capacityPublicationFailure?.let { failure ->
            throw completionFailure?.let { preservePrimaryFailure(failure, it, owner) } ?: failure
        }
        if (completionFailure != null) throw completionFailure
    }

    private fun finishRemovalHandoff(completion: PeerRemovalCompletion): Throwable? {
        var installedCompletion: PeerRemovalCompletion? = null
        return try {
            installedCompletion = peerRemovalHandoffs.remove(completion.peerId)
            check(installedCompletion === completion) {
                "Peer '${completion.peerId}' removal callback handoff changed before completion"
            }
            null
        } catch (failure: Throwable) {
            failure
        } finally {
            // Finish both the batch completion and any unexpected installed replacement. This is
            // deliberately the innermost finally: even an invariant failure cannot park a waiter.
            completion.finish()
            if (installedCompletion != null && installedCompletion !== completion) {
                installedCompletion!!.finish()
            }
        }
    }

    private fun invokeRemovalCallbacks(
        completion: PeerRemovalCompletion,
        owner: PeerFailureOwner,
        retainFailure: (Throwable) -> Unit
    ): Throwable? {
        val previousContext = removalCallbackContext.get()
        val currentContext = RemovalCallbackContext()
        removalCallbackContext.set(currentContext)
        return try {
            completion.invokeCallbacks(owner, retainFailure)
        } finally {
            currentContext.active = false
            if (previousContext == null) {
                removalCallbackContext.remove()
            } else {
                removalCallbackContext.set(previousContext)
            }
        }
    }

    private fun removePersistedPeer(peerId: String, owner: PeerFailureOwner = currentPeerFailureOwner()): PeerPersistenceException? {
        val directory = peersDirectory ?: return null
        val peerFile = directory / "$peerId.json"
        return try {
            lateinit var freshnessTime: PeerFreshnessTimeSample
            withPeerHistoryPersistenceOwnership(peerHistoryPersistenceOwners, peerId, prepare = {
                freshnessTime = peerFreshnessWindow.sampleTime()
            }) {
                registryClock.withPreparedSample(freshnessTime) {
                    persistPeerFreshnessHistory(peerId, freshnessTime)
                }
            }
            registryClock.withPreparedSample(freshnessTime) {
                updatePersistedPeer(peerId, null, owner)
            }
            null
        } catch (failure: Exception) {
            // Recoverable filesystem failures are reported as persistence failures and aggregated
            // with callback failures. Errors remain fatal so completeRemovals keeps the original
            // Throwable primary while it drains later callbacks and handoffs.
            if (failure is PeerPersistenceException) failure else PeerPersistenceException(
                "Failed to delete persisted peer '$peerId' at '$peerFile'",
                failure
            )
        }
    }

    /**
     * Gets a peer by ID.
     *
     * @param peerId The ID of the peer to get.
     * @return The peer, or null if not found.
     */
    fun getPeer(peerId: String): BootstrapPeer? = acceptedSnapshot.get().entry(peerId)?.peer

    /**
     * Returns the stable token for [peerId]'s current retained lifetime, or null when the peer is
     * absent. A token returned just before concurrent removal remains safe to use: its
     * [PeerLifetime.runIfActive] operation is ordered with that removal.
     */
    fun getPeerLifetime(peerId: String): PeerLifetime? =
        acceptedSnapshot.get().entry(peerId)?.lifetime

    /**
     * Gets all registered peers.
     *
     * @return List of all peers in the registry.
     */
    fun getAllPeers(): List<BootstrapPeer> = publishedPeersSnapshot

    /**
     * Publishes one completed peer without exposing unrelated additions that are still between map
     * installation and sidecar registration. Returns false only when adding this peer would exceed
     * the registry cap; that case needs the fair add gate and exact eviction pass.
     */
    private fun publishCompletedPeerSnapshotWithinCapacityUnderCapacityLock(
        peerId: String,
        visiblePeer: BootstrapPeer?
    ): Boolean {
        val current = publishedPeersSnapshot
        val accepted = acceptedSnapshot.get().entry(peerId)
        if (unpublishedPeerIds.isNotEmpty()) {
            if (accepted != null && current.entry(peerId) != null) {
                unpublishedRefreshIds.add(peerId)
                if (PeerLifetime.activeActionForRegistry(lifetimeRegistryIdentity) != null) {
                    val work = SnapshotWork()
                    installPublishedSnapshot(current.put(accepted, work), work)
                    return true
                }
            } else if (accepted != null) unpublishedPeerIds.add(peerId)
            return false
        }
        if (visiblePeer == null || accepted == null) return current.size <= MAX_REGISTRY_PEERS
        if (current.entry(peerId) == null && current.size >= MAX_REGISTRY_PEERS) {
            unpublishedPeerIds.add(peerId)
            return false
        }
        val work = SnapshotWork()
        installPublishedSnapshot(current.put(accepted, work), work)
        return true
    }

    private fun publishRemovedPeerSnapshotUnderCapacityLock(peerId: String): Throwable? {
        val work = SnapshotWork()
        installPublishedSnapshot(publishedPeersSnapshot.remove(peerId, work), work)
        unpublishedRemovalIds.remove(peerId)
        unpublishedRefreshIds.remove(peerId)
        return null
    }

    private fun publishPeersSnapshotUnderCapacityLock(completedUnpublished: Map<String, PeerLifetime>) {
        var next = publishedPeersSnapshot
        val accepted = acceptedSnapshot.get()
        val work = SnapshotWork()
        for (id in unpublishedRemovalIds) next = next.remove(id, work)
        for (id in unpublishedRefreshIds) {
            accepted.entry(id)?.let { entry ->
                if (next.entry(id) != null) next = next.put(entry, work)
            }
        }
        val additions = completedUnpublished.mapNotNull { (id, lifetime) ->
            accepted.entry(id)?.takeIf { it.lifetime === lifetime }
        }.sortedWith(compareBy<RegistrySnapshotEntry> { it.acceptedSequence }.thenBy { it.id })
        for (entry in additions) next = next.put(entry, work)
        unpublishedRemovalIds.clear()
        unpublishedRefreshIds.clear()
        completedUnpublished.forEach { (id, lifetime) ->
            if (peerLifetimes[id] == null || peerLifetimes[id] === lifetime) unpublishedPeerIds.remove(id)
        }
        installPublishedSnapshot(next, work)
    }

    // Writers call this only under capacityEvictionLock. No peer getter or callback runs here.
    private fun installPublishedSnapshot(snapshot: RegistrySnapshot, work: SnapshotWork) {
        getAllPeersCandidateCopies.addAndGet(work.copiedReferences)
        publishedSnapshot.set(snapshot)
    }

    // Same-peer stripes order generations; CAS combines unrelated writers without taking a
    // second lock. A retry only rebuilds the affected search paths, never the whole registry.
    private fun updateAcceptedSnapshot(change: (RegistrySnapshot, SnapshotWork) -> RegistrySnapshot) {
        while (true) {
            val current = acceptedSnapshot.get()
            val work = SnapshotWork()
            val next = change(current, work)
            getAllPeersCandidateCopies.addAndGet(work.examinedCatalogParts)
            if (acceptedSnapshot.compareAndSet(current, next)) return
        }
    }

    /**
     * Orders peer-plane work by descending ostracism score. Peer ID is the stable tie-breaker.
     */
    internal fun rankPeersForAllocation(
        candidates: Collection<BootstrapPeer> = acceptedSnapshot.get()
    ): List<BootstrapPeer> {
        val distinct = candidates.distinctBy { it.peerId }
        if (distinct.size < 2) return distinct
        val scores = observationLog.scoreAllComponents(scorer)
        return distinct.sortedWith(
            compareByDescending<BootstrapPeer> {
                scores[it.peerId]?.ostracismScore ?: 0.0
            }.thenBy { it.peerId }
        )
    }

    /**
     * Computes the greedy bootstrap-score × address-diversity ordering from scratch.
     */
    internal fun rankPeersForBootstrap(
        candidates: Collection<BootstrapPeer> = acceptedSnapshot.get()
    ): List<BootstrapPeer> = bootstrapRanking(candidates, collectFullRanking = true).ranking

    private fun prepareBootstrapRanking(
        candidates: Collection<BootstrapPeer>
    ): BootstrapRankingContext {
        // Observation updates do not flow through the registry, so score-derived ranking state
        // must not survive across calls. Addresses have their own peer cache, refreshed by
        // addPeer and cleared by removePeer; everything else is snapshotted for this walk.
        val remaining = candidates.distinctBy { it.peerId }.toMutableList()
        if (remaining.size < 2) {
            return BootstrapRankingContext(
                peers = remaining,
                scores = emptyMap(),
                addressesByPeer = remaining.associate { peer ->
                    peer.peerId to (
                        rankedAddresses[peer.peerId]
                            ?: parsePeerIpAddresses(peer.multiaddresses)
                        )
                },
                insertionSequenceByPeer = remaining.associate { peer ->
                    peer.peerId to (insertionSequence[peer.peerId] ?: Long.MIN_VALUE)
                }
            )
        }
        // Rank one coherent observation population. Re-reading the log later for scores lets a
        // concurrent capacity eviction remove a record between the two snapshots; that leaves a
        // retained candidate with the synthetic 0.0 fallback score and defeats the tied-score fast
        // paths even though every candidate carries identical evidence.
        val scorePopulation = observationLog.getBootstrapScorePopulation()
        val allSnapshots = scorePopulation.snapshots
        val snapshots = remaining.mapNotNull { peer ->
            allSnapshots[peer.peerId]?.let { peer.peerId to it }
        }.toMap()
        remaining.retainAll { it.peerId in snapshots }
        if (remaining.size < 2) {
            return BootstrapRankingContext(
                peers = remaining,
                scores = emptyMap(),
                addressesByPeer = remaining.associate { peer ->
                    peer.peerId to (
                        rankedAddresses[peer.peerId]
                            ?: parsePeerIpAddresses(peer.multiaddresses)
                        )
                },
                insertionSequenceByPeer = remaining.associate { peer ->
                    peer.peerId to (insertionSequence[peer.peerId] ?: Long.MIN_VALUE)
                }
            )
        }
        val cachedScoreShapes = scorePopulation.shapes
            .mapNotNull { (peerId, shape) -> shape?.let { peerId to it } }
            .toMap()
        val scores = if (cachedScoreShapes.size == allSnapshots.size) {
            scorer.scoreComponentsWithoutRecommendations(cachedScoreShapes)
        } else {
            scorer.scoreAllComponents(allSnapshots).also { scoredPopulation ->
                observationLog.refreshRecommendationBases(allSnapshots, scoredPopulation)
            }
        }
        val addressesByPeer = remaining.associate { peer ->
            peer.peerId to (
                rankedAddresses[peer.peerId]
                    ?: parsePeerIpAddresses(peer.multiaddresses)
                )
        }

        return BootstrapRankingContext(
            peers = remaining,
            scores = scores,
            addressesByPeer = addressesByPeer,
            insertionSequenceByPeer = remaining.associate { peer ->
                peer.peerId to (insertionSequence[peer.peerId] ?: Long.MIN_VALUE)
            }
        )
    }

    private fun bootstrapRanking(
        candidates: Collection<BootstrapPeer>,
        collectFullRanking: Boolean
    ): BootstrapRankingResult =
        bootstrapRanking(prepareBootstrapRanking(candidates), collectFullRanking)

    private fun bootstrapRanking(
        context: BootstrapRankingContext,
        collectFullRanking: Boolean
    ): BootstrapRankingResult {
        val remaining = context.peers.toMutableList()
        if (remaining.size < 2) {
            return BootstrapRankingResult(
                ranking = if (collectFullRanking) remaining else emptyList(),
                lastPeer = remaining.lastOrNull()
            )
        }

        // The greedy walk below re-compares the same candidates O(n^2) times, so every lookup a
        // comparator performs is paid once per comparison rather than once per peer. The score map
        // is a TreeMap keyed by peer ID, and registry peer IDs routinely share a long common
        // prefix, so each of those lookups costs O(log n) full-length string comparisons. Resolve
        // both comparator inputs into flat hash maps once here; the walk then compares primitives.
        val bootstrapScoreByPeerId = HashMap<String, Double>(context.peers.size * 2)
        val insertionSequenceByPeerId = HashMap<String, Long>(context.peers.size * 2)
        for (peer in context.peers) {
            bootstrapScoreByPeerId[peer.peerId] = context.scores[peer.peerId]?.bootstrapScore ?: 0.0
            insertionSequenceByPeerId[peer.peerId] =
                context.insertionSequenceByPeer[peer.peerId] ?: Long.MIN_VALUE
        }

        fun bootstrapScore(peer: BootstrapPeer): Double =
            bootstrapScoreByPeerId[peer.peerId] ?: 0.0

        fun insertionSequenceOf(peer: BootstrapPeer): Long =
            insertionSequenceByPeerId[peer.peerId] ?: Long.MIN_VALUE

        fun tieBreak(left: BootstrapPeer, right: BootstrapPeer): Int {
            val sequenceComparison = insertionSequenceOf(right).compareTo(insertionSequenceOf(left))
            return if (sequenceComparison != 0) sequenceComparison
            else left.peerId.compareTo(right.peerId)
        }

        val distinctScores = context.peers.map(::bootstrapScore).distinct()
        val singleDistinctIpv4Addresses = context.peers.mapNotNull { peer ->
            context.addressesByPeer.getValue(peer.peerId).singleOrNull()
                ?.takeIf { it.familyBits == 32 }
                ?.let { peer to it }
        }.takeIf { peerAddresses ->
            peerAddresses.size == context.peers.size &&
                peerAddresses.map { (_, address) -> rankedIpv4AddressKey(address) }.distinct()
                    .size == context.peers.size
        }
        if (
            distinctScores.size == 1 &&
            distinctScores.single() > 0.0 &&
            singleDistinctIpv4Addresses != null
        ) {
            return rankEqualScoreDistinctIpv4Peers(
                peerAddresses = singleDistinctIpv4Addresses,
                collectFullRanking = collectFullRanking,
                tieBreak = ::tieBreak
            )
        }

        val firstAddressSet = context.addressesByPeer.getValue(remaining.first().peerId)
        if (context.addressesByPeer.values.all { sameRankedAddressSet(firstAddressSet, it) }) {
            val comparator = Comparator<BootstrapPeer> { left, right ->
                val scoreComparison = bootstrapScore(right).compareTo(bootstrapScore(left))
                if (scoreComparison != 0) scoreComparison else tieBreak(left, right)
            }
            val lastPeer = remaining.maxWithOrNull(comparator)
            return BootstrapRankingResult(
                ranking = if (collectFullRanking) remaining.sortedWith(comparator) else emptyList(),
                lastPeer = lastPeer
            )
        }

        val first = remaining.minWithOrNull { left, right ->
            val scoreComparison = bootstrapScore(right).compareTo(bootstrapScore(left))
            if (scoreComparison != 0) scoreComparison else tieBreak(left, right)
        } ?: return BootstrapRankingResult(emptyList(), null)
        remaining.remove(first)

        val selectedAddresses = SelectedIpPrefixIndex()
        val selectedPeerCountByBlock = mutableMapOf<Long, Int>()
        var selectedCount = 0

        fun accountForSelected(addresses: List<RankedIpAddress>) {
            addresses.forEach(selectedAddresses::add)
            addresses.map(::diversityBlockKey).distinct().forEach { blockKey ->
                selectedPeerCountByBlock[blockKey] =
                    (selectedPeerCountByBlock[blockKey] ?: 0) + 1
            }
            selectedCount++
        }

        fun diversityDistance(addresses: List<RankedIpAddress>): Double {
            var minimumDistance = 1.0
            var hasSharedFamily = false
            addresses.forEach { address ->
                val commonPrefix = selectedAddresses.longestSharedPrefix(address)
                if (commonPrefix != null) {
                    hasSharedFamily = true
                    minimumDistance = minOf(
                        minimumDistance,
                        (address.familyBits - commonPrefix).toDouble() /
                            address.familyBits.toDouble()
                    )
                }
            }
            if (!hasSharedFamily) minimumDistance = 1.0
            val sameBlockCount = addresses.maxOfOrNull { address ->
                selectedPeerCountByBlock[diversityBlockKey(address)] ?: 0
            } ?: 0
            return maxOf(
                Math.scalb(0.05, -sameBlockCount),
                minimumDistance
            )
        }

        val ranking = if (collectFullRanking) {
            ArrayList<BootstrapPeer>(context.peers.size).apply { add(first) }
        } else {
            null
        }
        var lastPeer = first
        accountForSelected(context.addressesByPeer.getValue(first.peerId))

        // Each candidate carries the values its own ordering depends on, so the comparator below
        // reads fields instead of repeating a score, insertion-sequence, and address lookup on
        // every one of the O(n^2) comparisons the lazy re-evaluation walk performs.
        val queue = PriorityQueue<BootstrapRankingState> { left, right ->
            val utilityComparison = right.utility.compareTo(left.utility)
            if (utilityComparison != 0) {
                utilityComparison
            } else {
                val scoreComparison = right.score.compareTo(left.score)
                if (scoreComparison != 0) {
                    scoreComparison
                } else {
                    val sequenceComparison =
                        right.insertionSequence.compareTo(left.insertionSequence)
                    if (sequenceComparison != 0) sequenceComparison
                    else left.peer.peerId.compareTo(right.peer.peerId)
                }
            }
        }
        remaining.forEach { peer ->
            val score = bootstrapScore(peer)
            queue.add(
                BootstrapRankingState(
                    peer = peer,
                    score = score,
                    utility = score,
                    evaluatedAtSelectedCount = 0,
                    insertionSequence = insertionSequenceOf(peer),
                    addresses = context.addressesByPeer.getValue(peer.peerId)
                )
            )
        }

        while (queue.isNotEmpty()) {
            val next = queue.remove()
            if (next.evaluatedAtSelectedCount != selectedCount) {
                next.utility = next.score * diversityDistance(next.addresses)
                next.evaluatedAtSelectedCount = selectedCount
                queue.add(next)
                continue
            }

            lastPeer = next.peer
            ranking?.add(next.peer)
            accountForSelected(next.addresses)
        }

        return BootstrapRankingResult(ranking ?: emptyList(), lastPeer)
    }

    private fun rankEqualScoreDistinctIpv4Peers(
        peerAddresses: List<Pair<BootstrapPeer, RankedIpAddress>>,
        collectFullRanking: Boolean,
        tieBreak: (BootstrapPeer, BootstrapPeer) -> Int
    ): BootstrapRankingResult {
        // For distinct IPv4 addresses the diversity-block floor never changes the ordering. Before
        // a /16 has a selected peer, its candidates are at least 17 bits away and distance exceeds
        // 0.05. Afterward the floor is 0.025 while distinct addresses remain at least 1/32 apart.
        // A trie can therefore represent every equal-distance region exactly. Selecting a region's
        // best tied peer splits only that region along one 32-bit path.
        val root = RankedIpv4PeerTrieNode(depth = 0)
        val addressByPeer = peerAddresses.associate { it.first.peerId to it.second }
        val leafByPeer = mutableMapOf<String, RankedIpv4PeerTrieNode>()

        fun betterPeer(
            left: BootstrapPeer?,
            right: BootstrapPeer?
        ): BootstrapPeer? = when {
            left == null -> right
            right == null -> left
            tieBreak(left, right) <= 0 -> left
            else -> right
        }

        peerAddresses.forEach { (peer, address) ->
            var node = root
            val path = ArrayList<RankedIpv4PeerTrieNode>(33)
            path.add(node)
            repeat(32) { bitIndex ->
                node = if (rankedAddressBit(address, bitIndex) == 0) {
                    node.zero ?: RankedIpv4PeerTrieNode(bitIndex + 1, node).also {
                        node.zero = it
                    }
                } else {
                    node.one ?: RankedIpv4PeerTrieNode(bitIndex + 1, node).also {
                        node.one = it
                    }
                }
                path.add(node)
            }
            node.peer = peer
            leafByPeer[peer.peerId] = node
            path.asReversed().forEach { pathNode ->
                pathNode.bestPeer = betterPeer(pathNode.bestPeer, peer)
            }
        }

        fun removeFromTrie(peer: BootstrapPeer) {
            val leaf = leafByPeer.getValue(peer.peerId)
            leaf.peer = null
            var node: RankedIpv4PeerTrieNode? = leaf
            while (true) {
                val current = node ?: break
                current.bestPeer = betterPeer(
                    current.peer,
                    betterPeer(current.zero?.bestPeer, current.one?.bestPeer)
                )
                node = current.parent
            }
        }

        val regions = PriorityQueue<RankedIpv4PeerRegion> { left, right ->
            val distanceComparison = left.commonPrefixBits.compareTo(right.commonPrefixBits)
            if (distanceComparison != 0) distanceComparison
            else tieBreak(left.bestPeer, right.bestPeer)
        }

        fun addSiblingRegions(
            regionRoot: RankedIpv4PeerTrieNode,
            selectedAddress: RankedIpAddress
        ) {
            var node = regionRoot
            while (node.depth < 32) {
                val selectedBit = rankedAddressBit(selectedAddress, node.depth)
                val selectedChild = if (selectedBit == 0) node.zero else node.one
                val sibling = if (selectedBit == 0) node.one else node.zero
                sibling?.bestPeer?.let { bestPeer ->
                    regions.add(
                        RankedIpv4PeerRegion(
                            root = sibling,
                            commonPrefixBits = node.depth,
                            bestPeer = bestPeer
                        )
                    )
                }
                node = selectedChild ?: break
            }
        }

        val first = root.bestPeer ?: return BootstrapRankingResult(emptyList(), null)
        removeFromTrie(first)
        addSiblingRegions(root, addressByPeer.getValue(first.peerId))
        val ranking = if (collectFullRanking) {
            ArrayList<BootstrapPeer>(peerAddresses.size).apply { add(first) }
        } else {
            null
        }
        var lastPeer = first

        while (regions.isNotEmpty()) {
            val region = regions.remove()
            val next = region.bestPeer
            removeFromTrie(next)
            addSiblingRegions(region.root, addressByPeer.getValue(next.peerId))
            ranking?.add(next)
            lastPeer = next
        }

        return BootstrapRankingResult(ranking ?: emptyList(), lastPeer)
    }

    /**
     * Checks if a peer is in the registry.
     *
     * @param peerId The ID of the peer to check.
     * @return True if the peer is registered.
     */
    fun hasPeer(peerId: String): Boolean = acceptedSnapshot.get().entry(peerId) != null

    /**
     * Finds peers that advertise the given service identifier.
     *
     * Match is exact: prefix matching in either direction is intentionally not supported.
     * Advertising a service is a claim about the exact identifier the peer serves, not a
     * wildcard over its descendants or its ancestors — without this rule, a peer
     * advertising "tasks" would silently route requests for any "tasks-foo" service it
     * never registered, and a query for "com.example.api" would silently land on a peer
     * that only advertises the parent "com.example" namespace. Blank input matches nothing.
     *
     * @param serviceIdentifier The service to look for. Must be non-blank.
     * @return List of peers advertising exactly this service.
     */
    fun findPeersForService(serviceIdentifier: String): List<BootstrapPeer> {
        if (serviceIdentifier.isBlank()) {
            return emptyList()
        }
        return rankPeersForAllocation(
            acceptedSnapshot.get().forService(serviceIdentifier)
        )
    }

    /**
     * Finds a peer that can route to the given service.
     * Tries direct matches first, then asks peers if they can route.
     * Peers are sorted by lastSeenTimestamp (most recent first).
     *
     * @param serviceIdentifier The service to route to.
     * @return A peer that can route to the service, or null if none found.
     */
    fun findRouterForService(serviceIdentifier: String): BootstrapPeer? {
        // Guard: empty or blank service identifier should match nothing
        if (serviceIdentifier.isBlank()) {
            return null
        }

        // First, check direct advertisements
        val advertisers = findPeersForService(serviceIdentifier)
        for (peer in advertisers) {
            if (peer.ping(2000)) {
                return peer
            }
        }

        // Ask all peers if they can route
        // Note: Take a snapshot with toList() to avoid ConcurrentModificationException
        for (peer in rankPeersForAllocation()) {
            if (peer.canRoute(serviceIdentifier)) {
                return peer
            }
        }

        return null
    }

    /**
     * Discovers new peers from existing bootstrap peers.
     *
     * @param maxPeersPerBootstrap Maximum peers to request from each bootstrap peer.
     * @return Number of new peers discovered.
     */
    fun discoverNewPeers(maxPeersPerBootstrap: Int = 10): Int {
        var discovered = 0
        val currentPeers = rankPeersForBootstrap()

        for (peer in currentPeers) {
            try {
                val newPeers = peer.discoverPeers(maxPeersPerBootstrap)
                for (newPeer in newPeers) {
                    if (!peers.containsKey(newPeer.peerId)) {
                        addPeer(newPeer, origin = PeerRegistryAddOrigin.DISCOVERY)
                        discovered++
                    }
                }
            } catch (failure: PeerPersistenceException) {
                // Storage failures belong to the caller even when peer discovery is best effort.
                throw failure
            } catch (e: Exception) {
                // Skip unreachable peers
                continue
            }
        }

        return discovered
    }

    /**
     * Prunes offline peers from the registry.
     *
     * This is the original simple pruning method. For more intelligent pruning
     * with scoring, backoff, and protected peers, use [pruneWithScoring].
     *
     * @param maxAge Maximum age in milliseconds for peers to be considered stale.
     * @param pingTimeout Timeout for ping checks in milliseconds.
     * @return Number of peers removed.
     */
    fun pruneOfflinePeers(maxAge: Long = 24 * 60 * 60 * 1000, pingTimeout: Long = 5000): Int {
        // Measure peer age against the injected clock — consistent with the rest of this class
        // (including the sibling pruneWithScoring) — so an injected ManualClock/SimulationClock
        // drives staleness deterministically instead of wall-clock time.
        val now = registryClock.currentTimeMillis()
        var removed = 0

        val stalePeers = peers.values.filter { now - it.lastSeenTimestamp > maxAge }
        for (peer in stalePeers) {
            if (!peer.ping(pingTimeout)) {
                removePeer(peer.peerId)
                removed++
            }
        }

        return removed
    }

    /**
     * Maintains peer check observations using the exponential backoff schedule.
     *
     * The method name is retained for source compatibility. Score and calendar
     * thresholds no longer remove peers, so this returns zero. Step 4 consumes
     * bootstrap and ostracism scores in cap ranking and resource allocation.
     *
     * @param pingTimeout Timeout for each ping check in milliseconds.
     * @return Zero; threshold-based pruning is no longer part of peer management.
     */
    fun pruneWithScoring(pingTimeout: Long = 5000): Int {
        val scorer = PeerScorer(registryClock)
        val pruner = PeerPruner(scorer, registryClock)

        // Phase 1: Ping peers that need checking (respecting backoff)
        val peerList = rankPeersForAllocation()
        for (peer in peerList) {
            val snapshot = observationLog.getSnapshot(peer.peerId)
            if (snapshot != null) {
                val lastCheck = maxOf(snapshot.lastSuccessMs, snapshot.lastFailMs)
                // A peer that has never been checked is due now. Backoff is a delay measured
                // from the previous check, so with no previous check there is nothing to
                // measure from: comparing `now - 0` against the interval instead makes the
                // first check depend on the clock's absolute origin, which carries no meaning.
                // Under a wall clock that comparison is trivially true, but under a test clock
                // starting near zero it silently defers the first check of a freshly discovered
                // peer, and whether it does so depends on the jitter draw.
                if (lastCheck > 0L) {
                    val interval = pruner.nextCheckInterval(snapshot.consecutiveFailures)
                    if (registryClock.currentTimeMillis() - lastCheck < interval) continue
                }
            }

            if (peer.ping(pingTimeout)) {
                observationLog.recordSuccess(peer.peerId)
            } else {
                observationLog.recordFailure(peer.peerId)
            }
        }

        // Threshold pruning is deliberately disabled by the peer-management contract.
        val snapshots = observationLog.getAllSnapshots()
        val toPrune = pruner.determinePeersToPrune(snapshots, peers.keys.toSet())

        var removed = 0
        for (peerId in toPrune) {
            removePeer(peerId)
            observationLog.removePeer(peerId)
            removed++
        }

        return removed
    }

    /**
     * Saves all peers to the persistence directory.
     * Useful for periodic snapshots. Each peer's header and score evidence are
     * replaced atomically in one versioned file.
     */
    fun saveAll() {
        if (peersDirectory == null) return

        for (peerId in peers.keys) {
            val lifetime = getPeerLifetime(peerId) ?: continue
            persistCurrentPeerIfLifetimeActive(peerId, lifetime)
        }
        val historyDirectory = peersDirectory / PEER_FRESHNESS_HISTORY_DIRECTORY
        val historySubjects = peerFreshnessWindow.retainedSubjectIds(peerFreshnessWindow.sampleTime()).toMutableSet()
        if (filesystem.exists(historyDirectory)) {
            historySubjects += filesystem.list(historyDirectory)
                .filter { it.name.endsWith(".json") }
                .map { it.name.removeSuffix(".json") }
        }
        for (peerId in historySubjects) {
            lateinit var freshnessTime: PeerFreshnessTimeSample
            withPeerHistoryPersistenceOwnership(peerHistoryPersistenceOwners, peerId, prepare = {
                freshnessTime = peerFreshnessWindow.sampleTime()
            }) {
                registryClock.withPreparedSample(freshnessTime) {
                    persistPeerFreshnessHistory(peerId, freshnessTime)
                }
            }
        }
    }

    /**
     * Serializes all peers to a JSON array.
     */
    fun toJson(): JSONArray {
        return registrySnapshotToJson(acceptedSnapshot.get())
    }

    /**
     * Exports all peers to a JSON object in a format suitable for sharing/loading.
     * This is the recommended way to export peers for use in other UrlProtocol instances.
     *
     * @return JSONObject containing peers array and metadata
     */
    fun exportBootstrapPeers(): JSONObject {
        val snapshot = acceptedSnapshot.get()
        return JSONObject().apply {
            put("format", "urlprotocol-bootstrap-v1")
            put("peers", registrySnapshotToJson(snapshot))
            put("count", snapshot.size)
            put("exportedAt", System.currentTimeMillis())
        }
    }

    /**
     * Imports peers from a JSON array.
     * Each peer should have: peerId, multiaddresses, advertisedServices, lastSeenTimestamp
     *
     * @param peersArray JSON array of peer objects
     * @param persist Whether to persist imported peers to disk
     * @return Number of peers successfully imported
     */
    fun importPeers(peersArray: JSONArray, persist: Boolean = true): Int {
        var imported = 0
        for (i in 0 until peersArray.length()) {
            val peer = try {
                Libp2pPeer.fromJson(peersArray.getJSONObject(i))
            } catch (e: Exception) {
                // Skip entries that cannot be decoded as peers. Admission failures belong to the caller.
                continue
            }
            // A readable JSON object is not a successful import when address ingestion would
            // reject the peer. Keep the historical meaning for accepted entries even if the
            // registry's size bound later chooses another peer as the retained candidate.
            if (isQuarantined(peer.peerId)) continue
            val validatedPeer =
                withDialableAddresses(peer, PeerRegistryAddOrigin.CALLER) ?: continue
            // Preserve addPeer's second quarantine gate without validating the same record
            // twice (and therefore without reporting one rejected address twice).
            if (isQuarantined(peer.peerId)) continue
            addValidatedPeer(
                peer = validatedPeer,
                origin = PeerRegistryAddOrigin.CALLER,
                persist = persist,
                replaceServices = false,
                restoredHasCallerOrigin = false,
                replacePeer = false,
            )
            imported++
        }
        return imported
    }

    /**
     * Imports peers from an export JSON object.
     * Accepts output from exportBootstrapPeers() or a simple array.
     *
     * @param json Either a JSONObject with "peers" array, or a JSONArray of peers
     * @param persist Whether to persist imported peers to disk
     * @return Number of peers successfully imported
     */
    fun importFromExport(json: JSONObject, persist: Boolean = true): Int {
        val peersArray = if (json.has("peers")) {
            json.getJSONArray("peers")
        } else {
            // Treat the whole object as a single peer
            JSONArray().put(json)
        }
        return importPeers(peersArray, persist)
    }

    /**
     * Exports peers to a JSON string for easy sharing.
     */
    fun exportToString(): String {
        return exportBootstrapPeers().toString(2)
    }

    /**
     * Imports peers from a JSON string.
     *
     * @param jsonString JSON string (either export format or array)
     * @param persist Whether to persist imported peers to disk
     * @return Number of peers successfully imported
     */
    fun importFromString(jsonString: String, persist: Boolean = true): Int {
        val trimmed = jsonString.trim()
        return if (trimmed.startsWith("[")) {
            importPeers(JSONArray(trimmed), persist)
        } else {
            importFromExport(JSONObject(trimmed), persist)
        }
    }

    private fun persistCurrentPeerIfLifetimeActive(peerId: String, lifetime: PeerLifetime) {
        if (peersDirectory == null) return
        lifetime.rejectNestedLifetimeAcquisition("persist a record")
        while (peerLifetimes[peerId] === lifetime) {
            val peer = peers[peerId] ?: return
            val sequence = insertionSequence[peerId]
            // A serializer can call the registry, including removing this peer. It runs before
            // persistence ownership, so a completed removal can never be followed by this write.
            val record = preparePeerPersistenceRecord(peerId, peer)
            lateinit var freshnessTime: PeerFreshnessTimeSample
            var retry = false
            lifetime.persistIfActive(prepare = {
                freshnessTime = peerFreshnessWindow.sampleTime()
            }) {
                registryClock.withPreparedSample(freshnessTime) persistence@{
                    // Clock sampling can re-enter the registry. Finish snapshot preparation before
                    // checking the lifetime and revision that authorize this file write.
                    val history = peerFreshnessWindow.historySnapshot(peerId, freshnessTime)
                    val imported = history.freshness ?: peerImportedProvenance[peerId]
                    record.put("importedPeerFreshness", imported?.toJson() ?: JSONObject.NULL)
                        .put(IMPORTED_PEER_FRESHNESS_HISTORY, peerFreshnessHistoryToJson(history.entries))
                    if (peerLifetimes[peerId] !== lifetime) return@persistence
                    if (peers[peerId] !== peer || insertionSequence[peerId] != sequence) {
                        retry = true
                    } else {
                        updatePersistedPeer(peerId, record.toString(2))
                    }
                }
            }
            if (!retry) return
        }
    }

    private fun updatePersistedPeer(peerId: String, content: String?, owner: PeerFailureOwner = currentPeerFailureOwner()) {
        val directory = peersDirectory ?: return
        val peerFile = directory / "$peerId.json"
        val update = PeerPersistenceUpdate(content)
        // Keep the latest intent until every overlapping operation has returned. Storage callbacks
        // can remove or replace this peer before an earlier atomicMove publishes its old content.
        val updates = peerPersistenceUpdates.compute(peerId) { _, current ->
            (current ?: PeerPersistenceUpdates(update)).also {
                it.latest = update
                it.owners++
            }
        }!!
        try {
            var publication = update
            var publicationFailure: Throwable? = null
            while (true) {
                try {
                    val currentContent = publication.content
                    if (currentContent == null) {
                        try {
                            if (filesystem.exists(peerFile)) filesystem.delete(peerFile)
                        } catch (failure: Exception) {
                            throw PeerPersistenceException(
                                "Failed to delete persisted peer '$peerId' at '$peerFile'", failure
                            )
                        }
                    } else {
                        atomicWriteText(peerFile, currentContent, "persist peer '$peerId'")
                    }
                } catch (failure: Throwable) {
                    // A move may publish and then report an error. Complete newer intent before
                    // returning the first Error, or the first Exception when no Error occurred.
                    // Keep the other storage errors attached to that primary value.
                    val earlierStorageFailure = publicationFailure
                    val hadEarlierStorageFailure = earlierStorageFailure != null
                    publicationFailure = retainPeerPublicationFailure(
                        publicationFailure, failure, owner
                    )
                    if (hadEarlierStorageFailure) {
                        val reportMessage = if (publication.content == null) {
                            "Failed to delete persisted peer '$peerId' at '$peerFile'"
                        } else {
                            "Failed to persist peer '$peerId' atomically at '$peerFile'"
                        }
                        val deferred = peerPersistenceNotifications.get() != null
                        afterPeerPersistenceOwnership { displacedPrimary ->
                            try {
                                reportPersistenceFailure(
                                    reportMessage, failure, retainedPrimary = earlierStorageFailure, owner = owner
                                )
                            } catch (handlerFailure: Throwable) {
                                val handlerReport = reportPersistenceFailure(
                                    "Failed to report persistence issue for peer '$peerId' at '$peerFile'",
                                    handlerFailure,
                                    notify = false
                                )
                                retainDisplacedPeerFailure(handlerReport, handlerFailure, publicationFailure, owner)
                                retainDisplacedPeerFailure(handlerReport, handlerFailure, displacedPrimary, owner)
                                val reportedHandlerFailure = retainPeerPublicationFailure(handlerReport, handlerFailure, owner)
                                if (deferred) throw reportedHandlerFailure
                                publicationFailure = retainPeerPublicationFailure(
                                    publicationFailure, reportedHandlerFailure, owner
                                )
                            }
                        }
                    }
                }
                val latest = updates.latest
                if (latest === publication) {
                    publicationFailure?.let { throw it }
                    return
                }
                publication = latest
            }
        } finally {
            peerPersistenceUpdates.compute(peerId) { _, current ->
                check(current === updates) { "Peer '$peerId' persistence ownership changed" }
                if (--updates.owners == 0) null else updates
            }
        }
    }

    private fun preparePeerPersistenceRecord(peerId: String, peer: BootstrapPeer): JSONObject {
        return peer.toJson()
            .put("schemaVersion", PERSISTENCE_SCHEMA_VERSION)
            .put(
                "observationRecord",
                observationLog.getRecordJson(peerId) ?: JSONObject.NULL
            )
            .put(
                "lastDirectConnectionMs",
                directReachability[peerId] ?: JSONObject.NULL
            )
            .put(
                "registryFirstSeenAt",
                firstSeenAt[peerId] ?: JSONObject.NULL
            )
            .put(
                "peerRegistryHasCallerOrigin",
                peerOriginStates[peerId]?.hasCallerOrigin == true
            )
    }

    // Callers own per-subject persistence, with every admission guard already released.
    // Capture inside that ownership so a pending older write cannot follow a newer snapshot.
    private fun persistPeerFreshnessHistory(peerId: String, freshnessTime: PeerFreshnessTimeSample) {
        val directory = peersDirectory ?: return
        val path = directory / PEER_FRESHNESS_HISTORY_DIRECTORY / "$peerId.json"
        val history = peerFreshnessWindow.historySnapshot(peerId, freshnessTime)
        if (history.entries.isEmpty()) {
            if (filesystem.exists(path)) filesystem.delete(path)
            return
        }
        val record = JSONObject()
            .put("peerId", peerId)
            .put("importedPeerFreshness", history.freshness?.toJson() ?: JSONObject.NULL)
            .put(IMPORTED_PEER_FRESHNESS_HISTORY, peerFreshnessHistoryToJson(history.entries))
        atomicWriteJson(path, record, "persist imported observation history for '$peerId'")
    }

    private fun restorePeerFreshnessHistory(peerId: String, json: JSONObject) {
        peerFreshnessWindow.restoreHistory(
            peerId,
            peerFreshnessHistoryFromJson(json.optJSONArray(IMPORTED_PEER_FRESHNESS_HISTORY)),
            peerImportedProvenance[peerId]
                ?: PeerFreshness.fromJson(json.optJSONObject("importedPeerFreshness")),
            peerFreshnessWindow.sampleTime()
        )
    }

    private fun loadPersistedPeerFreshnessHistory() {
        val directory = peersDirectory ?: return
        val historyDirectory = directory / PEER_FRESHNESS_HISTORY_DIRECTORY
        try {
            if (!filesystem.exists(historyDirectory)) return
            for (path in filesystem.list(historyDirectory).filter { it.name.endsWith(".json") }) {
                try {
                    val json = readJson(path)
                    restorePeerFreshnessHistory(json.getString("peerId"), json)
                } catch (failure: Exception) {
                    reportPersistenceFailure("Failed to load imported observation history '$path'", failure, loadTime = true)
                }
            }
        } catch (failure: Exception) {
            reportPersistenceFailure("Failed to list imported observation histories in '$historyDirectory'", failure, loadTime = true)
        }
    }

    private fun loadPersistedPeers() {
        if (peersDirectory == null) return

        try {
            if (!filesystem.exists(peersDirectory)) {
                return
            }

            filesystem.list(peersDirectory)
                .filter { isPeerRecordFile(it) }
                .sortedBy { it.name }
                .forEach { peerFile ->
                    try {
                        val json = readJson(peerFile)
                        val peerId = json.getString("peerId")
                        PeerFreshness.fromJson(json.optJSONObject("importedPeerFreshness"))?.let {
                            peerImportedProvenance[peerId] = it.agedBy(Long.MAX_VALUE)
                        }
                        restorePeerFreshnessHistory(peerId, json)
                        if (json.has("observationRecord") && !json.isNull("observationRecord")) {
                            val observationRecord = json.getJSONObject("observationRecord")
                            val wrapper = JSONObject()
                                .put("schemaVersion", PERSISTENCE_SCHEMA_VERSION)
                                .put(
                                    "records",
                                    JSONObject().put(peerId, observationRecord)
                                )
                            observationLog.importRecords(
                                PeerObservationLog.fromJson(wrapper, registryClock)
                            )
                        }
                        if (
                            json.has("lastDirectConnectionMs") &&
                            !json.isNull("lastDirectConnectionMs")
                        ) {
                            directReachability[peerId] =
                                json.getLong("lastDirectConnectionMs")
                        }
                        if (
                            json.has("registryFirstSeenAt") &&
                            !json.isNull("registryFirstSeenAt")
                        ) {
                            firstSeenAt[peerId] = json.getLong("registryFirstSeenAt")
                        }
                        val peer = Libp2pPeer.fromJson(json)
                        addPeerWithRestoredCallerHistory(
                            peer = peer,
                            origin = PeerRegistryAddOrigin.PERSISTENCE,
                            persist = false,
                            replaceServices = false,
                            restoredHasCallerOrigin =
                                json.optBoolean("peerRegistryHasCallerOrigin", false)
                        )
                    } catch (failure: Exception) {
                        reportPersistenceFailure(
                            "Failed to load persisted peer record '$peerFile'; " +
                                "other peer records were still loaded",
                            failure,
                            loadTime = true
                        )
                    }
                }
        } catch (failure: Exception) {
            reportPersistenceFailure(
                "Failed to list persisted peer records in '$peersDirectory'",
                failure,
                loadTime = true
            )
        }
    }

    private fun migrateV1PersistenceIfNeeded() {
        if (peersDirectory == null) return
        val marker = peersDirectory / MIGRATION_V2_MARKER
        try {
            if (filesystem.exists(marker)) return
            if (!filesystem.exists(peersDirectory)) {
                return
            }
        } catch (failure: PeerPersistenceException) {
            throw failure
        } catch (failure: Exception) {
            throw PeerPersistenceException(
                "Failed to prepare peer persistence directory '$peersDirectory'",
                failure
            )
        }

        val peerFiles = try {
            filesystem.list(peersDirectory)
                .filter { isPeerRecordFile(it) }
                .sortedBy { it.name }
        } catch (failure: Exception) {
            throw PeerPersistenceException(
                "Failed to list v1 peer records in '$peersDirectory' for migration",
                failure
            )
        }
        val hasLegacySharedFiles = try {
            LEGACY_SHARED_FILES.any { legacyFileName ->
                filesystem.exists(peersDirectory / legacyFileName)
            }
        } catch (failure: Exception) {
            throw PeerPersistenceException(
                "Failed to inspect v1 persistence files in '$peersDirectory' for migration",
                failure
            )
        }
        if (peerFiles.isEmpty() && !hasLegacySharedFiles) {
            return
        }

        val observationRecords = readOptionalJson(
            peersDirectory / LEGACY_OBSERVATION_LOG_FILE
        )?.optJSONObject("records") ?: JSONObject()
        val directReachabilityJson = readOptionalJson(
            peersDirectory / LEGACY_DIRECT_REACHABILITY_FILE
        ) ?: JSONObject()
        val firstSeenJson = readOptionalJson(
            peersDirectory / LEGACY_FIRST_SEEN_FILE
        ) ?: JSONObject()

        for (peerFile in peerFiles) {
            try {
                val legacy = readJson(peerFile)
                if (legacy.optInt("schemaVersion", 1) >= PERSISTENCE_SCHEMA_VERSION) {
                    continue
                }
                val peerId = legacy.getString("peerId")
                val migrated = JSONObject(legacy.toString())
                    .put("schemaVersion", PERSISTENCE_SCHEMA_VERSION)
                    .put(
                        "lastDirectConnectionMs",
                        if (directReachabilityJson.has(peerId)) {
                            directReachabilityJson.getLong(peerId)
                        } else {
                            JSONObject.NULL
                        }
                    )
                    .put(
                        "registryFirstSeenAt",
                        if (firstSeenJson.has(peerId)) {
                            firstSeenJson.getLong(peerId)
                        } else {
                            JSONObject.NULL
                        }
                    )
                val observationRecord = observationRecords.optJSONObject(peerId)
                if (observationRecord != null) {
                    // Validate each record independently before committing it to the peer file.
                    PeerObservationRecord.fromJson(observationRecord)
                    migrated.put("observationRecord", observationRecord)
                } else {
                    migrated.put("observationRecord", JSONObject.NULL)
                }
                atomicWriteJson(peerFile, migrated, "migrate peer '$peerId' to v2")
            } catch (failure: Exception) {
                reportPersistenceFailure(
                    "Failed to migrate persisted peer record '$peerFile' to v2; " +
                        "other peer records were still migrated",
                    failure,
                    loadTime = true
                )
            }
        }

        var cleanupComplete = true
        for (legacyFileName in LEGACY_SHARED_FILES) {
            val legacyFile = peersDirectory / legacyFileName
            try {
                if (!filesystem.exists(legacyFile)) continue
                filesystem.delete(legacyFile)
            } catch (failure: Exception) {
                reportPersistenceFailure(
                    "Failed to delete migrated v1 persistence file '$legacyFile'",
                    failure,
                    loadTime = true
                )
                cleanupComplete = false
            }
        }
        if (cleanupComplete) {
            atomicWriteText(marker, "v2\n", "write the v2 migration marker")
        }
    }

    private fun readOptionalJson(path: Path): JSONObject? {
        try {
            if (!filesystem.exists(path)) return null
            return readJson(path)
        } catch (failure: Exception) {
            reportPersistenceFailure(
                "Failed to read v1 persistence file '$path'; peer-file migration continued",
                failure,
                loadTime = true
            )
            return null
        }
    }

    private fun readJson(path: Path): JSONObject =
        JSONObject(filesystem.source(path).buffer().use { it.readUtf8() })

    private fun atomicWriteJson(path: Path, json: JSONObject, operation: String) {
        atomicWriteText(path, json.toString(2), operation)
    }

    private fun atomicWriteText(path: Path, content: String, operation: String) {
        val parent = path.parent ?: throw PeerPersistenceException(
            "Failed to $operation at '$path': the path has no parent directory"
        )
        val temporaryPath = parent / ".${path.name}.${java.util.UUID.randomUUID()}.tmp"
        try {
            filesystem.createDirectories(parent)
            filesystem.sink(temporaryPath).buffer().use { sink ->
                sink.writeUtf8(content)
            }
            filesystem.atomicMove(temporaryPath, path)
        } catch (failure: Exception) {
            val persistenceFailure = PeerPersistenceException(
                "Failed to $operation atomically at '$path'",
                failure
            )
            try {
                if (filesystem.exists(temporaryPath)) {
                    filesystem.delete(temporaryPath)
                }
            } catch (cleanupFailure: Exception) {
                persistenceFailure.addSuppressed(cleanupFailure)
            } catch (cleanupFailure: Error) {
                cleanupFailure.addSuppressed(persistenceFailure)
                // Suppression can be disabled on the supplied Error. Report the earlier
                // operation independently, without inspecting that Error's accessors.
                val owner = currentPeerFailureOwner()
                afterPeerPersistenceOwnership { displacedPrimary ->
                    try {
                        reportPersistenceFailure("Failed to $operation atomically at '$path'", failure)
                    } catch (handlerFailure: Throwable) {
                        val handlerReport = reportPersistenceFailure(
                            "Failed to report persistence issue while cleaning temporary record at '$temporaryPath'",
                            handlerFailure,
                            notify = false
                        )
                        retainDisplacedPeerFailure(handlerReport, handlerFailure, displacedPrimary, owner)
                        cleanupFailure.addSuppressed(handlerReport)
                    }
                }
                throw cleanupFailure
            }
            throw persistenceFailure
        }
    }

    private fun reportPersistenceFailure(
        message: String,
        cause: Throwable,
        notify: Boolean = true,
        loadTime: Boolean = false,
        retainedPrimary: Throwable? = null,
        owner: PeerFailureOwner = currentPeerFailureOwner()
    ): PeerPersistenceException {
        val failure = PeerPersistenceException(message, cause)
        // Retain a displaced primary before publishing the report or calling its handler.
        retainDisplacedPeerFailure(failure, cause, retainedPrimary, owner)
        return publishPersistenceFailure(failure, notify, loadTime, owner)
    }

    private fun publishPersistenceFailure(
        failure: PeerPersistenceException,
        notify: Boolean = true,
        loadTime: Boolean = false,
        owner: PeerFailureOwner = currentPeerFailureOwner()
    ): PeerPersistenceException {
        synchronized(persistenceFailureLock) {
            if (loadTime) {
                persistenceFailures += failure
            } else {
                if (runtimePersistenceFailures.size == MAX_RUNTIME_PERSISTENCE_REPORTS) {
                    runtimePersistenceFailures.removeFirst()
                }
                runtimePersistenceFailures.addLast(failure)
            }
        }
        if (!notify) {
            // Keep this report available without invoking the handler that raised it again.
            return failure
        }
        afterPeerPersistenceOwnership { displacedPrimary ->
            val effect = PeerPersistenceWarningEffect(failure)
            try {
                toss(effect)
            } catch (handlerFailure: Throwable) {
                if (handlerFailure is UnhandledNotificationEffect && handlerFailure.effect === effect) {
                    // An unhandled warning remains available through getPersistenceFailures().
                } else {
                    if (loadTime) {
                        val handlerReport = reportPersistenceFailure(
                            "Failed to report persistence issue: ${failure.message}",
                            handlerFailure,
                            notify = false
                        )
                        retainDisplacedPeerFailure(handlerReport, handlerFailure, displacedPrimary, owner)
                    }
                    // Runtime callers attach their operation-specific report to the storage Error.
                    throw handlerFailure
                }
            }
        }
        return failure
    }

    private fun isPeerRecordFile(path: Path): Boolean =
        path.name.endsWith(".json") && path.name !in NON_PEER_PERSISTENCE_FILES

    companion object {
        private const val MAX_RUNTIME_PERSISTENCE_REPORTS = 64
        private const val PERSISTENCE_SCHEMA_VERSION = 2
        private const val MIGRATION_V2_MARKER = "migration-v2-complete"
        private const val LEGACY_OBSERVATION_LOG_FILE = "observation-log.json"
        private const val LEGACY_DIRECT_REACHABILITY_FILE = "direct-reachability.json"
        private const val LEGACY_FIRST_SEEN_FILE = "first-seen-at.json"
        private const val TLD_PERSISTENCE_FILE = "known-tld-descriptors.json"
        private val LEGACY_SHARED_FILES = setOf(
            LEGACY_OBSERVATION_LOG_FILE,
            LEGACY_DIRECT_REACHABILITY_FILE,
            LEGACY_FIRST_SEEN_FILE
        )
        private val NON_PEER_PERSISTENCE_FILES =
            LEGACY_SHARED_FILES + TLD_PERSISTENCE_FILE

        /**
         * Maximum number of multiaddresses to store per peer.
         * This prevents unbounded growth while preserving alternate routing paths.
         */
        const val MAX_MULTIADDRESSES_PER_PEER = 20

        /**
         * Maximum number of distinct peers retained in memory.
         *
         * Without a global cap, every gossip-discovered peer accumulates indefinitely
         * and the registry's footprint grows linearly with network churn. With each peer
         * holding up to [MAX_MULTIADDRESSES_PER_PEER] full p2p-circuit multiaddr strings
         * (~157 bytes each), a few thousand peers consume tens of megabytes — enough
         * to push embedded JVMs (e.g. ContainerNursery at -Xmx128m) into OOM during
         * peer-discovery bursts.
         *
         * 1000 is large enough to retain the entire reachable set on a healthy
         * network (typical observed peer counts are under 200) while keeping the
         * worst-case memory footprint bounded at ~3 MB of multiaddr storage.
         */
        const val MAX_REGISTRY_PEERS = 1000

        /**
         * Maximum number of dial-failure quarantines retained at once.
         *
         * A high-churn peer stream can cycle through more identities than the live registry holds,
         * so the quarantine history needs its own bound. Four registry generations preserve the
         * ordinary fifteen-minute protection across substantial churn while keeping retained peer
         * IDs strictly bounded.
         */
        const val MAX_QUARANTINED_PEERS = MAX_REGISTRY_PEERS * 4

        private const val DIAL_OUTCOME_LOCK_STRIPES = 64

        /**
         * Consecutive failed outbound dials, with no intervening success, after which a peer is
         * evicted and quarantined by [recordDialFailure].
         *
         * Three tolerates the ordinary transient failures a live peer produces — a restart, a
         * momentary event-loop stall, a dial that lost the admission race — while still removing a
         * genuinely departed host within seconds rather than leaving it in the registry
         * indefinitely. Every retained peer is a dial target on every gossip fan-out, so the
         * threshold directly bounds how long a destroyed host keeps consuming outbound sockets.
         */
        const val MAX_CONSECUTIVE_DIAL_FAILURES = 3

        /**
         * How long a peer evicted by [recordDialFailure] is refused re-entry to the registry.
         *
         * The quarantine has to outlast the mesh's re-advertisement cadence, otherwise the next
         * PeerExchange response or periodic re-announcement restores the peer immediately and the
         * eviction removes no dials at all. Fifteen minutes spans the five-minute periodic
         * re-announce with margin, while remaining short enough that a host which is rebooted or
         * has its network restored rejoins without operator action.
         */
        const val DIAL_FAILURE_QUARANTINE_MS = 15 * 60 * 1000L

        /**
         * How long a direct reachability record remains valid (10 minutes).
         * After this time without a new direct connection, [isDirectlyReachable] returns false.
         */
        const val DIRECT_REACHABILITY_TTL_MS = 10 * 60 * 1000L

        /**
         * Creates a PeerRegistry with in-memory storage only.
         */
        fun inMemory(clock: Clock = SystemClock()): PeerRegistry = PeerRegistry(clock = clock)

        /**
         * Creates a PeerRegistry with disk persistence.
         *
         * @param directory The directory to store peer files.
         * @param filesystem The filesystem to use (defaults to system filesystem).
         * @param clock Clock abstraction for testable time logic.
         */
        fun withPersistence(
            directory: Path,
            filesystem: FileSystem = FileSystem.SYSTEM,
            clock: Clock = SystemClock()
        ): PeerRegistry {
            return PeerRegistry(filesystem, directory, clock)
        }

        /**
         * Creates a PeerRegistry with disk persistence using a string path.
         *
         * @param directoryPath The directory path to store peer files.
         */
        fun withPersistence(directoryPath: String): PeerRegistry {
            return withPersistence(directoryPath.toPath())
        }

        /**
         * Creates a PeerRegistry initialized with the given bootstrap peers.
         *
         * @param bootstrapPeers Initial peers to add.
         * @param peersDirectory Optional directory for persistence.
         * @param clock Clock abstraction for testable time logic.
         */
        fun withBootstrapPeers(
            bootstrapPeers: List<BootstrapPeer>,
            peersDirectory: Path? = null,
            clock: Clock = SystemClock()
        ): PeerRegistry {
            val registry = PeerRegistry(peersDirectory = peersDirectory, clock = clock)
            registry.addPeers(bootstrapPeers)
            return registry
        }
    }
}

private fun registrySnapshotToJson(snapshot: RegistrySnapshot): JSONArray =
    JSONArray(snapshot.map { it.toJson() })

private data class PeerImportedRecord(
    val freshness: PeerFreshness?,
    val exchangeElapsedMillis: Long,
    val receivedAtElapsedMillis: Long,
    val receivedAtTimeSample: PeerFreshnessTimeSample? = null
)
