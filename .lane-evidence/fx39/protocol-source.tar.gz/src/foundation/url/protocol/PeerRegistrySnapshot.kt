package foundation.url.protocol

import java.util.AbstractList
import java.util.ArrayDeque

/** Registry-owned keys and metadata; the caller retains ownership of the peer object itself. */
internal data class RegistrySnapshotEntry(
    val id: String,
    val peer: BootstrapPeer,
    val services: RegistryServiceCatalog,
    val lifetime: PeerLifetime,
    val origin: PeerRegistryPeerOriginState,
    val order: Long,
    val acceptedSequence: Long = order,
)

internal class SnapshotWork {
    var copiedReferences = 0L
    var examinedCatalogParts = 0L
}

private class SnapshotNode<K : Comparable<K>, V>(
    val key: K,
    val value: V,
    val left: SnapshotNode<K, V>?,
    val right: SnapshotNode<K, V>?,
) {
    val height: Int = 1 + maxOf(left?.height ?: 0, right?.height ?: 0)
    val size: Int = 1 + (left?.size ?: 0) + (right?.size ?: 0)
    val firstKey: K = left?.firstKey ?: key
    val lastKey: K = right?.lastKey ?: key
}

private fun <K : Comparable<K>, V> snapshotNode(
    key: K, value: V, left: SnapshotNode<K, V>?, right: SnapshotNode<K, V>?, work: SnapshotWork,
): SnapshotNode<K, V> {
    work.copiedReferences++
    return SnapshotNode(key, value, left, right)
}

private fun <K : Comparable<K>, V> balanceSnapshotNode(
    key: K, value: V, left: SnapshotNode<K, V>?, right: SnapshotNode<K, V>?, work: SnapshotWork,
): SnapshotNode<K, V> {
    val difference = (left?.height ?: 0) - (right?.height ?: 0)
    if (difference > 1) {
        val l = checkNotNull(left)
        if ((l.left?.height ?: 0) >= (l.right?.height ?: 0)) {
            return snapshotNode(l.key, l.value, l.left,
                snapshotNode(key, value, l.right, right, work), work)
        }
        val middle = checkNotNull(l.right)
        return snapshotNode(middle.key, middle.value,
            snapshotNode(l.key, l.value, l.left, middle.left, work),
            snapshotNode(key, value, middle.right, right, work), work)
    }
    if (difference < -1) {
        val r = checkNotNull(right)
        if ((r.right?.height ?: 0) >= (r.left?.height ?: 0)) {
            return snapshotNode(r.key, r.value,
                snapshotNode(key, value, left, r.left, work), r.right, work)
        }
        val middle = checkNotNull(r.left)
        return snapshotNode(middle.key, middle.value,
            snapshotNode(key, value, left, middle.left, work),
            snapshotNode(r.key, r.value, middle.right, r.right, work), work)
    }
    return snapshotNode(key, value, left, right, work)
}

private fun <K : Comparable<K>, V> putSnapshotNode(
    node: SnapshotNode<K, V>?, key: K, value: V, work: SnapshotWork,
): SnapshotNode<K, V> {
    node ?: return snapshotNode(key, value, null, null, work)
    val comparison = key.compareTo(node.key)
    return when {
        comparison < 0 -> balanceSnapshotNode(node.key, node.value,
            putSnapshotNode(node.left, key, value, work), node.right, work)
        comparison > 0 -> balanceSnapshotNode(node.key, node.value, node.left,
            putSnapshotNode(node.right, key, value, work), work)
        else -> snapshotNode(key, value, node.left, node.right, work)
    }
}

private fun <K : Comparable<K>, V> removeSnapshotNode(
    node: SnapshotNode<K, V>?, key: K, work: SnapshotWork,
): SnapshotNode<K, V>? {
    node ?: return null
    val comparison = key.compareTo(node.key)
    if (comparison < 0) return balanceSnapshotNode(node.key, node.value,
        removeSnapshotNode(node.left, key, work), node.right, work)
    if (comparison > 0) return balanceSnapshotNode(node.key, node.value, node.left,
        removeSnapshotNode(node.right, key, work), work)
    if (node.left == null) return node.right
    if (node.right == null) return node.left
    var successor = checkNotNull(node.right)
    while (successor.left != null) successor = checkNotNull(successor.left)
    return balanceSnapshotNode(successor.key, successor.value, node.left,
        removeSnapshotNode(node.right, successor.key, work), work)
}

private class SnapshotTree<K : Comparable<K>, V>(val root: SnapshotNode<K, V>? = null) {
    val size: Int get() = root?.size ?: 0
    operator fun get(key: K): V? {
        var node = root
        while (node != null) {
            val comparison = key.compareTo(node.key)
            node = when {
                comparison < 0 -> node.left
                comparison > 0 -> node.right
                else -> return node.value
            }
        }
        return null
    }
    fun put(key: K, value: V, work: SnapshotWork) =
        SnapshotTree(putSnapshotNode(root, key, value, work))
    fun remove(key: K, work: SnapshotWork) = SnapshotTree(removeSnapshotNode(root, key, work))
    fun at(index: Int): V {
        if (index !in 0 until size) throw IndexOutOfBoundsException("Index $index, size $size")
        var remaining = index
        var node = root
        while (node != null) {
            val leftSize = node.left?.size ?: 0
            when {
                remaining < leftSize -> node = node.left
                remaining > leftSize -> { remaining -= leftSize + 1; node = node.right }
                else -> return node.value
            }
        }
        error("Snapshot index $index is absent from a tree of size $size")
    }
    fun iterator(): Iterator<V> = object : Iterator<V> {
        private val path = ArrayDeque<SnapshotNode<K, V>>()
        init { pushLeft(root) }
        private fun pushLeft(start: SnapshotNode<K, V>?) {
            var node = start
            while (node != null) { path.addLast(node); node = node.left }
        }
        override fun hasNext() = path.isNotEmpty()
        override fun next(): V {
            if (path.isEmpty()) throw NoSuchElementException()
            val node = path.removeLast()
            pushLeft(node.right)
            return node.value
        }
    }
}

private data class ServiceCatalogPart(val node: SnapshotNode<String, String>, val single: Boolean = false) {
    val first: String get() = if (single) node.key else node.firstKey
    val last: String get() = if (single) node.key else node.lastKey
}

private fun expandServiceCatalogPart(parts: ArrayDeque<ServiceCatalogPart>, work: SnapshotWork) {
    val node = parts.removeLast().node
    work.copiedReferences++
    work.examinedCatalogParts++
    node.right?.let { parts.addLast(ServiceCatalogPart(it)) }
    parts.addLast(ServiceCatalogPart(node, single = true))
    node.left?.let { parts.addLast(ServiceCatalogPart(it)) }
}

/** Immutable service keys prepared without registry guards, sharing every unchanged search path. */
internal class RegistryServiceCatalog private constructor(private val keys: SnapshotTree<String, String>) : Iterable<String> {
    constructor() : this(SnapshotTree())
    override fun iterator(): Iterator<String> = keys.iterator()

    // Full input traversal is caller preparation. Only changed paths are installed under mutation guards.
    fun prepared(proposed: Set<String>): RegistryServiceCatalog {
        var next = keys
        val preparation = SnapshotWork()
        for (key in this) if (key !in proposed) next = next.remove(key, preparation)
        for (key in proposed) if (keys[key] == null) next = next.put(key, key, preparation)
        return if (next === keys) this else RegistryServiceCatalog(next)
    }

    fun changesTo(next: RegistryServiceCatalog, work: SnapshotWork, change: (String, Boolean) -> Unit) {
        if (keys.root === next.keys.root) return
        val oldParts = ArrayDeque<ServiceCatalogPart>()
        val newParts = ArrayDeque<ServiceCatalogPart>()
        keys.root?.let { oldParts.addLast(ServiceCatalogPart(it)) }
        next.keys.root?.let { newParts.addLast(ServiceCatalogPart(it)) }
        while (oldParts.isNotEmpty() || newParts.isNotEmpty()) {
            val old = oldParts.peekLast()
            val new = newParts.peekLast()
            work.copiedReferences++
            work.examinedCatalogParts++
            if (old != null && new != null && old.node === new.node && old.single == new.single) {
                oldParts.removeLast()
                newParts.removeLast()
            } else if (old == null || (new != null && new.first < old.first)) {
                if (!checkNotNull(new).single) expandServiceCatalogPart(newParts, work)
                else { newParts.removeLast(); change(new.node.key, true) }
            } else if (new == null || old.first < new.first) {
                if (!old.single) expandServiceCatalogPart(oldParts, work)
                else { oldParts.removeLast(); change(old.node.key, false) }
            } else if (old.single && new.single) {
                oldParts.removeLast()
                newParts.removeLast()
            } else {
                // Align equal-start ranges before descending. Shared subtrees then meet as whole
                // parts even after AVL rotations, and are skipped without visiting their entries.
                if (!old.single && (new.single || old.last >= new.last)) expandServiceCatalogPart(oldParts, work)
                if (!new.single && (old.single || new.last >= old.last)) expandServiceCatalogPart(newParts, work)
            }
        }
    }
}

/** Every root owns all three indexes. Updates allocate only balanced search paths. */
internal class RegistrySnapshot private constructor(
    private val byId: SnapshotTree<String, RegistrySnapshotEntry>,
    private val ordered: SnapshotTree<Long, RegistrySnapshotEntry>,
    private val services: SnapshotTree<String, SnapshotTree<String, String>>,
) : AbstractList<BootstrapPeer>() {
    constructor() : this(SnapshotTree(), SnapshotTree(), SnapshotTree())
    override val size: Int get() = ordered.size
    val serviceCount: Int get() = services.size
    fun entry(id: String): RegistrySnapshotEntry? = byId[id]
    override fun get(index: Int): BootstrapPeer = ordered.at(index).peer
    override fun iterator(): MutableIterator<BootstrapPeer> {
        val source = ordered.iterator()
        return object : MutableIterator<BootstrapPeer> {
            override fun hasNext() = source.hasNext()
            override fun next() = source.next().peer
            override fun remove(): Unit = throw UnsupportedOperationException("Peer snapshots are immutable")
        }
    }
    fun forService(service: String): List<BootstrapPeer> {
        val source = services[service]?.iterator() ?: return emptyList()
        val result = ArrayList<BootstrapPeer>()
        while (source.hasNext()) {
            val id = source.next()
            result.add(checkNotNull(byId[id]) {
                "Service '$service' references peer '$id' absent from its snapshot"
            }.peer)
        }
        return result
    }
    fun put(entry: RegistrySnapshotEntry, work: SnapshotWork): RegistrySnapshot {
        val previous = byId[entry.id]
        val updated = entry.copy(order = previous?.order ?: entry.acceptedSequence)
        work.copiedReferences++
        var nextServices = services
        (previous?.services ?: RegistryServiceCatalog()).changesTo(updated.services, work) { service, added ->
            if (added) {
                val members = nextServices[service] ?: SnapshotTree()
                nextServices = nextServices.put(service, members.put(entry.id, entry.id, work), work)
            } else {
                val remaining = checkNotNull(nextServices[service]).remove(entry.id, work)
                nextServices = if (remaining.size == 0) nextServices.remove(service, work)
                    else nextServices.put(service, remaining, work)
            }
        }
        return RegistrySnapshot(byId.put(entry.id, updated, work),
            ordered.put(updated.order, updated, work), nextServices)
    }
    fun remove(id: String, work: SnapshotWork): RegistrySnapshot {
        val previous = byId[id] ?: return this
        var nextServices = services
        for (service in previous.services) {
            val remaining = checkNotNull(nextServices[service]).remove(id, work)
            nextServices = if (remaining.size == 0) nextServices.remove(service, work)
                else nextServices.put(service, remaining, work)
        }
        return RegistrySnapshot(byId.remove(id, work), ordered.remove(previous.order, work), nextServices)
    }
}
