package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import java.util.TreeMap
import kotlin.math.pow

data class PeerScoreComponents(
    val longevity: Double,
    val reliability: Double,
    val reach: Double,
    val novelRecommendation: Double,
    val allSharesRecommendation: Double,
    val recommendation: Double,
    val spamFactor: Double,
    val baseScore: Double,
    val bootstrapScore: Double,
    val ostracismScore: Double
)

internal data class PeerBootstrapScoreShape(
    val witnessedTenureMs: Long,
    val reliability: Double,
    val reach: Double,
    val spamFactor: Double
)

/**
 * Computes peer-management scores from bounded observation records.
 *
 * Recency is based on observation rank. The injected clock is retained in the
 * constructor for source compatibility, but score evaluation never reads it:
 * idle wall time cannot change a peer's score.
 */
class PeerScorer(
    @Suppress("UNUSED_PARAMETER")
    clock: Clock = SystemClock()
) {
    companion object {
        const val WEIGHT_LONGEVITY = 0.10
        const val WEIGHT_RELIABILITY = 0.50
        const val WEIGHT_RECOMMENDATION = 0.30
        const val WEIGHT_REACH = 0.10

        const val BOOTSTRAP_WEIGHT_LONGEVITY = 0.25
        const val BOOTSTRAP_WEIGHT_RELIABILITY = 0.30
        const val BOOTSTRAP_WEIGHT_RECOMMENDATION = 0.10
        const val BOOTSTRAP_WEIGHT_REACH = 0.35

        const val BASE_WEIGHT_LONGEVITY = 0.15
        const val BASE_WEIGHT_RELIABILITY = 0.70
        const val BASE_WEIGHT_REACH = 0.15

        const val RECOMMENDATION_WEIGHT_NOVEL = 0.60
        const val RECOMMENDATION_WEIGHT_ALL_SHARES = 0.40

        /**
         * Kept only so existing callers that use the old scheduling constants
         * remain source-compatible. Score computation does not use time windows.
         */
        @Deprecated("Longevity is a witnessed-tenure percentile with no time scale")
        const val LONGEVITY_SCALE_MS = 7L * 24L * 60L * 60L * 1000L

        @Deprecated("Evidence is rank-decayed and never expires by wall clock")
        const val RECENCY_SCALE_MS = 24L * 60L * 60L * 1000L

        @Deprecated("Every amount of evidence uses the same total formula")
        const val MIN_OBSERVATIONS = 0
    }

    /**
     * Compatibility entry point: the legacy single score is now the
     * resource-allocation [PeerScoreComponents.ostracismScore].
     */
    fun score(snapshot: PeerObservationSnapshot): Double =
        scoreComponents(snapshot).ostracismScore

    /**
     * Compatibility entry point returning ostracism scores for every peer.
     */
    fun scoreAll(snapshots: Map<String, PeerObservationSnapshot>): Map<String, Double> =
        scoreAllComponents(snapshots)
            .mapValuesTo(TreeMap()) { it.value.ostracismScore }

    fun scoreComponents(snapshot: PeerObservationSnapshot): PeerScoreComponents =
        if (snapshot.recommendations.isEmpty()) {
            // A singleton's witnessed-tenure percentile is exactly one half. Reuse the exact
            // evidence formula without staging the single peer through population maps.
            scoreComponentsWithoutRecommendations(snapshot, longevity = 0.5)
        } else {
            scoreAllComponents(mapOf(snapshot.peerId to snapshot)).getValue(snapshot.peerId)
        }

    fun scoreComponents(
        snapshot: PeerObservationSnapshot,
        allSnapshots: Map<String, PeerObservationSnapshot>
    ): PeerScoreComponents {
        val withSnapshot = if (allSnapshots[snapshot.peerId] == snapshot) {
            allSnapshots
        } else {
            allSnapshots + (snapshot.peerId to snapshot)
        }
        return scoreAllComponents(withSnapshot).getValue(snapshot.peerId)
    }

    /**
     * Fast exact path for a population whose witnessed tenures are tied and whose recommendation
     * ledgers are empty. Registry-cap churn commonly has this shape.
     */
    internal fun scoreComponentsWithoutRecommendations(
        snapshot: PeerObservationSnapshot,
        longevity: Double
    ): PeerScoreComponents {
        require(snapshot.recommendations.isEmpty()) {
            "The no-recommendations score path requires an empty recommendation ledger for " +
                "peer '${snapshot.peerId}', but it contained ${snapshot.recommendations.size} entries."
        }
        val shape = bootstrapScoreShape(snapshot)
            ?: throw IllegalArgumentException(
                "The no-recommendations score path could not derive a score shape for peer " +
                    "'${snapshot.peerId}' even though its recommendation ledger is empty."
            )
        return scoreComponentsWithoutRecommendations(shape, longevity)
    }

    /**
     * Scores a peer from its immutable per-record score inputs.
     *
     * Reliability, reach, and spam evidence are evaluated when the observation record changes.
     * Registry-cap churn can therefore update population-dependent longevity without walking every
     * retained peer's bounded evidence series again.
     */
    internal fun scoreComponentsWithoutRecommendations(
        shape: PeerBootstrapScoreShape,
        longevity: Double
    ): PeerScoreComponents {
        val reliability = shape.reliability
        val reach = shape.reach
        val spamFactor = shape.spamFactor
        val recommendation = 0.5
        val base = (
            BASE_WEIGHT_LONGEVITY * longevity +
                BASE_WEIGHT_RELIABILITY * reliability +
                BASE_WEIGHT_REACH * reach
            ) * spamFactor
        val bootstrap = (
            BOOTSTRAP_WEIGHT_LONGEVITY * longevity +
                BOOTSTRAP_WEIGHT_RELIABILITY * reliability +
                BOOTSTRAP_WEIGHT_RECOMMENDATION * recommendation +
                BOOTSTRAP_WEIGHT_REACH * reach
            ) * spamFactor
        val ostracism = (
            WEIGHT_LONGEVITY * longevity +
                WEIGHT_RELIABILITY * reliability +
                WEIGHT_RECOMMENDATION * recommendation +
                WEIGHT_REACH * reach
            ) * spamFactor
        return PeerScoreComponents(
            longevity = longevity,
            reliability = reliability,
            reach = reach,
            novelRecommendation = recommendation,
            allSharesRecommendation = recommendation,
            recommendation = recommendation,
            spamFactor = spamFactor,
            baseScore = base.coerceIn(0.0, 1.0),
            bootstrapScore = bootstrap.coerceIn(0.0, 1.0),
            ostracismScore = ostracism.coerceIn(0.0, 1.0)
        )
    }

    /**
     * Exact population score for recommendation-free records using their cached evidence shapes.
     */
    internal fun scoreComponentsWithoutRecommendations(
        shapes: Map<String, PeerBootstrapScoreShape>
    ): Map<String, PeerScoreComponents> {
        if (shapes.isEmpty()) return emptyMap()
        val longevity = computeLongevityPercentilesByPeer(
            shapes.mapValues { (_, shape) -> shape.witnessedTenureMs }
        )
        return shapes.toSortedMap().mapValuesTo(TreeMap()) { (peerId, shape) ->
            scoreComponentsWithoutRecommendations(shape, longevity.getValue(peerId))
        }
    }

    /**
     * Returns the score inputs that must match for peers with tied witnessed tenure and no
     * recommendations to have exactly equal bootstrap scores.
     */
    internal fun bootstrapScoreShape(
        snapshot: PeerObservationSnapshot
    ): PeerBootstrapScoreShape? {
        if (snapshot.recommendations.isNotEmpty()) return null
        return PeerBootstrapScoreShape(
            witnessedTenureMs = snapshot.lastSuccessfulObservationAtMs
                ?.let { (it - snapshot.firstSeenMs).coerceAtLeast(0L) }
                ?: 0L,
            reliability = computeReliability(snapshot),
            reach = computeReach(snapshot),
            spamFactor = computeSpamFactor(snapshot)
        )
    }

    internal fun bootstrapScoreForTiedPopulation(
        shape: PeerBootstrapScoreShape,
        populationSize: Int
    ): Double {
        require(populationSize > 0) {
            "A tied bootstrap-score population must contain at least one peer, but contained " +
                "$populationSize"
        }
        val longevity =
            (populationSize + 1).toDouble() / (2.0 * populationSize.toDouble())
        return (
            BOOTSTRAP_WEIGHT_LONGEVITY * longevity +
                BOOTSTRAP_WEIGHT_RELIABILITY * shape.reliability +
                BOOTSTRAP_WEIGHT_RECOMMENDATION * 0.5 +
                BOOTSTRAP_WEIGHT_REACH * shape.reach
            ) * shape.spamFactor
    }

    fun scoreAllComponents(
        snapshots: Map<String, PeerObservationSnapshot>
    ): Map<String, PeerScoreComponents> {
        if (snapshots.isEmpty()) {
            return emptyMap()
        }
        val sortedSnapshots = TreeMap(snapshots)
        val longevity = computeLongevityPercentiles(sortedSnapshots)
        val reliability = sortedSnapshots.mapValues { computeReliability(it.value) }
        val reach = sortedSnapshots.mapValues { computeReach(it.value) }
        val spam = sortedSnapshots.mapValues { computeSpamFactor(it.value) }
        val baseScores = sortedSnapshots.mapValues { (peerId, _) ->
            (
                BASE_WEIGHT_LONGEVITY * longevity.getValue(peerId) +
                    BASE_WEIGHT_RELIABILITY * reliability.getValue(peerId) +
                    BASE_WEIGHT_REACH * reach.getValue(peerId)
                ) * spam.getValue(peerId)
        }
        val observedBaseScores = baseScores.filterKeys { peerId ->
            sortedSnapshots.getValue(peerId).lastObservedAtMs != null
        }

        return sortedSnapshots.entries.associateTo(TreeMap()) { (peerId, snapshot) ->
            val novel = computeRecommendationSubScore(
                snapshot,
                observedBaseScores,
                novelOnly = true
            )
            val allShares = computeRecommendationSubScore(
                snapshot,
                observedBaseScores,
                novelOnly = false
            )
            val recommendation =
                RECOMMENDATION_WEIGHT_NOVEL * novel +
                    RECOMMENDATION_WEIGHT_ALL_SHARES * allShares
            val spamFactor = spam.getValue(peerId)
            val bootstrap = (
                BOOTSTRAP_WEIGHT_LONGEVITY * longevity.getValue(peerId) +
                    BOOTSTRAP_WEIGHT_RELIABILITY * reliability.getValue(peerId) +
                    BOOTSTRAP_WEIGHT_RECOMMENDATION * recommendation +
                    BOOTSTRAP_WEIGHT_REACH * reach.getValue(peerId)
                ) * spamFactor
            val ostracism = (
                WEIGHT_LONGEVITY * longevity.getValue(peerId) +
                    WEIGHT_RELIABILITY * reliability.getValue(peerId) +
                    WEIGHT_RECOMMENDATION * recommendation +
                    WEIGHT_REACH * reach.getValue(peerId)
                ) * spamFactor
            peerId to PeerScoreComponents(
                longevity = longevity.getValue(peerId),
                reliability = reliability.getValue(peerId),
                reach = reach.getValue(peerId),
                novelRecommendation = novel,
                allSharesRecommendation = allShares,
                recommendation = recommendation,
                spamFactor = spamFactor,
                baseScore = baseScores.getValue(peerId).coerceIn(0.0, 1.0),
                bootstrapScore = bootstrap.coerceIn(0.0, 1.0),
                ostracismScore = ostracism.coerceIn(0.0, 1.0)
            )
        }
    }

    private fun computeLongevityPercentiles(
        snapshots: Map<String, PeerObservationSnapshot>
    ): Map<String, Double> =
        computeLongevityPercentilesByPeer(
            snapshots.mapValues { (_, snapshot) ->
                snapshot.lastSuccessfulObservationAtMs
                    ?.let { (it - snapshot.firstSeenMs).coerceAtLeast(0L) }
                    ?: 0L
            }
        )

    private fun computeLongevityPercentilesByPeer(
        witnessedTenureByPeer: Map<String, Long>
    ): Map<String, Double> {
        if (witnessedTenureByPeer.size == 1) {
            return mapOf(witnessedTenureByPeer.keys.single() to 0.5)
        }
        val ranked = witnessedTenureByPeer.entries
            .map { (peerId, tenure) -> peerId to tenure }
            .sortedWith(compareBy<Pair<String, Long>>({ it.second }, { it.first }))
        val result = TreeMap<String, Double>()
        var groupStart = 0
        while (groupStart < ranked.size) {
            var groupEnd = groupStart
            while (
                groupEnd + 1 < ranked.size &&
                ranked[groupEnd + 1].second == ranked[groupStart].second
            ) {
                groupEnd++
            }
            val averageOneBasedRank =
                ((groupStart + 1) + (groupEnd + 1)).toDouble() / 2.0
            val percentile = averageOneBasedRank / ranked.size.toDouble()
            for (index in groupStart..groupEnd) {
                result[ranked[index].first] = percentile
            }
            groupStart = groupEnd + 1
        }
        return result
    }

    private fun computeReliability(snapshot: PeerObservationSnapshot): Double {
        val prior = snapshot.vouchPrior ?: PeerObservationLog.COLD_CONTACT_PRIOR
        if (snapshot.checks.isEmpty()) {
            return prior
        }
        val ordered = timestampOrder(snapshot.checks) { it.timestampMs }
        val coverage = coverageWeights(ordered.map { it.value.timestampMs })
        var weightedOutcome = 0.0
        var totalWeight = 0.0
        ordered.forEachIndexed { index, indexed ->
            val rank = ordered.lastIndex - index
            val weight = 2.0.pow(-rank.toDouble()) * coverage[index]
            totalWeight += weight
            if (indexed.value.outcome == PeerCheckOutcome.SUCCESS) {
                weightedOutcome += weight
            }
        }
        val observationCount = ordered.size
        val priorWeight =
            2.0.pow(-observationCount.toDouble()) / observationCount.coerceAtLeast(1)
        return ((weightedOutcome + priorWeight * prior) / (totalWeight + priorWeight))
            .coerceIn(0.0, 1.0)
    }

    private fun computeReach(snapshot: PeerObservationSnapshot): Double {
        if (snapshot.reachability.isEmpty()) {
            return 0.5
        }
        val ordered = timestampOrder(snapshot.reachability) { it.timestampMs }
        var weightedOutcome = 0.0
        var totalWeight = 0.0
        ordered.forEachIndexed { index, indexed ->
            val rank = ordered.lastIndex - index
            val weight = 2.0.pow(-rank.toDouble())
            totalWeight += weight
            if (indexed.value.outcome == PeerReachabilityOutcome.DIRECT) {
                weightedOutcome += weight
            }
        }
        return (weightedOutcome / totalWeight).coerceIn(0.0, 1.0)
    }

    private fun computeSpamFactor(snapshot: PeerObservationSnapshot): Double {
        if (snapshot.interactions.isEmpty()) {
            return 1.0
        }
        val ordered = timestampOrder(snapshot.interactions) { it.timestampMs }
        var weightedSeverity = 0.0
        var totalWeight = 0.0
        ordered.forEachIndexed { index, indexed ->
            val rank = ordered.lastIndex - index
            val weight = 2.0.pow(-rank.toDouble())
            totalWeight += weight
            weightedSeverity += weight * indexed.value.severity.value
        }
        return (1.0 - weightedSeverity / totalWeight).coerceIn(0.0, 1.0)
    }

    private fun computeRecommendationSubScore(
        snapshot: PeerObservationSnapshot,
        currentBaseScores: Map<String, Double>,
        novelOnly: Boolean
    ): Double {
        val eligible = snapshot.recommendations.values
            .filter { !novelOnly || it.wasNovel }
            .mapNotNull { recommendation ->
                val base = currentBaseScores[recommendation.recommendedPeerId]
                    ?: recommendation.lastKnownBase
                    ?: return@mapNotNull null
                recommendation to base
            }
            .sortedWith(
                compareBy<Pair<PeerRecommendationObservation, Double>>(
                    { it.first.lastSharedAtMs },
                    { it.first.lastSharedSequence },
                    { it.first.recommendedPeerId }
                )
            )
        if (eligible.isEmpty()) {
            return 0.5
        }
        var weightedBase = 0.0
        var totalWeight = 0.0
        eligible.forEachIndexed { index, (_, base) ->
            val rank = eligible.lastIndex - index
            val weight = 2.0.pow(-rank.toDouble())
            weightedBase += weight * base
            totalWeight += weight
        }
        return (weightedBase / totalWeight).coerceIn(0.0, 1.0)
    }

    private fun coverageWeights(timestamps: List<Long>): DoubleArray {
        val size = timestamps.size
        if (size == 1 || timestamps.first() == timestamps.last()) {
            return DoubleArray(size) { 1.0 / size.toDouble() }
        }
        val span = timestamps.last().toDouble() - timestamps.first().toDouble()
        return DoubleArray(size) { index ->
            val left = if (index == 0) {
                timestamps.first().toDouble()
            } else {
                midpoint(timestamps[index - 1], timestamps[index])
            }
            val right = if (index == size - 1) {
                timestamps.last().toDouble()
            } else {
                midpoint(timestamps[index], timestamps[index + 1])
            }
            (right - left) / span
        }
    }

    private fun midpoint(left: Long, right: Long): Double =
        left.toDouble() + (right.toDouble() - left.toDouble()) / 2.0

    private fun <T> timestampOrder(
        values: List<T>,
        timestamp: (T) -> Long
    ): List<IndexedValue<T>> =
        values.withIndex().sortedWith(
            compareBy<IndexedValue<T>>({ timestamp(it.value) }, { it.index })
        )
}
