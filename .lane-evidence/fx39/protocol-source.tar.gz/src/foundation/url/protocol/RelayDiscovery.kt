package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * Returns true when [addr] is a direct, publicly routable multiaddress.
 *
 * Circuit relay addresses are deliberately excluded: they may be reachable, but
 * they are not evidence that the peer itself can accept a direct mesh dial.
 */
internal fun isPublicDirectMultiaddress(addr: String): Boolean {
    if (addr.contains("/p2p-circuit/")) return false

    val ipv4Regex = Regex("""/ip4/(\d+\.\d+\.\d+\.\d+)/""")
    val ipv4Match = ipv4Regex.find(addr)
    if (ipv4Match != null) {
        return isPublicIpv4Address(ipv4Match.groupValues[1])
    }

    if (addr.contains("/ip6/")) {
        return !addr.contains("/ip6/::1/") && !addr.contains("/ip6/fe80:")
    }

    return addr.contains("/dns4/") || addr.contains("/dns6/") || addr.contains("/dnsaddr/")
}

internal fun isPublicIpv4Address(ip: String): Boolean {
    val parts = ip.split(".").mapNotNull { it.toIntOrNull() }
    if (parts.size != 4) return false

    val (a, b, _, _) = parts
    if (a == 10) return false
    if (a == 172 && b in 16..31) return false
    if (a == 192 && b == 168) return false
    if (a == 127) return false
    if (a == 169 && b == 254) return false
    if (a == 0) return false
    if (a >= 224) return false

    return true
}

/**
 * Discovers and manages available relay peers for NAT traversal.
 *
 * This class:
 * - Tracks known relay peers discovered via gossip
 * - Provides relay selection based on configurable strategies
 * - Measures relay latency for optimal selection
 *
 * ## Usage
 * ```kotlin
 * val discovery = RelayDiscovery(relayService, peerRegistry)
 *
 * // Discover relays from gossip
 * discovery.onRelayAnnouncement(announcement)
 *
 * // Select the best relay
 * val relay = discovery.selectBestRelay()
 *
 * // Select relay for a specific target
 * val relayForTarget = discovery.selectBestRelay(targetPeerId = "Qm...")
 * ```
 */
class RelayDiscovery(
    private val relayService: RelayService,
    private val peerRegistry: PeerRegistry,
    private val config: RelayConfig = RelayConfig(),
    private val clock: Clock = SystemClock()
) : AutoCloseable {

    /**
     * Known relay peers indexed by peer ID.
     */
    private val knownRelays = ConcurrentHashMap<String, RelayInfo>()

    /**
     * Local measurement age is maintenance state, not part of the public [RelayInfo] contract.
     */
    private val latencyMeasuredAtByPeer = ConcurrentHashMap<String, Long>()

    /**
     * Round-robin index for ROUND_ROBIN selection strategy.
     */
    private var roundRobinIndex = 0

    /**
     * Guards against more than one background latency sweep running at a time.
     */
    private val latencyRefreshInFlight = AtomicBoolean(false)

    private companion object {
        /**
         * How old a latency measurement may be before the background refresher measures it again.
         * This paces maintenance; it is not a bound on any caller, because no caller ever waits
         * for a measurement.
         */
        const val LATENCY_REMEASURE_INTERVAL_MS = 5 * 60 * 1000L
    }

    /**
     * Runs latency probes away from the connection-establishment path. A single thread is
     * deliberate: probing is background maintenance, and each probe dials a relay, so widening
     * this would reintroduce the dial storm that selection used to cause inline.
     */
    private val latencyRefreshExecutor: ExecutorService =
        Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "relay-latency-refresh").apply { isDaemon = true }
        }

    /**
     * Gets all known relays.
     */
    fun getAllRelays(): List<RelayInfo> = knownRelays.values.toList()

    /**
     * Gets relays that have capacity for new clients.
     */
    fun getAvailableRelays(): List<RelayInfo> = knownRelays.values.filter { it.hasCapacity() }

    /**
     * Gets relays that have capacity and are publicly reachable.
     * Filters out relays that only have private/local IP addresses or circuit relay addresses.
     */
    fun getPubliclyReachableRelays(): List<RelayInfo> = getAvailableRelays().filter { relay ->
        relay.multiaddresses.any { addr -> isPublicAddress(addr) }
    }

    /**
     * Checks if a multiaddress is a public (non-local, non-circuit) address.
     */
    internal fun isPublicAddress(addr: String): Boolean {
        return isPublicDirectMultiaddress(addr)
    }

    /**
     * Checks if an IPv4 address is publicly routable (not private or reserved).
     */
    internal fun isPublicIpv4(ip: String): Boolean {
        return isPublicIpv4Address(ip)
    }

    /**
     * Gets the number of known relays.
     */
    val relayCount: Int
        get() = knownRelays.size

    /**
     * Handles a relay announcement received via gossip.
     */
    fun onRelayAnnouncement(announcement: RelayProtocol.RelayAnnouncement) {
        var accepted: RelayInfo? = null
        knownRelays.compute(announcement.peerId) { _, existing ->
            if (existing != null && announcement.timestamp <= existing.lastSeen) {
                existing
            } else {
                val updated = RelayInfo(
                    peerId = announcement.peerId,
                    multiaddresses = announcement.multiaddresses,
                    maxClients = announcement.maxClients,
                    currentClients = announcement.currentClients,
                    lastSeen = clock.currentTimeMillis(),
                    // Announcements carry no latency. Preserve the locally measured value so
                    // normal gossip does not make this peer look unmeasured again.
                    latencyMs = existing?.latencyMs,
                    metadata = announcement.metadata
                )
                accepted = updated
                updated
            }
        }

        accepted?.let { relay ->
            // PeerRegistry may persist the update, so keep that external work outside the
            // ConcurrentHashMap computation for this relay.
            peerRegistry.addImportedPeer(
                Libp2pPeer.remote(
                    peerId = relay.peerId,
                    multiaddresses = relay.multiaddresses,
                    advertisedServices = emptyList()
                ),
                freshness = null,
                exchangeElapsedMillis = 0L,
                origin = PeerRegistryAddOrigin.RELAY
            )
        }
    }

    /**
     * Handles a relay withdrawal received via gossip.
     */
    fun onRelayWithdrawal(withdrawal: RelayProtocol.RelayWithdrawal) {
        removeRelay(withdrawal.peerId)
    }

    /**
     * Selects the best relay based on the configured strategy.
     *
     * Prefers publicly reachable relays (those with public IP addresses).
     * Only falls back to all available relays if no public ones are found.
     *
     * @param targetPeerId Optional destination peer ID. The destination is excluded because a
     *                     peer cannot act as the relay used to reach itself.
     * @return The best relay, or null if no suitable relay is found.
     */
    fun selectBestRelay(targetPeerId: String? = null): RelayInfo? {
        val availableRelays = getAvailableRelays().filter { relay -> relay.peerId != targetPeerId }

        // First, try to find publicly reachable relays (with public IP addresses)
        val publicRelays = availableRelays.filter { relay ->
            relay.multiaddresses.any { addr -> isPublicAddress(addr) }
        }
        val candidates = if (publicRelays.isNotEmpty()) {
            debugLog { "[RELAY-DISCOVERY] Found ${publicRelays.size} publicly reachable relay(s), using those" }
            publicRelays
        } else {
            // Fall back to all available relays if no public ones found
            debugLog { "[RELAY-DISCOVERY] No publicly reachable relays found, falling back to ${availableRelays.size} available relay(s)" }
            availableRelays
        }

        if (candidates.isEmpty()) return null

        return when (config.selectionStrategy) {
            RelaySelectionStrategy.FASTEST -> selectFastestRelay(candidates)
            RelaySelectionStrategy.RANDOM -> selectRandomRelay(candidates)
            RelaySelectionStrategy.ROUND_ROBIN -> selectRoundRobinRelay(candidates)
        }
    }

    /**
     * Selects the relay with the lowest latency.
     *
     * @param candidates List of candidate relays.
     * @return The fastest relay.
     */
    private fun selectFastestRelay(candidates: List<RelayInfo>): RelayInfo? {
        if (candidates.isEmpty()) return null
        if (candidates.size == 1) return candidates.first()

        // Relay selection runs on the synchronous connection-establishment path, underneath the
        // process-wide cold-factory admission permit held by LazyReconnectingMethodDispatcher.
        // It must therefore do no network work at all. Measuring latency here used to call
        // measureLatency() -> RelayService.pingRelay(), which dials the relay (a full transport
        // dial plus noise handshake whenever the host has no existing connection to it), waits up
        // to five seconds for a pong, and then closes the connection again -- once per candidate,
        // serially. With a large relay population that turns a single connection attempt into
        // minutes of blocking work while every other caller in the process queues behind the two
        // available permits.
        //
        // Selection now reads only measurements that have already been taken, and asks the
        // background refresher to fill in the rest. Preferring a relay with a real measurement
        // over an unmeasured one, and an unmeasured one over a relay already known to be
        // unreachable, keeps FASTEST meaningful without dialing anything here.
        requestBackgroundLatencyRefresh(candidates)

        val reachable = candidates.filter { it.latencyMs != null && it.latencyMs != Long.MAX_VALUE }
        if (reachable.isNotEmpty()) return reachable.minByOrNull { it.latencyMs ?: Long.MAX_VALUE }

        return candidates.firstOrNull { it.latencyMs == null } ?: candidates.first()
    }

    /**
     * Measures latency for candidates that have none, on a background thread.
     *
     * Only one refresh runs at a time: the probe is maintenance, not part of serving a
     * connection, and a second concurrent sweep would only re-dial the same relays. Results --
     * including failures -- are recorded in [knownRelays] so that an unreachable relay is not
     * re-dialed by every subsequent selection.
     */
    private fun requestBackgroundLatencyRefresh(candidates: List<RelayInfo>) {
        val now = clock.currentTimeMillis()
        val due = candidates.filter { relay ->
            val measuredAt = latencyMeasuredAtByPeer[relay.peerId]
            // Never measured, or the measurement has aged out. Carrying a measurement forward
            // across announcements is what stops the re-dial storm; ageing it out is what stops
            // a single early measurement from being trusted forever.
            relay.latencyMs == null || measuredAt == null || now - measuredAt >= LATENCY_REMEASURE_INTERVAL_MS
        }
        if (due.isEmpty()) return
        if (!latencyRefreshInFlight.compareAndSet(false, true)) return

        val peerIds = due.map { it.peerId }
        try {
            latencyRefreshExecutor.execute {
                try {
                    peerIds.forEach(::measureAndRecordLatency)
                } finally {
                    latencyRefreshInFlight.set(false)
                }
            }
        } catch (e: RejectedExecutionException) {
            // The refresher is shut down; selection continues on existing measurements.
            latencyRefreshInFlight.set(false)
        }
    }

    /**
     * Measures one relay's latency and records the outcome, so that both successes and failures
     * are remembered rather than re-measured on every selection.
     */
    private fun measureAndRecordLatency(relayPeerId: String) {
        if (!knownRelays.containsKey(relayPeerId)) return
        val latency = try {
            measureLatency(relayPeerId)
        } catch (e: Exception) {
            // Record the failure rather than dropping it: an unrecorded failure made the relay
            // look unmeasured again, so the next selection re-dialed it.
            Long.MAX_VALUE
        }
        val measuredAt = clock.currentTimeMillis()
        knownRelays.computeIfPresent(relayPeerId) { _, current ->
            // This update is ordered with announcements for the same peer. If an announcement
            // arrived during the probe, attach the completed measurement to its newer addresses
            // and capacity instead of discarding either update.
            latencyMeasuredAtByPeer[relayPeerId] = measuredAt
            current.copy(latencyMs = latency)
        }
    }

    /**
     * Stops the background latency refresher. Idempotent.
     */
    override fun close() {
        latencyRefreshExecutor.shutdownNow()
    }

    /**
     * Selects a random relay from candidates.
     */
    private fun selectRandomRelay(candidates: List<RelayInfo>): RelayInfo? {
        if (candidates.isEmpty()) return null
        return candidates[Random.nextInt(candidates.size)]
    }

    /**
     * Selects the next relay in round-robin fashion.
     */
    private fun selectRoundRobinRelay(candidates: List<RelayInfo>): RelayInfo? {
        if (candidates.isEmpty()) return null
        val index = roundRobinIndex++ % candidates.size
        return candidates[index]
    }

    /**
     * Measures latency to a relay peer.
     *
     * @param relayPeerId The peer ID of the relay.
     * @return Latency in milliseconds.
     */
    fun measureLatency(relayPeerId: String): Long {
        return relayService.pingRelay(relayPeerId)
    }

    /**
     * Updates latency measurements for all known relays.
     *
     * @param maxConcurrent Maximum concurrent ping operations.
     */
    fun refreshLatencies(maxConcurrent: Int = 5) {
        require(maxConcurrent >= 1) {
            "maxConcurrent must be at least 1 to measure any relay, but was $maxConcurrent"
        }
        val relays = getAllRelays()
        if (relays.isEmpty()) return

        // Previously this chunked the relays and then iterated each chunk with a plain forEach,
        // which measured every relay one after another however large maxConcurrent was. Probes are
        // network-bound, so honour the requested concurrency instead of measuring the whole
        // population serially.
        val pool = Executors.newFixedThreadPool(minOf(maxConcurrent, relays.size)) { runnable ->
            Thread(runnable, "relay-latency-refresh-batch").apply { isDaemon = true }
        }
        try {
            pool.invokeAll(relays.map { relay -> java.util.concurrent.Callable { measureAndRecordLatency(relay.peerId) } })
        } finally {
            pool.shutdownNow()
        }
    }

    /**
     * Removes stale relays that haven't been seen recently.
     *
     * @param maxAgeMs Maximum age in milliseconds.
     * @return Number of relays removed.
     */
    fun pruneStaleRelays(maxAgeMs: Long = 5 * 60 * 1000): Int {
        val cutoff = clock.currentTimeMillis() - maxAgeMs
        val stale = knownRelays.filter { it.value.lastSeen < cutoff }
        var removed = 0
        stale.keys.forEach { peerId ->
            knownRelays.computeIfPresent(peerId) { _, current ->
                if (current.lastSeen < cutoff) {
                    latencyMeasuredAtByPeer.remove(peerId)
                    removed++
                    null
                } else {
                    current
                }
            }
        }
        return removed
    }

    /**
     * Discovers relays by querying known peers.
     *
     * This method contacts bootstrap peers and asks them for known relays.
     *
     * @return Number of new relays discovered.
     */
    fun discoverRelays(): Int {
        val initialCount = knownRelays.size

        // Query bootstrap peers for relay information
        // This is handled by the gossip protocol integration

        return knownRelays.size - initialCount
    }

    /**
     * Adds a relay manually (useful for testing or bootstrap).
     */
    fun addRelay(relay: RelayInfo) {
        knownRelays.compute(relay.peerId) { _, _ ->
            if (relay.latencyMs == null) {
                latencyMeasuredAtByPeer.remove(relay.peerId)
            } else {
                latencyMeasuredAtByPeer[relay.peerId] = clock.currentTimeMillis()
            }
            relay
        }
    }

    /**
     * Removes a relay from the known list.
     */
    fun removeRelay(peerId: String): RelayInfo? {
        var removed: RelayInfo? = null
        knownRelays.compute(peerId) { _, current ->
            removed = current
            latencyMeasuredAtByPeer.remove(peerId)
            null
        }
        return removed
    }

    /**
     * Gets a relay by peer ID.
     */
    fun getRelay(peerId: String): RelayInfo? {
        return knownRelays[peerId]
    }

    /**
     * Checks if a peer ID is a known relay.
     */
    fun isKnownRelay(peerId: String): Boolean {
        return knownRelays.containsKey(peerId)
    }

    /**
     * Clears all known relays.
     */
    fun clear() {
        knownRelays.clear()
        latencyMeasuredAtByPeer.clear()
        roundRobinIndex = 0
    }
}

/**
 * Builder for creating RelayDiscovery instances with custom configuration.
 */
class RelayDiscoveryBuilder {
    private var relayService: RelayService? = null
    private var peerRegistry: PeerRegistry? = null
    private var config: RelayConfig = RelayConfig()
    private var clock: Clock = SystemClock()

    fun relayService(service: RelayService) = apply { this.relayService = service }
    fun peerRegistry(registry: PeerRegistry) = apply { this.peerRegistry = registry }
    fun config(config: RelayConfig) = apply { this.config = config }
    fun clock(clock: Clock) = apply { this.clock = clock }
    fun selectionStrategy(strategy: RelaySelectionStrategy) = apply {
        this.config = config.copy(selectionStrategy = strategy)
    }

    fun build(): RelayDiscovery {
        val service = relayService ?: throw IllegalStateException("RelayService is required")
        val registry = peerRegistry ?: throw IllegalStateException("PeerRegistry is required")
        return RelayDiscovery(service, registry, config, clock)
    }
}
