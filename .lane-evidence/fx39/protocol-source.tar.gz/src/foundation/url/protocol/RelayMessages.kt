package foundation.url.protocol

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

internal class RelayRequestFieldParsingException(message: String) : IllegalArgumentException(message)

/**
 * Protocol for peer-to-peer relaying across the P2P network.
 *
 * This protocol enables NAT-ed peers to receive incoming connections by registering
 * with publicly-reachable relay nodes. Any peer with a public IP can serve as a relay
 * for other peers behind NAT.
 *
 * Features:
 * - Relay announcements via gossip protocol
 * - Peer registration with relay nodes
 * - Request forwarding through relay connections
 * - Ping-based relay selection for lowest latency
 */
object RelayProtocol {
    const val PROTOCOL_ID = "/urlresolver-relay/1.0.0"

    // Message types
    const val TYPE_RELAY_ANNOUNCE = "relay_announce"
    const val TYPE_RELAY_WITHDRAW = "relay_withdraw"
    const val TYPE_RELAY_REGISTER = "relay_register"
    const val TYPE_RELAY_REGISTER_ACK = "relay_register_ack"
    const val TYPE_RELAY_UNREGISTER = "relay_unregister"
    const val TYPE_RELAY_UNREGISTER_ACK = "relay_unregister_ack"
    const val TYPE_RELAY_REQUEST = "relay_request"
    const val TYPE_RELAY_RESPONSE = "relay_response"
    const val TYPE_RELAY_PING = "relay_ping"
    const val TYPE_RELAY_PONG = "relay_pong"
    const val TYPE_RELAY_KEEPALIVE = "relay_keepalive"
    const val TYPE_RELAY_PEER_LIST = "relay_peer_list"
    const val TYPE_DISTANCE_VECTOR = "distance_vector"

    // Default configuration
    const val DEFAULT_TTL = 7
    const val DEFAULT_MAX_CLIENTS = 100
    // Use 15 second keepalive to detect NAT timeouts before they occur (commonly 20-30s)
    const val DEFAULT_KEEPALIVE_INTERVAL_MS = 15_000L
    const val DEFAULT_REGISTRATION_TIMEOUT_MS = 60_000L

    private val messageIdCounter = AtomicLong(0)

    /**
     * Distinguishes the ids minted by this process from those minted by every other process.
     *
     * A message id travels to other peers and is used by them as a correlation key, so it has to be
     * unique across PROCESSES, not merely within one. A millisecond plus a counter that restarts
     * at zero in every process is not: peers that start together and then do the same work advance
     * their counters in step, so they mint the same ids at the same moments, and a receiver keyed on
     * the id alone then treats two peers' messages as one.
     */
    private val messageIdProcessNonce: String =
        java.lang.Long.toUnsignedString(java.security.SecureRandom().nextLong(), 36)

    /**
     * Generates a unique message ID for relay messages. The id is unique across every process that
     * mints one, not only within this process.
     */
    fun nextMessageId(): String =
        "relay-${System.currentTimeMillis()}-$messageIdProcessNonce-${messageIdCounter.incrementAndGet()}"

    /**
     * Relay announcement broadcast via gossip protocol.
     *
     * Publicly-reachable peers broadcast this to advertise themselves as relays.
     * NAT-ed peers listen for these announcements to discover available relays.
     */
    class RelayAnnouncement(
        val messageId: String,
        val peerId: String,
        val multiaddresses: List<String>,
        val maxClients: Int = DEFAULT_MAX_CLIENTS,
        val currentClients: Int = 0,
        val metadata: Map<String, String> = emptyMap(),
        val timestamp: Long = System.currentTimeMillis(),
        val ttl: Int = DEFAULT_TTL
    ) {
        private var _freshness: PeerFreshness? = null
        val freshness: PeerFreshness? get() = _freshness

        constructor(
            messageId: String,
            peerId: String,
            multiaddresses: List<String>,
            maxClients: Int,
            currentClients: Int,
            metadata: Map<String, String>,
            timestamp: Long,
            ttl: Int,
            freshness: PeerFreshness?
        ) : this(messageId, peerId, multiaddresses, maxClients, currentClients, metadata, timestamp, ttl) {
            _freshness = freshness
        }

        fun withFreshness(freshness: PeerFreshness?): RelayAnnouncement = copy().also { it._freshness = freshness }
        fun withFreshnessAgedBy(elapsedMillis: Long): RelayAnnouncement = withFreshness(freshness?.agedBy(elapsedMillis))

        operator fun component1(): String = messageId
        operator fun component2(): String = peerId
        operator fun component3(): List<String> = multiaddresses
        operator fun component4(): Int = maxClients
        operator fun component5(): Int = currentClients
        operator fun component6(): Map<String, String> = metadata
        operator fun component7(): Long = timestamp
        operator fun component8(): Int = ttl

        fun copy(
            messageId: String = this.messageId,
            peerId: String = this.peerId,
            multiaddresses: List<String> = this.multiaddresses,
            maxClients: Int = this.maxClients,
            currentClients: Int = this.currentClients,
            metadata: Map<String, String> = this.metadata,
            timestamp: Long = this.timestamp,
            ttl: Int = this.ttl
        ): RelayAnnouncement {
            val result = RelayAnnouncement(messageId, peerId, multiaddresses, maxClients, currentClients, metadata, timestamp, ttl, if (peerId == this.peerId) freshness else null)
            return result
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is RelayAnnouncement) return false
            return messageId == other.messageId &&
                peerId == other.peerId &&
                multiaddresses == other.multiaddresses &&
                maxClients == other.maxClients &&
                currentClients == other.currentClients &&
                metadata == other.metadata &&
                timestamp == other.timestamp &&
                ttl == other.ttl && freshness == other.freshness
        }

        override fun hashCode(): Int {
            val legacyHash = peerFreshnessDataClassHash(messageId, peerId, multiaddresses, maxClients, currentClients, metadata, timestamp, ttl)
            return if (freshness == null) legacyHash else 31 * legacyHash + freshness.hashCode()
        }

        override fun toString(): String {
            val legacy = "RelayAnnouncement(" + listOf("messageId=$messageId", "peerId=$peerId", "multiaddresses=$multiaddresses", "maxClients=$maxClients", "currentClients=$currentClients", "metadata=$metadata", "timestamp=$timestamp", "ttl=$ttl").joinToString(", ") + ")"
            return if (freshness == null) legacy else legacy.substring(0, legacy.length - 1) + ", freshness=$freshness)"
        }


        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_ANNOUNCE)
                put("messageId", messageId)
                put("peerId", peerId)
                put("multiaddresses", JSONArray(multiaddresses))
                put("maxClients", maxClients)
                put("currentClients", currentClients)
                put("metadata", JSONObject(metadata))
                put("timestamp", timestamp)
                put("ttl", ttl)

                freshness?.let { put("freshness", it.toJson()) }
            }
        }

        fun withDecrementedTtl(): RelayAnnouncement = copy(ttl = ttl - 1)
        fun shouldPropagate(): Boolean = ttl > 0
        fun hasCapacity(): Boolean = currentClients < maxClients

        companion object {
            fun fromJson(json: JSONObject): RelayAnnouncement {
                val multiaddrs = mutableListOf<String>()
                val addrsArray = json.getJSONArray("multiaddresses")
                for (i in 0 until addrsArray.length()) {
                    multiaddrs.add(addrsArray.getString(i))
                }

                val metadata = mutableMapOf<String, String>()
                val metadataObj = json.optJSONObject("metadata")
                if (metadataObj != null) {
                    for (key in metadataObj.keys()) {
                        metadata[key] = metadataObj.getString(key)
                    }
                }

                return RelayAnnouncement(
                    messageId = json.getString("messageId"),
                    peerId = json.getString("peerId"),
                    multiaddresses = multiaddrs,
                    maxClients = json.optInt("maxClients", DEFAULT_MAX_CLIENTS),
                    currentClients = json.optInt("currentClients", 0),
                    metadata = metadata,
                    timestamp = json.getLong("timestamp"),
                    ttl = json.getInt("ttl"),
                    freshness = PeerFreshness.fromJson(json.optJSONObject("freshness")),
                )
            }
        }

        fun withDecrementedTtl(elapsedMillis: Long): RelayAnnouncement =
            withDecrementedTtl().withFreshness(freshness?.agedBy(elapsedMillis))

    }

    /**
     * Relay withdrawal broadcast via gossip protocol.
     *
     * Sent when a relay is no longer available.
     */
    data class RelayWithdrawal(
        val messageId: String,
        val peerId: String,
        val timestamp: Long = System.currentTimeMillis(),
        val ttl: Int = DEFAULT_TTL
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_WITHDRAW)
                put("messageId", messageId)
                put("peerId", peerId)
                put("timestamp", timestamp)
                put("ttl", ttl)
            }
        }

        fun withDecrementedTtl(): RelayWithdrawal = copy(ttl = ttl - 1)
        fun shouldPropagate(): Boolean = ttl > 0

        companion object {
            fun fromJson(json: JSONObject): RelayWithdrawal {
                return RelayWithdrawal(
                    messageId = json.getString("messageId"),
                    peerId = json.getString("peerId"),
                    timestamp = json.getLong("timestamp"),
                    ttl = json.getInt("ttl")
                )
            }
        }
    }

    /**
     * Registration request from a NAT-ed peer to a relay.
     *
     * NAT-ed peers send this to a relay to register for incoming requests.
     * The relay will then forward any requests for this peer.
     */
    data class RelayRegister(
        val requestId: String,
        val peerId: String,
        val advertisedServices: List<String> = emptyList(),
        /** The registering peer's own multiaddresses (for direct connection, if publicly reachable) */
        val multiaddresses: List<String> = emptyList(),
        val metadata: Map<String, String> = emptyMap(),
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_REGISTER)
                put("requestId", requestId)
                put("peerId", peerId)
                put("advertisedServices", JSONArray(advertisedServices))
                put("multiaddresses", JSONArray(multiaddresses))
                put("metadata", JSONObject(metadata))
                put("timestamp", timestamp)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): RelayRegister {
                val services = mutableListOf<String>()
                val servicesArray = json.optJSONArray("advertisedServices")
                if (servicesArray != null) {
                    for (i in 0 until servicesArray.length()) {
                        services.add(servicesArray.getString(i))
                    }
                }

                val multiaddrs = mutableListOf<String>()
                val multiaddrsArray = json.optJSONArray("multiaddresses")
                if (multiaddrsArray != null) {
                    for (i in 0 until multiaddrsArray.length()) {
                        multiaddrs.add(multiaddrsArray.getString(i))
                    }
                }

                val metadata = mutableMapOf<String, String>()
                val metadataObj = json.optJSONObject("metadata")
                if (metadataObj != null) {
                    for (key in metadataObj.keys()) {
                        metadata[key] = metadataObj.getString(key)
                    }
                }

                return RelayRegister(
                    requestId = json.getString("requestId"),
                    peerId = json.getString("peerId"),
                    advertisedServices = services,
                    multiaddresses = multiaddrs,
                    metadata = metadata,
                    timestamp = json.getLong("timestamp")
                )
            }
        }
    }

    /**
     * Acknowledgement of registration from relay to NAT-ed peer.
     */
    data class RelayRegisterAck(
        val requestId: String,
        val success: Boolean,
        val relayPeerId: String,
        val errorMessage: String? = null,
        val expiresAt: Long = System.currentTimeMillis() + DEFAULT_REGISTRATION_TIMEOUT_MS
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_REGISTER_ACK)
                put("requestId", requestId)
                put("success", success)
                put("relayPeerId", relayPeerId)
                errorMessage?.let { put("errorMessage", it) }
                put("expiresAt", expiresAt)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): RelayRegisterAck {
                return RelayRegisterAck(
                    requestId = json.getString("requestId"),
                    success = json.getBoolean("success"),
                    relayPeerId = json.getString("relayPeerId"),
                    errorMessage = json.optString("errorMessage", null),
                    expiresAt = json.optLong("expiresAt", 0)
                )
            }
        }
    }

    /**
     * Unregistration request from a NAT-ed peer.
     */
    data class RelayUnregister @JvmOverloads constructor(
        val requestId: String,
        val peerId: String,
        val registrationRequestId: String? = null,
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_UNREGISTER)
                put("requestId", requestId)
                put("peerId", peerId)
                registrationRequestId?.let { put("registrationRequestId", it) }
            }
        }

        companion object {
            fun fromJson(json: JSONObject): RelayUnregister {
                return RelayUnregister(
                    requestId = json.getString("requestId"),
                    peerId = json.getString("peerId"),
                    registrationRequestId = if (json.has("registrationRequestId"))
                        json.getString("registrationRequestId") else null
                )
            }
        }
    }

    /**
     * Confirms that the relay parsed an unregistration request and atomically committed its
     * registration-state transition. Withdrawal publication may continue asynchronously after
     * this acknowledgement, but the client can safely tear down its relay stream without racing
     * the request itself.
     */
    data class RelayUnregisterAck(
        val requestId: String,
        val success: Boolean,
        val relayPeerId: String,
        val errorMessage: String? = null
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_UNREGISTER_ACK)
                put("requestId", requestId)
                put("success", success)
                put("relayPeerId", relayPeerId)
                errorMessage?.let { put("errorMessage", it) }
            }
        }

        companion object {
            fun fromJson(json: JSONObject): RelayUnregisterAck {
                return RelayUnregisterAck(
                    requestId = json.getString("requestId"),
                    success = json.getBoolean("success"),
                    relayPeerId = json.getString("relayPeerId"),
                    errorMessage = json.optString("errorMessage", null)
                )
            }
        }
    }

    /**
     * Request to be forwarded through the relay to a target peer.
     *
     * Clients send this to a relay when they need to reach a NAT-ed peer.
     * The relay forwards the payload to the registered target peer.
     */
    data class RelayRequest(
        val requestId: String,
        val sourcePeerId: String,
        val targetPeerId: String,
        val payload: String,  // Base64-encoded request data (one chunk when totalChunks > 1)
        val path: String = "",
        val headers: Map<String, String> = emptyMap(),
        val timestamp: Long = System.currentTimeMillis(),
        // Chunked-request support: a large payload is split into [totalChunks]
        // frames sharing a [transferId]; the receiver reassembles them before
        // invoking the handler. Defaults (transferId="", chunkSeq=0,
        // totalChunks=1) mean "single, whole payload" — fully backward compatible.
        // When present on the wire, both numeric fields must be exact signed-Int JSON values.
        val transferId: String = "",
        val chunkSeq: Int = 0,
        val totalChunks: Int = 1,
        val hopLimit: Int = DEFAULT_RELAY_REQUEST_HOP_LIMIT
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_REQUEST)
                put("requestId", requestId)
                put("sourcePeerId", sourcePeerId)
                put("targetPeerId", targetPeerId)
                put("payload", payload)
                put("path", path)
                put("headers", JSONObject(headers))
                put("timestamp", timestamp)
                put("transferId", transferId)
                put("chunkSeq", chunkSeq)
                put("totalChunks", totalChunks)
                put("hopLimit", hopLimit)
            }
        }

        fun withDecrementedHopLimit(): RelayRequest = copy(hopLimit = hopLimit - 1)

        companion object {
            private fun strictJsonInt(
                json: JSONObject,
                fieldName: String,
                absentDefault: Int,
            ): Int {
                if (!json.has(fieldName)) return absentDefault
                val rawValue = json.get(fieldName)
                val parsed = when (rawValue) {
                    is Int -> rawValue
                    is Byte -> rawValue.toInt()
                    is Short -> rawValue.toInt()
                    is Long -> if (
                        rawValue in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()
                    ) rawValue.toInt() else null
                    is java.math.BigInteger -> if (
                        rawValue >= java.math.BigInteger.valueOf(Int.MIN_VALUE.toLong()) &&
                        rawValue <= java.math.BigInteger.valueOf(Int.MAX_VALUE.toLong())
                    ) rawValue.toInt() else null
                    is java.math.BigDecimal -> try {
                        strictJsonIntValue(rawValue.intValueExact())
                    } catch (_: ArithmeticException) {
                        null
                    }
                    is Double -> if (
                        rawValue.isFinite() && rawValue == Math.floor(rawValue) &&
                        rawValue >= Int.MIN_VALUE.toDouble() &&
                        rawValue <= Int.MAX_VALUE.toDouble()
                    ) rawValue.toInt() else null
                    is Float -> strictJsonIntValue(rawValue.toDouble())
                    else -> null
                }
                if (parsed != null) return parsed

                val renderedValue = when (rawValue) {
                    JSONObject.NULL -> "null"
                    is String -> JSONObject.quote(rawValue)
                    else -> rawValue.toString()
                }
                throw RelayRequestFieldParsingException(
                    "Relay request field '$fieldName' must be a JSON integer from " +
                        "${Int.MIN_VALUE} through ${Int.MAX_VALUE}, but the provided value was " +
                        renderedValue
                )
            }

            private fun strictJsonIntValue(rawValue: Int): Int = rawValue

            private fun strictJsonIntValue(rawValue: Double): Int? =
                if (
                    rawValue.isFinite() && rawValue == Math.floor(rawValue) &&
                    rawValue >= Int.MIN_VALUE.toDouble() &&
                    rawValue <= Int.MAX_VALUE.toDouble()
                ) rawValue.toInt() else null

            fun fromJson(json: JSONObject): RelayRequest {
                val headers = mutableMapOf<String, String>()
                val headersObj = json.optJSONObject("headers")
                if (headersObj != null) {
                    for (key in headersObj.keys()) {
                        headers[key] = headersObj.getString(key)
                    }
                }

                return RelayRequest(
                    requestId = json.getString("requestId"),
                    sourcePeerId = json.getString("sourcePeerId"),
                    targetPeerId = json.getString("targetPeerId"),
                    payload = json.getString("payload"),
                    path = json.optString("path", ""),
                    headers = headers,
                    timestamp = json.getLong("timestamp"),
                    transferId = json.optString("transferId", ""),
                    chunkSeq = strictJsonInt(json, "chunkSeq", 0),
                    totalChunks = strictJsonInt(json, "totalChunks", 1),
                    hopLimit = json.optInt("hopLimit", DEFAULT_RELAY_REQUEST_HOP_LIMIT)
                )
            }
        }
    }

    /**
     * Response from the target peer, forwarded back through the relay.
     */
    data class RelayResponse(
        val requestId: String,
        val sourcePeerId: String,
        val targetPeerId: String,
        val payload: String,  // Base64-encoded response data
        val success: Boolean = true,
        val errorMessage: String? = null,
        val timestamp: Long = System.currentTimeMillis(),
        // True for the intermediate ack of a non-final request chunk (see
        // chunked-request support in RelayService): the real handler hasn't run
        // yet, this just acknowledges receipt so the sender streams the next chunk.
        val chunkAck: Boolean = false
    ) {
        /** True only when the relay guarantees that no target handler received this request. */
        fun wasDefinitelyNotDispatched(): Boolean =
            !success && errorMessage?.startsWith(NOT_DISPATCHED_ERROR_PREFIX) == true

        /** Error text without the transport-only delivery-state marker. */
        fun displayErrorMessage(): String? = errorMessage?.removePrefix(NOT_DISPATCHED_ERROR_PREFIX)

        /**
         * Clears a reserved transport claim from an application handler's response. A handler has
         * already received the request by definition, so its error must remain delivery-ambiguous
         * even if its text begins with the transport marker.
         */
        internal fun withoutNotDispatchedMarker(): RelayResponse {
            if (!wasDefinitelyNotDispatched()) return this
            var sanitized = errorMessage ?: return this
            while (sanitized.startsWith(NOT_DISPATCHED_ERROR_PREFIX)) {
                sanitized = sanitized.removePrefix(NOT_DISPATCHED_ERROR_PREFIX)
            }
            return copy(errorMessage = sanitized)
        }

        // The payload carries the frame header and content. With the newer response capability,
        // the existing optional text field also carries the exact content length on a successful
        // response. Older intermediaries retain both fields when reading and writing the envelope.
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_RESPONSE)
                put("requestId", requestId)
                put("sourcePeerId", sourcePeerId)
                put("targetPeerId", targetPeerId)
                put("payload", payload)
                put("success", success)
                errorMessage?.let { put("errorMessage", it) }
                put("timestamp", timestamp)
                put("chunkAck", chunkAck)
            }
        }

        companion object {
            private const val NOT_DISPATCHED_ERROR_PREFIX = "relay:not-dispatched:"

            fun fromJson(json: JSONObject): RelayResponse {
                return RelayResponse(
                    requestId = json.getString("requestId"),
                    sourcePeerId = json.getString("sourcePeerId"),
                    targetPeerId = json.getString("targetPeerId"),
                    payload = json.getString("payload"),
                    success = json.optBoolean("success", true),
                    errorMessage = json.optString("errorMessage", null),
                    timestamp = json.getLong("timestamp"),
                    chunkAck = json.optBoolean("chunkAck", false)
                )
            }

            fun error(requestId: String, sourcePeerId: String, targetPeerId: String, errorMessage: String): RelayResponse {
                return RelayResponse(
                    requestId = requestId,
                    sourcePeerId = sourcePeerId,
                    targetPeerId = targetPeerId,
                    payload = "",
                    success = false,
                    errorMessage = errorMessage
                )
            }

            /**
             * Builds a backward-compatible error response that states the target did not receive
             * request bytes. The marker rides in errorMessage so older relays preserve it while
             * parsing and re-serializing the envelope.
             */
            fun notDispatchedError(
                requestId: String,
                sourcePeerId: String,
                targetPeerId: String,
                errorMessage: String
            ): RelayResponse = error(
                requestId,
                sourcePeerId,
                targetPeerId,
                NOT_DISPATCHED_ERROR_PREFIX + errorMessage
            )
        }
    }

    /**
     * Ping message for latency measurement.
     */
    data class RelayPing(
        val id: String,
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_PING)
                put("id", id)
                put("timestamp", timestamp)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): RelayPing {
                return RelayPing(
                    id = json.getString("id"),
                    timestamp = json.getLong("timestamp")
                )
            }
        }
    }

    /**
     * Pong response for latency measurement.
     */
    data class RelayPong(
        val id: String,
        val originalTimestamp: Long,
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_PONG)
                put("id", id)
                put("originalTimestamp", originalTimestamp)
                put("timestamp", timestamp)
            }
        }

        /**
         * Calculate round-trip latency in milliseconds.
         */
        fun calculateLatencyMs(): Long = timestamp - originalTimestamp

        companion object {
            fun fromJson(json: JSONObject): RelayPong {
                return RelayPong(
                    id = json.getString("id"),
                    originalTimestamp = json.getLong("originalTimestamp"),
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            }

            fun fromPing(ping: RelayPing): RelayPong {
                return RelayPong(
                    id = ping.id,
                    originalTimestamp = ping.timestamp
                )
            }
        }
    }

    /**
     * Keepalive message to maintain registration.
     */
    data class RelayKeepalive(
        val peerId: String,
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_KEEPALIVE)
                put("peerId", peerId)
                put("timestamp", timestamp)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): RelayKeepalive {
                return RelayKeepalive(
                    peerId = json.getString("peerId"),
                    timestamp = json.getLong("timestamp")
                )
            }
        }
    }

    /**
     * Peer list message sent by relay to inform clients about other registered peers.
     * This is sent to newly registered peers to inform them of existing peers,
     * and broadcast to existing peers when a new peer registers.
     */
    data class RelayPeerList(
        val peers: List<PeerListEntry>,
        val relayPeerId: String = ""
    ) {
        data class PeerListEntry(
            val peerId: String,
            val multiaddresses: List<String>,
            val advertisedServices: List<String>
        ) {
            var serviceLifecycleTimestamps: Map<String, Long>? = null
                private set

            constructor(
                peerId: String,
                multiaddresses: List<String>,
                advertisedServices: List<String>,
                serviceLifecycleTimestamps: Map<String, Long>?
            ) : this(peerId, multiaddresses, advertisedServices) {
                this.serviceLifecycleTimestamps =
                    immutableServiceLifecycleTimestamps(serviceLifecycleTimestamps)
            }

            fun toJson(): JSONObject {
                return JSONObject().apply {
                    put("peerId", peerId)
                    put("multiaddresses", JSONArray(multiaddresses))
                    put("advertisedServices", JSONArray(advertisedServices))
                    serviceLifecycleTimestamps?.let { timestamps ->
                        put("serviceLifecycleTimestamps", serviceLifecycleTimestampsToJson(timestamps))
                    }
                }
            }
        }

        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_RELAY_PEER_LIST)
                put("relayPeerId", relayPeerId)
                put("peers", JSONArray(peers.map { it.toJson() }))
            }
        }

        companion object {
            fun fromJson(json: JSONObject): RelayPeerList {
                val peersArray = json.optJSONArray("peers") ?: JSONArray()
                val peers = (0 until peersArray.length()).map { i ->
                    val peerJson = peersArray.getJSONObject(i)
                    val multiaddrsArray = peerJson.optJSONArray("multiaddresses") ?: JSONArray()
                    val multiaddrs = (0 until multiaddrsArray.length()).map { j -> multiaddrsArray.getString(j) }
                    val servicesArray = peerJson.optJSONArray("advertisedServices") ?: JSONArray()
                    val services = (0 until servicesArray.length()).map { j -> servicesArray.getString(j) }
                    PeerListEntry(
                        peerId = peerJson.getString("peerId"),
                        multiaddresses = multiaddrs,
                        advertisedServices = services,
                        serviceLifecycleTimestamps = serviceLifecycleTimestampsFromJson(peerJson)
                    )
                }
                return RelayPeerList(
                    peers = peers,
                    relayPeerId = json.optString("relayPeerId", "")
                )
            }
        }
    }

    /**
     * Distance vector routing update message.
     *
     * Each node periodically sends this to neighbors to share its routing table.
     * Contains entries for destinations this node can reach, along with the
     * hop count (distance) to each destination.
     *
     * Distance vector routing enables multi-hop message forwarding where each
     * node routes data to the next hop with the shortest path to the destination.
     */
    data class DistanceVector(
        val sourcePeerId: String,
        val entries: List<RoutingEntry>,
        val timestamp: Long = System.currentTimeMillis()
    ) {
        /**
         * A single routing table entry advertising a reachable destination.
         */
        data class RoutingEntry(
            /** The peer ID of the destination */
            val destination: String,
            /** Services advertised by this destination */
            val services: List<String> = emptyList(),
            /** Hop count to reach this destination (1 = directly connected) */
            val distance: Int,
            /** Sequence number for loop prevention (higher = more recent) */
            val sequenceNumber: Long = 0
        ) {
            fun toJson(): JSONObject {
                return JSONObject().apply {
                    put("destination", destination)
                    put("services", JSONArray(services))
                    put("distance", distance)
                    put("sequenceNumber", sequenceNumber)
                }
            }

            companion object {
                fun fromJson(json: JSONObject): RoutingEntry {
                    val servicesArray = json.optJSONArray("services") ?: JSONArray()
                    val services = (0 until servicesArray.length()).map { servicesArray.getString(it) }
                    return RoutingEntry(
                        destination = json.getString("destination"),
                        services = services,
                        distance = json.getInt("distance"),
                        sequenceNumber = json.optLong("sequenceNumber", 0)
                    )
                }
            }
        }

        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("type", TYPE_DISTANCE_VECTOR)
                put("sourcePeerId", sourcePeerId)
                put("entries", JSONArray(entries.map { it.toJson() }))
                put("timestamp", timestamp)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): DistanceVector {
                val entriesArray = json.optJSONArray("entries") ?: JSONArray()
                val entries = (0 until entriesArray.length()).map { i ->
                    RoutingEntry.fromJson(entriesArray.getJSONObject(i))
                }
                return DistanceVector(
                    sourcePeerId = json.getString("sourcePeerId"),
                    entries = entries,
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            }
        }
    }

    /**
     * Parses a relay protocol message from JSON.
     */
    fun parseMessage(json: JSONObject): Any {
        return when (val type = json.getString("type")) {
            TYPE_RELAY_ANNOUNCE -> RelayAnnouncement.fromJson(json)
            TYPE_RELAY_WITHDRAW -> RelayWithdrawal.fromJson(json)
            TYPE_RELAY_REGISTER -> RelayRegister.fromJson(json)
            TYPE_RELAY_REGISTER_ACK -> RelayRegisterAck.fromJson(json)
            TYPE_RELAY_UNREGISTER -> RelayUnregister.fromJson(json)
            TYPE_RELAY_UNREGISTER_ACK -> RelayUnregisterAck.fromJson(json)
            TYPE_RELAY_REQUEST -> RelayRequest.fromJson(json)
            TYPE_RELAY_RESPONSE -> RelayResponse.fromJson(json)
            TYPE_RELAY_PING -> RelayPing.fromJson(json)
            TYPE_RELAY_PONG -> RelayPong.fromJson(json)
            TYPE_RELAY_KEEPALIVE -> RelayKeepalive.fromJson(json)
            TYPE_RELAY_PEER_LIST -> RelayPeerList.fromJson(json)
            TYPE_DISTANCE_VECTOR -> DistanceVector.fromJson(json)
            else -> throw IllegalArgumentException("Unknown relay message type: $type")
        }
    }
}

/**
 * Information about a known relay peer.
 */
data class RelayInfo(
    val peerId: String,
    val multiaddresses: List<String>,
    val maxClients: Int,
    val currentClients: Int,
    val lastSeen: Long,
    val latencyMs: Long? = null,
    val metadata: Map<String, String> = emptyMap()
) {
    /**
     * Returns true if this relay has capacity for new clients.
     */
    fun hasCapacity(): Boolean = currentClients < maxClients

    /**
     * Creates an updated copy with new latency measurement.
     */
    fun withLatency(latencyMs: Long): RelayInfo = copy(latencyMs = latencyMs)

    /**
     * Creates an updated copy with new last seen timestamp.
     * @param currentTimeMs The current time in milliseconds. Defaults to System.currentTimeMillis()
     *                      for production use, but can be replaced with clock.currentTimeMillis() for testing.
     */
    fun touch(currentTimeMs: Long = System.currentTimeMillis()): RelayInfo = copy(lastSeen = currentTimeMs)
}

/**
 * Registration state for a peer registered with this relay.
 */
data class RelayRegistration(
    val peerId: String,
    val advertisedServices: List<String>,
    val registeredAt: Long = System.currentTimeMillis(),
    val lastKeepalive: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + RelayProtocol.DEFAULT_REGISTRATION_TIMEOUT_MS,
    val metadata: Map<String, String> = emptyMap()
) {
    /**
     * Returns true if this registration has expired.
     */
    fun isExpired(): Boolean = System.currentTimeMillis() > expiresAt

    /**
     * Creates an updated copy with refreshed expiration.
     */
    fun refresh(): RelayRegistration = copy(
        lastKeepalive = System.currentTimeMillis(),
        expiresAt = System.currentTimeMillis() + RelayProtocol.DEFAULT_REGISTRATION_TIMEOUT_MS
    )
}

/**
 * Configuration options for relay functionality.
 */
private const val MAX_RELAY_RECEIVE_CALLBACK_QUEUE_CAPACITY_PER_PEER = 4_096

class RelayConfig(
    /**
     * Whether to enable relay functionality.
     * If true, this peer will participate as a relay, accepting relay registrations
     * and forwarding gossip to connected peers. All nodes act as relays by default,
     * even if they are not publicly reachable - NAT-ed nodes can still relay traffic
     * for peers they are already connected to.
     */
    val enableRelay: Boolean = true,

    /**
     * Maximum number of peers this relay will serve.
     */
    val maxClients: Int = RelayProtocol.DEFAULT_MAX_CLIENTS,

    /**
     * Interval for sending keepalive messages when registered with a relay.
     */
    val keepaliveIntervalMs: Long = RelayProtocol.DEFAULT_KEEPALIVE_INTERVAL_MS,

    /**
     * How long registrations last without a keepalive.
     */
    val registrationTimeoutMs: Long = RelayProtocol.DEFAULT_REGISTRATION_TIMEOUT_MS,

    /**
     * Strategy for selecting a relay when multiple are available.
     */
    val selectionStrategy: RelaySelectionStrategy = RelaySelectionStrategy.FASTEST,

    /**
     * Maximum payload size for relayed requests (to prevent abuse).
     */
    val maxPayloadSize: Int = 1024 * 1024,  // 1 MB default

    /**
     * Interval at which this node re-broadcasts its relay announcement while it is relaying.
     *
     * Relay announcements are gossip; a node only learns about a relay if it receives that relay's
     * announcement. A node that registers with a relay AFTER another relay announced (common for a
     * NAT'd node, which only receives gossip through its relay) would otherwise never learn the other
     * relay — leaving it with no failover target if its own relay dies. Periodically re-announcing
     * keeps every node's view of available relays fresh (self-healing, eventually-consistent), so a
     * NAT'd node always has alternatives to fail over to. Set to `0` to disable periodic re-announce.
     */
    val relayAnnounceIntervalMs: Long = 30_000L
) {
    /**
     * Maximum time allowed for the non-blocking TCP reachability phase of each relay/direct dial.
     * The subsequent libp2p handshake has its own longer budget. Keeping this independently
     * configurable lets callers (and tests) bound unreachable-path failover without making slow
     * handshakes flaky.
     *
     * Deliberately a CLASS-BODY property, not a primary-constructor parameter: adding a parameter
     * to the configuration class regenerates its synthetic default-arguments constructor and breaks binary
     * compatibility with consumers compiled against the old shape (foundation.url:resolver
     * <= 0.0.628 constructs RelayConfig through that synthetic constructor — guarded by
     * tests/testUrlResolver0600CanConstructAgainstCurrentProtocol.kts). This existing
     * reachability property remains outside the constructor, equals, hashCode, and copy.
     */
    var reachabilityTimeoutMs: Long = 2_000L

    /**
     * Maximum callback work retained for one authenticated relay peer after that peer's current
     * callback has started. When the queue is full, the newest callback is dropped and reported
     * through [RelayService.relayWarningEffectsSnapshot] so the relay connection reader never
     * waits on application callback code.
     *
     * Values from 1 through 4,096 are accepted. This remains a class-body property to preserve the
     * primary constructor used by pre-built consumers. Set it before constructing or starting the
     * corresponding [RelayService].
     */
    var receiveCallbackQueueCapacityPerPeer: Int = 64
        set(value) {
            require(value in 1..MAX_RELAY_RECEIVE_CALLBACK_QUEUE_CAPACITY_PER_PEER) {
                "receiveCallbackQueueCapacityPerPeer must be between 1 and " +
                    "$MAX_RELAY_RECEIVE_CALLBACK_QUEUE_CAPACITY_PER_PEER, but was $value"
            }
            field = value
        }

    private var chunkAssemblyTtlMsOverride: Long? = null
    private var outgoingChunkedResponseIdleTtlMsOverride: Long? = null

    /**
     * How long an incomplete incoming chunked request may remain without receiving another chunk.
     * RelayService refreshes this idle time-to-live as each request chunk arrives.
     *
     * This is deliberately a class-body property, not a primary-constructor parameter. Adding a
     * parameter to this class would change its synthetic default-arguments constructor and
     * break pre-built consumers; `testUrlResolver0600CanPeerExchangeAgainstCurrentProtocol` and
     * `testUrlResolver0600CanConstructAgainstCurrentProtocol` are the reason this placement is
     * required. The hand-written data-class-compatible methods below explicitly carry this value
     * through `copy()`, `equals()`, and `hashCode()` while keeping it out of the primary
     * constructor. The secondary constructor below therefore provides the configurable
     * construction path without changing the old constructor signature; the value remains
     * read-only after construction.
     */
    val chunkAssemblyTtlMs: Long
        get() = chunkAssemblyTtlMsOverride ?: 60_000L

    /**
     * How long a chunked outgoing response may remain without delivering a previously unserved
     * chunk. This bounds the memory retained when a requester abandons a large response, while
     * allowing a transfer that continues making progress to outlive its total wall-clock age.
     *
     * Like [chunkAssemblyTtlMs], this is deliberately a class-body property so the historical
     * primary and secondary constructor descriptors remain available to already-compiled callers.
     * The hand-written data-class-compatible methods below carry this value through `copy()`,
     * `equals()`, and `hashCode()`. The two-lifetime secondary constructor below is the
     * configurable path.
     */
    val outgoingChunkedResponseIdleTtlMs: Long
        get() = outgoingChunkedResponseIdleTtlMsOverride ?: 60_000L

    constructor(
        enableRelay: Boolean = true,
        maxClients: Int = RelayProtocol.DEFAULT_MAX_CLIENTS,
        keepaliveIntervalMs: Long = RelayProtocol.DEFAULT_KEEPALIVE_INTERVAL_MS,
        registrationTimeoutMs: Long = RelayProtocol.DEFAULT_REGISTRATION_TIMEOUT_MS,
        selectionStrategy: RelaySelectionStrategy = RelaySelectionStrategy.FASTEST,
        maxPayloadSize: Int = 1024 * 1024,
        relayAnnounceIntervalMs: Long = 30_000L,
        chunkAssemblyTtlMs: Long
    ) : this(
        enableRelay = enableRelay,
        maxClients = maxClients,
        keepaliveIntervalMs = keepaliveIntervalMs,
        registrationTimeoutMs = registrationTimeoutMs,
        selectionStrategy = selectionStrategy,
        maxPayloadSize = maxPayloadSize,
        relayAnnounceIntervalMs = relayAnnounceIntervalMs
    ) {
        require(chunkAssemblyTtlMs > 0L) {
            "chunkAssemblyTtlMs must be greater than 0 milliseconds, but was $chunkAssemblyTtlMs"
        }
        chunkAssemblyTtlMsOverride = chunkAssemblyTtlMs
    }

    constructor(
        enableRelay: Boolean = true,
        maxClients: Int = RelayProtocol.DEFAULT_MAX_CLIENTS,
        keepaliveIntervalMs: Long = RelayProtocol.DEFAULT_KEEPALIVE_INTERVAL_MS,
        registrationTimeoutMs: Long = RelayProtocol.DEFAULT_REGISTRATION_TIMEOUT_MS,
        selectionStrategy: RelaySelectionStrategy = RelaySelectionStrategy.FASTEST,
        maxPayloadSize: Int = 1024 * 1024,
        relayAnnounceIntervalMs: Long = 30_000L,
        chunkAssemblyTtlMs: Long,
        outgoingChunkedResponseIdleTtlMs: Long
    ) : this(
        enableRelay = enableRelay,
        maxClients = maxClients,
        keepaliveIntervalMs = keepaliveIntervalMs,
        registrationTimeoutMs = registrationTimeoutMs,
        selectionStrategy = selectionStrategy,
        maxPayloadSize = maxPayloadSize,
        relayAnnounceIntervalMs = relayAnnounceIntervalMs,
        chunkAssemblyTtlMs = chunkAssemblyTtlMs
    ) {
        require(outgoingChunkedResponseIdleTtlMs > 0L) {
            "outgoingChunkedResponseIdleTtlMs must be greater than 0 milliseconds, but was " +
                outgoingChunkedResponseIdleTtlMs
        }
        outgoingChunkedResponseIdleTtlMsOverride = outgoingChunkedResponseIdleTtlMs
    }

    operator fun component1(): Boolean = enableRelay
    operator fun component2(): Int = maxClients
    operator fun component3(): Long = keepaliveIntervalMs
    operator fun component4(): Long = registrationTimeoutMs
    operator fun component5(): RelaySelectionStrategy = selectionStrategy
    operator fun component6(): Int = maxPayloadSize
    operator fun component7(): Long = relayAnnounceIntervalMs

    fun copy(
        enableRelay: Boolean = this.enableRelay,
        maxClients: Int = this.maxClients,
        keepaliveIntervalMs: Long = this.keepaliveIntervalMs,
        registrationTimeoutMs: Long = this.registrationTimeoutMs,
        selectionStrategy: RelaySelectionStrategy = this.selectionStrategy,
        maxPayloadSize: Int = this.maxPayloadSize,
        relayAnnounceIntervalMs: Long = this.relayAnnounceIntervalMs
    ): RelayConfig {
        return RelayConfig(
            enableRelay = enableRelay,
            maxClients = maxClients,
            keepaliveIntervalMs = keepaliveIntervalMs,
            registrationTimeoutMs = registrationTimeoutMs,
            selectionStrategy = selectionStrategy,
            maxPayloadSize = maxPayloadSize,
            relayAnnounceIntervalMs = relayAnnounceIntervalMs
        ).also { copied ->
            copied.chunkAssemblyTtlMsOverride = chunkAssemblyTtlMs
            copied.outgoingChunkedResponseIdleTtlMsOverride = outgoingChunkedResponseIdleTtlMs
            copied.receiveCallbackQueueCapacityPerPeer = receiveCallbackQueueCapacityPerPeer
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RelayConfig) return false
        return enableRelay == other.enableRelay &&
            maxClients == other.maxClients &&
            keepaliveIntervalMs == other.keepaliveIntervalMs &&
            registrationTimeoutMs == other.registrationTimeoutMs &&
            selectionStrategy == other.selectionStrategy &&
            maxPayloadSize == other.maxPayloadSize &&
            relayAnnounceIntervalMs == other.relayAnnounceIntervalMs &&
            chunkAssemblyTtlMs == other.chunkAssemblyTtlMs &&
            outgoingChunkedResponseIdleTtlMs == other.outgoingChunkedResponseIdleTtlMs &&
            receiveCallbackQueueCapacityPerPeer == other.receiveCallbackQueueCapacityPerPeer
    }

    override fun hashCode(): Int {
        var result = enableRelay.hashCode()
        result = 31 * result + maxClients
        result = 31 * result + keepaliveIntervalMs.hashCode()
        result = 31 * result + registrationTimeoutMs.hashCode()
        result = 31 * result + selectionStrategy.hashCode()
        result = 31 * result + maxPayloadSize
        result = 31 * result + relayAnnounceIntervalMs.hashCode()
        result = 31 * result + chunkAssemblyTtlMs.hashCode()
        result = 31 * result + outgoingChunkedResponseIdleTtlMs.hashCode()
        result = 31 * result + receiveCallbackQueueCapacityPerPeer
        return result
    }

    override fun toString(): String =
        "RelayConfig(enableRelay=$enableRelay, maxClients=$maxClients, " +
            "keepaliveIntervalMs=$keepaliveIntervalMs, registrationTimeoutMs=$registrationTimeoutMs, " +
            "selectionStrategy=$selectionStrategy, maxPayloadSize=$maxPayloadSize, " +
            "relayAnnounceIntervalMs=$relayAnnounceIntervalMs, " +
            "receiveCallbackQueueCapacityPerPeer=$receiveCallbackQueueCapacityPerPeer)"
}

const val DEFAULT_RELAY_REQUEST_HOP_LIMIT = 16

/**
 * Strategy for selecting which relay to use.
 */
enum class RelaySelectionStrategy {
    /**
     * Select the relay with the lowest ping latency.
     */
    FASTEST,

    /**
     * Select a random relay from available options.
     */
    RANDOM,

    /**
     * Rotate through available relays in round-robin fashion.
     */
    ROUND_ROBIN
}
