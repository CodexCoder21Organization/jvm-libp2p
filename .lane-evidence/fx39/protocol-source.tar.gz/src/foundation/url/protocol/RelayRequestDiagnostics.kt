package foundation.url.protocol

import io.libp2p.core.Stream
import io.netty.channel.Channel
import io.netty.util.AttributeKey
import java.util.concurrent.atomic.AtomicBoolean

/** First locally observed reason; the peer's private reason is never inferred from EOF. */
internal data class RelayStreamCloseObservation(
    val locallyInitiated: Boolean,
    val reason: String,
    val cause: Throwable? = null,
)

private class RelayStreamCloseState {
    val observations = mutableListOf<RelayStreamCloseObservation>()
    var hasPermanentObservation = false
    var terminal = false
}

private val relayStreamCloseObservationKey = AttributeKey.valueOf<RelayStreamCloseState>(
    "foundation.url.protocol.relayStreamCloseObservation"
)

private fun relayStreamCloseState(channel: Channel): RelayStreamCloseState {
    val attribute = channel.attr(relayStreamCloseObservationKey)
    return attribute.get() ?: RelayStreamCloseState().let { attribute.setIfAbsent(it) ?: it }
}

internal fun markRelayStreamClose(
    channel: Channel,
    locallyInitiated: Boolean,
    reason: String,
    cause: Throwable? = null,
) {
    val state = relayStreamCloseState(channel)
    synchronized(state) {
        if (!state.terminal && !state.hasPermanentObservation) {
            state.observations.add(RelayStreamCloseObservation(locallyInitiated, reason, cause))
            state.hasPermanentObservation = true
        }
    }
}

internal fun beginRelayStreamCloseAttempt(channel: Channel, reason: String): RelayStreamCloseObservation {
    val observation = RelayStreamCloseObservation(true, reason)
    val state = relayStreamCloseState(channel)
    synchronized(state) {
        // Child inactivity can re-enter close before the root recorder receives inactivity.
        if (channel.isOpen && !state.terminal && !state.hasPermanentObservation) state.observations.add(observation)
    }
    return observation
}

internal fun abandonRelayStreamCloseAttempt(channel: Channel, observation: RelayStreamCloseObservation) {
    val state = relayStreamCloseState(channel)
    synchronized(state) {
        if (state.terminal || !channel.isOpen) return
        val index = state.observations.indexOfFirst { it === observation }
        if (index >= 0) state.observations.removeAt(index)
    }
}

internal fun finishRelayStreamClose(channel: Channel) {
    val state = relayStreamCloseState(channel)
    synchronized(state) {
        if (state.terminal) return
        val selected = state.observations.firstOrNull()
        state.observations.clear()
        if (selected != null) state.observations.add(selected)
        state.hasPermanentObservation = true
        state.terminal = true
    }
}

private fun observedRelayStreamClose(channel: Channel): RelayStreamCloseObservation? {
    val state = channel.attr(relayStreamCloseObservationKey).get() ?: return null
    return synchronized(state) { state.observations.firstOrNull() }
}

internal fun relayStreamCloseObservation(stream: Stream): RelayStreamCloseObservation {
    val channel = streamAsChannel(stream)
    return channel?.let(::observedRelayStreamClose)
        ?: channel?.let { observedRelayStreamClose(libp2pRootConnectionChannel(it)) }
        ?: RelayStreamCloseObservation(false, "remote-end-of-stream")
}

internal fun markRelaySenderClose(stream: Stream) {
    val channel = streamAsChannel(stream) ?: return
    if (channel.isOpen && libp2pRootConnectionChannel(channel).isOpen) {
        markRelayStreamClose(channel, true, "local-close")
    }
}

/** Rendering a diagnostic never makes a close depend on a supplied exception's message getter. */
private fun relayDiagnosticCause(cause: Throwable?): String {
    if (cause == null) return "none"
    return try {
        connectionRecordCause(cause)
    } catch (renderingFailure: Throwable) {
        // Include the rendering failure in the record itself; no close or reply can be prevented by it.
        "${cause.javaClass.name}: message unavailable (${renderingFailure.javaClass.name})"
    }
}

/** One field stays on one physical line even when a peer supplied control characters. */
private fun relayDiagnosticField(value: String): String = value.take(1024)
    .replace("\\", "\\\\").replace("\r", "\\r").replace("\n", "\\n")
    .replace(";", "\\u003b") + if (value.length > 1024) "...[${value.length} chars]" else ""

/** No request payload, response payload or completed-request history is retained here. */
internal class RelayForwardDiagnostic(
    private val requestId: String,
    private val forwardRequestId: String,
    rpcRequestId: String?,
    private val callerPeerId: String,
    private val providerPeerId: String,
    private val relayPeerId: String,
    private val callerSender: RelayMessageSender,
    private val providerSender: RelayMessageSender,
    private val onTerminal: (RelayForwardDiagnostic) -> Unit,
    fetchTransferId: String?,
    fetchSequence: String?,
) {
    private val callerRpcRequestId = relayDiagnosticField(rpcRequestId ?: "unknown")
    private val progressRpcRequestId = relayProgressField(rpcRequestId ?: "unknown")
    private val progressTransferId = fetchTransferId?.let(::relayProgressField)
    private val progressSequence = fetchSequence?.let(::relayProgressField) ?: "unknown"
    private val terminal = AtomicBoolean(false)
    private val providerReplied = AtomicBoolean(false)
    private val callerStream = callerSender.relayDiagnosticStream()
    private val providerStream = providerSender.relayDiagnosticStream()
    private val callerConnectionIdentity = callerStream?.let { connectionRecordIdentity(it.connection) } ?: "unknown"
    private val providerConnectionIdentity = providerStream?.let { connectionRecordIdentity(it.connection) } ?: "unknown"
    private val callerStreamIdentity = callerStream?.let(::streamAsChannel)?.id()?.asLongText() ?: "unknown"
    private val providerStreamIdentity = providerStream?.let(::streamAsChannel)?.id()?.asLongText() ?: "unknown"
    private val nextHopPeerId = providerStream?.let {
        connectionRecordValue { it.remotePeerId().toBase58() }
    } ?: "unknown"

    fun responseProgressSnapshot(currentProvider: (String) -> RelayMessageSender?): String? {
        val transfer = progressTransferId ?: return null
        val caller = callerStream?.let(::relayProgressStreamIdentity) ?: "unknown"
        val provider = providerStream?.let(::relayProgressStreamIdentity) ?: "unknown"
        val currentChild = currentProvider(providerPeerId)?.relayDiagnosticStream()
            ?.let(::streamAsChannel)?.id()?.asLongText() ?: "none"
        return "forward requestId=${relayProgressField(requestId)} " +
            "forwardRequestId=${relayProgressField(forwardRequestId)} " +
            "rpcRequestId=$progressRpcRequestId " +
            "transferId=$transfer sequence=$progressSequence " +
            "caller[$caller] provider[$provider] currentProviderChild=$currentChild"
    }

    fun providerResponded() {
        providerReplied.set(true)
    }

    fun prepareStreamClosed(
        sender: RelayMessageSender,
        observation: RelayStreamCloseObservation,
    ): (() -> Unit)? {
        val side = when {
            callerSender.matchesStreamSender(sender) -> "caller"
            !providerReplied.get() && providerSender.matchesStreamSender(sender) -> "provider"
            else -> return null
        }
        return prepareFailure(if (observation.locallyInitiated) "relay" else side, observation.reason) {
            relayDiagnosticCause(observation.cause)
        }
    }

    private fun failedOnLeg(side: String, observation: RelayStreamCloseObservation) {
        prepareFailure(if (observation.locallyInitiated) "relay" else side, observation.reason) {
            relayDiagnosticCause(observation.cause)
        }?.invoke()
    }

    fun providerFailure(cause: Throwable) {
        prepareProviderFailure(cause)?.invoke()
    }

    fun prepareProviderFailure(cause: Throwable): (() -> Unit)? {
        if (terminal.get()) return null
        val observation = providerStream?.let(::relayStreamCloseObservation)
        return if (observation != null &&
            (providerSender.isClosed() || providerStream?.let(::streamAsChannel)?.isOpen == false)
        ) {
            prepareFailure(if (observation.locallyInitiated) "relay" else "provider", observation.reason) {
                relayDiagnosticCause(observation.cause)
            }
        } else prepareFailure("relay", "error") { relayDiagnosticCause(cause) }
    }

    fun responseWriteCompleted(cause: Throwable?) {
        if (cause == null) {
            if (terminal.compareAndSet(false, true)) onTerminal(this)
        } else {
            val observation = callerStream?.let(::relayStreamCloseObservation)
            if (observation != null && (callerStream?.let(::streamAsChannel)?.isOpen == false || observation.locallyInitiated)) {
                failedOnLeg("caller", observation)
            } else {
                prepareFailure("relay", "error") { relayDiagnosticCause(cause) }?.invoke()
            }
        }
    }

    fun shutdown() = failed("relay", "shutdown", "none")

    fun prepareShutdown(): (() -> Unit)? = prepareFailure("relay", "shutdown") { "none" }

    private fun failed(side: String, reason: String, cause: String) {
        prepareFailure(side, reason) { cause }?.invoke()
    }

    // Claim the diagnostic before replies wake asynchronous forward completions. Rendering and
    // output are deferred too: a supplied cause getter or output sink may block or re-enter.
    private fun prepareFailure(side: String, reason: String, cause: () -> String): (() -> Unit)? {
        if (!terminal.compareAndSet(false, true)) return null
        onTerminal(this)
        return {
            val line = "[RelayRequestFailed] requestId=${relayDiagnosticField(requestId)}; " +
                "forwardRequestId=${relayDiagnosticField(forwardRequestId)}; " +
                "rpcRequestId=$callerRpcRequestId; " +
                "callerPeerId=${relayDiagnosticField(callerPeerId)}; providerPeerId=${relayDiagnosticField(providerPeerId)}; " +
                "relayPeerId=${relayDiagnosticField(relayPeerId)}; nextHopPeerId=${relayDiagnosticField(nextHopPeerId)}; " +
                "closedSide=$side; reason=$reason; " +
                "callerConnection=$callerConnectionIdentity; callerStream=$callerStreamIdentity; " +
                "providerConnection=$providerConnectionIdentity; providerStream=$providerStreamIdentity; " +
                "cause=${relayDiagnosticField(cause())}"
            val channel = callerStream?.let(::streamAsChannel)
            if (channel == null) System.err.println(line)
            else notifyRpcObserver(channel, "Relay request failure record") { System.err.println(line) }
        }
    }
}
