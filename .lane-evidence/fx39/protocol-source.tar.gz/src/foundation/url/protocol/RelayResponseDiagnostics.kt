package foundation.url.protocol

import io.libp2p.core.Stream
import io.libp2p.etc.util.netty.mux.MuxChannel
import io.netty.util.AttributeKey

// Diagnostic text owns no message body and never participates in admission or correlation.
internal fun relayProgressField(value: String): String = value.take(256)
    .replace("\\", "\\\\").replace("\r", "\\r").replace("\n", "\\n").replace(";", "\\u003b") +
    if (value.length > 256) "...[${value.length} chars]" else ""

internal fun relayProgressStreamIdentity(stream: Stream): String {
    val channel = streamAsChannel(stream)
    val root = channel?.let(::libp2pRootConnectionChannel)
    val link = if (root == null) "unknown" else listOf(
        root.localAddress().toString(), root.remoteAddress().toString(),
    ).sorted().joinToString("<->")
    return "child=${channel?.id()?.asLongText() ?: "unknown"} " +
        "mux=${(channel as? MuxChannel<*>)?.id?.id ?: "unknown"} link=${relayProgressField(link)} " +
        "peer=${relayProgressField(stream.remotePeerId().toBase58())}"
}

internal data class RelayResponseFetchDiagnostic(val requestId: String, val fields: String, val issuedAtMs: Long)

internal class RelayResponseStreamDiagnostics {
    // One request-stream caller writes this immutable, at-most-ten-entry list.
    @Volatile var fetches: List<RelayResponseFetchDiagnostic> = emptyList()
}

internal val relayResponseDiagnosticsKey = AttributeKey.valueOf<RelayResponseStreamDiagnostics>(
    "foundation.url.protocol.responseProgressDiagnostics",
)

internal class RelayRegistrationReaderDiagnostic(val identity: String) {
    // This scalar history never retains a stream, controller, callback, or Thread.
    @Volatile var state: String = "starting"
}
