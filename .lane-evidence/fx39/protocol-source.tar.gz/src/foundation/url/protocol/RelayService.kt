package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.Scheduled
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.logging.MessageSeverity
import io.libp2p.core.Host
import io.libp2p.core.PeerId
import io.libp2p.core.Stream
import io.libp2p.core.multiformats.Multiaddr
import io.libp2p.etc.util.netty.mux.MuxChannel
import io.libp2p.etc.util.netty.mux.MuxId
import io.libp2p.mux.yamux.YamuxFlag
import io.libp2p.mux.yamux.YamuxFrame
import io.libp2p.mux.yamux.YamuxHandler
import io.libp2p.mux.yamux.YamuxType
import io.netty.buffer.ByteBuf
import io.netty.buffer.Unpooled
import io.netty.channel.Channel
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import io.netty.channel.ChannelOutboundHandlerAdapter
import io.netty.channel.ChannelPromise
import io.netty.channel.SimpleChannelInboundHandler
import io.netty.handler.codec.LengthFieldBasedFrameDecoder
import io.netty.handler.timeout.ReadTimeoutHandler
import io.netty.handler.timeout.ReadTimeoutException
import io.netty.util.ReferenceCountUtil
import okio.Buffer
import okio.FileHandle
import okio.FileSystem
import okio.Path
import org.json.JSONException
import org.json.JSONObject
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64
import java.util.UUID
import java.util.concurrent.*
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.locks.ReentrantLock
import kotlinx.algebraiceffects.EffectHandlerRepository
import kotlinx.algebraiceffects.EffectHandlerContext
import kotlinx.algebraiceffects.captureEffectHandlerContext
import kotlinx.algebraiceffects.withEffectHandlerContext
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.`$effectHandlerRepository`
import kotlinx.algebraiceffects.toss
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import kotlin.concurrent.thread
import kotlin.concurrent.withLock

private fun parseRelayOrGossipMessage(json: JSONObject): Any {
    val message = try {
        RelayProtocol.parseMessage(json)
    } catch (failure: IllegalArgumentException) {
        // The server sends a correlated error for malformed relay requests. Keep that path distinct
        // from falling through to the gossip dispatcher for an unrecognized relay message type.
        if (failure is RelayRequestFieldParsingException) throw failure
        GossipProtocol.parseMessage(json)
    }
    validateLibp2pWithdrawalPeerId(message)
    return message
}

// Reserve a public outcome before promising its cleanup detail to a caller. Cancellation
// and normal completion use the same claim, while callbacks still run outside lifecycle locks.
private class RelayRegistrationRefreshResult : CompletableFuture<Boolean>() {
    val completionClaimed = AtomicBoolean(false)

    override fun cancel(mayInterruptIfRunning: Boolean): Boolean =
        if (completionClaimed.compareAndSet(false, true)) super.cancel(mayInterruptIfRunning)
        else isCancelled

    override fun complete(value: Boolean?): Boolean =
        completionClaimed.compareAndSet(false, true) && super.complete(value)

    override fun completeExceptionally(failure: Throwable): Boolean =
        completionClaimed.compareAndSet(false, true) && super.completeExceptionally(failure)

    fun completeReservedValue(value: Boolean) {
        super.complete(value)
    }

    fun completeReservedFailure(failure: Throwable) {
        super.completeExceptionally(failure)
    }
}

private fun reserveRelayRefreshFailure(result: RelayRegistrationRefreshResult): Boolean =
    !result.isDone && result.completionClaimed.compareAndSet(false, true)

private class RelayRegistrationTurn(val owner: Thread) {
    val completed = CompletableFuture<Unit>()
}

private class RelayRegistrationSerialization {
    val lock = ReentrantLock()
    var active: RelayRegistrationTurn? = null
}

// Reserve a transaction under a short lock, then run all transport work without holding it.
// Waiters own no reservation, so interrupting one cannot release or cancel another caller's turn.
private fun <T> withRelayRegistrationTurn(
    serialization: RelayRegistrationSerialization,
    peerId: String,
    relayPeerId: String,
    action: () -> T,
): T {
    val caller = Thread.currentThread()
    while (true) {
        var acquired = false
        var reentered = false
        val turn = serialization.lock.withLock {
            val active = serialization.active
            when {
                active == null -> RelayRegistrationTurn(caller).also {
                    serialization.active = it
                    acquired = true
                }
                active.owner === caller -> active.also { reentered = true }
                else -> active
            }
        }
        // Selectors and Clock callbacks may re-enter on the transaction's own thread, just as
        // they could with the original reentrant monitor. They must not await their own result.
        if (reentered) return action()
        if (acquired) {
            try {
                return action()
            } finally {
                serialization.lock.withLock { serialization.active = null }
                // Complete outside the lock: future callbacks may themselves enter registration.
                turn.completed.complete(Unit)
            }
        }
        try {
            turn.completed.get()
        } catch (failure: InterruptedException) {
            caller.interrupt()
            throw RelayException(
                "Interrupted while waiting to register peer $peerId with relay $relayPeerId " +
                    "because another registration is still in progress.",
                failure,
            )
        }
    }
}

private const val RESPONSE_FRAMING_CAPABILITY = "opaque-v2"
private const val RESPONSE_FRAMING_HEADER = "__relay_response_framing__"
private const val RESPONSE_FRAMING_TAG = "response-framing-v2:"
private const val RESPONSE_BODY_TAG = "response-body-v2:"
private val legacyResponseTransferId = Regex("relay-[0-9]+-[a-z0-9]+-[0-9]+")

private const val RELAY_RESPONSE_CHUNK_BYTES = 128 * 1024
private const val RELAY_REQUEST_CHUNK_BYTES = 128 * 1024
private const val MAX_RELAY_REQUEST_CHUNK_ENCODED_CHARACTERS =
    ((RELAY_REQUEST_CHUNK_BYTES + 2) / 3) * 4
private const val MAX_RELAY_REQUEST_CHUNKS = 12_288
private const val MAX_RELAY_REQUEST_TEMPORARY_STORAGE_BYTES = 1_610_612_736L

private val responseChunkEnvelopeMagic = "RCNK1\n"

private fun wrapResponseChunk(transferId: String, seq: Int, total: Int, data: ByteArray): String {
    val header = "$responseChunkEnvelopeMagic$transferId\n$seq\n$total\n".toByteArray(Charsets.ISO_8859_1)
    return Base64.getEncoder().encodeToString(header + data)
}

private class ParsedResponseChunk(
    val transferId: String,
    val seq: Int,
    val total: Int,
    val data: ByteArray,
    val opaqueFraming: Boolean = false,
)

/** Parses a complete response-chunk envelope. */
private fun parseResponseChunk(rawPayload: ByteArray): ParsedResponseChunk? {
    val magic = responseChunkEnvelopeMagic.toByteArray(Charsets.ISO_8859_1)
    if (rawPayload.size < magic.size) return null
    for (i in magic.indices) if (rawPayload[i] != magic[i]) return null
    var idx = magic.size
    fun nextLine(): String? {
        val sb = StringBuilder()
        while (idx < rawPayload.size && rawPayload[idx] != '\n'.code.toByte()) { sb.append((rawPayload[idx].toInt() and 0xFF).toChar()); idx++ }
        if (idx >= rawPayload.size) return null
        idx++ // skip '\n'
        return sb.toString()
    }
    val transferId = nextLine() ?: return null
    val seq = nextLine()?.toIntOrNull() ?: return null
    val total = nextLine()?.toIntOrNull() ?: return null
    return ParsedResponseChunk(transferId, seq, total, rawPayload.copyOfRange(idx, rawPayload.size))
}

private fun requireUninterruptedResponseDelivery() {
    if (Thread.currentThread().isInterrupted) {
        throw RelayException("Interrupted while delivering response to caller output")
    }
}

private fun interruptionAwareResponseOutput(output: OutputStream): OutputStream = object : OutputStream() {
    override fun write(value: Int) {
        requireUninterruptedResponseDelivery()
        output.write(value)
        requireUninterruptedResponseDelivery()
    }

    override fun write(bytes: ByteArray, offset: Int, length: Int) {
        requireUninterruptedResponseDelivery()
        output.write(bytes, offset, length)
        requireUninterruptedResponseDelivery()
    }
}

// The existing optional text field survives older intermediaries. On a successful response
// this reserved tag selects framing and supplies the authoritative content length.
private fun parseTaggedResponseChunk(response: RelayProtocol.RelayResponse, raw: ByteArray): ParsedResponseChunk? {
    val tag = response.errorMessage ?: return null
    if (!tag.startsWith(RESPONSE_FRAMING_TAG)) return null
    val length = tag.removePrefix(RESPONSE_FRAMING_TAG).toIntOrNull()
        ?: throw RelayException("Response framing length must be an integer, but was $tag")
    val chunk = parseResponseChunk(raw)
        ?: throw RelayException("A response tagged as framed did not contain a complete frame header")
    if (length < 0 || chunk.data.size != length) {
        throw RelayException("Response frame declared $length content bytes but contained ${chunk.data.size}")
    }
    return ParsedResponseChunk(chunk.transferId, chunk.seq, chunk.total, chunk.data, opaqueFraming = true)
}

/** The first reply selects the representation; continuations must keep that selection. */
private fun parseNegotiatedResponseChunk(
    response: RelayProtocol.RelayResponse,
    raw: ByteArray,
    opaqueFraming: Boolean? = null,
): ParsedResponseChunk? {
    if (opaqueFraming == true) return parseTaggedResponseChunk(response, raw)
    if (opaqueFraming == false) {
        val chunk = parseResponseChunk(raw)
        val tag = response.errorMessage
        if (tag != null && (tag.startsWith(RESPONSE_FRAMING_TAG) || tag.startsWith(RESPONSE_BODY_TAG))) {
            val declaredLength = tag.substringAfter(':')
            val frame = chunk ?: throw RelayException(
                "Response continuation tagged '$tag' declared $declaredLength content bytes " +
                    "but contained ${raw.size} raw bytes without a complete frame header; " +
                    "the response began with legacy framing and cannot switch response representation"
            )
            throw RelayException(
                "Response frame ${frame.seq} tagged '$tag' declared $declaredLength content bytes " +
                    "but contained ${frame.data.size}; the response began with legacy framing " +
                    "and cannot switch response representation"
            )
        }
        return chunk
    }
    val tag = response.errorMessage
    if (tag?.startsWith(RESPONSE_BODY_TAG) == true) {
        val length = tag.removePrefix(RESPONSE_BODY_TAG).toIntOrNull()
        if (length == null || length < 0 || length != raw.size) {
            throw RelayException("Response body declared ${tag.removePrefix(RESPONSE_BODY_TAG)} content bytes but contained ${raw.size}")
        }
        return null
    }
    parseTaggedResponseChunk(response, raw)?.let { return it }
    // Published 0.0.608 sends small bodies unchanged and starts every larger response with
    // a full 128 KiB data chunk plus its envelope. A small frame-like body is therefore literal.
    if (raw.size <= RELAY_RESPONSE_CHUNK_BYTES) return null
    return parseResponseChunk(raw)?.takeIf {
        it.seq == 0 && it.total > 1 && it.data.size == RELAY_RESPONSE_CHUNK_BYTES &&
            legacyResponseTransferId.matches(it.transferId)
    }
}

private fun readForwardedResponse(
    connection: RelayConnection,
    timeout: Long,
    timeoutUnit: TimeUnit,
    clock: Clock,
    deadlineMs: Long,
): JSONObject? {
    val message = connection.readMessage(timeout, timeout, timeoutUnit, clock, deadlineMs)
    if (Thread.currentThread().isInterrupted) {
        throw RelayException("Interrupted while waiting for forwarded response")
    }
    return message
}


private data class RefusedRelayResponseChunk(
    val sequence: Int,
    val deadlineMs: Long,
    val timeoutMs: Long,
    val reason: String,
)

private fun checkRefusedRelayChunkDeadline(clock: Clock, chunk: RefusedRelayResponseChunk) {
    remainingRefusedRelayChunkWait(clock, chunk)
}

private fun remainingRefusedRelayChunkWait(clock: Clock, chunk: RefusedRelayResponseChunk): Long {
    val now = clock.currentTimeMillis()
    if (now >= chunk.deadlineMs) {
        throw RelayException(
            "Relay response chunk fetch remained refused until the original ${chunk.timeoutMs}ms request deadline: " +
                "${chunk.reason} The application request was not resent.",
        )
    }
    return remainingReadWaitMillis(chunk.deadlineMs, now)
}

private fun awaitRelayChunkReply(
    reply: RelayPendingReply,
    clock: Clock,
    refused: RefusedRelayResponseChunk?,
): RelayProtocol.RelayResponse {
    try {
        if (refused != null) checkRefusedRelayChunkDeadline(clock, refused)
        val response = try {
            reply.await()
        } catch (failure: RelayException) {
            // Keep the call's existing refusal diagnostic when expiry wakes an accepted resend.
            if (refused != null && !Thread.currentThread().isInterrupted) checkRefusedRelayChunkDeadline(clock, refused)
            throw failure
        }
        if (refused != null) checkRefusedRelayChunkDeadline(clock, refused)
        return response
    } finally {
        // A deadline can expire before await starts; that reply must still leave routing.
        reply.abandon()
    }
}

internal class RelayStreamRetirement(
    private val replies: List<Pair<CompletableFuture<RelayProtocol.RelayResponse>, RelayException>>,
    private val reports: List<() -> Unit>,
) {
    fun settleReplies() {
        replies.forEach { (future, failure) -> future.completeExceptionally(failure) }
    }

    fun reportFailures() {
        var failure: Throwable? = null
        reports.forEach { report ->
            try { report() }
            catch (later: Throwable) { failure = appendRelayCleanupFailure(failure, later) }
        }
        failure?.let { throw it }
    }
}

internal class RelaySynchronousForwardFailure(
    val settleReply: suspend () -> Unit,
    val reportFailure: () -> Unit,
)

internal class RelayMessageProcessingOutcome(
    val registeredPeerId: String?,
    val synchronousFailure: RelaySynchronousForwardFailure? = null,
)

private fun relaySynchronousForwardFailureDetail(failure: Exception): String =
    if (failure is RelayException) failure.transportMessage ?: failure.javaClass.name
    else failure.javaClass.name

private class PendingRelayRequest(val target: RelayMessageSender, val targetPeerId: String) {
    val future = CompletableFuture<RelayProtocol.RelayResponse>()
}

private fun pendingRelayStreamClosed(requestId: String, pending: PendingRelayRequest): RelayException =
    RelayException(
        "Relay stream to peer '${pending.targetPeerId}' closed before response to request '$requestId' arrived",
    )

/** A fair connection-wide fetch budget whose waiting callers keep their own Clock deadline. */
private class RelayResponseChunkFetchBudget(private val capacity: Int) {
    private val lock = ReentrantLock()
    private val changed = lock.newCondition()
    private val waiters = ArrayDeque<Any>()
    private var available = capacity

    fun tryAcquire(): Boolean {
        if (Thread.interrupted()) throw InterruptedException()
        return lock.withLock {
            if (available == 0 || waiters.isNotEmpty()) false
            else { available--; true }
        }
    }

    fun acquire(clock: Clock, deadlineMs: Long): Boolean {
        val ticket = Any()
        val expired = AtomicBoolean()
        var acquired = false
        // Scheduling outside the lock also permits a Clock to invoke an already-due wake inline.
        val wake = if (clock is SystemClock) null else clock.schedule(deadlineMs) {
            expired.set(true)
            lock.withLock { changed.signalAll() }
        }
        try {
            lock.lockInterruptibly()
            try {
                waiters.addLast(ticket)
                try {
                    while (true) {
                        val remaining = remainingReadWaitMillis(deadlineMs, clock.currentTimeMillis())
                        if (expired.get() || remaining <= 0L) return false
                        if (waiters.first() === ticket && available > 0) {
                            available--
                            acquired = true
                            return true
                        }
                        if (clock is SystemClock) changed.await(remaining, TimeUnit.MILLISECONDS)
                        else changed.await()
                    }
                } finally {
                    waiters.remove(ticket)
                    changed.signalAll()
                }
            } finally {
                lock.unlock()
            }
        } finally {
            try {
                wake?.let(clock::unschedule)
            } catch (failure: Throwable) {
                // A grant reaches the caller only after wake cleanup succeeds.
                if (acquired) {
                    try { release() } catch (releaseFailure: Throwable) { failure.addSuppressed(releaseFailure) }
                }
                throw failure
            }
        }
    }

    fun release(count: Int = 1) {
        lock.withLock {
            check(count >= 0 && count <= capacity - available) { "Cannot return $count fetch permits with $available of $capacity available" }
            available += count
            changed.signalAll()
        }
    }
}

/** A false zero-wait offer wrote no part of the message, so offering it again is safe. */
private fun admitRelayCallMessage(
    clock: Clock,
    deadlineMs: Long,
    maxAdmissionWaitMs: Long,
    isClosed: () -> Boolean,
    parkedWriteBudget: () -> Semaphore?,
    offer: () -> Boolean,
): Boolean {
    val admissionDeadline = minOf(deadlineMs, saturatedReadDeadline(clock.currentTimeMillis(), maxAdmissionWaitMs))
    var ownedParkedBudget: Semaphore? = null
    try {
        while (clock.currentTimeMillis() < admissionDeadline && !isClosed()) {
            requireUninterruptedResponseDelivery()
            if (offer()) return true
            if (ownedParkedBudget == null) {
                val budget = parkedWriteBudget()
                if (budget != null) {
                    if (!budget.tryAcquire()) return false
                    ownedParkedBudget = budget
                }
            }
            // Keep the connection's retained-caller bound while the Clock owns the wait.
            clock.sleep(minOf(1L, remainingReadWaitMillis(admissionDeadline, clock.currentTimeMillis())))
        }
        requireUninterruptedResponseDelivery()
        return false
    } finally {
        ownedParkedBudget?.release()
    }
}

private fun awaitRefusedRelayChunkTurn(clock: Clock, chunk: RefusedRelayResponseChunk) {
    checkRefusedRelayChunkDeadline(clock, chunk)
    try {
        // Only a proven-unstarted chunk is eligible. Yield between refusals rather than
        // continuously offering work to a peer whose handler slots are still occupied.
        clock.sleep(1L)
    } catch (interrupted: InterruptedException) {
        Thread.currentThread().interrupt()
        throw RelayException("Interrupted while waiting to resend relay response chunk ${chunk.sequence}", interrupted)
    }
    checkRefusedRelayChunkDeadline(clock, chunk)
}

private fun relayRequestEncodedByteCount(rawByteCount: Long): Long =
    ((rawByteCount + 2L) / 3L) * 4L

private fun relayRequestMaterializationByteCount(rawByteCount: Long): Long {
    val encodedByteCount = relayRequestEncodedByteCount(rawByteCount)
    // Keep room for the Base64 byte buffer, a two-byte-per-character String representation, and
    // the raw bytes that the request handler may decode while both encoded forms are still live.
    return rawByteCount + (3L * encodedByteCount)
}

private class IdempotentRelayRequestLease(
    private val release: () -> Unit,
) : AutoCloseable {
    private val lock = Any()
    private var released = false

    override fun close() {
        synchronized(lock) {
            if (released) return
            release()
            released = true
        }
    }
}

/**
 * Point-in-time process-wide accounting for completed chunked requests awaiting delivery.
 *
 * [waitingRequestCount] counts completed requests queued behind earlier materializations. The
 * snapshot contains no mutable scheduler state, so callers may retain it for diagnostics.
 */
data class RelayRequestMaterializationSnapshot(
    val capacityBytes: Long,
    val retainedBytes: Long,
    val waitingRequestCount: Int,
)

private object RelayRequestMaterializationBudget {
    private const val MAX_CAPACITY_BYTES = 512L * 1024L * 1024L

    private class Ticket(
        val estimatedByteCount: Long,
        val serviceClosed: () -> Boolean,
    )

    private val capacityBytes =
        (Runtime.getRuntime().maxMemory() / 2L).coerceAtMost(MAX_CAPACITY_BYTES)
    private val lock = ReentrantLock(true)
    private val capacityChanged = lock.newCondition()
    private val tickets = java.util.ArrayDeque<Ticket>()
    private var retainedByteCount = 0L

    fun acquire(
        peerId: String,
        transferId: String,
        rawByteCount: Long,
        serviceClosed: () -> Boolean,
    ): AutoCloseable {
        val encodedByteCount = relayRequestEncodedByteCount(rawByteCount)
        val estimatedByteCount = relayRequestMaterializationByteCount(rawByteCount)
        if (estimatedByteCount > capacityBytes) {
            throw RelayException(
                "Rejected completed chunked relay request from peer '$peerId' for transfer " +
                    "'$transferId': raw payload is $rawByteCount bytes, encoded payload is " +
                    "$encodedByteCount bytes, estimated materialization is $estimatedByteCount " +
                    "bytes, and the process-wide materialization limit is $capacityBytes bytes"
            )
        }

        val ticket = Ticket(estimatedByteCount, serviceClosed)
        val lease = IdempotentRelayRequestLease {
            lock.withLock {
                check(retainedByteCount >= estimatedByteCount) {
                    "Relay request materialization accounting released $estimatedByteCount bytes " +
                        "while only $retainedByteCount bytes were retained"
                }
                retainedByteCount -= estimatedByteCount
                capacityChanged.signalAll()
            }
        }
        try {
            lock.lockInterruptibly()
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            throw interruptedMaterializationWait(
                peerId,
                transferId,
                rawByteCount,
                encodedByteCount,
                estimatedByteCount,
                interrupted,
            )
        }
        try {
            tickets.addLast(ticket)
            while (true) {
                if (serviceClosed()) {
                    tickets.remove(ticket)
                    capacityChanged.signalAll()
                    throw RelayException(
                        "RelayService closed while waiting to materialize chunked relay request " +
                            "from peer '$peerId' for transfer '$transferId'"
                    )
                }
                removeClosedTickets()
                if (tickets.peekFirst() === ticket &&
                    retainedByteCount <= capacityBytes - ticket.estimatedByteCount
                ) {
                    tickets.removeFirst()
                    retainedByteCount += ticket.estimatedByteCount
                    capacityChanged.signalAll()
                    return lease
                }
                try {
                    capacityChanged.await()
                } catch (interrupted: InterruptedException) {
                    tickets.remove(ticket)
                    capacityChanged.signalAll()
                    Thread.currentThread().interrupt()
                    throw interruptedMaterializationWait(
                        peerId,
                        transferId,
                        rawByteCount,
                        encodedByteCount,
                        estimatedByteCount,
                        interrupted,
                    )
                }
            }
        } finally {
            lock.unlock()
        }
    }

    fun wakeWaiters() {
        lock.withLock {
            removeClosedTickets()
            capacityChanged.signalAll()
        }
    }

    fun snapshot(): RelayRequestMaterializationSnapshot = lock.withLock {
        RelayRequestMaterializationSnapshot(
            capacityBytes = capacityBytes,
            retainedBytes = retainedByteCount,
            waitingRequestCount = tickets.size,
        )
    }

    /** Caller must hold [lock]. */
    private fun removeClosedTickets() {
        tickets.removeIf { it.serviceClosed() }
    }

    private fun interruptedMaterializationWait(
        peerId: String,
        transferId: String,
        rawByteCount: Long,
        encodedByteCount: Long,
        estimatedByteCount: Long,
        cause: InterruptedException,
    ): RelayException = RelayException(
        "Interrupted while waiting to materialize chunked relay request from peer '$peerId' for " +
            "transfer '$transferId': raw payload is $rawByteCount bytes, encoded payload is " +
            "$encodedByteCount bytes, estimated materialization is $estimatedByteCount bytes, " +
            "and the process-wide materialization limit is $capacityBytes bytes",
        cause,
    )
}

/** Shares bounded file-backed request storage across every RelayService in this JVM. */
private object RelayRequestTemporaryStorageLedger {
    private val lock = Any()
    private var retainedByteCount = 0L

    fun reserve(peerId: String, transferId: String, requestedByteCount: Long): AutoCloseable {
        RelayRequestTemporaryStorageCleanupRegistry.retryPendingCleanup()
        val lease = IdempotentRelayRequestLease {
            synchronized(lock) {
                check(retainedByteCount >= requestedByteCount) {
                    "Relay request temporary-storage accounting released $requestedByteCount " +
                        "bytes while only $retainedByteCount bytes were retained"
                }
                retainedByteCount -= requestedByteCount
            }
        }
        synchronized(lock) {
            if (requestedByteCount > MAX_RELAY_REQUEST_TEMPORARY_STORAGE_BYTES - retainedByteCount) {
                throw RelayException(
                    "Rejected chunked relay request from peer '$peerId' for transfer '$transferId': " +
                        "requested temporary storage is $requestedByteCount bytes, retained " +
                        "temporary storage is $retainedByteCount bytes, and the process-wide " +
                        "temporary-storage limit is $MAX_RELAY_REQUEST_TEMPORARY_STORAGE_BYTES bytes"
                )
            }
            retainedByteCount += requestedByteCount
        }
        return lease
    }
}

/**
 * Retains temporary files whose deletion failed so their process-wide storage stays charged.
 *
 * Cleanup runs outside this registry's lock. A filesystem can block or call back into unrelated
 * code while deleting, and neither case may stop another registry update.
 */
private object RelayRequestTemporaryStorageCleanupRegistry {
    private val lock = Any()
    private val pendingCleanup = LinkedHashSet<RelayRequestTemporaryFile>()

    fun retain(temporaryFile: RelayRequestTemporaryFile) {
        synchronized(lock) {
            pendingCleanup += temporaryFile
        }
    }

    fun retryPendingCleanup() {
        val candidates = synchronized(lock) { pendingCleanup.toList() }
        candidates.forEach { temporaryFile ->
            val retryFailure = temporaryFile.retryCleanup()
            if (retryFailure != null) {
                // RelayRequestTemporaryFile reports every failed attempt through the owning
                // RelayService's public warning snapshot. Keep the owner registered and continue
                // trying unrelated retained files rather than hiding the failure or stopping the
                // whole reservation path.
            }
            if (temporaryFile.hasReleasedStorage()) {
                synchronized(lock) {
                    pendingCleanup.remove(temporaryFile)
                }
            }
        }
    }
}

/** Owns one temporary path and releases its ledger lease only after that path is absent. */
private class RelayRequestTemporaryFile(
    private val fileSystem: FileSystem,
    private val path: Path,
    private val temporaryStorageLease: AutoCloseable,
    private val reportCleanupFailure: (RelayRequestTemporaryStorageCleanupWarningEffect) -> Unit,
) {
    private val cleanupLock = Any()
    private var handle: FileHandle? = null
    private var cleanupStarted = false
    private var handleClosed = false
    private var permanentHandleCloseFailure: Throwable? = null
    private var storageReleased = false
    private var cleanupAttemptCount = 0

    fun attach(openedHandle: FileHandle) {
        synchronized(cleanupLock) {
            check(handle == null && !cleanupStarted) {
                "Cannot attach a handle after temporary relay request cleanup started for '$path'"
            }
            handle = openedHandle
        }
    }

    fun openedHandle(): FileHandle = synchronized(cleanupLock) {
        checkNotNull(handle) { "Temporary relay request file '$path' has no open handle" }
    }

    fun closeAndDelete(primaryFailure: Throwable? = null): Throwable? {
        val failure = synchronized(cleanupLock) {
            cleanupStarted = true
            cleanupAttemptCount += 1
            var accumulatedFailure = primaryFailure
            val earlierCloseFailure = permanentHandleCloseFailure
            if (earlierCloseFailure != null) {
                val retainedFailure = RelayException(
                    "Temporary relay request file '$path' remains retained because its FileHandle " +
                        "close previously failed with ${relayCleanupFailureDescription(earlierCloseFailure)}; " +
                        "Okio FileHandle cannot retry a close after it throws",
                    earlierCloseFailure,
                )
                reportCleanupFailure(
                    relayRequestTemporaryStorageCleanupWarning(
                        path = path,
                        operation = "close",
                        attempt = cleanupAttemptCount,
                        failure = earlierCloseFailure,
                        closePreviouslyFailed = true,
                    )
                )
                accumulatedFailure = appendRelayRequestCleanupFailure(
                    accumulatedFailure,
                    retainedFailure,
                )
            } else if (!handleClosed) {
                val attachedHandle = handle
                if (attachedHandle == null) {
                    handleClosed = true
                } else {
                    try {
                        attachedHandle.close()
                        handleClosed = true
                    } catch (closeFailure: Throwable) {
                        permanentHandleCloseFailure = closeFailure
                        reportCleanupFailure(
                            relayRequestTemporaryStorageCleanupWarning(
                                path = path,
                                operation = "close",
                                attempt = cleanupAttemptCount,
                                failure = closeFailure,
                                closePreviouslyFailed = false,
                            )
                        )
                        accumulatedFailure = appendRelayRequestCleanupFailure(
                            accumulatedFailure,
                            closeFailure,
                        )
                    }
                }
            }
            if (handleClosed && !storageReleased) {
                try {
                    fileSystem.delete(path, mustExist = false)
                    temporaryStorageLease.close()
                    storageReleased = true
                } catch (deleteFailure: Throwable) {
                    reportCleanupFailure(
                        relayRequestTemporaryStorageCleanupWarning(
                            path = path,
                            operation = "delete",
                            attempt = cleanupAttemptCount,
                            failure = deleteFailure,
                            closePreviouslyFailed = false,
                        )
                    )
                    accumulatedFailure = appendRelayRequestCleanupFailure(
                        accumulatedFailure,
                        deleteFailure,
                    )
                }
            }
            accumulatedFailure
        }
        if (!hasReleasedStorage()) {
            RelayRequestTemporaryStorageCleanupRegistry.retain(this)
        }
        return failure
    }

    fun retryCleanup(): Throwable? = closeAndDelete()

    fun hasReleasedStorage(): Boolean = synchronized(cleanupLock) { storageReleased }
}

private fun relayCleanupFailureDescription(failure: Throwable): String =
    "${failure::class.java.name}: ${failure.message ?: "<no message>"}"

private fun relayRequestTemporaryStorageCleanupWarning(
    path: Path,
    operation: String,
    attempt: Int,
    failure: Throwable,
    closePreviouslyFailed: Boolean,
): RelayRequestTemporaryStorageCleanupWarningEffect {
    val failureDescription = relayCleanupFailureDescription(failure)
    val message = if (closePreviouslyFailed) {
        "Could not retry cleanup attempt $attempt for temporary relay request file '$path' because " +
            "its FileHandle close previously failed with $failureDescription. Okio FileHandle cannot " +
            "retry a close after it throws, so the path was not deleted and its process-wide " +
            "storage charge remains retained."
    } else {
        "Failed to $operation temporary relay request file '$path' during cleanup attempt $attempt: " +
            "$failureDescription. The path was not deleted and its process-wide storage charge " +
            "remains retained."
    }
    return RelayRequestTemporaryStorageCleanupWarningEffect(
        path = path.toString(),
        operation = operation,
        cleanupAttempt = attempt,
        failureClass = failure::class.java.name,
        failureMessage = failure.message,
        closePreviouslyFailed = closePreviouslyFailed,
        storageChargeRetained = true,
        message = message,
    )
}

private fun appendRelayRequestCleanupFailure(
    primaryFailure: Throwable?,
    cleanupFailure: Throwable,
): Throwable = appendRelayCleanupFailure(primaryFailure, cleanupFailure)

private fun appendRelayCleanupFailure(
    primaryFailure: Throwable?,
    cleanupFailure: Throwable,
): Throwable {
    if (primaryFailure == null) return cleanupFailure
    if (primaryFailure !== cleanupFailure) primaryFailure.addSuppressed(cleanupFailure)
    return primaryFailure
}

/**
 * Stores one incomplete chunked relay request outside the JVM heap.
 *
 * Each sequence owns one fixed-width slot. Repeating a sequence overwrites that slot instead of
 * extending the file. [chunkSizes] records the exact logical size because only the slot width is
 * fixed; the final chunk, and valid chunks from older senders, may be shorter.
 */
private class FileBackedRelayChunkAssembly private constructor(
    val totalChunks: Int,
    private val temporaryFile: RelayRequestTemporaryFile,
    private val handle: FileHandle,
) : AutoCloseable {
    private val chunkSizes = IntArray(totalChunks) { -1 }
    private var storedRawByteCount = 0L

    val rawByteCount: Long get() = storedRawByteCount

    fun writeChunk(sequence: Int, bytes: ByteArray) {
        val fileOffset = sequence.toLong() * RELAY_REQUEST_CHUNK_BYTES.toLong()
        handle.write(fileOffset, bytes, 0, bytes.size)
        val previousSize = chunkSizes[sequence]
        chunkSizes[sequence] = bytes.size
        storedRawByteCount += bytes.size.toLong() - maxOf(previousSize, 0).toLong()
    }

    fun isComplete(): Boolean = chunkSizes.all { it >= 0 }

    fun encodePayload(): String {
        check(isComplete()) { "Cannot encode an incomplete relay request assembly" }
        val encodedByteCount = relayRequestEncodedByteCount(rawByteCount)
        require(encodedByteCount <= Int.MAX_VALUE.toLong()) {
            "Completed relay request needs $encodedByteCount Base64 bytes, which exceeds the " +
                "${Int.MAX_VALUE}-byte in-memory payload limit"
        }

        val encodedBytes = java.io.ByteArrayOutputStream(encodedByteCount.toInt())
        Base64.getEncoder().wrap(encodedBytes).use { encoder ->
            val readBytes = ByteArray(8 * 1024)
            for (sequence in chunkSizes.indices) {
                var fileOffset = sequence.toLong() * RELAY_REQUEST_CHUNK_BYTES.toLong()
                var remaining = chunkSizes[sequence]
                while (remaining > 0) {
                    val requested = minOf(remaining, readBytes.size)
                    val read = handle.read(fileOffset, readBytes, 0, requested)
                    if (read <= 0) {
                        throw EOFException(
                            "Temporary relay request assembly ended with $remaining bytes still " +
                                "expected in chunk $sequence"
                        )
                    }
                    encoder.write(readBytes, 0, read)
                    remaining -= read
                    fileOffset += read.toLong()
                }
            }
        }
        return encodedBytes.toString(StandardCharsets.ISO_8859_1)
    }

    override fun close() {
        temporaryFile.closeAndDelete()?.let { throw it }
    }

    companion object {
        fun create(
            fileSystem: FileSystem,
            temporaryDirectory: Path,
            totalChunks: Int,
            temporaryStorageLease: AutoCloseable,
            reportCleanupFailure: (RelayRequestTemporaryStorageCleanupWarningEffect) -> Unit,
        ): FileBackedRelayChunkAssembly {
            val path = temporaryDirectory /
                "urlprotocol-relay-request-${UUID.randomUUID()}.chunks"
            val temporaryFile = RelayRequestTemporaryFile(
                fileSystem,
                path,
                temporaryStorageLease,
                reportCleanupFailure,
            )
            return try {
                val handle = fileSystem.openReadWrite(
                    path,
                    mustCreate = true,
                    mustExist = false,
                )
                temporaryFile.attach(handle)
                FileBackedRelayChunkAssembly(
                    totalChunks = totalChunks,
                    temporaryFile = temporaryFile,
                    handle = temporaryFile.openedHandle(),
                )
            } catch (failure: Throwable) {
                throw temporaryFile.closeAndDelete(failure) ?: failure
            }
        }
    }
}

private fun closeRelayChunkAssembly(
    assembly: FileBackedRelayChunkAssembly,
    primaryFailure: Throwable? = null,
): Throwable? {
    var failure = primaryFailure
    try {
        assembly.close()
    } catch (cleanupFailure: Throwable) {
        val firstFailure = failure
        if (firstFailure == null) {
            failure = cleanupFailure
        } else {
            firstFailure.addSuppressed(cleanupFailure)
        }
    }
    return failure
}

/**
 * Reports that a relay finished removing stream-owned state for a disconnected peer.
 *
 * [cachedAnnouncementRemoved] is `true` when that cleanup removed at least one cached service
 * announcement belonging to [peerId]. The effect is emitted after registration and cache cleanup
 * and after the disconnected stream sender has closed.
 */
class RelayDisconnectedPeerCleanupEffect(
    val peerId: String,
    val cachedAnnouncementRemoved: Boolean
) : NotificationEffect(
    "Relay finished disconnect cleanup for peer '$peerId'; " +
        "cached announcement removed: $cachedAnnouncementRemoved",
    MessageSeverity.INFO
)

private fun MessageDigest.updateInt(value: Int) {
    update((value ushr 24).toByte())
    update((value ushr 16).toByte())
    update((value ushr 8).toByte())
    update(value.toByte())
}

private fun MessageDigest.updateString(value: String) {
    val bytes = value.toByteArray(StandardCharsets.UTF_8)
    updateInt(bytes.size)
    update(bytes)
}

private fun MessageDigest.updateNullableString(value: String?) {
    update((if (value == null) 0 else 1).toByte())
    if (value != null) updateString(value)
}

private fun serviceAnnouncementContentHash(
    announcement: GossipProtocol.ServiceAnnouncement
): String {
    val digest = MessageDigest.getInstance("SHA-256")
    digest.updateString(announcement.serviceUrl)
    digest.updateString(announcement.serviceIdentifier)
    digest.updateString(announcement.providerPeerId)
    digest.updateInt(announcement.providerMultiaddresses.size)
    announcement.providerMultiaddresses.forEach(digest::updateString)
    digest.updateInt(announcement.stunAddresses.size)
    announcement.stunAddresses.forEach(digest::updateString)
    digest.updateInt(announcement.turnServers.size)
    for (turnServer in announcement.turnServers) {
        digest.updateString(turnServer.url)
        digest.updateNullableString(turnServer.username)
        digest.updateNullableString(turnServer.credential)
    }
    val sortedMetadata = announcement.metadata.entries.sortedBy { it.key }
    digest.updateInt(sortedMetadata.size)
    for ((key, value) in sortedMetadata) {
        digest.updateString(key)
        digest.updateString(value)
    }
    return Base64.getEncoder().encodeToString(digest.digest())
}

private class CompletionQueueFutureTask<T>(
    callable: Callable<T>,
    private val completionQueue: BlockingQueue<Future<T>>,
    private val onDone: (Future<T>) -> Unit
) : FutureTask<T>(callable) {
    override fun done() {
        onDone(this)
        completionQueue.offer(this)
    }
}

// Only request-created dials use this view. Independent registration and maintenance keep
// their original Clock and failure behavior.
private sealed interface RelayRequestDialOutcome {
    data object Pending : RelayRequestDialOutcome
    data class Failed(val failure: Throwable) : RelayRequestDialOutcome
    data class Committed(val connection: RelayConnection?) : RelayRequestDialOutcome
}

private class RelayRequestDialClock(val source: Clock) : Clock by source {
    // Clock failure and winner commitment compete for this same decision.
    val outcome = AtomicReference<RelayRequestDialOutcome>(RelayRequestDialOutcome.Pending)
    override fun currentTimeMillis(): Long = observeRelayDialClock(this) { source.currentTimeMillis() }
    override fun schedule(atMillis: Long, callback: () -> Unit): Scheduled =
        observeRelayDialClock(this) { source.schedule(atMillis, callback) }
    override fun unschedule(scheduled: Scheduled) = observeRelayDialClock(this) { source.unschedule(scheduled) }
}

// The private signal crosses the transport-only Exception catches without changing the
// original Throwable. Future completion can wrap it; the request retains its cause separately.
private class RelayDialClockFailure(val original: Throwable) : Error(null, original, false, false)

private inline fun <T> observeRelayDialClock(clock: RelayRequestDialClock, operation: () -> T): T = try {
    operation()
} catch (failure: Throwable) {
    val outcome = clock.outcome.updateAndGet { previous ->
        if (previous === RelayRequestDialOutcome.Pending) RelayRequestDialOutcome.Failed(failure) else previous
    }
    val first = (outcome as? RelayRequestDialOutcome.Failed)?.failure ?: failure
    if (first !== failure) first.addSuppressed(failure)
    throw RelayDialClockFailure(first)
}

private fun requestRelayDialClockFailure(clock: RelayRequestDialClock, targetPeerId: String): RelayRequestClockException? =
    (clock.outcome.get() as? RelayRequestDialOutcome.Failed)?.failure?.let {
        RelayRequestClockException("Clock failed while dialing relay request for target $targetPeerId", it)
    }

// Cleanup diagnostics belong to the original cause, which request adapters unwrap.
private fun relayDialCleanupCause(clock: Clock, failure: Throwable? = null): Throwable? =
    ((clock as? RelayRequestDialClock)?.outcome?.get() as? RelayRequestDialOutcome.Failed)?.failure
        ?: if (failure is RelayRequestClockException) failure.cause else failure

private fun recordRelayDialCleanupFailure(clock: Clock, cleanup: Throwable, failure: Throwable? = null) {
    val original = relayDialCleanupCause(clock, failure)
    val detail = if (cleanup is java.util.concurrent.CompletionException || cleanup is ExecutionException)
        cleanup.cause ?: cleanup else cleanup
    if (original != null) {
        if (original !== detail) original.addSuppressed(detail)
    } else if (detail is Error) {
        throw detail
    }
    // Without a request failure, ordinary transport cleanup keeps its best-effort behavior.
}

private inline fun relayDialCleanup(clock: Clock, failure: Throwable? = null, cleanup: () -> Unit) {
    try { cleanup() } catch (later: Throwable) { recordRelayDialCleanupFailure(clock, later, failure) }
}

private fun closeRelayDialStream(clock: Clock, stream: io.libp2p.core.Stream?) {
    if (stream == null) return
    relayDialCleanup(clock) {
        stream.close().whenComplete { _, failure ->
            if (failure != null) recordRelayDialCleanupFailure(clock, failure)
        }
    }
}

private fun closeRelayDialConnection(clock: Clock, connection: RelayConnection, failure: Throwable? = null) {
    relayDialCleanup(clock, failure) {
        val original = relayDialCleanupCause(clock, failure)
        if (original == null && clock !is RelayRequestDialClock) connection.close()
        else closeRelayRegistration(connection.closeState, 0L, false, null,
            reportFailureToCleanupCaller = true,
            cleanupFailureReporter = { recordRelayDialCleanupFailure(clock, it, original) })
    }
}

// Both reused-parent and cold acquisitions carry the same operation-owned Clock view.
private fun openRelayDialStream(
    host: Host, peer: PeerId, address: Multiaddr, clock: Clock,
): io.libp2p.core.StreamPromise<RelayMessageSender> =
    if (host is RelayStreamHost) {
        host.newStreamWithClock(listOf(RelayProtocol.PROTOCOL_ID), peer, clock, address)
    } else {
        host.newStream(listOf(RelayProtocol.PROTOCOL_ID), peer, address)
    }

private const val MAX_IDLE_RELAY_REQUEST_CONNECTIONS_PER_PEER = 4

@Volatile
private var relayReceiveLedgerInvariantTestMode = false

// Cached announcements retain only this scalar generation value, never a stream or handler
// reference. That lets disconnect cleanup identify the stream that wrote an entry without
// extending the lifetime of the transport objects being cleaned up.
private val nextRelayServerStreamGeneration = AtomicLong(0L)

/**
 * Whether [connection]'s physical channel is at its inbound admission boundary, with automatic
 * reads held by admission control. The controller keeps a controlled lifecycle read pending, but
 * the root may be shed if the peer sends another excess stream, so relay callers must not commit
 * new work to it. Returns false for transports that expose no Netty channel to interrogate.
 */
private fun relayConnectionReadsPausedByAdmission(connection: io.libp2p.core.Connection): Boolean {
    val channel =
        (connection as? io.libp2p.transport.implementation.P2PChannelOverNetty)?.nettyChannel
            ?: return false
    return inboundReadsPausedByAdmission(libp2pRootConnectionChannel(channel))
}

private class IdleRelayRequestConnections {
    val connections = java.util.ArrayDeque<RelayConnection>()
}

/**
 * Interface for sending messages on a relay stream without blocking reads.
 *
 * Server-side relay streams use [StreamRelayMessageSender] (write-only, no blocking reader).
 * Client-side relay streams use [RelayStreamController] (full blocking read/write).
 *
 * [sendMessage] must never silently discard a message: it either accepts the message into the
 * sender's ordered delivery path or throws [RelayException]. For the concrete stream-backed
 * senders, acceptance means admission to the libp2p stream's Netty transport after at most the
 * default 200 ms backpressure budget; it does not mean remote acknowledgement. The private
 * registration-ACK gate is the one adapter that first accepts messages into its ordered pre-ACK
 * queue before forwarding them to a stream sender. This distinction is required by [close]: its
 * [io.libp2p.core.Stream.closeWrite] barrier can drain transport-admitted writes, but it cannot flush
 * a frame that the bounded backpressure path rejected before it entered the transport.
 *
 * Concrete stream-backed implementations also expose an additive two-argument `sendMessage`
 * overload that accepts a caller-supplied admission budget and returns whether admission occurred.
 * The one-argument method remains source- and binary-compatible for existing callers while making
 * its former silent-drop outcome a caller-visible exception.
 */
interface RelayMessageSender : AutoCloseable {
    fun isClosed(): Boolean
    fun sendMessage(json: JSONObject)

    /**
     * Closes the underlying stream. Before tearing down, awaits the per-stream flush
     * barrier ([io.libp2p.core.Stream.closeWrite]) for up to [flushTimeoutMs] milliseconds
     * so messages already admitted to the transport (notably the final write before close,
     * e.g. RelayUnregister) can drain to the wire. This timeout does not affect admission:
     * a message rejected by [sendMessage] before entering the transport cannot be recovered by
     * the close barrier. Returns `true` if the flush completed within the timeout (or there was
     * nothing to flush), `false` if the timeout expired with bytes still pending.
     *
     * Default implementation closes immediately with no flush; concrete senders backed by a
     * libp2p stream override this to await `stream.closeWrite()`.
     */
    fun close(flushTimeoutMs: Long): Boolean {
        close()
        return true
    }

    /**
     * `AutoCloseable.close()` — closes without waiting for any pending writes to flush.
     *
     * Callers that need flush-on-close semantics (notably `RelayService.unregisterFromRelay`,
     * which sends a final `RelayUnregister` message and needs the bytes on the wire before
     * the channel goes away) must call [close] with an explicit `flushTimeoutMs` value.
     *
     * The no-arg form deliberately does NOT pay the flush cost. Several teardown paths
     * (`RelayService.close`, registered-peer cleanup on shutdown, listener-thread cleanup)
     * call AutoCloseable.close on N senders / connections in sequence — defaulting those
     * to a 1 s flush ceiling each turned per-instance close latency from O(ms) into O(1s)
     * per relay link, multiplied across registered peers. Stress tests that churn many
     * short-lived peers (e.g. `stressTestCloseDoesNotExhaustDispatchersIO`) saw 12+
     * timeouts under that default. Flush-on-close is opt-in via the explicit
     * `flushTimeoutMs` parameter; teardown paths that don't care can keep using the cheap
     * no-arg form.
     */
    override fun close() {
        close(0L)
    }
}

private fun relayMessageNotAdmittedMessage(maxAdmissionWaitMs: Long): String =
    "Relay message was not admitted within the ${maxAdmissionWaitMs}ms budget: " +
        "stream/connection was closed or remained unwritable, or the per-connection " +
        "parked-write budget was exhausted"

private fun framedRelayJsonBuffer(json: JSONObject): ByteBuf {
    val bytes = jsonWireBytes(json)
    return Unpooled.buffer(4 + bytes.size).apply {
        writeInt(bytes.size)
        writeBytes(bytes)
    }
}

private fun requireValidRelayAdmissionWait(maxAdmissionWaitMs: Long) {
    require(maxAdmissionWaitMs >= 0L) {
        "maxAdmissionWaitMs must be greater than or equal to 0, but was $maxAdmissionWaitMs"
    }
}

/**
 * Takes one registered-request handler slot from [running] without waiting. Returns null when a
 * slot was taken, or the running count that was observed when every one of
 * [RelayService.MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS] slots was already taken.
 */
private fun tryAdmitRelayedRequestHandler(running: AtomicInteger): Int? {
    while (true) {
        val current = running.get()
        if (current >= RelayService.MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS) return current
        if (running.compareAndSet(current, current + 1)) return null
    }
}

/**
 * One admitted registered-request handler slot. [release] returns it to [running] exactly once,
 * however many exit paths call it.
 */
private class RelayedRequestHandlerSlot(private val running: AtomicInteger) {
    private val released = AtomicBoolean(false)

    fun release() {
        if (released.compareAndSet(false, true)) running.decrementAndGet()
    }
}

/** The refusal sent for a relayed request that arrives while every handler slot is taken. */
private fun relayedRequestHandlerCapacityMessage(running: Int): String =
    "A relayed request was refused without running it: this peer is already running " +
        "$running relayed request handlers, which is the limit of " +
        "${RelayService.MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS} " +
        "(RelayService.MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS). Retry after one of them finishes."

private fun relayFailureFromResponse(
    response: RelayProtocol.RelayResponse,
    context: String
): RelayException {
    val message = "$context: ${response.displayErrorMessage()}"
    return if (response.wasDefinitelyNotDispatched()) {
        RelayRequestNotDispatchedException(message)
    } else {
        RelayException(message)
    }
}

private fun estimateJsonRetentionBytes(root: Any?): Long {
    val seen = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Any, Boolean>())

    fun saturatedAdd(left: Long, right: Long): Long =
        if (right >= Long.MAX_VALUE - left) Long.MAX_VALUE else left + right

    fun estimate(value: Any?): Long {
        if (value == null || value === JSONObject.NULL) return 8L
        return when (value) {
            is String -> saturatedAdd(40L, value.length.toLong() * 2L)
            is Number, is Boolean -> 24L
            is JSONObject -> {
                if (!seen.add(value)) return 0L
                var bytes = 64L
                for (key in value.keySet()) {
                    bytes = saturatedAdd(bytes, estimate(key))
                    bytes = saturatedAdd(bytes, estimate(value.opt(key)))
                    if (bytes > ORDINARY_RELAY_GOSSIP_BYTES_GLOBAL) break
                }
                bytes
            }
            is org.json.JSONArray -> {
                if (!seen.add(value)) return 0L
                var bytes = 48L
                for (index in 0 until value.length()) {
                    bytes = saturatedAdd(bytes, estimate(value.opt(index)))
                    if (bytes > ORDINARY_RELAY_GOSSIP_BYTES_GLOBAL) break
                }
                bytes
            }
            else -> saturatedAdd(40L, value.toString().length.toLong() * 2L)
        }
    }

    return estimate(root)
}

private fun boundedOrdinaryGossipDiagnosticField(value: String, maxUtf8Bytes: Int): String {
    var index = 0
    var bytes = 0
    while (index < value.length) {
        val codePoint = Character.codePointAt(value, index)
        val codePointBytes = when {
            codePoint <= 0x7f -> 1
            codePoint <= 0x7ff -> 2
            codePoint <= 0xffff -> 3
            else -> 4
        }
        if (bytes + codePointBytes > maxUtf8Bytes) break
        bytes += codePointBytes
        index += Character.charCount(codePoint)
    }
    return if (index == value.length) value else value.substring(0, index) + "[truncated]"
}

/**
 * One lazily prepared wire representation shared by every registered-peer delivery of one gossip
 * message. Preparation stays off the ingress/handler thread: the first outbox worker serializes the
 * message and all competing workers wait for and reuse that result. Each stream then gets an
 * independent ByteBuf view with its own reader index and reference count.
 */
private class PreparedRelayGossipMessage private constructor(
    source: JSONObject,
    val messageType: String,
    val diagnosticMessageId: String,
    val retainedBytes: Long
) {
    private var source: JSONObject? = source
    @Volatile private var framedBytes: ByteArray? = null
    @Volatile private var framingFailure: RelayException? = null

    private fun frame(): ByteArray {
        framedBytes?.let { return it }
        framingFailure?.let { throw it }
        return synchronized(this) {
            framedBytes?.let { return@synchronized it }
            framingFailure?.let { throw it }
            try {
                val jsonBytes = jsonWireBytes(
                    checkNotNull(source) {
                        "Relay gossip source disappeared before its wire frame was prepared"
                    }
                )
                val prepared = ByteArray(4 + jsonBytes.size)
                prepared[0] = (jsonBytes.size ushr 24).toByte()
                prepared[1] = (jsonBytes.size ushr 16).toByte()
                prepared[2] = (jsonBytes.size ushr 8).toByte()
                prepared[3] = jsonBytes.size.toByte()
                jsonBytes.copyInto(prepared, destinationOffset = 4)
                source = null
                framedBytes = prepared
                prepared
            } catch (failure: Exception) {
                val relayFailure = RelayException(
                    "Failed to serialize relay gossip message of type '$messageType'",
                    failure
                )
                source = null
                framingFailure = relayFailure
                throw relayFailure
            }
        }
    }

    fun newBuffer(): ByteBuf = Unpooled.wrappedBuffer(frame())

    fun toJson(): JSONObject {
        val prepared = frame()
        return parseJsonWireString(String(prepared, 4, prepared.size - 4, StandardCharsets.UTF_8))
    }

    companion object {
        fun from(message: JSONObject): PreparedRelayGossipMessage = PreparedRelayGossipMessage(
            source = message,
            messageType = message.optString("type", "unknown"),
            diagnosticMessageId = boundedOrdinaryGossipDiagnosticField(
                message.optString("messageId", "unknown"), 128,
            ),
            retainedBytes = estimateJsonRetentionBytes(message)
        )
    }
}

private sealed interface AckGatedPendingMessage {
    data class Json(val value: JSONObject) : AckGatedPendingMessage
    data class PreparedGossip(val value: PreparedRelayGossipMessage) : AckGatedPendingMessage
}

private class AckGatedRelayMessageSender(
    private val delegate: RelayMessageSender
) : RelayMessageSender {
    private val lock = Any()
    private val pendingMessages = ArrayDeque<AckGatedPendingMessage>()
    private var released = false

    override fun isClosed(): Boolean = delegate.isClosed()

    override fun sendMessage(json: JSONObject) {
        synchronized(lock) {
            if (!released) {
                pendingMessages.addLast(
                    AckGatedPendingMessage.Json(parseJsonWireString(jsonWireString(json)))
                )
                return
            }
        }
        delegate.sendMessage(json)
    }

    fun sendMessage(json: JSONObject, maxAdmissionWaitMs: Long): Boolean {
        synchronized(lock) {
            if (!released) {
                pendingMessages.addLast(
                    AckGatedPendingMessage.Json(parseJsonWireString(jsonWireString(json)))
                )
                return true
            }
        }
        return delegate.trySendMessage(json, maxAdmissionWaitMs)
    }

    fun sendPreparedGossip(message: PreparedRelayGossipMessage) {
        if (!sendPreparedGossip(message, WRITE_BACKPRESSURE_WAIT_MS)) {
            throw RelayException(relayMessageNotAdmittedMessage(WRITE_BACKPRESSURE_WAIT_MS))
        }
    }

    /**
     * Honours the caller's admission budget once the ACK has released this gate. A caller that owns
     * its own overall budget - the link-state fan-out offers every destination a zero-wait probe
     * inside one shared interval - must not be charged this wrapper's default wait instead.
     */
    fun sendPreparedGossip(
        message: PreparedRelayGossipMessage,
        maxAdmissionWaitMs: Long
    ): Boolean {
        synchronized(lock) {
            if (!released) {
                pendingMessages.addLast(AckGatedPendingMessage.PreparedGossip(message))
                return true
            }
        }
        return delegate.trySendPreparedGossip(message, maxAdmissionWaitMs)
    }

    fun sendAckAndRelease(ackJson: JSONObject): List<AckGatedPendingMessage> {
        synchronized(lock) {
            delegate.sendMessage(ackJson)
            released = true
            val buffered = pendingMessages.toList()
            pendingMessages.clear()
            return buffered
        }
    }

    override fun close(flushTimeoutMs: Long): Boolean = delegate.close(flushTimeoutMs)

    override fun close() {
        delegate.close()
    }

    fun diagnosticStream(): Stream? = delegate.relayDiagnosticStream()

    fun wraps(sender: RelayMessageSender): Boolean = delegate === sender
}

internal fun RelayMessageSender.relayDiagnosticStream(): Stream? = when (this) {
    is StreamRelayMessageSender -> diagnosticStream
    is RelayStreamController -> diagnosticStream
    is AckGatedRelayMessageSender -> diagnosticStream()
    else -> null
}

internal fun RelayMessageSender.matchesStreamSender(sender: RelayMessageSender): Boolean =
    this === sender || (this is AckGatedRelayMessageSender && wraps(sender))

private fun RelayMessageSender.trySendMessage(
    json: JSONObject,
    maxAdmissionWaitMs: Long
): Boolean = when (this) {
    is StreamRelayMessageSender -> sendMessage(json, maxAdmissionWaitMs)
    is RelayStreamController -> sendMessage(json, maxAdmissionWaitMs)
    is AckGatedRelayMessageSender -> sendMessage(json, maxAdmissionWaitMs)
    else -> {
        sendMessage(json)
        true
    }
}

private fun RelayMessageSender.trySendPreparedGossip(
    message: PreparedRelayGossipMessage,
    maxAdmissionWaitMs: Long
): Boolean = when (this) {
    is StreamRelayMessageSender -> sendFramedMessage(message.newBuffer(), maxAdmissionWaitMs)
    // A registered peer's controller and the upstream relay connection both reach this path, and
    // the link-state fan-out re-offers the same prepared frame to a still-unwritable destination
    // once per poll round inside its shared budget. Going through [trySendMessage] would parse the
    // prepared frame back into a JSONObject and re-serialize it on every one of those attempts;
    // the prepared frame's bytes are already exactly what goes on the wire.
    is RelayStreamController -> sendFramedMessage(message.newBuffer(), maxAdmissionWaitMs)
    is AckGatedRelayMessageSender -> sendPreparedGossip(message, maxAdmissionWaitMs)
    else -> trySendMessage(message.toJson(), maxAdmissionWaitMs)
}

private fun RelayMessageSender.sendPendingMessage(message: AckGatedPendingMessage) {
    when (message) {
        is AckGatedPendingMessage.Json -> sendMessage(message.value)
        is AckGatedPendingMessage.PreparedGossip -> {
            if (!trySendPreparedGossip(message.value, WRITE_BACKPRESSURE_WAIT_MS)) {
                throw RelayException(relayMessageNotAdmittedMessage(WRITE_BACKPRESSURE_WAIT_MS))
            }
        }
    }
}

private const val ORDINARY_RELAY_GOSSIP_MESSAGES_PER_PEER = 8
private const val ORDINARY_RELAY_GOSSIP_BYTES_PER_PEER = 12L * 1024L * 1024L
private const val ORDINARY_RELAY_GOSSIP_BYTES_GLOBAL = 24L * 1024L * 1024L
private const val RELAY_RECEIVE_CALLBACK_PEERS = 64
private const val RELAY_RECEIVE_CALLBACK_BYTES_PER_PEER = 24L * 1024L * 1024L
private const val RELAY_RECEIVE_SERVICE_STATE_KEYS_PER_PEER = 4096

private data class RelayReceiveServiceStateKey(
    val providerPeerId: String,
    val serviceIdentifier: String,
)

private data class RelayReceiveServiceStateRecency(
    val providerTimestamp: Long,
    val isWithdrawal: Boolean,
)

private fun serviceStateSupersedes(
    previous: RelayReceiveServiceStateRecency,
    candidate: RelayReceiveServiceStateRecency,
): Boolean = when {
    candidate.providerTimestamp > previous.providerTimestamp -> true
    candidate.providerTimestamp < previous.providerTimestamp -> false
    candidate.isWithdrawal && !previous.isWithdrawal -> true
    else -> false
}

private typealias RelayReceiveServiceStateApplication = (
    application: () -> Boolean,
    publishWatermark: () -> Unit,
) -> Boolean

private enum class RelayReceiveCallbackDropReason {
    CALLBACK_COUNT,
    RETAINED_BYTES,
}

private sealed interface RelayReceiveCallbackOfferResult {
    object Accepted : RelayReceiveCallbackOfferResult
    object Closed : RelayReceiveCallbackOfferResult
    data class Dropped(
        val queuedCallbacks: Int,
        val retainedBytes: Long,
        val retainedByteLimitPerPeer: Long,
        val activePeerLanes: Int,
        val reason: RelayReceiveCallbackDropReason,
    ) : RelayReceiveCallbackOfferResult
}

/**
 * Immutable operational view of relay callback work retained by this service.
 *
 * Retained bytes include queued and executing callback payloads. A service is quiescent only after
 * every retained payload, queued callback, executing callback, and capacity wait has ended.
 */
data class RelayReceiveQueueSnapshot(
    val retainedBytes: Long,
    val queuedCallbacks: Int,
    val activeCallbacks: Int,
    val waitingServiceStateOffers: Int,
    val activePeerLanes: Int,
    val retiredPeerLanes: Int,
    val retainedByteLimitPerPeer: Long,
) {
    val isQuiescent: Boolean
        get() = retainedBytes == 0L &&
            queuedCallbacks == 0 &&
            activeCallbacks == 0 &&
            waitingServiceStateOffers == 0
}

/**
 * Keeps one relay connection's receive admission work in wire order without parking its control
 * reader behind a bounded service-state capacity wait.
 *
 * The worker removes a task from [pending] before running it. This leaves one bounded handoff slot
 * available while the task itself waits in [RelayReceiveCallbackQueue.offer]. A later control frame
 * can therefore be read and correlated, while parsed application-facing frames remain bounded and
 * ordered. Closing the connection interrupts the worker so a capacity wait does not outlive the
 * stream generation.
 */
private class RelayReceiveCallbackAdmissionDispatcher(
    private val executor: Executor,
    private val maxPendingMessages: Int,
    private val onFailure: (Throwable) -> Unit,
) : AutoCloseable {
    private val lock = ReentrantLock()
    private val changed = lock.newCondition()
    private val pending = ArrayDeque<() -> Unit>()
    private var workerScheduled = false
    private var workerThread: Thread? = null
    private var closed = false

    init {
        require(maxPendingMessages > 0) {
            "Relay receive admission dispatcher capacity must be positive, but was " +
                "$maxPendingMessages"
        }
    }

    /**
     * Adds one parsed receive task, waiting only for this dispatcher's bounded handoff capacity.
     * The task itself may wait in the receive ledger; that wait never runs on the control reader.
     */
    fun submit(task: () -> Unit): Boolean {
        var scheduleWorker = false
        lock.lockInterruptibly()
        try {
            while (!closed && pending.size >= maxPendingMessages) {
                changed.await()
            }
            if (closed) return false
            pending.addLast(task)
            if (!workerScheduled) {
                workerScheduled = true
                scheduleWorker = true
            }
        } finally {
            lock.unlock()
        }

        if (!scheduleWorker) return true
        return try {
            executor.execute(::drain)
            true
        } catch (_: RejectedExecutionException) {
            lock.withLock {
                closed = true
                pending.clear()
                workerScheduled = false
                changed.signalAll()
            }
            false
        }
    }

    private fun drain() {
        val worker = Thread.currentThread()
        val shouldRun = lock.withLock {
            workerThread = worker
            if (closed) {
                pending.clear()
                workerScheduled = false
                changed.signalAll()
                false
            } else {
                true
            }
        }
        if (!shouldRun) {
            lock.withLock {
                if (workerThread === worker) workerThread = null
                changed.signalAll()
            }
            return
        }
        try {
            while (true) {
                val task = lock.withLock {
                    if (closed || pending.isEmpty()) {
                        if (closed) pending.clear()
                        workerScheduled = false
                        changed.signalAll()
                        null
                    } else {
                        pending.removeFirst().also { changed.signalAll() }
                    }
                } ?: return

                try {
                    task()
                } catch (failure: Throwable) {
                    try {
                        onFailure(failure)
                    } catch (reportFailure: Throwable) {
                        System.err.println(
                            "Relay receive admission failure reporting also failed: " +
                                "${reportFailure::class.java.name}: ${reportFailure.message}"
                        )
                        reportFailure.printStackTrace(System.err)
                    }
                }
            }
        } finally {
            lock.withLock {
                if (workerThread === Thread.currentThread()) workerThread = null
                if (closed) {
                    pending.clear()
                    workerScheduled = false
                }
                changed.signalAll()
            }
        }
    }

    override fun close() {
        val worker = lock.withLock {
            if (closed) return
            closed = true
            pending.clear()
            workerScheduled = false
            changed.signalAll()
            workerThread
        }
        worker?.interrupt()
    }
}

/**
 * Bounded serial lanes for callbacks associated with frames read from a relay connection.
 *
 * A live relay connection owns one generation-tagged virtual-thread worker, so callbacks for that
 * connection keep wire order. Ordinary queued work does not cross a reconnect. Service-state work
 * that was accepted but not yet applied transfers to the replacement generation instead of being
 * lost. Ordinary callbacks are bounded by both count and estimated retained bytes and drop newest
 * when either bound is full.
 *
 * Service announcements and withdrawals are correctness-bearing state transitions. The queue
 * retains at most one accepted transition per (provider, service) key. Provider timestamps decide
 * recency, with withdrawal winning an equal-timestamp tie, matching the service inventory rule.
 * One per-key transition record owns the accepted entry, its application phase, and its applied
 * recency. Dequeue does not release that record or its retained-byte charge. Reconnect moves the
 * same record to the replacement lane, and only a higher-recency accepted entry may supersede it.
 * The record's interruptible application lock serializes same-key application across generations.
 * Every accepted entry also receives a monotonic sequence, so reconnect rebuilds the surviving
 * per-key entries in accepted arrival order instead of relying on map-key insertion order. After the
 * application callback returns, the relay catalog update and watermark publication run together
 * under the catalog monitor. The watermark therefore advances in application order, survives
 * dequeue and reconnect while the relay catalog retains that key as a live announcement or
 * withdrawal tombstone, and leaves when the catalog's existing lifecycle forgets the key. Queued
 * and in-flight payload memory is included in the same per-peer byte bound;
 * when a new key cannot fit, only this message class backpressures the reader until space is
 * available. Thus a withdrawal is never shed, total queued retained bytes stay bounded, and the
 * number of coalescing-map entries is additionally capped independently of message count.
 */
private class RelayReceiveCallbackQueue(
    private val executor: Executor,
    private val maxCallbacksPerPeer: Int,
    private val maxRetainedBytesPerPeer: Long,
    private val maxServiceStateKeysPerPeer: Int,
    private val maxPeerLanes: Int,
) : AutoCloseable {
    /**
     * Scheduling seam for tests that need to stop a newly scheduled worker before its first
     * dequeue. Production never installs it. Reconnect transfer and worker start otherwise have a
     * sub-millisecond scheduling window that cannot be ordered reliably from the public transport
     * path alone.
     */
    @Volatile
    private var workerStartSeam: (() -> Unit)? = null

    /** Installs, or with `null` removes, the [workerStartSeam]. */
    fun installWorkerStartSeam(seam: (() -> Unit)?) {
        workerStartSeam = seam
    }

    /**
     * Test-only notification emitted after a new receive entry has been charged. The service
     * identifier is present for service-state payloads and `null` for ordinary callbacks.
     */
    @Volatile
    private var admissionTestSeam: ((String?, Long) -> Unit)? = null

    /** Installs, or with `null` removes, the [admissionTestSeam]. */
    fun installAdmissionTestSeam(seam: ((String?, Long) -> Unit)?) {
        admissionTestSeam = seam
    }

    private class Entry(
        val beforeApplication: ((Any) -> Boolean)?,
        val callback: (Any) -> Boolean,
        val onFailure: (Any, Throwable, Boolean) -> Unit,
        val retainedBytes: Long,
        val serviceStateKey: RelayReceiveServiceStateKey?,
        val serviceStateRecency: RelayReceiveServiceStateRecency?,
        val applyServiceState: RelayReceiveServiceStateApplication?,
        val serviceStateTransition: ServiceStateTransition?,
        val acceptedSequence: Long,
    ) {
        var retainedLane: Lane? = null
        var activeExecutions = 0
        var beforeApplicationCompleted = false
        var chargeCreated = false
        var chargeReleased = false
    }

    private class ServiceStateTransition {
        val applicationLock = ReentrantLock()
        var latestAccepted: Entry? = null
        var appliedRecency: RelayReceiveServiceStateRecency? = null
    }

    private class Lane(val generation: Any) {
        val entries = ArrayDeque<Entry>()
        val serviceStateEntries = LinkedHashMap<RelayReceiveServiceStateKey, Entry>()
        val chargedEntries = LinkedHashSet<Entry>()
        var ordinaryCallbackCount = 0
        // Invariant: charged == sum of live entry sizes at every mutation boundary; exactly 0 at
        // quiescence. Every mutation goes through create, move, or release below.
        var retainedBytes = 0L
        var workerScheduled = false
        var workerThread: Thread? = null
    }

    private class LedgerInvariantTestState {
        val knownLanes: MutableSet<Lane> = java.util.Collections.newSetFromMap(
            java.util.IdentityHashMap<Lane, Boolean>()
        )
    }

    private val lock = java.util.concurrent.locks.ReentrantLock()
    private val capacityChanged = lock.newCondition()
    private var retainedByteLimitForTesting: Long? = null
    private val lanes = LinkedHashMap<String, Lane>()
    private val retiredServiceStateLanes = LinkedHashMap<String, Lane>()
    private val activeWorkerThreads = java.util.IdentityHashMap<Thread, Entry?>()
    private val serviceStateTransitions =
        LinkedHashMap<RelayReceiveServiceStateKey, ServiceStateTransition>()
    private var nextAcceptedSequence = 0L
    private var waitingServiceStateOfferCount = 0
    private var closed = false
    private var ledgerInvariantTestState: LedgerInvariantTestState? = null

    fun installRetainedByteLimitForTesting(limit: Long?) {
        require(limit == null || limit > 0L) {
            "The relay receive retained-byte test limit must be positive, but was $limit"
        }
        lock.withLock {
            retainedByteLimitForTesting = limit
            capacityChanged.signalAll()
        }
    }

    private fun retainedByteLimitLocked(): Long =
        retainedByteLimitForTesting ?: maxRetainedBytesPerPeer

    fun installLedgerInvariantCheckerForTesting() {
        lock.withLock {
            check(ledgerInvariantTestState == null) {
                "Relay receive ledger invariant checking was installed more than once"
            }
            ledgerInvariantTestState = LedgerInvariantTestState().also { state ->
                state.knownLanes.addAll(lanes.values)
                state.knownLanes.addAll(retiredServiceStateLanes.values)
                activeWorkerThreads.values.filterNotNull().mapNotNullTo(state.knownLanes) {
                    it.retainedLane
                }
            }
            relayReceiveLedgerInvariantTestMode = true
            checkLedgerInvariantForTestingLocked()
        }
    }

    fun retainedBytesForTesting(): Long = lock.withLock {
        ledgerInvariantTestState?.knownLanes?.sumOf(Lane::retainedBytes)
            ?: error("Relay receive ledger invariant checking is not installed")
    }

    /** Temporarily removes an active entry's charge so the test checker must reject the state. */
    fun forceEarlyEntryReleaseForTesting(): String = lock.withLock {
        check(ledgerInvariantTestState != null) {
            "Relay receive ledger invariant checking is not installed"
        }
        val entry = activeWorkerThreads.values.filterNotNull().firstOrNull()
            ?: error("Relay receive ledger test injection requires an active callback")
        val lane = checkNotNull(entry.retainedLane) {
            "Relay receive ledger test injection found an active entry without a charge owner"
        }
        check(lane.chargedEntries.remove(entry)) {
            "Relay receive ledger test injection found no charge for the active entry"
        }
        lane.retainedBytes -= entry.retainedBytes
        var checkerFailure: IllegalStateException? = null
        try {
            try {
                checkLedgerInvariantForTestingLocked()
            } catch (failure: IllegalStateException) {
                checkerFailure = failure
            }
        } finally {
            check(lane.chargedEntries.add(entry)) {
                "Relay receive ledger test injection could not restore the active entry charge"
            }
            lane.retainedBytes += entry.retainedBytes
            checkLedgerInvariantForTestingLocked()
        }
        return checkerFailure?.message
            ?: error("Relay receive ledger checker accepted an early release")
    }

    fun awaitQuiescenceForTesting(timeout: Long, unit: TimeUnit): Boolean {
        var remainingNanos = unit.toNanos(timeout)
        return lock.withLock {
            while (!ledgerIsQuiescentForTestingLocked() && remainingNanos > 0L) {
                remainingNanos = capacityChanged.awaitNanos(remainingNanos)
            }
            checkLedgerInvariantForTestingLocked()
            ledgerIsQuiescentForTestingLocked()
        }
    }

    private fun newLane(generation: Any): Lane = Lane(generation).also { lane ->
        if (relayReceiveLedgerInvariantTestMode) {
            ledgerInvariantTestState?.knownLanes?.add(lane)
        }
    }

    private fun retainedBytesForTestingLocked(): Long =
        checkNotNull(ledgerInvariantTestState) {
            "Relay receive ledger invariant checking is not installed"
        }.knownLanes.sumOf(Lane::retainedBytes)

    private fun ledgerIsQuiescentForTestingLocked(): Boolean {
        val state = checkNotNull(ledgerInvariantTestState) {
            "Relay receive ledger invariant checking is not installed"
        }
        return state.knownLanes.all { lane ->
            lane.retainedBytes == 0L && lane.chargedEntries.isEmpty()
        } && activeWorkerThreads.values.none { it != null }
    }

    private fun checkLedgerInvariantForTestingLocked() {
        val state = ledgerInvariantTestState ?: return
        val actuallyRetained: MutableSet<Entry> = java.util.Collections.newSetFromMap(
            java.util.IdentityHashMap<Entry, Boolean>()
        )
        state.knownLanes.forEach { lane ->
            actuallyRetained.addAll(lane.entries)
            actuallyRetained.addAll(lane.serviceStateEntries.values)
        }
        serviceStateTransitions.values.mapNotNullTo(actuallyRetained) { it.latestAccepted }
        activeWorkerThreads.values.filterNotNullTo(actuallyRetained)
        val ledgerEntries = state.knownLanes.flatMap(Lane::chargedEntries)
        check(ledgerEntries.size == ledgerEntries.toSet().size) {
            "Relay receive entry was charged in more than one lane"
        }
        val chargedBytes = state.knownLanes.sumOf(Lane::retainedBytes)
        val directlyWalkedBytes = actuallyRetained.sumOf(Entry::retainedBytes)
        check(ledgerEntries.toSet() == actuallyRetained) {
            "Relay receive retained-entry ledger invariant failed: ledgerEntries=" +
                "${ledgerEntries.size}, directlyWalkedLiveEntries=${actuallyRetained.size}; " +
                "every live entry must have exactly one charge"
        }
        state.knownLanes.forEach { lane ->
            val laneWalkBytes = lane.chargedEntries.sumOf(Entry::retainedBytes)
            check(lane.retainedBytes == laneWalkBytes) {
                "Relay receive per-lane retained-byte ledger invariant failed: " +
                    "chargedBytes=${lane.retainedBytes}, directlyWalkedChargeBytes=$laneWalkBytes"
            }
        }
        check(chargedBytes == directlyWalkedBytes) {
            "Relay receive retained-byte ledger invariant failed: chargedBytes=$chargedBytes, " +
                "directlyWalkedLiveEntryBytes=$directlyWalkedBytes, " +
                "liveEntries=${actuallyRetained.size}; charged must equal the sum of live entry " +
                "sizes at every mutation boundary and must be exactly zero at quiescence"
        }
    }

    fun openConnection(peerId: String, generation: Any): Boolean {
        var oldWorker: Thread? = null
        var laneToSchedule: Lane? = null
        val opened = lock.withLock {
            if (closed) return@withLock false
            val oldLane = lanes[peerId]
            if (oldLane?.generation === generation) return@withLock true
            val retiredLane = retiredServiceStateLanes.remove(peerId)
            if (oldLane == null && retiredLane == null &&
                lanes.size + retiredServiceStateLanes.size >= maxPeerLanes
            ) return@withLock false

            val replacementLane = newLane(generation)
            if (retiredLane != null) transferServiceStateEntries(retiredLane, replacementLane)
            if (oldLane != null) {
                oldWorker = oldLane.workerThread
                transferServiceStateEntries(oldLane, replacementLane)
                dropEntries(oldLane)
            }
            lanes[peerId] = replacementLane
            if (replacementLane.entries.isNotEmpty()) {
                replacementLane.workerScheduled = true
                laneToSchedule = replacementLane
            }
            capacityChanged.signalAll()
            true
        }
        oldWorker?.interrupt()
        val scheduledLane = laneToSchedule ?: return opened
        return try {
            executor.execute { drain(peerId, scheduledLane) }
            true
        } catch (_: RejectedExecutionException) {
            lock.withLock {
                if (lanes[peerId] === scheduledLane) {
                    lanes.remove(peerId)
                    retainServiceStateEntries(peerId, scheduledLane)
                    dropEntries(scheduledLane)
                    capacityChanged.signalAll()
                }
            }
            false
        }
    }

    fun closeConnection(peerId: String, generation: Any) {
        var worker: Thread? = null
        lock.withLock {
            val lane = lanes[peerId]
            if (lane?.generation !== generation) return
            lanes.remove(peerId)
            worker = lane.workerThread
            retainServiceStateEntries(peerId, lane)
            dropEntries(lane)
            capacityChanged.signalAll()
        }
        worker?.interrupt()
    }

    fun isCurrent(peerId: String, generation: Any): Boolean = lock.withLock {
        !closed && lanes[peerId]?.generation === generation
    }

    fun isWorkerThread(thread: Thread): Boolean = lock.withLock {
        activeWorkerThreads.containsKey(thread)
    }

    fun snapshot(): RelayReceiveQueueSnapshot = lock.withLock {
        val retainedLanes: MutableSet<Lane> = java.util.Collections.newSetFromMap(
            java.util.IdentityHashMap<Lane, Boolean>()
        )
        retainedLanes.addAll(lanes.values)
        retainedLanes.addAll(retiredServiceStateLanes.values)
        activeWorkerThreads.values.filterNotNull().mapNotNullTo(retainedLanes) {
            it.retainedLane
        }
        serviceStateTransitions.values.mapNotNullTo(retainedLanes) {
            it.latestAccepted?.retainedLane
        }
        RelayReceiveQueueSnapshot(
            retainedBytes = retainedLanes.sumOf(Lane::retainedBytes),
            queuedCallbacks = retainedLanes.sumOf { it.entries.size },
            activeCallbacks = activeWorkerThreads.values.count { it != null },
            waitingServiceStateOffers = waitingServiceStateOfferCount,
            activePeerLanes = lanes.size,
            retiredPeerLanes = retiredServiceStateLanes.size,
            retainedByteLimitPerPeer = retainedByteLimitLocked(),
        )
    }

    fun offer(
        peerId: String,
        generation: Any,
        retainedBytes: Long,
        serviceStateKey: RelayReceiveServiceStateKey?,
        serviceStateRecency: RelayReceiveServiceStateRecency?,
        losslessServiceState: Boolean,
        applyServiceState: RelayReceiveServiceStateApplication?,
        beforeApplication: ((Any) -> Boolean)?,
        callback: (Any) -> Boolean,
        onFailure: (Any, Throwable, Boolean) -> Unit,
    ): RelayReceiveCallbackOfferResult {
        var laneToSchedule: Lane? = null
        var admissionEvent: ((String?, Long) -> Unit)? = null
        val entryBytes = retainedBytes.coerceAtLeast(0L)
        val result = lock.withLock {
            var lane: Lane = lanes[peerId]
                ?: return@withLock RelayReceiveCallbackOfferResult.Closed
            if (closed || lane.generation !== generation) {
                return@withLock RelayReceiveCallbackOfferResult.Closed
            }

            if (serviceStateKey != null) {
                val candidateRecency = checkNotNull(serviceStateRecency) {
                    "Relay service state for '$serviceStateKey' from peer '$peerId' did not " +
                        "include provider-authored recency."
                }
                var registeredCapacityWait = false
                try {
                    while (true) {
                        if (closed || lanes[peerId] !== lane || lane.generation !== generation) {
                            return@withLock RelayReceiveCallbackOfferResult.Closed
                        }
                        val transition = serviceStateTransitions[serviceStateKey]
                        val previous = transition?.latestAccepted
                        val processedRecency = transition?.appliedRecency
                        if (processedRecency != null &&
                            !serviceStateSupersedes(processedRecency, candidateRecency)
                        ) {
                            return@withLock RelayReceiveCallbackOfferResult.Accepted
                        }
                        if (previous != null &&
                            !serviceStateSupersedes(
                                checkNotNull(previous.serviceStateRecency),
                                candidateRecency,
                            )
                        ) {
                            return@withLock RelayReceiveCallbackOfferResult.Accepted
                        }
                        val retainedByteLimit = retainedByteLimitLocked()
                        if (entryBytes > retainedByteLimit && !losslessServiceState) {
                            return@withLock RelayReceiveCallbackOfferResult.Dropped(
                                queuedCallbacks = lane.ordinaryCallbackCount,
                                retainedBytes = lane.retainedBytes,
                                retainedByteLimitPerPeer = retainedByteLimit,
                                activePeerLanes = lanes.size,
                                reason = RelayReceiveCallbackDropReason.RETAINED_BYTES,
                            )
                        }
                        check(entryBytes <= retainedByteLimit) {
                            "A validated relay withdrawal from peer '$peerId' retained approximately " +
                                "$entryBytes bytes, exceeding the lossless callback lane limit of " +
                                "$retainedByteLimit bytes."
                        }
                        val lanePrevious = lane.serviceStateEntries[serviceStateKey]
                        val releasablePreviousBytes = lanePrevious
                            ?.takeIf {
                                it.retainedLane === lane &&
                                    it.activeExecutions == 0 &&
                                    lane.entries.contains(it)
                            }
                            ?.retainedBytes
                            ?: 0L
                        val retainedWithoutPrevious = lane.retainedBytes - releasablePreviousBytes
                        val nextKeys = lane.serviceStateEntries.size +
                            if (lanePrevious == null) 1 else 0
                        if (entryBytes <= retainedByteLimit - retainedWithoutPrevious &&
                            nextKeys <= maxServiceStateKeysPerPeer
                        ) {
                            if (previous != null) supersedeRetainedServiceStateEntry(previous)
                            if (lanePrevious != null && lanePrevious !== previous) {
                                supersedeRetainedServiceStateEntry(lanePrevious)
                            }
                            capacityChanged.signalAll()
                            break
                        }
                        if (!registeredCapacityWait) {
                            registeredCapacityWait = true
                            waitingServiceStateOfferCount += 1
                            capacityChanged.signalAll()
                        }
                        try {
                            capacityChanged.await()
                        } catch (_: InterruptedException) {
                            Thread.currentThread().interrupt()
                            return@withLock RelayReceiveCallbackOfferResult.Closed
                        }
                        lane = lanes[peerId]
                            ?: return@withLock RelayReceiveCallbackOfferResult.Closed
                    }
                } finally {
                    if (registeredCapacityWait) {
                        check(waitingServiceStateOfferCount > 0) {
                            "Relay receive capacity-wait accounting reached zero before an offer left its wait"
                        }
                        waitingServiceStateOfferCount -= 1
                        capacityChanged.signalAll()
                    }
                }
            } else {
                val retainedByteLimit = retainedByteLimitLocked()
                if (lane.ordinaryCallbackCount >= maxCallbacksPerPeer) {
                    return@withLock RelayReceiveCallbackOfferResult.Dropped(
                        queuedCallbacks = lane.ordinaryCallbackCount,
                        retainedBytes = lane.retainedBytes,
                        retainedByteLimitPerPeer = retainedByteLimit,
                        activePeerLanes = lanes.size,
                        reason = RelayReceiveCallbackDropReason.CALLBACK_COUNT,
                    )
                }
                if (entryBytes > retainedByteLimit - lane.retainedBytes) {
                    return@withLock RelayReceiveCallbackOfferResult.Dropped(
                        queuedCallbacks = lane.ordinaryCallbackCount,
                        retainedBytes = lane.retainedBytes,
                        retainedByteLimitPerPeer = retainedByteLimit,
                        activePeerLanes = lanes.size,
                        reason = RelayReceiveCallbackDropReason.RETAINED_BYTES,
                    )
                }
            }

            val transition = serviceStateKey?.let {
                serviceStateTransitions.getOrPut(it, ::ServiceStateTransition)
            }
            check(nextAcceptedSequence != Long.MAX_VALUE) {
                "Relay receive callback acceptance sequence reached Long.MAX_VALUE; the service " +
                    "must be restarted before accepting another callback."
            }
            val entry = Entry(
                beforeApplication,
                callback,
                onFailure,
                entryBytes,
                serviceStateKey,
                serviceStateRecency,
                applyServiceState,
                transition,
                nextAcceptedSequence++,
            )
            lane.entries.addLast(entry)
            if (serviceStateKey == null) {
                lane.ordinaryCallbackCount++
            } else {
                lane.serviceStateEntries[serviceStateKey] = entry
                checkNotNull(transition).latestAccepted = entry
            }
            createEntryCharge(entry, lane)
            admissionEvent = admissionTestSeam
            if (!lane.workerScheduled) {
                lane.workerScheduled = true
                laneToSchedule = lane
            }
            RelayReceiveCallbackOfferResult.Accepted
        }

        admissionEvent?.invoke(serviceStateKey?.serviceIdentifier, entryBytes)
        val scheduledLane = laneToSchedule ?: return result
        return try {
            executor.execute { drain(peerId, scheduledLane) }
            result
        } catch (_: RejectedExecutionException) {
            lock.withLock {
                if (lanes[peerId] === scheduledLane) {
                    lanes.remove(peerId)
                    retainServiceStateEntries(peerId, scheduledLane)
                    dropEntries(scheduledLane)
                    capacityChanged.signalAll()
                }
            }
            RelayReceiveCallbackOfferResult.Closed
        }
    }

    private fun drain(peerId: String, lane: Lane) {
        workerStartSeam?.invoke()
        val worker = Thread.currentThread()
        lock.withLock {
            activeWorkerThreads[worker] = null
            if (closed || lanes[peerId] !== lane) {
                activeWorkerThreads.remove(worker)
                return
            }
            lane.workerThread = worker
        }
        try {
            while (true) {
                val entry = lock.withLock {
                    if (closed || lanes[peerId] !== lane) {
                        null
                    } else {
                        // Reconnect may queue an alias of an entry that is still executing on the
                        // retired generation. Leave that alias queued so an unrelated later key
                        // can run; the last old execution schedules it below.
                        lane.entries.firstOrNull { it.activeExecutions == 0 }
                            ?.also { removed ->
                            check(lane.entries.remove(removed)) {
                                "Relay receive entry selected for execution was no longer queued"
                            }
                            removed.activeExecutions++
                            activeWorkerThreads[worker] = removed
                            if (removed.serviceStateKey == null) {
                                lane.ordinaryCallbackCount--
                                capacityChanged.signalAll()
                            }
                            if (relayReceiveLedgerInvariantTestMode) {
                                checkLedgerInvariantForTestingLocked()
                            }
                        }
                    }
                } ?: return

                try {
                    if (!prepareEntryForApplication(entry, lane.generation)) {
                        continue
                    }
                    if (entry.serviceStateTransition == null) {
                        entry.callback(lane.generation)
                    } else {
                        applyServiceStateEntry(peerId, lane, entry)
                    }
                } catch (failure: Throwable) {
                    if (failure is InterruptedException) worker.interrupt()
                    val staleGeneration = !discard(peerId, lane)
                    try {
                        entry.onFailure(lane.generation, failure, staleGeneration)
                    } catch (reportFailure: Throwable) {
                        System.err.println(
                            "Relay receive callback failure reporting also failed for peer " +
                                "'$peerId': ${reportFailure::class.java.name}: " +
                                "${reportFailure.message}"
                        )
                        reportFailure.printStackTrace(System.err)
                    }
                    return
                } finally {
                    finishEntryExecution(entry)
                }
            }
        } finally {
            val reschedule = lock.withLock {
                activeWorkerThreads.remove(worker)
                if (lane.workerThread === worker) lane.workerThread = null
                val current = !closed && lanes[peerId] === lane
                if (current) lane.workerScheduled = false
                val shouldReschedule = current &&
                    lane.entries.any { it.activeExecutions == 0 }
                if (shouldReschedule) lane.workerScheduled = true
                capacityChanged.signalAll()
                shouldReschedule
            }
            if (reschedule) {
                try {
                    executor.execute { drain(peerId, lane) }
                } catch (_: RejectedExecutionException) {
                    discard(peerId, lane)
                }
            }
        }
    }

    private fun discard(peerId: String, lane: Lane): Boolean = lock.withLock {
        if (lanes[peerId] === lane) {
            lanes.remove(peerId)
            retainServiceStateEntries(peerId, lane)
            dropEntries(lane)
            capacityChanged.signalAll()
            true
        } else {
            false
        }
    }

    private fun dropEntries(lane: Lane) {
        for (entry in lane.chargedEntries.toList()) {
            if (lane.entries.remove(entry) && entry.serviceStateKey == null) {
                lane.ordinaryCallbackCount--
            }
            entry.serviceStateKey?.let { key ->
                if (lane.serviceStateEntries[key] === entry) {
                    lane.serviceStateEntries.remove(key)
                }
            }
            entry.serviceStateTransition?.let { transition ->
                if (transition.latestAccepted === entry) transition.latestAccepted = null
            }
            if (entry.activeExecutions == 0) {
                releaseEntryCharge(entry)
            } else {
                if (relayReceiveLedgerInvariantTestMode) {
                    checkLedgerInvariantForTestingLocked()
                }
            }
        }
        check(lane.entries.isEmpty()) {
            "Relay receive lane still had queued entries after terminal drop"
        }
        check(lane.serviceStateEntries.isEmpty()) {
            "Relay receive lane still indexed service state after terminal drop"
        }
        check(lane.ordinaryCallbackCount == 0) {
            "Relay receive lane ordinary callback count was ${lane.ordinaryCallbackCount} " +
                "after terminal drop"
        }
    }

    private fun retainServiceStateEntries(peerId: String, lane: Lane) {
        if (lane.chargedEntries.none { it.serviceStateKey != null }) return
        val retiredLane = retiredServiceStateLanes.getOrPut(peerId) { newLane(lane.generation) }
        transferServiceStateEntries(lane, retiredLane)
    }

    private fun transferServiceStateEntries(source: Lane, destination: Lane) {
        for (entry in source.chargedEntries.toList()) {
            val key = entry.serviceStateKey ?: continue
            val transition = checkNotNull(entry.serviceStateTransition)
            if (entry.retainedLane !== source) continue
            if (source.serviceStateEntries[key] !== entry ||
                transition.latestAccepted !== entry
            ) {
                releaseQueuedOrMoveInFlightCharge(entry, source, destination)
                continue
            }
            val previous = destination.serviceStateEntries[key]
            if (previous != null && !serviceStateSupersedes(
                    checkNotNull(previous.serviceStateRecency),
                    checkNotNull(entry.serviceStateRecency),
                )
            ) {
                releaseQueuedOrMoveInFlightCharge(entry, source, destination)
                continue
            }
            if (previous != null) supersedeRetainedServiceStateEntry(previous)
            removeServiceStateEligibility(entry, source)
            destination.entries.addLast(entry)
            destination.serviceStateEntries[key] = entry
            moveEntryCharge(entry, destination)
        }
        val acceptedOrder = destination.serviceStateEntries.values
            .sortedBy(Entry::acceptedSequence)
        destination.entries.clear()
        destination.entries.addAll(acceptedOrder)
    }

    private fun applyServiceStateEntry(peerId: String, lane: Lane, entry: Entry): Boolean {
        val key = checkNotNull(entry.serviceStateKey)
        val recency = checkNotNull(entry.serviceStateRecency)
        val transition = checkNotNull(entry.serviceStateTransition)
        // Lock order is per-key application -> catalog -> queue; no path acquires a per-key lock
        // while holding the catalog or queue lock. A callback may call an API that briefly takes
        // the queue lock, but close releases that lock before joining workers. Per-key acquisition
        // is interruptible, so close never joins a replacement worker parked behind its callback.
        transition.applicationLock.lockInterruptibly()
        return try {
            val shouldApply = lock.withLock {
                val processedRecency = transition.appliedRecency
                !closed && lanes[peerId] === lane &&
                    transition.latestAccepted === entry &&
                    (processedRecency == null ||
                        serviceStateSupersedes(processedRecency, recency))
            }
            if (!shouldApply) {
                lock.withLock {
                    if (transition.latestAccepted !== entry ||
                        transition.appliedRecency?.let {
                            !serviceStateSupersedes(it, recency)
                        } == true
                    ) {
                        completeServiceStateEntry(key, transition, entry)
                    }
                }
                return false
            }

            val applied = checkNotNull(entry.applyServiceState).invoke(
                { entry.callback(lane.generation) },
                {
                    lock.withLock {
                        if (!closed) {
                            val appliedRecency = transition.appliedRecency
                            if (appliedRecency == null ||
                                serviceStateSupersedes(appliedRecency, recency)
                            ) {
                                transition.appliedRecency = recency
                            }
                        }
                    }
                },
            )
            if (applied) {
                lock.withLock {
                    completeServiceStateEntry(key, transition, entry)
                }
            }
            applied
        } finally {
            transition.applicationLock.unlock()
        }
    }

    private fun prepareEntryForApplication(entry: Entry, generation: Any): Boolean {
        val beforeApplication = entry.beforeApplication ?: return true
        val transition = entry.serviceStateTransition
            ?: return beforeApplication(generation)
        transition.applicationLock.lockInterruptibly()
        return try {
            if (entry.beforeApplicationCompleted) {
                true
            } else if (beforeApplication(generation)) {
                entry.beforeApplicationCompleted = true
                true
            } else {
                false
            }
        } finally {
            transition.applicationLock.unlock()
        }
    }

    /** Must be called while holding [lock]. */
    private fun completeServiceStateEntry(
        key: RelayReceiveServiceStateKey,
        transition: ServiceStateTransition,
        entry: Entry,
    ) {
        val retainedLane = entry.retainedLane
        if (retainedLane != null) {
            removeServiceStateEligibility(entry, retainedLane)
        }
        if (transition.latestAccepted === entry) transition.latestAccepted = null
        if (entry.activeExecutions == 0) {
            releaseEntryCharge(entry)
        } else {
            if (relayReceiveLedgerInvariantTestMode) {
                checkLedgerInvariantForTestingLocked()
            }
        }
        if (transition.appliedRecency == null && transition.latestAccepted == null) {
            serviceStateTransitions.remove(key, transition)
        }
        capacityChanged.signalAll()
    }

    /** Must be called while holding [lock]. */
    private fun removeServiceStateEligibility(entry: Entry, lane: Lane) {
        lane.entries.remove(entry)
        val key = checkNotNull(entry.serviceStateKey)
        if (lane.serviceStateEntries[key] === entry) lane.serviceStateEntries.remove(key)
    }

    /** Must be called while holding [lock]. */
    private fun createEntryCharge(entry: Entry, lane: Lane) {
        check(!entry.chargeCreated && !entry.chargeReleased && entry.retainedLane == null) {
            "Relay receive entry charge was created more than once"
        }
        check(lane.chargedEntries.add(entry)) {
            "Relay receive entry was already present in its accepting lane ledger"
        }
        entry.chargeCreated = true
        entry.retainedLane = lane
        lane.retainedBytes += entry.retainedBytes
        if (relayReceiveLedgerInvariantTestMode) {
            checkLedgerInvariantForTestingLocked()
        }
    }

    /** Must be called while holding [lock]. */
    private fun detachEntryChargeForMove(entry: Entry) {
        val retainedLane = checkNotNull(entry.retainedLane) {
            "Relay receive entry charge had no owner during an atomic move"
        }
        check(entry.chargeCreated && !entry.chargeReleased) {
            "Relay receive entry charge was moved outside its live lifecycle"
        }
        check(retainedLane.chargedEntries.remove(entry)) {
            "Relay receive entry charge owner did not contain the entry being moved"
        }
        retainedLane.retainedBytes -= entry.retainedBytes
        check(retainedLane.retainedBytes >= 0L) {
            "Relay receive retained-byte ledger became negative while moving a charge"
        }
        entry.retainedLane = null
    }

    /** Must be called while holding [lock]. */
    private fun releaseEntryCharge(entry: Entry) {
        check(entry.activeExecutions == 0) {
            "Relay receive entry charge was released while ${entry.activeExecutions} " +
                "worker execution(s) still retained the entry"
        }
        check(entry.chargeCreated && !entry.chargeReleased) {
            "Relay receive entry charge was released more than once or before acceptance"
        }
        val retainedLane = checkNotNull(entry.retainedLane) {
            "Relay receive entry charge had no owner at terminal release"
        }
        check(!retainedLane.entries.contains(entry)) {
            "Relay receive entry charge was released while the entry was still queued"
        }
        check(entry.serviceStateTransition?.latestAccepted !== entry) {
            "Relay receive service-state charge was released while still latest accepted"
        }
        check(retainedLane.chargedEntries.remove(entry)) {
            "Relay receive entry charge owner did not contain the entry being released"
        }
        retainedLane.retainedBytes -= entry.retainedBytes
        check(retainedLane.retainedBytes >= 0L) {
            "Relay receive retained-byte ledger became negative while releasing a charge"
        }
        entry.retainedLane = null
        entry.chargeReleased = true
        if (relayReceiveLedgerInvariantTestMode) {
            checkLedgerInvariantForTestingLocked()
        }
        capacityChanged.signalAll()
    }

    /** Must be called while holding [lock]. */
    private fun supersedeRetainedServiceStateEntry(entry: Entry) {
        val retainedLane = entry.retainedLane ?: return
        val key = checkNotNull(entry.serviceStateKey)
        if (retainedLane.serviceStateEntries[key] === entry) {
            retainedLane.serviceStateEntries.remove(key)
        }
        retainedLane.entries.remove(entry)
        entry.serviceStateTransition?.let { transition ->
            if (transition.latestAccepted === entry) transition.latestAccepted = null
        }
        if (entry.activeExecutions == 0) {
            releaseEntryCharge(entry)
        } else {
            if (relayReceiveLedgerInvariantTestMode) {
                checkLedgerInvariantForTestingLocked()
            }
        }
    }

    /** Must be called while holding [lock]. */
    private fun moveEntryCharge(entry: Entry, destination: Lane) {
        detachEntryChargeForMove(entry)
        check(destination.chargedEntries.add(entry)) {
            "Relay receive destination lane already contained the moved entry charge"
        }
        destination.retainedBytes += entry.retainedBytes
        entry.retainedLane = destination
        if (relayReceiveLedgerInvariantTestMode) {
            checkLedgerInvariantForTestingLocked()
        }
    }

    /** Must be called while holding [lock]. */
    private fun releaseQueuedOrMoveInFlightCharge(
        entry: Entry,
        source: Lane,
        destination: Lane,
    ) {
        removeServiceStateEligibility(entry, source)
        if (entry.activeExecutions == 0) {
            entry.serviceStateTransition?.let { transition ->
                if (transition.latestAccepted === entry) transition.latestAccepted = null
            }
            releaseEntryCharge(entry)
        } else {
            moveEntryCharge(entry, destination)
        }
    }

    private fun finishEntryExecution(entry: Entry) {
        var laneToSchedule: Pair<String, Lane>? = null
        lock.withLock {
            activeWorkerThreads[Thread.currentThread()] = null
            check(entry.activeExecutions > 0) {
                "Relay receive entry execution finished without a matching start"
            }
            entry.activeExecutions--
            val transition = entry.serviceStateTransition
            if (entry.activeExecutions == 0 &&
                (transition == null || transition.latestAccepted !== entry)
            ) {
                releaseEntryCharge(entry)
            } else {
                if (relayReceiveLedgerInvariantTestMode) {
                    checkLedgerInvariantForTestingLocked()
                }
            }
            if (entry.activeExecutions == 0) {
                // A reconnect alias skipped above becomes runnable at this exact lifecycle edge.
                val retainedLane = entry.retainedLane
                val peerId = retainedLane?.let { candidate ->
                    lanes.entries.firstOrNull { it.value === candidate }?.key
                }
                if (peerId != null && retainedLane.entries.contains(entry) &&
                    !retainedLane.workerScheduled
                ) {
                    retainedLane.workerScheduled = true
                    laneToSchedule = peerId to retainedLane
                }
            }
            // A queued alias becomes safely replaceable when its last execution finishes even if
            // it remains the latest accepted entry and keeps its one charge. Wake an offer that
            // may now subtract that queued charge from its same-key replacement calculation.
            capacityChanged.signalAll()
        }
        laneToSchedule?.let { (peerId, lane) ->
            try {
                executor.execute { drain(peerId, lane) }
            } catch (_: RejectedExecutionException) {
                discard(peerId, lane)
            }
        }
    }

    fun awaitWorkersExcept(exemptWorker: Thread) {
        var waitInterrupted = false
        lock.withLock {
            while (activeWorkerThreads.keys.any { it !== exemptWorker }) {
                try {
                    capacityChanged.await()
                } catch (_: InterruptedException) {
                    waitInterrupted = true
                }
            }
        }
        if (waitInterrupted) exemptWorker.interrupt()
    }

    fun processedServiceStateRecencyCount(): Int = lock.withLock {
        serviceStateTransitions.values.count { it.appliedRecency != null }
    }

    fun forgetProcessedServiceStateRecency(key: RelayReceiveServiceStateKey) {
        lock.withLock {
            val transition = serviceStateTransitions[key] ?: return
            transition.appliedRecency = null
            if (transition.latestAccepted == null) {
                serviceStateTransitions.remove(key)
            }
        }
    }

    override fun close() {
        val workers = lock.withLock {
            if (closed) return
            closed = true
            val currentWorkers = lanes.values.mapNotNull { it.workerThread }.distinct()
            lanes.values.forEach(::dropEntries)
            lanes.clear()
            retiredServiceStateLanes.values.forEach(::dropEntries)
            retiredServiceStateLanes.clear()
            serviceStateTransitions.clear()
            capacityChanged.signalAll()
            currentWorkers
        }
        workers.forEach(Thread::interrupt)
    }
}

/**
 * One bounded, serial delivery lane for ordinary gossip sent to a relay-registered peer.
 *
 * The caller only reserves bounded memory and appends to this peer's lane. A shared worker pool
 * executes one item per lane turn, so a full 200 ms transport wait for many stalled peers cannot
 * monopolize every worker or place a healthy peer behind one stalled peer's entire backlog.
 */
private class OrdinaryRelayGossipOutbox(
    private val peerId: String,
    private val controller: RelayMessageSender,
    private val executor: Executor,
    private val globallyRetainedBytes: AtomicLong,
    private val workerStartSeam: () -> Unit,
    private val latestDeliveryFailure: AtomicReference<RelayOrdinaryGossipDeliveryFailureWarningEffect?>,
    private val isCurrentRegistration: () -> Boolean
) {
    private data class Entry(val message: PreparedRelayGossipMessage, val retainedBytes: Long)

    private val lock = Any()
    private val queue = ArrayDeque<Entry>()
    private var retainedBytes = 0L
    private var workerScheduled = false

    fun offer(message: PreparedRelayGossipMessage): Boolean {
        val messageBytes = message.retainedBytes
        if (messageBytes > ORDINARY_RELAY_GOSSIP_BYTES_PER_PEER) return false

        var scheduleWorker = false
        synchronized(lock) {
            if (!isCurrentRegistration()) return false
            if (queue.size >= ORDINARY_RELAY_GOSSIP_MESSAGES_PER_PEER) return false
            if (retainedBytes + messageBytes > ORDINARY_RELAY_GOSSIP_BYTES_PER_PEER) return false
            if (!reserveGlobalBytes(messageBytes)) return false
            queue.addLast(Entry(message, messageBytes))
            retainedBytes += messageBytes
            if (!workerScheduled) {
                workerScheduled = true
                scheduleWorker = true
            }
        }

        if (scheduleWorker && !submitWorker()) {
            discardQueuedMessages()
            return false
        }
        return true
    }

    private fun reserveGlobalBytes(bytes: Long): Boolean {
        while (true) {
            val current = globallyRetainedBytes.get()
            if (current + bytes > ORDINARY_RELAY_GOSSIP_BYTES_GLOBAL) return false
            if (globallyRetainedBytes.compareAndSet(current, current + bytes)) return true
        }
    }

    private fun submitWorker(): Boolean = try {
        executor.execute(::deliverOne)
        true
    } catch (_: RejectedExecutionException) {
        false
    }

    private fun deliverOne() {
        workerStartSeam()
        val entry = synchronized(lock) {
            if (!isCurrentRegistration()) {
                null
            } else {
                queue.removeFirstOrNull()
            }
        }
        if (entry == null) {
            discardQueuedMessages()
            return
        }

        try {
            val failure = try {
                if (controller.trySendPreparedGossip(entry.message, WRITE_BACKPRESSURE_WAIT_MS)) {
                    null
                } else {
                    RelayException(relayMessageNotAdmittedMessage(WRITE_BACKPRESSURE_WAIT_MS))
                }
            } catch (failure: Exception) {
                failure
            }
            if (failure == null) {
                debugLog {
                    "[RELAY] Delivered queued ${entry.message.messageType} " +
                        "to registered peer $peerId"
                }
            } else {
                // Publish detached failure evidence before optional logging can itself fail.
                latestDeliveryFailure.set(RelayOrdinaryGossipDeliveryFailureWarningEffect(
                    peerId = boundedOrdinaryGossipDiagnosticField(peerId, 128),
                    messageId = entry.message.diagnosticMessageId,
                    messageType = boundedOrdinaryGossipDiagnosticField(entry.message.messageType, 128),
                    failureClass = boundedOrdinaryGossipDiagnosticField(failure.javaClass.name, 128),
                    failureMessage = failure.message?.let { boundedOrdinaryGossipDiagnosticField(it, 512) },
                ))
                debugLog {
                    "[RELAY] Failed queued gossip delivery to registered peer $peerId: " +
                        failure.message
                }
            }
        } finally {
            globallyRetainedBytes.addAndGet(-entry.retainedBytes)
            var reschedule = false
            var discard = false
            synchronized(lock) {
                retainedBytes -= entry.retainedBytes
                if (!isCurrentRegistration()) {
                    discard = true
                } else if (queue.isEmpty()) {
                    workerScheduled = false
                } else {
                    reschedule = true
                }
            }
            if (discard) {
                discardQueuedMessages()
            } else if (reschedule && !submitWorker()) {
                discardQueuedMessages()
            }
        }
    }

    private fun discardQueuedMessages() {
        val releasedBytes = synchronized(lock) {
            val bytes = retainedBytes
            queue.clear()
            retainedBytes = 0L
            workerScheduled = false
            bytes
        }
        if (releasedBytes != 0L) globallyRetainedBytes.addAndGet(-releasedBytes)
    }
}

/**
 * Relay response chunking keeps ten roughly 175 KiB replies in flight on one stream. Yamux's
 * initial per-stream send window is 256 KiB, so a temporarily-paused peer cannot acknowledge enough
 * bytes to drain that response window immediately. Netty's default 64 KiB child-channel high water
 * mark would make the stream unwritable after the first reply and leave the remaining awaited
 * writers parked until WINDOW_UPDATE arrives, even after the root connection itself recovered.
 *
 * A 2 MiB high water mark keeps enough byte-buffer headroom for the complete bounded ten-reply
 * window (about 1.75 MiB). Yamux may independently mark the child unwritable for protocol flow
 * control; after a real root recovery, [writeAwaitedRelayBufferWithBackpressure] admits that bounded
 * window without waiting for the peer's next WINDOW_UPDATE. Snapshot-19 Yamux reserves every child
 * write against its 10 MiB connection-wide outbound budget. Mplex has no equivalent connection-wide
 * bound, so legacy mplex streams deliberately retain the 64 KiB RPC watermark and strict gating.
 */
private val RELAY_YAMUX_WRITE_WATER_MARK: io.netty.channel.WriteBufferWaterMark =
    io.netty.channel.WriteBufferWaterMark(1 * 1024 * 1024, 2 * 1024 * 1024)

private fun configureRelayWriteBackpressure(stream: Stream) {
    configureWriteBackpressure(stream)
    if (stream.connection.muxerSession() !is YamuxHandler) return
    val channel = streamAsChannel(stream) ?: return
    try {
        channel.config().writeBufferWaterMark = RELAY_YAMUX_WRITE_WATER_MARK
    } catch (_: UnsupportedOperationException) {
        // Some channel implementations do not allow runtime watermark changes.
    } catch (_: ClassCastException) {
        // Some transport wrappers reject the writeBufferWaterMark setter.
    }
}

/**
 * Defers Yamux receive-window credit for one relay stream while its application reader is behind.
 *
 * A libp2p mux child does not honor `autoRead`: its config is not retained, its `doBeginRead()` is
 * empty, and the muxer delivers data directly into the child pipeline. Yamux's real admission
 * signal is the WINDOW_UPDATE frame it writes after consuming receive-window bytes. This handler
 * sits immediately before the negotiated [YamuxHandler] on the root connection, withholds only
 * this child's updates while paused, and sends the accumulated credit when the application drains.
 * It retains a scalar byte count rather than a frame or buffer.
 */
private class RelayYamuxReceiveWindowControl(
    private val rootChannel: Channel,
    private val yamuxHandlerName: String,
    private val streamId: MuxId,
) : ChannelOutboundHandlerAdapter(), AutoCloseable {
    private val handlerName =
        "foundation.url.protocol.relayReceiveWindow.${streamId.asLongText()}"
    private var handlerContext: ChannelHandlerContext? = null
    private var paused = false
    private var pauseGeneration = 0L
    private var deferredCreditBytes = 0L
    private var closed = false

    init {
        rootChannel.pipeline().addBefore(yamuxHandlerName, handlerName, this)
    }

    override fun handlerAdded(ctx: ChannelHandlerContext) {
        handlerContext = ctx
    }

    override fun write(ctx: ChannelHandlerContext, msg: Any, promise: ChannelPromise) {
        if (
            paused && msg is YamuxFrame && msg.id == streamId &&
            msg.type == YamuxType.WINDOW_UPDATE
        ) {
            deferredCreditBytes += msg.length
            debugLog {
                "[RELAY-FLOW] Deferred ${msg.length} receive-window bytes for " +
                    "stream ${streamId.asLongText()}; total=$deferredCreditBytes"
            }
            ReferenceCountUtil.release(msg)
            promise.trySuccess()
            return
        }
        ctx.write(msg, promise)
    }

    /** Called synchronously from child delivery, which Yamux runs on the root event loop. */
    fun pause(): Long? {
        if (closed || !rootChannel.isOpen || !rootChannel.eventLoop().inEventLoop()) return null
        pauseGeneration += 1L
        paused = true
        debugLog { "[RELAY-FLOW] Paused receive-window credit for stream ${streamId.asLongText()}" }
        return pauseGeneration
    }

    fun resume(expectedPauseGeneration: Long? = null) {
        runOnRootEventLoop {
            if (
                closed || !paused ||
                (expectedPauseGeneration != null && pauseGeneration != expectedPauseGeneration)
            ) return@runOnRootEventLoop
            paused = false
            val credit = deferredCreditBytes
            deferredCreditBytes = 0L
            debugLog {
                "[RELAY-FLOW] Resumed receive-window credit for stream ${streamId.asLongText()}; " +
                    "granting $credit deferred bytes"
            }
            val ctx = handlerContext
            if (credit > 0L && ctx != null && rootChannel.isOpen) {
                // Start at this handler's context so the aggregate update continues toward the
                // transport without being intercepted by this handler a second time.
                ctx.writeAndFlush(
                    YamuxFrame(streamId, YamuxType.WINDOW_UPDATE, YamuxFlag.NONE, credit, null)
                )
            }
        }
    }

    override fun close() {
        runOnRootEventLoop {
            if (closed) return@runOnRootEventLoop
            closed = true
            paused = false
            deferredCreditBytes = 0L
            val pipeline = rootChannel.pipeline()
            if (pipeline.context(this) != null) pipeline.remove(this)
        }
    }

    private fun runOnRootEventLoop(action: () -> Unit) {
        if (rootChannel.eventLoop().inEventLoop()) {
            action()
        } else {
            try {
                rootChannel.eventLoop().execute(action)
            } catch (_: RejectedExecutionException) {
                // The root connection is already shutting down, so no receive credit remains to
                // grant and Netty will remove the handler with the pipeline.
            }
        }
    }
}

private fun installRelayYamuxReceiveWindowControl(
    stream: Stream,
): RelayYamuxReceiveWindowControl? {
    val yamuxHandler = stream.connection.muxerSession() as? YamuxHandler ?: return null
    val childChannel = streamAsChannel(stream) as? MuxChannel<*> ?: return null
    val rootChannel = libp2pRootConnectionChannel(childChannel)
    val yamuxContext = rootChannel.pipeline().context(yamuxHandler) ?: return null
    return RelayYamuxReceiveWindowControl(rootChannel, yamuxContext.name(), childChannel.id)
}

/**
 * Lightweight write-only wrapper for server-side relay streams.
 * Used with NIO pipeline handlers where reads are handled by Netty,
 * and this class only provides the ability to write messages back.
 *
 * See [RelayMessageSender] for the close-flush contract.
 */
class StreamRelayMessageSender(private val stream: Stream) : RelayMessageSender {
    internal val diagnosticStream: Stream get() = stream
    private val closed = AtomicBoolean(false)

    init {
        configureRelayWriteBackpressure(stream)
    }

    override fun isClosed(): Boolean = closed.get()

    override fun sendMessage(json: JSONObject) {
        if (closed.get()) throw RelayException("Stream closed")
        if (!sendMessage(json, WRITE_BACKPRESSURE_WAIT_MS)) {
            throw RelayException(relayMessageNotAdmittedMessage(WRITE_BACKPRESSURE_WAIT_MS))
        }
    }

    /**
     * Attempts to admit [json] to this stream's transport, waiting at most
     * [maxAdmissionWaitMs] for backpressure to clear.
     *
     * Returns `true` once the complete frame has been handed to Netty, or `false` if the stream is
     * closed or remains unwritable for the entire bounded budget. A `true` result is transport
     * admission, not a remote acknowledgement; callers that close immediately afterward can use
     * [close] as the ordered flush barrier. The wait must be non-negative and is never unbounded.
     *
     * @throws org.json.JSONException if [json] cannot be serialized. Serialization previously went
     *   through `JSONObject.toString()`, which returns `null` on failure and surfaced here as a
     *   `NullPointerException` naming nothing.
     */
    fun sendMessage(json: JSONObject, maxAdmissionWaitMs: Long): Boolean {
        requireValidRelayAdmissionWait(maxAdmissionWaitMs)
        if (closed.get()) return false
        val bytes = jsonWireBytes(json)
        val buf = Unpooled.buffer(4 + bytes.size)
        buf.writeInt(bytes.size)
        buf.writeBytes(bytes)
        return sendFramedMessage(buf, maxAdmissionWaitMs)
    }

    /**
     * Admits one already-framed immutable message. This is internal so relay fanout can reuse one
     * encoded payload while every recipient still owns an independent ByteBuf view.
     */
    internal fun sendFramedMessage(buf: ByteBuf, maxAdmissionWaitMs: Long): Boolean {
        requireValidRelayAdmissionWait(maxAdmissionWaitMs)
        if (closed.get()) {
            buf.release()
            return false
        }
        // Gate on channel writability so a stalled relay peer cannot OOM us
        // by accumulating WriteTasks on the event loop. See OOM root cause from
        // production outage 2026-04-27 (writeFramedBufferWithBackpressure docs).
        // Default 200ms bounded admission budget for gossip / distance-vector traffic. This
        // Boolean overload reports non-admission as false; the binary-compatible one-argument
        // overload converts false to RelayException. AWAITED replies/forwards (whose loss hangs a
        // requesting client for its full invocation timeout) use [sendMessageAwaitingDelivery].
        return writeRelayBufferWithBackpressure(stream, buf, maxAdmissionWaitMs)
    }

    /**
     * Sends [json] as an AWAITED reply/forward — the write direction whose silent loss hangs a
     * requesting client for its full invocation timeout (the prod "uploadFile ... timed out after
     * 30000ms": the relay forwarded a reply back to a NAT'd client, the write was dropped on a
     * momentarily-unwritable connection, and the historical [sendMessage] implementation swallowed
     * the drop so the client blocked its whole 30s readMessage).
     *
     * Unlike the default [sendMessage] (a 200ms admission budget), this rides out a transient
     * backpressure stall for up to [WRITE_BACKPRESSURE_DELIVERY_WAIT_MS] and throws
     * [RelayException] if the write is still not admitted. This operation remains for awaited
     * request/forward traffic; computed replies use [sendResponseWithOutbox] so an undeliverable
     * reply cannot tear down a shared logical stream.
     *
     * Memory stays bounded exactly as the best-effort path intended:
     * [writeFramedBufferWithBackpressure] only `writeAndFlush`es while writable (so the event loop's
     * WriteTask queue never grows unbounded — the OOM root cause) and parks at most
     * [maxConcurrentParkedWritesPerConnection] writes per connection.
     */
    internal fun sendMessageAwaitingDelivery(json: JSONObject) {
        if (closed.get()) throw RelayException("Stream closed")
        // Yamux finalizes child-channel config during activation, after this sender is constructed.
        // Reapply the idempotent relay watermark at the active write boundary so activation cannot
        // restore Netty's 64 KiB default underneath the awaited-delivery contract.
        configureRelayWriteBackpressure(stream)
        val bytes = jsonWireBytes(json)
        val buf = Unpooled.buffer(4 + bytes.size)
        buf.writeInt(bytes.size)
        buf.writeBytes(bytes)
        val delivered = writeAwaitedRelayBufferWithBackpressure(
            stream,
            buf,
            WRITE_BACKPRESSURE_DELIVERY_WAIT_MS
        )
        if (!delivered) {
            throw RelayException(
                "Relay awaited reply/forward write dropped: connection to peer unwritable after " +
                    "${WRITE_BACKPRESSURE_DELIVERY_WAIT_MS}ms delivery wait (park budget exhausted or connection wedged)"
            )
        }
    }

    internal fun sendResponseWithOutbox(
        json: JSONObject,
        failureReservation: AwaitedResponseFailureReservation?,
        completion: ((Throwable?) -> Unit)? = null,
    ): AwaitedResponseWriteOutcome {
        if (closed.get()) {
            failureReservation?.close()
            return AwaitedResponseWriteOutcome.CONNECTION_CLOSED
        }
        configureRelayWriteBackpressure(stream)
        return writeAwaitedResponseWithOutbox(
            stream,
            framedRelayJsonBuffer(json),
            failureReservation,
            completion,
        )
    }

    internal suspend fun reserveResponseFailure(
        outboxFullSignal: JSONObject,
    ): AwaitedResponseFailureReservation? {
        if (closed.get()) return null
        configureRelayWriteBackpressure(stream)
        return reserveAwaitedResponseFailureSignal(stream) {
            framedRelayJsonBuffer(outboxFullSignal)
        }
    }

    override fun close(flushTimeoutMs: Long): Boolean {
        if (closed.getAndSet(true)) return true
        markRelaySenderClose(stream)
        // libp2p's [Stream.writeAndFlush] returns void — the underlying ChannelFuture is
        // not exposed — so we use [Stream.closeWrite] as the per-stream flush barrier
        // instead. closeWrite returns a CompletableFuture that completes once every
        // queued write on this stream has actually drained onto the wire and the write
        // side is half-closed. Netty preserves write ordering on a single channel, so
        // awaiting closeWrite is sufficient to guarantee every prior sendMessage call
        // has been delivered. After the half-close drains, [stream.close] tears down
        // the read side.
        val flushed = try {
            stream.closeWrite().get(flushTimeoutMs, TimeUnit.MILLISECONDS)
            true
        } catch (_: TimeoutException) {
            false
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            false
        } catch (_: Exception) {
            // closeWrite may already have been called or the stream may already be torn
            // down — treat as "nothing left to flush" rather than a hard failure.
            false
        }
        try {
            stream.close()
        } catch (_: Exception) {
            // Ignore
        }
        return flushed
    }
}

/**
 * Current state of a bounded relay candidate registration.
 */
enum class RelayCandidateRegistrationStatus {
    PREPARING,
    ACKNOWLEDGED,
    COMMITTED,
    CANCELED,
    FAILED
}

internal class RelayCandidateRegistrationState(
    val services: List<String>,
    val desiredCatalogIntentRevisionAtPreparation: Long,
    val handler: (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse
) {
    val status = AtomicReference(RelayCandidateRegistrationStatus.PREPARING)
    val connection = AtomicReference<RelayConnection?>(null)
    val preparationTask = AtomicReference<Future<*>?>(null)
    val timeoutTask = AtomicReference<Scheduled?>(null)
    /**
     * The most recent parse-memory admission the preparation read missed, cleared once a frame is
     * delivered. Either timeout path reports it as the cause, so a budget spent waiting for parse
     * memory is distinguishable from a relay that never answered.
     */
    val lastAdmissionMiss = AtomicReference<RelayParseBudgetDeadlineException?>(null)
    val acknowledgedLifetimeTask = AtomicReference<Scheduled?>(null)
    val workerStarted = AtomicBoolean(false)
    val workerSettled = CompletableFuture<Unit>()
    val cleanupStarted = AtomicBoolean(false)
    val cleanup = CompletableFuture<Unit>()
    val slotAcquired = AtomicBoolean(false)
    val slotReleased = AtomicBoolean(false)
}

private class RelayRegistrationCoordination {
    val lock = ReentrantLock()
    var users: Int = 0
}

/**
 * Serializes registration generations only when they target the same relay.
 *
 * A preparation's empty registration is authoritative at the relay, so its send and
 * acknowledgement must finish before a same-relay commit can publish a selected catalog.
 * Different relays keep separate gates and can still prepare concurrently.
 */
private class RelayRegistrationCoordinator {
    private val monitor = Any()
    private val coordinationByRelayPeerId = mutableMapOf<String, RelayRegistrationCoordination>()

    fun <T> withRelay(relayPeerId: String, block: () -> T): T {
        val coordination = synchronized(monitor) {
            coordinationByRelayPeerId.getOrPut(relayPeerId) {
                RelayRegistrationCoordination()
            }.also {
                it.users++
            }
        }
        try {
            return coordination.lock.withLock(block)
        } finally {
            synchronized(monitor) {
                coordination.users--
                if (coordination.users == 0) {
                    coordinationByRelayPeerId.remove(relayPeerId, coordination)
                }
            }
        }
    }
}

private data class SameRelayFailureState(
    val generation: Long,
    val failures: Int
)

private fun AtomicReference<SameRelayFailureState>.resetSameRelayFailures() {
    updateAndGet { current ->
        SameRelayFailureState(
            generation = current.generation + 1L,
            failures = 0
        )
    }
}

private fun AtomicReference<SameRelayFailureState>.recordSameRelayFailure(
    expectedGeneration: Long
): SameRelayFailureState? {
    while (true) {
        val current = get()
        if (current.generation != expectedGeneration) return null
        val updated = current.copy(failures = current.failures + 1)
        if (compareAndSet(current, updated)) return updated
    }
}

/**
 * An acknowledged relay registration that has not necessarily been selected.
 *
 * [acknowledgement] completes with this handle after the relay accepts the registration. It
 * completes exceptionally when preparation fails, exceeds its budget, or is canceled. After
 * acknowledgement, the same [budgetMs] bounds how long the uncommitted handle remains live.
 * A caller that does not commit this handle should pass it promptly to
 * [RelayService.cancelRelayCandidateRegistration].
 */
class RelayCandidateRegistration internal constructor(
    internal val ownerToken: Any,
    internal val state: RelayCandidateRegistrationState,
    val relayPeerId: String,
    val budgetMs: Long
) {
    val acknowledgement = CompletableFuture<RelayCandidateRegistration>()

    val status: RelayCandidateRegistrationStatus
        get() = state.status.get()
}

/**
 * Service that handles peer-to-peer relay functionality.
 *
 * This service enables NAT traversal by allowing publicly-reachable peers to relay
 * requests for NAT-ed peers. It can operate in two modes:
 *
 * 1. **Relay Mode** (for public peers): Accepts registrations from NAT-ed peers
 *    and forwards requests to them.
 *
 * 2. **Client Mode** (for NAT-ed peers): Registers with a relay and receives
 *    forwarded requests through the relay connection.
 *
 * The service [clock] governs application timers, including candidate preparation, reconnect
 * checks and chunk lifetimes. Registered-listener idle, frame and parse-admission waits use a
 * separate [listenerReadClock], defaulting to [SystemClock]. Advancing the application clock
 * therefore does not expire an otherwise healthy listener's network read.
 *
 * ## Usage as Relay
 * ```kotlin
 * val service = RelayService(host, peerRegistry, RelayConfig(enableRelay = true))
 * service.start()
 * // Service will announce itself via gossip and accept registrations
 * ```
 *
 * ## Usage as Client
 * ```kotlin
 * val service = RelayService(host, peerRegistry, RelayConfig(enableRelay = false))
 * service.start()
 * service.registerWithRelay(relayPeerId) { request ->
 *     // Handle incoming relayed requests
 *     handleRequest(request)
 * }
 * ```
 */
class RelayService(
    private val host: Host,
    private val peerRegistry: PeerRegistry,
    private val config: RelayConfig = RelayConfig(),
    gossipHandler: GossipHandler? = null,
    private val clock: Clock = SystemClock(),
) : AutoCloseable {

    private var listenerReadClock: Clock = SystemClock()

    /**
     * Creates a relay with a separately owned clock for registered-listener network reads.
     *
     * [clock] still governs application timers and the complete candidate-preparation operation,
     * including that operation's bounded reads. [listenerReadClock] governs only registered-listener
     * idle, frame and parse-admission waits; the caller retains ownership of both clocks.
     * The existing constructors keep their signatures and use [SystemClock] for listener reads.
     */
    constructor(
        host: Host,
        peerRegistry: PeerRegistry,
        config: RelayConfig = RelayConfig(),
        gossipHandler: GossipHandler? = null,
        clock: Clock = SystemClock(),
        listenerReadClock: Clock,
    ) : this(host, peerRegistry, config, gossipHandler, clock) {
        this.listenerReadClock = listenerReadClock
    }

    private var relayRequestFileSystem: FileSystem = FileSystem.SYSTEM
    private var relayRequestTemporaryDirectory: Path = FileSystem.SYSTEM_TEMPORARY_DIRECTORY
    /**
     * Creates a relay with an explicit filesystem boundary for incoming chunked requests.
     *
     * The filesystem and directory remain required on this overload. The five-parameter primary
     * constructor remains byte-for-byte compatible with callers compiled before storage injection
     * was added.
     */
    constructor(
        host: Host,
        peerRegistry: PeerRegistry,
        config: RelayConfig,
        gossipHandler: GossipHandler? = null,
        clock: Clock = SystemClock(),
        relayRequestFileSystem: FileSystem,
        relayRequestTemporaryDirectory: Path,
    ) : this(host, peerRegistry, config, gossipHandler, clock) {
        this.relayRequestFileSystem = relayRequestFileSystem
        this.relayRequestTemporaryDirectory = relayRequestTemporaryDirectory
    }

    /**
     * Handler for gossip protocol events (peer discovery notifications).
     * Can be set after construction but before start().
     */
    private var gossipHandler: GossipHandler? = gossipHandler

    /**
     * Sets the gossip handler for receiving peer discovery notifications.
     * Must be called before start() for the handler to receive initial peer broadcasts.
     */
    fun setGossipHandler(handler: GossipHandler) {
        this.gossipHandler = handler
    }

    /**
     * Sets a callback to find alternative relays when the current relay fails.
     * This is called after [maxSameRelayAttempts] consecutive failures to the same relay.
     * The callback should return a PeerInfo for an alternative relay, or null if none available.
     */
    fun setAlternativeRelaySelector(selector: () -> PeerInfo?) {
        this.alternativeRelaySelector = selector
    }

    /**
     * Sets a request handler for this peer. Used when this peer provides a service
     * and may receive relay requests targeting itself (self-target scenario).
     *
     * This is different from the handler passed to registerWithRelay() - that handler
     * is for when we receive requests VIA a relay. This handler is for when we ARE
     * the relay and receive a request targeting ourselves.
     */
    fun setRequestHandler(handler: (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse) {
        this.requestHandler = wrapWithChunking(handler)
    }

    // ---- Chunked request/response transfer (large relay payloads) -----------
    // Large payloads are split into [relayChunkBytes] frames sharing a transferId so
    // no single relay frame is large enough to stall the write path (the
    // WriteBufferWaterMark + 200ms backpressure-drop in writeFramedBufferWithBackpressure)
    // or force the relay to buffer a whole multi-MB message. This is symmetric:
    //  - Requests: the requester (sendViaRelay) splits; the receiver reassembles in
    //    [reassembleAndHandle] before invoking the real handler.
    //  - Responses: the receiver buffers a large handler result here and serves it in
    //    chunks as the requester fetches them (see [maybeChunkResponse]/[serveResponseChunk]
    //    and the response-reassembly in sendViaRelay).
    // Keeping each forwarded frame small preserves the constrained-heap behaviour guarded
    // by stressTestRelayProcessSurvivesOomFloodWithConstrainedHeap.
    private val relayChunkBytes = RELAY_REQUEST_CHUNK_BYTES     // 128 KiB raw per chunk (~180 KB base64 frame)
    private val relayRequestChunkBytes = relayChunkBytes
    // Open with two request chunks in flight on a sendViaRelay request stream, then widen the
    // window as acknowledgements arrive. Waiting for every acknowledgement before sending the next
    // chunk makes an N-chunk upload cost N complete application-level round trips. Two overlaps each
    // acknowledgement wait with the following request while keeping one transfer well below the
    // connection-wide 16 parked-write transport budget. Concurrent substreams remain governed by
    // that existing connection-wide budget.
    private val relayRequestChunkWindow = 2
    // How many response-chunk fetches sendViaRelay keeps in flight at once (sliding window). Each reply
    // is a ~180 KB frame; a relay (and the target one hop further) can only hold
    // [maxConcurrentParkedWritesPerConnection] (16) such writes parked on one connection before the
    // overflow is dropped and the source stream torn down (the "got X/N" truncation this bound
    // prevents). Issuing all N-1 fetches up front floods each hop with N concurrent large reply writes.
    // Kept comfortably BELOW the 16-write budget rather than at it: the budget is per root CONNECTION and
    // shared across all of that connection's mux substreams (see maxConcurrentParkedWritesPerConnection /
    // parkedWriteBudgetFor), and connectToRelay reuses one connection to a relay, so a transfer's chunk
    // replies can share the budget with keepalive/gossip writes on the same connection — the headroom
    // absorbs that concurrent traffic. Still deep enough to pipeline: an N-chunk response costs
    // ~ceil(N/window) relay round-trips instead of N sequential ones.
    private val relayResponseChunkFetchWindow = 10
    // The REQUEST direction needs the same bounded pipeline for the same reason. A large upload is
    // split into ~180 KB chunk frames that the relay absorbs into its file-backed assembly and
    // answers with a tiny interim acknowledgement. Sending chunk N and BLOCKING on its
    // acknowledgement before writing chunk N+1 makes an N-chunk upload cost N SEQUENTIAL relay
    // round-trips, so every scheduling delay on either side is multiplied by the chunk count
    // (64 for an 8 MiB payload). Keeping a bounded window of chunk frames in flight costs
    // ~ceil(N/window) round-trips instead, exactly as the response direction already does.
    //
    // The request window is bounded in BYTES, not in frames, and this is the difference that
    // matters: the response direction's ten in-flight items are ~500-byte chunk-FETCH requests,
    // whereas ten in-flight request chunks are ~1.8 MB of this sender's own writes. Netty marks the
    // relay stream unwritable once queued writes pass RELAY_YAMUX_WRITE_WATER_MARK's 2 MiB high mark
    // and only writable again below its 1 MiB low mark, while sendCommittedRequest admits each frame
    // on a bounded best-effort budget. A frame-counted window therefore let one transfer queue enough
    // of its own bytes to push its channel past the watermark, and the next frame then failed
    // admission outright — reported as RelayRequestNotDispatchedException, a dispatch failure rather
    // than backpressure. Bounding in-flight bytes at the LOW-water mark keeps a transfer from ever
    // making its own channel unwritable, and keeps aggregate ingress at a busy relay proportionally
    // lower too.
    private val relayRequestChunkSendWindowBytes = 1024 * 1024
    private val relayRequestChunkSendWindow = maxOf(
        1,
        relayRequestChunkSendWindowBytes / MAX_RELAY_REQUEST_CHUNK_ENCODED_CHARACTERS
    )
    // sendViaRelay calls on separate mux substreams share one root relay connection, and the
    // transport's 16 parked-write permits are connection-wide. Bound the sum of chunk fetches across
    // every transfer on that connection, rather than allowing each transfer its own window of ten.
    // Ten preserves the existing single-transfer pipeline while retaining six transport permits for
    // keepalive/gossip traffic during a transient stall.
    private val relayResponseChunkFetchConnectionBudget = 10
    private val fallbackResponseChunkFetchBudget = RelayResponseChunkFetchBudget(relayResponseChunkFetchConnectionBudget)
    private val responseChunkFetchBudgetAttribute =
        io.netty.util.AttributeKey.valueOf<RelayResponseChunkFetchBudget>("foundation.url.protocol.responseChunkFetchBudget")
    // The request direction gets its OWN connection-wide budget, and a smaller one, for the same
    // reason its per-transfer window is smaller: the two directions put very different numbers of
    // bytes on the wire per in-flight item. Ten in-flight response-chunk FETCHES are ~5 KB of tiny
    // requests; ten in-flight request CHUNKS are ~1.8 MB. Counting them against one shared budget
    // treats those as equivalent, and four concurrent uploads sharing one relay connection then put
    // enough bytes in flight to push that connection past its write watermark, at which point the
    // next frame fails admission outright and is reported as never dispatched.
    //
    // Sizing each direction by its own byte footprint keeps BOTH transport bounds satisfied at once:
    // five large frames (874 KB) plus ten tiny ones stays under the 1 MiB low-water mark, and 5 + 10
    // in-flight writes stays within the 16 connection-wide parked-write permits.
    private val relayRequestChunkSendConnectionBudget = relayRequestChunkSendWindow
    private val fallbackRequestChunkSendBudget = Semaphore(relayRequestChunkSendConnectionBudget, true)
    private val requestChunkSendBudgetAttribute =
        io.netty.util.AttributeKey.valueOf<Semaphore>("foundation.url.protocol.requestChunkSendBudget")
    private val chunkAssemblyTtlMs = config.chunkAssemblyTtlMs
    private val outgoingChunkedResponseIdleTtlMs = config.outgoingChunkedResponseIdleTtlMs
    private val responseChunkFetchHeader = "__relay_response_chunk_fetch__"   // header: transferId to fetch
    private val responseChunkSeqHeader = "__relay_response_chunk_seq__"       // header: chunk index to fetch
    // Capability negotiation: a requester whose sendViaRelay understands chunked responses advertises
    // this header. The target only chunks a large response when the requester advertised support;
    // otherwise it returns the whole response (old behavior), so a new target never silently truncates
    // an OLD requester that wouldn't reassemble. New-requester↔old-target degrades too: the old target
    // ignores the header and returns an unchunked response, which the new sendViaRelay handles as
    // totalChunks=1.
    private val responseChunkSupportHeader = "__relay_supports_response_chunking__"
    private class ChunkAssemblyExpirySchedule(val expiresAtMs: Long) {
        var scheduled: Scheduled? = null
    }
    private class ChunkAssembly(
        val storage: FileBackedRelayChunkAssembly,
        var lastReceivedAtMs: Long,
    ) {
        val totalChunks: Int get() = storage.totalChunks
        var expirySchedule: ChunkAssemblyExpirySchedule? = null
        // Guarded by raceLifecycleLock; this assignment is the delivery/close linearization point.
        var handlerDeliveryClaimed = false
    }
    private val chunkAssemblyLock = Any()
    private class ChunkTransferGate {
        val lock = ReentrantLock(true)
        var references = 0
    }
    private val chunkTransferGates = HashMap<String, ChunkTransferGate>()
    // Keyed by SOURCE PEER + transfer id, never by transfer id alone. A transfer id identifies a
    // transfer only within the process that minted it (RelayProtocol.nextMessageId is a per-process
    // counter), so two independent uploaders routinely present the same one. Keying on the transfer
    // id alone merges their chunks into a single assembly, which completes early with a mixture of
    // both payloads and leaves the other uploader's remaining chunks orphaned.
    private val chunkedTransfers = ConcurrentHashMap<String, ChunkAssembly>()
    // A completed transfer remains keyed until its file has been materialized and closed. Keeping
    // this ownership by source peer + transfer id prevents a late duplicate chunk from creating a
    // second assembly after the incomplete map entry has been removed.
    private val completingChunkAssemblies = HashMap<String, ChunkAssembly>()
    // Large handler responses awaiting chunk-by-chunk pickup, keyed by transferId.
    private class OutgoingChunkedResponse(
        var raw: ByteArray,
        val totalChunks: Int,
        var lastProgressAtMs: Long,
        val errorMessage: String?,
        val opaqueFraming: Boolean,
    ) {
        val servedChunks = HashSet<Int>().apply { add(0) }
        var expirySchedule: OutgoingChunkedResponseExpirySchedule? = null
    }
    private class OutgoingChunkedResponseExpirySchedule(val expiresAtMs: Long) {
        var scheduled: Scheduled? = null
    }
    private val outgoingChunkedResponses = ConcurrentHashMap<String, OutgoingChunkedResponse>()
    private val outgoingChunkedResponsesLock = Any()

    /** The connection-wide budget of concurrently in-flight response-chunk fetches. */
    private fun responseChunkFetchBudgetFor(connection: RelayConnection): RelayResponseChunkFetchBudget {
        val rootChannel = connection.controller.rootConnectionChannel()
            ?: return fallbackResponseChunkFetchBudget
        val attribute = rootChannel.attr(responseChunkFetchBudgetAttribute)
        attribute.get()?.let { return it }
        val created = RelayResponseChunkFetchBudget(relayResponseChunkFetchConnectionBudget)
        return attribute.setIfAbsent(created) ?: created
    }

    /**
     * The connection-wide budget of concurrently in-flight request-chunk sends. Separate from, and
     * smaller than, the response-fetch budget because a request chunk is a ~175 KB frame while a
     * response-chunk fetch is a few hundred bytes.
     */
    private fun requestChunkSendBudgetFor(connection: RelayConnection): Semaphore {
        val rootChannel = connection.controller.rootConnectionChannel()
            ?: return fallbackRequestChunkSendBudget
        val attribute = rootChannel.attr(requestChunkSendBudgetAttribute)
        attribute.get()?.let { return it }
        val created = Semaphore(relayRequestChunkSendConnectionBudget, true)
        return attribute.setIfAbsent(created) ?: created
    }

    private fun wrapWithChunking(
        handler: (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse
    ): (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse = { request ->
        val fetchTransferId = request.headers[responseChunkFetchHeader]
        if (!fetchTransferId.isNullOrEmpty()) {
            serveResponseChunk(request, fetchTransferId)
        } else {
            maybeChunkResponse(request, reassembleAndHandle(handler, request))
        }
    }

    private fun handleClosedRelayRequest(
        request: RelayProtocol.RelayRequest,
    ): RelayProtocol.RelayResponse {
        val fetchTransferId = request.headers[responseChunkFetchHeader]
        return if (!fetchTransferId.isNullOrEmpty()) {
            serveResponseChunk(request, fetchTransferId)
        } else {
            relayServiceClosedResponse(request)
        }
    }

    private fun relayServiceClosedResponse(request: RelayProtocol.RelayRequest): RelayProtocol.RelayResponse =
        RelayProtocol.RelayResponse.error(
            requestId = request.requestId,
            sourcePeerId = request.targetPeerId,
            targetPeerId = request.sourcePeerId,
            errorMessage = "RelayService closed"
        )

    private fun chunkAssemblyExpiryDeadline(lastReceivedAtMs: Long): Long {
        return if (lastReceivedAtMs > Long.MAX_VALUE - chunkAssemblyTtlMs) {
            Long.MAX_VALUE
        } else {
            lastReceivedAtMs + chunkAssemblyTtlMs
        }
    }

    private fun chunkAssemblyHasExpired(lastReceivedAtMs: Long, now: Long): Boolean {
        val deadline = chunkAssemblyExpiryDeadline(lastReceivedAtMs)
        return deadline != Long.MAX_VALUE && now > deadline
    }

    private fun outgoingChunkedResponseExpiryDeadline(lastProgressAtMs: Long): Long {
        return if (lastProgressAtMs > Long.MAX_VALUE - outgoingChunkedResponseIdleTtlMs) {
            Long.MAX_VALUE
        } else {
            lastProgressAtMs + outgoingChunkedResponseIdleTtlMs
        }
    }

    private fun outgoingChunkedResponseHasExpired(lastProgressAtMs: Long, now: Long): Boolean {
        val deadline = outgoingChunkedResponseExpiryDeadline(lastProgressAtMs)
        return deadline != Long.MAX_VALUE && now > deadline
    }

    private fun <T> withChunkTransferGate(
        assemblyKey: String,
        action: () -> T,
    ): T {
        val gate = synchronized(chunkAssemblyLock) {
            chunkTransferGates.getOrPut(assemblyKey, ::ChunkTransferGate).also {
                it.references += 1
            }
        }
        try {
            gate.lock.lockInterruptibly()
        } catch (interrupted: InterruptedException) {
            synchronized(chunkAssemblyLock) {
                gate.references -= 1
                removeChunkTransferGateIfUnusedLocked(assemblyKey, gate)
            }
            Thread.currentThread().interrupt()
            throw RelayException(
                "Interrupted while waiting to process chunked relay transfer '$assemblyKey'",
                interrupted,
            )
        }
        try {
            return action()
        } finally {
            gate.lock.unlock()
            synchronized(chunkAssemblyLock) {
                gate.references -= 1
                removeChunkTransferGateIfUnusedLocked(assemblyKey, gate)
            }
        }
    }

    /** Caller must hold this assembly's transfer gate. */
    private fun removeChunkTransferGateIfUnusedLocked(
        assemblyKey: String,
        gate: ChunkTransferGate,
    ) {
        check(gate.references >= 0) {
            "Chunked relay transfer gate '$assemblyKey' has a negative reference count"
        }
        if (gate.references == 0 &&
            !chunkedTransfers.containsKey(assemblyKey) &&
            !completingChunkAssemblies.containsKey(assemblyKey)
        ) {
            chunkTransferGates.remove(assemblyKey, gate)
        }
    }

    /** Caller must hold this assembly's transfer gate. */
    private fun cancelChunkAssemblyExpiry(assembly: ChunkAssembly) {
        val scheduled = assembly.expirySchedule?.scheduled
        assembly.expirySchedule = null
        scheduled?.cancel()
    }

    /** Caller must hold this assembly's transfer gate. */
    private fun removeAndCloseChunkAssembly(
        assemblyKey: String,
        assembly: ChunkAssembly,
        primaryFailure: Throwable? = null,
    ): Throwable? {
        synchronized(chunkAssemblyLock) {
            chunkedTransfers.remove(assemblyKey, assembly)
            completingChunkAssemblies.remove(assemblyKey, assembly)
        }
        var failure = primaryFailure
        try {
            cancelChunkAssemblyExpiry(assembly)
        } catch (cleanupFailure: Throwable) {
            failure = appendRelayRequestCleanupFailure(failure, cleanupFailure)
        }
        return closeRelayChunkAssembly(assembly.storage, failure)
    }

    /** Caller must hold [chunkAssemblyLock]. */
    private fun rejectCompletingChunkTransferLocked(
        request: RelayProtocol.RelayRequest,
        assemblyKey: String,
    ) {
        if (completingChunkAssemblies.containsKey(assemblyKey)) {
            throw RelayException(
                "Rejected chunked relay request from peer '${request.sourcePeerId}' for transfer " +
                    "'${request.transferId}': this transfer already received every chunk and is " +
                    "being delivered to its handler"
            )
        }
    }

    private fun createChunkAssembly(
        request: RelayProtocol.RelayRequest,
        receivedAtMs: Long,
    ): ChunkAssembly {
        val reservedByteCount =
            request.totalChunks.toLong() * RELAY_REQUEST_CHUNK_BYTES.toLong()
        val storageLease = RelayRequestTemporaryStorageLedger.reserve(
            request.sourcePeerId,
            request.transferId,
            reservedByteCount,
        )
        // A permanently retained cleanup owner must not keep the entire RelayService reachable.
        // Capture only its bounded warning cell in the process-wide cleanup registry callback.
        val cleanupWarningSnapshot = latestRelayRequestTemporaryStorageCleanupFailure
        val storage = FileBackedRelayChunkAssembly.create(
            relayRequestFileSystem,
            relayRequestTemporaryDirectory,
            request.totalChunks,
            storageLease,
        ) { warning ->
            cleanupWarningSnapshot.set(warning)
        }
        return try {
            ChunkAssembly(storage, receivedAtMs)
        } catch (failure: Throwable) {
            throw closeRelayChunkAssembly(storage, failure) ?: failure
        }
    }

    /** Caller must hold this assembly's transfer gate. */
    private fun scheduleChunkAssemblyExpiry(
        assemblyKey: String,
        assembly: ChunkAssembly
    ) {
        cancelChunkAssemblyExpiry(assembly)
        val expiresAtMs = chunkAssemblyExpiryDeadline(assembly.lastReceivedAtMs)
        if (closed.get() || expiresAtMs == Long.MAX_VALUE) return

        val schedule = ChunkAssemblyExpirySchedule(expiresAtMs)
        assembly.expirySchedule = schedule
        val scheduled = clock.schedule(expiresAtMs + 1L) {
            expireChunkAssembly(assemblyKey, assembly, schedule)
        }
        schedule.scheduled = scheduled
        // A ManualClock can advance after the assembly becomes visible but before schedule()
        // registers this callback. Scheduling first and then re-reading the same injected clock
        // closes that lost-wake window.
        val scheduleStillActive = synchronized(chunkAssemblyLock) {
            chunkedTransfers[assemblyKey] === assembly && assembly.expirySchedule === schedule
        }
        if (!scheduleStillActive) {
            scheduled.cancel()
        } else if (clock.currentTimeMillis() > expiresAtMs) {
            scheduled.cancel()
            expireChunkAssemblyWhileGated(assemblyKey, assembly, schedule)
        }
    }

    private fun expireChunkAssembly(
        assemblyKey: String,
        assembly: ChunkAssembly,
        schedule: ChunkAssemblyExpirySchedule
    ) {
        withChunkTransferGate(assemblyKey) {
            expireChunkAssemblyWhileGated(assemblyKey, assembly, schedule)
        }
    }

    /** Caller must hold this assembly's transfer gate. */
    private fun expireChunkAssemblyWhileGated(
        assemblyKey: String,
        assembly: ChunkAssembly,
        schedule: ChunkAssemblyExpirySchedule
    ) {
        val ownsSchedule = synchronized(chunkAssemblyLock) {
            !closed.get() &&
                chunkedTransfers[assemblyKey] === assembly &&
                assembly.expirySchedule === schedule
        }
        if (!ownsSchedule) {
            return
        }
        if (!chunkAssemblyHasExpired(assembly.lastReceivedAtMs, clock.currentTimeMillis())) {
            scheduleChunkAssemblyExpiry(assemblyKey, assembly)
            return
        }
        removeAndCloseChunkAssembly(assemblyKey, assembly)?.let { throw it }
    }

    /** Caller must hold [outgoingChunkedResponsesLock]. */
    private fun cancelOutgoingChunkedResponseExpiryLocked(response: OutgoingChunkedResponse) {
        response.expirySchedule?.scheduled?.cancel()
        response.expirySchedule = null
    }

    /** Caller must hold [outgoingChunkedResponsesLock]. */
    private fun scheduleOutgoingChunkedResponseExpiryLocked(
        transferId: String,
        response: OutgoingChunkedResponse
    ) {
        cancelOutgoingChunkedResponseExpiryLocked(response)
        val expiresAtMs = outgoingChunkedResponseExpiryDeadline(response.lastProgressAtMs)
        if (closed.get() || expiresAtMs == Long.MAX_VALUE) return

        val schedule = OutgoingChunkedResponseExpirySchedule(expiresAtMs)
        response.expirySchedule = schedule
        schedule.scheduled = clock.schedule(expiresAtMs + 1L) {
            expireOutgoingChunkedResponse(transferId, response, schedule)
        }
        if (clock.currentTimeMillis() > expiresAtMs &&
            outgoingChunkedResponses[transferId] === response &&
            response.expirySchedule === schedule
        ) {
            schedule.scheduled?.cancel()
            expireOutgoingChunkedResponseLocked(transferId, response, schedule)
        }
    }

    private fun expireOutgoingChunkedResponse(
        transferId: String,
        response: OutgoingChunkedResponse,
        schedule: OutgoingChunkedResponseExpirySchedule
    ) {
        synchronized(outgoingChunkedResponsesLock) {
            expireOutgoingChunkedResponseLocked(transferId, response, schedule)
        }
    }

    /** Caller must hold [outgoingChunkedResponsesLock]. */
    private fun expireOutgoingChunkedResponseLocked(
        transferId: String,
        response: OutgoingChunkedResponse,
        schedule: OutgoingChunkedResponseExpirySchedule
    ) {
        if (closed.get() ||
            outgoingChunkedResponses[transferId] !== response ||
            response.expirySchedule !== schedule
        ) {
            return
        }
        if (!outgoingChunkedResponseHasExpired(response.lastProgressAtMs, clock.currentTimeMillis())) {
            scheduleOutgoingChunkedResponseExpiryLocked(transferId, response)
            return
        }
        response.expirySchedule = null
        outgoingChunkedResponses.remove(transferId, response)
    }

    /**
     * Identifies one inbound chunked transfer. A transfer id is unique only within the peer that
     * minted it, so the source peer is part of a transfer's identity.
     */
    private fun chunkAssemblyKey(request: RelayProtocol.RelayRequest): String =
        "${request.sourcePeerId} ${request.transferId}"

    private fun validateRelayRequestChunkMetadata(request: RelayProtocol.RelayRequest) {
        if (request.transferId.isEmpty() && request.totalChunks != 1) {
            if (request.totalChunks > 1) {
                throw RelayException(
                    "Rejected relay request from peer '${request.sourcePeerId}': totalChunks was " +
                        "${request.totalChunks}, but requests with multiple chunks require a non-empty transferId"
                )
            }
            throw RelayException(
                "Rejected relay request from peer '${request.sourcePeerId}': totalChunks was " +
                    "${request.totalChunks}, but requests without a transferId require totalChunks=1"
            )
        }
        if (request.transferId.isNotEmpty() && request.totalChunks < 2) {
            throw RelayException(
                "Rejected relay request from peer '${request.sourcePeerId}': transfer " +
                    "'${request.transferId}' declared " +
                    "totalChunks=${request.totalChunks}, but a non-empty transferId requires at least 2 chunks"
            )
        }
        if (request.totalChunks > MAX_RELAY_REQUEST_CHUNKS) {
            throw RelayException(
                "Rejected chunked relay request from peer '${request.sourcePeerId}' for transfer " +
                    "'${request.transferId}': totalChunks was ${request.totalChunks}, but the maximum " +
                    "supported totalChunks is $MAX_RELAY_REQUEST_CHUNKS"
            )
        }
        if (request.chunkSeq !in 0 until request.totalChunks) {
            throw RelayException(
                "Rejected chunked relay request from peer '${request.sourcePeerId}' for transfer " +
                    "'${request.transferId}': chunkSeq was ${request.chunkSeq}, but the allowed range " +
                    "for totalChunks=${request.totalChunks} is 0 until ${request.totalChunks}"
            )
        }
    }

    /** Caller must hold [chunkAssemblyLock]. */
    private fun rejectMismatchedChunkCountLocked(
        request: RelayProtocol.RelayRequest,
        assembly: ChunkAssembly?,
    ) {
        if (assembly != null && assembly.totalChunks != request.totalChunks) {
            throw RelayException(
                "Rejected chunked relay request from peer '${request.sourcePeerId}' for transfer " +
                    "'${request.transferId}': totalChunks was ${request.totalChunks}, but this transfer " +
                    "was established with totalChunks=${assembly.totalChunks}"
            )
        }
    }

    /**
     * If [request] is a single, whole payload (the default), invoke [handler]
     * directly. Otherwise buffer the chunk; ack non-final chunks; on the final
     * chunk reassemble and invoke [handler] once with the full payload.
     */
    private fun reassembleAndHandle(
        handler: (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse,
        request: RelayProtocol.RelayRequest
    ): RelayProtocol.RelayResponse {
        validateRelayRequestChunkMetadata(request)
        if (request.totalChunks == 1) {
            return handler(request)
        }
        val assemblyKey = chunkAssemblyKey(request)

        if (request.payload.length > MAX_RELAY_REQUEST_CHUNK_ENCODED_CHARACTERS) {
            throw RelayException(
                "Rejected chunked relay request from peer '${request.sourcePeerId}' for transfer " +
                    "'${request.transferId}': encoded chunk contained ${request.payload.length} " +
                    "characters, but the maximum allowed encoded chunk length is " +
                    "$MAX_RELAY_REQUEST_CHUNK_ENCODED_CHARACTERS characters"
            )
        }
        val decodedChunk = Base64.getDecoder().decode(request.payload)
        if (decodedChunk.size > relayRequestChunkBytes) {
            throw RelayException(
                "Rejected chunked relay request from peer '${request.sourcePeerId}' for transfer " +
                    "'${request.transferId}': decoded chunk contained ${decodedChunk.size} bytes, but " +
                "the maximum allowed chunk size is $relayRequestChunkBytes bytes"
            )
        }

        class PreparedChunkDelivery(
            val assembly: ChunkAssembly,
            val encodedPayload: String,
            val materializationLease: AutoCloseable,
        )

        var serviceClosed = false
        val delivery = withChunkTransferGate(assemblyKey) {
            val receivedAtMs = clock.currentTimeMillis()
            val existingBeforeExpiry = synchronized(chunkAssemblyLock) {
                if (closed.get()) {
                    serviceClosed = true
                    null
                } else {
                    rejectCompletingChunkTransferLocked(request, assemblyKey)
                    chunkedTransfers[assemblyKey]
                }
            }
            if (serviceClosed) return@withChunkTransferGate null

            var existing = existingBeforeExpiry
            if (existing != null && chunkAssemblyHasExpired(existing.lastReceivedAtMs, receivedAtMs)) {
                removeAndCloseChunkAssembly(assemblyKey, existing)?.let { throw it }
                existing = null
            }
            rejectMismatchedChunkCountLocked(request, existing)

            val current = existing ?: createChunkAssembly(request, receivedAtMs)
            if (closed.get()) {
                serviceClosed = true
                removeAndCloseChunkAssembly(assemblyKey, current)?.let { throw it }
                return@withChunkTransferGate null
            }

            try {
                current.storage.writeChunk(request.chunkSeq, decodedChunk)
                current.lastReceivedAtMs = maxOf(current.lastReceivedAtMs, receivedAtMs)
                if (!current.storage.isComplete()) {
                    synchronized(chunkAssemblyLock) {
                        if (closed.get()) {
                            serviceClosed = true
                        } else {
                            chunkedTransfers[assemblyKey] = current
                        }
                    }
                    if (serviceClosed) {
                        removeAndCloseChunkAssembly(assemblyKey, current)?.let { throw it }
                        return@withChunkTransferGate null
                    }
                    scheduleChunkAssemblyExpiry(assemblyKey, current)
                    return@withChunkTransferGate null
                }

                synchronized(chunkAssemblyLock) {
                    chunkedTransfers.remove(assemblyKey, current)
                    completingChunkAssemblies[assemblyKey] = current
                }
                cancelChunkAssemblyExpiry(current)

                val materializationLease = try {
                    RelayRequestMaterializationBudget.acquire(
                        request.sourcePeerId,
                        request.transferId,
                        current.storage.rawByteCount,
                    ) { closed.get() }
                } catch (failure: Throwable) {
                    throw removeAndCloseChunkAssembly(assemblyKey, current, failure) ?: failure
                }

                try {
                    val encodedPayload = current.storage.encodePayload()
                    closeRelayChunkAssembly(current.storage)?.let { throw it }
                    PreparedChunkDelivery(current, encodedPayload, materializationLease)
                } catch (failure: Throwable) {
                    materializationLease.close()
                    throw removeAndCloseChunkAssembly(assemblyKey, current, failure) ?: failure
                }
            } catch (failure: Throwable) {
                throw removeAndCloseChunkAssembly(assemblyKey, current, failure) ?: failure
            }
        }
        if (serviceClosed) return relayServiceClosedResponse(request)
        if (delivery == null) {
            return RelayProtocol.RelayResponse(
                requestId = request.requestId,
                sourcePeerId = request.targetPeerId,
                targetPeerId = request.sourcePeerId,
                payload = "",
                success = true,
                chunkAck = true
            )
        }
        try {
            return delivery.materializationLease.use {
                raceLifecycleLock.withLock {
                    if (closed.get()) {
                        throw RelayException(
                            "RelayService closed before the completed chunked relay request from peer " +
                                "'${request.sourcePeerId}' for transfer '${request.transferId}' could " +
                                "be delivered to its handler"
                        )
                    }
                    // This claim and close()'s closed-state transition share the same lock. Once this
                    // assignment succeeds, delivery won the race; close never waits for or runs under
                    // the arbitrary handler code itself.
                    check(!delivery.assembly.handlerDeliveryClaimed) {
                        "Completed chunked relay request handler delivery was claimed more than once"
                    }
                    delivery.assembly.handlerDeliveryClaimed = true
                }
                handler(
                    request.copy(
                        payload = delivery.encodedPayload,
                        transferId = "",
                        chunkSeq = 0,
                        totalChunks = 1,
                    )
                )
            }
        } finally {
            // The temporary file is already closed before handler invocation, but this lightweight
            // ownership marker stays until the handler returns or throws. close() may remove the
            // same entry concurrently, so the conditional removal is deliberately idempotent.
            synchronized(chunkAssemblyLock) {
                completingChunkAssemblies.remove(assemblyKey, delivery.assembly)
                chunkTransferGates[assemblyKey]?.let { gate ->
                    removeChunkTransferGateIfUnusedLocked(assemblyKey, gate)
                }
            }
        }
    }

    // Frame headers remain inside the payload so older intermediaries preserve them.
    // New callers require a separate successful-response length tag before parsing the header;
    // ordinary response content can therefore contain the same bytes without losing its prefix.
    /**
     * If [response] fits in one frame — or the requesting [request] did not advertise chunked-response
     * support — return it unchanged. Otherwise buffer the full raw payload under a new transferId and
     * return chunk 0 wrapped in the response-chunk envelope (inside the payload, so it survives an older
     * relay); the requester fetches the rest (see sendViaRelay), which [serveResponseChunk] answers. The
     * support gate means a new target never silently truncates an OLD requester. Acks and errors pass through.
     */
    private fun maybeChunkResponse(request: RelayProtocol.RelayRequest, response: RelayProtocol.RelayResponse): RelayProtocol.RelayResponse {
        if (!response.success || response.chunkAck || response.payload.isEmpty()) return response
        if (request.headers[responseChunkSupportHeader] != "true") return response
        val raw = Base64.getDecoder().decode(response.payload)
        val opaqueFraming = request.headers[RESPONSE_FRAMING_HEADER] == RESPONSE_FRAMING_CAPABILITY
        if (raw.size <= relayChunkBytes && (opaqueFraming || parseResponseChunk(raw) == null)) {
            return if (opaqueFraming) response.copy(errorMessage = RESPONSE_BODY_TAG + raw.size) else response
        }
        val totalChunks = (raw.size + relayChunkBytes - 1) / relayChunkBytes
        val transferId = RelayProtocol.nextMessageId()
        if (totalChunks > 1) synchronized(outgoingChunkedResponsesLock) {
            if (closed.get()) return relayServiceClosedResponse(request)
            val now = clock.currentTimeMillis()
            val response = OutgoingChunkedResponse(raw, totalChunks, now, response.errorMessage, opaqueFraming)
            outgoingChunkedResponses.put(transferId, response)?.let(::cancelOutgoingChunkedResponseExpiryLocked)
            scheduleOutgoingChunkedResponseExpiryLocked(transferId, response)
        }
        val data = raw.copyOfRange(0, minOf(relayChunkBytes, raw.size))
        return response.copy(
            payload = wrapResponseChunk(transferId, 0, totalChunks, data),
            errorMessage = if (opaqueFraming)
                RESPONSE_FRAMING_TAG + data.size else response.errorMessage
        )
    }

    /** Answers a requester's fetch for chunk [responseChunkSeqHeader] of a buffered chunked response. */
    private fun serveResponseChunk(request: RelayProtocol.RelayRequest, transferId: String): RelayProtocol.RelayResponse {
        val seq = request.headers[responseChunkSeqHeader]?.toIntOrNull() ?: 0
        return synchronized(outgoingChunkedResponsesLock) {
            val buffered = outgoingChunkedResponses[transferId]
                ?: return@synchronized RelayProtocol.RelayResponse.error(
                    request.requestId, request.targetPeerId, request.sourcePeerId,
                    "Unknown or expired response transfer $transferId (chunk $seq)"
                )
            val now = clock.currentTimeMillis()
            if (outgoingChunkedResponseHasExpired(buffered.lastProgressAtMs, now)) {
                if (outgoingChunkedResponses.remove(transferId, buffered)) {
                    cancelOutgoingChunkedResponseExpiryLocked(buffered)
                }
                return@synchronized RelayProtocol.RelayResponse.error(
                    request.requestId, request.targetPeerId, request.sourcePeerId,
                    "Unknown or expired response transfer $transferId (chunk $seq)"
                )
            }
            val start = seq.toLong() * relayChunkBytes
            if (seq < 0 || start > buffered.raw.size) {
                return@synchronized RelayProtocol.RelayResponse.error(
                    request.requestId, request.targetPeerId, request.sourcePeerId,
                    "Response chunk $seq out of range for $transferId"
                )
            }
            val end = minOf(start.toInt() + relayChunkBytes, buffered.raw.size)
            // Chunk fetches are served in whatever order the handler executor schedules them —
            // requestHandlers run off the connection reader thread, so the fetch for the FINAL
            // chunk can be served before the fetch for an earlier one. Releasing the buffer on
            // the final-seq fetch (the pre-concurrency behavior) made an earlier chunk's fetch
            // fail with "Unknown or expired response transfer", so the buffer is released only
            // once EVERY chunk has been served, regardless of order. Chunk 0 is pre-served at
            // construction; a duplicate fetch neither refreshes the idle lifetime nor completes
            // the transfer twice, because servedChunks.add is false for an already-served seq.
            if (buffered.servedChunks.add(seq.coerceAtMost(buffered.totalChunks - 1))) {
                if (buffered.servedChunks.size >= buffered.totalChunks) {
                    if (outgoingChunkedResponses.remove(transferId, buffered)) {
                        cancelOutgoingChunkedResponseExpiryLocked(buffered)
                    }
                } else {
                    buffered.lastProgressAtMs = now
                    scheduleOutgoingChunkedResponseExpiryLocked(transferId, buffered)
                }
            }
            RelayProtocol.RelayResponse(
                requestId = request.requestId,
                sourcePeerId = request.targetPeerId,
                targetPeerId = request.sourcePeerId,
                payload = wrapResponseChunk(transferId, seq, buffered.totalChunks, buffered.raw.copyOfRange(start.toInt(), end)),
                errorMessage = if (buffered.opaqueFraming)
                    RESPONSE_FRAMING_TAG + (end - start.toInt()) else buffered.errorMessage,
                success = true
            )
        }
    }

    private val started = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private val idleRelayRequestConnections =
        ConcurrentHashMap<String, IdleRelayRequestConnections>()
    // Owned under raceLifecycleLock. Close detaches this complete set, then closes each stream
    // after releasing the lock so an admitted request write cannot keep close from becoming final.
    private val activeRelayRequestConnections = LinkedHashSet<RelayConnection>()

    // AlgebraicEffects V1 stores handler scopes in a ThreadLocal. Relay disconnect cleanup runs
    // on a coroutine worker, so retain the scope that started this service and install it only
    // while emitting asynchronous relay lifecycle effects. This carries the effect to the caller;
    // the relay does not handle or suppress it.
    @Volatile
    private var effectHandlerRepositoryAtStart: EffectHandlerRepository? = null
    @Volatile
    private var disconnectEffectContextAtStart: EffectHandlerContext? = null

    // Relay mode: peers registered with us. The map monitor serializes writes with ordinary
    // gossip worker sizing; reads remain concurrent. No lifecycle work or IO runs under it.
    private val registeredPeers = ConcurrentHashMap<String, RegisteredPeer>()

    // A transport close removes the unusable live controller immediately, but it is not an
    // authoritative service withdrawal. Preserve only the compact provider inventory and the
    // original registration deadline until reconnect grace expires. Lifecycle transitions that
    // install/cancel a tombstone are serialized so an old stream's close cannot race a successful
    // replacement registration and leave behind (or erase) the wrong generation.
    private class DisconnectedProviderTombstone(
        val serviceInventory: ProviderServiceInventory,
        val expiresAtMs: Long
    )

    private class DisconnectedProviderExpirySchedule(
        val expiresAtMs: Long
    ) {
        var scheduled: Scheduled? = null
    }
    // Whenever these locks are combined, the order is strictly registrationLifecycleLock ->
    // providerLifecycleLock(providerPeerId) -> ProviderServiceInventory state lock ->
    // cachedServiceAnnouncementsLock. A path may skip an earlier lock when it does not need that
    // state, but code already holding a later lock must never acquire an earlier one. This keeps
    // stream-close/re-registration transitions from deadlocking announcement and withdrawal
    // processing while preserving the bounded per-provider transaction domain.
    private val registrationLifecycleLock = Any()
    private val disconnectedProviderTombstones =
        LinkedHashMap<String, DisconnectedProviderTombstone>()
    // Cache admission runs on every announcement and must not take the global registration lock.
    // This bounded mirror lets it answer the one question it needs under the provider lock: whether
    // this identity has no live registration because its last stream is in disconnect grace. Every
    // mutation is paired with the tombstone map while holding registrationLifecycleLock and the
    // provider's lifecycle lock, so the marker cannot outlive or predate its tombstone transition.
    private val disconnectedProviderPeerIds = ConcurrentHashMap.newKeySet<String>()
    private var disconnectedProviderExpirySchedule: DisconnectedProviderExpirySchedule? = null

    // Distance vector routing table for multi-hop message forwarding
    private val routingTable = RoutingTable(host.peerId.toBase58(), clock)

    // Link-state routing table runs alongside distance-vector routing. It is
    // consulted first for forwarding, with distance-vector retained as fallback.
    private val linkStateRoutingTable = LinkStateRoutingTable(host.peerId.toBase58(), clock)
    private val linkStateForwardingCounts = ConcurrentHashMap<String, AtomicInteger>()
    private val relayForwardingCounts = ConcurrentHashMap<String, AtomicInteger>()
    private val linkStateLinkCosts = ConcurrentHashMap<String, Long>()
    private val relayWarningEffects = ConcurrentLinkedQueue<RelayWarningEffect>()
    private val latestOrdinaryGossipDeliveryFailure =
        AtomicReference<RelayOrdinaryGossipDeliveryFailureWarningEffect?>(null)
    // Callback saturation may repeat for every incoming frame. Retain only the latest occurrence
    // so the diagnostic path is observable without turning overload into an unbounded log queue.
    private val latestRelayReceiveCallbackOverflow =
        AtomicReference<RelayReceiveCallbackQueueOverflowWarningEffect?>(null)
    @Volatile
    private var relayReceiveCallbackOverflowSeamForTesting:
        ((RelayReceiveCallbackQueueOverflowWarningEffect) -> Unit)? = null
    private val latestRelayReceiveCallbackFailure =
        AtomicReference<RelayReceiveCallbackFailureDiagnostic?>(null)
    @Volatile
    private var relayRegistrationNotificationStartTestSeam: (() -> Unit)? = null
    @Volatile
    private var relayIdentityPublicationStartTestSeam: (() -> Unit)? = null
    @Volatile
    private var relayReceiveCallbackOfferCompletedTestSeam: ((String) -> Unit)? = null
    /**
     * Test-only observation point immediately after a relay has admitted an unregister ACK to the
     * transport. It is intentionally absent from the production path unless a test installs it.
     */
    @Volatile
    private var relayUnregisterAcknowledgementAdmittedTestSeam: ((String) -> Unit)? = null
    // Cleanup failures remain observable without allowing repeated reservation attempts to grow
    // an unbounded warning queue. The effect includes the cleanup-attempt number and whether an
    // earlier FileHandle close already failed.
    private val latestRelayRequestTemporaryStorageCleanupFailure =
        AtomicReference<RelayRequestTemporaryStorageCleanupWarningEffect?>(null)

    // Serialize before extracting fields so admission and replay share one detached value.
    // Only immutable strings and numbers survive construction; no caller-owned JSON is retained.
    private class ServiceAnnouncementSnapshot(message: JSONObject) {
        val serializedMessage: String = message.toString()
        val providerPeerId: String
        val timestamp: Long
        val serviceUrl: String?

        init {
            val detached = JSONObject(serializedMessage)
            providerPeerId = detached.optString("providerPeerId", "")
            timestamp = detached.optLong("timestamp", 0L)
            serviceUrl = detached.optString("serviceUrl", null)
        }
    }

    private class CachedServiceAnnouncement(
        val message: ServiceAnnouncementSnapshot,
        val cachedAtMs: Long,
        val ownerStreamGeneration: Long?,
        val ownerPeerId: String?
    )

    private data class CachedWithdrawalTimestamp(
        val serviceIdentifier: String,
        val providerPeerId: String,
        val providerTimestamp: Long,
        val expiresAtMs: Long
    )

    private data class PreparedServiceWithdrawal(
        val withdrawal: GossipProtocol.ServiceWithdrawal,
        val providerRegistrationAtCommit: RegisteredPeer?,
        val excludePeerId: String? = withdrawal.providerPeerId,
        val callbackSenderPeerId: String = withdrawal.providerPeerId
    )

    private data class PreparedReceivedServiceWithdrawal(
        val received: PreparedServiceWithdrawal,
        val expiredTombstones: List<PreparedServiceWithdrawal>
    )

    private data class StagedRelayRegistration(
        val request: RelayProtocol.RelayRegister,
        val ackGatedController: AckGatedRelayMessageSender,
        val registration: RegisteredPeer,
        val previousRegistration: RegisteredPeer?,
        val registeredPeerAddresses: List<String>,
        val committedAdvertisedServices: List<String>,
        val committedServiceLifecycleTimestamps: Map<String, Long>,
        val cachedServiceKeysSupersededByRegistration: List<String>,
        val servicesDisplacedDuringRegistration: List<ProviderServiceLifecycle>,
        var previousRegistrationClosed: Boolean = false
    )

    private data class RelayRegistryPeerSnapshot(
        val peer: BootstrapPeer?,
        val originState: PeerRegistryPeerOriginState?
    )

    private data class PreparedRelayRegistrationPublication(
        val staged: StagedRelayRegistration,
        val controller: RelayMessageSender,
        val bufferedMessages: List<AckGatedPendingMessage>,
        val withdrawals: List<PreparedServiceWithdrawal>
    )

    private data class PreparedRelayUnregisterPublication(
        val request: RelayProtocol.RelayUnregister,
        val withdrawals: List<PreparedServiceWithdrawal>,
        val removedRegistration: Boolean,
        val acknowledgedSupersededGeneration: Boolean,
    )

    private data class RelayIdentityPublication(
        val generation: Long,
        val advertisedServices: Set<String>,
        val withdrawals: List<PreparedServiceWithdrawal>,
        val publishRegistryReplacement: () -> Unit,
        val publishBufferedMessages: () -> Unit,
        val scheduleRegistrationCallback: () -> CompletableFuture<Unit>,
        val scheduleNotifications: () -> CompletableFuture<Unit>,
        val includeCallbacksInVisibility: Boolean = false,
        val completion: CompletableFuture<Unit> = CompletableFuture(),
        val visibilityCompletion: CompletableFuture<Unit> = CompletableFuture()
    )

    private class RelayIdentityPublicationGate {
        val lock = Any()
        val carriedWithdrawals = LinkedHashMap<String, PreparedServiceWithdrawal>()
        var active: RelayIdentityPublication? = null
        var pending: RelayIdentityPublication? = null
        var workerScheduled = false
    }

    private data class RelayIdentityPublicationTicket(
        val providerPeerId: String,
        val gate: RelayIdentityPublicationGate,
        val completion: CompletableFuture<Unit>,
        val visibilityCompletion: CompletableFuture<Unit>,
        val hasPublicationPredecessor: Boolean
    )

    internal class IdentityPublicationCompletion(
        val completion: CompletableFuture<Unit>,
        val requestStateTransitionCommitted: Boolean = true,
        val unregisterAcknowledged: Boolean = requestStateTransitionCommitted,
        private val failureOwnership: () -> Boolean
    ) {
        fun failureStillOwnsRegistration(): Boolean = failureOwnership()
    }

    private class RelayRegistrationTransaction {
        val admitted = CompletableFuture<Unit>()
        // Read and written only while holding providerLifecycleLock for this transaction's peer.
        var stagedRegistration: StagedRelayRegistration? = null
    }

    private class RelayRegistrationGate(
        @Volatile var owner: RelayRegistrationTransaction
    ) {
        val waiters = ArrayDeque<RelayRegistrationTransaction>()
    }

    // Full-payload cache used ONLY for replay to late joiners. Disconnect correctness is owned by
    // each live registration's compact ProviderServiceInventory below, so evicting a large JSON
    // payload can never erase the relay's knowledge that the provider must withdraw that service.
    // Access is serialized so the insertion-ordered map deterministically evicts the oldest
    // distinct service while a refresh moves the identifier back to the newest position.
    private val cachedServiceAnnouncementsLock = Any()
    private val cachedServiceAnnouncements = LinkedHashMap<String, CachedServiceAnnouncement>()

    private data class RelayIngressAnnouncementFingerprint(
        val contentHash: String,
        val lastFanoutAtMs: Long
    )

    private data class RelayIngressAnnouncementKey(
        val originPeerId: String,
        val serviceIdentifier: String
    )

    // The full replay cache above is keyed by service for compatibility. Ingress suppression must
    // instead distinguish the authenticated relay-stream origin: a source can claim any provider
    // ID in a gossip payload, and two origins may legitimately announce the same service. This map
    // shares the replay-cache lock and bound so attacker-controlled identities cannot introduce an
    // unbounded relay-side cache.
    private val relayIngressAnnouncementFingerprints =
        LinkedHashMap<RelayIngressAnnouncementKey, RelayIngressAnnouncementFingerprint>()

    // Provider lifecycle transitions use a fixed lock domain so registration, announcement, and
    // withdrawal commits for the same provider serialize without retaining attacker-controlled
    // provider IDs forever. Every path acquires this provider lock before an inventory lock and
    // before cachedServiceAnnouncementsLock; no path may acquire them in the opposite order.
    private val providerLifecycleLocks = Array(PROVIDER_LIFECYCLE_LOCK_STRIPES) { Any() }

    private fun providerLifecycleLock(providerPeerId: String): Any =
        providerLifecycleLocks[(providerPeerId.hashCode() and Int.MAX_VALUE) % providerLifecycleLocks.size]

    // Only one RelayRegister or RelayUnregister transaction for a provider identity may own the
    // stage -> ACK -> internal commit/rollback interval. Per-key ConcurrentHashMap computation
    // serializes only the brief enqueue/handoff bookkeeping: no map, lifecycle, provider,
    // inventory, or announcement monitor is held while a waiter is parked or while the owner
    // performs ACK I/O. Ownership is handed to exactly the queue head before it is awakened, so a
    // newcomer cannot overtake a parked waiter. External callbacks and publication I/O are ordered
    // separately after this transaction is released, so callback re-entry and slow network fan-out
    // cannot reserve the provider identity. Returning null from the final owner's release removes
    // the idle identity atomically, keeping identity churn from accumulating entries. The map
    // computation never overlaps the documented lifecycle lock order (registrationLifecycleLock ->
    // providerLifecycleLock -> inventory -> cachedServiceAnnouncementsLock), so the gate adds no
    // edge to that acquisition graph.
    private val relayRegistrationTransactions =
        ConcurrentHashMap<String, RelayRegistrationGate>()

    // Publication generations are globally unique, which also makes each identity's subsequence
    // monotonic without retaining a permanent attacker-controlled identity -> counter map.
    private val relayIdentityPublicationGeneration = AtomicLong(0L)
    private val relayIdentityPublicationGates =
        ConcurrentHashMap<String, RelayIdentityPublicationGate>()

    // Identity publication never runs on a relay stream's limitedParallelism(1) dispatcher. One
    // dedicated worker per RelayService drains the bounded per-identity state below; callbacks and
    // best-effort fan-out use separate contexts so a callback that never returns cannot retain a
    // publication gate or prevent a newer committed generation from advancing.
    private val relayIdentityPublicationExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "RelayService-identity-publication").apply { isDaemon = true }
    }
    private val relayPublicationCallbackExecutor = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "RelayService-publication-callback").apply { isDaemon = true }
    }
    private val relayPublicationNotificationExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "RelayService-publication-notification").apply { isDaemon = true }
    }

    // Registered-target request handling never runs on the relay connection's reader thread.
    // startRequestListener used to invoke the registered handler inline and write the reply
    // before looping back to read, so a handler that took seconds stopped every later frame on
    // that connection from being read at all — including the next chunk of an in-progress
    // chunked upload, which then died on the caller's deadline. Handlers run here instead, and
    // the reader returns to reading immediately. This mirrors what forwardRequestToRegistered
    // already does for the relay side of the same connection.
    private val relayedRequestHandlerExecutor = Executors.newThreadPerTaskExecutor(
        Thread.ofVirtual().name("RelayService-request-handler-", 0L).factory()
    )
    // Number of registered requests executing or retaining a reply awaiting outbox capacity.
    // The reader admits a request only below MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS and never
    // waits for a handler to finish: a request over the bound is refused at once with a request-scoped error, so a
    // registration connection keeps reading requests, acknowledgements and pings no matter how
    // long its admitted handlers run. Each slot returns exactly once at response admission, or
    // on failure/close if the request cannot reach that handoff.
    private val runningRelayedRequestHandlers = AtomicInteger(0)
    // Admitted handlers by the registration connection that delivered them, so closing that
    // connection can interrupt the handlers whose replies it can no longer carry.
    private val relayedRequestHandlerThreads = ConcurrentHashMap<Thread, RelayConnection>()
    // Test-only observation point on the reader thread immediately before a registered request
    // is admitted. A lifecycle test can hold the reader here (after it reserved the request's
    // failure-reply capacity) without depending on scheduler timing.
    @Volatile
    private var relayRequestDispatchTestSeam: (() -> Unit)? = null
    // Test-only observation point after a detached listener has been interrupted. It lets a
    // lifecycle test force the listener's fallback acknowledgement sweep to finish before the
    // close observer continues, without depending on scheduler timing.
    @Volatile
    private var relayListenerInterruptedTestSeam: (() -> Unit)? = null
    private val relayReceiveCallbacksPerPeer = config.receiveCallbackQueueCapacityPerPeer
    private val relayReceiveCallbackExecutor = Executors.newThreadPerTaskExecutor(
        Thread.ofVirtual().name("RelayService-receive-callback-", 0L).factory()
    )
    // Remote transport-close observations can complete public futures and therefore run arbitrary
    // caller callbacks. Keep them off the receive executor that close() joins: a callback may ask
    // another thread to close this service and wait for it, so joining this observer would create
    // a wait cycle. Shutdown interrupts these daemon workers but deliberately does not join them.
    private val relayCloseObserverExecutor = Executors.newThreadPerTaskExecutor(
        Thread.ofVirtual().name("RelayService-close-observer-", 0L).factory()
    )
    private val relayReceiveCallbacks = RelayReceiveCallbackQueue(
        executor = relayReceiveCallbackExecutor,
        maxCallbacksPerPeer = relayReceiveCallbacksPerPeer,
        maxRetainedBytesPerPeer = RELAY_RECEIVE_CALLBACK_BYTES_PER_PEER,
        maxServiceStateKeysPerPeer = RELAY_RECEIVE_SERVICE_STATE_KEYS_PER_PEER,
        maxPeerLanes = RELAY_RECEIVE_CALLBACK_PEERS,
    )
    private val ordinaryRelayGossipRetainedBytes = AtomicLong(0L)
    @Volatile
    private var ordinaryRelayGossipWorkerStartSeamForTesting: (() -> Unit)? = null
    private val ordinaryRelayGossipWorkerCount = config.maxClients.coerceIn(1, 16)
    private val ordinaryRelayGossipExecutor = ThreadPoolExecutor(
        1,
        ordinaryRelayGossipWorkerCount,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(config.maxClients.coerceIn(8, 1024) * 2),
        { runnable ->
            Thread(runnable, "RelayService-ordinary-gossip").apply { isDaemon = true }
        },
        ThreadPoolExecutor.AbortPolicy()
    )
    private val relayRegisterAckAdmissionDepth = ThreadLocal.withInitial { 0 }

    private fun acquireRelayRegistrationTransaction(
        providerPeerId: String
    ): RelayRegistrationTransaction {
        val transaction = RelayRegistrationTransaction()
        var admittedImmediately = false
        relayRegistrationTransactions.compute(providerPeerId) { _, existingGate ->
            if (existingGate == null) {
                admittedImmediately = true
                RelayRegistrationGate(transaction)
            } else {
                existingGate.waiters.addLast(transaction)
                existingGate
            }
        }
        if (admittedImmediately) return transaction

        try {
            transaction.admitted.get()
        } catch (failure: Throwable) {
            try {
                abandonRelayRegistrationTransaction(providerPeerId, transaction)
            } catch (cleanupFailure: Throwable) {
                failure.addSuppressed(cleanupFailure)
            }
            throw failure
        }
        return transaction
    }

    private fun releaseRelayRegistrationTransaction(
        providerPeerId: String,
        transaction: RelayRegistrationTransaction
    ) {
        var nextOwner: RelayRegistrationTransaction? = null
        relayRegistrationTransactions.compute(providerPeerId) { _, gate ->
            checkNotNull(gate) {
                "Relay registration transaction gate disappeared while provider '$providerPeerId' " +
                    "still had an owner"
            }
            check(gate.owner === transaction) {
                "Relay registration transaction ownership was lost for provider '$providerPeerId'"
            }
            nextOwner = if (gate.waiters.isEmpty()) null else gate.waiters.removeFirst()
            nextOwner?.let {
                gate.owner = it
                gate
            }
        }
        nextOwner?.admitted?.complete(Unit)
    }

    private fun abandonRelayRegistrationTransaction(
        providerPeerId: String,
        transaction: RelayRegistrationTransaction
    ) {
        var nextOwner: RelayRegistrationTransaction? = null
        relayRegistrationTransactions.compute(providerPeerId) { _, gate ->
            checkNotNull(gate) {
                "Relay registration transaction gate disappeared while abandoning a waiter for " +
                    "provider '$providerPeerId'"
            }
            if (gate.owner === transaction) {
                nextOwner = if (gate.waiters.isEmpty()) null else gate.waiters.removeFirst()
                nextOwner?.let {
                    gate.owner = it
                    gate
                }
            } else {
                check(gate.waiters.remove(transaction)) {
                    "Relay registration transaction waiter was lost for provider '$providerPeerId'"
                }
                gate
            }
        }
        nextOwner?.admitted?.complete(Unit)
    }

    /** Caller must hold [providerLifecycleLock] for [providerPeerId]. */
    private fun registrationIsStagedByOwningTransactionWithProviderLock(
        providerPeerId: String,
        registration: RegisteredPeer
    ): Boolean = relayRegistrationTransactions[providerPeerId]
        ?.owner
        ?.stagedRegistration
        ?.registration === registration

    private fun withdrawalServiceIdentifier(prepared: PreparedServiceWithdrawal): String =
        prepared.withdrawal.serviceIdentifier

    /** Queues one committed generation while retaining at most one not-yet-started full snapshot. */
    private fun enqueueRelayIdentityPublication(
        providerPeerId: String,
        advertisedServices: Set<String>,
        withdrawals: List<PreparedServiceWithdrawal>,
        publishRegistryReplacement: () -> Unit,
        publishBufferedMessages: () -> Unit,
        scheduleRegistrationCallback: () -> CompletableFuture<Unit>,
        scheduleNotifications: () -> CompletableFuture<Unit>
    ): RelayIdentityPublicationTicket {
        var ticket: RelayIdentityPublicationTicket? = null
        relayIdentityPublicationGates.compute(providerPeerId) { _, existing ->
            val gate = existing ?: RelayIdentityPublicationGate()
            synchronized(gate.lock) {
                val hasPublicationPredecessor = gate.active != null || gate.pending != null
                val generation = relayIdentityPublicationGeneration.incrementAndGet()
                check(generation > 0L) {
                    "Relay identity publication generation overflowed while committing provider " +
                        "'$providerPeerId'"
                }
                val publication = RelayIdentityPublication(
                    generation = generation,
                    advertisedServices = advertisedServices,
                    withdrawals = withdrawals,
                    publishRegistryReplacement = publishRegistryReplacement,
                    publishBufferedMessages = publishBufferedMessages,
                    scheduleRegistrationCallback = scheduleRegistrationCallback,
                    scheduleNotifications = scheduleNotifications
                )

                val supersededWithdrawalServices = advertisedServices +
                    withdrawals.map(::withdrawalServiceIdentifier)
                gate.carriedWithdrawals.keys.removeAll(supersededWithdrawalServices)
                gate.pending?.let { superseded ->
                    for (withdrawal in superseded.withdrawals) {
                        val serviceIdentifier = withdrawalServiceIdentifier(withdrawal)
                        if (serviceIdentifier !in supersededWithdrawalServices) {
                            gate.carriedWithdrawals[serviceIdentifier] = withdrawal
                        }
                    }
                    // Its full snapshot is superseded before it starts and every required
                    // withdrawal is either represented by the newer generation or carried here.
                    superseded.completion.complete(Unit)
                    superseded.visibilityCompletion.complete(Unit)
                }
                gate.pending = publication
                ticket = RelayIdentityPublicationTicket(
                    providerPeerId,
                    gate,
                    publication.completion,
                    publication.visibilityCompletion,
                    hasPublicationPredecessor
                )
            }
            gate
        }
        return checkNotNull(ticket) {
            "Relay identity publication for provider '$providerPeerId' was not queued"
        }
    }

    /**
     * Adds withdrawals to an identity's ordered publication stream without replacing a pending
     * registration snapshot. Expiry and capacity cleanup do not own a full identity snapshot, so
     * treating them as one could discard a newer committed registration that has not started
     * publication yet.
     */
    private fun enqueueRelayIdentityWithdrawals(
        providerPeerId: String,
        withdrawals: List<PreparedServiceWithdrawal>
    ): RelayIdentityPublicationTicket {
        check(withdrawals.all { it.withdrawal.providerPeerId == providerPeerId }) {
            "Relay identity withdrawal batch for provider '$providerPeerId' contained a " +
                "withdrawal owned by another provider"
        }
        var ticket: RelayIdentityPublicationTicket? = null
        relayIdentityPublicationGates.compute(providerPeerId) { _, existing ->
            val gate = existing ?: RelayIdentityPublicationGate()
            synchronized(gate.lock) {
                val hasPublicationPredecessor = gate.active != null || gate.pending != null
                val pending = gate.pending
                val publication = if (pending == null) {
                    val generation = relayIdentityPublicationGeneration.incrementAndGet()
                    check(generation > 0L) {
                        "Relay identity publication generation overflowed while committing " +
                            "provider '$providerPeerId'"
                    }
                    RelayIdentityPublication(
                        generation = generation,
                        advertisedServices = emptySet(),
                        withdrawals = withdrawals,
                        publishRegistryReplacement = {},
                        publishBufferedMessages = {},
                        scheduleRegistrationCallback = {
                            CompletableFuture.completedFuture(Unit)
                        },
                        scheduleNotifications = {
                            CompletableFuture.completedFuture(Unit)
                        },
                        includeCallbacksInVisibility = true
                    )
                } else {
                    val mergedWithdrawals = LinkedHashMap<String, PreparedServiceWithdrawal>()
                    for (withdrawal in pending.withdrawals) {
                        mergedWithdrawals[withdrawalServiceIdentifier(withdrawal)] = withdrawal
                    }
                    for (withdrawal in withdrawals) {
                        mergedWithdrawals[withdrawalServiceIdentifier(withdrawal)] = withdrawal
                    }
                    pending.copy(
                        withdrawals = mergedWithdrawals.values.toList(),
                        includeCallbacksInVisibility = true
                    )
                }
                gate.pending = publication
                ticket = RelayIdentityPublicationTicket(
                    providerPeerId,
                    gate,
                    publication.completion,
                    publication.visibilityCompletion,
                    hasPublicationPredecessor
                )
            }
            gate
        }
        return checkNotNull(ticket) {
            "Relay identity withdrawals for provider '$providerPeerId' were not queued"
        }
    }

    private fun scheduleRelayIdentityWithdrawals(
        withdrawals: List<PreparedServiceWithdrawal>
    ): List<RelayIdentityPublicationTicket> {
        val tickets = withdrawals.groupBy { it.withdrawal.providerPeerId }
            .map { (providerPeerId, providerWithdrawals) ->
                enqueueRelayIdentityWithdrawals(providerPeerId, providerWithdrawals)
            }
        tickets.forEach(::scheduleRelayIdentityPublicationDrain)
        return tickets
    }

    /** Called only after the registration transaction has released its provider identity. */
    private fun scheduleRelayIdentityPublicationDrain(ticket: RelayIdentityPublicationTicket) {
        val gate = ticket.gate
        val scheduleWorker = synchronized(gate.lock) {
            if (gate.workerScheduled) {
                false
            } else {
                gate.workerScheduled = true
                true
            }
        }
        if (!scheduleWorker) return
        try {
            relayIdentityPublicationExecutor.execute {
                drainRelayIdentityPublications(ticket.providerPeerId, gate)
            }
        } catch (t: Throwable) {
            synchronized(gate.lock) {
                gate.workerScheduled = false
                gate.pending?.completion?.completeExceptionally(t)
                gate.pending?.visibilityCompletion?.completeExceptionally(t)
            }
            relayIdentityPublicationGates.remove(ticket.providerPeerId, gate)
        }
    }

    private fun carryUnpublishedWithdrawalsLocked(
        gate: RelayIdentityPublicationGate,
        withdrawals: List<PreparedServiceWithdrawal>
    ) {
        val newer = gate.pending
        val newerEffects = newer?.advertisedServices.orEmpty() +
            newer?.withdrawals.orEmpty().map(::withdrawalServiceIdentifier)
        for (withdrawal in withdrawals) {
            val serviceIdentifier = withdrawalServiceIdentifier(withdrawal)
            if (serviceIdentifier !in newerEffects) {
                gate.carriedWithdrawals[serviceIdentifier] = withdrawal
            }
        }
    }

    private fun drainRelayIdentityPublications(
        providerPeerId: String,
        gate: RelayIdentityPublicationGate
    ) {
        while (true) {
            val work = synchronized(gate.lock) {
                val publication = gate.pending
                if (publication == null) {
                    gate.workerScheduled = false
                    null
                } else {
                    gate.pending = null
                    gate.active = publication
                    val withdrawalsByService = LinkedHashMap(gate.carriedWithdrawals)
                    gate.carriedWithdrawals.clear()
                    for (withdrawal in publication.withdrawals) {
                        withdrawalsByService[withdrawalServiceIdentifier(withdrawal)] = withdrawal
                    }
                    publication to withdrawalsByService.values.toList()
                }
            } ?: run {
                relayIdentityPublicationGates.computeIfPresent(providerPeerId) { _, current ->
                    if (current !== gate) current else synchronized(gate.lock) {
                        if (!gate.workerScheduled && gate.active == null && gate.pending == null &&
                            gate.carriedWithdrawals.isEmpty()
                        ) null else gate
                    }
                }
                return
            }

            val publication = work.first
            val requiredWithdrawals = work.second
            var nextWithdrawalIndex = 0
            val failedWithdrawals = mutableListOf<PreparedServiceWithdrawal>()
            var firstWithdrawalFailure: Throwable? = null
            try {
                relayIdentityPublicationStartTestSeam?.invoke()
                publication.publishRegistryReplacement()
                var callbackPredecessor = publication.scheduleRegistrationCallback()
                while (nextWithdrawalIndex < requiredWithdrawals.size) {
                    val withdrawal = requiredWithdrawals[nextWithdrawalIndex]
                    val attempt = publishPreparedServiceWithdrawalFromIdentityWorker(
                        withdrawal,
                        callbackPredecessor
                    )
                    callbackPredecessor = attempt.callbackCompletion
                    attempt.failure?.let { failure ->
                        // A closing or backpressured recipient must not suppress the remaining
                        // authoritative withdrawals for this provider. Retain only the failed
                        // withdrawal for a later identity generation and keep draining this one.
                        failedWithdrawals += withdrawal
                        if (firstWithdrawalFailure == null) firstWithdrawalFailure = failure
                    }
                    nextWithdrawalIndex++
                }
                if (failedWithdrawals.isNotEmpty()) {
                    synchronized(gate.lock) {
                        carryUnpublishedWithdrawalsLocked(gate, failedWithdrawals)
                    }
                }
                publication.publishBufferedMessages()
                val notificationCompletion = publication.scheduleNotifications()
                val visibility = if (publication.includeCallbacksInVisibility) {
                    CompletableFuture.allOf(callbackPredecessor, notificationCompletion)
                } else {
                    notificationCompletion
                }
                visibility.whenComplete { _, throwable ->
                    val failure = firstWithdrawalFailure ?: throwable
                    if (failure == null) {
                        publication.visibilityCompletion.complete(Unit)
                    } else {
                        publication.visibilityCompletion.completeExceptionally(failure)
                    }
                }
                firstWithdrawalFailure?.let(publication.completion::completeExceptionally)
                    ?: publication.completion.complete(Unit)
            } catch (t: Throwable) {
                synchronized(gate.lock) {
                    carryUnpublishedWithdrawalsLocked(
                        gate,
                        failedWithdrawals + requiredWithdrawals.drop(nextWithdrawalIndex)
                    )
                }
                publication.completion.completeExceptionally(t)
                publication.visibilityCompletion.completeExceptionally(t)
            } finally {
                synchronized(gate.lock) {
                    if (gate.active === publication) gate.active = null
                }
            }
        }
    }

    // Tracks the most recent ServiceWithdrawal timestamp per (serviceId, providerPeerId).
    // Used by [cacheServiceAnnouncement] to reject ServiceAnnouncements that are older than
    // a known withdrawal — closes a race where a delayed gossip rebroadcast of a stale
    // announcement (forwarded by another peer that received it before the withdrawal) arrives
    // at the relay AFTER [prepareServiceWithdrawalsForPeerWithProviderLock] has cleaned the cache.
    // Without this guard,
    // the late rebroadcast unconditionally re-populated [cachedServiceAnnouncements], leaving
    // a stale entry that the relay would replay to future late-joining peers.
    // Key: "$serviceIdentifier::$providerPeerId" — same scheme as
    // foundation.url.resolver.UrlResolver.withdrawnServices so different providers of the same
    // service can be tracked independently.
    // Access is serialized with cachedServiceAnnouncements so an announcement cannot observe a
    // tombstone decision separately from the replay payload/inventory mutation it protects.
    // A tombstone carries the provider-issued ordering timestamp plus a relay-local expiry
    // deadline. The two clock domains are never compared: provider time decides staleness, while
    // relay time decides only how long the decision must be retained against bounded gossip replay.
    private val cacheWithdrawalTimestamps = LinkedHashMap<String, CachedWithdrawalTimestamp>()
    private val withdrawalAdmissionFenceExpiresAtMsByProvider = LinkedHashMap<String, Long>()
    private var globalWithdrawalAdmissionFenceExpiresAtMs: Long? = null

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun relayServiceStateCatalogContainsLocked(
        key: RelayReceiveServiceStateKey,
    ): Boolean {
        val liveProvider = cachedServiceAnnouncements[key.serviceIdentifier]
            ?.message
            ?.providerPeerId
        return liveProvider == key.providerPeerId ||
            cacheWithdrawalTimestamps.containsKey(
                "${key.serviceIdentifier}::${key.providerPeerId}"
            )
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun forgetRelayReceiveWatermarkIfCatalogForgotLocked(
        key: RelayReceiveServiceStateKey,
    ) {
        if (!relayServiceStateCatalogContainsLocked(key)) {
            relayReceiveCallbacks.forgetProcessedServiceStateRecency(key)
        }
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun removeCachedServiceAnnouncementLocked(
        serviceIdentifier: String,
    ): CachedServiceAnnouncement? {
        val removed = cachedServiceAnnouncements.remove(serviceIdentifier) ?: return null
        forgetRelayReceiveWatermarkIfCatalogForgotLocked(
            RelayReceiveServiceStateKey(
                providerPeerId = removed.message.providerPeerId,
                serviceIdentifier = serviceIdentifier,
            )
        )
        return removed
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun removeCachedServiceAnnouncementsLocked(
        predicate: (String, CachedServiceAnnouncement) -> Boolean,
    ): Boolean {
        var removedAny = false
        val iterator = cachedServiceAnnouncements.entries.iterator()
        while (iterator.hasNext()) {
            val (serviceIdentifier, cached) = iterator.next()
            if (!predicate(serviceIdentifier, cached)) continue
            iterator.remove()
            removedAny = true
            forgetRelayReceiveWatermarkIfCatalogForgotLocked(
                RelayReceiveServiceStateKey(
                    providerPeerId = cached.message.providerPeerId,
                    serviceIdentifier = serviceIdentifier,
                )
            )
        }
        return removedAny
    }

    private fun applyRelayServiceStateInCatalogOrder(
        key: RelayReceiveServiceStateKey,
        recordCatalogState: () -> Unit,
        application: () -> Boolean,
        publishWatermark: () -> Unit,
    ): Boolean {
        val applied = application()
        if (!applied) return false
        synchronized(cachedServiceAnnouncementsLock) {
            pruneExpiredWithdrawalTimestampsLocked(clock.currentTimeMillis())
            recordCatalogState()
            if (relayServiceStateCatalogContainsLocked(key)) publishWatermark()
        }
        return true
    }

    private fun recordAppliedRelayReceiveServiceState(message: Any) {
        synchronized(cachedServiceAnnouncementsLock) {
            val now = clock.currentTimeMillis()
            when (message) {
                is GossipProtocol.ServiceAnnouncement -> {
                    val admission = ServiceAnnouncementSnapshot(message.toJson())
                    if (!announcementIsSuppressedByLifecycleLocked(
                            serviceIdentifier = message.serviceIdentifier,
                            providerPeerId = admission.providerPeerId,
                            announcementTimestamp = admission.timestamp,
                            now = now,
                        )
                    ) {
                        cacheServiceAnnouncementLocked(
                            serviceIdentifier = message.serviceIdentifier,
                            message = admission,
                            cachedAtMs = now,
                            ownerStreamGeneration = null,
                            ownerPeerId = null,
                        )
                    }
                    Unit
                }
                is GossipProtocol.ServiceWithdrawal -> recordWithdrawalReplayStateLocked(
                    serviceIdentifier = message.serviceIdentifier,
                    providerPeerId = message.providerPeerId,
                    timestamp = message.timestamp,
                )
                else -> Unit
            }
        }
    }

    // Client mode: our registration with a relay.
    // relayConnection and connectedRelayPeerId form one lifecycle state guarded by
    // raceLifecycleLock. They remain @Volatile because public properties and reconnect workers
    // read them without taking that lock.
    @Volatile
    private var relayConnection: RelayConnection? = null
    @Volatile
    private var requestHandler: ((RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse)? = null

    private data class RelayCatalogRevision(
        val revision: Long,
        val services: List<String>
    )

    private data class PendingRegistrationRefreshAck(
        val connection: RelayConnection,
        val services: List<String>,
        val acknowledgement: CompletableFuture<RelayProtocol.RelayRegisterAck>,
        val result: RelayRegistrationRefreshResult,
        val reportsFailure: Boolean,
    )

    // Desired state is advanced before a catalog-changing API inspects the connection or performs
    // I/O. Committed state records only revisions whose specific registration request was
    // acknowledged. Keeping both snapshots revisioned prevents an older ACK from making a newer
    // desired catalog look committed and gives every recovery path one authoritative send source.
    private val relayCatalogRevision = AtomicLong(0L)
    // Candidate commits also create transport catalog revisions. Keep public desired-state intent
    // separate so one candidate commit does not look like a newer caller decision to another
    // candidate that was prepared concurrently.
    private val desiredRelayCatalogIntentRevision = AtomicLong(0L)
    private val desiredRelayServices =
        AtomicReference(RelayCatalogRevision(revision = 0L, services = emptyList()))
    private val committedRelayServices =
        AtomicReference(RelayCatalogRevision(revision = 0L, services = emptyList()))

    // Store registration info for reconnection
    @Volatile
    private var registeredRelayPeerId: String? = null
    private val relayRegistrationIntentGeneration = AtomicLong(0L)
    private val relayRegistrationWireSequence = AtomicLong()
    private val pendingRegistrationRefreshAcks =
        ConcurrentHashMap<String, PendingRegistrationRefreshAck>()
    private val pendingUnregisterAcks =
        ConcurrentHashMap<String, CompletableFuture<RelayProtocol.RelayUnregisterAck>>()
    // Test-only hook invoked by the registered client-side close observer. It is consumed once so
    // a test can inject a deterministic observer failure without reaching into a raw stream
    // controller or relying on a transport race.
    private val relayCloseObserverTestHook = AtomicReference<(() -> Unit)?>(null)
    // Track the relay we're ACTUALLY connected to (only set after successful registration).
    // This is distinct from registeredRelayPeerId which is set at the START of registration
    // for reconnection purposes - even if registration fails.
    // @Volatile for the same reason as relayConnection.
    @Volatile
    private var connectedRelayPeerId: String? = null
    private var reconnectAttempts = 0
    // Exponential backoff: base delay doubles after each failure, capped at max
    private val baseReconnectDelayMs = 5000L      // Start with 5 seconds
    private val maxReconnectDelayMs = 600_000L    // Cap at 10 minutes
    private var currentReconnectDelayMs = baseReconnectDelayMs

    // After this many consecutive failures to the same relay, try an alternative
    private val maxSameRelayAttempts = 3
    private val sameRelayFailureState =
        AtomicReference(SameRelayFailureState(generation = 0L, failures = 0))

    // Callback to find alternative relays when the current one fails
    private var alternativeRelaySelector: (() -> PeerInfo?)? = null

    // Executor for background tasks
    private val executor = Executors.newScheduledThreadPool(2) { r ->
        Thread(r, "RelayService-worker").apply { isDaemon = true }
    }

    // Connection races must not run on CompletableFuture's unbounded common pool, nor on the
    // two-thread scheduled executor above: connectToRelay intentionally blocks its caller while its
    // Netty futures settle, so sharing those threads could starve keepalive/reconnect/routing work.
    // Four admitted races x two contenders gives a hard per-service bound of eight lazy daemon
    // workers and eight tracked futures; excess callers fail descriptively instead of growing an
    // unbounded queue. FutureTask (unlike CompletableFuture.cancel) honors cancel(true) by
    // interrupting the worker blocked in connectToRelay. This lock also serializes the closed-state
    // transition with installing and acknowledging a client relay connection, so close cannot miss
    // a late reconnect stream or let its identity commit after shutdown.
    private val maxInFlightRaceDials = 8
    private val raceDialExecutor = ThreadPoolExecutor(
        maxInFlightRaceDials,
        maxInFlightRaceDials,
        0L,
        TimeUnit.MILLISECONDS,
        SynchronousQueue(),
        ThreadFactory { r -> Thread(r, "RelayService-race-dial").apply { isDaemon = true } },
        ThreadPoolExecutor.AbortPolicy()
    )
    private val raceLifecycleLock = ReentrantLock()
    private val relayRegistrationSerialization = RelayRegistrationSerialization()
    private val inFlightRaceDials = mutableSetOf<Future<*>>()
    private val inlineDialFallbacks = AtomicLong(0L)

    /**
     * Runs [action] only while the expected acknowledged relay generation is still committed.
     *
     * This is a test scheduling seam. The callback holds the lifecycle lock that installs and
     * clears [relayConnection], [connectedRelayPeerId], and [relayConnectionGenerationOwner], so
     * a lifecycle clear or replacement cannot pass between the caller's observation and action.
     */
    internal fun withCommittedRelayRegistrationForTesting(
        expectedRelayPeerId: String,
        action: () -> Unit,
    ): Boolean = raceLifecycleLock.withLock {
        val expectedConnection = relayConnection ?: return@withLock false
        val expectedGenerationOwner =
            relayConnectionGenerationOwner.get() ?: return@withLock false
        if (closed.get() ||
            expectedConnection.isClosed() ||
            connectedRelayPeerId != expectedRelayPeerId ||
            expectedConnection.relayPeerId != expectedRelayPeerId
        ) {
            return@withLock false
        }

        action()

        !closed.get() &&
            !expectedConnection.isClosed() &&
            relayConnection === expectedConnection &&
            connectedRelayPeerId == expectedRelayPeerId &&
            relayConnectionGenerationOwner.get() === expectedGenerationOwner
    }

    /** Reports whether [thread] is waiting for the relay lifecycle lock in a test. */
    internal fun isRelayLifecycleThreadQueuedForTesting(thread: Thread): Boolean =
        raceLifecycleLock.hasQueuedThread(thread)

    /**
     * Scheduling seam for tests. Runs on the thread that just finished a bounded dial task, after
     * that task has been removed from [inFlightRaceDials] and before its worker can return to the
     * executor's hand-off queue. Nothing in production assigns it, so it costs one volatile read
     * per completed dial and changes no behaviour.
     *
     * It exists because that window is the only state in which the two hand-offs of a single race
     * can be decided differently — logical tracking already reports the slot free while the worker
     * is not yet available, so the direct dial is accepted and the relay dial is refused — and it is
     * a few hundred nanoseconds wide, far too narrow to reach from a test by concurrency alone.
     * Holding a worker here lets a test reproduce that split admission exactly, over the ordinary
     * public [sendViaRelay] path. The completed task is passed so a test can tell a cancellation
     * apart from a normal completion; note the seam also runs on a caller's own thread when a
     * cancel completes a task, so a test that blocks in it must let its own threads through.
     */
    @Volatile
    private var raceDialWorkerReleaseSeam: ((Future<*>) -> Unit)? = null

    /** Installs, or with `null` removes, the [raceDialWorkerReleaseSeam]. */
    internal fun installRaceDialWorkerReleaseSeam(seam: ((Future<*>) -> Unit)?) {
        raceDialWorkerReleaseSeam = seam
    }

    /**
     * Bounded dial-capacity diagnostics.
     *
     * [RelayDialCapacitySnapshot.inFlightDials] is how many of [RelayDialCapacitySnapshot.maxInFlightDials]
     * bounded dial tasks are currently running, and [RelayDialCapacitySnapshot.inlineDialFallbacks]
     * counts how often a request had to dial on its caller's own thread because none were free.
     * A persistently saturated pool is why relayed traffic between two peers that could reach each
     * other directly ends up on a third-party relay, so this is an operational signal, not just a
     * counter.
     */
    fun dialCapacity(): RelayDialCapacitySnapshot =
        RelayDialCapacitySnapshot(
            inFlightDials = raceLifecycleLock.withLock { inFlightRaceDials.size },
            maxInFlightDials = maxInFlightRaceDials,
            inlineDialFallbacks = inlineDialFallbacks.get()
        )

    // Candidate registration keeps network work off the RelayService monitor and away from the
    // keepalive/reconnect scheduler. A service admits at most sixteen live handles, with no more
    // than eight preparations executing at once. Teardown has its own bounded pool so a slow
    // stream close cannot occupy a preparation worker or the thread performing commit.
    private val maxRelayCandidateRegistrations = 16
    private val activeRelayCandidateCount = AtomicInteger(0)
    // Guarded by raceLifecycleLock so close observes one atomic admission/cleanup generation.
    private val activeRelayCandidates = mutableSetOf<RelayCandidateRegistration>()
    private val relayCandidateOwnerToken = Any()
    private val committedRelayCandidate =
        AtomicReference<RelayCandidateRegistration?>(null)
    private val relayRegistrationCoordinator = RelayRegistrationCoordinator()
    // This exact installation owner survives an unexpected connection clear. A later candidate
    // or ordinary registration replaces it, so delayed cleanup from an older same-relay candidate
    // cannot clear the newer generation by comparing only the shared relay peer ID.
    private val relayConnectionGenerationOwner = AtomicReference<Any?>(null)
    // Guarded by raceLifecycleLock. Unlike relayConnection, this registration-owned close
    // record survives listener detachment. There is only one retained registration record.
    private var relayRegistrationCloseState: RelayRegistrationCloseState? = null
    private val relayCandidatePreparationExecutor = ThreadPoolExecutor(
        8,
        8,
        0L,
        TimeUnit.MILLISECONDS,
        SynchronousQueue(),
        ThreadFactory { runnable ->
            Thread(runnable, "RelayService-candidate-prepare").apply { isDaemon = true }
        },
        ThreadPoolExecutor.AbortPolicy()
    )
    private val relayCandidateCleanupExecutor = ThreadPoolExecutor(
        4,
        4,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(maxRelayCandidateRegistrations),
        ThreadFactory { runnable ->
            Thread(runnable, "RelayService-candidate-cleanup").apply { isDaemon = true }
        },
        ThreadPoolExecutor.AbortPolicy()
    )

    // Track scheduled tasks for proper cleanup
    private var keepaliveTask: ScheduledFuture<*>? = null
    // These connection identities are guarded by taskLock. They let a stream-close callback stop
    // only the listener/keepalive tasks owned by the stream that actually closed; a stale close
    // notification must never detach a replacement generation's tasks.
    private var keepaliveConnection: RelayConnection? = null
    private var reconnectionTask: RelayReconnectTask? = null
    private var listenerThread: Thread? = null
    private var listenerStopSignal: AtomicBoolean? = null
    private var listenerConnection: RelayConnection? = null
    // Installation already holds taskLock; diagnostics add no new lock to the listener path.
    @Volatile private var registrationReaderDiagnostics: List<RelayRegistrationReaderDiagnostic> = emptyList()
    private val taskLock = ReentrantLock()

    // Each pending response belongs to the exact stream used to send it. Peer identity alone
    // cannot distinguish a retired registration from its replacement.
    private val pendingRequests = ConcurrentHashMap<String, PendingRelayRequest>()

    private fun registerPendingRelayRequest(
        requestId: String,
        target: RelayMessageSender,
        targetPeerId: String,
    ): PendingRelayRequest {
        val pending = PendingRelayRequest(target, targetPeerId)
        pendingRequests[requestId] = pending
        // Publish before checking terminal state: either the close sweep sees this entry, or
        // this check observes the close that already swept. No callback is retained on a stream.
        if (closed.get() || target.isClosed() ||
            target.relayDiagnosticStream()?.let(::streamAsChannel)?.isOpen == false
        ) {
            if (pendingRequests.remove(requestId, pending)) {
                pending.future.completeExceptionally(pendingRelayStreamClosed(requestId, pending))
            }
        }
        return pending
    }

    private fun failPendingRelayRequestsForClosedSender(sender: RelayMessageSender) {
        pendingRequests.forEach { (requestId, pending) ->
            if (pending.target.matchesStreamSender(sender) && pendingRequests.remove(requestId, pending)) {
                pending.future.completeExceptionally(pendingRelayStreamClosed(requestId, pending))
            }
        }
    }
    // One scalar diagnostic per existing forward or bounded queued reply; no completed history.
    private val forwardDiagnostics = ConcurrentHashMap.newKeySet<RelayForwardDiagnostic>()

    private fun createForwardDiagnostic(
        request: RelayProtocol.RelayRequest,
        forwardRequestId: String,
        source: RelayMessageSender,
        target: RelayMessageSender,
    ): RelayForwardDiagnostic {
        val diagnostic = RelayForwardDiagnostic(
            request.requestId, forwardRequestId, request.headers["resolverRpcRequestId"], request.sourcePeerId, request.targetPeerId,
            peerId, source, target, { forwardDiagnostics.remove(it) },
            request.headers[responseChunkFetchHeader], request.headers[responseChunkSeqHeader],
        )
        forwardDiagnostics.add(diagnostic)
        return diagnostic
    }

    internal fun detachForwardStreamClosed(
        sender: RelayMessageSender,
        observation: RelayStreamCloseObservation,
    ): RelayStreamRetirement {
        // Claim diagnostics before completing replies: their async forward completions must not
        // win diagnostic delivery and block before forwarding the terminal error to the caller.
        val reports = forwardDiagnostics.mapNotNull { it.prepareStreamClosed(sender, observation) }
        val replies = pendingRequests.entries.mapNotNull { (requestId, pending) ->
            if (pending.target.matchesStreamSender(sender) && pendingRequests.remove(requestId, pending)) {
                pending.future to pendingRelayStreamClosed(requestId, pending)
            } else null
        }
        return RelayStreamRetirement(replies, reports)
    }

    /**
     * Per-request timeout for forwarding to a directly registered peer. Replaces the
     * blocking `future.get(30, TimeUnit.SECONDS)` of the prior synchronous implementation
     * — see [forwardRequestToRegistered].
     */
    private val REGISTERED_FORWARD_TIMEOUT_MS: Long = 30_000L

    /**
     * Per-request timeout for forwarding via distance-vector routing (multi-hop).
     * Slightly longer than [REGISTERED_FORWARD_TIMEOUT_MS] because the request may need
     * to traverse additional hops.
     */
    private val ROUTED_FORWARD_TIMEOUT_MS: Long = 45_000L

    // Pending keepalive pings awaiting pong response - used to detect dead connections
    private val pendingPings = ConcurrentHashMap<String, CompletableFuture<RelayProtocol.RelayPong>>()

    // Track consecutive keepalive failures before marking connection dead.
    // This prevents marking a connection dead due to a single network hiccup.
    private val maxConsecutiveKeepaliveFailures = 2  // Require 2 failures before marking dead

    /**
     * Our peer ID from the libp2p host.
     */
    val peerId: String
        get() = host.peerId.toBase58()

    /**
     * Whether this service is currently acting as a relay.
     *
     * All UrlProtocol instances behave as relays by default, even if they
     * are not publicly reachable. NAT-ed nodes can still relay traffic
     * for peers they are connected to (through their existing connections).
     * There is no standalone relay service - relay is a built-in capability
     * of every node in the P2P network.
     */
    val isRelaying: Boolean
        get() = config.enableRelay

    /**
     * Whether this service has begun its permanent close transition.
     *
     * This becomes true before close waits for in-flight work or releases resources, and remains
     * true afterward. Callers can use it to stop submitting work once shutdown has started.
     */
    val isClosed: Boolean
        get() = closed.get()

    /**
     * Number of peers currently registered with this relay.
     */
    val registeredPeerCount: Int
        get() = registeredPeers.size

    /**
     * Whether we are currently registered with a relay.
     */
    val isRegisteredWithRelay: Boolean
        get() = relayConnection != null

    /**
     * The peer ID of the relay we're registered with, if any.
     * Returns null if the connection is currently lost.
     */
    val currentRelayPeerId: String?
        get() = relayConnection?.relayPeerId

    /**
     * The peer ID of the relay we're ACTUALLY connected to.
     * Returns null if registration has not yet succeeded.
     * This is used by broadcastGossipMessage to know if we can send via relay,
     * avoiding the case where we try to skip a relay peer that we're not connected to.
     */
    val targetRelayPeerId: String?
        get() = connectedRelayPeerId

    /**
     * Starts the relay service.
     */
    fun start() {
        if (!started.compareAndSet(false, true)) {
            return
        }
        effectHandlerRepositoryAtStart = `$effectHandlerRepository`.get()
        disconnectEffectContextAtStart = captureEffectHandlerContext()

        // Start cleanup task to remove expired registrations
        executor.scheduleAtFixedRate(
            ::cleanupExpiredRegistrations,
            config.registrationTimeoutMs,
            config.registrationTimeoutMs / 2,
            TimeUnit.MILLISECONDS
        )

        // Start periodic distance vector updates for routing
        executor.scheduleAtFixedRate(
            ::broadcastDistanceVector,
            DISTANCE_VECTOR_INTERVAL_MS,
            DISTANCE_VECTOR_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        )

        // Start periodic routing table pruning
        executor.scheduleAtFixedRate(
            { routingTable.pruneStaleRoutes() },
            ROUTING_PRUNE_INTERVAL_MS,
            ROUTING_PRUNE_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        )

        executor.scheduleAtFixedRate(
            { linkStateRoutingTable.expireStaleAdvertisements() },
            ROUTING_PRUNE_INTERVAL_MS,
            ROUTING_PRUNE_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        )

        executor.scheduleAtFixedRate(
            ::refreshLocalLinkStateAdvertisement,
            LINK_STATE_REFRESH_INTERVAL_MS,
            LINK_STATE_REFRESH_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        )

        // If we can relay, announce ourselves and then re-announce periodically. Re-announcing keeps
        // every node's view of available relays (knownRelays) fresh: a node only learns about a relay
        // by receiving that relay's announcement, and a node that joins/registers AFTER a relay's
        // one-shot announcement (typical for a NAT'd node, which receives gossip only through its own
        // relay) would otherwise never learn it. With periodic re-announcement the missed announcement
        // is delivered on the next round, so a NAT'd node always has an alternative relay to fail over
        // to if its own relay dies. announceAsRelay() self-guards on isRelaying/closed.
        if (isRelaying) {
            announceAsRelay()
            val interval = config.relayAnnounceIntervalMs
            if (interval > 0) {
                executor.scheduleAtFixedRate(
                    {
                        try {
                            announceAsRelay()
                        } catch (e: Exception) {
                            debugLog { "[RELAY] Periodic re-announce failed: ${e.message}" }
                        }
                    },
                    interval,
                    interval,
                    TimeUnit.MILLISECONDS
                )
            }
        }
    }

    /**
     * Broadcast distance vector updates to all neighbors.
     * Implements split horizon: routes learned from a neighbor are not advertised back.
     */
    private fun broadcastDistanceVector() {
        try {
            // Send to all registered peers (directly connected)
            for ((peerId, registered) in registeredPeers) {
                try {
                    val dv = routingTable.generateDistanceVector(excludeNeighbor = peerId)
                    registered.controller.sendMessage(dv.toJson())
                } catch (e: Exception) {
                    debugLog { "[ROUTING] Failed to send distance_vector to $peerId: ${e.message}" }
                }
            }

            // Also send to the relay we're registered with (if any)
            relayConnection?.let { conn ->
                try {
                    val dv = routingTable.generateDistanceVector(excludeNeighbor = conn.relayPeerId)
                    conn.sendMessage(dv.toJson())
                } catch (e: Exception) {
                    debugLog { "[ROUTING] Failed to send distance_vector to relay: ${e.message}" }
                }
            }

            debugLog { "[ROUTING] Broadcast distance_vector to ${registeredPeers.size} peers + relay" }
        } catch (e: Exception) {
            debugLog { "[ROUTING] Error broadcasting distance_vector: ${e.message}" }
        }
    }

    /**
     * Public snapshot of the SPF next-hop table. Intended for diagnostics and
     * tests; forwarding still falls back to distance-vector if this table has no route.
     */
    fun linkStateNextHopTable(): Map<String, String> = linkStateRoutingTable.nextHopTable()

    /**
     * Public forwarding counters keyed by the next hop used for relay forwarding.
     * This lets end-to-end tests verify that traffic took the SPF-selected hop.
     */
    fun linkStateForwardingCountsByNextHop(): Map<String, Int> {
        return linkStateForwardingCounts.mapValues { it.value.get() }.toSortedMap()
    }

    /**
     * Public relay-hop counters keyed by the next hop a relay forwarded to.
     * Endpoint-local direct sends over an already-registered peer stream do not
     * increment this; only [handleRelayRequest] forwarding does.
     */
    fun relayForwardingCountsByNextHop(): Map<String, Int> {
        return relayForwardingCounts.mapValues { it.value.get() }.toSortedMap()
    }

    /**
     * Bounded, non-atomic response progress for diagnosing stalled relay calls. Returns detached
     * text: up to 64 issued fetches, 64 outstanding fetch forwards, and the last four registration
     * readers. A truncated category has an explicit marker. Peer-supplied fields retain at most
     * 256 input characters and escape line breaks, backslashes and semicolons. Ages use this
     * service's Clock. No payload, admission decision, or transport operation is exposed.
     */
    fun relayResponseDiagnostics(): List<String> = buildList {
        val fetches = host.streams.asSequence().flatMap { stream ->
            val channel = streamAsChannel(stream)
            val entries = channel?.attr(relayResponseDiagnosticsKey)?.get()?.fetches ?: emptyList()
            entries.asSequence().map { entry ->
                val age = (clock.currentTimeMillis() - entry.issuedAtMs).coerceAtLeast(0L)
                "fetch ${entry.fields} ageMs=$age " +
                    "budget=${channel?.let(::libp2pRootConnectionChannel)?.id()?.asLongText() ?: "unknown"} " +
                    relayProgressStreamIdentity(stream)
            }
        }.take(65).toList()
        addAll(fetches.take(64).sorted())
        if (fetches.size > 64) add("fetch truncated after 64 entries")
        val forwards = forwardDiagnostics.asSequence().mapNotNull { diagnostic ->
            diagnostic.responseProgressSnapshot { registeredPeers[it]?.controller }
        }.take(65).toList()
        addAll(forwards.take(64).sorted())
        if (forwards.size > 64) add("forward truncated after 64 entries")
        val currentReader = relayConnection?.readerDiagnostic
        registrationReaderDiagnostics.forEach { reader ->
            add("reader ${reader.identity} current=${reader === currentReader} state=${reader.state}")
        }
    }

    fun relayWarningEffectsSnapshot(): List<RelayWarningEffect> = buildList {
        addAll(relayWarningEffects)
        latestRelayReceiveCallbackOverflow.get()?.let(::add)
        latestRelayReceiveCallbackFailure.get()?.snapshot()?.let(::add)
        latestRelayRequestTemporaryStorageCleanupFailure.get()?.let(::add)
        latestOrdinaryGossipDeliveryFailure.get()?.let(::add)
    }

    fun setDirectLinkCostForTesting(peerId: String, cost: Long) {
        require(peerId.isNotBlank()) {
            "Invalid direct link cost override: peerId must not be blank."
        }
        require(cost > 0) {
            "Invalid direct link cost override for peer '$peerId': cost was $cost, but link costs must be positive."
        }
        linkStateLinkCosts[peerId] = cost
        updateLocalLinkStateAdvertisement(force = true)
    }

    /**
     * Installs a link-state advertisement through the same acceptance rules used
     * by inbound gossip. Returns true only when the LSA was newer and accepted.
     */
    fun receiveLinkStateAdvertisement(advertisement: LinkStateAdvertisement): Boolean {
        val decision = linkStateRoutingTable.processAdvertisement(advertisement)
        if (decision.shouldReflood) {
            broadcastLinkStateAdvertisement(advertisement)
        }
        return decision.accepted
    }

    fun refreshLocalLinkStateAdvertisement() {
        val advertisement = linkStateRoutingTable.refreshLocalAdvertisement()
        broadcastLinkStateAdvertisement(advertisement)
    }

    private fun updateLocalLinkStateAdvertisement(force: Boolean = false) {
        val advertisement = linkStateRoutingTable.updateLocalLinks(
            force = force,
            linksSnapshot = ::currentDirectLinkStateLinks,
        ) ?: return
        broadcastLinkStateAdvertisement(advertisement)
    }

    private fun currentDirectLinkStateLinks(): List<LinkStateAdvertisement.Link> {
        val links = mutableMapOf<String, Long>()
        for ((peerId, registration) in registeredPeers) {
            if (!registration.controller.isClosed()) {
                links[peerId] = linkStateLinkCosts[peerId] ?: 1L
            }
        }
        relayConnection?.let { connection ->
            if (!connection.controller.isClosed()) {
                links[connection.relayPeerId] = linkStateLinkCosts[connection.relayPeerId] ?: 1L
            }
        }
        return links.entries
            .map { LinkStateAdvertisement.Link(it.key, it.value) }
            .sortedWith(compareBy<LinkStateAdvertisement.Link> { it.peerId }.thenBy { it.cost })
    }

    private fun broadcastLinkStateAdvertisement(
        advertisement: LinkStateAdvertisement,
        excludePeerId: String? = null
    ): Int {
        val prepared = PreparedRelayGossipMessage.from(advertisement.toJson())
        val deliveries = mutableListOf<Pair<String, (Long) -> Boolean>>()
        for ((peerId, registered) in registeredPeers) {
            if (peerId == excludePeerId) continue
            deliveries += peerId to { admissionWaitMs: Long ->
                registered.controller.trySendPreparedGossip(prepared, admissionWaitMs)
            }
        }
        relayConnection?.let { connection ->
            if (connection.relayPeerId != excludePeerId) {
                deliveries += "relay ${connection.relayPeerId}" to { admissionWaitMs: Long ->
                    connection.controller.trySendPreparedGossip(prepared, admissionWaitMs)
                }
            }
        }
        return deliverLinkStateAdvertisement(advertisement, deliveries)
    }

    /**
     * Offers [advertisement] to every destination inside ONE shared
     * [WRITE_BACKPRESSURE_WAIT_MS] transport-admission budget, on the calling thread.
     *
     * Link-state advertisements are authoritative topology state, not best-effort gossip, so the
     * existing synchronous completion boundary is preserved: the caller does not proceed until every
     * recipient has had its ordered transport-admission attempt. Serially charging the caller one
     * full [WRITE_BACKPRESSURE_WAIT_MS] wait per unwritable peer would make one re-flood O(peer
     * count), so each round offers the frame to every still-pending destination with the
     * non-blocking (zero-wait) admission probe and then polls once for all of them. A destination
     * whose connection recovers at any point inside the shared budget is still delivered to, and one
     * stalled destination neither denies nor delays delivery to a healthy one.
     *
     * This is deliberately not equivalent to the per-destination wait it replaces. Under that
     * scheme every recipient started its own [WRITE_BACKPRESSURE_WAIT_MS] clock, so a destination
     * that recovered late - after this shared budget has expired, but inside the window its own
     * clock would still have allowed - used to be delivered to and is now dropped. That is the
     * intended trade: the whole fan-out costs one bounded wait instead of one per recipient, so a
     * re-flood's cost stops growing with peer count, and topology state a peer misses is
     * re-originated before expiry anyway.
     *
     * **Why this runs on the calling thread.** An earlier revision dispatched each destination to a
     * virtual thread and awaited the resulting futures with no deadline. That made a caller-visible
     * completion depend on the JVM-wide virtual-thread scheduler: a virtual thread blocked entering a
     * contended `synchronized` block occupies its carrier and is never compensated for, so once
     * `availableProcessors()` virtual threads anywhere in the process are in that state, no fan-out
     * task is ever scheduled and the caller blocks indefinitely — regardless of this budget. Owning
     * the wait here keeps the advertisement's cost bounded by the transport budget alone.
     */
    private fun deliverLinkStateAdvertisement(
        advertisement: LinkStateAdvertisement,
        deliveries: List<Pair<String, (Long) -> Boolean>>
    ): Int {
        if (deliveries.isEmpty()) return 0
        // A closing relay does not spend a transport-backpressure interval re-flooding topology it is
        // about to stop serving; its shutdown must not wait on peers that have stopped reading. The
        // previous fan-out got this only as a side effect of its executor being shut down, which made
        // every remaining destination fail scheduling instead.
        if (closed.get()) {
            debugLog {
                "[LINK-STATE] Skipping LSA fan-out from ${advertisement.originPeerId} to " +
                    "${deliveries.size} destination(s) because this RelayService is closing"
            }
            return 0
        }
        // One absolute budget on the monotonic clock covers the whole fan-out, so a late destination
        // cannot restart the wait that an earlier one already spent.
        val startedAtNanos = System.nanoTime()
        val budgetNanos = TimeUnit.MILLISECONDS.toNanos(WRITE_BACKPRESSURE_WAIT_MS)
        var pending = deliveries
        var delivered = 0
        while (true) {
            val stillPending = mutableListOf<Pair<String, (Long) -> Boolean>>()
            for (destinationAttempt in pending) {
                val (destination, attempt) = destinationAttempt
                val admitted = try {
                    attempt(0L)
                } catch (failure: Exception) {
                    debugLog {
                        "[LINK-STATE] Failed to send LSA from " +
                            "${advertisement.originPeerId} to $destination: ${failure.message}"
                    }
                    // The destination itself rejected the frame; retrying it inside this budget
                    // cannot change that, so it is not offered again.
                    continue
                }
                if (admitted) delivered++ else stillPending += destinationAttempt
            }
            pending = stillPending
            if (pending.isEmpty()) break
            if (System.nanoTime() - startedAtNanos >= budgetNanos) break
            try {
                Thread.sleep(WRITE_BACKPRESSURE_POLL_MS)
            } catch (interruption: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            }
        }
        for ((destination, _) in pending) {
            debugLog {
                "[LINK-STATE] Failed to send LSA from ${advertisement.originPeerId} " +
                    "to $destination: ${relayMessageNotAdmittedMessage(WRITE_BACKPRESSURE_WAIT_MS)}"
            }
        }
        return delivered
    }

    private fun processLinkStateAdvertisement(
        advertisement: LinkStateAdvertisement,
        senderPeerId: String?
    ) {
        val decision = linkStateRoutingTable.processAdvertisement(advertisement)
        if (decision.shouldReflood) {
            broadcastLinkStateAdvertisement(advertisement, excludePeerId = senderPeerId)
        }
    }

    private fun recordRelayForwarding(nextHopPeerId: String) {
        relayForwardingCounts.computeIfAbsent(nextHopPeerId) { AtomicInteger(0) }.incrementAndGet()
    }

    companion object {
        /**
         * How many relayed requests this peer may have in its registered request handler at once.
         *
         * Admissions cover executing handlers plus completed replies not yet charged to the outbox.
         * Charged replies have already returned their slots, even before writing. The reader never
         * waits at this bound: a request that arrives while every slot is taken is refused at once
         * with a not-dispatched error naming the limit and the current count, and the connection
         * keeps reading. Failure-reservation admission is non-waiting too; exhaustion refuses
         * without dispatch. Refusals have their own bounded byte allowance; exhaustion closes
         * the registration instead of waiting. Handlers run on virtual threads, so an in-flight request costs a stack
         * rather than an operating-system thread; the bound is sized for services that hold
         * requests open (long-polls) rather than only for short calls.
         */
        const val MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS = 64

        /** Interval for sending distance vector updates */
        const val DISTANCE_VECTOR_INTERVAL_MS = 30_000L  // 30 seconds

        /** Interval for pruning stale routes */
        const val ROUTING_PRUNE_INTERVAL_MS = 60_000L  // 1 minute

        /** Re-origin local LSAs well before their TTL so steady topologies stay routable. */
        const val LINK_STATE_REFRESH_INTERVAL_MS = LinkStateAdvertisement.DEFAULT_LSA_TTL_MS / 3

        /**
         * Maximum age of a cached ServiceAnnouncement (by relay-local receipt time) that
         * [handleRegister] will replay to a newly-registered peer when the announcement's
         * provider does NOT hold a live (unexpired) relay registration. Matches the
         * 5-minute peer-verification window used by the downstream resolver's vouching
         * gates so the relay layer and the gossip layer agree on what "recent enough to
         * re-vouch" means. Announcements older than this from unregistered/expired
         * providers are the signature of a provider that crashed without a withdrawal —
         * replaying them hands a dead service to every late joiner.
         */
        const val CACHED_ANNOUNCEMENT_REPLAY_MAX_AGE_MS = 5 * 60 * 1000L

        /**
         * Maximum number of distinct services retained for late-join replay.
         *
         * This matches [PeerRegistry.MAX_REGISTRY_PEERS], the existing bound on the relay's
         * discoverable peer population. Retaining more full JSON announcements than that made a
         * relay's heap proportional to attacker-controlled unique service identifiers, while also
         * making every new registration replay an unbounded batch. The oldest distinct service is
         * evicted; refreshing the same identifier still replaces its cached value and moves it to
         * the newest position, preserving the deduplication contract callers already rely on.
         */
        private const val MAX_CACHED_SERVICE_ANNOUNCEMENTS = PeerRegistry.MAX_REGISTRY_PEERS

        /** Maximum interval for suppressing semantically unchanged service announcements. */
        private const val MAX_UNCHANGED_ANNOUNCEMENT_SUPPRESSION_MS = 60_000L

        /** Maximum compact service identifiers retained by one live relay registration. */
        private const val MAX_SERVICES_PER_LIVE_PROVIDER = PeerRegistry.MAX_REGISTRY_PEERS

        /**
         * Maximum individual withdrawal decisions retained by the relay.
         *
         * Relayed gossip can name providers outside this relay's registry, so registry cardinality
         * is not a valid bound on live tombstones. Expired entries are pruned by relay-local TTL.
         * If unexpired entries fill this hard bound, the provider whose withdrawal could not be
         * admitted receives a provider-scoped admission fence until that same TTL elapses. Fence
         * deadlines are non-renewable and use a fixed TTL, so insertion order is expiry order and
         * expired entries can be pruned from the map head in O(1) amortized time. Provider fences
         * are capped at the registry bound; if all slots are live, one global fail-closed fence is
         * activated only until the earliest provider-fence deadline instead of retaining a new ID.
         */
        private const val MAX_CACHED_WITHDRAWAL_TIMESTAMPS = MAX_CACHED_SERVICE_ANNOUNCEMENTS

        /** Maximum attacker-controlled provider IDs retained by withdrawal admission fences. */
        private const val MAX_WITHDRAWAL_ADMISSION_FENCES = PeerRegistry.MAX_REGISTRY_PEERS

        /** Maximum disconnected provider generations retained through reconnect grace. */
        private const val MAX_DISCONNECTED_PROVIDER_TOMBSTONES = PeerRegistry.MAX_REGISTRY_PEERS

        /** Fixed, bounded serialization domain for per-provider lifecycle commits. */
        private const val PROVIDER_LIFECYCLE_LOCK_STRIPES = 256
    }

    /**
     * Announces this peer as a relay via gossip protocol.
     * Call this to advertise relay availability to the network.
     */
    fun announceAsRelay() {
        // A node that does not accept relay registrations must not advertise itself as a relay:
        // otherwise it pollutes every other node's relay view (knownRelays) with an entry that
        // rejects registrations, so peers waste failover attempts on it. This guard makes the
        // announcement consistent with handleRegister (which rejects when !enableRelay) and covers
        // BOTH callers — RelayService.start() (already guarded) and UrlProtocol2.joinNetwork (which
        // calls announceAsRelay() unconditionally).
        if (!isRelaying) return
        if (closed.get()) return
        // Use effective addresses which properly substitute PUBLIC_IP for wildcard addresses
        val effectiveAddrs = PublicAddressDiscovery.getEffectiveAddresses(host.listenAddresses(), peerId)
        val announcement = RelayProtocol.RelayAnnouncement(
            messageId = RelayProtocol.nextMessageId(),
            peerId = peerId,
            multiaddresses = effectiveAddrs,
            maxClients = config.maxClients,
            currentClients = registeredPeers.size
        )

        // Broadcast via gossip (handled by UrlProtocol)
        gossipHandler?.let { handler ->
            // The handler will propagate the relay announcement
            broadcastRelayAnnouncement(announcement)
        }
    }

    /**
     * Broadcasts a relay announcement to all connected peers via gossip protocol.
     */
    private fun broadcastRelayAnnouncement(announcement: RelayProtocol.RelayAnnouncement) {
        val handler = gossipHandler ?: return
        val count = handler.broadcastGossipMessage(announcement.toJson())
        debugLog { "[RELAY] Broadcast relay announcement to $count peers: ${announcement.peerId}" }
    }

    /**
     * Forwards a gossip message to all relay-registered peers through their existing connections.
     *
     * This is essential for gossip propagation to NAT'd peers: since they connected to us
     * (via relay registration), we can't reach them via direct connections. But we CAN
     * send messages through their existing relay connection.
     *
     * @param message The gossip message to forward
     * @param excludePeerId Optional peer ID to exclude from forwarding (usually the sender)
     * @return The number of peers whose bounded delivery lane accepted the message
     */
    fun forwardGossipToRegisteredPeers(message: JSONObject, excludePeerId: String? = null): Int {
        var count = 0
        val acceptedMessage = relayGossipMessageWithoutNestedCircuitAddresses(
            message,
            "before relay gossip fan-out",
        ) ?: return 0
        // An excluded destination has no lane in this fan-out. Ordinary broadcasts usually keep
        // the target already set by registration changes; only eligibility changes resize it here.
        withOrdinaryRelayGossipWorkerSizing(
            registeredPeers, ordinaryRelayGossipExecutor, excludePeerId
        ) {}
        val messageType = acceptedMessage.optString("type", "unknown")
        var preparedMessage: PreparedRelayGossipMessage? = null
        for ((peerId, reg) in registeredPeers) {
            // Skip the excluded peer (usually the sender to avoid echoing back)
            if (peerId == excludePeerId) continue
            try {
                // Ordinary gossip is best-effort, but best-effort cannot mean that the stream
                // handler waits once per stalled transport or that a momentarily-full queue drops
                // a healthy peer's registration snapshot. Each registration owns a bounded serial
                // outbox; the shared executor services one item per peer per turn for fairness.
                // Authoritative withdrawals retain their separate synchronous visibility gate.
                val prepared = preparedMessage ?: PreparedRelayGossipMessage.from(acceptedMessage).also {
                    preparedMessage = it
                }
                if (reg.ordinaryGossipOutbox.offer(prepared)) {
                    debugLog { "[RELAY] Queued $messageType for registered peer $peerId" }
                    count++
                } else {
                    debugLog { "[RELAY] Shed $messageType for saturated registered peer $peerId" }
                }
            } catch (e: Exception) {
                debugLog { "[RELAY] Failed to forward gossip to registered peer $peerId: ${e.message}" }
            }
        }
        return count
    }

    private fun relayGossipMessageWithoutNestedCircuitAddresses(
        message: JSONObject,
        acceptanceContext: String,
    ): JSONObject? = when (message.optString("type")) {
        GossipProtocol.TYPE_SERVICE_ANNOUNCE -> {
            val announcement = GossipProtocol.ServiceAnnouncement.fromJson(message)
            val acceptedAddresses = filterNestedCircuitPeerMultiaddresses(
                announcement.providerPeerId,
                announcement.providerMultiaddresses,
                acceptanceContext,
            )
            // A service announcement is one provider assertion. Match resolver receipt semantics:
            // if any address is malformed, drop the assertion instead of publishing a partial copy.
            if (acceptedAddresses.size == announcement.providerMultiaddresses.size) message else null
        }
        GossipProtocol.TYPE_PEER_ANNOUNCE -> {
            val announcement = GossipProtocol.PeerAnnouncement.fromJson(message)
            val acceptedAddresses = filterNestedCircuitPeerMultiaddresses(
                announcement.peerId,
                announcement.multiaddresses,
                acceptanceContext,
            )
            if (acceptedAddresses.isEmpty() && announcement.multiaddresses.isNotEmpty()) null
            else if (acceptedAddresses == announcement.multiaddresses) message
            else announcement.copy(multiaddresses = acceptedAddresses).toJson()
        }
        RelayProtocol.TYPE_RELAY_ANNOUNCE -> {
            val announcement = RelayProtocol.RelayAnnouncement.fromJson(message)
            val acceptedAddresses = filterNestedCircuitPeerMultiaddresses(
                announcement.peerId,
                announcement.multiaddresses,
                acceptanceContext,
            )
            if (acceptedAddresses.isEmpty() && announcement.multiaddresses.isNotEmpty()) null
            else if (acceptedAddresses == announcement.multiaddresses) message
            else announcement.copy(multiaddresses = acceptedAddresses).toJson()
        }
        else -> message
    }

    private fun gossipIngressMetadata(senderPeerId: String): GossipIngressMetadata =
        GossipIngressMetadata(
            senderPeerId = senderPeerId,
            ingressRelayPeerId = peerId,
            registeredClientFanoutOwnedByRelay = true
        )

    private fun notifyServiceAnnouncementFromRegisteredClient(
        announcement: GossipProtocol.ServiceAnnouncement,
        senderPeerId: String
    ) {
        val handler = gossipHandler ?: return
        val ingress = gossipIngressMetadata(senderPeerId)
        if (handler is RelayIngressGossipHandler) {
            handler.onServiceAnnouncement(announcement, ingress)
        } else {
            handler.onServiceAnnouncement(announcement)
        }
    }

    private fun notifyPeerAnnouncementFromRegisteredClient(
        announcement: GossipProtocol.PeerAnnouncement,
        senderPeerId: String
    ) {
        val handler = gossipHandler ?: return
        val ingress = gossipIngressMetadata(senderPeerId)
        if (handler is RelayIngressGossipHandler) {
            handler.onPeerAnnouncement(announcement, ingress)
        } else {
            handler.onPeerAnnouncement(announcement)
        }
    }

    private fun notifyTldResolverAnnouncementFromRegisteredClient(
        announcement: GossipProtocol.TldResolverAnnouncement,
        senderPeerId: String
    ) {
        val handler = gossipHandler ?: return
        val ingress = gossipIngressMetadata(senderPeerId)
        if (handler is RelayIngressGossipHandler) {
            handler.onTldResolverAnnouncement(announcement, ingress)
        } else {
            handler.onTldResolverAnnouncement(announcement)
        }
    }

    private fun notifyServiceWithdrawalWithRelayFanoutOwnership(
        withdrawal: GossipProtocol.ServiceWithdrawal,
        senderPeerId: String
    ) {
        val handler = gossipHandler ?: return
        val ingress = gossipIngressMetadata(senderPeerId)
        if (handler is RelayIngressGossipHandler) {
            handler.onServiceWithdrawal(withdrawal, ingress)
        } else {
            handler.onServiceWithdrawal(withdrawal)
        }
    }

    /**
     * Delivers an authoritative service withdrawal to every currently registered observer.
     *
     * Ordinary gossip is deliberately best-effort and may shed after 200 ms of transport
     * backpressure. A withdrawal is different: silently dropping it leaves observers routing to a
     * provider that no longer exists. First attempt zero-wait admission for every observer so a
     * currently-writable peer can never sit behind a stalled one. Then share one bounded delivery
     * budget across the remaining backpressured peers and surface any combined failure so the
     * identity publication gate retains the withdrawal for a later retry. The shared deadline keeps
     * one withdrawal bounded even when every slot in a full relay is stalled.
     */
    private fun forwardAuthoritativeWithdrawalToRegisteredPeers(
        withdrawal: GossipProtocol.ServiceWithdrawal,
        excludePeerId: String? = null
    ): Int {
        val observers = registeredPeers.entries
            .filter { (peerId, _) -> peerId != excludePeerId }
        val deferred = mutableListOf<Map.Entry<String, RegisteredPeer>>()
        val failures = mutableListOf<Pair<String, Exception>>()
        val message = withdrawal.toJson()
        var count = 0

        for (observer in observers) {
            val peerId = observer.key
            try {
                if (observer.value.controller.trySendMessage(message, 0L)) {
                    debugLog {
                        "[RELAY] Immediately delivered authoritative withdrawal for " +
                            "${withdrawal.serviceIdentifier} to peer $peerId"
                    }
                    count++
                } else {
                    deferred += observer
                }
            } catch (failure: Exception) {
                failures += peerId to failure
                debugLog {
                    "[RELAY] Failed immediate authoritative withdrawal delivery for " +
                        "${withdrawal.serviceIdentifier} to peer $peerId: ${failure.message}"
                }
            }
        }

        val deliveryDeadlineMs = clock.currentTimeMillis() + WRITE_BACKPRESSURE_DELIVERY_WAIT_MS
        for ((peerId, registration) in deferred) {
            try {
                val remainingBudgetMs =
                    (deliveryDeadlineMs - clock.currentTimeMillis()).coerceAtLeast(0L)
                if (registration.controller.trySendMessage(message, remainingBudgetMs)) {
                    debugLog {
                        "[RELAY] Delivered authoritative withdrawal after bounded backpressure " +
                            "wait for ${withdrawal.serviceIdentifier} to peer $peerId"
                    }
                    count++
                } else {
                    failures += peerId to RelayException(
                        "Relay stream remained unwritable within the shared " +
                            "${WRITE_BACKPRESSURE_DELIVERY_WAIT_MS}ms authoritative-withdrawal " +
                            "delivery budget"
                    )
                }
            } catch (failure: Exception) {
                failures += peerId to failure
                debugLog {
                    "[RELAY] Failed awaited authoritative withdrawal delivery for " +
                        "${withdrawal.serviceIdentifier} to peer $peerId: ${failure.message}"
                }
            }
        }
        if (failures.isNotEmpty()) {
            val first = failures.first()
            val deliveryFailure = RelayException(
                "Failed to deliver authoritative withdrawal for service " +
                    "${withdrawal.serviceIdentifier} to ${failures.size} registered peer(s); " +
                    "first failed peer ${first.first}: ${first.second.message}",
                first.second
            )
            failures.drop(1).forEach { (peerId, failure) ->
                deliveryFailure.addSuppressed(
                    RelayException("Authoritative withdrawal delivery failed for peer $peerId", failure)
                )
            }
            throw deliveryFailure
        }
        return count
    }

    /**
     * Caches a ServiceAnnouncement for later replay to late-joining peers.
     *
     * This should be called by the gossip handler whenever a ServiceAnnouncement
     * is received from ANY source (not just through the relay stream). This ensures
     * that the relay cache is populated regardless of whether the announcement
     * arrived via direct gossip or through the relay connection.
     *
     * When a new peer registers with the relay, all cached announcements are
     * replayed through the relay connection for reliable delivery. Admission rejects a strictly
     * older timestamp for the same retained service/provider, whether or not that provider is
     * registered here. A recorded withdrawal also rejects equal timestamps.
     *
     * Admission owns a detached snapshot; later mutations of [message] cannot change ordering or
     * replay. Application handlers run after every caller has released the relay's provider,
     * registration, inventory and cache locks.
     *
     * This call may synchronously notify an inventory-eviction withdrawal. Callers must release
     * application locks that their withdrawal handler may acquire before calling this method.
     */
    fun cacheServiceAnnouncement(serviceIdentifier: String, message: JSONObject) {
        cacheServiceAnnouncementIfAccepted(serviceIdentifier, message)
    }

    /**
     * Atomically validates a provider registration, records its per-service lifecycle timestamp,
     * and updates replay state. The public wrapper preserves the existing Unit-returning API while
     * the relay stream path uses the Boolean result to suppress publication of rejected messages.
     * Callers must hold no provider or lifecycle lock: this helper publishes evictions after its
     * own transaction releases those locks.
     */
    private fun cacheServiceAnnouncementIfAccepted(
        serviceIdentifier: String,
        message: JSONObject,
        ownerStreamGeneration: Long? = null,
        ownerPeerId: String? = null
    ): Boolean {
        // Relay-disabled instances still deliver/process gossip; only replay caching is disabled.
        if (!config.enableRelay) return true
        val admission = ServiceAnnouncementSnapshot(message)
        val providerPeerId = admission.providerPeerId
        val announcementTimestamp = admission.timestamp
        var displacedService: ProviderServiceLifecycle? = null
        val result = synchronized(providerLifecycleLock(providerPeerId)) {
            val providerRegistration = registeredPeers[providerPeerId]
            if (providerRegistration == null && providerPeerId in disconnectedProviderPeerIds) {
                ProviderServiceRecordResult.RejectedDisconnected
            } else if (providerRegistration == null) {
                synchronized(cachedServiceAnnouncementsLock) {
                    val lockedNow = clock.currentTimeMillis()
                    if (announcementIsSuppressedByLifecycleLocked(
                            serviceIdentifier,
                            providerPeerId,
                            announcementTimestamp,
                            lockedNow
                    )) {
                        ProviderServiceRecordResult.RejectedStale
                    } else {
                        cacheServiceAnnouncementLocked(
                            serviceIdentifier,
                            admission,
                            lockedNow,
                            ownerStreamGeneration,
                            ownerPeerId
                        )
                        ProviderServiceRecordResult.Accepted(null)
                    }
                }
            } else providerRegistration.serviceInventory.withStateLock {
                val lockedNow = clock.currentTimeMillis()
                if (!providerRegistration.serviceInventory.isLiveLocked(lockedNow)) {
                    ProviderServiceRecordResult.RejectedExpired
                } else {
                    synchronized(cachedServiceAnnouncementsLock) {
                        if (announcementIsSuppressedByLifecycleLocked(
                                serviceIdentifier,
                                providerPeerId,
                                announcementTimestamp,
                                lockedNow
                            )) {
                            ProviderServiceRecordResult.RejectedStale
                        } else {
                            val recorded = providerRegistration.serviceInventory.recordLocked(
                                serviceIdentifier,
                                announcementTimestamp
                            )
                            if (recorded is ProviderServiceRecordResult.Accepted) {
                                displacedService = recorded.displaced
                                cacheServiceAnnouncementLocked(
                                    serviceIdentifier,
                                    admission,
                                    lockedNow,
                                    ownerStreamGeneration,
                                    ownerPeerId
                                )
                            }
                            recorded
                        }
                    }
                }
            }
        }
        if (result !is ProviderServiceRecordResult.Accepted) {
            debugLog {
                "[RELAY] Rejecting service announcement '$serviceIdentifier' from " +
                    "${providerPeerId.takeLast(8)} because registration/inventory state was $result"
            }
            return false
        }

        displacedService?.let { displaced ->
            broadcastServiceWithdrawal(
                displaced.serviceIdentifier,
                providerPeerId,
                minimumTimestamp = lifecycleTimestampAfter(displaced.timestamp)
            )
        }
        return true
    }

    /**
     * Caller must hold [cachedServiceAnnouncementsLock] through admission and cache mutation.
     * Public admission and relay-receive catalog application use the same retained timestamps.
     */
    private fun announcementIsSuppressedByLifecycleLocked(
        serviceIdentifier: String,
        providerPeerId: String,
        announcementTimestamp: Long,
        now: Long
    ): Boolean {
        if (announcementIsSuppressedByWithdrawalLocked(
                serviceIdentifier, providerPeerId, announcementTimestamp, now
            )) return true
        val cached = cachedServiceAnnouncements[serviceIdentifier]?.message ?: return false
        return providerPeerId.isNotEmpty() &&
            cached.providerPeerId == providerPeerId &&
            announcementTimestamp < cached.timestamp
    }

    private fun announcementIsSuppressedByWithdrawalLocked(
        serviceIdentifier: String,
        providerPeerId: String,
        announcementTimestamp: Long,
        now: Long
    ): Boolean {
        if (providerPeerId.isEmpty()) return false
        pruneExpiredWithdrawalTimestampsLocked(now)
        val globalFenceExpiresAtMs = globalWithdrawalAdmissionFenceExpiresAtMs
        if (globalFenceExpiresAtMs != null && globalFenceExpiresAtMs >= now) {
            debugLog {
                "[RELAY] Rejecting service announcement '$serviceIdentifier' from " +
                    "${providerPeerId.takeLast(8)} while the bounded withdrawal cache is " +
                    "globally fail-closed until $globalFenceExpiresAtMs"
            }
            return true
        }
        val fenceExpiresAtMs = withdrawalAdmissionFenceExpiresAtMsByProvider[providerPeerId]
        if (fenceExpiresAtMs != null && fenceExpiresAtMs >= now) {
            debugLog {
                "[RELAY] Rejecting service announcement '$serviceIdentifier' from " +
                    "${providerPeerId.takeLast(8)} while the bounded withdrawal cache is " +
                    "fail-closed for that provider until $fenceExpiresAtMs"
            }
            return true
        }
        val recordedWithdrawalTs = cacheWithdrawalTimestamps["$serviceIdentifier::$providerPeerId"]
            ?.providerTimestamp
        if (recordedWithdrawalTs == null ||
            !withdrawalDefeatsAnnouncement(announcementTimestamp, recordedWithdrawalTs)
        ) return false
        debugLog {
            "[RELAY] Rejecting stale cache write for '$serviceIdentifier' from " +
                "${providerPeerId.takeLast(8)} — announcement ts=$announcementTimestamp " +
                "<= recorded withdrawal ts=$recordedWithdrawalTs"
        }
        return true
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun pruneExpiredWithdrawalTimestampsLocked(now: Long) {
        val withdrawalIterator = cacheWithdrawalTimestamps.entries.iterator()
        while (withdrawalIterator.hasNext()) {
            val cached = withdrawalIterator.next().value
            if (cached.expiresAtMs >= now) continue
            withdrawalIterator.remove()
            forgetRelayReceiveWatermarkIfCatalogForgotLocked(
                RelayReceiveServiceStateKey(
                    providerPeerId = cached.providerPeerId,
                    serviceIdentifier = cached.serviceIdentifier,
                )
            )
        }
        val fenceIterator = withdrawalAdmissionFenceExpiresAtMsByProvider.entries.iterator()
        while (fenceIterator.hasNext()) {
            val (_, expiresAtMs) = fenceIterator.next()
            if (expiresAtMs >= now) break
            fenceIterator.remove()
        }
        if (globalWithdrawalAdmissionFenceExpiresAtMs?.let { it < now } == true) {
            globalWithdrawalAdmissionFenceExpiresAtMs = null
        }
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock] after expiry pruning. */
    private fun recordWithdrawalAdmissionFenceLocked(
        providerPeerId: String,
        expiresAtMs: Long,
        now: Long
    ) {
        if (globalWithdrawalAdmissionFenceExpiresAtMs?.let { it >= now } == true) return
        if (withdrawalAdmissionFenceExpiresAtMsByProvider.containsKey(providerPeerId)) return
        if (withdrawalAdmissionFenceExpiresAtMsByProvider.size < MAX_WITHDRAWAL_ADMISSION_FENCES) {
            withdrawalAdmissionFenceExpiresAtMsByProvider[providerPeerId] = expiresAtMs
            return
        }

        globalWithdrawalAdmissionFenceExpiresAtMs =
            withdrawalAdmissionFenceExpiresAtMsByProvider.entries.first().value
    }

    private fun cacheServiceAnnouncementLocked(
        serviceIdentifier: String,
        message: ServiceAnnouncementSnapshot,
        cachedAtMs: Long,
        ownerStreamGeneration: Long?,
        ownerPeerId: String?
    ) {
        // LinkedHashMap does not change insertion order when replacing in place. Remove first so
        // a genuine refresh remains newest for deterministic oldest-first eviction.
        val replaced = cachedServiceAnnouncements.remove(serviceIdentifier)
        cachedServiceAnnouncements[serviceIdentifier] = CachedServiceAnnouncement(
            message,
            cachedAtMs,
            ownerStreamGeneration,
            ownerPeerId
        )
        if (replaced != null) {
            forgetRelayReceiveWatermarkIfCatalogForgotLocked(
                RelayReceiveServiceStateKey(
                    providerPeerId = replaced.message.providerPeerId,
                    serviceIdentifier = serviceIdentifier,
                )
            )
        }
        if (cachedServiceAnnouncements.size > MAX_CACHED_SERVICE_ANNOUNCEMENTS) {
            val oldest = cachedServiceAnnouncements.entries.iterator()
            if (oldest.hasNext()) {
                val (oldestServiceIdentifier, oldestCached) = oldest.next()
                oldest.remove()
                forgetRelayReceiveWatermarkIfCatalogForgotLocked(
                    RelayReceiveServiceStateKey(
                        providerPeerId = oldestCached.message.providerPeerId,
                        serviceIdentifier = oldestServiceIdentifier,
                    )
                )
            }
        }
    }

    private fun shouldFanOutServiceAnnouncement(
        announcement: GossipProtocol.ServiceAnnouncement,
        originPeerId: String
    ): Boolean = synchronized(cachedServiceAnnouncementsLock) {
        val now = clock.currentTimeMillis()
        val key = RelayIngressAnnouncementKey(
            originPeerId,
            announcement.serviceIdentifier
        )
        val contentHash = serviceAnnouncementContentHash(announcement)
        val previous = relayIngressAnnouncementFingerprints.remove(key)
        val suppressionWindowMs = minOf(
            config.registrationTimeoutMs / 3,
            MAX_UNCHANGED_ANNOUNCEMENT_SUPPRESSION_MS
        ).coerceAtLeast(1L)
        val elapsedSinceFanoutMs = previous?.let { now - it.lastFanoutAtMs }
        val stillWithinSuppressionWindow = previous != null &&
            elapsedSinceFanoutMs != null &&
            now >= previous.lastFanoutAtMs &&
            elapsedSinceFanoutMs >= 0L &&
            elapsedSinceFanoutMs < suppressionWindowMs
        val shouldFanOut = previous == null ||
            previous.contentHash != contentHash ||
            !stillWithinSuppressionWindow
        relayIngressAnnouncementFingerprints[key] = RelayIngressAnnouncementFingerprint(
            contentHash = contentHash,
            lastFanoutAtMs = if (shouldFanOut) now else checkNotNull(previous).lastFanoutAtMs
        )
        if (relayIngressAnnouncementFingerprints.size > MAX_CACHED_SERVICE_ANNOUNCEMENTS) {
            val oldest = relayIngressAnnouncementFingerprints.entries.iterator()
            if (oldest.hasNext()) {
                oldest.next()
                oldest.remove()
            }
        }
        shouldFanOut
    }

    private fun clearRelayIngressAnnouncementFingerprint(
        originPeerId: String,
        serviceIdentifier: String
    ) = synchronized(cachedServiceAnnouncementsLock) {
        relayIngressAnnouncementFingerprints.remove(
            RelayIngressAnnouncementKey(originPeerId, serviceIdentifier)
        )
        Unit
    }

    /**
     * Infrequent age maintenance for the replay cache.
     *
     * Capacity is enforced once at insertion; time is considered only at explicit maintenance
     * points (registration replay, public snapshot, and registration cleanup). An old payload is
     * retained while its provider has a live registration because that registration is stronger
     * liveness evidence than the payload's age.
     */
    private fun pruneInactiveProviderAnnouncements() {
        val now = clock.currentTimeMillis()
        val liveProviderPeerIds = registeredPeers.entries
            .filter { (_, registration) -> registration.serviceInventory.isLive(now) }
            .mapTo(mutableSetOf()) { it.key }
        synchronized(cachedServiceAnnouncementsLock) {
            removeCachedServiceAnnouncementsLocked { _, cached ->
                val providerPeerId = cached.message.providerPeerId
                now - cached.cachedAtMs >= CACHED_ANNOUNCEMENT_REPLAY_MAX_AGE_MS &&
                    providerPeerId !in liveProviderPeerIds
            }
        }
    }

    private fun cachedServiceAnnouncementSnapshot(): Map<String, JSONObject> =
        synchronized(cachedServiceAnnouncementsLock) {
            val snapshot = LinkedHashMap<String, JSONObject>(cachedServiceAnnouncements.size)
            for ((serviceIdentifier, cached) in cachedServiceAnnouncements) {
                snapshot[serviceIdentifier] = JSONObject(cached.message.serializedMessage)
            }
            snapshot
        }

    /**
     * Records a ServiceWithdrawal so subsequent [cacheServiceAnnouncement] calls can reject
     * announcements that originated before the withdrawal. Also removes any currently cached
     * entry for the same service whose providerPeerId matches the withdrawal's provider AND
     * whose timestamp is not newer than the withdrawal — leaving genuine re-registrations
     * (newer-timestamp announcements that may have raced past the cleanup) intact.
     *
     * Designed to be called BEFORE notifying handlers and BEFORE forwarding the withdrawal,
     * so an externally-observable handler signal (e.g. a test polling [GossipHandler]) implies
     * the withdrawal is already recorded for cache-rejection purposes.
     *
     * The recorded timestamp uses [Long.maxOf] semantics so an out-of-order older withdrawal
     * cannot downgrade a newer recorded value. Recording and cache removal finish before this
     * method returns. It invokes no application handler on the calling thread, including when it
     * cleans up expired disconnected providers: their withdrawal publication is scheduled on a
     * separate worker. All announcement and withdrawal callbacks run outside the relay's provider,
     * registration, inventory and cache locks, so a consumer may call this method while holding
     * its own service-state lock.
     */
    fun recordServiceWithdrawal(
        serviceIdentifier: String,
        providerPeerId: String,
        timestamp: Long
    ) {
        if (!config.enableRelay) return
        if (providerPeerId.isEmpty()) return
        val expiredTombstoneWithdrawals = synchronized(registrationLifecycleLock) {
            val expired = pruneExpiredDisconnectedProviderTombstonesLocked(
                clock.currentTimeMillis()
            )
            synchronized(providerLifecycleLock(providerPeerId)) {
                recordServiceWithdrawalWithProviderLock(
                    serviceIdentifier,
                    providerPeerId,
                    timestamp
                )
            }
            expired
        }
        scheduleRelayIdentityWithdrawals(expiredTombstoneWithdrawals)
    }

    /**
     * Caller must hold [registrationLifecycleLock] and then [providerLifecycleLock] for
     * [providerPeerId].
     */
    private fun recordServiceWithdrawalWithProviderLock(
        serviceIdentifier: String,
        providerPeerId: String,
        timestamp: Long
    ): RegisteredPeer? {
        val registration = registeredPeers[providerPeerId]
        val registrationInventory = registration?.serviceInventory
        val tombstoneInventory = disconnectedProviderTombstones[providerPeerId]?.serviceInventory
        if (registration == null && tombstoneInventory == null) {
            synchronized(cachedServiceAnnouncementsLock) {
                recordWithdrawalReplayStateLocked(
                    serviceIdentifier,
                    providerPeerId,
                    timestamp
                )
            }
        } else {
            registrationInventory?.withStateLock {
                synchronized(cachedServiceAnnouncementsLock) {
                    val effectiveTimestamp = recordWithdrawalReplayStateLocked(
                        serviceIdentifier,
                        providerPeerId,
                        timestamp
                    )
                    registrationInventory.removeIfDefeatedByWithdrawalLocked(
                        serviceIdentifier,
                        effectiveTimestamp
                    )
                }
            }
            if (tombstoneInventory != null &&
                tombstoneInventory !== registrationInventory
            ) {
                tombstoneInventory.withStateLock {
                    synchronized(cachedServiceAnnouncementsLock) {
                        val effectiveTimestamp = recordWithdrawalReplayStateLocked(
                            serviceIdentifier,
                            providerPeerId,
                            timestamp
                        )
                        tombstoneInventory.removeIfDefeatedByWithdrawalLocked(
                            serviceIdentifier,
                            effectiveTimestamp
                        )
                    }
                }
            }
        }
        return registration
    }

    private fun prepareReceivedServiceWithdrawal(
        withdrawal: GossipProtocol.ServiceWithdrawal
    ): PreparedReceivedServiceWithdrawal = synchronized(registrationLifecycleLock) {
        val expiredTombstones = pruneExpiredDisconnectedProviderTombstonesLocked(
            clock.currentTimeMillis()
        )
        val received = synchronized(providerLifecycleLock(withdrawal.providerPeerId)) {
            val registrationAtCommit = if (config.enableRelay && withdrawal.providerPeerId.isNotEmpty()) {
                recordServiceWithdrawalWithProviderLock(
                    withdrawal.serviceIdentifier,
                    withdrawal.providerPeerId,
                    withdrawal.timestamp
                )
            } else {
                registeredPeers[withdrawal.providerPeerId]
            }
            PreparedServiceWithdrawal(withdrawal, registrationAtCommit)
        }
        PreparedReceivedServiceWithdrawal(received, expiredTombstones)
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun recordWithdrawalReplayStateLocked(
        serviceIdentifier: String,
        providerPeerId: String,
        timestamp: Long
    ): Long {
        val now = clock.currentTimeMillis()
        pruneExpiredWithdrawalTimestampsLocked(now)
        val withdrawalKey = "$serviceIdentifier::$providerPeerId"
        relayIngressAnnouncementFingerprints.remove(
            RelayIngressAnnouncementKey(providerPeerId, serviceIdentifier)
        )
        val existing = cacheWithdrawalTimestamps[withdrawalKey]
        val effectiveTimestamp = if (existing == null) {
            timestamp
        } else {
            maxOf(existing.providerTimestamp, timestamp)
        }
        val expiresAtMs = now + config.registrationTimeoutMs
        if (existing == null && cacheWithdrawalTimestamps.size >= MAX_CACHED_WITHDRAWAL_TIMESTAMPS) {
            recordWithdrawalAdmissionFenceLocked(providerPeerId, expiresAtMs, now)
        } else {
            cacheWithdrawalTimestamps.remove(withdrawalKey)
            cacheWithdrawalTimestamps[withdrawalKey] = CachedWithdrawalTimestamp(
                serviceIdentifier = serviceIdentifier,
                providerPeerId = providerPeerId,
                providerTimestamp = effectiveTimestamp,
                expiresAtMs = expiresAtMs
            )
        }

        val cached = cachedServiceAnnouncements[serviceIdentifier]?.message
        if (cached != null
            && cached.providerPeerId == providerPeerId
            && withdrawalDefeatsAnnouncement(
                cached.timestamp,
                effectiveTimestamp
            )
        ) {
            removeCachedServiceAnnouncementLocked(serviceIdentifier)
        }
        return effectiveTimestamp
    }

    /**
     * Removes a cached ServiceAnnouncement without recording a lifecycle timestamp or invoking
     * an application handler. Use [recordServiceWithdrawal] when a direct withdrawal must also
     * reject delayed old-or-equal announcements.
     */
    fun removeCachedServiceAnnouncement(serviceIdentifier: String) {
        synchronized(cachedServiceAnnouncementsLock) {
            removeCachedServiceAnnouncementLocked(serviceIdentifier)
        }
    }

    /**
     * Returns all cached service announcements.
     *
     * This is used by UrlResolver to send cached announcements to newly discovered peers
     * via PeerExchange. When a new peer connects, they should receive all known service
     * announcements immediately, not just the ones stored in discoveredServices.
     *
     * The cache may contain announcements that discoveredServices doesn't have,
     * particularly when the relay receives announcements from registered peers
     * before the local UrlResolver processes them through its gossip handler.
     *
     * Values are detached copies, including nested JSON; changing them cannot change cache
     * ordering or later replay. Each admission and each returned value requires one JSON copy.
     *
     * @return Map of serviceIdentifier to detached ServiceAnnouncement JSON
     */
    fun getCachedServiceAnnouncements(): Map<String, JSONObject> {
        pruneInactiveProviderAnnouncements()
        return cachedServiceAnnouncementSnapshot()
    }

    internal fun getWithdrawalAdmissionFenceCount(): Int =
        synchronized(cachedServiceAnnouncementsLock) {
            pruneExpiredWithdrawalTimestampsLocked(clock.currentTimeMillis())
            withdrawalAdmissionFenceExpiresAtMsByProvider.size
        }

    internal fun getDisconnectedProviderTombstoneCount(): Int {
        var count = 0
        val expiredWithdrawals = synchronized(registrationLifecycleLock) {
            val expired = pruneExpiredDisconnectedProviderTombstonesLocked(
                clock.currentTimeMillis()
            )
            count = disconnectedProviderTombstones.size
            expired
        }
        scheduleRelayIdentityWithdrawals(expiredWithdrawals)
        return count
    }

    internal fun getRelayReceiveServiceStateWatermarkCount(): Int =
        relayReceiveCallbacks.processedServiceStateRecencyCount()

    /** Installs, or with `null` removes, the deterministic receive-worker scheduling seam. */
    internal fun installRelayReceiveWorkerStartSeam(seam: (() -> Unit)?) {
        relayReceiveCallbacks.installWorkerStartSeam(seam)
    }

    /** Installs, or with `null` removes, the receive-payload admission seam used by tests. */
    internal fun installRelayReceiveAdmissionSeamForTesting(
        seam: ((String?, Long) -> Unit)?,
    ) {
        relayReceiveCallbacks.installAdmissionTestSeam(seam)
    }

    /** Forces the retained-byte admission boundary used by receive-accounting tests. */
    internal fun installRelayReceiveRetainedByteLimitForTesting(limit: Long?) {
        relayReceiveCallbacks.installRetainedByteLimitForTesting(limit)
    }

    /** Installs, or with `null` removes, the receive-overflow observation seam used by tests. */
    internal fun installRelayReceiveOverflowSeamForTesting(
        seam: ((RelayReceiveCallbackQueueOverflowWarningEffect) -> Unit)?,
    ) {
        relayReceiveCallbackOverflowSeamForTesting = seam
    }

    /** Installs, or with `null` removes, the registration-notification start seam used by tests. */
    internal fun installRelayRegistrationNotificationStartSeamForTesting(
        seam: (() -> Unit)?,
    ) {
        relayRegistrationNotificationStartTestSeam = seam
    }

    /** Installs, or with `null` removes, the identity-publication start seam used by tests. */
    internal fun installRelayIdentityPublicationStartSeamForTesting(
        seam: (() -> Unit)?,
    ) {
        relayIdentityPublicationStartTestSeam = seam
    }

    /** Installs, or with `null` removes, the receive-queue offer completion seam used by tests. */
    internal fun installRelayReceiveCallbackOfferCompletedSeamForTesting(
        seam: ((String) -> Unit)?,
    ) {
        relayReceiveCallbackOfferCompletedTestSeam = seam
    }

    /** Installs, or with `null` removes, the relay-side unregister-ACK admission seam. */
    internal fun installRelayUnregisterAcknowledgementAdmittedTestSeam(
        seam: ((String) -> Unit)?,
    ) {
        relayUnregisterAcknowledgementAdmittedTestSeam = seam
    }

    /** Installs, or with `null` removes, a one-shot client close-observer test hook. */
    internal fun installRelayCloseObserverTestHookForTesting(hook: (() -> Unit)?) {
        relayCloseObserverTestHook.set(hook)
    }

    /** Installs, or with `null` removes, the registered-request dispatch test seam. */
    internal fun installRelayRequestDispatchTestSeamForTesting(
        seam: (() -> Unit)?,
    ) {
        relayRequestDispatchTestSeam = seam
    }

    /**
     * Number of admitted relayed requests whose handler is running or whose completed reply is
     * waiting for outbox capacity on this peer. It never exceeds
     * [MAX_CONCURRENT_RELAYED_REQUEST_HANDLERS]; a request that arrives at the limit is refused
     * without waiting for a slot, with a not-dispatched error naming the limit and current count.
     */
    fun activeRelayedRequestHandlerCount(): Int = runningRelayedRequestHandlers.get()

    /** Installs, or with `null` removes, the post-interruption listener seam used by tests. */
    internal fun installRelayListenerInterruptedTestSeamForTesting(
        seam: (() -> Unit)?,
    ) {
        relayListenerInterruptedTestSeam = seam
    }

    /** Enables the direct-walk receive-ledger invariant checker used by integration tests. */
    internal fun installRelayReceiveLedgerInvariantCheckerForTesting() {
        relayReceiveCallbacks.installLedgerInvariantCheckerForTesting()
    }

    /** Installs, or with `null` removes, the ordinary relay gossip worker-start test seam. */
    internal fun installOrdinaryRelayGossipWorkerStartSeamForTesting(seam: (() -> Unit)?) {
        ordinaryRelayGossipWorkerStartSeamForTesting = seam
    }

    /** Returns receive payload bytes still charged after invariant checking has been enabled. */
    internal fun relayReceiveRetainedBytesForTesting(): Long =
        relayReceiveCallbacks.retainedBytesForTesting()

    /** Temporarily corrupts one active receive charge so the checker can prove it rejects it. */
    internal fun forceRelayReceiveEarlyEntryReleaseForTesting(): String =
        relayReceiveCallbacks.forceEarlyEntryReleaseForTesting()

    /** Waits until every receive payload charge reaches its normal terminal release. */
    internal fun awaitRelayReceiveLedgerQuiescenceForTesting(
        timeout: Long,
        unit: TimeUnit,
    ): Boolean = relayReceiveCallbacks.awaitQuiescenceForTesting(timeout, unit)

    /** Returns immutable receive-queue accounting for operational diagnostics. */
    fun relayReceiveQueueSnapshot(): RelayReceiveQueueSnapshot = relayReceiveCallbacks.snapshot()

    /** Returns the process-wide completed-request materialization accounting. */
    fun relayRequestMaterializationSnapshot(): RelayRequestMaterializationSnapshot =
        RelayRequestMaterializationBudget.snapshot()

    /**
     * Returns the number of incomplete incoming chunked-request assemblies currently retained.
     * Operators can monitor this value to confirm that abandoned transfers are releasing their
     * buffered memory after [RelayConfig.chunkAssemblyTtlMs] instead of accumulating while relay
     * traffic is idle.
     */
    fun currentIncomingChunkAssemblyCount(): Int = synchronized(chunkAssemblyLock) {
        chunkedTransfers.size
    }

    // Desired and committed catalog state share the lifecycle guard. No transport work or
    // transaction wait runs while this lock is held.
    private fun reviseDesiredRelayServices(services: List<String>): RelayCatalogRevision {
        raceLifecycleLock.withLock {
            val serviceSnapshot = services.toList()
            val current = desiredRelayServices.get()
            if (current.services == serviceSnapshot) {
                return current
            }
            val revision = RelayCatalogRevision(
                revision = relayCatalogRevision.incrementAndGet(),
                services = serviceSnapshot
            )
            desiredRelayCatalogIntentRevision.incrementAndGet()
            desiredRelayServices.set(revision)
            return revision
        }
    }

    // An acknowledgement commits both the catalog revision and the public identity of the exact
    // connection that carried it. close(), a failed registration, or a newer connection may win
    // before this short critical section; in that case the stale acknowledgement commits nothing.
    private fun commitAcknowledgedRelayConnection(
        connection: RelayConnection,
        acknowledged: RelayCatalogRevision,
        registrationRequestId: String,
        registrationSequence: Long,
        expectedIntentGeneration: Long? = null,
    ): Boolean = raceLifecycleLock.withLock {
        if (closed.get() ||
            relayConnection !== connection ||
            expectedIntentGeneration != null &&
                relayRegistrationIntentGeneration.get() != expectedIntentGeneration
        ) return false

        while (true) {
            val current = committedRelayServices.get()
            if (acknowledged.revision <= current.revision) break
            if (committedRelayServices.compareAndSet(current, acknowledged)) break
        }
        // The accepted ACK ends the preceding recovery failures before callers can observe
        // this relay as connected. A close during the remaining registration work may make
        // that worker return false, but its pre-ACK failure generation no longer owns backoff.
        sameRelayFailureState.resetSameRelayFailures()
        currentReconnectDelayMs = baseReconnectDelayMs
        reconnectAttempts = 0
        connectedRelayPeerId = connection.relayPeerId
        if (registrationSequence > connection.latestStreamOwningRegistrationSequence) {
            connection.latestStreamOwningRegistrationRequestId = registrationRequestId
            connection.latestStreamOwningRegistrationSequence = registrationSequence
            releaseRelayRegistrationCloseFailureClaim(connection.closeState)
        }
        true
    }

    /**
     * Clears the connection and its reported identity as one lifecycle transition.
     *
     * When [expected] is non-null, a newer connection is preserved.
     */
    private fun clearRelayConnectionState(expected: RelayConnection? = null): Boolean {
        var clearedConnection: RelayConnection? = null
        val cleared = raceLifecycleLock.withLock {
            if (expected != null && relayConnection !== expected) {
                false
            } else {
                clearedConnection = relayConnection
                relayConnection = null
                connectedRelayPeerId = null
                committedRelayCandidate.get()?.let { candidate ->
                    if (clearedConnection == null ||
                        candidate.state.connection.get() === clearedConnection
                    ) {
                        committedRelayCandidate.compareAndSet(candidate, null)
                    }
                }
                true
            }
        }
        clearedConnection?.let { connection ->
            var retirementFailure: Throwable? = null
            try {
                connection.stopKeepaliveProgress()
            } catch (failure: Throwable) {
                retirementFailure = appendRelayCleanupFailure(retirementFailure, failure)
            }
            try {
                relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
            } catch (failure: Throwable) {
                retirementFailure = appendRelayCleanupFailure(retirementFailure, failure)
            }
            // Selected state is already detached. Closing outside the lifecycle lock permits
            // observer re-entry and can never close a replacement generation.
            try {
                connection.retire()
            } catch (failure: Throwable) {
                retirementFailure = appendRelayCleanupFailure(retirementFailure, failure)
            }
            retirementFailure?.let { throw it }
        }
        return cleared
    }

    // ACK completion runs on a listener or timeout thread. It uses only the short lifecycle
    // transaction and never waits for the registration turn whose caller may be awaiting this ACK.
    // Connection close and receive callbacks run after releasing the lifecycle guard.
    private fun abandonUnacknowledgedRelayConnection(
        connection: RelayConnection,
        failedRevision: RelayCatalogRevision,
        reportsCloseFailure: Boolean,
    ): Throwable? {
        var registrationClose: CapturedRelayRegistrationClose? = null
        val shouldClose = raceLifecycleLock.withLock {
            val desired = desiredRelayServices.get()
            val committed = committedRelayServices.get()
            if (desired.revision != failedRevision.revision ||
                committed.revision >= failedRevision.revision ||
                relayConnection !== connection
            ) {
                false
            } else {
                registrationClose = CapturedRelayRegistrationClose(
                    connection.closeState,
                    if (reportsCloseFailure) claimRelayRegistrationCloseFailure(connection.closeState) else null,
                )
                relayConnection = null
                connectedRelayPeerId = null
                true
            }
        }
        if (!shouldClose) return null

        var closeFailure: Throwable? = null
        try {
            relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
        } catch (failure: Throwable) {
            closeFailure = appendRelayCleanupFailure(closeFailure, failure)
        }
        val captured = checkNotNull(registrationClose)
        try {
            closeRelayRegistration(captured.state, 0L, false, captured.claim)
        } catch (failure: Throwable) {
            closeFailure = appendRelayCleanupFailure(closeFailure, failure)
        } finally {
            releaseCapturedRelayRegistrationClose(captured)
        }
        closeFailure?.let { failure ->
            debugLog {
                "[RELAY-CLIENT] Failed to close relay ${connection.relayPeerId} after catalog " +
                    "revision ${failedRevision.revision} went unacknowledged: $failure"
            }
        }
        return closeFailure
    }

    /**
     * Sends a gossip message TO the relay this client is registered with.
     *
     * This is essential for NAT'd clients: when they want to broadcast gossip,
     * they can't open direct connections to other peers (including the relay).
     * Instead, they should send gossip through their existing relay connection.
     *
     * The relay will then:
     * 1. Process the gossip message (e.g., store service announcements)
     * 2. Forward it to other registered peers via forwardGossipToRegisteredPeers()
     *
     * @param message The gossip message to send to the relay
     * @return `true` only when the frame entered the relay transport; `false` otherwise
     */
    fun sendGossipToRelay(message: JSONObject): Boolean = sendGossipToRelay(message, allowReconnect = true)

    /**
     * Sends a gossip message TO the relay this client is registered with, optionally without the
     * immediate-reconnection fallback.
     *
     * With [allowReconnect] = true this behaves exactly like [sendGossipToRelay] (message): a lost
     * relay connection triggers an immediate SYNCHRONOUS re-registration on the calling thread so
     * critical messages (like ServiceWithdrawal) are delivered even if the background reconnection
     * task hasn't run yet. That reconnect is a full dial — a 2-second reachability probe, a libp2p
     * handshake with a 30-second budget, then a 10-second registration-ACK wait — so it can park
     * the caller for tens of seconds against a dead or starved relay.
     *
     * With [allowReconnect] = false a lost connection makes the send return false immediately.
     * This is the right mode for teardown paths (a best-effort goodbye must never re-dial the peer
     * it is saying goodbye to — see UrlProtocol2.close() in the UrlResolver consumer) and for any
     * caller on a latency-sensitive thread. Note that checking the connection state before calling
     * the reconnecting overload is NOT equivalent: the connection can be marked lost between the
     * check and the send (keepalive failure on another thread), and the reconnecting overload
     * would then re-dial anyway. This parameter closes that race at the owning layer.
     *
     * @param message The gossip message to send to the relay
     * @param allowReconnect Whether a lost relay connection may be synchronously re-established
     *                       (a blocking dial on the calling thread) before sending
     * @return `true` only when the frame entered the relay transport; `false` otherwise
     */
    fun sendGossipToRelay(message: JSONObject, allowReconnect: Boolean): Boolean =
        sendGossipToRelay(message, allowReconnect, WRITE_BACKPRESSURE_WAIT_MS)

    /**
     * Sends a gossip message to this client's relay with an explicit bounded transport-admission
     * budget.
     *
     * Unlike the historical implementation, `true` means the frame was actually admitted to the
     * relay connection; a frame rejected by transport backpressure returns `false`. This method does
     * not wait for a remote acknowledgement. A caller that immediately closes the node can use a
     * larger finite [maxAdmissionWaitMs] to causally await admission, then rely on the relay
     * connection's ordered closeWrite barrier to flush the admitted frame. The budget must be
     * non-negative; no overload blocks without a bound.
     *
     * @param message The gossip message to send to the relay
     * @param allowReconnect Whether a lost relay connection may be synchronously re-established
     * @param maxAdmissionWaitMs Maximum time to wait for the connection to become writable
     * @return `true` only when the frame entered the transport; `false` otherwise
     */
    fun sendGossipToRelay(
        message: JSONObject,
        allowReconnect: Boolean,
        maxAdmissionWaitMs: Long
    ): Boolean {
        requireValidRelayAdmissionWait(maxAdmissionWaitMs)
        var connection = relayConnection

        // If relay connection is lost, attempt immediate reconnection
        // This ensures critical messages (like ServiceWithdrawal) are delivered
        // even if the background reconnection task hasn't run yet
        if (connection == null) {
            if (!allowReconnect) {
                debugLog { "[RELAY-CLIENT] Cannot send gossip: relay connection lost and allowReconnect=false" }
                return false
            }
            val registrationIntent = raceLifecycleLock.withLock {
                registeredRelayPeerId?.let { relayPeerId ->
                    relayPeerId to relayRegistrationIntentGeneration.get()
                }
            }
            if (registrationIntent != null) {
                val (relayPeerId, intentGeneration) = registrationIntent
                debugLog { "[RELAY-CLIENT] Relay connection lost, attempting immediate reconnection before sending gossip" }
                try {
                    if (doRegisterWithRelay(relayPeerId, intentGeneration, reportsFailure = false)) {
                        connection = relayConnection
                        debugLog {
                            "[RELAY-CLIENT] Immediate reconnection successful with relay " +
                                connection?.relayPeerId
                        }
                    }
                } catch (e: Exception) {
                    debugLog { "[RELAY-CLIENT] Immediate reconnection failed: ${e.message}" }
                }
            }

            if (connection == null) {
                debugLog { "[RELAY-CLIENT] Cannot send gossip: not registered with relay" }
                return false
            }
        }

        return try {
            val admitted = connection.sendMessage(message, maxAdmissionWaitMs)
            if (admitted) {
                debugLog { "[RELAY-CLIENT] Admitted gossip to relay transport: ${message.optString("type", "unknown")}" }
                true
            } else {
                debugLog {
                    "[RELAY-CLIENT] Gossip was not admitted to relay transport within " +
                        "${maxAdmissionWaitMs}ms: ${message.optString("type", "unknown")}"
                }
                if (connection.isClosed()) {
                    clearRelayConnectionState(connection)
                }
                false
            }
        } catch (e: Exception) {
            debugLog { "[RELAY-CLIENT] Failed to send gossip to relay: ${e.message}" }
            // Mark connection as lost so next attempt will try to reconnect
            clearRelayConnectionState(connection)
            false
        }
    }

    /**
     * Sends a gossip message to a peer that has registered with this relay service.
     * This is used when we need to send gossip to a peer that is only reachable through
     * the relay connection (e.g., NAT-ed peers).
     *
     * @param peerId The peer ID of the registered peer
     * @param message The gossip message to send
     * @return True if the message was sent successfully, false if the peer is not registered
     */
    fun sendGossipToRegisteredPeer(peerId: String, message: JSONObject): Boolean {
        val registration = registeredPeers[peerId] ?: return false
        return try {
            registration.controller.sendMessage(message)
            debugLog { "[RELAY] Sent gossip to registered peer $peerId via relay connection" }
            true
        } catch (e: Exception) {
            debugLog { "[RELAY] Failed to send gossip to registered peer $peerId: ${e.message}" }
            false
        }
    }

    /**
     * Starts one bounded relay registration without selecting that relay.
     *
     * The returned handle is created immediately. Dialing, sending the registration, and waiting
     * for its acknowledgement run on a bounded per-service worker pool. The candidate connection
     * remains private to the handle until [commitRelayCandidateRegistration] installs it.
     * Its idle polls, partial-frame allowance and absolute preparation deadline all use the service
     * [clock], as does its cancellation timer. The registered listener's separate read clock does
     * not govern this application operation.
     *
     * @param relayPeerId exact candidate peer ID already present in this service's peer registry
     * @param budgetMs total preparation budget, measured by this service's [Clock]
     * @param services services to publish only if this candidate is committed
     * @param handler request handler to install only if this candidate is committed
     */
    fun prepareRelayCandidateRegistration(
        relayPeerId: String,
        budgetMs: Long,
        services: List<String> = emptyList(),
        handler: (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse
    ): RelayCandidateRegistration {
        require(relayPeerId.isNotBlank()) {
            "Relay candidate peer ID must not be blank, but the provided value was '$relayPeerId'."
        }
        require(budgetMs > 0L) {
            "Relay candidate preparation budget must be greater than zero milliseconds, but the " +
                "provided value was $budgetMs."
        }

        val state = raceLifecycleLock.withLock {
            RelayCandidateRegistrationState(
                services = services.toList(),
                desiredCatalogIntentRevisionAtPreparation =
                    desiredRelayCatalogIntentRevision.get(),
                handler = wrapWithChunking(handler)
            )
        }
        val candidate = RelayCandidateRegistration(
            relayCandidateOwnerToken,
            state,
            relayPeerId,
            budgetMs
        )
        val preparation = object : FutureTask<Unit>(Callable {
            state.workerStarted.set(true)
            runRelayCandidatePreparation(candidate)
        }) {
            override fun done() {
                // cancel(true) can complete a FutureTask before its callable ever starts. In that
                // case no worker finally block exists to release the cleanup waiter.
                if (!state.workerStarted.get()) {
                    state.workerSettled.complete(Unit)
                    scheduleRelayCandidateCleanup(candidate)
                }
            }
        }
        state.preparationTask.set(preparation)
        raceLifecycleLock.withLock {
            if (closed.get()) {
                failUnadmittedRelayCandidatePreparation(
                    candidate,
                    IllegalStateException(
                        "Cannot prepare relay candidate $relayPeerId because RelayService is closed."
                    )
                )
                return candidate
            }
            if (relayConnection?.relayPeerId == relayPeerId) {
                failUnadmittedRelayCandidatePreparation(
                    candidate,
                    IllegalStateException(
                        "Cannot prepare relay candidate $relayPeerId because it is already the " +
                            "selected relay for peer $peerId."
                    )
                )
                return candidate
            }

            val activeCount = activeRelayCandidateCount.incrementAndGet()
            if (activeCount > maxRelayCandidateRegistrations) {
                activeRelayCandidateCount.decrementAndGet()
                failUnadmittedRelayCandidatePreparation(
                    candidate,
                    RejectedExecutionException(
                        "RelayService already has $maxRelayCandidateRegistrations live relay " +
                            "candidate registrations; candidate $relayPeerId was not admitted."
                    )
                )
                return candidate
            }
            state.slotAcquired.set(true)
            activeRelayCandidates.add(candidate)

            try {
                relayCandidatePreparationExecutor.execute(preparation)
            } catch (failure: RejectedExecutionException) {
                failRelayCandidatePreparation(
                    candidate,
                    RejectedExecutionException(
                        "Relay candidate $relayPeerId could not start because all eight bounded " +
                            "candidate preparation workers are occupied.",
                        failure
                    )
                )
                state.workerSettled.complete(Unit)
                scheduleRelayCandidateCleanup(candidate)
                return candidate
            }
        }

        val scheduledTimeout = clock.schedule(clock.currentTimeMillis() + budgetMs) {
            timeoutRelayCandidatePreparation(candidate)
        }
        state.timeoutTask.set(scheduledTimeout)
        if (state.status.get() != RelayCandidateRegistrationStatus.PREPARING) {
            state.timeoutTask.getAndSet(null)?.let(clock::unschedule)
        }
        return candidate
    }

    /**
     * Atomically selects one acknowledged candidate.
     *
     * Returns `true` only after the relay acknowledges the selected candidate's service catalog.
     * A handle that is not acknowledged, belongs to another service, loses to an already committed
     * candidate, or cannot publish its catalog is not retained and returns `false`.
     */
    fun commitRelayCandidateRegistration(candidate: RelayCandidateRegistration): Boolean =
        relayRegistrationCoordinator.withRelay(candidate.relayPeerId) {
            commitRelayCandidateRegistrationWithRelayGate(candidate)
        }

    private fun commitRelayCandidateRegistrationWithRelayGate(
        candidate: RelayCandidateRegistration
    ): Boolean {
        if (candidate.ownerToken !== relayCandidateOwnerToken) return false
        val state = candidate.state
        val connection = state.connection.get()
        if (connection == null || connection.isClosed()) {
            failDeadAcknowledgedRelayCandidate(candidate)
            return false
        }
        var committed = false
        var deadConnectionRejected = false
        var candidateIntentGeneration = 0L
        raceLifecycleLock.withLock {
            if (connection.isClosed()) {
                deadConnectionRejected = true
                return@withLock
            }
            if (closed.get() ||
                relayConnection != null ||
                committedRelayCandidate.get() != null ||
                !state.status.compareAndSet(
                    RelayCandidateRegistrationStatus.ACKNOWLEDGED,
                    RelayCandidateRegistrationStatus.COMMITTED
                )
            ) {
                return false
            }

            val desiredAtCommit = desiredRelayServices.get()
            if (desiredRelayCatalogIntentRevision.get() <=
                state.desiredCatalogIntentRevisionAtPreparation &&
                desiredAtCommit.services != state.services
            ) {
                desiredRelayServices.set(
                    RelayCatalogRevision(
                        revision = relayCatalogRevision.incrementAndGet(),
                        services = state.services
                    )
                )
            }
            registeredRelayPeerId = candidate.relayPeerId
            requestHandler = state.handler
            candidateIntentGeneration = relayRegistrationIntentGeneration.incrementAndGet()
            reconnectAttempts = 0
            currentReconnectDelayMs = baseReconnectDelayMs
            relayConnection = connection
            relayRegistrationCloseState = carryRelayRegistrationCloseFailures(
                relayRegistrationCloseState, connection.closeState,
            )
            committedRelayCandidate.set(candidate)
            relayConnectionGenerationOwner.set(candidate)

            committed = true
        }

        if (deadConnectionRejected) {
            failDeadAcknowledgedRelayCandidate(candidate)
            return false
        }
        if (!committed) return false

        // The listener must be active before the selected catalog is sent because it completes
        // the matching acknowledgement future. Installation is an external effect and therefore
        // runs only after the lifecycle state transaction above has released its lock.
        if (!startRequestListener(connection)) {
            failCommittedRelayCandidate(candidate, connection)
            return false
        }

        state.timeoutTask.getAndSet(null)?.let(clock::unschedule)
        state.acknowledgedLifetimeTask.getAndSet(null)?.let(clock::unschedule)
        val catalogAcknowledged = try {
            sendLatestDesiredRelayRegistrationAsync(
                connection,
                candidateIntentGeneration,
                reportsFailure = false,
            ).get()
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            debugLogErr {
                "[RELAY-CLIENT] Interrupted while waiting for relay ${candidate.relayPeerId} to " +
                    "acknowledge committed services ${state.services}: $interrupted"
            }
            false
        } catch (execution: ExecutionException) {
            debugLogErr {
                "[RELAY-CLIENT] Publishing committed relay candidate ${candidate.relayPeerId} " +
                    "services ${state.services} failed: ${execution.cause ?: execution}"
            }
            false
        } catch (cancellation: CancellationException) {
            debugLogErr {
                "[RELAY-CLIENT] Publishing committed relay candidate ${candidate.relayPeerId} " +
                    "services ${state.services} was canceled: $cancellation"
            }
            false
        }
        if (!catalogAcknowledged) {
            failCommittedRelayCandidate(candidate, connection)
            return false
        }

        startKeepalive(connection)
        val routePublished = raceLifecycleLock.withLock {
            if (closed.get() ||
                relayConnection !== connection ||
                committedRelayCandidate.get() !== candidate ||
                relayConnectionGenerationOwner.get() !== candidate ||
                relayRegistrationIntentGeneration.get() != candidateIntentGeneration
            ) {
                false
            } else {
                // Only the acknowledged committed catalog proves this selected relay is serving
                // us. Clear failures before scheduling its first same-relay recovery check.
                sameRelayFailureState.resetSameRelayFailures()
                activeRelayCandidates.remove(candidate)
                releaseRelayCandidateSlot(candidate)
                routingTable.addNeighbor(candidate.relayPeerId, connection.controller)
                true
            }
        }
        if (routePublished) replaceReconnectionTask {
            !closed.get() && relayConnection === connection &&
                committedRelayCandidate.get() === candidate &&
                relayRegistrationIntentGeneration.get() == candidateIntentGeneration
        }
        if (routePublished) updateLocalLinkStateAdvertisement()
        val selectionStillInstalled =
            routePublished &&
                raceLifecycleLock.withLock {
                    !closed.get() &&
                        relayConnection === connection &&
                        committedRelayCandidate.get() === candidate &&
                        relayConnectionGenerationOwner.get() === candidate &&
                        relayRegistrationIntentGeneration.get() == candidateIntentGeneration
                }
        if (!selectionStillInstalled) {
            failCommittedRelayCandidate(candidate, connection)
            return false
        }

        return true
    }

    private fun failDeadAcknowledgedRelayCandidate(candidate: RelayCandidateRegistration) {
        val state = candidate.state
        if (state.status.compareAndSet(
                RelayCandidateRegistrationStatus.ACKNOWLEDGED,
                RelayCandidateRegistrationStatus.FAILED
            )
        ) {
            state.acknowledgedLifetimeTask.getAndSet(null)?.let(clock::unschedule)
            scheduleRelayCandidateCleanup(candidate)
        }
    }

    private fun failCommittedRelayCandidate(
        candidate: RelayCandidateRegistration,
        connection: RelayConnection
    ) {
        val state = candidate.state
        var connectionCleared = false
        var detachedTasks: DetachedRelayTasks? = null
        raceLifecycleLock.withLock {
            if (relayConnectionGenerationOwner.get() === candidate) {
                // Capture the old generation's exact task references before releasing ownership;
                // cleanup after the lock cannot stop tasks installed by a later candidate.
                detachedTasks = detachListenerAndKeepalive()
                if (relayConnection === connection) {
                    relayConnection = null
                    connectedRelayPeerId = null
                    connectionCleared = true
                }
                committedRelayCandidate.compareAndSet(candidate, null)
                if (registeredRelayPeerId == candidate.relayPeerId) {
                    registeredRelayPeerId = null
                }
                if (requestHandler === state.handler) {
                    requestHandler = null
                }
                relayConnectionGenerationOwner.compareAndSet(candidate, null)
            }
        }
        detachedTasks?.let(::cleanupDetachedRelayTasks)
        if (connectionCleared) {
            relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
        }
        state.status.compareAndSet(
            RelayCandidateRegistrationStatus.COMMITTED,
            RelayCandidateRegistrationStatus.FAILED
        )
        scheduleRelayCandidateCleanup(candidate)
    }

    /**
     * Cancels an uncommitted candidate and schedules its transport teardown.
     *
     * The method itself does not wait for the preparation worker or stream close. The returned
     * future completes after both have settled. Canceling a committed winner is rejected because
     * the selected relay is owned by the ordinary unregister/close lifecycle.
     */
    fun cancelRelayCandidateRegistration(
        candidate: RelayCandidateRegistration
    ): CompletableFuture<Unit> {
        if (candidate.ownerToken !== relayCandidateOwnerToken) {
            return failedFuture(
                IllegalArgumentException(
                    "Relay candidate ${candidate.relayPeerId} belongs to a different RelayService."
                )
            )
        }
        return cancelRelayCandidateRegistrationInternal(
            candidate,
            CancellationException(
                "Relay candidate ${candidate.relayPeerId} was canceled before commit."
            )
        )
    }

    private fun runRelayCandidatePreparation(candidate: RelayCandidateRegistration) {
        val state = candidate.state
        try {
            if (state.status.get() != RelayCandidateRegistrationStatus.PREPARING) return
            val relayPeer = peerRegistry.getPeer(candidate.relayPeerId)
                ?: throw IllegalArgumentException(
                    "Relay candidate ${candidate.relayPeerId} was not found in the peer registry."
                )
            val connection = connectToRelay(relayPeer)
            state.connection.set(connection)
            if (state.status.get() != RelayCandidateRegistrationStatus.PREPARING) return

            val acknowledgement = relayRegistrationCoordinator.withRelay(candidate.relayPeerId) {
                if (state.status.get() != RelayCandidateRegistrationStatus.PREPARING) {
                    return@withRelay null
                }
                val selectedSameRelay = raceLifecycleLock.withLock {
                    relayConnection?.relayPeerId == candidate.relayPeerId
                }
                if (selectedSameRelay) {
                    throw IllegalStateException(
                        "Cannot prepare relay candidate ${candidate.relayPeerId} because it is " +
                            "already the selected relay for peer $peerId."
                    )
                }

                val request = RelayProtocol.RelayRegister(
                    requestId = RelayProtocol.nextMessageId(),
                    peerId = peerId,
                    // Candidate preparation establishes only transport liveness. Publishing the
                    // real catalog here would expose an unselected route before its listener is
                    // installed.
                    advertisedServices = emptyList(),
                    multiaddresses = ownRegistrationMultiaddresses(host, peerId),
                    timestamp = reserveProviderLifecycleTimestamp(clock, peerId)
                )
                connection.sendMessage(request.toJson())

                var receivedAcknowledgement: RelayProtocol.RelayRegisterAck? = null
                val deadline = saturatedReadDeadline(clock.currentTimeMillis(), candidate.budgetMs)
                while (receivedAcknowledgement == null &&
                    state.status.get() == RelayCandidateRegistrationStatus.PREPARING
                ) {
                    val remainingMs = remainingReadWaitMillis(deadline, clock.currentTimeMillis())
                    if (remainingMs <= 0L) {
                        throw TimeoutException(
                            "Timed out after ${candidate.budgetMs}ms preparing relay candidate " +
                                "${candidate.relayPeerId} for peer $peerId."
                        ).apply { state.lastAdmissionMiss.get()?.let(::initCause) }
                    }
                    val response = try {
                        connection.readMessage(
                            remainingMs.coerceAtMost(1000L), remainingMs,
                            TimeUnit.MILLISECONDS, clock, deadline,
                        )
                    } catch (admissionMiss: RelayParseBudgetDeadlineException) {
                        // Admission consumed no body bytes. The next iteration checks the
                        // original operation deadline before attempting to resume the frame.
                        state.lastAdmissionMiss.set(admissionMiss)
                        continue
                    } ?: continue
                    // A delivered frame was admitted, so an earlier miss no longer explains a timeout.
                    state.lastAdmissionMiss.set(null)
                    if (response.optString("type", "") ==
                        RelayProtocol.TYPE_RELAY_REGISTER_ACK
                    ) {
                        receivedAcknowledgement =
                            RelayProtocol.RelayRegisterAck.fromJson(response)
                    }
                }
                receivedAcknowledgement
            }

            if (state.status.get() != RelayCandidateRegistrationStatus.PREPARING) return
            val ack = acknowledgement ?: return
            if (!ack.success) {
                throw RelayException(
                    "Relay candidate ${candidate.relayPeerId} rejected registration for peer " +
                        "$peerId: ${ack.errorMessage ?: "no error message was provided"}"
                )
            }
            if (state.status.compareAndSet(
                    RelayCandidateRegistrationStatus.PREPARING,
                    RelayCandidateRegistrationStatus.ACKNOWLEDGED
                )
            ) {
                state.timeoutTask.getAndSet(null)?.let(clock::unschedule)
                val lifetimeTask = clock.schedule(
                    clock.currentTimeMillis() + candidate.budgetMs
                ) {
                    expireAcknowledgedRelayCandidate(candidate)
                }
                state.acknowledgedLifetimeTask.set(lifetimeTask)
                if (state.status.get() != RelayCandidateRegistrationStatus.ACKNOWLEDGED) {
                    state.acknowledgedLifetimeTask.getAndSet(null)?.let(clock::unschedule)
                }
                candidate.acknowledgement.complete(candidate)
            }
        } catch (failure: Throwable) {
            if (failure is InterruptedException) {
                Thread.currentThread().interrupt()
            }
            if (state.status.get() == RelayCandidateRegistrationStatus.PREPARING) {
                failRelayCandidatePreparation(candidate, failure)
            }
        } finally {
            state.workerSettled.complete(Unit)
            val finalStatus = state.status.get()
            if (finalStatus != RelayCandidateRegistrationStatus.ACKNOWLEDGED &&
                finalStatus != RelayCandidateRegistrationStatus.COMMITTED
            ) {
                scheduleRelayCandidateCleanup(candidate)
            }
        }
    }

    private fun timeoutRelayCandidatePreparation(candidate: RelayCandidateRegistration) {
        val failure = TimeoutException(
            "Timed out after ${candidate.budgetMs}ms preparing relay candidate " +
                "${candidate.relayPeerId} for peer $peerId."
        ).apply { candidate.state.lastAdmissionMiss.get()?.let(::initCause) }
        if (candidate.state.status.compareAndSet(
                RelayCandidateRegistrationStatus.PREPARING,
                RelayCandidateRegistrationStatus.FAILED
            )
        ) {
            candidate.acknowledgement.completeExceptionally(failure)
            candidate.state.preparationTask.get()?.cancel(true)
            scheduleRelayCandidateCleanup(candidate)
        }
    }

    private fun expireAcknowledgedRelayCandidate(candidate: RelayCandidateRegistration) {
        if (candidate.state.status.compareAndSet(
                RelayCandidateRegistrationStatus.ACKNOWLEDGED,
                RelayCandidateRegistrationStatus.FAILED
            )
        ) {
            candidate.state.acknowledgedLifetimeTask.set(null)
            scheduleRelayCandidateCleanup(candidate)
        }
    }

    private fun failRelayCandidatePreparation(
        candidate: RelayCandidateRegistration,
        failure: Throwable
    ) {
        if (candidate.state.status.compareAndSet(
                RelayCandidateRegistrationStatus.PREPARING,
                RelayCandidateRegistrationStatus.FAILED
            )
        ) {
            candidate.state.timeoutTask.getAndSet(null)?.let(clock::unschedule)
            candidate.acknowledgement.completeExceptionally(failure)
            scheduleRelayCandidateCleanup(candidate)
        }
    }

    private fun failUnadmittedRelayCandidatePreparation(
        candidate: RelayCandidateRegistration,
        failure: Throwable
    ) {
        val state = candidate.state
        if (state.status.compareAndSet(
                RelayCandidateRegistrationStatus.PREPARING,
                RelayCandidateRegistrationStatus.FAILED
            )
        ) {
            candidate.acknowledgement.completeExceptionally(failure)
        }
        // No worker was admitted, so cleanup is already complete and must not be scheduled later.
        state.cleanupStarted.set(true)
        state.workerSettled.complete(Unit)
        state.cleanup.complete(Unit)
    }

    private fun cancelRelayCandidateRegistrationInternal(
        candidate: RelayCandidateRegistration,
        cancellation: CancellationException
    ): CompletableFuture<Unit> {
        val state = candidate.state
        while (true) {
            when (val status = state.status.get()) {
                RelayCandidateRegistrationStatus.PREPARING,
                RelayCandidateRegistrationStatus.ACKNOWLEDGED -> {
                    if (!state.status.compareAndSet(
                            status,
                            RelayCandidateRegistrationStatus.CANCELED
                        )
                    ) {
                        continue
                    }
                    state.timeoutTask.getAndSet(null)?.let(clock::unschedule)
                    state.acknowledgedLifetimeTask.getAndSet(null)?.let(clock::unschedule)
                    candidate.acknowledgement.completeExceptionally(cancellation)
                    state.preparationTask.get()?.cancel(true)
                    scheduleRelayCandidateCleanup(candidate)
                    return state.cleanup
                }
                RelayCandidateRegistrationStatus.CANCELED,
                RelayCandidateRegistrationStatus.FAILED -> {
                    scheduleRelayCandidateCleanup(candidate)
                    return state.cleanup
                }
                RelayCandidateRegistrationStatus.COMMITTED -> {
                    return failedFuture(
                        IllegalStateException(
                            "Relay candidate ${candidate.relayPeerId} is committed and must be " +
                                "released through unregisterFromRelay() or RelayService.close()."
                        )
                    )
                }
            }
        }
    }

    private fun scheduleRelayCandidateCleanup(candidate: RelayCandidateRegistration) {
        val state = candidate.state
        if (!state.cleanupStarted.compareAndSet(false, true)) return
        state.timeoutTask.getAndSet(null)?.let(clock::unschedule)
        state.acknowledgedLifetimeTask.getAndSet(null)?.let(clock::unschedule)
        val cleanup = Runnable {
            var failure: Throwable? = null
            try {
                try {
                    state.workerSettled.get()
                } catch (_: CancellationException) {
                    // The workerSettled future itself is never canceled.
                } catch (execution: ExecutionException) {
                    failure = execution.cause ?: execution
                }
                try {
                    state.connection.getAndSet(null)?.close()
                } catch (closeFailure: Throwable) {
                    if (failure == null) {
                        failure = closeFailure
                    } else {
                        failure!!.addSuppressed(closeFailure)
                    }
                }
            } catch (interrupted: InterruptedException) {
                Thread.currentThread().interrupt()
                failure = interrupted
            } finally {
                raceLifecycleLock.withLock {
                    activeRelayCandidates.remove(candidate)
                    releaseRelayCandidateSlot(candidate)
                }
                val cleanupFailure = failure
                if (cleanupFailure == null) {
                    state.cleanup.complete(Unit)
                } else {
                    state.cleanup.completeExceptionally(cleanupFailure)
                }
            }
        }
        try {
            relayCandidateCleanupExecutor.execute(cleanup)
        } catch (_: RejectedExecutionException) {
            // This occurs only during service close, after preparation workers were interrupted.
            // Use a daemon fallback so cancel remains non-blocking and late connections are closed.
            Thread(cleanup, "RelayService-candidate-cleanup-after-close").apply {
                isDaemon = true
                start()
            }
        }
    }

    private fun releaseRelayCandidateSlot(candidate: RelayCandidateRegistration) {
        if (candidate.state.slotAcquired.get() &&
            candidate.state.slotReleased.compareAndSet(false, true)
        ) {
            activeRelayCandidateCount.decrementAndGet()
        }
    }

    private fun <T> failedFuture(failure: Throwable): CompletableFuture<T> =
        CompletableFuture<T>().also { it.completeExceptionally(failure) }

    /**
     * Registers with a relay to receive forwarded requests.
     *
     * @param relayPeerId The peer ID of the relay to register with.
     * @param services List of services we're advertising through this relay.
     * @param handler Handler for incoming relayed requests.
     * @return True if registration was successful.
     */
    fun registerWithRelay(
        relayPeerId: String,
        services: List<String> = emptyList(),
        handler: (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse
    ): Boolean = withRelayRegistrationTurn(relayRegistrationSerialization, peerId, relayPeerId) {
        reviseDesiredRelayServices(services)
        if (closed.get()) return@withRelayRegistrationTurn false

        val wrappedHandler = wrapWithChunking(handler)
        val intentGeneration = raceLifecycleLock.withLock {
            // Store one versioned intent for initial registration and every later recovery path.
            // unregisterFromRelay advances the same counter, so a worker that already captured
            // these fields cannot install or commit after that caller clears its intent.
            this.registeredRelayPeerId = relayPeerId
            this.requestHandler = wrappedHandler
            this.reconnectAttempts = 0
            this.currentReconnectDelayMs = baseReconnectDelayMs
            relayRegistrationIntentGeneration.incrementAndGet()
        }

        var registrationFailure: Throwable? = null
        val success = try {
            doRegisterWithRelay(relayPeerId, intentGeneration, reportsFailure = true)
        } catch (failure: Throwable) {
            registrationFailure = failure
            throw failure
        } finally {
            // Every explicit registration creates a new intent generation. Replace any task that
            // captured the preceding generation; that task deliberately will not reschedule itself. A
            // failed attempt still owns this generation, so it must also leave a replacement task behind.
            try {
                replaceReconnectionTask {
                    !closed.get() && relayRegistrationIntentGeneration.get() == intentGeneration
                }
            } catch (schedulingFailure: Throwable) {
                val primaryFailure = registrationFailure
                if (primaryFailure == null) throw schedulingFailure
                appendRelayCleanupFailure(primaryFailure, schedulingFailure)
            }
        }

        success
    }

    /**
     * Replaces the services advertised by this peer over its existing relay registration stream.
     * The relay applies the replacement before acknowledging it, so a successful return confirms
     * delivery without opening another libp2p connection or substream.
     *
     * @return `true` when the relay acknowledged the replacement, or `false` when there is no live
     * relay registration or the relay rejected it.
     */
    fun refreshRelayRegistrationAsync(services: List<String>): CompletableFuture<Boolean> =
        withRelayRegistrationTurn(
            relayRegistrationSerialization,
            peerId,
            registeredRelayPeerId ?: "none",
        ) {
            reviseDesiredRelayServices(services)
            val capturedRegistration = raceLifecycleLock.withLock {
                if (closed.get()) return@withRelayRegistrationTurn CompletableFuture.completedFuture(false)
                val connection = relayConnection ?: return@withRelayRegistrationTurn CompletableFuture.completedFuture(false)
                connection to relayRegistrationIntentGeneration.get()
            }
            return@withRelayRegistrationTurn sendLatestDesiredRelayRegistrationAsync(
                capturedRegistration.first,
                capturedRegistration.second,
                reportsFailure = true,
            )
        }

    // The lifecycle transaction reserves the request identity and acknowledgement state. The
    // returned post-commit action performs transport admission only after releasing the lock, so
    // close can claim and close this exact connection while the peer write is parked.
    private fun sendLatestDesiredRelayRegistrationAsync(
        connection: RelayConnection,
        expectedIntentGeneration: Long?,
        reportsFailure: Boolean,
    ): CompletableFuture<Boolean> {
        val afterCommit = raceLifecycleLock.withLock {
            if (closed.get() ||
                relayConnection !== connection ||
                expectedIntentGeneration != null &&
                    relayRegistrationIntentGeneration.get() != expectedIntentGeneration
            ) {
                return@withLock null
            }

            val revision = desiredRelayServices.get()
            val registrationSequence = relayRegistrationWireSequence.incrementAndGet()
            val request = RelayProtocol.RelayRegister(
                requestId = RelayProtocol.nextMessageId(),
                peerId = peerId,
                advertisedServices = revision.services,
                multiaddresses = ownRegistrationMultiaddresses(host, peerId)
            )
            val ackFuture = CompletableFuture<RelayProtocol.RelayRegisterAck>()
            val result = RelayRegistrationRefreshResult()
            val pendingAck = PendingRegistrationRefreshAck(connection, revision.services, ackFuture, result, reportsFailure)
            pendingRegistrationRefreshAcks[request.requestId] = pendingAck
            // Reserving the newer request transfers ownership of this shared stream before its
            // transport write begins. An older unregister may finish while that write is parked,
            // but it must no longer close the stream that the newer request needs for its ACK.
            if (registrationSequence > connection.latestStreamOwningRegistrationSequence) {
                connection.latestStreamOwningRegistrationRequestId = request.requestId
                connection.latestStreamOwningRegistrationSequence = registrationSequence
                // The newer registration owns this live stream and its first teardown claim.
                // An older unregister must not reserve that claim while it awaits its own ACK.
                releaseRelayRegistrationCloseFailureClaim(connection.closeState)
            }
            // [result] must be completed on every path this callback can take: doRegisterWithRelay
            // waits on it with an unbounded get(), so a callback that returned without completing
            // it would park that caller forever. orTimeout guarantees the callback runs; the catch
            // guarantees it always completes [result], even if abandoning the connection fails
            // unexpectedly. completeExceptionally is a no-op once [result] is already completed, so
            // it cannot override an outcome the body below already published.
            ackFuture.orTimeout(10, TimeUnit.SECONDS).whenComplete { ack, failure ->
                pendingRegistrationRefreshAcks.remove(request.requestId, pendingAck)
                var resultReserved = false
                try {
                    if (failure != null) {
                        resultReserved = reserveRelayRefreshFailure(result)
                        val reportedFailure = if (failure is TimeoutException) {
                            IllegalStateException(
                                "Timed out after 10000ms waiting for relay ${connection.relayPeerId} to " +
                                    "acknowledge the refreshed registration for peer $peerId with " +
                                    "services ${revision.services}",
                                failure
                            )
                        } else {
                            failure
                        }
                        val cleanupFailure = try {
                            abandonUnacknowledgedRelayConnection(connection, revision, resultReserved && reportsFailure)
                        } catch (abandonFailure: Throwable) {
                            abandonFailure
                        }
                        if (resultReserved) result.completeReservedFailure(
                            cleanupFailure?.let {
                                appendRelayCleanupFailure(reportedFailure, it)
                            } ?: reportedFailure
                        )
                    } else {
                        val committed = if (ack.success) {
                            commitAcknowledgedRelayConnection(
                                connection,
                                revision,
                                ack.requestId,
                                registrationSequence,
                                expectedIntentGeneration,
                            )
                        } else {
                            resultReserved = reserveRelayRefreshFailure(result)
                            val cleanupFailure = try {
                                abandonUnacknowledgedRelayConnection(connection, revision, resultReserved && reportsFailure)
                            } catch (abandonFailure: Throwable) {
                                abandonFailure
                            }
                            if (cleanupFailure == null) {
                                false
                            } else {
                                if (resultReserved) result.completeReservedFailure(cleanupFailure)
                                return@whenComplete
                            }
                        }
                        if (resultReserved) result.completeReservedValue(committed)
                        else result.complete(committed)
                    }
                } catch (callbackFailure: Throwable) {
                    // Rethrowing here would only populate the dependent stage nobody keeps, which
                    // discards the failure entirely. Surface it and hand it to the waiter instead.
                    debugLogErr {
                        "[RELAY-CLIENT] Handling the registration acknowledgement for relay " +
                            "${connection.relayPeerId} catalog revision ${revision.revision} failed: " +
                            "$callbackFailure"
                    }
                    if (resultReserved) result.completeReservedFailure(callbackFailure)
                    else result.completeExceptionally(callbackFailure)
                }
            }
            val action: () -> CompletableFuture<Boolean> = {
                try {
                    connection.sendMessage(request.toJson())
                } catch (e: Exception) {
                    pendingRegistrationRefreshAcks.remove(request.requestId, pendingAck)
                    val resultReserved = reserveRelayRefreshFailure(result)
                    val cleanupFailure = try {
                        abandonUnacknowledgedRelayConnection(connection, revision, resultReserved && reportsFailure)
                    } catch (abandonFailure: Throwable) {
                        abandonFailure
                    }
                    if (resultReserved) result.completeReservedFailure(
                        cleanupFailure?.let { appendRelayCleanupFailure(e, it) } ?: e
                    )
                    ackFuture.cancel(false)
                }
                result
            }
            action
        }
        return afterCommit?.invoke() ?: CompletableFuture.completedFuture(false)
    }

    /**
     * Fails every pending registration-refresh acknowledgement belonging to [connection], called
     * from the stream close observer and, as a fallback, from the relay listener loop's
     * `finally` on every exit path.
     *
     * Sweeping here must NOT be hoisted earlier in those exit paths, ahead of
     * [clearRelayConnectionState]: completing these futures runs their completion callback inline
     * on this thread, which nulls `relayConnection` and leaves `committedRelayCandidate` set, so
     * the subsequent clear no-ops and reconnection is refused forever. The call sites carry the
     * full explanation.
     *
     * The connection-identity filter is required because a retired listener can outlive selected
     * state while a newer generation adds its own pending refresh. A late close from the old stream
     * must complete only entries owned by that stream; this is covered by
     * `testRelayRefreshGenerationOwnershipSurvivesCrossGenerationCloses`.
     */
    private fun failRegistrationRefreshAcksForClosedConnection(
        connection: RelayConnection,
        closeFailure: Throwable? = null,
        prepareFailure: ((Boolean) -> Throwable?)? = null,
    ) {
        // Reserve both the private ACK and the public result before any caller callback runs.
        // A canceled or internal Boolean-only result cannot carry a report. A reserved public result
        // can no longer be canceled by a sibling callback after the listener consumes its cleanup detail.
        var reportedFailure = closeFailure
        val acknowledgements = raceLifecycleLock.withLock {
            val claimed = pendingRegistrationRefreshAcks.entries.mapNotNull { entry ->
                val pendingAck = entry.value
                if (pendingAck.connection === connection &&
                    pendingRegistrationRefreshAcks.remove(entry.key, pendingAck)
                ) pendingAck to reserveRelayRefreshFailure(pendingAck.result) else null
            }
            if (prepareFailure != null) {
                reportedFailure = prepareFailure(claimed.any { it.second && it.first.reportsFailure })
            }
            claimed
        }
        acknowledgements.forEach { (pendingAck, resultReserved) ->
            val failure = reportedFailure ?: connection.closeObserverFailure.get() ?: IllegalStateException(
                "Relay ${connection.relayPeerId} closed its registration stream before " +
                    "acknowledging the refreshed registration for peer $peerId with " +
                    "services ${pendingAck.services}."
            )
            if (resultReserved) pendingAck.result.completeReservedFailure(failure)
            pendingAck.acknowledgement.completeExceptionally(failure)
        }
    }

    private fun observeRelayConnectionClosed(connection: RelayConnection) {
        var observerFailure: Throwable? = null
        try {
            relayCloseObserverTestHook.getAndSet(null)?.invoke()
        } catch (failure: Throwable) {
            observerFailure = failure
        }
        // A close callback can arrive while the listener is parked on the bounded handler-permit
        // wait, or after another path has already cleared relayConnection. Stop only the task
        // references owned by this exact stream. Retirement closes even a logically failed
        // generation; late observers must still leave replacement tasks untouched.
        var detachedTasks: DetachedRelayTasks? = null
        try {
            detachedTasks = detachRelayTasksForClosedConnection(connection)
        } catch (failure: Throwable) {
            observerFailure = appendRelayCleanupFailure(observerFailure, failure)
        }
        // Clear the active connection before completing an acknowledgement. The completion
        // callback runs inline and may try to abandon the failed connection; after this clear it
        // can no longer mistake that callback for the owner of the current relay generation.
        try {
            clearRelayConnectionState(connection)
        } catch (failure: Throwable) {
            observerFailure = appendRelayCleanupFailure(observerFailure, failure)
        }
        // Let either cleanup path preserve this connection's known cause. Do not complete any
        // caller future before signalling the listener: a caller callback may wait for its exit.
        observerFailure?.let { connection.closeObserverFailure.compareAndSet(null, it) }
        try {
            detachedTasks?.let(::signalDetachedRelayTasks)
        } catch (failure: Throwable) {
            observerFailure = appendRelayCleanupFailure(observerFailure, failure)
        }
        try {
            val listenerOwnsSettlement = raceLifecycleLock.withLock {
                connection.failedListenerOwnsSettlement
            }
            // A failing listener closes its transport before publishing its outcome. That local
            // close re-enters this observer; let the listener include transport-close details
            // before any refresh callback sees the result. Other close observations stay prompt.
            if (!listenerOwnsSettlement) {
                failRegistrationRefreshAcksForClosedConnection(connection, observerFailure)
            }
        } catch (failure: Throwable) {
            observerFailure = appendRelayCleanupFailure(observerFailure, failure)
        }
        try {
            relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
        } catch (failure: Throwable) {
            observerFailure = appendRelayCleanupFailure(observerFailure, failure)
        }
        observerFailure?.let { throw it }
    }

    private fun runRelayCloseObserver(connection: RelayConnection) {
        observeRelayConnectionClosed(connection)
    }

    fun refreshRelayRegistration(services: List<String>): Boolean {
        return try {
            refreshRelayRegistrationAsync(services).get()
        } catch (e: java.util.concurrent.ExecutionException) {
            throw (e.cause ?: e)
        }
    }

    /**
     * Internal method to perform the actual relay registration.
     * Called both for initial registration and reconnection.
     */
    private fun doRegisterWithRelay(
        relayPeerId: String,
        expectedIntentGeneration: Long,
        reportsFailure: Boolean,
    ): Boolean = withRelayRegistrationTurn(relayRegistrationSerialization, peerId, relayPeerId) {
        if (relayRegistrationIntentGeneration.get() != expectedIntentGeneration) return@withRelayRegistrationTurn false
        // Immediate recovery and scheduled recovery share one transaction turn with public
        // registration. Contenders await its completion interruptibly, outside every state lock.
        // The winner owns dial/register/listener installation until its finally releases the turn;
        // a later same-relay caller then uses that live stream and the latest desired catalog.
        // Find the relay peer in registry
        var relayPeer = peerRegistry.getPeer(relayPeerId)
        var effectiveRelayPeerId = relayPeerId

        // If relay peer not found, try to re-discover via alternativeRelaySelector
        // This handles the case where the peer entry has expired from the registry
        // during a reconnection attempt (bug #136)
        if (relayPeer == null) {
            val alternativePeer = alternativeRelaySelector?.invoke()
            if (alternativePeer != null) {
                debugLog { "[RELAY-DEBUG] Relay peer $relayPeerId not in registry, using alternativeRelaySelector to re-discover" }
                // Create a Libp2pPeer from the PeerInfo and add to registry
                val recoveredPeer = Libp2pPeer.remote(
                    peerId = alternativePeer.peerId,
                    multiaddresses = alternativePeer.multiaddresses,
                    advertisedServices = alternativePeer.advertisedServices
                )
                peerRegistry.addPeer(recoveredPeer, origin = PeerRegistryAddOrigin.RELAY)

                // If the selector returned the same relay we were looking for, use it
                // If it returned a different relay, update our target and use that instead
                relayPeer = recoveredPeer
                if (alternativePeer.peerId != relayPeerId) {
                    debugLog { "[RELAY-DEBUG] alternativeRelaySelector provided different relay: ${alternativePeer.peerId}" }
                    // Update the registered relay peer ID for future reconnection attempts
                    val alternativeInstalled = raceLifecycleLock.withLock {
                        if (relayRegistrationIntentGeneration.get() != expectedIntentGeneration) {
                            false
                        } else {
                            registeredRelayPeerId = alternativePeer.peerId
                            true
                        }
                    }
                    if (!alternativeInstalled) {
                        return@withRelayRegistrationTurn false
                    }
                    effectiveRelayPeerId = alternativePeer.peerId
                }
            }
        }

        if (relayPeer == null) {
            throw IllegalArgumentException("Relay peer $relayPeerId not found in registry")
        }

        // Resolve a missing registry entry before treating an existing stream as a no-op. The
        // registry entry is independently expirable state: a healthy stream does not prove that a
        // later reconnect can still resolve its relay. Re-running the selector here restores that
        // state, and if the selector deliberately chooses a different relay we must replace the old
        // stream rather than returning early against the original peer ID.
        val activeGeneration = raceLifecycleLock.withLock {
            relayConnection?.let { connection ->
                connection to (relayConnectionGenerationOwner.get() ?: connection)
            }
        }
        val activeConnection = activeGeneration?.first
        if (activeConnection != null &&
            !activeConnection.isClosed() &&
            activeConnection.relayPeerId == effectiveRelayPeerId
        ) {
            val desiredRevision = desiredRelayServices.get()
            // The acknowledgement has its existing ten-second deadline. The transaction owns
            // its turn while awaiting it, but holds no lock; contenders can leave on interruption
            // and close can settle this exact connection through the lifecycle guard.
            return@withRelayRegistrationTurn committedRelayServices.get().revision >= desiredRevision.revision ||
                try {
                    sendLatestDesiredRelayRegistrationAsync(
                        activeConnection,
                        expectedIntentGeneration,
                        reportsFailure,
                    ).get()
                } catch (e: ExecutionException) {
                    throw (e.cause ?: e)
                }
        }

        // Retire a different relay before opening its replacement. Keeping the first stream until
        // the replacement ACK would avoid a connectivity gap, but it would leave two relays able
        // to route to this client during the handoff. Early retirement gives replacement one
        // lifecycle boundary: if the new relay rejects registration, the old relay has already
        // acknowledged unregister (or observed its stream close) and cannot retain a dead route.
        //
        // The exact captured connection is passed through retirement. Every state clear compares
        // object identity under raceLifecycleLock, and only that captured object is closed, so a
        // newer connection can never be cleared or closed by stale replacement cleanup.
        activeGeneration?.let { (connection, generationOwner) ->
            retireRelayConnectionForReplacement(connection, generationOwner, reportsFailure)
        }

        val registrationAttemptOwner = Any()
        val registrationAdmission = raceLifecycleLock.withLock {
            // close() advances the same intent generation while holding this lock, so a separate
            // closed-state check here would duplicate this generation check without excluding an
            // additional execution.
            if (relayRegistrationIntentGeneration.get() != expectedIntentGeneration ||
                registeredRelayPeerId != effectiveRelayPeerId ||
                requestHandler == null ||
                relayConnection != null ||
                committedRelayCandidate.get() != null
            ) {
                false to null
            } else {
                // Reserve this exact ordinary dial generation before touching shared listener
                // state. Candidate commit remains free to replace the reservation while network
                // I/O is in flight; the install check below then rejects this older dial.
                relayConnectionGenerationOwner.set(registrationAttemptOwner)
                // The old listener remains active long enough to receive the unregister ACK above.
                // Stop it only after retirement and while candidate installation is excluded.
                true to detachListenerAndKeepalive()
            }
        }
        val (registrationAttemptAdmitted, detachedRegistrationTasks) = registrationAdmission
        detachedRegistrationTasks?.let(::cleanupDetachedRelayTasks)
        if (!registrationAttemptAdmitted) return@withRelayRegistrationTurn false

        var attemptedConnection: RelayConnection? = null
        fun cleanupFailedRegistrationAttempt(): Throwable? {
            var cleanupFailure: Throwable? = null
            val attempted = attemptedConnection
            val captured = attempted?.let { connection ->
                raceLifecycleLock.withLock {
                    CapturedRelayRegistrationClose(
                        connection.closeState,
                        if (reportsFailure) claimRelayRegistrationCloseFailure(connection.closeState) else null,
                    )
                }
            }
            try {
                if (attempted == null) {
                    relayConnectionGenerationOwner.compareAndSet(registrationAttemptOwner, null)
                } else if (clearRelayConnectionState(attempted)) {
                    relayConnectionGenerationOwner.compareAndSet(attempted, null)
                } else {
                    relayConnectionGenerationOwner.compareAndSet(registrationAttemptOwner, null)
                }
            } catch (failure: Throwable) {
                cleanupFailure = appendRelayCleanupFailure(cleanupFailure, failure)
            }
            try {
                captured?.let { closeRelayRegistration(it.state, 0L, false, it.claim) }
            } catch (failure: Throwable) {
                cleanupFailure = appendRelayCleanupFailure(cleanupFailure, failure)
            } finally {
                captured?.let(::releaseCapturedRelayRegistrationClose)
            }
            return cleanupFailure
        }
        return@withRelayRegistrationTurn try {
            // Connect to the relay
            val connection = connectToRelay(relayPeer)
            attemptedConnection = connection

            // Get our effective addresses (with PUBLIC_IP substitution if set).
            // getEffectiveAddresses filters out BOTH wildcard (0.0.0.0 when no public
            // IP has been discovered via Identify yet) AND loopback (127.0.0.1)
            // addresses, so on a freshly-started node — or any node bound only to a
            // loopback/wildcard interface — it returns an EMPTY list. Registering with
            // an empty multiaddress list poisons every downstream sink that records the
            // peer: the relay's gossip handler publishes an address-less, unusable
            // service entry into discoveredServices, peerRegistry stores an address-less
            // peer that peer-exchange then re-shares, and forwarded ServiceAnnouncements
            // carry empty addresses. Fall back to loopback-derived addresses (the same
            // localhost fallback UrlResolver.getAnnounceAddresses applies to its gossip
            // announcements) so the registration is never address-less. The relay
            // additionally augments this with a circuit-relay address for external
            // reachability; see handleRegister.
            val ownMultiaddresses = ownRegistrationMultiaddresses(host, peerId)
            val desiredRevision = desiredRelayServices.get()

            // Send registration request with our multiaddresses
            val registrationSequence = relayRegistrationWireSequence.incrementAndGet()
            val request = RelayProtocol.RelayRegister(
                requestId = RelayProtocol.nextMessageId(),
                peerId = peerId,
                advertisedServices = desiredRevision.services,
                multiaddresses = ownMultiaddresses,
                // The registration is an authoritative provider snapshot. Reserve its timestamp
                // from the same allocator as announcements and withdrawals so every event
                // captured before this snapshot is <= it and every later lifecycle event is > it,
                // even when the wall clock freezes or moves backward.
                timestamp = reserveProviderLifecycleTimestamp(clock, peerId)
            )

            val registrationInstalled = raceLifecycleLock.withLock {
                if (closed.get() ||
                    relayRegistrationIntentGeneration.get() != expectedIntentGeneration ||
                    relayConnection != null ||
                    committedRelayCandidate.get() != null ||
                    relayConnectionGenerationOwner.get() !== registrationAttemptOwner
                ) {
                    false
                } else {
                    // A replacement is not publicly connected until this exact stream's
                    // registration acknowledgement is committed below.
                    relayConnection = connection
                    relayRegistrationCloseState = carryRelayRegistrationCloseFailures(
                        relayRegistrationCloseState, connection.closeState,
                    )
                    connectedRelayPeerId = null
                    relayConnectionGenerationOwner.set(connection)
                    true
                }
            }
            if (!registrationInstalled) {
                connection.close()
                return@withRelayRegistrationTurn false
            }
            // Network admission remains outside the lifecycle guard. If close wins after
            // installation, it clears and closes this exact connection; this write then fails and
            // the catch path performs an expected-connection clear without touching newer state.
            connection.sendMessage(request.toJson())

            // Wait for acknowledgement. Read messages until we receive the ACK,
            // skipping any non-ACK messages that may arrive on the relay connection.
            // This defensive handling protects against edge cases where gossip messages
            // could theoretically be forwarded through the relay controller before the ACK.
            var ack: RelayProtocol.RelayRegisterAck? = null
            val deadline = System.currentTimeMillis() + 10_000
            while (ack == null) {
                val remainingMs = deadline - System.currentTimeMillis()
                if (remainingMs <= 0) {
                    throw IllegalStateException("Timed out waiting for relay registration ACK")
                }
                val response = connection.readMessage(remainingMs, TimeUnit.MILLISECONDS)
                    ?: throw IllegalStateException("No response from relay")
                val type = response.optString("type", "")
                if (type == RelayProtocol.TYPE_RELAY_REGISTER_ACK) {
                    ack = RelayProtocol.RelayRegisterAck.fromJson(response)
                } else {
                    // Non-ACK message received before ACK - skip it.
                    // This can happen if a concurrent gossip broadcast forwarded a message
                    // through the relay controller before the ACK was sent.
                    debugLog { "[RELAY-CLIENT] Skipping non-ACK message (type=$type) while waiting for registration ACK" }
                }
            }

            val registrationAcknowledged =
                ack.success && commitAcknowledgedRelayConnection(
                    connection,
                    desiredRevision,
                    ack.requestId,
                    registrationSequence,
                    expectedIntentGeneration,
                )
            if (registrationAcknowledged) {
                // Listener/keepalive installation uses taskLock to serialize with teardown and
                // rechecks exact connection ownership before publishing either task. Transport
                // fan-out then runs after the lifecycle transaction, so a concurrent close or
                // unregister can claim the acknowledged connection without waiting for the write.
                startRequestListener(connection)
                val routePublished = raceLifecycleLock.withLock {
                    if (closed.get() ||
                        relayConnection !== connection ||
                        relayConnectionGenerationOwner.get() !== connection
                    ) {
                        false
                    } else {
                        routingTable.addNeighbor(effectiveRelayPeerId, connection.controller)
                        reconnectAttempts = 0
                        currentReconnectDelayMs = baseReconnectDelayMs
                        true
                    }
                }
                if (routePublished) {
                    updateLocalLinkStateAdvertisement()
                    // startRequestListener starts its reader asynchronously. Let it enter the
                    // stream read path before keepalive samples the injected clock, which may
                    // re-enter the service and close this acknowledged relay.
                    startKeepalive(connection)
                }
                routePublished &&
                    raceLifecycleLock.withLock {
                        !closed.get() &&
                            relayConnection === connection &&
                            relayConnectionGenerationOwner.get() === connection &&
                            relayRegistrationIntentGeneration.get() == expectedIntentGeneration
                    }
            } else {
                cleanupFailedRegistrationAttempt()?.let { throw it }
                false
            }
        } catch (e: InterruptedException) {
            cleanupFailedRegistrationAttempt()?.let { appendRelayCleanupFailure(e, it) }
            Thread.currentThread().interrupt()
            throw e
        } catch (e: Exception) {
            cleanupFailedRegistrationAttempt()?.let { appendRelayCleanupFailure(e, it) }
            throw e
        }
    }

    /**
     * Unregisters and closes the exact relay connection displaced by a replacement attempt.
     *
     * Registration replacement must not call [unregisterFromRelay]: that public operation also
     * clears desired services, the request handler, and reconnection intent. This narrower
     * retirement keeps those replacement inputs while giving the old relay an explicit unregister
     * boundary. If unregister delivery or acknowledgement fails, closing the same stream still
     * lets the remote relay remove the registration through its stream-close lifecycle.
     */
    private fun retireRelayConnectionForReplacement(
        connection: RelayConnection,
        generationOwner: Any,
        reportsFailure: Boolean,
        flushTimeoutMs: Long = 1000L
    ) {
        val registrationClose = raceLifecycleLock.withLock {
            CapturedRelayRegistrationClose(
                connection.closeState,
                if (reportsFailure) claimRelayRegistrationCloseFailure(connection.closeState) else null,
            )
        }
        var retirementFailure: Throwable? = null
        var acknowledgementFuture: CompletableFuture<RelayProtocol.RelayUnregisterAck>? = null
        var requestId: String? = null
        try {
            val request = RelayProtocol.RelayUnregister(
                requestId = RelayProtocol.nextMessageId(),
                peerId = peerId
            )
            requestId = request.requestId
            val future = CompletableFuture<RelayProtocol.RelayUnregisterAck>()
            acknowledgementFuture = future

            val reserved = raceLifecycleLock.withLock {
                if (closed.get() || relayConnection !== connection) {
                    false
                } else {
                    pendingUnregisterAcks[request.requestId] = future
                    true
                }
            }
            val admitted = reserved && connection.sendMessage(request.toJson(), flushTimeoutMs)
            if (admitted) {
                val acknowledgement = CompletableFuture.anyOf(
                    future,
                    connection.controller.responseEnded,
                ).get(flushTimeoutMs, TimeUnit.MILLISECONDS) as RelayProtocol.RelayUnregisterAck
                if (!acknowledgement.success) {
                    throw RelayException(
                        "Relay ${acknowledgement.relayPeerId} rejected unregister request " +
                            "${acknowledgement.requestId} for peer $peerId during replacement: " +
                            (acknowledgement.errorMessage ?: "no error message was provided")
                    )
                }
            }
        } catch (failure: Throwable) {
            val normalizedFailure = when (failure) {
                is TimeoutException -> RelayException(
                    "Timed out after ${flushTimeoutMs}ms waiting for relay ${connection.relayPeerId} " +
                        "to acknowledge unregister request $requestId for peer $peerId during replacement",
                    failure
                )
                is ExecutionException -> failure.cause ?: failure
                else -> failure
            }
            val streamDepartureOwnsCleanup =
                connection.responsePathIsGone() &&
                    (failure is TimeoutException || failure is ExecutionException)
            if (!streamDepartureOwnsCleanup) retirementFailure = normalizedFailure
        } finally {
            requestId?.let { pendingUnregisterAcks.remove(it, acknowledgementFuture) }
            var detachedTasks: DetachedRelayTasks? = null
            var connectionCleared = false
            val routeRemoved = raceLifecycleLock.withLock {
                val ownsCurrentConnection = relayConnection === connection
                val ownsAlreadyClearedGeneration =
                    relayConnection == null &&
                        relayConnectionGenerationOwner.get() === generationOwner
                if (ownsCurrentConnection || ownsAlreadyClearedGeneration) {
                    // Detach the old generation's exact tasks before releasing ownership. Their
                    // cancellation and join run after this state transaction releases the lock.
                    detachedTasks = detachListenerAndKeepalive()
                    if (ownsCurrentConnection) {
                        relayConnection = null
                        connectedRelayPeerId = null
                        committedRelayCandidate.get()?.let { candidate ->
                            if (candidate.state.connection.get() === connection) {
                                committedRelayCandidate.compareAndSet(candidate, null)
                            }
                        }
                        connectionCleared = true
                    }
                    relayConnectionGenerationOwner.compareAndSet(generationOwner, null)
                    routingTable.removeNeighbor(connection.relayPeerId)
                    true
                } else {
                    false
                }
            }
            detachedTasks?.let(::cleanupDetachedRelayTasks)
            if (connectionCleared) {
                relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
            }
            if (routeRemoved) updateLocalLinkStateAdvertisement()
            try {
                closeRelayRegistration(
                    registrationClose.state, flushTimeoutMs, false, registrationClose.claim,
                )
            } catch (closeFailure: Throwable) {
                retirementFailure = appendRelayCleanupFailure(retirementFailure, closeFailure)
            } finally {
                releaseCapturedRelayRegistrationClose(registrationClose)
            }
        }

        val failure = retirementFailure
        if (failure is InterruptedException) {
            Thread.currentThread().interrupt()
            throw failure
        }
        failure?.let { throw it }
    }

    /** Detaches task ownership without waiting for any task or listener to finish. */
    private fun detachListenerAndKeepalive(): DetachedRelayTasks = taskLock.withLock {
        DetachedRelayTasks(
            keepalive = keepaliveTask,
            listenerStopSignal = listenerStopSignal,
            listenerThread = listenerThread,
        ).also {
            keepaliveTask = null
            keepaliveConnection = null
            listenerStopSignal = null
            listenerThread = null
            listenerConnection = null
        }
    }

    /** Detaches only the task references owned by [connection], preserving a newer generation. */
    private fun detachRelayTasksForClosedConnection(
        connection: RelayConnection,
    ): DetachedRelayTasks? = taskLock.withLock {
        val ownsKeepalive = keepaliveConnection === connection
        val ownsListener = listenerConnection === connection
        if (!ownsKeepalive && !ownsListener) return@withLock null

        DetachedRelayTasks(
            keepalive = if (ownsKeepalive) keepaliveTask else null,
            listenerStopSignal = if (ownsListener) listenerStopSignal else null,
            listenerThread = if (ownsListener) listenerThread else null,
        ).also {
            if (ownsKeepalive) {
                keepaliveTask = null
                keepaliveConnection = null
            }
            if (ownsListener) {
                listenerStopSignal = null
                listenerThread = null
                listenerConnection = null
            }
        }
    }

    /** Signals detached work without joining, which is safe on a transport event-loop thread. */
    private fun signalDetachedRelayTasks(tasks: DetachedRelayTasks) {
        tasks.keepalive?.cancel(false)
        tasks.listenerStopSignal?.set(true)
        tasks.listenerThread?.let { listener ->
            listener.interrupt()
            relayListenerInterruptedTestSeam?.invoke()
        }
    }

    /** Performs cancellation and the bounded listener join after lifecycle-lock release. */
    private fun cleanupDetachedRelayTasks(tasks: DetachedRelayTasks) {
        signalDetachedRelayTasks(tasks)
        tasks.listenerThread?.let { thread ->
            try {
                thread.join(500)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
    }

    /**
     * Unregisters from the current relay.
     *
     * When the response path remains live, sends a [RelayProtocol.RelayUnregister] and waits for
     * the matching [RelayProtocol.RelayUnregisterAck] before tearing the connection down. If the
     * response path has already ended, or ends while the request or acknowledgement is in flight,
     * the stream-close lifecycle owns relay-side cleanup and this method completes after bounded
     * local teardown; relay-side removal may still be finishing asynchronously. A later
     * registration generation that reused the same live stream is preserved.
     *
     * @param flushTimeoutMs finite budget used independently for unregister transport admission,
     *                       remote acknowledgement, and final transport flushing. Defaults to 1 s.
     */
    fun unregisterFromRelay(flushTimeoutMs: Long = 1000L) {
        var registrationClose: CapturedRelayRegistrationClose? = null
        var reconnectToCancel: RelayReconnectTask? = null
        val capturedGeneration = withRelayRegistrationTurn(
            relayRegistrationSerialization, peerId, registeredRelayPeerId ?: "none",
        ) {
            reviseDesiredRelayServices(emptyList())
            // Stop the never-give-up reconnection task BEFORE tearing down the connection.
            // registerWithRelay schedules a background reconnect task that fires
            // every baseReconnectDelayMs and re-registers whenever relayConnection == null. If we
            // only closed the connection, that task would observe the null connection with the
            // registration state (registeredRelayPeerId / requestHandler) still populated and
            // silently RE-REGISTER the peer we are intentionally unregistering — the intentional
            // unregister would be undone ~5s later. Cancel the task, clear the registration state,
            // and advance the intent generation so a reconnect already in flight cannot install its
            // stale result. Mirrors close()'s task teardown, but leaves the executor running so the
            // service remains reusable (a later registerWithRelay restarts the task).
            committedRelayServices.set(RelayCatalogRevision(revision = 0L, services = emptyList()))
            raceLifecycleLock.withLock {
                registrationClose = relayRegistrationCloseState?.let { state ->
                    CapturedRelayRegistrationClose(state, claimRelayRegistrationCloseFailure(state))
                }
                reconnectToCancel = taskLock.withLock {
                    reconnectionTask.also { reconnectionTask = null }
                }
                relayRegistrationIntentGeneration.incrementAndGet()
                registeredRelayPeerId = null
                requestHandler = null
                relayConnection?.let { current ->
                    CapturedRelayUnregister(
                        current,
                        relayConnectionGenerationOwner.get() ?: current,
                        current.latestStreamOwningRegistrationRequestId,
                    )
                }.also { captured ->
                    val current = captured?.connection
                    if (current == null) {
                        connectedRelayPeerId = null
                        committedRelayCandidate.set(null)
                        relayConnectionGenerationOwner.set(null)
                    }
                }
            }
        }
        // Reserve the outcome above before invoking supplied cancellation code. Detach the
        // schedule under taskLock, then cancel outside both locks so reentry sees that claim.
        var cancellationFailure: Throwable? = null
        try {
            reconnectToCancel?.cancel(false)
        } catch (failure: Throwable) {
            cancellationFailure = failure
        }
        if (capturedGeneration == null) {
            var failure = cancellationFailure
            registrationClose?.let { captured ->
                try {
                    closeRelayRegistration(captured.state, flushTimeoutMs, false, captured.claim)
                } catch (closeFailure: Throwable) {
                    failure = appendRelayCleanupFailure(failure, closeFailure)
                } finally {
                    releaseCapturedRelayRegistrationClose(captured)
                }
            }
            failure?.let { throw it }
            return
        }
        val (connection, connectionGenerationOwner, registrationRequestId) = capturedGeneration
        var sendFailure: Throwable? = cancellationFailure
        var ackFuture: CompletableFuture<RelayProtocol.RelayUnregisterAck>? = null
        var requestId: String? = null
        var ownsTargetRegistration = false
        fun recordFailure(failure: Throwable) {
            sendFailure = appendRelayCleanupFailure(sendFailure, failure)
        }
        try {
            val request = RelayProtocol.RelayUnregister(
                requestId = RelayProtocol.nextMessageId(),
                peerId = peerId,
                registrationRequestId = registrationRequestId,
            )
            requestId = request.requestId
            ackFuture = CompletableFuture()
            pendingUnregisterAcks[request.requestId] = ackFuture
            // Admission already detects a terminal stream. Its failure and a terminal ACK wait
            // share the ownership classification below, so there is no separate early-close path.
            if (!connection.sendMessage(request.toJson(), flushTimeoutMs)) {
                throw RelayException(relayMessageNotAdmittedMessage(flushTimeoutMs))
            }
            val acknowledgement = CompletableFuture.anyOf(
                ackFuture,
                connection.controller.responseEnded,
            ).get(flushTimeoutMs, TimeUnit.MILLISECONDS) as RelayProtocol.RelayUnregisterAck
            if (!acknowledgement.success) {
                throw RelayException(
                    "Relay ${acknowledgement.relayPeerId} rejected unregister request " +
                        "${acknowledgement.requestId} for peer $peerId: " +
                        (acknowledgement.errorMessage ?: "no error message was provided")
                )
            }
        } catch (failure: Throwable) {
            val normalizedFailure = when (failure) {
                is TimeoutException -> RelayException(
                    "Timed out after ${flushTimeoutMs}ms waiting for relay ${connection.relayPeerId} " +
                        "to acknowledge unregister request $requestId for peer $peerId"
                )
                is ExecutionException -> failure.cause ?: failure
                else -> failure
            }
            val streamDepartureOwnsCleanup =
                connection.responsePathIsGone() &&
                    (failure is TimeoutException ||
                        failure is ExecutionException ||
                        failure is RelayException &&
                            failure.message == relayMessageNotAdmittedMessage(flushTimeoutMs))
            if (streamDepartureOwnsCleanup) {
                debugLogErr {
                    "[RELAY-CLIENT] Unregister completed by stream departure; remote stream-close " +
                        "cleanup owns the captured registration. Dropped failure: " +
                        "${normalizedFailure.javaClass.name}: ${normalizedFailure.message}"
                }
            } else {
                recordFailure(normalizedFailure)
            }
        } finally {
            try {
                requestId?.let { pendingUnregisterAcks.remove(it, ackFuture) }
            } catch (failure: Throwable) {
                recordFailure(failure)
            }
            var detachedTasks: DetachedRelayTasks? = null
            var connectionCleared = false
            var routeRemoved = false
            try {
                routeRemoved = raceLifecycleLock.withLock {
                    val ownsCurrentConnection =
                        relayConnection === connection &&
                            connection.latestStreamOwningRegistrationRequestId == registrationRequestId
                    val ownsAlreadyClearedGeneration =
                        relayConnection == null &&
                            relayConnectionGenerationOwner.get() === connectionGenerationOwner &&
                            connection.latestStreamOwningRegistrationRequestId == registrationRequestId
                    ownsTargetRegistration = ownsCurrentConnection || ownsAlreadyClearedGeneration
                    if (ownsCurrentConnection || ownsAlreadyClearedGeneration) {
                        try {
                            detachedTasks = detachListenerAndKeepalive()
                        } catch (failure: Throwable) {
                            recordFailure(failure)
                        }
                        if (ownsCurrentConnection) {
                            relayConnection = null
                            connectedRelayPeerId = null
                            committedRelayCandidate.get()?.let { candidate ->
                                if (candidate.state.connection.get() === connection) {
                                    committedRelayCandidate.compareAndSet(candidate, null)
                                }
                            }
                            connectionCleared = true
                        }
                        relayConnectionGenerationOwner.compareAndSet(
                            connectionGenerationOwner,
                            null,
                        )
                        try {
                            routingTable.removeNeighbor(connection.relayPeerId)
                        } catch (failure: Throwable) {
                            recordFailure(failure)
                        }
                        true
                    } else {
                        false
                    }
                }
            } catch (failure: Throwable) {
                recordFailure(failure)
            }
            try {
                detachedTasks?.let(::cleanupDetachedRelayTasks)
            } catch (failure: Throwable) {
                recordFailure(failure)
            }
            if (connectionCleared) {
                try {
                    relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
                } catch (failure: Throwable) {
                    recordFailure(failure)
                }
            }
            if (routeRemoved) {
                try {
                    updateLocalLinkStateAdvertisement()
                } catch (failure: Throwable) {
                    recordFailure(failure)
                }
            }
            val captured = registrationClose
            val preserveReusedStream = if (!ownsTargetRegistration && captured != null) {
                raceLifecycleLock.withLock {
                    if (!closed.get() && relayConnection?.closeState === captured.state) {
                        // Stream ownership and the new registration's claim moved together.
                        // This stale unregister must preserve that live stream and its claimant.
                        true
                    } else false
                }
            } else false
            if (ownsTargetRegistration || closed.get() || captured != null && !preserveReusedStream) {
                try {
                    if (captured != null) {
                        closeRelayRegistration(captured.state, flushTimeoutMs, false, captured.claim)
                    } else {
                        connection.retire()
                    }
                } catch (failure: Throwable) {
                    recordFailure(failure)
                } finally {
                    captured?.let(::releaseCapturedRelayRegistrationClose)
                }
            }
        }
        if (sendFailure is InterruptedException) Thread.currentThread().interrupt()
        sendFailure?.let { throw it }
    }

    /**
     * Stops registration admission and queues a terminal reply for each unfinished accepted
     * request, followed by unregister on the same ordered outbox. Returns without waiting for
     * handlers, transport writes or an acknowledgement. The returned future reports completion
     * of the local unregister write and retirement, or their failure.
     *
     * [finalResponse] runs on this caller outside lifecycle and outbox locks. It must return a
     * reply for the supplied request, retaining that request's correlation and peer identities.
     * As with handler replies, not-dispatched metadata is removed: this request was accepted
     * and its handler may already have run.
     * A handler that has already consumed its response reservation keeps its own reply; a late
     * result after the close reply consumes the reservation is discarded.
     */
    fun unregisterFromRelay(
        finalResponse: (RelayProtocol.RelayRequest) -> RelayProtocol.RelayResponse,
    ): CompletableFuture<Unit> {
        val result = CompletableFuture<Unit>()
        var registrationClose: CapturedRelayRegistrationClose? = null
        var detached: DetachedRelayTasks? = null
        var reconnect: RelayReconnectTask? = null
        var accepted = emptyList<Pair<AwaitedResponseFailureReservation, RelayProtocol.RelayRequest>>()
        val connection = raceLifecycleLock.withLock {
            reviseDesiredRelayServices(emptyList())
            committedRelayServices.set(RelayCatalogRevision(revision = 0L, services = emptyList()))
            relayRegistrationIntentGeneration.incrementAndGet()
            registeredRelayPeerId = null
            requestHandler = null
            reconnect = taskLock.withLock { reconnectionTask.also { reconnectionTask = null } }
            relayConnection?.also { current ->
                registrationClose = CapturedRelayRegistrationClose(
                    current.closeState, claimRelayRegistrationCloseFailure(current.closeState),
                )
                current.orderedUnregisterInProgress.set(true)
                accepted = current.sealRegisteredRequests()
                detached = detachListenerAndKeepalive()
                relayConnection = null
                connectedRelayPeerId = null
                committedRelayCandidate.get()?.let { candidate ->
                    if (candidate.state.connection.get() === current) committedRelayCandidate.compareAndSet(candidate, null)
                }
                relayConnectionGenerationOwner.set(null)
                routingTable.removeNeighbor(current.relayPeerId)
            }
        }
        if (connection == null) {
            try {
                reconnect?.cancel(false)
                result.complete(Unit)
            } catch (failure: Throwable) {
                result.completeExceptionally(failure)
            }
            return result
        }
        val finished = AtomicBoolean(false)
        val finish: (Throwable?) -> Unit = { writeFailure ->
            if (finished.compareAndSet(false, true)) {
                var failure = writeFailure
                fun cleanup(action: () -> Unit) {
                    try { action() } catch (later: Throwable) {
                        failure = appendRelayCleanupFailure(failure, later)
                    }
                }
                connection.orderedUnregisterInProgress.set(false)
                cleanup { detached?.let(::signalDetachedRelayTasks) }
                cleanup { connection.retire() }
                accepted.forEach { (reservation, _) ->
                    cleanup { reservation.outbox.releaseFailureReservation(reservation) }
                }
                cleanup { relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection) }
                val captured = checkNotNull(registrationClose)
                val operation = captured.state.operation.get()
                checkNotNull(operation).outcome.whenComplete { _, operationFailure ->
                    cleanup { operationFailure?.let { throw it } }
                    cleanup { takeRelayRegistrationCloseFailure(captured.state, captured.claim)?.let { throw it } }
                    fun completeAfterStreamClose(streamCloseFailure: Throwable?) {
                        cleanup { streamCloseFailure?.let { throw it } }
                        releaseCapturedRelayRegistrationClose(captured)
                        if (failure == null) result.complete(Unit) else result.completeExceptionally(failure!!)
                    }
                    val streamClose = connection.controller.streamCloseCompletion
                    if (streamClose == null) completeAfterStreamClose(null)
                    else streamClose.whenComplete { _, streamCloseFailure ->
                        completeAfterStreamClose(streamCloseFailure)
                    }
                }
            }
        }
        try {
            reconnect?.cancel(false)
            detached?.keepalive?.cancel(false)
            connection.controller.responseEnded.whenComplete { _, failure ->
                if (!finished.get()) finish(failure ?: RelayException("Relay registration ended before unregister completed"))
            }
            accepted.forEach { (reservation, request) ->
                val response = finalResponse(request).withoutNotDispatchedMarker()
                require(response.requestId == request.requestId &&
                    response.sourcePeerId == request.targetPeerId && response.targetPeerId == request.sourcePeerId) {
                    "Close reply for accepted request ${request.requestId} must use requestId=${request.requestId}, " +
                        "sourcePeerId=${request.targetPeerId}, targetPeerId=${request.sourcePeerId}, but received " +
                        "requestId=${response.requestId}, sourcePeerId=${response.sourcePeerId}, targetPeerId=${response.targetPeerId}"
                }
                connection.sendResponseWithOutbox(response.toJson(), reservation, registeredClose = true)
            }
            val unregister = RelayProtocol.RelayUnregister(
                requestId = RelayProtocol.nextMessageId(),
                peerId = peerId,
                registrationRequestId = connection.latestStreamOwningRegistrationRequestId,
            )
            connection.controller.enqueueRegistrationBoundary(unregister.toJson(), finish)
            cancelRelayedRequestHandlers(connection)
        } catch (failure: Throwable) {
            finish(failure)
        }
        return result
    }

    private fun sendRelayPayloadTo(
        targetPeerId: String,
        payload: ByteArray,
        output: OutputStream,
        path: String,
        headers: Map<String, String>,
        responseTimeoutMs: Long,
        responseDeadlineMs: Long,
        submit: (RelayProtocol.RelayRequest, Long?) -> RelayPendingReply
    ) {
        fun exchange(request: RelayProtocol.RelayRequest): RelayProtocol.RelayResponse = submit(request, null).await()
        val outHeaders = headers + mapOf(responseChunkSupportHeader to "true", RESPONSE_FRAMING_HEADER to RESPONSE_FRAMING_CAPABILITY)
        val response: RelayProtocol.RelayResponse
        if (payload.size <= relayRequestChunkBytes) {
            val request = RelayProtocol.RelayRequest(
                requestId = RelayProtocol.nextMessageId(),
                sourcePeerId = peerId,
                targetPeerId = targetPeerId,
                payload = Base64.getEncoder().encodeToString(payload),
                path = path,
                headers = outHeaders
            )
            response = exchange(request)
        } else {
            val transferId = RelayProtocol.nextMessageId()
            val totalChunks = (payload.size + relayRequestChunkBytes - 1) / relayRequestChunkBytes
            var finalResponse: RelayProtocol.RelayResponse? = null
            for (seq in 0 until totalChunks) {
                val start = seq * relayRequestChunkBytes
                val end = minOf(start + relayRequestChunkBytes, payload.size)
                val chunkRequest = RelayProtocol.RelayRequest(
                    requestId = RelayProtocol.nextMessageId(),
                    sourcePeerId = peerId,
                    targetPeerId = targetPeerId,
                    payload = Base64.getEncoder().encodeToString(payload.copyOfRange(start, end)),
                    path = path,
                    headers = outHeaders,
                    transferId = transferId,
                    chunkSeq = seq,
                    totalChunks = totalChunks
                )
                val chunkResponse = exchange(chunkRequest)
                if (!chunkResponse.success) {
                    throw RelayException("Relay request failed at chunk $seq/$totalChunks: ${chunkResponse.errorMessage}")
                }
                if (seq == totalChunks - 1) {
                    if (chunkResponse.chunkAck) {
                        throw RelayException(
                            "Relay returned an interim acknowledgement for final chunk " +
                                "$seq/$totalChunks of transfer $transferId instead of the target response"
                        )
                    }
                    finalResponse = chunkResponse
                }
            }
            response = finalResponse ?: throw RelayException("Relay chunked transfer produced no final response")
        }

        if (!response.success) {
            throw RelayException("Relay request failed: ${response.errorMessage}")
        }

        val firstRaw = Base64.getDecoder().decode(response.payload)
        val firstChunk = parseNegotiatedResponseChunk(response, firstRaw)
        if (firstChunk == null) {
            output.write(firstRaw)
            return
        }
        if (firstChunk.seq != 0 || firstChunk.total <= 0) {
            throw RelayException("Relay response first chunk must have sequence 0 and positive total, but had ${firstChunk.seq}/${firstChunk.total}")
        }
        output.write(firstChunk.data)
        val chunks = HashMap<Int, ByteArray>()
        var nextToWrite = 1
        fun buildChunkFetch(seq: Int): RelayProtocol.RelayRequest {
            return RelayProtocol.RelayRequest(
                requestId = RelayProtocol.nextMessageId(),
                sourcePeerId = peerId,
                targetPeerId = targetPeerId,
                payload = "",
                path = path,
                headers = headers + mapOf(
                    responseChunkSupportHeader to "true",
                    RESPONSE_FRAMING_HEADER to if (firstChunk.opaqueFraming) RESPONSE_FRAMING_CAPABILITY else "legacy",
                    responseChunkFetchHeader to firstChunk.transferId,
                    responseChunkSeqHeader to seq.toString()
                )
            )
        }

        val window = minOf(firstChunk.total - 1, relayResponseChunkFetchWindow)
        var nextToRequest = 1
        // Every fetch in the window is sent before any reply is awaited, so the target builds and
        // sends the next chunks while this thread decodes and writes the current one. Replies are
        // awaited in request order; a reply that is never awaited is abandoned on exit.
        val pendingChunkResponses = ArrayDeque<Pair<Int, RelayPendingReply>>()
        val refusedChunks = HashMap<Int, RefusedRelayResponseChunk>()
        var refusalBudget: RefusedRelayResponseChunk? = null
        fun submitChunkFetch(sequence: Int): RelayPendingReply {
            val budget = refusalBudget
            try {
                return submit(buildChunkFetch(sequence), budget?.let { remainingRefusedRelayChunkWait(clock, it) })
            } catch (failure: Exception) {
                if (budget != null && !Thread.currentThread().isInterrupted) checkRefusedRelayChunkDeadline(clock, budget)
                throw failure
            }
        }
        try {
            while (nextToRequest <= window) {
                pendingChunkResponses.add(nextToRequest to submitChunkFetch(nextToRequest))
                nextToRequest++
            }
            var received = 1
            while (received < firstChunk.total) {
                val pending = if (pendingChunkResponses.isEmpty()) {
                    throw RelayException("Timeout or invalid response fetching response chunks (got $received/${firstChunk.total})")
                } else {
                    pendingChunkResponses.removeFirst()
                }
                var chunkResponse = awaitRelayChunkReply(pending.second, clock, refusalBudget)
                while (!chunkResponse.success && chunkResponse.wasDefinitelyNotDispatched()) {
                    val refused = refusedChunks.getOrPut(pending.first) {
                        RefusedRelayResponseChunk(
                            pending.first, responseDeadlineMs,
                            responseTimeoutMs, checkNotNull(chunkResponse.displayErrorMessage()),
                        )
                    }
                    refusalBudget = refused
                    awaitRefusedRelayChunkTurn(clock, refused)
                    // Other futures keep receiving their replies through the registration reader.
                    // Replace only this fetch; the application request is never submitted again.
                    chunkResponse = awaitRelayChunkReply(submitChunkFetch(pending.first), clock, refused)
                }
                refusedChunks.remove(pending.first)
                if (!chunkResponse.success) {
                    throw RelayException("Relay response chunk fetch failed: ${chunkResponse.errorMessage}")
                }
                val parsed = parseNegotiatedResponseChunk(chunkResponse, Base64.getDecoder().decode(chunkResponse.payload), firstChunk.opaqueFraming)
                    ?: throw RelayException("Relay response chunk missing chunk envelope (got $received/${firstChunk.total})")
                if (parsed.seq <= 0 || parsed.seq >= firstChunk.total) {
                    throw RelayException("Relay response chunk seq ${parsed.seq} out of range [1, ${firstChunk.total})")
                }
                if (parsed.transferId != firstChunk.transferId || parsed.total != firstChunk.total) {
                    throw RelayException("Relay response chunk belongs to a different transfer or total")
                }
                if (parsed.seq < nextToWrite || parsed.seq >= nextToRequest || chunks.containsKey(parsed.seq)) {
                    throw RelayException("Relay response chunk sequence ${parsed.seq} was not pending in [$nextToWrite, $nextToRequest)")
                }
                chunks[parsed.seq] = parsed.data
                received++
                while (true) {
                    val data = chunks.remove(nextToWrite) ?: break
                    output.write(data)
                    nextToWrite++
                }
                while (nextToRequest < firstChunk.total && nextToRequest - nextToWrite < window) {
                    pendingChunkResponses.add(nextToRequest to submitChunkFetch(nextToRequest))
                    nextToRequest++
                }
            }
        } finally {
            while (pendingChunkResponses.isNotEmpty()) pendingChunkResponses.removeFirst().second.abandon()
        }
    }

    private fun sendDirectlyToRegisteredPeer(
        targetPeerId: String,
        payload: ByteArray,
        output: OutputStream,
        path: String,
        headers: Map<String, String>,
        timeout: Long,
        timeoutUnit: TimeUnit,
        responseDeadlineMs: Long,
    ): Boolean {
        val registered = registeredPeers[targetPeerId] ?: return false
        if (registered.controller.isClosed()) {
            withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                registeredPeers.remove(targetPeerId, registered)
            }
            updateLocalLinkStateAdvertisement()
            return false
        }
        var outputStarted = false
        val trackedOutput = object : OutputStream() {
            override fun write(value: Int) {
                outputStarted = true
                output.write(value)
            }
            override fun write(bytes: ByteArray, offset: Int, length: Int) {
                outputStarted = true
                output.write(bytes, offset, length)
            }
        }
        return try {
            sendRelayPayloadTo(
                targetPeerId, payload, trackedOutput, path, headers, timeoutUnit.toMillis(timeout), responseDeadlineMs,
            ) { request, maxAdmissionWaitMs ->
                sendRegisteredRequest(registered, request, responseDeadlineMs, maxAdmissionWaitMs)
            }
            true
        } catch (e: DirectRegisteredPeerUnavailableException) {
            withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                registeredPeers.remove(targetPeerId, registered)
            }
            updateLocalLinkStateAdvertisement()
            if (outputStarted) throw e
            false
        }
    }

    private fun targetHasPublicDirectAddress(targetPeerId: String): Boolean =
        peerRegistry.getPeer(targetPeerId)
            ?.multiaddresses
            ?.any { it.isNotBlank() && isPublicDirectMultiaddress(it) }
            ?: false

    /**
     * Checks out one exclusively-used request stream for a relay-only route. A clean call returns
     * the stream through [releaseRelayRequestConnection]; failed or partly-read calls close it.
     *
     */
    private fun acquireRelayRequestConnection(relayPeer: BootstrapPeer, dialClock: Clock): RelayConnection {
        idleRelayRequestConnections[relayPeer.peerId]?.let { idle ->
            val discarded = ArrayList<RelayConnection>()
            val reusable = synchronized(idle) {
                var chosen: RelayConnection? = null
                while (idle.connections.isNotEmpty()) {
                    val connection = idle.connections.removeFirst()
                    if (connection.canCarryResponse()) {
                        chosen = connection
                        break
                    }
                    discarded.add(connection)
                }
                chosen
            }
            // Close outside the pool monitor: close() drives transport teardown.
            discarded.forEach { it.close() }
            if (reusable != null) return reusable
        }
        return connectToRelay(relayPeer, dialClock)
    }

    /**
     * Returns an exclusively-used relay request stream only after its complete response was read.
     * The synchronized per-relay deque makes the idle bound exact under concurrent completions.
     */
    private fun releaseRelayRequestConnection(
        relayPeerId: String,
        connection: RelayConnection,
        reusable: Boolean
    ) {
        if (reusable && !closed.get() && connection.canCarryResponse()) {
            val idle = idleRelayRequestConnections.computeIfAbsent(relayPeerId) {
                IdleRelayRequestConnections()
            }
            synchronized(idle) {
                if (
                    !closed.get() &&
                    connection.canCarryResponse() &&
                    idle.connections.size < MAX_IDLE_RELAY_REQUEST_CONNECTIONS_PER_PEER
                ) {
                    idle.connections.addFirst(connection)
                    return
                }
            }
        }
        connection.close()
    }

    private fun drainIdleRelayRequestConnections() {
        idleRelayRequestConnections.values.forEach { idle ->
            val connections = synchronized(idle) {
                buildList {
                    while (idle.connections.isNotEmpty()) {
                        add(idle.connections.removeFirst())
                    }
                }
            }
            connections.forEach { connection -> connection.close() }
        }
        idleRelayRequestConnections.clear()
    }

    private fun connectDirectlyToRoutableTarget(targetPeerId: String, dialClock: Clock): RelayConnection? {
        val targetPeer = peerRegistry.getPeer(targetPeerId) ?: return null
        val directPublicAddresses = targetPeer.multiaddresses
            .filter { it.isNotBlank() }
            .filter(::isPublicDirectMultiaddress)
        if (directPublicAddresses.isEmpty()) return null

        val directTargetPeer = Libp2pPeer.remote(
            peerId = targetPeerId,
            multiaddresses = directPublicAddresses,
            advertisedServices = targetPeer.advertisedServices,
            lastSeenTimestamp = targetPeer.lastSeenTimestamp
        )
        val connection = try {
            connectToRelay(directTargetPeer, dialClock)
        } catch (e: Exception) {
            debugLog { "[RELAY-TIMING] direct target dial failed target=$targetPeerId addresses=$directPublicAddresses error=${e.message}" }
            return null
        }
        return connection
    }

    /**
     * Sends [request] to a directly registered peer and returns its reply handle without waiting,
     * so a caller can keep several requests in flight on the registration stream. The reply is
     * routed by request id; [RelayPendingReply.abandon] stops routing a reply nobody will read.
     */
    private fun sendRegisteredRequest(
        registered: RegisteredPeer,
        request: RelayProtocol.RelayRequest,
        responseDeadlineMs: Long,
        maxAdmissionWaitMs: Long? = null,
    ): RelayPendingReply {
        val pending = registerPendingRelayRequest(request.requestId, registered.controller, registered.peerId)
        val future = pending.future
        try {
            val admissionWaitMs = minOf(
                if (maxAdmissionWaitMs == null) WRITE_BACKPRESSURE_DELIVERY_WAIT_MS else WRITE_BACKPRESSURE_WAIT_MS,
                maxAdmissionWaitMs ?: Long.MAX_VALUE,
            )
            val json = request.toJson()
            if (!admitRelayCallMessage(clock, responseDeadlineMs, admissionWaitMs, registered.controller::isClosed,
                { relayCallParkedWriteBudget(registered.controller.relayDiagnosticStream()) }) {
                registered.controller.trySendMessage(json, 0L)
            }) {
                throw RelayException(relayMessageNotAdmittedMessage(admissionWaitMs))
            }
        } catch (e: Exception) {
            pendingRequests.remove(request.requestId, pending)
            if (e is InterruptedException) Thread.currentThread().interrupt()
            if (Thread.currentThread().isInterrupted) {
                // A caller interruption does not make the registered peer unavailable.
                throw RelayException("Interrupted while waiting for response from directly registered peer ${registered.peerId}", e)
            }
            if (clock.currentTimeMillis() >= responseDeadlineMs) {
                throw RelayException("Timeout waiting for response from directly registered peer ${registered.peerId}", e)
            }
            throw DirectRegisteredPeerUnavailableException(
                "Direct stream to registered peer ${registered.peerId} is unavailable: ${e.message}",
                e
            )
        } catch (t: Throwable) {
            pendingRequests.remove(request.requestId, pending)
            throw t
        }
        return object : RelayPendingReply {
            override fun await(): RelayProtocol.RelayResponse = try {
                val remaining = remainingReadWaitMillis(responseDeadlineMs, clock.currentTimeMillis())
                if (remaining <= 0L) throw TimeoutException()
                val response = if (clock is SystemClock) {
                    future.get(remaining, TimeUnit.MILLISECONDS)
                } else {
                    val expiry = clock.schedule(responseDeadlineMs) { future.completeExceptionally(TimeoutException()) }
                    try {
                        // A Clock may have advanced between the first read and scheduling.
                        if (clock.currentTimeMillis() >= responseDeadlineMs) throw TimeoutException()
                        future.get()
                    } finally { clock.unschedule(expiry) }
                }
                if (clock.currentTimeMillis() >= responseDeadlineMs) throw TimeoutException()
                response
            } catch (e: TimeoutException) {
                throw RelayException("Timeout waiting for response from directly registered peer ${registered.peerId}", e)
            } catch (e: ExecutionException) {
                if (e.cause is TimeoutException) {
                    throw RelayException("Timeout waiting for response from directly registered peer ${registered.peerId}", e.cause)
                }
                throw RelayException("Direct request to registered peer ${registered.peerId} failed: ${e.cause?.message}", e.cause ?: e)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                throw RelayException("Interrupted while waiting for response from directly registered peer ${registered.peerId}", e)
            } finally {
                pendingRequests.remove(request.requestId, pending)
            }

            override fun abandon() {
                pendingRequests.remove(request.requestId, pending)
            }
        }
    }

    /**
     * Sends a request to a target peer through a relay.
     *
     * @param relayPeerId The peer ID of the relay to use.
     * @param targetPeerId The peer ID of the target.
     * @param payload The request payload.
     * @param path Optional path for the request.
     * @param headers Optional headers.
     * @param timeout Timeout for the request.
     * @return The response from the target peer.
     */
    fun sendViaRelay(
        relayPeerId: String,
        targetPeerId: String,
        payload: ByteArray,
        path: String = "",
        headers: Map<String, String> = emptyMap(),
        timeout: Long = 30,
        timeoutUnit: TimeUnit = TimeUnit.SECONDS
    ): ByteArray {
        // Keep partial replies segmented while the targets still retain their complete answers.
        val response = Buffer()
        try {
            sendViaRelayTo(relayPeerId, targetPeerId, payload, response.outputStream(), path, headers, timeout, timeoutUnit)
            return response.readByteArray()
        } finally {
            response.clear()
        }
    }

    /**
     * Delivers the response in order to caller-owned [output] with a bounded chunk-fetch window.
     * Does not flush or close the output. A failed write propagates and retires the request stream;
     * the caller may already have received a prefix of the response when an operation fails.
     * Uses the existing wire format, including whole responses from older peers.
     */
    fun sendViaRelayTo(
        relayPeerId: String,
        targetPeerId: String,
        payload: ByteArray,
        output: OutputStream,
        path: String = "",
        headers: Map<String, String> = emptyMap(),
        timeout: Long = 30,
        timeoutUnit: TimeUnit = TimeUnit.SECONDS
    ) {
        try {
            requireUninterruptedResponseDelivery()
            sendViaRelayToInternal(relayPeerId, targetPeerId, payload, interruptionAwareResponseOutput(output), path, headers, timeout, timeoutUnit)
            requireUninterruptedResponseDelivery()
        } catch (failure: java.io.InterruptedIOException) {
            if (failure !is java.net.SocketTimeoutException) Thread.currentThread().interrupt()
            throw failure
        } catch (failure: InterruptedException) {
            Thread.currentThread().interrupt()
            throw failure
        }
    }

    private fun sendViaRelayToInternal(
        relayPeerId: String,
        targetPeerId: String,
        payload: ByteArray,
        output: OutputStream,
        path: String,
        headers: Map<String, String>,
        timeout: Long,
        timeoutUnit: TimeUnit
    ) {
        if (closed.get()) {
            throw RelayRequestNotDispatchedException("Cannot send via relay because RelayService is closed")
        }
        val totalStart = System.currentTimeMillis()
        // Every refused fetch shares the caller's original budget, including time already
        // spent dialing, sending application work and receiving earlier response chunks.
        val responseDeadlineMs = saturatedReadDeadline(clock.currentTimeMillis(), timeoutUnit.toMillis(timeout))

        if (sendDirectlyToRegisteredPeer(targetPeerId, payload, output, path, headers, timeout, timeoutUnit, responseDeadlineMs)) {
            val totalMs = System.currentTimeMillis() - totalStart
            debugLog { "[RELAY-TIMING] sendViaRelay: direct-registered target=$targetPeerId bytes=${payload.size}, total=${totalMs}ms" }
            return
        }

        // Reuse is restricted to routes with no possible public direct connection. A pooled relay
        // stream is available immediately and would otherwise keep winning the direct/relay race
        // after a target became directly reachable.
        val relayRequestReuseAllowed = !targetHasPublicDirectAddress(targetPeerId)
        val relayFailure = AtomicReference<Throwable?>(null)
        val completions = LinkedBlockingQueue<Future<RelayConnection?>>()
        val requestDialClock = RelayRequestDialClock(clock)
        val dialCandidates = ConcurrentHashMap.newKeySet<RelayConnection>()

        fun dial(dialer: () -> RelayConnection?): RelayConnection? {
            val candidate = dialer()
            if (candidate != null) {
                dialCandidates.add(candidate)
                val outcome = requestDialClock.outcome.get()
                if (outcome !== RelayRequestDialOutcome.Pending &&
                    (outcome as? RelayRequestDialOutcome.Committed)?.connection !== candidate &&
                    dialCandidates.remove(candidate)) {
                    closeRelayDialConnection(requestDialClock, candidate)
                }
            }
            return candidate
        }

        val onTaskDone: (Future<RelayConnection?>) -> Unit = { completed ->
            raceLifecycleLock.withLock { inFlightRaceDials.remove(completed) }
            raceDialWorkerReleaseSeam?.invoke(completed)
        }
        val directDialer = Callable { dial { connectDirectlyToRoutableTarget(targetPeerId, requestDialClock) } }
        val relayDialer = Callable {
            dial {
                try {
                    val relayPeer = peerRegistry.getPeer(relayPeerId)
                        ?: throw IllegalArgumentException("Relay peer $relayPeerId not found in registry")
                    if (relayRequestReuseAllowed) {
                        acquireRelayRequestConnection(relayPeer, requestDialClock)
                    } else {
                        connectToRelay(relayPeer, requestDialClock)
                    }
                } catch (e: Exception) {
                    relayFailure.compareAndSet(null, e)
                    if (e is InterruptedException) Thread.currentThread().interrupt()
                    null
                }
            }
        }
        var directTask = CompletionQueueFutureTask(directDialer, completions, onTaskDone)
        var relayTask = CompletionQueueFutureTask(relayDialer, completions, onTaskDone)

        // Whether the two dials were admitted to the bounded worker pool and are running in
        // parallel. When they were not, they still run — sequentially, on this caller's own thread.
        var racedDials = false
        // Per-task admission outcome. The two hand-offs are separate: the pool can accept the first
        // and refuse the second, because logical dial tracking releases a slot in onTaskDone before
        // the worker that finished has returned to the executor's hand-off queue.
        var directAdmitted = false
        var relayAdmitted = false
        raceLifecycleLock.withLock {
            if (closed.get()) {
                throw RelayRequestNotDispatchedException(
                    "Cannot start direct/relay dial race because RelayService is closed"
                )
            }
            if (inFlightRaceDials.size + 2 <= maxInFlightRaceDials) {
                inFlightRaceDials.add(directTask)
                inFlightRaceDials.add(relayTask)
                try {
                    raceDialExecutor.execute(directTask)
                    directAdmitted = true
                    raceDialExecutor.execute(relayTask)
                    relayAdmitted = true
                    racedDials = true
                } catch (e: RejectedExecutionException) {
                    debugLogErr {
                        "[RELAY] Bounded dial workers rejected the direct/relay race for " +
                            "$targetPeerId (${e.message}); dialing on the calling thread instead"
                    }
                    // Only a task the executor REFUSED may be cancelled, untracked and replaced:
                    // rejection is proof it never ran, so nothing it could have opened exists.
                    //
                    // A task the executor ACCEPTED is already running on a worker and owns whatever
                    // connection it goes on to establish. Cancelling it here would not stop it —
                    // FutureTask.cancel(false) succeeds on a running callable because its state
                    // stays NEW until the callable publishes a result, and the later publish is then
                    // discarded — so its connection would be established with no holder: dial()
                    // closes a late result only once this request has committed to another one, and
                    // a request that never commits never closes it. The accepted task therefore
                    // stays tracked and is observed through the completion queue below, exactly as
                    // it would have been had both hand-offs succeeded.
                    if (!directAdmitted) {
                        directTask.cancel(false)
                        inFlightRaceDials.remove(directTask)
                        directTask = CompletionQueueFutureTask(directDialer, completions, onTaskDone)
                    }
                    if (!relayAdmitted) {
                        relayTask.cancel(false)
                        inFlightRaceDials.remove(relayTask)
                        relayTask = CompletionQueueFutureTask(relayDialer, completions, onTaskDone)
                    }
                }
            }
        }

        var directReady: RelayConnection? = null
        var relayReady: RelayConnection? = null
        var directObserved = false
        var relayObserved = false
        var reusableRelayRequestConnection = false
        fun abandonDials(failure: Throwable) {
            // Terminal without a winner: a worker returning later closes its own candidate.
            // Publish before cancelling FutureTasks, which can discard a running task's result.
            requestDialClock.outcome.compareAndSet(
                RelayRequestDialOutcome.Pending, RelayRequestDialOutcome.Committed(null),
            )
            directTask.cancel(true)
            relayTask.cancel(true)
            dialCandidates.forEach { candidate ->
                if (dialCandidates.remove(candidate)) {
                    closeRelayDialConnection(requestDialClock, candidate, failure)
                }
            }
        }
        try {
            if (!racedDials) {
                inlineDialFallbacks.incrementAndGet()
                // Every bounded dial worker is busy. Racing the direct and relay paths in parallel
                // is a LATENCY optimization; having no spare worker for it is not a reason to
                // refuse to send the request at all. Refusing here hands the caller a request it
                // must treat as un-sent, and under churn the caller's whole deadline can expire
                // across repeated refusals without a single byte ever being attempted. This thread
                // is already blocked waiting for the result, so it does the two dials itself, in
                // the same direct-then-relay preference order, adding no worker, no queue growth,
                // and no new concurrency beyond what the caller had already committed.
                //
                // Only the dials the pool refused are run here. One the pool accepted is already
                // running on a worker; running it again on this thread is impossible (its task is
                // live, not a replacement) and taking it away from the worker would strand the
                // connection that worker is opening. It is observed through the completion queue
                // below instead.
                if (!directAdmitted) {
                    directTask.run()
                    directObserved = true
                    directReady = try { directTask.get() } catch (_: CancellationException) { null }
                }
                if (directReady == null && !relayAdmitted) {
                    relayTask.run()
                    relayObserved = true
                    relayReady = try { relayTask.get() } catch (_: CancellationException) { null }
                }
            }
            while (directReady == null && relayReady == null && (!directObserved || !relayObserved)) {
                completions.take()
                // Inspect direct first so a same-instant tie preserves direct-path preference.
                if (!directObserved && directTask.isDone) {
                    directObserved = true
                    directReady = try { directTask.get() } catch (_: CancellationException) { null }
                }
                if (!relayObserved && relayTask.isDone) {
                    relayObserved = true
                    relayReady = try { relayTask.get() } catch (_: CancellationException) { null }
                }
            }
        } catch (e: InterruptedException) {
            val failure = requestRelayDialClockFailure(requestDialClock, targetPeerId)
                ?: RelayRequestNotDispatchedException(
                    "Interrupted while racing direct and relay dials for target $targetPeerId", e,
                )
            abandonDials(failure)
            Thread.currentThread().interrupt()
            throw failure
        } catch (e: ExecutionException) {
            val failure = requestRelayDialClockFailure(requestDialClock, targetPeerId)
                ?: RelayRequestNotDispatchedException(
                    "Direct/relay dial race for target $targetPeerId failed: ${e.cause?.message}", e.cause ?: e,
                )
            abandonDials(failure)
            throw failure
        }

        requestRelayDialClockFailure(requestDialClock, targetPeerId)?.let { failure ->
            abandonDials(failure)
            throw failure
        }
        val connection = directReady ?: relayReady
        if (connection == null) {
            if (closed.get()) {
                throw RelayRequestNotDispatchedException(
                    "RelayService closed while racing direct and relay dials for target $targetPeerId"
                )
            }
            throw RelayRequestNotDispatchedException(
                "Neither the direct path to $targetPeerId nor relay $relayPeerId could be reached",
                relayFailure.get()
            )
        }
        val usingDirectPath = directReady != null
        if (!requestDialClock.outcome.compareAndSet(
                RelayRequestDialOutcome.Pending, RelayRequestDialOutcome.Committed(connection),
            )) {
            val failure = checkNotNull(requestRelayDialClockFailure(requestDialClock, targetPeerId))
            abandonDials(failure)
            throw failure
        }
        dialCandidates.remove(connection)

        val requestConnectionAdmitted = raceLifecycleLock.withLock {
            if (closed.get()) {
                false
            } else {
                activeRelayRequestConnections.add(connection)
                true
            }
        }
        if (!requestConnectionAdmitted) {
            val failure = RelayRequestNotDispatchedException(
                "RelayService closed before the winning path to $targetPeerId could transmit the request"
            )
            abandonDials(failure)
            closeRelayDialConnection(requestDialClock, connection, failure)
            throw failure
        }

        // Include a losing task that completed after its last isDone check. A candidate published
        // after this drain sees the terminal decision in dial() and closes itself.
        dialCandidates.forEach { candidate ->
            if (dialCandidates.remove(candidate)) {
                closeRelayDialConnection(requestDialClock, candidate)
            }
        }
        val losingTask = if (usingDirectPath) relayTask else directTask
        // FutureTask.cancel(true) interrupts connectToRelay's resultReady.get. Its interrupted path
        // completes the composed attempt exceptionally and closes every already-open libp2p stream;
        // if an underlying library still returns a connection after cancellation, dial() above sees
        // the committed winner and closes that late result before it can carry request bytes.
        losingTask.cancel(true)

        fun sendCommittedRequest(buildRequest: () -> RelayProtocol.RelayRequest) {
            // Transport admission is post-commit work. Close owns the active-connection set and
            // closes this exact stream after its terminal state transition, making a parked write
            // report that the request was not dispatched.
            try {
                val json = buildRequest().toJson()
                if (!admitRelayCallMessage(clock, responseDeadlineMs, WRITE_BACKPRESSURE_WAIT_MS, connection::isClosed,
                    { relayCallParkedWriteBudget(connection.controller.diagnosticStream) }) {
                    connection.sendMessage(json, 0L)
                }) throw RelayException(relayMessageNotAdmittedMessage(WRITE_BACKPRESSURE_WAIT_MS))
            } catch (e: RelayRequestNotDispatchedException) {
                throw e
            } catch (e: RelayException) {
                if (!Thread.currentThread().isInterrupted && clock.currentTimeMillis() >= responseDeadlineMs) {
                    throw RelayException("Timeout or invalid response waiting for relay response", e)
                }
                // sendMessage either admits the complete frame to the transport or throws, so a
                // throw here means these bytes never entered the transport and the target can
                // never have executed this request. Reporting that as a plain (ambiguous)
                // RelayException would stop the caller retrying an operation that provably did
                // not happen; say plainly that it was never dispatched.
                throw RelayRequestNotDispatchedException(
                    "Relay request for target $targetPeerId was never written to the transport " +
                        "on the winning path via relay $relayPeerId: ${e.message}",
                    e
                )
            }
        }

        try {
            val outHeaders = headers + mapOf(responseChunkSupportHeader to "true", RESPONSE_FRAMING_HEADER to RESPONSE_FRAMING_CAPABILITY)
            val response: RelayProtocol.RelayResponse
            if (payload.size <= relayRequestChunkBytes) {
                sendCommittedRequest {
                    RelayProtocol.RelayRequest(
                        requestId = RelayProtocol.nextMessageId(),
                        sourcePeerId = peerId,
                        targetPeerId = targetPeerId,
                        payload = Base64.getEncoder().encodeToString(payload),
                        path = path,
                        headers = outHeaders
                    )
                }
                response = readForwardedResponse(connection, timeout, timeoutUnit, clock, responseDeadlineMs)
                    ?.let { RelayProtocol.parseMessage(it) as? RelayProtocol.RelayResponse }
                    ?: throw RelayException(
                        if (connection.isClosed())
                            "Stream closed while awaiting relay response because the relay connection " +
                                "ended before this request completed"
                        else
                            "Timeout or invalid response waiting for relay response"
                    )
            } else {
                val transferId = RelayProtocol.nextMessageId()
                val totalChunks = (payload.size + relayRequestChunkBytes - 1) / relayRequestChunkBytes
                // Pipeline the chunk frames within a bounded window instead of blocking on each
                // chunk's acknowledgement before writing the next one.
                //
                // Replies are classified, never positionally correlated — this reader must not depend
                // on the order replies arrive in. Chunk assembly happens at the TARGET, so a relay
                // forwards every chunk onward and answers from an async completion callback rather
                // than from the per-stream critical section (see handleRelayRequest's note that "the
                // forward paths reply to [sourceController] ASYNCHRONOUSLY", which is deliberate: it
                // is what frees the dispatcher slot and removes per-stream head-of-line blocking).
                // Nothing in that path promises that reply i belongs to chunk i once more than one
                // frame is in flight, and multi-hop routes and older relay versions widen the gap
                // further. No reordering has actually been observed, and the public API gives no way
                // to force one, so this is robustness against an ordering the protocol never
                // guaranteed rather than a fix for an observed interleaving.
                //
                // Interim acknowledgements are interchangeable (`chunkAck`, empty payload), so the
                // only reply that must be identified is the single non-acknowledgement one. Every
                // reply is still read before returning, so a reused request connection is never left
                // holding stale replies.
                val requestChunkBudget = requestChunkSendBudgetFor(connection)
                var outstandingChunkSendPermits = 0

                fun sendChunkWithPermit(seq: Int) {
                    val start = seq * relayRequestChunkBytes
                    val end = minOf(start + relayRequestChunkBytes, payload.size)
                    try {
                        sendCommittedRequest {
                            RelayProtocol.RelayRequest(
                                requestId = RelayProtocol.nextMessageId(),
                                sourcePeerId = peerId,
                                targetPeerId = targetPeerId,
                                payload = Base64.getEncoder().encodeToString(payload.copyOfRange(start, end)),
                                path = path,
                                headers = outHeaders,
                                transferId = transferId,
                                chunkSeq = seq,
                                totalChunks = totalChunks
                            )
                        }
                    } catch (t: Throwable) {
                        outstandingChunkSendPermits--
                        requestChunkBudget.release()
                        throw t
                    }
                }

                fun trySendChunk(seq: Int): Boolean {
                    // The timed zero wait honors the fair semaphore's queue, unlike bare tryAcquire(),
                    // so an active transfer cannot continually barge ahead of a transfer waiting for
                    // its first permit.
                    val acquired = try {
                        requestChunkBudget.tryAcquire(0, TimeUnit.NANOSECONDS)
                    } catch (e: InterruptedException) {
                        Thread.currentThread().interrupt()
                        throw RelayException(
                            "Interrupted while waiting for the relay request-chunk send budget",
                            e
                        )
                    }
                    if (!acquired) return false
                    outstandingChunkSendPermits++
                    try {
                        sendChunkWithPermit(seq)
                    } catch (notDispatched: RelayRequestNotDispatchedException) {
                        // An OPPORTUNISTIC send is one this transfer makes while it already has frames
                        // in flight, purely to widen the pipeline. Failing to admit one of those is not
                        // a transfer failure: sendCommittedRequest throws this exception precisely
                        // because the bytes provably never entered the transport, so this exact chunk
                        // can go out again later with nothing duplicated and no sequence skipped.
                        //
                        // It matters because the pipeline creates its own congestion. A serial sender
                        // never had a second large frame outstanding, so every write met a drained
                        // channel; writing back-to-back frames does not, and on a loaded host a later
                        // frame can miss the bounded admission budget. Aborting the upload for that
                        // would make pipelining strictly worse than the serialization it replaced.
                        // Instead the chunk is simply not sent this turn — the caller reads an
                        // acknowledgement it is already owed, which is exactly the drain time the
                        // channel needed, and offers the chunk again.
                        //
                        // With NOTHING in flight there is no drain to wait for and no later turn to
                        // use, so the failure propagates exactly as it did before this pipeline
                        // existed. sendChunkWithPermit has already returned this frame's permit.
                        if (outstandingChunkSendPermits == 0) throw notDispatched
                        return false
                    }
                    return true
                }

                fun awaitAndSendChunk(seq: Int) {
                    // This blocking path is called only when this transfer holds ZERO permits. A
                    // transfer with chunk frames in flight must keep reading their acknowledgements so
                    // those permits can be released; if it blocked here while holding permits, two
                    // transfers could deadlock waiting for capacity that only their unread
                    // acknowledgements can return.
                    check(outstandingChunkSendPermits == 0) {
                        "A relay request transfer may wait for a request-chunk send permit only with no chunk " +
                            "frames in flight, but held $outstandingChunkSendPermits"
                    }
                    val acquired = try {
                        requestChunkBudget.tryAcquire(timeout, timeoutUnit)
                    } catch (e: InterruptedException) {
                        Thread.currentThread().interrupt()
                        throw RelayException(
                            "Interrupted while waiting for the relay request-chunk send budget",
                            e
                        )
                    }
                    if (!acquired) {
                        throw RelayException(
                            "Timed out waiting for the relay request-chunk send budget " +
                                "($relayRequestChunkSendConnectionBudget concurrent request chunks per relay connection)"
                        )
                    }
                    outstandingChunkSendPermits++
                    sendChunkWithPermit(seq)
                }

                val maximumWindow = minOf(totalChunks, relayRequestChunkSendWindow)
                var nextToSend = 0
                // Keep the established two-frame opening window. The request-chunk semaphore below
                // still bounds the aggregate number of frames across transfers sharing this relay
                // connection; this per-transfer window lets the sender overlap an acknowledgement
                // wait with the next request without opening an unbounded burst.
                var window = minOf(relayRequestChunkWindow, maximumWindow)

                fun refillWindow() {
                    while (nextToSend < totalChunks && outstandingChunkSendPermits < window) {
                        if (!trySendChunk(nextToSend)) break
                        nextToSend++
                    }
                    // Never leave the transfer with nothing in flight while chunks remain: it would
                    // have no acknowledgement coming, so nothing would ever release a permit for it.
                    if (outstandingChunkSendPermits == 0 && nextToSend < totalChunks) {
                        awaitAndSendChunk(nextToSend)
                        nextToSend++
                    }
                }

                var finalResponse: RelayProtocol.RelayResponse? = null
                try {
                    refillWindow()
                    for (received in 0 until totalChunks) {
                        // Ambiguity note: this timeout reports the transfer as failed while leaving
                        // open whether the target executed it. Serial sending confined that ambiguity
                        // to a lost FINAL reply, because only the final chunk's reply could have been
                        // the one carrying execution. With several frames in flight, any lost reply
                        // lands here, and the chunks already delivered may still complete the assembly
                        // at the target afterwards. The window is wider, not new — a plain
                        // RelayException has always meant "may or may not have happened", which is
                        // why the never-dispatched case has its own distinct exception type and is
                        // the only one a caller may safely retry on.
                        val chunkResponse = readForwardedResponse(connection, timeout, timeoutUnit, clock, responseDeadlineMs)
                            ?.let { RelayProtocol.parseMessage(it) as? RelayProtocol.RelayResponse }
                            ?: throw RelayException(
                                "Timeout or invalid response for relay chunk reply " +
                                    "$received of $totalChunks"
                            )
                        outstandingChunkSendPermits--
                        requestChunkBudget.release()
                        if (!chunkResponse.success) {
                            throw relayFailureFromResponse(
                                chunkResponse,
                                "Relay request failed at chunk reply $received of $totalChunks"
                            )
                        }
                        if (!chunkResponse.chunkAck) {
                            if (finalResponse != null) {
                                throw RelayException(
                                    "Relay returned a second target response at chunk reply " +
                                        "$received of $totalChunks of transfer $transferId; a chunked " +
                                        "transfer completes exactly once, so every reply but one must " +
                                        "be an interim acknowledgement"
                                )
                            }
                            finalResponse = chunkResponse
                        }
                        if (window < maximumWindow) window++
                        // A frame that cannot take a shared permit right now is simply not sent this
                        // turn: this transfer keeps reading the acknowledgements it is already owed,
                        // and the next one frees capacity. It never blocks while holding permits,
                        // which is what would let two transfers wait on each other.
                        refillWindow()
                    }
                    if (finalResponse == null) {
                        throw RelayException(
                            "Relay returned an interim acknowledgement for final chunk " +
                                "${totalChunks - 1}/$totalChunks of transfer $transferId instead of " +
                                "the target response"
                        )
                    }
                } finally {
                    if (outstandingChunkSendPermits > 0) {
                        requestChunkBudget.release(outstandingChunkSendPermits)
                        outstandingChunkSendPermits = 0
                    }
                }
                response = finalResponse
                    ?: throw RelayException("Relay chunked transfer produced no final response")
            }

            if (!response.success) {
                throw relayFailureFromResponse(response, "Relay request failed")
            }

            val totalMs = System.currentTimeMillis() - totalStart
            debugLog {
                val route = if (usingDirectPath) "direct-routable target=$targetPeerId" else "relay=$relayPeerId target=$targetPeerId"
                "[RELAY-TIMING] sendViaRelay: $route bytes=${payload.size}, total=${totalMs}ms"
            }

            val firstRaw = Base64.getDecoder().decode(response.payload)
            val firstChunk = parseNegotiatedResponseChunk(response, firstRaw)
            if (firstChunk == null) {
                output.write(firstRaw)
                reusableRelayRequestConnection = !usingDirectPath && relayRequestReuseAllowed
                return
            }
            if (firstChunk.seq != 0 || firstChunk.total <= 0) {
                throw RelayException("Relay response first chunk must have sequence 0 and positive total, but had ${firstChunk.seq}/${firstChunk.total}")
            }
            output.write(firstChunk.data)
            val chunks = HashMap<Int, ByteArray>()
            var nextToWrite = 1
            val chunkFetchBudget = responseChunkFetchBudgetFor(connection)
            var outstandingChunkFetchPermits = 0
            val fetchSequencesByRequestId = HashMap<String, Int>()
            val refusedChunks = HashMap<Int, RefusedRelayResponseChunk>()
            val refusedSequences = ArrayDeque<Int>()
            var refusalBudget: RefusedRelayResponseChunk? = null
            var received = 1
            fun checkChunkFetchDeadline() {
                val budget = refusalBudget
                if (budget != null) checkRefusedRelayChunkDeadline(clock, budget)
                else if (clock.currentTimeMillis() >= responseDeadlineMs) {
                    throw RelayException("Timeout or invalid response fetching response chunks (got $received/${firstChunk.total})")
                }
            }

            fun acquireChunkFetchPermit(): Boolean {
                checkChunkFetchDeadline()
                val acquired = try {
                    // A probe cannot pass callers already queued for their first permit.
                    chunkFetchBudget.tryAcquire()
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw RelayException(
                        "Interrupted while waiting for the shared relay response-chunk fetch budget",
                        e
                    )
                }
                if (acquired) outstandingChunkFetchPermits++
                return acquired
            }

            fun awaitChunkFetchPermit(refused: RefusedRelayResponseChunk? = null) {
                val acquired = try {
                    val budget = refused ?: refusalBudget
                    if (budget != null) checkRefusedRelayChunkDeadline(clock, budget)
                    chunkFetchBudget.acquire(clock, responseDeadlineMs)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw RelayException(
                        "Interrupted while waiting for the shared relay response-chunk fetch budget",
                        e
                    )
                }
                if (!acquired) {
                    (refused ?: refusalBudget)?.let { checkRefusedRelayChunkDeadline(clock, it) }
                    throw RelayException(
                        "Timed out waiting for the shared relay response-chunk fetch budget " +
                            "($relayResponseChunkFetchConnectionBudget concurrent fetches per relay connection)"
                    )
                }
                outstandingChunkFetchPermits++
            }

            fun sendChunkFetchWithPermit(seq: Int) {
                val requestId = RelayProtocol.nextMessageId()
                fetchSequencesByRequestId[requestId] = seq
                try {
                    checkChunkFetchDeadline()
                    connection.responseDiagnostics.fetches = connection.responseDiagnostics.fetches +
                        RelayResponseFetchDiagnostic(
                            requestId,
                            "requestId=${relayProgressField(requestId)} " +
                                "rpcRequestId=${relayProgressField(headers["resolverRpcRequestId"] ?: "unknown")} " +
                                "transferId=${relayProgressField(firstChunk.transferId)} sequence=$seq",
                            clock.currentTimeMillis(),
                        )
                    val request = RelayProtocol.RelayRequest(
                        requestId = requestId,
                        sourcePeerId = peerId,
                        targetPeerId = targetPeerId,
                        payload = "",
                        path = path,
                        headers = headers + mapOf(
                            responseChunkSupportHeader to "true",
                            RESPONSE_FRAMING_HEADER to if (firstChunk.opaqueFraming) RESPONSE_FRAMING_CAPABILITY else "legacy",
                            responseChunkFetchHeader to firstChunk.transferId,
                            responseChunkSeqHeader to seq.toString()
                        )
                    ).toJson()
                    val budget = refusalBudget
                    val admissionWaitMs = minOf(WRITE_BACKPRESSURE_WAIT_MS,
                        budget?.let { remainingRefusedRelayChunkWait(clock, it) } ?: Long.MAX_VALUE)
                    val admitted = admitRelayCallMessage(clock, responseDeadlineMs, admissionWaitMs, connection::isClosed,
                        { relayCallParkedWriteBudget(connection.controller.diagnosticStream) }) {
                        connection.sendMessage(request, 0L)
                    }
                    checkChunkFetchDeadline()
                    if (!admitted) throw RelayException(relayMessageNotAdmittedMessage(admissionWaitMs))
                } catch (t: Throwable) {
                    fetchSequencesByRequestId.remove(requestId)
                    connection.responseDiagnostics.fetches = connection.responseDiagnostics.fetches.filterNot {
                        it.requestId == requestId
                    }
                    outstandingChunkFetchPermits--
                    chunkFetchBudget.release()
                    throw t
                }
            }

            fun trySendChunkFetch(seq: Int): Boolean {
                if (!acquireChunkFetchPermit()) return false
                sendChunkFetchWithPermit(seq)
                return true
            }

            fun awaitAndSendChunkFetch(seq: Int, refused: RefusedRelayResponseChunk? = null) {
                // This blocking path is called only when this transfer holds ZERO permits. A transfer
                // with replies in flight must keep reading them so those permits can be released; if it
                // blocked here while holding permits, two transfers could deadlock waiting for capacity
                // that only their unread replies can return.
                check(outstandingChunkFetchPermits == 0) {
                    "A relay response transfer may wait for a shared fetch permit only with no replies in flight, " +
                        "but held $outstandingChunkFetchPermits"
                }
                awaitChunkFetchPermit(refused)
                if (refused != null) checkRefusedRelayChunkDeadline(clock, refused)
                sendChunkFetchWithPermit(seq)
            }
            try {
                val window = minOf(firstChunk.total - 1, relayResponseChunkFetchWindow)
                var nextToRequest = 1
                fun replenishFetches() {
                    while (refusedSequences.isNotEmpty()) {
                        val sequence = refusedSequences.first()
                        val refused = checkNotNull(refusedChunks[sequence])
                        awaitRefusedRelayChunkTurn(clock, refused)
                        if (!trySendChunkFetch(sequence)) break
                        refusedSequences.removeFirst()
                    }
                    if (refusedSequences.isEmpty()) {
                        while (
                            nextToRequest < firstChunk.total && nextToRequest - nextToWrite < window &&
                            !connection.isClosed() && trySendChunkFetch(nextToRequest)
                        ) nextToRequest++
                    }
                    // A transfer with unread replies must keep draining them. Blocking for a
                    // shared permit while owning other permits would prevent their return.
                    if (outstandingChunkFetchPermits == 0 && !connection.isClosed()) {
                        if (refusedSequences.isNotEmpty()) {
                            val sequence = refusedSequences.removeFirst()
                            awaitAndSendChunkFetch(sequence, checkNotNull(refusedChunks[sequence]))
                        } else if (nextToRequest < firstChunk.total && nextToRequest - nextToWrite < window) {
                            awaitAndSendChunkFetch(nextToRequest)
                            nextToRequest++
                        }
                    }
                }
                replenishFetches()
                while (received < firstChunk.total) {
                    val budget = refusalBudget
                    val chunkJson = try {
                        if (budget == null) readForwardedResponse(connection, timeout, timeoutUnit, clock, responseDeadlineMs)
                        else readForwardedResponse(connection, remainingRefusedRelayChunkWait(clock, budget), TimeUnit.MILLISECONDS, clock, responseDeadlineMs)
                    } catch (failure: RelayException) {
                        if (budget != null && !Thread.currentThread().isInterrupted) checkRefusedRelayChunkDeadline(clock, budget)
                        throw failure
                    }
                    if (budget != null) checkRefusedRelayChunkDeadline(clock, budget)
                    if (chunkJson == null) throw RelayException(
                            "Timeout or invalid response fetching response chunks " +
                                "(got $received/${firstChunk.total})"
                        )
                    outstandingChunkFetchPermits--
                    chunkFetchBudget.release()
                    val chunkResponse = RelayProtocol.parseMessage(chunkJson) as? RelayProtocol.RelayResponse
                        ?: throw RelayException(
                            "Timeout or invalid response fetching response chunks " +
                                "(got $received/${firstChunk.total})"
                        )
                    if (!chunkResponse.success && chunkResponse.wasDefinitelyNotDispatched()) {
                        connection.responseDiagnostics.fetches = connection.responseDiagnostics.fetches.filterNot {
                            it.requestId == chunkResponse.requestId
                        }
                        val sequence = fetchSequencesByRequestId.remove(chunkResponse.requestId)
                            ?: throw RelayException(
                                "Not-dispatched chunk refusal has no pending fetch with requestId ${chunkResponse.requestId}; " +
                                    "the application request was not resent",
                            )
                        val refused = refusedChunks.getOrPut(sequence) {
                            val timeoutMs = timeoutUnit.toMillis(timeout)
                            RefusedRelayResponseChunk(
                                sequence, responseDeadlineMs,
                                timeoutMs, checkNotNull(chunkResponse.displayErrorMessage()),
                            )
                        }
                        refusalBudget = refused
                        refusedSequences.addLast(sequence)
                        replenishFetches()
                        continue
                    }
                    if (!chunkResponse.success) {
                        throw RelayException("Relay response chunk fetch failed: ${chunkResponse.errorMessage}")
                    }
                    val parsed = parseNegotiatedResponseChunk(chunkResponse, Base64.getDecoder().decode(chunkResponse.payload), firstChunk.opaqueFraming)
                        ?: throw RelayException("Relay response chunk missing chunk envelope (got $received/${firstChunk.total})")
                    if (parsed.seq <= 0 || parsed.seq >= firstChunk.total) {
                        throw RelayException("Relay response chunk seq ${parsed.seq} out of range [1, ${firstChunk.total})")
                    }
                    if (parsed.transferId != firstChunk.transferId || parsed.total != firstChunk.total) {
                        throw RelayException("Relay response chunk belongs to a different transfer or total")
                    }
                    val matchingFetch = fetchSequencesByRequestId.entries.firstOrNull { it.value == parsed.seq }
                    if (parsed.seq < nextToWrite || parsed.seq >= nextToRequest || chunks.containsKey(parsed.seq) || matchingFetch == null) {
                        throw RelayException("Relay response chunk sequence ${parsed.seq} was not pending in [$nextToWrite, $nextToRequest)")
                    }
                    connection.responseDiagnostics.fetches = connection.responseDiagnostics.fetches.filterNot {
                        it.requestId == checkNotNull(matchingFetch).key
                    }
                    fetchSequencesByRequestId.remove(checkNotNull(matchingFetch).key)
                    refusedChunks.remove(parsed.seq)
                    chunks[parsed.seq] = parsed.data
                    received++
                    while (true) {
                        val data = chunks.remove(nextToWrite) ?: break
                        output.write(data)
                        nextToWrite++
                    }
                    replenishFetches()
                }
                reusableRelayRequestConnection = !usingDirectPath && relayRequestReuseAllowed
                return
            } finally {
                connection.responseDiagnostics.fetches = emptyList()
                if (outstandingChunkFetchPermits > 0) {
                    chunkFetchBudget.release(outstandingChunkFetchPermits)
                    outstandingChunkFetchPermits = 0
                }
            }
        } finally {
            raceLifecycleLock.withLock { activeRelayRequestConnections.remove(connection) }
            if (!usingDirectPath && relayRequestReuseAllowed) {
                releaseRelayRequestConnection(
                    relayPeerId,
                    connection,
                    reusableRelayRequestConnection
                )
            } else {
                connection.close()
            }
        }
    }

    /**
     * Gets information about a peer registered with this relay.
     *
     * @param targetPeerId The peer ID to look up.
     * @return Registration info if the peer is registered, null otherwise.
     */
    fun getRegisteredPeerInfo(targetPeerId: String): RegisteredPeerInfo? {
        val registration = registeredPeers[targetPeerId] ?: return null
        return RegisteredPeerInfo(
            peerId = registration.peerId,
            advertisedServices = registration.advertisedServices,
            registeredAt = registration.registeredAt,
            expiresAt = registration.expiresAt
        )
    }

    /**
     * Returns the set of peer IDs currently registered with the relay.
     * This is a snapshot — registrations may expire between the call and use.
     */
    fun getRegisteredPeerIds(): Set<String> {
        val peerIds = LinkedHashSet<String>()
        // Iterate directly because toSet() branches on the live view's size. A registration can
        // expire between that size read and iteration, including during the size-one branch.
        for (peerId in registeredPeers.keys) {
            peerIds.add(peerId)
        }
        return peerIds
    }

    /**
     * Connects to a specific relay by peer ID and address.
     *
     * @param relayPeerId The peer ID of the relay.
     * @param relayAddress The multiaddress of the relay.
     */
    fun connectToRelay(relayPeerId: String, relayAddress: String) {
        // Add the relay to the peer registry if not already present
        val existingPeer = peerRegistry.getPeer(relayPeerId)
        if (existingPeer == null) {
            val peer = Libp2pPeer.remote(
                peerId = relayPeerId,
                multiaddresses = listOf(relayAddress),
                advertisedServices = emptyList()
            )
            peerRegistry.addPeer(peer, origin = PeerRegistryAddOrigin.RELAY)
        }

        // Register with the relay using a default handler
        registerWithRelay(relayPeerId) { request ->
            // Default handler - this will be replaced by the actual service handler
            RelayProtocol.RelayResponse.error(
                requestId = request.requestId,
                sourcePeerId = request.targetPeerId,
                targetPeerId = request.sourcePeerId,
                errorMessage = "No handler registered for this peer"
            )
        }
    }

    /**
     * Pings a relay to measure latency.
     *
     * @param relayPeerId The peer ID of the relay to ping.
     * @return Latency in milliseconds.
     */
    fun pingRelay(relayPeerId: String): Long {
        val relayPeer = peerRegistry.getPeer(relayPeerId)
            ?: throw IllegalArgumentException("Relay peer $relayPeerId not found in registry")

        val connection = connectToRelay(relayPeer)

        try {
            val ping = RelayProtocol.RelayPing(
                id = RelayProtocol.nextMessageId()
            )

            connection.sendMessage(ping.toJson())
            val response = connection.readMessage(5, TimeUnit.SECONDS)
                ?: throw IllegalStateException("No pong response from relay")
            val pong = RelayProtocol.RelayPong.fromJson(response)

            val latency = pong.calculateLatencyMs().coerceAtLeast(1L)
            linkStateLinkCosts[relayPeerId] = latency
            updateLocalLinkStateAdvertisement(force = true)
            return latency
        } finally {
            connection.close()
        }
    }

    /**
     * Handles an incoming stream on the relay protocol.
     * Called by the libp2p host when a new relay stream is opened.
     *
     * Sets up a non-blocking Netty pipeline for message processing instead of
     * spawning a dedicated thread per stream.
     *
     * Returns the [RelayMessageSender] for the stream so that callers can reuse it
     * instead of creating a duplicate controller (which would interfere with data reception).
     */
    fun handleIncomingStream(stream: Stream): RelayMessageSender {
        debugLog { "[RELAY-DEBUG] RelayService.handleIncomingStream called, remotePeer=${stream.remotePeerId()}" }
        val sender = StreamRelayMessageSender(stream)
        debugLog { "[RELAY-DEBUG] StreamRelayMessageSender created for peer=${stream.remotePeerId()}" }
        // Set up NIO pipeline: ReadTimeoutHandler → LengthFieldBasedFrameDecoder → RelayServerMessageHandler
        stream.pushHandler(ReadTimeoutHandler(60, TimeUnit.SECONDS))
        stream.pushHandler(LengthFieldBasedFrameDecoder(10_000_000, 0, 4, 0, 4))
        val handler = RelayServerMessageHandler(stream, sender, this)
        activeServerHandlers.add(handler)
        stream.pushHandler(handler)
        return sender
    }

    // Live RelayServerMessageHandler instances on this relay. Tracked so that tests
    // (and operator dashboards) can observe per-stream pending-processing depth, which
    // is the canonical signal for the "inbound queue grew unbounded under a stuck
    // forward target" failure mode (see [RelayServerMessageHandler.pendingProcessingCount]).
    private val activeServerHandlers = java.util.concurrent.CopyOnWriteArrayList<RelayServerMessageHandler>()

    internal fun unregisterServerHandler(handler: RelayServerMessageHandler) {
        activeServerHandlers.remove(handler)
    }

    /**
     * Sum of [RelayServerMessageHandler.pendingProcessingCount] across every live
     * server-side relay stream on this RelayService. A bounded value under steady
     * inbound load is the contract that backpressure in [RelayServerMessageHandler]
     * is supposed to enforce; tests assert against this to catch regressions.
     */
    fun currentTotalPendingProcessing(): Int =
        activeServerHandlers.sumOf { it.pendingProcessingCount() }

    /**
     * Maximum [RelayServerMessageHandler.pendingProcessingCount] across every live
     * server-side relay stream. Useful when a test wants to verify that NO single
     * stream blew past the per-stream pause threshold.
     */
    fun maxPerStreamPendingProcessing(): Int =
        activeServerHandlers.maxOfOrNull { it.pendingProcessingCount() } ?: 0

    /**
     * Backpressure hook plumbed through the async forward path. The handler that
     * invokes [processIncomingMessage] increments its per-stream pending count
     * **before** the launch (existing behaviour) and decrements when the launch
     * body returns. Async forwarding paths additionally call
     * [beforeAsyncForwardScheduled] just before scheduling
     * `future.whenCompleteAsync(...)`, and [afterAsyncForwardCompleted] from
     * after that callback's reply has entered the outbox allowance or its connection has closed.
     * This makes the per-stream pending count track
     * `(queued + in-flight async forwards)` rather than just `queued` — without
     * which the queue cap from PR #252 would not bound the heap exposure of
     * in-flight forwards (each pinning its captured `RelayRequest`,
     * `sourceController`, and lambda state). Synchronous-reply paths (local
     * handling, no-route error) leave the sink alone — the launch's own +1/−1
     * already accounts for them.
     */
    internal interface InflightForwardSink {
        fun beforeAsyncForwardScheduled()
        fun afterAsyncForwardCompleted()
    }

    internal interface IdentityPublicationCompletionSink {
        fun trackIdentityPublication(
            providerPeerId: String,
            publication: IdentityPublicationCompletion
        )
    }

    /**
     * Processes a single incoming relay/gossip message from a stream.
     * Called by [RelayServerMessageHandler] for each complete message frame.
     *
     * @param json The parsed JSON message
     * @param sender The message sender for writing responses back
     * @param stream The underlying libp2p stream
     * @param registeredPeerId The currently tracked registered peer ID for this stream (may be null)
     * @return The updated registered peer ID (may differ from input if a register/unregister occurred)
     */
    internal suspend fun processIncomingMessage(
        json: JSONObject,
        sender: RelayMessageSender,
        stream: Stream,
        registeredPeerId: String?,
        inflightSink: InflightForwardSink? = null,
        publicationCompletionSink: IdentityPublicationCompletionSink? = null,
        streamGeneration: Long? = null
    ): RelayMessageProcessingOutcome {
        debugLog { "[RELAY-DEBUG] Received message: ${json.toString().take(200)}" }

        // Try to parse the message, handling unknown message types gracefully
        val message = try {
            parseRelayOrGossipMessage(json)
        } catch (failure: RelayRequestFieldParsingException) {
            val requestId = json.optString("requestId", "")
            val sourcePeerId = json.optString("sourcePeerId", "")
            val targetPeerId = json.optString("targetPeerId", "")
            val response = RelayProtocol.RelayResponse.error(
                requestId = requestId,
                sourcePeerId = targetPeerId,
                targetPeerId = sourcePeerId,
                errorMessage = "Relay request parse error: ${failure.message}",
            )
            val outboxFullResponse = RelayProtocol.RelayResponse.error(
                requestId = requestId,
                sourcePeerId = targetPeerId,
                targetPeerId = sourcePeerId,
                errorMessage =
                    "$AWAITED_RESPONSE_OUTBOX_FULL_CODE: $AWAITED_RESPONSE_OUTBOX_FULL_MESSAGE",
            )
            val failureReservation = sender.reserveAwaitedResponseFailure(
                outboxFullResponse.toJson()
            )
            if (
                failureReservation == null &&
                (sender is StreamRelayMessageSender || sender is RelayStreamController)
            ) {
                throw RelayException(
                    "Malformed relay request $requestId could not be declined because its source " +
                        "connection closed before reply-failure capacity could be reserved"
                )
            }
            sendReplyToSourceQuietly(sender, response, failureReservation)
            return RelayMessageProcessingOutcome(registeredPeerId)
        } catch (failure: RuntimeException) {
            if (failure !is JSONException && failure !is IllegalArgumentException) throw failure
            gossipHandler?.recordAuthenticatedInteractionCompatible(
                stream.remotePeerId().toBase58(),
                PeerInteractionSeverity.SEVERE,
            )
            debugLog { "[RELAY] Refused malformed relay/gossip frame: ${failure.message?.take(200)}" }
            return RelayMessageProcessingOutcome(registeredPeerId)
        }

        var updatedRegisteredPeerId = registeredPeerId
        var synchronousFailure: RelaySynchronousForwardFailure? = null

        when (message) {
            is RelayProtocol.RelayRegister -> {
                handleRegister(
                    message,
                    sender,
                    stream,
                    awaitExternalVisibility = false
                )?.let { publication ->
                    publicationCompletionSink?.trackIdentityPublication(message.peerId, publication)
                }
                updatedRegisteredPeerId = message.peerId
            }
            is RelayProtocol.RelayUnregister -> {
                val completion = handleUnregister(
                    message,
                    sender,
                    awaitExternalVisibility = false
                )
                val committed = completion.requestStateTransitionCommitted
                val acknowledgement = RelayProtocol.RelayUnregisterAck(
                    requestId = message.requestId,
                    success = completion.unregisterAcknowledged,
                    relayPeerId = peerId,
                    errorMessage = if (completion.unregisterAcknowledged) null else
                        "This relay stream no longer owns the active registration for peer ${message.peerId}"
                )
                if (!sender.trySendMessage(
                        acknowledgement.toJson(),
                        WRITE_BACKPRESSURE_DELIVERY_WAIT_MS
                    )
                ) {
                    throw RelayException(
                        "Relay unregister acknowledgement ${message.requestId} for peer " +
                            "${message.peerId} was not admitted within the " +
                            "${WRITE_BACKPRESSURE_DELIVERY_WAIT_MS}ms delivery budget"
                    )
                }
                relayUnregisterAcknowledgementAdmittedTestSeam?.invoke(message.requestId)
                if (committed && message.peerId == updatedRegisteredPeerId) {
                    updatedRegisteredPeerId = null
                }
            }
            is RelayProtocol.RelayRequest -> {
                val outboxFullReply = RelayProtocol.RelayResponse.error(
                    requestId = message.requestId,
                    sourcePeerId = message.sourcePeerId,
                    targetPeerId = message.targetPeerId,
                    errorMessage =
                        "$AWAITED_RESPONSE_OUTBOX_FULL_CODE: $AWAITED_RESPONSE_OUTBOX_FULL_MESSAGE",
                )
                val failureReservation = sender.reserveAwaitedResponseFailure(
                    outboxFullReply.toJson()
                )
                if (
                    failureReservation == null &&
                    (sender is StreamRelayMessageSender || sender is RelayStreamController)
                ) {
                    throw RelayException(
                        "Relay request ${message.requestId} was not dispatched because its source " +
                            "connection closed before reply-failure capacity could be reserved"
                    )
                }
                try {
                    synchronousFailure = handleRelayRequest(
                        message,
                        sender,
                        inflightSink,
                        failureReservation,
                    )
                } catch (failure: Exception) {
                    failureReservation?.close()
                    throw failure
                }
                // A locally computed reply that had to wait for outbox space keeps this stream
                // from processing further requests until it is queued for sending, so waiting
                // replies stay bounded instead of accumulating behind a full outbox.
                if (synchronousFailure == null) failureReservation?.awaitResponseAdmission()
            }
            is RelayProtocol.RelayResponse -> handleRelayResponse(message)
            is RelayProtocol.RelayPing -> handlePing(message, sender)
            is RelayProtocol.RelayKeepalive -> handleKeepalive(message)

            // Handle gossip messages received from registered peers via the relay connection
            is GossipProtocol.ServiceAnnouncement -> {
                debugLog { "[RELAY] Received service announcement from registered peer: ${message.serviceIdentifier}" }
                val acceptedMessage = relayGossipMessageWithoutNestedCircuitAddresses(
                    message.toJson(),
                    "during registered-client service-announcement receipt",
                )?.let { GossipProtocol.ServiceAnnouncement.fromJson(it) }
                    ?: return RelayMessageProcessingOutcome(updatedRegisteredPeerId, synchronousFailure)
                // Route through cacheServiceAnnouncement instead of writing the map directly so the
                // withdrawal-timestamp guard applies on every cache write — including announcements
                // that arrive on a different stream's serialized scope after this relay has already
                // recorded a withdrawal for the same (serviceId, providerPeerId).
                val senderPeerId = updatedRegisteredPeerId ?: stream.remotePeerId().toString()
                // Admission owns the provider/inventory/cache transaction and publishes any
                // eviction afterward. An outer provider lock would remain held in that callback.
                val accepted = cacheServiceAnnouncementIfAccepted(
                    acceptedMessage.serviceIdentifier,
                    acceptedMessage.toJson(),
                    ownerStreamGeneration = streamGeneration,
                    ownerPeerId = senderPeerId
                )
                if (accepted) {
                    val shouldFanOut = shouldFanOutServiceAnnouncement(acceptedMessage, senderPeerId)
                    // KNOWN pre-existing residual race (verified on main): cache admission and
                    // external publication are separate, so a concurrent lifecycle transition can
                    // still change the provider between them. Root cause #11 only retains
                    // disconnect tombstones; callbacks and transport writes must remain outside
                    // lifecycle/provider locks and this publication race is tracked separately.
                    if (shouldFanOut) {
                        notifyServiceAnnouncementFromRegisteredClient(acceptedMessage, senderPeerId)
                        forwardGossipToRegisteredPeers(acceptedMessage.toJson(), excludePeerId = senderPeerId)
                    } else {
                        debugLog {
                            "[RELAY] Suppressed unchanged service announcement " +
                                "'${message.serviceIdentifier}' from " +
                                message.providerPeerId.takeLast(8)
                        }
                    }
                } else {
                    debugLog {
                        "[RELAY] Rejected service announcement '${message.serviceIdentifier}' " +
                            "without publishing or forwarding it"
                    }
                }
            }
            is GossipProtocol.PeerAnnouncement -> {
                debugLog { "[RELAY] Received peer announcement from registered peer: ${message.peerId}" }
                val acceptedMessage = relayGossipMessageWithoutNestedCircuitAddresses(
                    message.toJson(),
                    "during registered-client peer-announcement receipt",
                )?.let { GossipProtocol.PeerAnnouncement.fromJson(it) }
                    ?: return RelayMessageProcessingOutcome(updatedRegisteredPeerId, synchronousFailure)
                val senderPeerId = updatedRegisteredPeerId ?: stream.remotePeerId().toString()
                notifyPeerAnnouncementFromRegisteredClient(acceptedMessage, senderPeerId)
                forwardGossipToRegisteredPeers(acceptedMessage.toJson(), excludePeerId = senderPeerId)
            }
            is GossipProtocol.TldResolverAnnouncement -> {
                debugLog { "[RELAY] Received TLD resolver announcement from registered peer: ${message.descriptor.tld}" }
                val senderPeerId = updatedRegisteredPeerId ?: stream.remotePeerId().toString()
                notifyTldResolverAnnouncementFromRegisteredClient(message, senderPeerId)
                val accepted = gossipHandler?.onTldResolverQuery()
                    ?.any { it.descriptor.tld == message.descriptor.tld && it.descriptor.signatureBase64 == message.descriptor.signatureBase64 }
                    ?: false
                if (accepted) {
                    forwardGossipToRegisteredPeers(message.toJson(), excludePeerId = senderPeerId)
                }
            }
            is GossipProtocol.ServiceWithdrawal -> {
                debugLog { "[RELAY] Received service withdrawal from registered peer: ${message.serviceIdentifier}" }
                // Record BEFORE notifying handler / forwarding so a delayed gossip rebroadcast
                // arriving on another stream's scope cannot resurrect this service in the cache.
                val preparedWithdrawal = prepareReceivedServiceWithdrawal(message)
                val senderPeerId = updatedRegisteredPeerId ?: stream.remotePeerId().toString()
                clearRelayIngressAnnouncementFingerprint(senderPeerId, message.serviceIdentifier)
                // Fan-out is external I/O and can fail because an unrelated observer is stalled.
                // Running it inline on this source stream used to let that failure escape the
                // message handler, which closed the healthy source registration and discarded
                // other withdrawals already admitted to it. Queue the committed withdrawal on the
                // identity publication worker instead: it retains failures for retry, preserves
                // per-provider ordering, and isolates the source stream from another peer's
                // backpressure. Retain the original sender only for echo suppression and callback
                // ingress metadata.
                scheduleRelayIdentityWithdrawals(
                    preparedWithdrawal.expiredTombstones + preparedWithdrawal.received.copy(
                        excludePeerId = senderPeerId,
                        callbackSenderPeerId = senderPeerId
                    )
                )
            }

            is RelayProtocol.DistanceVector -> {
                debugLog { "[RELAY] Received distance_vector from ${message.sourcePeerId} with ${message.entries.size} entries" }
                routingTable.processDistanceVector(message)
            }
            is LinkStateAdvertisement -> {
                val senderPeerId = updatedRegisteredPeerId ?: stream.remotePeerId().toString()
                debugLog { "[LINK-STATE] Received LSA from ${message.originPeerId} via $senderPeerId with ${message.links.size} links" }
                processLinkStateAdvertisement(message, senderPeerId)
            }

            else -> { /* Ignore unknown messages */ }
        }

        return RelayMessageProcessingOutcome(updatedRegisteredPeerId, synchronousFailure)
    }

    /**
     * Cleans up registration when a relay stream closes.
     * Called by [RelayServerMessageHandler.channelInactive].
     *
     * Only removes the registration if THIS stream's sender is the one currently
     * registered. A peer may open multiple streams (e.g., due to reconnection
     * or retry logic), and each registration overwrites the previous one.
     * If an EARLIER stream closes, we must NOT remove the registration that
     * belongs to the CURRENT (later) stream.
     *
     * Local replay state cleanup removes entries naming the disconnected provider when they came
     * from this stream or another peer that forwarded the provider's announcement. An overlapping
     * replacement stream from the same provider retains entries that it owns. The compact provider
     * inventory and its existing registration expiry move into a disconnected-provider tombstone,
     * which also prevents a delayed forwarded copy from repopulating replay state during grace.
     *
     * NOTE: Stream close does NOT broadcast [GossipProtocol.ServiceWithdrawal]
     * messages to the network, and does NOT invoke the
     * [GossipHandler.onServiceWithdrawal] callback. A dropped libp2p stream
     * under CPU contention / transient Netty errors is a connectivity event,
     * not an authoritative "the peer no longer provides these services"
     * signal — the peer itself may reconnect and re-register within
     * milliseconds. Previously, broadcasting synthetic withdrawals on every
     * stream close was the root cause of the recurring
     * stressTestPeerExchangeResponseServiceDiscovery flake in UrlResolver:
     * the withdrawals cleared the provider's advertisedServices throughout
     * the network and nothing restored them until the provider's 5-minute
     * re-announce job fired, during which PeerExchange responses carried
     * empty service lists and late-joining clients could not populate
     * discoveredServices via the sync pull path. Genuine "peer is gone"
     * paths — explicit [handleRelayUnregister] and
     * [cleanupExpiredRegistrations] — still broadcast withdrawals and invoke
     * the gossip callback; those signals ARE authoritative.
     *
     * @return `true` when at least one cached announcement naming [registeredPeerId] was removed.
     */
    private fun cachedAnnouncementBelongsToStream(
        cached: CachedServiceAnnouncement,
        registeredPeerId: String,
        streamGeneration: Long?
    ): Boolean = streamGeneration != null &&
        cached.ownerStreamGeneration == streamGeneration &&
        cached.message.providerPeerId == registeredPeerId

    internal fun cleanupStreamRegistration(
        registeredPeerId: String,
        sender: RelayMessageSender,
        streamGeneration: Long? = null
    ): Boolean {
        var preparedTombstoneWithdrawals: List<PreparedServiceWithdrawal>
        var displacedRegistrationDisconnected = false
        var cachedAnnouncementRemoved = false
        var preservedReplacement = false
        val disconnectedRegistration = synchronized(registrationLifecycleLock) {
            val now = clock.currentTimeMillis()
            preparedTombstoneWithdrawals =
                pruneExpiredDisconnectedProviderTombstonesLocked(now)
            synchronized(providerLifecycleLock(registeredPeerId)) {
                val currentReg = registeredPeers[registeredPeerId]
                if (currentReg != null && currentReg.controller.matchesStreamSender(sender)) {
                    if (!withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                        registeredPeers.remove(registeredPeerId, currentReg)
                    }) {
                        null
                    } else {
                        preparedTombstoneWithdrawals =
                            preparedTombstoneWithdrawals +
                                installDisconnectedProviderTombstoneWithProviderLock(
                                    registeredPeerId,
                                    currentReg.serviceInventory,
                                    now
                                )
                        cachedAnnouncementRemoved =
                            synchronized(cachedServiceAnnouncementsLock) {
                                removeCachedServiceAnnouncementsLocked { _, cached ->
                                    cached.message.providerPeerId == registeredPeerId &&
                                        (cached.ownerPeerId != registeredPeerId ||
                                            cachedAnnouncementBelongsToStream(
                                                cached,
                                                registeredPeerId,
                                                streamGeneration
                                            ))
                                }
                            } || cachedAnnouncementRemoved
                        currentReg
                    }
                } else {
                    val staged = relayRegistrationTransactions[registeredPeerId]
                        ?.owner
                        ?.stagedRegistration
                        ?.takeIf { it.registration === currentReg }
                    val displacedRegistration = staged?.previousRegistration
                    if (staged != null &&
                        displacedRegistration != null &&
                        !staged.previousRegistrationClosed &&
                        displacedRegistration.controller.matchesStreamSender(sender)
                    ) {
                        staged.previousRegistrationClosed = true
                        displacedRegistrationDisconnected = true
                        preparedTombstoneWithdrawals =
                            preparedTombstoneWithdrawals +
                                installDisconnectedProviderTombstoneWithProviderLock(
                                    registeredPeerId,
                                    displacedRegistration.serviceInventory,
                                    now
                                )
                        cachedAnnouncementRemoved =
                            synchronized(cachedServiceAnnouncementsLock) {
                                removeCachedServiceAnnouncementsLocked { _, cached ->
                                    cachedAnnouncementBelongsToStream(
                                        cached,
                                        registeredPeerId,
                                        streamGeneration
                                    )
                                }
                            } || cachedAnnouncementRemoved
                    } else if (currentReg != null) {
                        // The replacement registration is already current, but this stream may
                        // still own announcements accepted before the replacement committed.
                        // Keep the replacement registration and its generation-owned entries;
                        // remove only the closing stream's generation while holding the same
                        // cache lock used by announcement admission and the other cleanup paths.
                        cachedAnnouncementRemoved =
                            synchronized(cachedServiceAnnouncementsLock) {
                                removeCachedServiceAnnouncementsLocked { _, cached ->
                                    cachedAnnouncementBelongsToStream(
                                        cached,
                                        registeredPeerId,
                                        streamGeneration
                                    )
                                }
                            } || cachedAnnouncementRemoved
                        preservedReplacement = true
                    } else {
                        // A stream may cache an announcement before its first registration
                        // coroutine returns. Remove only entries written by this stream generation;
                        // a concurrent stream from the same peer may have written other live state.
                        cachedAnnouncementRemoved =
                            synchronized(cachedServiceAnnouncementsLock) {
                                removeCachedServiceAnnouncementsLocked { _, cached ->
                                    cachedAnnouncementBelongsToStream(
                                        cached,
                                        registeredPeerId,
                                        streamGeneration
                                    )
                                }
                            } || cachedAnnouncementRemoved
                    }
                    null
                }
            }
        }
        if (preservedReplacement) {
            debugLog { "[RELAY-DEBUG] Stream closed for peer $registeredPeerId but registration belongs to a different stream - keeping registration" }
        }
        if (disconnectedRegistration != null) {
            routingTable.removeNeighbor(registeredPeerId)
            updateLocalLinkStateAdvertisement()
            // Local bookkeeping: remove only announcements written through this stream
            // generation. We cannot replay those entries through a closed stream, while a
            // concurrent stream from the same peer may still own and serve its own entries.
            debugLog { "[RELAY-DEBUG] Removed live registration for peer $registeredPeerId (stream closed; retained compact provider inventory until expiry; cleared this stream generation's cached announcements; NOT broadcasting withdrawals — a transient stream close is not an authoritative withdrawal)" }
        } else if (displacedRegistrationDisconnected) {
            debugLog { "[RELAY-DEBUG] Retained the staged replacement for peer $registeredPeerId after its displaced previous stream closed; the previous inventory remains tombstoned until replacement commit or expiry" }
        }
        val withdrawalTickets = scheduleRelayIdentityWithdrawals(preparedTombstoneWithdrawals)
        // Capacity eviction historically completed its externally observable withdrawal before
        // stream cleanup returned. Preserve that boundary without retaining lifecycle/provider
        // locks or the publication gate while callback and wire effects execute.
        for (ticket in withdrawalTickets) {
            ticket.visibilityCompletion.get()
        }
        return cachedAnnouncementRemoved
    }

    /**
     * Caller must hold [registrationLifecycleLock] and [providerLifecycleLock] for [peerId].
     * Expired tombstones must already have been pruned for the caller's current timestamp.
     */
    private fun consumeSupersededDisconnectedProviderTombstoneWithProviderLock(
        peerId: String,
        supersedingInventory: ProviderServiceInventory,
        supersedingProviderTimestamp: Long? = null
    ): List<PreparedServiceWithdrawal> {
        val tombstone = disconnectedProviderTombstones[peerId]
        if (tombstone != null && tombstone.serviceInventory !== supersedingInventory) {
            if (disconnectedProviderTombstones.remove(peerId) !== tombstone) return emptyList()
            check(disconnectedProviderPeerIds.remove(peerId)) {
                "Disconnected-provider marker was missing while removing tombstone for '$peerId'"
            }
            rescheduleDisconnectedProviderExpiryLocked()
            val survivingServices = supersedingInventory.snapshot().toSet()
            val removedServices = tombstone.serviceInventory.deactivateAndSnapshot()
                .filterNot { it.serviceIdentifier in survivingServices }
            if (removedServices.isEmpty()) return emptyList()
            return synchronized(cachedServiceAnnouncementsLock) {
                removedServices.map { service ->
                    // The replacement registration is a provider-issued snapshot: a service
                    // omitted from it was absent no later than the snapshot timestamp. Use that
                    // causal boundary as well as the old lifecycle's strict successor so a
                    // pre-snapshot announcement delayed in another gossip queue cannot outrank
                    // this withdrawal at receivers.
                    val withdrawalTimestamp = maxOf(
                        lifecycleTimestampAfter(service.timestamp),
                        supersedingProviderTimestamp ?: Long.MIN_VALUE
                    )
                    PreparedServiceWithdrawal(
                        withdrawal = createAndRecordServiceWithdrawalLocked(
                            service.serviceIdentifier,
                            peerId,
                            withdrawalTimestamp
                        ),
                        providerRegistrationAtCommit = null
                    )
                }
            }
        }
        return emptyList()
    }

    /** Caller must hold [registrationLifecycleLock]. */
    private fun pruneExpiredDisconnectedProviderTombstonesLocked(
        now: Long
    ): List<PreparedServiceWithdrawal> {
        val preparedWithdrawals = mutableListOf<PreparedServiceWithdrawal>()
        val iterator = disconnectedProviderTombstones.entries.iterator()
        while (iterator.hasNext()) {
            val (providerPeerId, tombstone) = iterator.next()
            // Each tombstone captures one fixed expiry at install, and installation maintains
            // expiry order. The first live entry proves every later entry is live as well.
            if (tombstone.expiresAtMs >= now) break
            iterator.remove()
            synchronized(providerLifecycleLock(providerPeerId)) {
                preparedWithdrawals += prepareDisconnectedProviderTombstoneWithdrawalsWithProviderLock(
                    providerPeerId,
                    tombstone
                )
                check(disconnectedProviderPeerIds.remove(providerPeerId)) {
                    "Disconnected-provider marker was missing while expiring tombstone for '$providerPeerId'"
                }
            }
        }
        rescheduleDisconnectedProviderExpiryLocked()
        return preparedWithdrawals
    }

    /** Caller must hold [registrationLifecycleLock]. */
    private fun rescheduleDisconnectedProviderExpiryLocked() {
        val nextExpiry = disconnectedProviderTombstones.entries.firstOrNull()?.value?.expiresAtMs
        val currentSchedule = disconnectedProviderExpirySchedule
        if (currentSchedule?.expiresAtMs == nextExpiry) return

        currentSchedule?.scheduled?.cancel()
        disconnectedProviderExpirySchedule = null
        if (nextExpiry == null || nextExpiry == Long.MAX_VALUE || closed.get()) return

        val schedule = DisconnectedProviderExpirySchedule(nextExpiry)
        disconnectedProviderExpirySchedule = schedule
        schedule.scheduled = clock.schedule(nextExpiry + 1L) {
            dispatchDisconnectedProviderExpiry(schedule)
        }
        // A ManualClock can advance after the tombstone becomes visible but before schedule()
        // registers this callback. Scheduling first and then re-reading the same injected clock
        // closes that lost-wake window. If the normal callback ran concurrently, the schedule
        // identity check in dispatchDisconnectedProviderExpiry lets only one task prune it.
        if (clock.currentTimeMillis() > nextExpiry &&
            disconnectedProviderExpirySchedule === schedule
        ) {
            schedule.scheduled?.cancel()
            dispatchDisconnectedProviderExpiry(schedule)
        }
    }

    private fun dispatchDisconnectedProviderExpiry(schedule: DisconnectedProviderExpirySchedule) {
        if (closed.get()) return
        try {
            executor.execute {
                val preparedWithdrawals = synchronized(registrationLifecycleLock) {
                    if (disconnectedProviderExpirySchedule !== schedule) {
                        emptyList()
                    } else {
                        disconnectedProviderExpirySchedule = null
                        pruneExpiredDisconnectedProviderTombstonesLocked(clock.currentTimeMillis())
                    }
                }
                scheduleRelayIdentityWithdrawals(preparedWithdrawals)
            }
        } catch (e: RejectedExecutionException) {
            if (!closed.get()) throw e
        }
    }

    /** Caller must hold [registrationLifecycleLock] and [providerLifecycleLock] for [peerId]. */
    private fun installDisconnectedProviderTombstoneWithProviderLock(
        peerId: String,
        serviceInventory: ProviderServiceInventory,
        now: Long
    ): List<PreparedServiceWithdrawal> {
        val preparedWithdrawals = mutableListOf<PreparedServiceWithdrawal>()
        preparedWithdrawals += consumeSupersededDisconnectedProviderTombstoneWithProviderLock(
            peerId,
            serviceInventory
        )
        val tombstone = DisconnectedProviderTombstone(
            serviceInventory = serviceInventory,
            expiresAtMs = serviceInventory.expiresAt()
        )
        if (tombstone.expiresAtMs < now) {
            preparedWithdrawals += prepareDisconnectedProviderTombstoneWithdrawalsWithProviderLock(
                peerId,
                tombstone
            )
            return preparedWithdrawals
        }

        // Keep LinkedHashMap iteration ordered by the fixed expiry captured at install. Provider
        // keepalives can make disconnect order differ from deadline order, so later-expiring entries
        // are moved behind the new tombstone. Head pruning and capacity eviction are then exact.
        val laterExpiringEntries = disconnectedProviderTombstones.entries
            .filter { (_, existing) -> existing.expiresAtMs > tombstone.expiresAtMs }
            .map { it.key to it.value }
        for ((laterPeerId, _) in laterExpiringEntries) {
            disconnectedProviderTombstones.remove(laterPeerId)
        }
        disconnectedProviderTombstones[peerId] = tombstone
        disconnectedProviderPeerIds.add(peerId)
        for ((laterPeerId, laterTombstone) in laterExpiringEntries) {
            disconnectedProviderTombstones[laterPeerId] = laterTombstone
        }

        if (disconnectedProviderTombstones.size > MAX_DISCONNECTED_PROVIDER_TOMBSTONES) {
            val oldest = disconnectedProviderTombstones.entries.iterator()
            if (oldest.hasNext()) {
                val evicted = oldest.next()
                oldest.remove()
                synchronized(providerLifecycleLock(evicted.key)) {
                    preparedWithdrawals +=
                        prepareDisconnectedProviderTombstoneWithdrawalsWithProviderLock(
                            evicted.key,
                            evicted.value
                        )
                    check(disconnectedProviderPeerIds.remove(evicted.key)) {
                        "Disconnected-provider marker was missing while evicting tombstone for '${evicted.key}'"
                    }
                }
            }
        }
        rescheduleDisconnectedProviderExpiryLocked()
        return preparedWithdrawals
    }

    /** Caller must hold [registrationLifecycleLock] and [providerLifecycleLock] for [peerId]. */
    private fun prepareDisconnectedProviderTombstoneWithdrawalsWithProviderLock(
        peerId: String,
        tombstone: DisconnectedProviderTombstone
    ): List<PreparedServiceWithdrawal> {
        val services = tombstone.serviceInventory.deactivateAndSnapshot()
        if (services.isEmpty()) return emptyList()
        return synchronized(cachedServiceAnnouncementsLock) {
            services.map { service ->
                PreparedServiceWithdrawal(
                    withdrawal = createAndRecordServiceWithdrawalLocked(
                        service.serviceIdentifier,
                        peerId,
                        lifecycleTimestampAfter(service.timestamp)
                    ),
                    providerRegistrationAtCommit = null
                )
            }
        }
    }

    internal fun cleanupStreamRegistrationWithProviderLock(
        registeredPeerId: String,
        sender: RelayMessageSender,
        streamGeneration: Long? = null
    ): Boolean = cleanupStreamRegistration(registeredPeerId, sender, streamGeneration)

    internal fun tossDisconnectedPeerCleanupEffect(
        peerId: String,
        cachedAnnouncementRemoved: Boolean
    ) {
        val effect = RelayDisconnectedPeerCleanupEffect(peerId, cachedAnnouncementRemoved)
        val context = disconnectEffectContextAtStart
        if (context == null) toss(effect)
        else withEffectHandlerContext(context) { toss(effect) }
    }

    internal fun handleRegister(
        request: RelayProtocol.RelayRegister,
        controller: RelayMessageSender,
        stream: Stream,
        awaitExternalVisibility: Boolean = true
    ): IdentityPublicationCompletion? {
        val acceptedRequest = request.copy(
            multiaddresses = filterNestedCircuitPeerMultiaddresses(
                request.peerId,
                request.multiaddresses,
                "before relay connection feedback",
            )
        )
        val transaction = acquireRelayRegistrationTransaction(acceptedRequest.peerId)
        var publicationTicket: RelayIdentityPublicationTicket? = null
        var otherIdentityWithdrawals = emptyList<PreparedServiceWithdrawal>()
        var publicationOwnerInventory: ProviderServiceInventory? = null
        var publicationCanAwaitVisibility = false
        try {
            val publication = handleRegisterTransaction(
                acceptedRequest,
                controller,
                stream,
                transaction,
            )
            if (publication != null) {
                val (identityWithdrawals, foreignWithdrawals) = publication.withdrawals.partition {
                    it.withdrawal.providerPeerId == acceptedRequest.peerId
                }
                otherIdentityWithdrawals = foreignWithdrawals
                publicationOwnerInventory = publication.staged.registration.serviceInventory
                // A generation with captured post-ACK frames owns an independently observable
                // publication result. Its caller must receive that completion without waiting for
                // the frames, because a newer generation may be required to supersede a stalled
                // or failing write. Generations without captured frames can retain the historical
                // direct-call visibility boundary after the transaction has been released.
                publicationCanAwaitVisibility = publication.bufferedMessages.isEmpty()
                publicationTicket = enqueueRelayIdentityPublication(
                    providerPeerId = acceptedRequest.peerId,
                    advertisedServices = publication.staged.committedAdvertisedServices.toSet(),
                    withdrawals = identityWithdrawals,
                    // Registry membership is already visible before the ACK is admitted. The
                    // ordered worker retains the later callbacks, messages, and withdrawals.
                    publishRegistryReplacement = {},
                    publishBufferedMessages = {
                        for (message in publication.bufferedMessages) {
                            publication.controller.sendPendingMessage(message)
                        }
                    },
                    scheduleRegistrationCallback = {
                        scheduleCommittedRelayRegistrationCallback(publication.staged)
                    },
                    scheduleNotifications = {
                        scheduleCommittedRelayRegistrationNotifications(
                            publication.staged,
                            publication.controller
                        )
                    }
                )
            }
        } finally {
            releaseRelayRegistrationTransaction(acceptedRequest.peerId, transaction)
            publicationTicket?.let(::scheduleRelayIdentityPublicationDrain)
            scheduleRelayIdentityWithdrawals(otherIdentityWithdrawals)
        }
        val ticket = publicationTicket ?: return null
        if (awaitExternalVisibility && publicationCanAwaitVisibility &&
            !ticket.hasPublicationPredecessor &&
            relayRegisterAckAdmissionDepth.get() == 0
        ) {
            ticket.visibilityCompletion.get()
        }
        val ownerInventory = checkNotNull(publicationOwnerInventory)
        return IdentityPublicationCompletion(ticket.completion) {
            synchronized(providerLifecycleLock(acceptedRequest.peerId)) {
                registeredPeers[acceptedRequest.peerId]?.serviceInventory === ownerInventory
            }
        }
    }

    private fun handleRegisterTransaction(
        request: RelayProtocol.RelayRegister,
        controller: RelayMessageSender,
        stream: Stream,
        transaction: RelayRegistrationTransaction
    ): PreparedRelayRegistrationPublication? {
        val ack = createRelayRegisterAck(request)
        if (!ack.success) {
            controller.sendMessage(ack.toJson())
            return null
        }

        val staged = synchronized(registrationLifecycleLock) {
            synchronized(providerLifecycleLock(request.peerId)) {
                stageRelayRegistrationWithProviderLock(request, controller, stream).also {
                    transaction.stagedRegistration = it
                }
            }
        }

        val registrySnapshot = relayRegistryPeerSnapshot(request.peerId)
        val bufferedMessages = try {
            // Registry replacement and ACK admission are deliberately outside both the global
            // tombstone lifecycle monitor and the provider stripe. The registry write is complete
            // before the ACK can enter the transport, so an ACK-driven caller cannot observe the
            // old peer view. Post-ACK buffered writes are captured here and published only after
            // the identity transaction is released.
            publishCommittedRelayRegistrationToRegistry(staged)
            val previousDepth = relayRegisterAckAdmissionDepth.get()
            relayRegisterAckAdmissionDepth.set(previousDepth + 1)
            try {
                staged.ackGatedController.sendAckAndRelease(
                    ack.copy(expiresAt = staged.registration.expiresAt).toJson()
                )
            } finally {
                if (previousDepth == 0) {
                    relayRegisterAckAdmissionDepth.remove()
                } else {
                    relayRegisterAckAdmissionDepth.set(previousDepth)
                }
            }
        } catch (e: Exception) {
            try {
                restoreRelayRegistryPeerSnapshot(request.peerId, registrySnapshot)
            } catch (restoreFailure: Exception) {
                e.addSuppressed(restoreFailure)
            }
            synchronized(providerLifecycleLock(request.peerId)) {
                rollbackStagedRelayRegistrationWithProviderLock(staged)
            }
            throw e
        }

        val preparedWithdrawals = mutableListOf<PreparedServiceWithdrawal>()
        synchronized(registrationLifecycleLock) {
            preparedWithdrawals += pruneExpiredDisconnectedProviderTombstonesLocked(
                clock.currentTimeMillis()
            )
            synchronized(providerLifecycleLock(request.peerId)) {
                val committedRegistration = staged.registration.copy(controller = controller)
                check(withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                    registeredPeers.replace(request.peerId, staged.registration, committedRegistration)
                }) {
                    "Relay registration commit for provider '${request.peerId}' lost its staged " +
                        "registration after the ACK completed"
                }
                routingTable.addNeighbor(request.peerId, controller)
                if (!staged.previousRegistrationClosed) {
                    staged.previousRegistration?.serviceInventory?.deactivate()
                }

                synchronized(cachedServiceAnnouncementsLock) {
                    for (serviceIdentifier in staged.cachedServiceKeysSupersededByRegistration) {
                        val cached = cachedServiceAnnouncements[serviceIdentifier] ?: continue
                        if (cached.message.providerPeerId == request.peerId) {
                            removeCachedServiceAnnouncementLocked(serviceIdentifier)
                        }
                    }
                }

                // Consume only the disconnected generation for this provider. Services present in
                // both inventories transfer to the live registration; services absent from the
                // successful replacement are genuinely gone and become authoritative withdrawals.
                preparedWithdrawals +=
                    consumeSupersededDisconnectedProviderTombstoneWithProviderLock(
                        request.peerId,
                        committedRegistration.serviceInventory,
                        supersedingProviderTimestamp = request.timestamp
                    )

                for (displaced in staged.servicesDisplacedDuringRegistration) {
                    preparedWithdrawals += prepareServiceWithdrawalWithProviderLock(
                        serviceIdentifier = displaced.serviceIdentifier,
                        providerPeerId = request.peerId,
                        minimumTimestamp = lifecycleTimestampAfter(displaced.timestamp)
                    )
                }
            }
        }

        return PreparedRelayRegistrationPublication(
            staged,
            controller,
            bufferedMessages,
            preparedWithdrawals
        )
    }

    private fun createRelayRegisterAck(
        request: RelayProtocol.RelayRegister
    ): RelayProtocol.RelayRegisterAck = if (!config.enableRelay) {
        RelayProtocol.RelayRegisterAck(
            requestId = request.requestId,
            success = false,
            relayPeerId = peerId,
            errorMessage = "This peer does not accept relay registrations"
        )
    } else if (registeredPeers.size >= config.maxClients && !registeredPeers.containsKey(request.peerId)) {
        RelayProtocol.RelayRegisterAck(
            requestId = request.requestId,
            success = false,
            relayPeerId = peerId,
            errorMessage = "Relay at capacity"
        )
    } else {
        RelayProtocol.RelayRegisterAck(
            requestId = request.requestId,
            success = true,
            relayPeerId = peerId,
            expiresAt = clock.currentTimeMillis() + config.registrationTimeoutMs
        )
    }

    /**
     * Caller must hold [registrationLifecycleLock] and then the stable
     * [providerLifecycleLock] for [request]'s provider.
     */
    private fun stageRelayRegistrationWithProviderLock(
        request: RelayProtocol.RelayRegister,
        controller: RelayMessageSender,
        stream: Stream
    ): StagedRelayRegistration {
        var committedAdvertisedServices = emptyList<String>()
        var committedServiceLifecycleTimestamps = emptyMap<String, Long>()
        var cachedServiceKeysSupersededByRegistration = emptyList<String>()
        val ackGatedController = AckGatedRelayMessageSender(controller)
        val registrationTimestamp = clock.currentTimeMillis()
        val previousRegistration = registeredPeers[request.peerId]
        val previousLiveness = listOfNotNull(
            previousRegistration?.serviceInventory?.livenessSnapshot(),
            disconnectedProviderTombstones[request.peerId]
                ?.serviceInventory
                ?.livenessSnapshot()
        ).reduceOrNull { left, right ->
            RelayRegistrationLiveness(
                lastReceipt = maxOf(left.lastReceipt, right.lastReceipt),
                expiresAt = maxOf(left.expiresAt, right.expiresAt)
            )
        }
        val serviceInventory = ProviderServiceInventory(
            MAX_SERVICES_PER_LIVE_PROVIDER,
            registrationTimestamp,
            config.registrationTimeoutMs,
            previousLiveness
        )
        val servicesDisplacedDuringRegistration = mutableListOf<ProviderServiceLifecycle>()
        serviceInventory.withStateLock {
            synchronized(cachedServiceAnnouncementsLock) {
                val lockedNow = clock.currentTimeMillis()
                for (serviceIdentifier in request.advertisedServices) {
                    if (!announcementIsSuppressedByWithdrawalLocked(
                            serviceIdentifier,
                            request.peerId,
                            request.timestamp,
                            lockedNow
                        )) {
                        val recorded = serviceInventory.recordLocked(serviceIdentifier, request.timestamp)
                        check(recorded is ProviderServiceRecordResult.Accepted)
                        recorded.displaced?.let(servicesDisplacedDuringRegistration::add)
                    }
                }
                for ((serviceIdentifier, cached) in cachedServiceAnnouncements) {
                    val cachedMessage = cached.message
                    if (cachedMessage.providerPeerId != request.peerId) continue
                    val cachedTimestamp = cachedMessage.timestamp
                    if (cachedTimestamp <= request.timestamp) continue
                    if (announcementIsSuppressedByWithdrawalLocked(
                            serviceIdentifier,
                            request.peerId,
                            cachedTimestamp,
                            lockedNow
                        )) continue
                    val recorded = serviceInventory.recordLocked(serviceIdentifier, cachedTimestamp)
                    check(recorded is ProviderServiceRecordResult.Accepted)
                    recorded.displaced?.let(servicesDisplacedDuringRegistration::add)
                }

                val committedLifecycles = serviceInventory.snapshotLifecyclesLocked()
                val committedTimestampByService = committedLifecycles.associate {
                    it.serviceIdentifier to it.timestamp
                }
                cachedServiceKeysSupersededByRegistration = cachedServiceAnnouncements
                    .mapNotNull { (serviceIdentifier, cached) ->
                        val cachedMessage = cached.message
                        if (cachedMessage.providerPeerId != request.peerId) {
                            return@mapNotNull null
                        }
                        val committedTimestamp = committedTimestampByService[serviceIdentifier]
                        if (committedTimestamp == null ||
                            cachedMessage.timestamp < committedTimestamp
                        ) serviceIdentifier else null
                    }.toList()
                committedAdvertisedServices = committedLifecycles
                    .map(ProviderServiceLifecycle::serviceIdentifier)
                committedServiceLifecycleTimestamps = committedTimestampByService
                servicesDisplacedDuringRegistration.removeAll {
                    it.serviceIdentifier in committedTimestampByService
                }
            }
        }
        val ordinaryGossipGeneration = Any()
        val ordinaryGossipOutbox = OrdinaryRelayGossipOutbox(
            peerId = request.peerId,
            controller = ackGatedController,
            executor = ordinaryRelayGossipExecutor,
            globallyRetainedBytes = ordinaryRelayGossipRetainedBytes,
            workerStartSeam = { ordinaryRelayGossipWorkerStartSeamForTesting?.invoke() },
            latestDeliveryFailure = latestOrdinaryGossipDeliveryFailure,
        ) {
            registeredPeers[request.peerId]?.ordinaryGossipGeneration === ordinaryGossipGeneration
        }
        val registration = RegisteredPeer(
            peerId = request.peerId,
            registrationRequestId = request.requestId,
            serviceInventory = serviceInventory,
            multiaddresses = request.multiaddresses,
            controller = ackGatedController,
            stream = stream,
            registeredAt = registrationTimestamp,
            ordinaryGossipGeneration = ordinaryGossipGeneration,
            ordinaryGossipOutbox = ordinaryGossipOutbox
        )
        // KNOWN pre-existing residual race (verified on main): this staged registration is visible
        // to concurrent snapshots before its ACK. Root cause #11 does not alter that publication
        // contract; the separately tracked publication-race follow-up owns any broader redesign.
        check(withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
            registeredPeers.put(request.peerId, registration)
        } === previousRegistration) {
            "Relay registration staging for provider '${request.peerId}' observed its previous " +
                "registration change while holding the provider lifecycle lock."
        }
        routingTable.addNeighbor(request.peerId, ackGatedController)
        debugLog { "[RELAY] Added ${request.peerId} as staged routing neighbor" }
        return StagedRelayRegistration(
            request = request,
            ackGatedController = ackGatedController,
            registration = registration,
            previousRegistration = previousRegistration,
            registeredPeerAddresses =
                (request.multiaddresses + circuitRelayAddress(host, peerId, request.peerId)).distinct(),
            committedAdvertisedServices = committedAdvertisedServices,
            committedServiceLifecycleTimestamps = committedServiceLifecycleTimestamps,
            cachedServiceKeysSupersededByRegistration = cachedServiceKeysSupersededByRegistration,
            servicesDisplacedDuringRegistration = servicesDisplacedDuringRegistration
        )
    }

    /** Caller must hold the stable [providerLifecycleLock] for the staged provider. */
    private fun rollbackStagedRelayRegistrationWithProviderLock(staged: StagedRelayRegistration) {
        if (!withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
            registeredPeers.remove(staged.request.peerId, staged.registration)
        }) return
        staged.registration.serviceInventory.deactivate()
        if (staged.previousRegistration != null && !staged.previousRegistrationClosed) {
            withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                registeredPeers[staged.request.peerId] = staged.previousRegistration
            }
            routingTable.addNeighbor(
                staged.request.peerId,
                staged.previousRegistration.controller
            )
        } else {
            routingTable.removeNeighbor(staged.request.peerId)
        }
    }

    /** Applies the required external registry replacement before a generation is completed. */
    private fun publishCommittedRelayRegistrationToRegistry(staged: StagedRelayRegistration) {
        val request = staged.request
        val committedAdvertisedServices = staged.committedAdvertisedServices
        val registeredPeerAddresses = staged.registeredPeerAddresses
        val peer = Libp2pPeer.remote(
            peerId = request.peerId,
            multiaddresses = registeredPeerAddresses,
            advertisedServices = committedAdvertisedServices
        )
        peerRegistry.getObservationLog().recordSuccess(request.peerId)
        peerRegistry.addPeer(
            peer,
            origin = PeerRegistryAddOrigin.RELAY,
            replaceServices = true
        )
    }

    private fun relayRegistryPeerSnapshot(peerId: String): RelayRegistryPeerSnapshot {
        val retainedState = peerRegistry.getPeerWithOriginState(peerId)
        return RelayRegistryPeerSnapshot(
            peer = retainedState?.first,
            originState = retainedState?.second
        )
    }

    private fun restoreRelayRegistryPeerSnapshot(
        peerId: String,
        snapshot: RelayRegistryPeerSnapshot
    ) {
        val previousPeer = snapshot.peer
        if (previousPeer == null) {
            peerRegistry.removePeer(peerId)
            return
        }
        val previousOrigin = checkNotNull(snapshot.originState) {
            "Peer registry snapshot for '$peerId' retained a peer without its origin state"
        }
        peerRegistry.restorePeerAfterFailedRelayRegistration(
            previousPeer,
            previousOrigin
        )
    }

    private fun scheduleRelayPublicationCallback(
        description: String,
        predecessor: CompletableFuture<Unit> = CompletableFuture.completedFuture(Unit),
        callback: () -> Unit
    ): CompletableFuture<Unit> {
        val completion = CompletableFuture<Unit>()
        predecessor.whenComplete { _, _ ->
            try {
                relayPublicationCallbackExecutor.execute {
                    try {
                        callback()
                    } catch (t: Throwable) {
                        debugLogErr { "[RELAY] Publication callback failed ($description): ${t.message}" }
                    } finally {
                        completion.complete(Unit)
                    }
                }
            } catch (t: Throwable) {
                debugLogErr { "[RELAY] Could not schedule publication callback ($description): ${t.message}" }
                completion.completeExceptionally(t)
            }
        }
        return completion
    }

    private fun scheduleCommittedRelayRegistrationCallback(
        staged: StagedRelayRegistration
    ): CompletableFuture<Unit> {
        val request = staged.request
        val peerInfo = PeerInfo(
            peerId = request.peerId,
            multiaddresses = staged.registeredPeerAddresses,
            advertisedServices = staged.committedAdvertisedServices,
            serviceLifecycleTimestamps = staged.committedServiceLifecycleTimestamps
        )
        return scheduleRelayPublicationCallback("relay registration for ${request.peerId}") {
            gossipHandler?.onPeerRegisteredWithRelay(peerInfo)
            debugLog { "[RELAY] Notified gossip handler of peer registration: ${request.peerId}" }
        }
    }

    /** Callbacks and transport notification tasks never retain or advance a publication gate. */
    private fun scheduleCommittedRelayRegistrationNotifications(
        staged: StagedRelayRegistration,
        controller: RelayMessageSender
    ): CompletableFuture<Unit> {
        val request = staged.request
        val completion = CompletableFuture<Unit>()
        try {
            relayPublicationNotificationExecutor.execute {
                try {
                    publishCommittedRelayRegistrationNotifications(staged, controller)
                } catch (t: Throwable) {
                    debugLogErr {
                        "[RELAY] Best-effort registration notification failed for " +
                            "${request.peerId}: ${t.message}"
                    }
                } finally {
                    completion.complete(Unit)
                }
            }
        } catch (t: Throwable) {
            debugLogErr {
                "[RELAY] Could not schedule registration notifications for " +
                    "${request.peerId}: ${t.message}"
            }
            completion.completeExceptionally(t)
        }
        return completion
    }

    /** Topology, replay, and peer-list notifications run off both the stream and identity worker. */
    private fun publishCommittedRelayRegistrationNotifications(
        staged: StagedRelayRegistration,
        controller: RelayMessageSender
    ) {
        relayRegistrationNotificationStartTestSeam?.invoke()
        val request = staged.request
        val committedAdvertisedServices = staged.committedAdvertisedServices

        updateLocalLinkStateAdvertisement()
        broadcastDistanceVector()

            // Get relay's public-facing address for circuit addresses
            // Use PublicAddressDiscovery to get the actual public IP instead of wildcard addresses
            val effectiveAddrs = PublicAddressDiscovery.getEffectiveAddresses(host.listenAddresses(), peerId)
            val relayFullAddr = effectiveAddrs.firstOrNull() ?: ""

            // Extract just the transport portion (IP/TCP) without /p2p/ suffix for circuit address construction
            // Format: /ip4/198.199.106.165/tcp/35000 (without /p2p/PEERID)
            val relayBaseAddr = relayFullAddr.replace(Regex("/p2p/[^/]+$"), "")
            debugLog { "[RELAY-DEBUG] Using relay base address: $relayBaseAddr (from effective: $relayFullAddr)" }

            // 1. Send current peer list to the newly registered peer
            val existingPeers = registeredPeers.values
                .filter { it.peerId != request.peerId }
                .map { reg ->
                    val serviceLifecycles = reg.serviceInventory.snapshotLifecycles()
                    // Build circuit relay address for each peer
                    // Format: /ip4/198.199.106.165/tcp/35000/p2p/RELAY_PEER_ID/p2p-circuit/p2p/TARGET_PEER_ID
                    val circuitAddr = if (relayBaseAddr.isNotEmpty()) {
                        "$relayBaseAddr/p2p/$peerId/p2p-circuit/p2p/${reg.peerId}"
                    } else {
                        "/p2p/$peerId/p2p-circuit/p2p/${reg.peerId}"
                    }
                    // Include BOTH the peer's own direct addresses AND the circuit relay address
                    // Direct addresses first (preferred for public peers), relay as fallback
                    val allAddresses = (
                        filterNestedCircuitPeerMultiaddresses(
                            reg.peerId,
                            reg.multiaddresses,
                            "before relay connection feedback",
                        ) + circuitAddr
                    ).distinct()
                    RelayProtocol.RelayPeerList.PeerListEntry(
                        peerId = reg.peerId,
                        multiaddresses = allAddresses,
                        advertisedServices = serviceLifecycles.map(
                            ProviderServiceLifecycle::serviceIdentifier
                        ),
                        serviceLifecycleTimestamps = serviceLifecycles.associate {
                            it.serviceIdentifier to it.timestamp
                        }
                    )
                }

            if (existingPeers.isNotEmpty()) {
                val peerListForNewPeer = RelayProtocol.RelayPeerList(
                    peers = existingPeers,
                    relayPeerId = peerId
                )
                try {
                    controller.sendMessage(peerListForNewPeer.toJson())
                    debugLog { "[RELAY-DEBUG] Sent ${existingPeers.size} existing peers to new peer ${request.peerId}" }
                } catch (e: Exception) {
                    debugLog { "[RELAY-DEBUG] Failed to send peer list to new peer: ${e.message}" }
                }
            }

            // 2. Replay cached service announcements to the new peer via relay connection.
            // This ensures late joiners discover services that were announced BEFORE they
            // registered. Using the relay connection (not a new gossip stream) is reliable
            // because the connection is already established.
            //
            // STALENESS GUARD: a cached announcement is replayed ONLY while there is
            // live evidence its provider still exists — either the provider holds an
            // unexpired relay registration (keepalives refresh expiresAt, so this is the
            // relay's own authoritative liveness signal) or the announcement itself is
            // recent. Without this guard the replay was UNCONDITIONAL, and a provider
            // that crashed without a withdrawal kept being replayed to every late
            // registrant until the relay happened to process the provider's stream close
            // (which purges its cache entries) — a timing race that leaked stale services
            // to late joiners under load. This is the layer that repeatedly defeated the
            // downstream resolver's vouching gates: the replay bypasses them entirely, so
            // the guard must live HERE. Reproduced by UrlResolver's
            // testStaleServiceAnnouncementsNotForwardedToLateJoiners (whose assertion
            // message blames sendDiscoveredServiceAnnouncementsToPeer — three fix
            // attempts targeted that gated path before this ungated replay was found).
            pruneInactiveProviderAnnouncements()
            val cachedAnnouncements = cachedServiceAnnouncementSnapshot()
            if (cachedAnnouncements.isNotEmpty()) {
                var replayCount = 0
                for ((serviceId, cachedMessage) in cachedAnnouncements) {
                    // pruneInactiveProviderAnnouncements already removed entries whose relay-local
                    // receipt deadline elapsed unless the provider is live. Never compare the
                    // provider's wire timestamp with this relay's clock here.
                    try {
                        val acceptedMessage = relayGossipMessageWithoutNestedCircuitAddresses(
                            cachedMessage,
                            "before cached relay service-announcement replay",
                        ) ?: continue
                        debugLog { "[RELAY-DEBUG] Sending cached service announcement '$serviceId' (type=${cachedMessage.optString("type")}) to ${request.peerId.take(8)}" }
                        controller.sendMessage(acceptedMessage)
                        replayCount++
                        debugLog { "[RELAY-DEBUG] Sent cached service announcement '$serviceId' to ${request.peerId.take(8)}" }
                    } catch (e: Exception) {
                        debugLog { "[RELAY-DEBUG] Failed to replay service announcement '$serviceId' to ${request.peerId}: ${e.message}" }
                        break
                    }
                }
                if (replayCount > 0) {
                    debugLog { "[RELAY-DEBUG] Replayed $replayCount cached service announcements to new peer ${request.peerId}" }
                }
            }

            // 3. Broadcast the new peer to all existing registered peers
            val newPeerCircuitAddr = circuitRelayAddress(host, peerId, request.peerId)
            // Include BOTH the peer's own direct addresses AND the circuit relay address
            // Direct addresses first (preferred for public peers), relay as fallback
            val newPeerAllAddresses = (
                filterNestedCircuitPeerMultiaddresses(
                    request.peerId,
                    request.multiaddresses,
                    "before relay connection feedback",
                ) + newPeerCircuitAddr
            ).distinct()
            val newPeerEntry = RelayProtocol.RelayPeerList.PeerListEntry(
                peerId = request.peerId,
                multiaddresses = newPeerAllAddresses,
                advertisedServices = committedAdvertisedServices,
                serviceLifecycleTimestamps = staged.committedServiceLifecycleTimestamps
            )
            val newPeerList = RelayProtocol.RelayPeerList(
                peers = listOf(newPeerEntry),
                relayPeerId = peerId
            )

            for ((existingPeerId, existingReg) in registeredPeers) {
                if (existingPeerId != request.peerId) {
                    try {
                        existingReg.controller.sendMessage(newPeerList.toJson())
                        debugLog { "[RELAY-DEBUG] Broadcast new peer ${request.peerId} to existing peer $existingPeerId" }
                    } catch (e: Exception) {
                        debugLog { "[RELAY-DEBUG] Failed to broadcast to $existingPeerId: ${e.message}" }
                    }
                }
            }
    }

    internal fun handleUnregister(
        request: RelayProtocol.RelayUnregister,
        controller: RelayMessageSender,
        awaitExternalVisibility: Boolean = true
    ): IdentityPublicationCompletion {
        val transaction = acquireRelayRegistrationTransaction(request.peerId)
        var publicationTicket: RelayIdentityPublicationTicket? = null
        var otherIdentityWithdrawals = emptyList<PreparedServiceWithdrawal>()
        var removedRegistration = false
        var acknowledgedSupersededGeneration = false
        try {
            val publication = handleUnregisterTransaction(request, controller)
            val (identityWithdrawals, foreignWithdrawals) = publication.withdrawals.partition {
                it.withdrawal.providerPeerId == request.peerId
            }
            otherIdentityWithdrawals = foreignWithdrawals
            removedRegistration = publication.removedRegistration
            acknowledgedSupersededGeneration = publication.acknowledgedSupersededGeneration
            publicationTicket = if (publication.removedRegistration) {
                enqueueRelayIdentityPublication(
                    providerPeerId = request.peerId,
                    advertisedServices = emptySet(),
                    withdrawals = identityWithdrawals,
                    publishRegistryReplacement = {},
                    publishBufferedMessages = {},
                    scheduleRegistrationCallback = {
                        CompletableFuture.completedFuture(Unit)
                    },
                    scheduleNotifications = {
                        val completion = CompletableFuture<Unit>()
                        try {
                            relayPublicationNotificationExecutor.execute {
                                try {
                                    updateLocalLinkStateAdvertisement()
                                    debugLog {
                                        "[RELAY] Removed ${publication.request.peerId} from routing neighbors"
                                    }
                                } finally {
                                    completion.complete(Unit)
                                }
                            }
                        } catch (t: Throwable) {
                            debugLogErr {
                                "[RELAY] Could not schedule unregister notifications for " +
                                    "${publication.request.peerId}: ${t.message}"
                            }
                            completion.completeExceptionally(t)
                        }
                        completion
                    }
                )
            } else {
                debugLog {
                    "[RELAY] Ignored unregister for ${publication.request.peerId} because its " +
                        "controller does not own the current registration"
                }
                // A displaced controller owns no identity snapshot. Enqueuing an empty full
                // snapshot here can supersede a replacement registration that committed moments
                // earlier but has not reached the single publication worker yet. Retain only any
                // independently prepared withdrawals (for example an expired tombstone); a true
                // no-op must not create a publication generation at all.
                identityWithdrawals.takeIf { it.isNotEmpty() }?.let {
                    enqueueRelayIdentityWithdrawals(request.peerId, it)
                }
            }
        } finally {
            releaseRelayRegistrationTransaction(request.peerId, transaction)
            publicationTicket?.let(::scheduleRelayIdentityPublicationDrain)
            scheduleRelayIdentityWithdrawals(otherIdentityWithdrawals)
        }
        val ticket = publicationTicket
        if (ticket == null) {
            return IdentityPublicationCompletion(
                CompletableFuture.completedFuture(Unit),
                requestStateTransitionCommitted = false,
                unregisterAcknowledged = acknowledgedSupersededGeneration,
            ) { false }
        }
        if (awaitExternalVisibility && relayRegisterAckAdmissionDepth.get() == 0) {
            ticket.visibilityCompletion.get()
        }
        return IdentityPublicationCompletion(
            ticket.completion,
            requestStateTransitionCommitted = removedRegistration
        ) {
            removedRegistration && synchronized(providerLifecycleLock(request.peerId)) {
                registeredPeers[request.peerId] == null
            }
        }
    }

    private fun handleUnregisterTransaction(
        request: RelayProtocol.RelayUnregister,
        controller: RelayMessageSender
    ): PreparedRelayUnregisterPublication {
        val preparedWithdrawals = mutableListOf<PreparedServiceWithdrawal>()
        var removedRegistration: RegisteredPeer? = null
        var acknowledgedSupersededGeneration = false
        synchronized(registrationLifecycleLock) {
            preparedWithdrawals += pruneExpiredDisconnectedProviderTombstonesLocked(
                clock.currentTimeMillis()
            )
            synchronized(providerLifecycleLock(request.peerId)) {
                val currentRegistration = registeredPeers[request.peerId]
                val ownsStream = currentRegistration != null &&
                    currentRegistration.controller.matchesStreamSender(controller)
                acknowledgedSupersededGeneration = ownsStream &&
                    request.registrationRequestId != null &&
                    currentRegistration!!.registrationRequestId != request.registrationRequestId
                if (currentRegistration != null && ownsStream && !acknowledgedSupersededGeneration &&
                    withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                        registeredPeers.remove(request.peerId, currentRegistration)
                    }
                ) {
                    removedRegistration = currentRegistration
                    preparedWithdrawals +=
                        consumeSupersededDisconnectedProviderTombstoneWithProviderLock(
                            request.peerId,
                            currentRegistration.serviceInventory
                        )
                    preparedWithdrawals += prepareServiceWithdrawalsForPeerWithProviderLock(
                        request.peerId,
                        currentRegistration
                    )
                    routingTable.removeNeighbor(request.peerId)
                }
            }
        }
        return PreparedRelayUnregisterPublication(
            request = request,
            withdrawals = preparedWithdrawals,
            removedRegistration = removedRegistration != null,
            acknowledgedSupersededGeneration = acknowledgedSupersededGeneration,
        )
    }

    internal fun handleRelayRequest(
        request: RelayProtocol.RelayRequest,
        sourceController: RelayMessageSender,
        inflightSink: InflightForwardSink? = null,
        failureReservation: AwaitedResponseFailureReservation? = null,
    ): RelaySynchronousForwardFailure? {
        // A request can arrive on an existing source stream while shutdown output is held.
        // Refuse it before creating a forward diagnostic or invoking any supplied log sink.
        // Requests addressed to this peer retain their established closed-transfer handling below.
        if (closed.get() && request.targetPeerId != peerId) {
            sendReplyToSourceQuietly(
                sourceController,
                RelayProtocol.RelayResponse.notDispatchedError(
                    requestId = request.requestId,
                    sourcePeerId = request.targetPeerId,
                    targetPeerId = request.sourcePeerId,
                    errorMessage = "RelayService closed",
                ),
                failureReservation,
            )
            return null
        }

        debugLog { "[RELAY-DEBUG] handleRelayRequest called, target=${request.targetPeerId}, source=${request.sourcePeerId}" }

        // CRITICAL: Check if WE are the target peer - handle locally. Local handling is
        // synchronous because there is no remote round-trip to wait for; the registered
        // request handler is invoked inline.
        if (request.targetPeerId == peerId) {
            debugLog { "[RELAY-DEBUG] Target is THIS peer, handling locally" }
            val handler = requestHandler
            // close() deliberately clears the shared handler so registration teardown does not
            // retain application code. Closed requests must still reach the established transfer
            // and close responses instead of being mistaken for an unregistered live service.
            val response = if (closed.get()) {
                handleClosedRelayRequest(request)
            } else if (handler != null) {
                try {
                    val result = handler(request).withoutNotDispatchedMarker()
                    debugLog { "[RELAY-DEBUG] Local handler returned: success=${result.success}, errorMessage=${result.errorMessage}" }
                    result
                } catch (e: Exception) {
                    debugLog { "[RELAY-DEBUG] Local handler threw exception: ${e.message}" }
                    e.printStackTrace()
                    RelayProtocol.RelayResponse.error(
                        requestId = request.requestId,
                        sourcePeerId = request.targetPeerId,
                        targetPeerId = request.sourcePeerId,
                        errorMessage = "Request handler error: ${e.message}"
                    )
                }
            } else {
                RelayProtocol.RelayResponse.notDispatchedError(
                    requestId = request.requestId,
                    sourcePeerId = request.sourcePeerId,
                    targetPeerId = request.targetPeerId,
                    errorMessage = "No request handler registered for this peer"
                )
            }
            debugLog { "[RELAY-DEBUG] Sending local response back to source ${request.sourcePeerId}" }
            sendReplyToSourceQuietly(sourceController, response, failureReservation)
            return null
        }

        if (request.hopLimit <= 0) {
            val warning = RelayRequestHopLimitExceededWarningEffect(
                requestId = request.requestId,
                sourcePeerId = request.sourcePeerId,
                targetPeerId = request.targetPeerId,
                localPeerId = peerId,
                message = "Relay request ${request.requestId} from ${request.sourcePeerId} to ${request.targetPeerId} exceeded hop limit at $peerId and was dropped."
            )
            relayWarningEffects.add(warning)
            sendReplyToSourceQuietly(
                sourceController,
                RelayProtocol.RelayResponse.notDispatchedError(
                    requestId = request.requestId,
                    sourcePeerId = request.sourcePeerId,
                    targetPeerId = request.targetPeerId,
                    errorMessage = warning.message
                ),
                failureReservation,
            )
            return null
        }

        // Target is somewhere else. The forward paths reply to [sourceController]
        // ASYNCHRONOUSLY when the response or timeout fires; this method returns to
        // the caller as soon as the request bytes are queued for the next hop. That
        // is what frees the per-stream message-processing dispatcher slot before the
        // 30/45-second forward timeout, eliminating per-stream head-of-line blocking
        // (see [forwardRequestToRegistered] docs).

        val registered = registeredPeers[request.targetPeerId]

        // Prefer link-state SPF when it has a usable route. If SPF chooses the target
        // itself as next hop, the direct registration path below sends the final hop.
        // Otherwise a lower-cost two-hop path can beat an expensive direct edge.
        debugLog { "[RELAY-DEBUG] Checking link-state table for target peer ${request.targetPeerId}" }
        val linkStateNextHop = linkStateRoutingTable.nextHopFor(request.targetPeerId)
        if (linkStateNextHop != null) {
            debugLog { "[RELAY-DEBUG] Found link-state route to ${request.targetPeerId} via next hop: $linkStateNextHop" }
            if (linkStateNextHop == request.targetPeerId && registered != null) {
                linkStateForwardingCounts.computeIfAbsent(linkStateNextHop) { AtomicInteger(0) }.incrementAndGet()
                recordRelayForwarding(linkStateNextHop)
                return forwardRequestToRegistered(
                    request,
                    registered,
                    sourceController,
                    inflightSink,
                    failureReservation,
                )
            }
            val linkStateNextHopController = findControllerForPeer(linkStateNextHop)
            if (linkStateNextHopController != null) {
                linkStateForwardingCounts.computeIfAbsent(linkStateNextHop) { AtomicInteger(0) }.incrementAndGet()
                recordRelayForwarding(linkStateNextHop)
                return forwardRequestViaRoute(
                    request,
                    linkStateNextHopController,
                    linkStateNextHop,
                    sourceController,
                    inflightSink,
                    failureReservation,
                )
            }
            debugLog { "[RELAY-DEBUG] Link-state next hop $linkStateNextHop has no controller; falling back to distance-vector routing" }
        }

        if (registered != null) {
            recordRelayForwarding(request.targetPeerId)
            return forwardRequestToRegistered(
                request,
                registered,
                sourceController,
                inflightSink,
                failureReservation,
            )
        }

        // Fall back to existing distance-vector routing for convergence windows
        // and peers that do not emit link-state advertisements yet.
        debugLog { "[RELAY-DEBUG] Checking distance-vector routing table for ${request.targetPeerId}" }
        val nextHop = routingTable.getNextHop(request.targetPeerId)
        if (nextHop != null) {
            debugLog { "[RELAY-DEBUG] Found route to ${request.targetPeerId} via next hop: $nextHop" }
            val nextHopController = findControllerForPeer(nextHop)
            if (nextHopController != null) {
                recordRelayForwarding(nextHop)
                return forwardRequestViaRoute(
                    request,
                    nextHopController,
                    nextHop,
                    sourceController,
                    inflightSink,
                    failureReservation,
                )
            }
            debugLog { "[RELAY-DEBUG] No controller available for next hop $nextHop" }
            sendReplyToSourceQuietly(
                sourceController,
                RelayProtocol.RelayResponse.notDispatchedError(
                    requestId = request.requestId,
                    sourcePeerId = request.sourcePeerId,
                    targetPeerId = request.targetPeerId,
                    errorMessage = "Route exists but next hop $nextHop is unreachable"
                ),
                failureReservation,
            )
            return null
        }

        debugLog { "[RELAY-DEBUG] No route to target peer ${request.targetPeerId}" }
        sendReplyToSourceQuietly(
            sourceController,
            RelayProtocol.RelayResponse.notDispatchedError(
                requestId = request.requestId,
                sourcePeerId = request.sourcePeerId,
                targetPeerId = request.targetPeerId,
                errorMessage = "Target peer ${request.targetPeerId} not reachable (no direct registration or route)"
            ),
            failureReservation,
        )
        return null
    }

    /**
     * Forward a relay request to a directly registered peer, replying to [sourceController]
     * **asynchronously** when the target's response arrives or the per-request timeout fires.
     *
     * This function returns as soon as the request bytes are queued for the target — it does
     * NOT block waiting for the reply. The previous synchronous implementation called
     * `future.get(30s)` on this thread, which (when invoked from the per-stream message-
     * processing dispatcher's `limitedParallelism(1)` slot) held that slot for the full
     * timeout while inbound messages on the same stream stacked up on `scope.launch`.
     * That behaviour produced the unbounded-queue OOM captured in the 2026-05-03 BuildTest
     * heap dump (see [RelayServerMessageHandler.channelRead0] backpressure docs and
     * UrlProtocol PR #252). The queue cap from PR #252 prevents the heap leak in the
     * pathological case; this asynchronous reply path additionally eliminates the per-
     * stream head-of-line blocking, so a single slow target no longer wedges every
     * subsequent request on the same stream behind it.
     *
     * Reply paths:
     *  - Send to target succeeds → schedule async reply on completion of [pendingRequests]
     *    future, with a [REGISTERED_FORWARD_TIMEOUT_MS] orTimeout guard.
     *  - Send to target fails (e.g. registration's stream is dead) → reply synchronously
     *    with an error, and evict the stale registration so future requests don't repeat
     *    the failure.
     */
    private fun forwardRequestToRegistered(
        request: RelayProtocol.RelayRequest,
        registered: RegisteredPeer,
        sourceController: RelayMessageSender,
        inflightSink: InflightForwardSink?,
        failureReservation: AwaitedResponseFailureReservation?,
    ): RelaySynchronousForwardFailure? {
        // Correlate under an id THIS relay mints rather than the source's own request id. A request
        // id identifies a request only within the process that minted it
        // (RelayProtocol.nextMessageId is a per-process counter), so two peers that started at the
        // same moment routinely present the same id. Keyed by the source's id, the second forward
        // silently replaced the first in this map, the target's first reply completed the wrong
        // waiter, and the second reply found no waiter at all — so one peer never heard back and
        // failed on its own deadline. The source's id is restored on the reply below, so the source
        // still sees the id it chose.
        val forwardRequestId = RelayProtocol.nextMessageId()
        val diagnostic = createForwardDiagnostic(request, forwardRequestId, sourceController, registered.controller)
        // Add to pending map BEFORE sending so [handleRelayResponse] can find the future
        // even if the reply races back before this method returns.
        val pending = registerPendingRelayRequest(forwardRequestId, registered.controller, request.targetPeerId)
        val future = pending.future
        future.whenComplete { response, _ -> if (response != null) diagnostic.providerResponded() }
        debugLog { "[RELAY-DEBUG] Forwarding request ${request.requestId} to registered peer ${request.targetPeerId} as $forwardRequestId" }

        try {
            // AWAITED forward: ride out a transient stall and surface a genuine drop (throw) rather
            // than best-effort dropping at 200ms and leaving the source to hang on the missing reply.
            // A throw here lands in the catch below, which sends an error reply back to the source.
            registered.controller.sendMessageAwaited(
                request.withDecrementedHopLimit().copy(requestId = forwardRequestId).toJson()
            )
        } catch (e: Exception) {
            // Only detach ownership here. The server handler still holds its message mutex.
            pendingRequests.remove(forwardRequestId, pending)
            val report = diagnostic.prepareProviderFailure(e)
            val stalePeerId = request.targetPeerId
            val removedRegistration = withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                registeredPeers.remove(stalePeerId)
            } != null
            val reply = RelayProtocol.RelayResponse.notDispatchedError(
                requestId = request.requestId,
                sourcePeerId = request.sourcePeerId,
                targetPeerId = request.targetPeerId,
                errorMessage = "Failed to forward request: ${relaySynchronousForwardFailureDetail(e)}",
            )
            return RelaySynchronousForwardFailure(
                settleReply = {
                    sendReplyToSourceQuietly(sourceController, reply, failureReservation)
                    // Retain this stream's pending-processing ownership until reply admission.
                    failureReservation?.awaitResponseAdmission()
                },
                reportFailure = {
                    try { report?.invoke() }
                    finally {
                        debugLog { "[RELAY-DEBUG] Error forwarding request: ${e.message}" }
                        if (removedRegistration) {
                            debugLog { "[RELAY-DEBUG] Removed stale registration for $stalePeerId" }
                        }
                    }
                },
            )
        }

        // Send succeeded — schedule async reply. Inform the inflight sink BEFORE
        // scheduling whenCompleteAsync so the per-stream pending count includes this
        // forward's heap-pinned state (request, sourceController, captured lambda).
        // The matching completion releases the slot after response admission settles, including
        // a response that waits for outbox space and ends through promotion or connection close.
        inflightSink?.beforeAsyncForwardScheduled()
        debugLog { "[RELAY-DEBUG] Request sent to target, scheduling async reply" }
        future.orTimeout(REGISTERED_FORWARD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            .whenCompleteAsync { targetResponse, throwable ->
                val report = throwable?.let {
                    if (closed.get()) diagnostic.prepareShutdown()
                    else diagnostic.prepareProviderFailure(unwrapCompletionException(it) ?: it)
                }
                try {
                    pendingRequests.remove(forwardRequestId, pending)
                    val reply = buildRegisteredForwardReply(request, targetResponse, throwable)
                    sendReplyToSourceQuietly(
                        sourceController,
                        reply,
                        failureReservation,
                        diagnostic,
                    )
                } finally {
                    // A queued frame owns its byte allowance. A frame still waiting for that
                    // allowance must keep this forwarding slot until promotion or close instead.
                    try {
                        val admission = failureReservation?.pendingAdmission
                        if (admission == null) {
                            inflightSink?.afterAsyncForwardCompleted()
                        } else {
                            admission.invokeOnCompletion { inflightSink?.afterAsyncForwardCompleted() }
                        }
                    } finally {
                        // Returning the error reply and releasing forwarding ownership must not
                        // depend on a supplied failure-log callback, including close-sweep races.
                        report?.invoke()
                    }
                }
            }
        return null
    }

    /**
     * Forward a relay request via distance vector routing to the next hop.
     *
     * Asynchronous reply semantics — see [forwardRequestToRegistered] for rationale.
     * The orTimeout guard here is [ROUTED_FORWARD_TIMEOUT_MS] (longer than the direct
     * forward to allow for multi-hop traversal).
     */
    private fun forwardRequestViaRoute(
        request: RelayProtocol.RelayRequest,
        nextHopController: RelayMessageSender,
        nextHopPeerId: String,
        sourceController: RelayMessageSender,
        inflightSink: InflightForwardSink?,
        failureReservation: AwaitedResponseFailureReservation?,
    ): RelaySynchronousForwardFailure? {
        // Correlated under an id this relay mints, for the reason given in
        // [forwardRequestToRegistered]: the source's own id is unique only within the source.
        val forwardRequestId = RelayProtocol.nextMessageId()
        val diagnostic = createForwardDiagnostic(request, forwardRequestId, sourceController, nextHopController)
        val pending = registerPendingRelayRequest(forwardRequestId, nextHopController, nextHopPeerId)
        val future = pending.future
        future.whenComplete { response, _ -> if (response != null) diagnostic.providerResponded() }
        debugLog { "[RELAY-DEBUG] Forwarding request ${request.requestId} via route to next hop $nextHopPeerId as $forwardRequestId" }

        try {
            // AWAITED forward (see forwardRequestToRegistered). For a directly-registered next hop
            // this rides out a transient stall with the longer delivery budget; a client-side relay
            // controller uses its bounded default admission budget. Both paths throw on non-admission,
            // and a throw lands in the catch below as an immediate error reply.
            nextHopController.sendMessageAwaited(
                request.withDecrementedHopLimit().copy(requestId = forwardRequestId).toJson()
            )
        } catch (e: Exception) {
            // Only detach ownership here. The server handler still holds its message mutex.
            pendingRequests.remove(forwardRequestId, pending)
            val report = diagnostic.prepareProviderFailure(e)
            val reply = RelayProtocol.RelayResponse.notDispatchedError(
                requestId = request.requestId,
                sourcePeerId = request.sourcePeerId,
                targetPeerId = request.targetPeerId,
                errorMessage = "Failed to forward via route: ${relaySynchronousForwardFailureDetail(e)}",
            )
            return RelaySynchronousForwardFailure(
                settleReply = {
                    sendReplyToSourceQuietly(sourceController, reply, failureReservation)
                    // Retain this stream's pending-processing ownership until reply admission.
                    failureReservation?.awaitResponseAdmission()
                },
                reportFailure = {
                    try { report?.invoke() }
                    finally {
                        debugLog { "[RELAY-DEBUG] Error forwarding via route: ${e.message}" }
                    }
                },
            )
        }

        inflightSink?.beforeAsyncForwardScheduled()
        debugLog { "[RELAY-DEBUG] Request sent to next hop, scheduling async reply" }
        future.orTimeout(ROUTED_FORWARD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            .whenCompleteAsync { targetResponse, throwable ->
                val report = throwable?.let {
                    if (closed.get()) diagnostic.prepareShutdown()
                    else diagnostic.prepareProviderFailure(unwrapCompletionException(it) ?: it)
                }
                try {
                    pendingRequests.remove(forwardRequestId, pending)
                    val reply = buildRoutedForwardReply(request, nextHopPeerId, targetResponse, throwable)
                    sendReplyToSourceQuietly(
                        sourceController,
                        reply,
                        failureReservation,
                        diagnostic,
                    )
                } finally {
                    // A queued frame owns its byte allowance. A frame still waiting for that
                    // allowance must keep this forwarding slot until promotion or close instead.
                    try {
                        val admission = failureReservation?.pendingAdmission
                        if (admission == null) {
                            inflightSink?.afterAsyncForwardCompleted()
                        } else {
                            admission.invokeOnCompletion { inflightSink?.afterAsyncForwardCompleted() }
                        }
                    } finally {
                        // Returning the error reply and releasing forwarding ownership must not
                        // depend on a supplied failure-log callback, including close-sweep races.
                        report?.invoke()
                    }
                }
            }
        return null
    }

    private fun buildRegisteredForwardReply(
        request: RelayProtocol.RelayRequest,
        targetResponse: RelayProtocol.RelayResponse?,
        throwable: Throwable?
    ): RelayProtocol.RelayResponse {
        if (throwable == null && targetResponse != null) {
            debugLog { "[RELAY-DEBUG] Got response from target: success=${targetResponse.success}, errorMessage=${targetResponse.errorMessage}" }
            // The target answered the relay-minted forward id; the source is waiting on its own.
            return targetResponse.copy(requestId = request.requestId)
        }
        val cause = unwrapCompletionException(throwable)
        if (cause is TimeoutException) {
            debugLog { "[RELAY-DEBUG] Timeout waiting for response from target ${request.targetPeerId}" }
            return RelayProtocol.RelayResponse.error(
                requestId = request.requestId,
                sourcePeerId = request.sourcePeerId,
                targetPeerId = request.targetPeerId,
                errorMessage = "Timeout waiting for response from target peer"
            )
        }
        debugLog { "[RELAY-DEBUG] Forward future completed exceptionally: ${cause?.message}" }
        return RelayProtocol.RelayResponse.error(
            requestId = request.requestId,
            sourcePeerId = request.sourcePeerId,
            targetPeerId = request.targetPeerId,
            errorMessage = "Failed to forward request: ${cause?.message}"
        )
    }

    private fun buildRoutedForwardReply(
        request: RelayProtocol.RelayRequest,
        nextHopPeerId: String,
        targetResponse: RelayProtocol.RelayResponse?,
        throwable: Throwable?
    ): RelayProtocol.RelayResponse {
        if (throwable == null && targetResponse != null) {
            debugLog { "[RELAY-DEBUG] Got response via route: success=${targetResponse.success}, errorMessage=${targetResponse.errorMessage}" }
            // The next hop answered the relay-minted forward id; the source is waiting on its own.
            return targetResponse.copy(requestId = request.requestId)
        }
        val cause = unwrapCompletionException(throwable)
        if (cause is TimeoutException) {
            debugLog { "[RELAY-DEBUG] Timeout waiting for response via route (next hop: $nextHopPeerId)" }
            // Remove stale route — same eviction as the prior synchronous implementation.
            routingTable.removeNeighbor(nextHopPeerId)
            return RelayProtocol.RelayResponse.error(
                requestId = request.requestId,
                sourcePeerId = request.sourcePeerId,
                targetPeerId = request.targetPeerId,
                errorMessage = "Timeout waiting for response via route (next hop timed out)"
            )
        }
        debugLog { "[RELAY-DEBUG] Routed forward future completed exceptionally: ${cause?.message}" }
        return RelayProtocol.RelayResponse.error(
            requestId = request.requestId,
            sourcePeerId = request.sourcePeerId,
            targetPeerId = request.targetPeerId,
            errorMessage = "Failed to forward via route: ${cause?.message}"
        )
    }

    private fun sendReplyToSourceQuietly(
        sourceController: RelayMessageSender,
        reply: RelayProtocol.RelayResponse,
        failureReservation: AwaitedResponseFailureReservation?,
        diagnostic: RelayForwardDiagnostic? = null,
    ) {
        try {
            when (
                sourceController.sendAwaitedResponseWithOutbox(
                    reply.toJson(),
                    failureReservation,
                    diagnostic?.let { record -> { cause: Throwable? -> record.responseWriteCompleted(cause) } },
                )
            ) {
                AwaitedResponseWriteOutcome.OUTBOX_FULL -> {
                    diagnostic?.responseWriteCompleted(IOException("Relay response outbox was full"))
                    debugLog {
                        "[RELAY-DEBUG] Reply ${reply.requestId} exceeded the bounded response " +
                            "outbox; queued a per-request $AWAITED_RESPONSE_OUTBOX_FULL_CODE " +
                            "reply without closing the shared logical stream"
                    }
                }
                AwaitedResponseWriteOutcome.CONNECTION_CLOSED -> {
                    diagnostic?.responseWriteCompleted(EOFException("Caller response path closed before delivery"))
                    debugLog {
                        "[RELAY-DEBUG] Could not return reply ${reply.requestId}: source " +
                            "connection was already closed"
                    }
                }
                AwaitedResponseWriteOutcome.DELIVERED,
                AwaitedResponseWriteOutcome.QUEUED -> Unit
            }
        } catch (e: Exception) {
            diagnostic?.responseWriteCompleted(e)
            failureReservation?.close()
            debugLog {
                "[RELAY-DEBUG] Failed to enqueue reply ${reply.requestId} for source " +
                    "${reply.sourcePeerId} without closing its shared logical stream: ${e.message}"
            }
            throw RelayException(
                "Failed to enqueue awaited relay reply ${reply.requestId} for source " +
                    "${reply.sourcePeerId}",
                e,
            )
        }
    }

    private fun RelayMessageSender.sendAwaitedResponseWithOutbox(
        json: JSONObject,
        failureReservation: AwaitedResponseFailureReservation?,
        completion: ((Throwable?) -> Unit)? = null,
    ): AwaitedResponseWriteOutcome = when (this) {
        is StreamRelayMessageSender -> this.sendResponseWithOutbox(json, failureReservation, completion)
        is RelayStreamController -> this.sendResponseWithOutbox(json, failureReservation, completion)
        else -> {
            failureReservation?.close()
            this.sendMessage(json)
            completion?.invoke(null)
            AwaitedResponseWriteOutcome.DELIVERED
        }
    }

    private suspend fun RelayMessageSender.reserveAwaitedResponseFailure(
        outboxFullSignal: JSONObject,
    ): AwaitedResponseFailureReservation? = when (this) {
        is StreamRelayMessageSender -> this.reserveResponseFailure(outboxFullSignal)
        is RelayStreamController -> this.reserveResponseFailure(outboxFullSignal)
        else -> null
    }

    /**
     * Sends [json] as an AWAITED reply/forward. For a stream-backed [StreamRelayMessageSender]
     * (every source stream and every directly-registered peer's controller) this rides out a
     * transient backpressure stall and THROWS on a genuine drop so the caller surfaces the failure
     * instead of hanging the requesting client for its full invocation timeout. Both concrete
     * stream senders use their bounded awaited-delivery operation; unknown implementations fall
     * back to the throwing [RelayMessageSender.sendMessage] contract.
     */
    private fun RelayMessageSender.sendMessageAwaited(json: JSONObject) {
        when (this) {
            is StreamRelayMessageSender -> this.sendMessageAwaitingDelivery(json)
            is RelayStreamController -> this.sendMessageAwaitingDelivery(json)
            else -> this.sendMessage(json)
        }
    }

    private fun unwrapCompletionException(t: Throwable?): Throwable? {
        var cause: Throwable? = t
        while (cause is CompletionException && cause.cause != null && cause.cause !== cause) {
            cause = cause.cause
        }
        return cause
    }

    /**
     * Find a controller for sending messages to a peer.
     * Checks registered peers first, then the relay we're registered with,
     * then routing table neighbors.
     */
    private fun findControllerForPeer(peerId: String): RelayMessageSender? {
        // Check registered peers (peers that registered WITH us)
        val registered = registeredPeers[peerId]
        if (registered != null) {
            return registered.controller
        }

        // Check if this is the relay we're registered with (for multi-hop routing)
        // This enables cross-relay routing: when we receive a distance vector update
        // from our relay saying "peer X is reachable via me", we can forward requests
        // to peer X through our relay connection.
        val conn = relayConnection
        if (conn != null && conn.relayPeerId == peerId) {
            return conn.controller
        }

        // Check routing table neighbors
        return routingTable.getNeighborController(peerId)
    }

    internal fun handleRelayResponse(response: RelayProtocol.RelayResponse) {
        pendingRequests[response.requestId]?.future?.complete(response)
    }

    internal fun handlePing(ping: RelayProtocol.RelayPing, controller: RelayMessageSender) {
        // Receipt of an authenticated ping is the liveness proof. Record it before attempting the
        // pong write so temporary outbound backpressure cannot turn an accepted live keepalive into
        // an unrefreshed registration. Tombstones are deliberately excluded: only the currently
        // registered controller can extend its inventory, and refresh fails if expiry cleanup has
        // already deactivated that inventory.
        val registrationEntry = registeredPeers.entries.firstOrNull { (_, registration) ->
            registration.controller === controller
        }
        val refreshedPeerId = registrationEntry?.let { (peerId, registration) ->
            synchronized(registrationLifecycleLock) {
                synchronized(providerLifecycleLock(peerId)) {
                    val currentRegistration = registeredPeers[peerId]
                    if (currentRegistration === registration &&
                        currentRegistration.controller === controller &&
                        currentRegistration.serviceInventory.refresh(
                            clock.currentTimeMillis(),
                            config.registrationTimeoutMs
                        )
                    ) peerId else null
                }
            }
        }
        if (refreshedPeerId != null) {
            gossipHandler?.onPeerKeepaliveSuccess(refreshedPeerId)
        }

        val pong = RelayProtocol.RelayPong.fromPing(ping)
        try {
            // A pong is a direct reply to an actively waiting ping. Use the bounded awaited path
            // so a Yamux child whose peer has temporarily withheld response-window credit admits
            // this compact frame under the connection-wide mux budget instead of serially waiting
            // 200 ms and discarding it. The caller's unread-response buffer supplies the matching
            // receive-window bound and eventually releases that credit as it drains.
            controller.sendMessageAwaited(pong.toJson())
        } catch (e: RelayException) {
            if (controller.isClosed()) {
                // The registration-expiry reaper can close this sender concurrently. The peer's
                // reader observes that close, so no local handler should fail the relay process.
                debugLog {
                    "[RELAY] Skipping pong to departed peer (sender closed concurrently): ${e.message}"
                }
                return
            }
            // A live sender that cannot admit an awaited pong has a real transport failure. Let
            // RelayServerMessageHandler close that one stream instead of describing it as a
            // routine departure or silently losing the response.
            throw e
        }
    }

    internal fun handleKeepalive(keepalive: RelayProtocol.RelayKeepalive) {
        val registration = registeredPeers[keepalive.peerId]
        if (registration != null) {
            registration.serviceInventory.refresh(
                clock.currentTimeMillis(),
                config.registrationTimeoutMs
            )
            // Notify gossip handler that the peer proved it is alive via keepalive.
            gossipHandler?.onPeerKeepaliveSuccess(keepalive.peerId)
        }
    }

    private fun connectToRelay(peer: BootstrapPeer, dialClock: Clock = clock): RelayConnection {
        debugLog { "[RELAY-DEBUG] connectToRelay called, peer=${peer.peerId}, addresses=${peer.multiaddresses}" }
        val remotePeerId = PeerId.fromBase58(peer.peerId)

        // FAST PATH: Check for existing TCP connection to this peer.
        // UrlProtocol and RelayService share the same host. The host maintains
        // TCP connections from bootstrap/gossip. Opening a new Mplex stream on
        // an existing connection is ~5ms (just Mplex framing, no handshake).
        try {
            // A connection whose inbound reads are held by admission control cannot report that
            // its peer has gone, so opening a fresh substream on it would inherit exactly the same
            // blindness as reusing a pooled one. Decline it here and let the dial below establish a
            // connection whose liveness is observable.
            val existingConn = host.network.connections.find {
                it.secureSession().remoteId.toBase58() == peer.peerId &&
                    !relayConnectionReadsPausedByAdmission(it)
            }
            if (existingConn != null) {
                val addr = existingConn.remoteAddress()
                debugLog { "[RELAY-DEBUG] Fast path: found existing connection to ${peer.peerId} at $addr" }
                val fastStartTime = System.currentTimeMillis()
                val streamFuture = openRelayDialStream(host, remotePeerId, addr, dialClock)
                // Cast is safe: initiator always gets a RelayStreamController from UnifiedRelayProtocol.
                // If the caller is cancelled while waiting, close the underlying stream even when
                // protocol negotiation completes later; falling through to the slow path would turn
                // one cancelled registration into a second dial.
                val controller = try {
                    streamFuture.controller.get(3, TimeUnit.SECONDS) as RelayStreamController
                } catch (e: InterruptedException) {
                    streamFuture.stream.whenComplete { stream, _ ->
                        closeRelayDialStream(dialClock, stream)
                    }
                    Thread.currentThread().interrupt()
                    throw e
                } catch (e: Exception) {
                    streamFuture.stream.whenComplete { stream, _ ->
                        closeRelayDialStream(dialClock, stream)
                    }
                    throw e
                }
                val fastElapsed = System.currentTimeMillis() - fastStartTime
                debugLog { "[RELAY-DEBUG] Fast path: opened relay stream in ${fastElapsed}ms" }
                return RelayConnection(peer.peerId, controller)
            } else {
                debugLog { "[RELAY-DEBUG] Fast path: no existing connection to ${peer.peerId}" }
            }
        } catch (e: InterruptedException) {
            throw e
        } catch (e: Exception) {
            // A future may wrap the private Clock signal. Once that operation has failed,
            // another stream acquisition cannot repair it and must not retry the host.
            ((dialClock as? RelayRequestDialClock)?.outcome?.get()
                as? RelayRequestDialOutcome.Failed)?.let { throw RelayDialClockFailure(it.failure) }
            debugLog { "[RELAY-DEBUG] Fast path failed (falling back to slow path): ${e.message}" }
        }

        val addresses = peer.multiaddresses.filter { it.isNotBlank() }
            .filter { !it.contains("/ip6/::/") && !it.contains("/ip4/0.0.0.0/") }
            .filter { !it.contains("/p2p-circuit/") }  // Circuit relay addresses can't be used for direct relay registration
        if (addresses.isEmpty()) {
            throw IllegalArgumentException("Peer ${peer.peerId} has no usable direct multiaddresses (had ${peer.multiaddresses.size} total, all circuit-relay or wildcard)")
        }

        // SLOW PATH: no existing connection. We split the dial into two phases that need
        // very different time budgets, because conflating them is what made the old code
        // flaky — but BOTH phases are fully non-blocking, so no thread is ever parked
        // waiting:
        //
        //   Phase 1 — REACHABILITY (short budget). A genuinely unreachable relay (host
        //   down, dropped on the wire) never answers the TCP SYN, so it must fail fast to
        //   let us fail over to another relay quickly — the P2P network has to stay
        //   responsive. We probe each address with a short TCP connect timeout
        //   (probeReachableAsync), which uses an AsynchronousSocketChannel: the connect
        //   result arrives as an OS event and the timeout is a scheduled completion, so
        //   no thread is blocked on the probe. libp2p's own connect timeout defaults to
        //   15s, far too long for relay failover, which is why this is done here.
        //
        //   Phase 2 — HANDSHAKE (generous budget). Once an address answers the SYN, the
        //   libp2p Noise handshake is pure CPU/round-trips. On a CPU-saturated host or a
        //   laggy path it can legitimately take several seconds — and abandoning it is
        //   exactly the bug this replaces. Earlier revisions opened the stream by BLOCKING
        //   a thread of this class's 2-thread executor (shared with keepalive, reconnect,
        //   and the periodic routing tasks) on streamFuture.controller.get(...), AND
        //   blocked the caller on a queue poll — two pool threads parked per dial. To
        //   avoid starving keepalive, the per-attempt budget was driven down (30s -> 5s ->
        //   2s, #109/#189), and 2s is too tight for a cold handshake under load, so a
        //   perfectly good connection got abandoned and registerWithRelay threw
        //   TimeoutException (the flake). Here host.newStream(...).controller is a
        //   CompletableFuture completed by libp2p's Netty event loop, so no pool thread is
        //   parked while a handshake is in flight either.
        //
        // The probe and handshake are composed per address into a single non-blocking
        // pipeline (probeReachableAsync -> thenCompose -> newStream); all addresses race
        // in parallel, so a bad address (e.g. the HCF daemon on :44605, which accepts TCP
        // but never speaks the relay protocol) never blocks a good one. The ONLY blocking
        // wait anywhere is the single resultReady.get() below, on the caller's own thread;
        // when every address is unreachable, resultReady completes exceptionally as soon
        // as the last probe times out (~reachability budget), so an unreachable relay
        // still fails fast even though the handshake budget is generous.
        val reachabilityTimeoutMs = config.reachabilityTimeoutMs.toInt()  // short: bounds unreachable-relay failover
        val connectionTimeout = 30L        // seconds — generous; covers a slow handshake

        debugLog { "[RELAY-DEBUG] Slow path: dialing ${addresses.size} addresses (reachability ${reachabilityTimeoutMs}ms, handshake budget ${connectionTimeout}s)" }
        val startTime = System.currentTimeMillis()

        // Exactly one connection survives: the first to complete wins and is returned;
        // every other attempt (a slower winner, or one that finishes after we time out)
        // is closed so no stream leaks.
        val winner = AtomicReference<RelayConnection?>(null)
        val firstError = AtomicReference<Throwable?>(null)
        val pending = AtomicInteger(addresses.size)
        val resultReady = CompletableFuture<RelayConnection>()
        // Underlying libp2p stream of the WINNING attempt — never reaped. Every other opened stream
        // is closed once the result is decided, INCLUDING one whose protocol negotiation never
        // completes (its `controller` future hangs forever). The old code chained only off
        // `newStream(...).controller`, so a stream stuck in negotiation was never closed by this
        // client and leaked an inbound mux substream on the remote relay — those accumulate there
        // until the relay OOMs (the ContainerNursery crash-loop, issue #294). The server-side
        // admission cap (InboundSubstreamAdmissionControl, #299) bounds the damage; this closes the
        // leak at its source so abandoned dials don't churn against that cap.
        val winnerStream = AtomicReference<CompletableFuture<io.libp2p.core.Stream>?>(null)

        val attemptFutures = addresses.map { multiaddr ->
            val streamHolder = AtomicReference<CompletableFuture<io.libp2p.core.Stream>?>(null)
            val streamCleanupClaimed = AtomicBoolean(false)
            fun closeAttemptStream(streamFuture: CompletableFuture<io.libp2p.core.Stream>) {
                streamFuture.whenComplete { stream, _ ->
                    if (stream != null && streamCleanupClaimed.compareAndSet(false, true)) {
                        closeRelayDialStream(dialClock, stream)
                    }
                }
            }
            val attempt: CompletableFuture<RelayConnection> =
                probeReachableAsync(multiaddr, reachabilityTimeoutMs, dialClock).thenCompose { reachable ->
                    if (!reachable) {
                        debugLog { "[RELAY-DEBUG] Address not reachable within ${reachabilityTimeoutMs}ms: $multiaddr" }
                        CompletableFuture<RelayConnection>().also {
                            it.completeExceptionally(IllegalStateException(
                                "relay address $multiaddr did not answer a TCP connect within ${reachabilityTimeoutMs}ms"))
                        }
                    } else {
                        try {
                            val addr = Multiaddr(multiaddr)
                            debugLog { "[RELAY-DEBUG] Opening stream to $remotePeerId at $addr using protocol ${RelayProtocol.PROTOCOL_ID}" }
                            val streamPromise = openRelayDialStream(host, remotePeerId, addr, dialClock)
                            // Track the underlying stream so an abandoned attempt can close it even
                            // if its controller (which resolves only AFTER protocol negotiation)
                            // never completes — `stream` resolves as soon as the stream is opened.
                            streamHolder.set(streamPromise.stream)
                            // A sibling probe can fail while this address is opening its stream,
                            // before the resultReady cleanup hook below has been installed.
                            if (resultReady.isDone && streamPromise.stream !== winnerStream.get()) {
                                closeAttemptStream(streamPromise.stream)
                            }
                            streamPromise.controller.thenApply { controller ->
                                // Cast is safe: initiator always gets a RelayStreamController from UnifiedRelayProtocol
                                RelayConnection(peer.peerId, controller as RelayStreamController)
                            }
                        } catch (e: Exception) {
                            // newStream can throw synchronously (e.g. an unparseable multiaddr).
                            CompletableFuture<RelayConnection>().also { it.completeExceptionally(e) }
                        }
                    }
                }

            attempt.whenComplete { connection, error ->
                if (connection != null) {
                    if (winner.compareAndSet(null, connection)) {
                        winnerStream.set(streamHolder.get())
                        if (!resultReady.complete(connection)) {
                            // We already gave up (timed out); don't keep this connection.
                            winner.compareAndSet(connection, null)
                            winnerStream.set(null)
                            closeRelayDialConnection(dialClock, connection)
                        }
                    } else {
                        // Another address already won — close this redundant stream.
                        closeRelayDialConnection(dialClock, connection)
                    }
                } else {
                    debugLog { "[RELAY-DEBUG] Failed to connect to relay at $multiaddr: ${error?.message}" }
                    firstError.compareAndSet(null, error)
                    val remaining = pending.decrementAndGet()
                    val clockFailure = ((dialClock as? RelayRequestDialClock)?.outcome?.get()
                        as? RelayRequestDialOutcome.Failed)?.failure
                    if (clockFailure != null) {
                        // A local Clock failure belongs to the request, regardless of other routes.
                        resultReady.completeExceptionally(RelayDialClockFailure(clockFailure))
                    } else if (remaining == 0) {
                        resultReady.completeExceptionally(
                            firstError.get()
                                ?: IllegalArgumentException("Peer ${peer.peerId}: all ${addresses.size} address(es) were unreachable or failed the relay handshake")
                        )
                    }
                }
            }

            // Once the overall result is decided (a winner, all-failed, or the outer timeout below),
            // close THIS attempt's underlying stream unless it is the winner's. This covers an attempt
            // whose controller never completes (stuck in negotiation) — `streamHolder` resolves at
            // stream-open, so the close fires even when the controller hangs — preventing a leaked
            // inbound substream on the relay.
            resultReady.whenComplete { _, _ ->
                val sf = streamHolder.get()
                if (sf != null && sf !== winnerStream.get()) {
                    closeAttemptStream(sf)
                }
            }
            attempt
        }

        fun cancelPendingConnection(cause: Throwable) {
            // Completing the shared result first prevents a handshake that wins after the caller
            // unwinds from being retained as winner. Each attempt's resultReady completion hook
            // then closes its underlying stream, including mid-negotiation streams.
            resultReady.completeExceptionally(cause)
            winner.getAndSet(null)?.let { closeRelayDialConnection(dialClock, it, cause) }
            winnerStream.set(null)
            attemptFutures.forEach { future ->
                future.cancel(true)
                future.whenComplete { connection, _ ->
                    if (connection != null) closeRelayDialConnection(dialClock, connection, cause)
                }
            }
        }

        return try {
            val connection = resultReady.get(connectionTimeout, TimeUnit.SECONDS)
            debugLog { "[RELAY-DEBUG] Slow path: successfully connected in ${System.currentTimeMillis() - startTime}ms" }
            connection
        } catch (e: TimeoutException) {
            cancelPendingConnection(e)
            throw e
        } catch (e: InterruptedException) {
            // FutureTask.cancel(true) from a race winner or close() lands here. Complete the shared
            // result and close every stream attempt before preserving the interrupt for the caller.
            cancelPendingConnection(e)
            Thread.currentThread().interrupt()
            throw e
        } catch (e: ExecutionException) {
            // Unwrap so callers see the underlying connection failure, as before.
            throw e.cause ?: e
        }
    }

    private fun startKeepalive(connection: RelayConnection) {
        if (closed.get() || relayConnection !== connection) return

        val alreadyRunning = taskLock.withLock {
            if (closed.get() || relayConnection !== connection) return
            keepaliveConnection === connection && keepaliveTask?.isDone == false
        }
        if (alreadyRunning) return

        // A missing PONG can take the bounded local admission wait plus the PONG timeout.
        // Locally declined probes check I + D silence on this existing tick, where I is
        // the interval and D = W + T. Admitted probes retain their two-failure tolerance.
        val keepaliveIntervalMs = config.keepaliveIntervalMs
        val pongTimeoutMs = keepaliveIntervalMs / 3 * 2 + keepaliveIntervalMs % 3 * 2 / 3
        val missingPongWindowMs = saturatedReadDeadline(WRITE_BACKPRESSURE_WAIT_MS, pongTimeoutMs)
        val progressWindowMs = saturatedReadDeadline(keepaliveIntervalMs, missingPongWindowMs)
        // Read the injected clock before entering RelayConnection's synchronized lifecycle
        // methods. A caller-supplied Clock may re-enter the service or close this connection.
        val pongReceived = connection.startKeepaliveProgress(clock, clock.currentTimeMillis())
        val started = try {
            taskLock.withLock {
                if (closed.get() || relayConnection !== connection) return@withLock false
                if (keepaliveConnection === connection && keepaliveTask?.isDone == false) {
                    return@withLock true
                }
                // A cancelled old tick cannot change the replacement generation's history.
                var consecutiveKeepaliveFailures = 0

                keepaliveTask = executor.scheduleAtFixedRate({
                    try {
                        if (!closed.get() && relayConnection == connection) {
                            // Use bidirectional ping/pong instead of unidirectional keepalive.
                            // This detects dead connections even when TCP send succeeds but the
                            // relay never receives the message (e.g., due to NAT timeout).
                            val pingId = java.util.UUID.randomUUID().toString()
                            val ping = RelayProtocol.RelayPing(id = pingId)
                            val pongFuture = CompletableFuture<RelayProtocol.RelayPong>()
                            pendingPings[pingId] = pongFuture

                            try {
                                if (!connection.sendKeepalivePing(ping)) {
                                    // Only locally declined probes use the silence bound. An
                                    // admitted probe must retain the two-missing-PONG rule.
                                    if (connection.keepaliveProgressHasExpired(progressWindowMs)) {
                                        debugLog {
                                            "[RELAY-DEBUG] Keepalive observed no inbound registration-stream " +
                                                "progress within the " +
                                                "liveness window; ending the registration"
                                        }
                                        clearRelayConnectionState(connection)
                                        return@scheduleAtFixedRate
                                    }
                                    debugLog {
                                        "[RELAY-DEBUG] Keepalive ping was not admitted locally; " +
                                            "retaining the registration without counting a remote failure"
                                    }
                                    return@scheduleAtFixedRate
                                }

                                // Wait for pong with timeout - use 2/3 of keepalive interval
                                // to give adequate time for response while still detecting failures
                                pongFuture.get(pongTimeoutMs, TimeUnit.MILLISECONDS)
                                // A completed PONG is direct inbound evidence as well. Record it
                                // here in case it raced with observer installation or this tick.
                                pongReceived()
                                consecutiveKeepaliveFailures = 0
                            } catch (e: java.util.concurrent.TimeoutException) {
                                // No pong received within timeout
                                consecutiveKeepaliveFailures++
                                debugLog { "[RELAY-DEBUG] Keepalive ping timeout ($consecutiveKeepaliveFailures/$maxConsecutiveKeepaliveFailures)" }

                                // Only mark connection dead after multiple consecutive failures
                                // This prevents false positives from single network hiccups
                                if (consecutiveKeepaliveFailures >= maxConsecutiveKeepaliveFailures) {
                                    debugLog { "[RELAY-DEBUG] $maxConsecutiveKeepaliveFailures consecutive keepalive failures - marking connection dead" }
                                    clearRelayConnectionState(connection)
                                }
                            } finally {
                                pendingPings.remove(pingId)
                            }
                        }
                    } catch (e: Exception) {
                        // Keepalive failed - track failure
                        consecutiveKeepaliveFailures++
                        debugLog { "[RELAY-DEBUG] Keepalive failed ($consecutiveKeepaliveFailures/$maxConsecutiveKeepaliveFailures): ${e.message}" }

                        if (consecutiveKeepaliveFailures >= maxConsecutiveKeepaliveFailures) {
                            if (relayConnection == connection) {
                                debugLog { "[RELAY-DEBUG] $maxConsecutiveKeepaliveFailures consecutive keepalive failures - marking connection dead" }
                                clearRelayConnectionState(connection)
                            }
                        }
                    }
                }, config.keepaliveIntervalMs, config.keepaliveIntervalMs, TimeUnit.MILLISECONDS)
                keepaliveConnection = connection
                true
            }
        } catch (failure: Throwable) {
            connection.stopKeepaliveProgress()
            throw failure
        }
        if (!started) connection.stopKeepaliveProgress()
    }

    /**
     * The refusal uses a separately charged lane, never a running handler's failure reservation.
     * If that lane is full, end this registration instead of parking its sole reader. The frame
     * acquires no handler slot and cannot be replayed as an ordinary handler-completed error.
     */
    private fun refuseRegisteredRequest(
        connection: RelayConnection,
        message: RelayProtocol.RelayRequest,
        reason: String,
    ) {
        val refusal = RelayProtocol.RelayResponse.notDispatchedError(
            requestId = message.requestId,
            sourcePeerId = message.targetPeerId,
            targetPeerId = message.sourcePeerId,
            errorMessage = reason,
        ).toJson()
        if (!connection.controller.trySendRegisteredRequestRefusal(refusal)) {
            throw RelayException(
                "Relay registration cannot admit a not-dispatched refusal: its separate " +
                    "128-KiB connection or 256-KiB process refusal budget is full, or the " +
                    "frame exceeds 64 KiB. Closing this registration without waiting.",
            )
        }
    }

    /**
     * Hands [message] and its admitted [slot] to a handler task on its own virtual thread.
     *
     * Returns true when the task now owns [failureReservation] and [slot]; false when the executor
     * no longer accepts work, in which case the caller still owns both.
     */
    private fun dispatchRegisteredRequest(
        connection: RelayConnection,
        message: RelayProtocol.RelayRequest,
        failureReservation: AwaitedResponseFailureReservation,
        slot: RelayedRequestHandlerSlot,
    ): Boolean {
        val permit = checkNotNull(failureReservation.requestPermit)
        try {
            relayedRequestHandlerExecutor.execute {
                // Each task runs on its own single-use virtual thread, so interrupting a thread
                // found in this map can only ever reach the handler it was registered for.
                val handlerThread = Thread.currentThread()
                relayedRequestHandlerThreads[handlerThread] = connection
                try {
                    if (connection.isClosed()) {
                        // The close sweep may have run before this handler registered itself.
                        handlerThread.interrupt()
                    }
                    // The outbox keeps the slot while an uncharged completed reply waits for
                    // capacity, then returns it under its monitor before any writer can send it.
                    // The registration reader never participates in that wait.
                    if (!connection.orderedUnregisterInProgress.get()) runRegisteredRequestHandler(
                        connection,
                        message,
                        failureReservation,
                    )
                } finally {
                    relayedRequestHandlerThreads.remove(handlerThread)
                    connection.forgetRegisteredRequest(failureReservation)
                    if (!failureReservation.closeOwnsRegisteredResponse) permit.releaseByHandler()
                }
            }
        } catch (rejected: RejectedExecutionException) {
            return false
        }
        return true
    }

    /**
     * Interrupts every admitted handler that [connection] delivered. Their replies can no longer
     * be carried. Workers return handler-owned slots on exit; outbox cleanup returns slots owned
     * by retained replies.
     */
    private fun cancelRelayedRequestHandlers(connection: RelayConnection) {
        relayedRequestHandlerThreads.forEach { (handlerThread, owner) ->
            if (owner === connection) handlerThread.interrupt()
        }
    }

    /**
     * Runs the registered request handler for one relayed request and returns its reply.
     *
     * Called from [relayedRequestHandlerExecutor], never from the connection's reader thread.
     * Replies are matched by request id on the requesting side, so a reply produced here may
     * overtake one for an earlier request without confusing any caller.
     */
    private fun runRegisteredRequestHandler(
        connection: RelayConnection,
        message: RelayProtocol.RelayRequest,
        failureReservation: AwaitedResponseFailureReservation,
    ) {
        try {
            val handler = requestHandler
            val response = try {
                if (handler != null) {
                    val result = handler(message).withoutNotDispatchedMarker()
                    debugLog {
                        "[RELAY-CLIENT] Handler returned: " +
                            "success=${result.success}, " +
                            "errorMessage=${result.errorMessage}"
                    }
                    result
                } else {
                    debugLog {
                        "[RELAY-CLIENT] No request handler registered!"
                    }
                    RelayProtocol.RelayResponse.error(
                        requestId = message.requestId,
                        sourcePeerId = message.targetPeerId,
                        targetPeerId = message.sourcePeerId,
                        errorMessage = "No request handler registered"
                    )
                }
            } catch (e: Exception) {
                debugLog {
                    "[RELAY-CLIENT] Handler threw exception: ${e.message}"
                }
                e.printStackTrace()
                RelayProtocol.RelayResponse.error(
                    requestId = message.requestId,
                    sourcePeerId = message.targetPeerId,
                    targetPeerId = message.sourcePeerId,
                    errorMessage = "Handler error: ${e.message}"
                )
            }
            if (failureReservation.closeOwnsRegisteredResponse) return
            val responseJson = response.toJson()
            val outcome = connection.sendResponseWithOutbox(
                responseJson,
                failureReservation,
            )
            // A response owns its slot while it waits uncharged. Admission returns the slot
            // before writing; close returns it if admission never happens.
            if (!failureReservation.closeOwnsRegisteredResponse && failureReservation.pendingAdmission != null) {
                kotlinx.coroutines.runBlocking { failureReservation.awaitResponseAdmission() }
            }
            when (outcome) {
                AwaitedResponseWriteOutcome.OUTBOX_FULL -> debugLog {
                    "[RELAY-CLIENT] Registered-target response " +
                        "${message.requestId} exceeded its bounded outbox; " +
                        "queued request-scoped " +
                        AWAITED_RESPONSE_OUTBOX_FULL_CODE
                }
                AwaitedResponseWriteOutcome.CONNECTION_CLOSED -> debugLog {
                    "[RELAY-CLIENT] Registered-target response " +
                        "${message.requestId} could not be returned because " +
                        "the registration connection closed"
                }
                AwaitedResponseWriteOutcome.DELIVERED,
                AwaitedResponseWriteOutcome.QUEUED -> Unit
            }
        } finally {
            failureReservation.close()
        }
    }

    private fun enqueueRelayReceiveCallback(
        connection: RelayConnection,
        messageType: String,
        retainedBytes: Long,
        serviceStateKey: RelayReceiveServiceStateKey? = null,
        serviceStateRecency: RelayReceiveServiceStateRecency? = null,
        losslessServiceState: Boolean = false,
        beforeApplication: ((GossipHandler, RelayConnection) -> Boolean)? = null,
        recordServiceState: (() -> Unit)? = null,
        callback: (GossipHandler, RelayConnection) -> Boolean,
    ) {
        val currentGossipHandler = gossipHandler ?: return
        val result = relayReceiveCallbacks.offer(
            peerId = connection.relayPeerId,
            generation = connection,
            retainedBytes = retainedBytes,
            serviceStateKey = serviceStateKey,
            serviceStateRecency = serviceStateRecency,
            losslessServiceState = losslessServiceState,
            applyServiceState = serviceStateKey?.let { key ->
                { application, publishWatermark ->
                    applyRelayServiceStateInCatalogOrder(
                        key,
                        checkNotNull(recordServiceState),
                        application,
                        publishWatermark,
                    )
                }
            },
            beforeApplication = beforeApplication?.let { before ->
                { activeGeneration ->
                    val activeConnection = activeGeneration as RelayConnection
                    if (relayReceiveCallbacks.isCurrent(
                            activeConnection.relayPeerId,
                            activeConnection,
                        )
                    ) {
                        before(currentGossipHandler, activeConnection)
                        true
                    } else {
                        false
                    }
                }
            },
            callback = { activeGeneration ->
                val activeConnection = activeGeneration as RelayConnection
                if (relayReceiveCallbacks.isCurrent(
                        activeConnection.relayPeerId,
                        activeConnection,
                    )
                ) {
                    callback(currentGossipHandler, activeConnection)
                } else {
                    false
                }
            },
            onFailure = { activeGeneration, failure, staleGeneration ->
                val activeConnection = activeGeneration as RelayConnection
                val callbackPeerId = activeConnection.relayPeerId
                // Publish before registration loss, without running supplied Throwable getters.
                // A snapshot reader can render independently while this reporter is held there.
                val failureClass = failure::class.java.name
                val callbackDescription = if (staleGeneration) {
                    "Stale-generation relay receive callback"
                } else {
                    "Relay receive callback"
                }
                val outcome = if (staleGeneration) {
                    "No current relay connection was closed."
                } else {
                    "The affected relay connection was closed."
                }
                val warning = RelayReceiveCallbackFailureDiagnostic(
                    RelayReceiveCallbackFailureWarningEffect(
                        relayPeerId = callbackPeerId,
                        messageType = messageType,
                        failureClass = failureClass,
                        failureMessage = null,
                        message = "$callbackDescription " +
                            "for '$messageType' from peer '$callbackPeerId' failed with " +
                            "$failureClass. Its error description is being rendered on this thread.",
                        staleGeneration = staleGeneration,
                    ),
                ) {
                    val failureMessage = try {
                        failure.message
                    } catch (renderFailure: Throwable) {
                        addRelayReceiveCallbackRenderingFailure(failure, renderFailure)
                        val renderFailureMessage = try {
                            renderFailure.message ?: "no message"
                        } catch (nestedRenderFailure: Throwable) {
                            addRelayReceiveCallbackRenderingFailure(failure, nestedRenderFailure)
                            "message could not be rendered (${nestedRenderFailure::class.java.name})"
                        }
                        return@RelayReceiveCallbackFailureDiagnostic RelayReceiveCallbackFailureWarningEffect(
                            relayPeerId = callbackPeerId,
                            messageType = messageType,
                            failureClass = failureClass,
                            failureMessage = null,
                            message = "$callbackDescription for '$messageType' from peer " +
                                "'$callbackPeerId' failed with $failureClass. " +
                                "Its error description could not be rendered: " +
                                "${renderFailure::class.java.name}: $renderFailureMessage. $outcome",
                            staleGeneration = staleGeneration,
                        )
                    }
                    RelayReceiveCallbackFailureWarningEffect(
                        relayPeerId = callbackPeerId,
                        messageType = messageType,
                        failureClass = failureClass,
                        failureMessage = failureMessage,
                        message =
                            "$callbackDescription for '$messageType' from peer " +
                                "'${callbackPeerId}' failed with " +
                                "$failureClass: ${failureMessage ?: "no message"}. " +
                                outcome,
                        staleGeneration = staleGeneration,
                    )
                }
                latestRelayReceiveCallbackFailure.set(warning)
                var cleanupFailure: Throwable? = null
                val registrationClose = raceLifecycleLock.withLock {
                    if (!staleGeneration && relayConnection === activeConnection) {
                        CapturedRelayRegistrationClose(
                            activeConnection.closeState,
                            claimRelayRegistrationCloseFailure(activeConnection.closeState),
                        )
                    } else null
                }
                if (registrationClose != null) {
                    try {
                        clearRelayConnectionState(activeConnection)
                    } catch (clearFailure: Throwable) {
                        cleanupFailure = appendRelayCleanupFailure(cleanupFailure, clearFailure)
                    }
                    try {
                        // This callback will print the outcome. Reserve it before retirement's
                        // supplied close callbacks, then consume it before the public report.
                        closeRelayRegistration(
                            registrationClose.state, 0L, false, registrationClose.claim,
                        )
                    } catch (closeFailure: Throwable) {
                        cleanupFailure = appendRelayCleanupFailure(cleanupFailure, closeFailure)
                    } finally {
                        releaseCapturedRelayRegistrationClose(registrationClose)
                    }
                }
                cleanupFailure?.let { appendRelayCleanupFailure(failure, it) }
                val renderedWarning = warning.snapshot()
                debugLog { "[RELAY-CLIENT] ${renderedWarning.message}" }
                // Print after teardown so a surfaced close failure is retained in the same
                // diagnostic chain as the callback failure instead of being logged and lost.
                printRelayReceiveCallbackFailure(failure, renderedWarning)
            },
        )
        if (result is RelayReceiveCallbackOfferResult.Dropped) {
            val reason = when (result.reason) {
                RelayReceiveCallbackDropReason.CALLBACK_COUNT ->
                    "the peer queue already held ${result.queuedCallbacks} callbacks " +
                        "(ordinary callback limit $relayReceiveCallbacksPerPeer)"
                RelayReceiveCallbackDropReason.RETAINED_BYTES ->
                    "the peer queue already retained approximately ${result.retainedBytes} bytes " +
                        "(limit ${result.retainedByteLimitPerPeer})"
            }
            val warning = RelayReceiveCallbackQueueOverflowWarningEffect(
                relayPeerId = connection.relayPeerId,
                messageType = messageType,
                queuedCallbacks = result.queuedCallbacks,
                maxQueuedCallbacksPerPeer = relayReceiveCallbacksPerPeer,
                retainedBytes = result.retainedBytes,
                maxRetainedBytesPerPeer = result.retainedByteLimitPerPeer,
                activePeerLanes = result.activePeerLanes,
                maxPeerLanes = RELAY_RECEIVE_CALLBACK_PEERS,
                message =
                    "Relay receive callback work for '$messageType' from peer " +
                        "'${connection.relayPeerId}' was dropped because $reason. The newest " +
                        "callback is dropped so the relay connection reader can continue.",
            )
            latestRelayReceiveCallbackOverflow.set(warning)
            relayReceiveCallbackOverflowSeamForTesting?.invoke(warning)
            debugLog { "[RELAY-CLIENT] ${warning.message}" }
        }
        relayReceiveCallbackOfferCompletedTestSeam?.invoke(messageType)
    }

    private fun enqueueRelayMessageCallbacks(
        connection: RelayConnection,
        messageType: String,
        message: Any,
        retainedBytes: Long,
    ) {
        val serviceStateKey = when (message) {
            is GossipProtocol.ServiceAnnouncement -> RelayReceiveServiceStateKey(
                providerPeerId = message.providerPeerId,
                serviceIdentifier = message.serviceIdentifier,
            )
            is GossipProtocol.ServiceWithdrawal -> RelayReceiveServiceStateKey(
                providerPeerId = message.providerPeerId,
                serviceIdentifier = message.serviceIdentifier,
            )
            else -> null
        }
        val serviceStateRecency = when (message) {
            is GossipProtocol.ServiceAnnouncement -> RelayReceiveServiceStateRecency(
                providerTimestamp = message.timestamp,
                isWithdrawal = false,
            )
            is GossipProtocol.ServiceWithdrawal -> RelayReceiveServiceStateRecency(
                providerTimestamp = message.timestamp,
                isWithdrawal = true,
            )
            else -> null
        }
        enqueueRelayReceiveCallback(
            connection = connection,
            messageType = messageType,
            retainedBytes = retainedBytes,
            serviceStateKey = serviceStateKey,
            serviceStateRecency = serviceStateRecency,
            losslessServiceState = message is GossipProtocol.ServiceWithdrawal,
            beforeApplication = { handler, activeConnection ->
                handler.recordAuthenticatedInteractionCompatible(
                    activeConnection.relayPeerId,
                    handler.classifyAuthenticatedInteractionCompatible(message),
                )
                true
            },
            recordServiceState = { recordAppliedRelayReceiveServiceState(message) },
        ) { handler, activeConnection ->
            when (message) {
                is RelayProtocol.RelayPeerList -> {
                    val peerInfos = message.peers.map { entry ->
                        PeerInfo(
                            peerId = entry.peerId,
                            multiaddresses = entry.multiaddresses,
                            advertisedServices = entry.advertisedServices,
                            serviceLifecycleTimestamps = entry.serviceLifecycleTimestamps,
                        )
                    }
                    handler.receivePeersCompatible(peerInfos, activeConnection.relayPeerId)
                }
                is GossipProtocol.ServiceAnnouncement -> handler.onServiceAnnouncement(message)
                is GossipProtocol.ServiceWithdrawal -> handler.onServiceWithdrawal(message)
                is GossipProtocol.PeerAnnouncement -> handler.onPeerAnnouncement(message)
                is GossipProtocol.TldResolverAnnouncement ->
                    handler.onTldResolverAnnouncement(message)
                is GossipProtocol.PeerExchange -> {
                    if (!message.isRequest) {
                        handler.receivePeersCompatible(message.peers, activeConnection.relayPeerId)
                    }
                }
                is RelayProtocol.RelayAnnouncement -> handler.onRelayAnnouncement(message)
            }
            true
        }
    }

    private fun startRequestListener(connection: RelayConnection): Boolean {
        val listenerId = peerId.takeLast(8)
        val stopSignal = AtomicBoolean(false)
        if (!relayReceiveCallbacks.openConnection(connection.relayPeerId, connection)) {
            clearRelayConnectionState(connection)
            try { connection.close() } catch (_: Throwable) {}
            return false
        }
        // The stream controller reports remote channelInactive and local close directly. This
        // notification is independent of the listener thread, which may be parked elsewhere (for
        // example reserving response-failure capacity) and so cannot reach its read/close cleanup
        // yet. It also interrupts this connection's handlers. Handler-owned slots return on exit;
        // the outbox's close cleanup returns slots owned by retained replies.
        connection.onClosed {
            failPendingRelayRequestsForClosedSender(connection.controller)
            cancelRelayedRequestHandlers(connection)
            val observe = {
                runRelayCloseObserver(connection)
            }
            if (connection.isOnTransportEventLoop()) {
                // A pending refresh future may have caller-owned completion callbacks. Running
                // those inline from channelInactive would let one callback park the Netty event
                // loop and prevent further transport progress. Keep local close() synchronous so
                // its caller still receives observer failures directly; remote close notifications
                // run on workers that service close interrupts but never joins.
                try {
                    relayCloseObserverExecutor.execute {
                        try {
                            observe()
                        } catch (failure: Throwable) {
                            debugLogErr {
                                "[RELAY-CLIENT] Relay close observer failed asynchronously for " +
                                    "${connection.relayPeerId}: ${failure.message}"
                            }
                        }
                    }
                } catch (_: RejectedExecutionException) {
                    // The service is already shutting down. Finish the close transition inline so
                    // pending acknowledgements are still settled if the executor rejected it.
                    observe()
                }
            } else {
                observe()
            }
        }
        val callbackAdmission = RelayReceiveCallbackAdmissionDispatcher(
            executor = relayReceiveCallbackExecutor,
            // Keep one parsed frame ready while the admission worker waits in the bounded
            // receive ledger. Control frames are completed before this handoff, so this single
            // slot is enough to prevent application-facing work from stopping ACK correlation.
            maxPendingMessages = 1,
        ) { failure ->
            if (!Thread.currentThread().isInterrupted && clearRelayConnectionState(connection)) {
                debugLog {
                    "[RELAY-DEBUG] Relay receive admission failed: ${failure.message}"
                }
                try { connection.close() } catch (_: Throwable) {}
            }
        }
        // Assign listenerThread and listenerStopSignal under taskLock BEFORE the thread starts
        // running. This prevents task detachment from reading stale ownership and missing it.
        val installed = taskLock.withLock {
            if (closed.get() || relayConnection !== connection) return@withLock false
            listenerStopSignal = stopSignal
            listenerConnection = connection
            val readerDiagnostic = RelayRegistrationReaderDiagnostic(
                relayProgressStreamIdentity(connection.controller.diagnosticStream),
            )
            connection.readerDiagnostic = readerDiagnostic
            registrationReaderDiagnostics = (registrationReaderDiagnostics + readerDiagnostic).takeLast(4)
            val newThread = thread(name = "RelayService-listener-$listenerId") {
                readerDiagnostic.state = "active"
                var listenerFailure: Throwable? = null
                var fatalFailure: Throwable? = null
                var requiresFatalWorkerReport = false
                var reportsPublicFailure = false
                try {
                    debugLog { "[RELAY-LISTENER-$listenerId] Listener thread started!" }
                    while (!closed.get() && !stopSignal.get() && (relayConnection == connection || connection.orderedUnregisterInProgress.get()) && !Thread.currentThread().isInterrupted) {
                        val json = try {
                            connection.readMessage(60, 60, TimeUnit.SECONDS, listenerReadClock)
                        } catch (budgetDeadline: RelayParseBudgetDeadlineException) {
                            // This listener's 60 seconds is an idle poll window, not a request
                            // budget: an inbound frame that could not be admitted to the
                            // parse-memory pool within it is the same situation as a poll that saw
                            // no message. Keep listening instead of dropping a healthy relay link
                            // (and with it this peer's registration) over inbound contention.
                            reportRelayParseBudgetDeadline(
                                connection.relayPeerId, budgetDeadline, effectHandlerRepositoryAtStart
                            )
                            continue
                        }
                        if (json == null) {
                            // readMessage returns null for BOTH a genuine 60s read-timeout
                            // (no message arrived but the stream is still open — keep
                            // listening) AND a remote-closed stream (channelInactive set the
                            // controller's closed flag, so readBytes returns immediately).
                            // Treating the closed case as a timeout and `continue`-ing
                            // hot-spins this thread at ~100% CPU until the service is
                            // explicitly closed, and never marks the connection lost — so the
                            // never-give-up reconnection task (which only fires when
                            // relayConnection == null) never re-establishes the relay link.
                            // Distinguish the two: on a closed stream, drop the connection
                            // (mirroring the catch block below so reconnection re-registers)
                            // and exit the loop; only retry on a true timeout.
                            if (connection.isClosed()) {
                                // Do NOT sweep the pending refresh acknowledgements here. The
                                // sweep completes them exceptionally, and because orTimeout
                                // returns the same future the whenComplete below runs INLINE on
                                // this thread, reaching abandonUnacknowledgedRelayConnection and
                                // nulling relayConnection before the next line executes.
                                // clearRelayConnectionState(connection) would then observe
                                // relayConnection !== connection, return false, and leave
                                // committedRelayCandidate set - which the reconnect task's
                                // admission check reads as "a candidate is already committed" and
                                // refuses forever, so the peer never re-registers with any relay.
                                // The finally block sweeps microseconds later on every exit path,
                                // by which point relayConnection is already cleared and the inline
                                // abandon correctly no-ops.
                                clearRelayConnectionState(connection)
                                break
                            }
                            continue
                        }
                        val messageType = json.optString("type", "unknown")
                        debugLog { "[RELAY-LISTENER-$listenerId] Received message of type: $messageType" }

                        // Check for stop signal or interruption after blocking read
                        if (stopSignal.get() || Thread.currentThread().isInterrupted) break

                        // Try to parse the message, handling unknown message types gracefully
                        val message = try {
                            parseRelayOrGossipMessage(json)
                        } catch (failure: RuntimeException) {
                            if (failure !is JSONException && failure !is IllegalArgumentException) throw failure
                            val type = json.optString("type", "unknown")
                            callbackAdmission.submit {
                                enqueueRelayReceiveCallback(
                                    connection = connection,
                                    messageType = type,
                                    retainedBytes = estimateJsonRetentionBytes(json),
                                ) { handler, activeConnection ->
                                    handler.recordAuthenticatedInteractionCompatible(
                                        activeConnection.relayPeerId,
                                        PeerInteractionSeverity.SEVERE,
                                    )
                                    true
                                }
                            }
                            debugLog { "[RELAY-CLIENT] Refused malformed relay/gossip frame: ${failure.message?.take(200)}" }
                            continue
                        }

                        // Complete control acknowledgements before handing application-facing
                        // receive work to the bounded serial dispatcher. Otherwise a service-state
                        // capacity wait on an earlier frame can consume the entire acknowledgement
                        // budget without the reader ever matching this frame.
                        when (message) {
                            is RelayProtocol.RelayRegisterAck -> {
                                pendingRegistrationRefreshAcks.remove(message.requestId)
                                    ?.acknowledgement
                                    ?.complete(message)
                            }
                            is RelayProtocol.RelayUnregisterAck -> {
                                pendingUnregisterAcks.remove(message.requestId)?.complete(message)
                            }
                            else -> Unit
                        }
                        if (!callbackAdmission.submit {
                            enqueueRelayMessageCallbacks(
                                connection,
                                messageType,
                                message,
                                estimateJsonRetentionBytes(json),
                            )
                        }) break

                        when (message) {
                            is RelayProtocol.RelayRegisterAck,
                            is RelayProtocol.RelayUnregisterAck -> Unit
                            is RelayProtocol.RelayRequest -> {
                                // Handle incoming relayed request
                                debugLog { "[RELAY-CLIENT] Received relay_request: requestId=${message.requestId}, sourcePeerId=${message.sourcePeerId}" }
                                // Never wait for a handler to finish: waiting here would stop
                                // every later frame on this connection (requests,
                                // acknowledgements, pings) from being read for as long as the
                                // slowest admitted handler runs. A request over the handler
                                // bound is refused at once instead.
                                val runningWhenFull =
                                    tryAdmitRelayedRequestHandler(runningRelayedRequestHandlers)
                                if (runningWhenFull != null) {
                                    refuseRegisteredRequest(
                                        connection,
                                        message,
                                        relayedRequestHandlerCapacityMessage(runningWhenFull),
                                    )
                                    continue
                                }
                                // This listener owns the admitted slot until a handler task takes
                                // it over; every other exit below returns it.
                                val slot = RelayedRequestHandlerSlot(runningRelayedRequestHandlers)
                                var dispatched = false
                                try {
                                    val outboxFullResponse = RelayProtocol.RelayResponse.error(
                                        requestId = message.requestId,
                                        sourcePeerId = message.targetPeerId,
                                        targetPeerId = message.sourcePeerId,
                                        errorMessage =
                                            "$AWAITED_RESPONSE_OUTBOX_FULL_CODE: " +
                                                AWAITED_RESPONSE_OUTBOX_FULL_MESSAGE,
                                    )
                                    val failureReservation = connection.controller.tryReserveResponseFailure(
                                        outboxFullResponse.toJson(),
                                    )
                                    if (failureReservation == null) {
                                        refuseRegisteredRequest(
                                            connection,
                                            message,
                                            "A relayed request was refused without running it: this peer " +
                                                "has no response-failure reservation capacity available. " +
                                                "Retry after an earlier response releases capacity.",
                                        )
                                        continue
                                    }
                                    failureReservation.requestPermit = RpcRequestPermit(
                                        releaseOnAdmission = true, release = slot::release,
                                    )
                                    try {
                                        if (!connection.acceptRegisteredRequest(message, failureReservation)) continue
                                        relayRequestDispatchTestSeam?.invoke()
                                        dispatched = dispatchRegisteredRequest(
                                            connection,
                                            message,
                                            failureReservation,
                                            slot,
                                        )
                                    } finally {
                                        if (!dispatched) {
                                            // Interruption before dispatch or executor rejection:
                                            // no handler owns the reservation.
                                            connection.forgetRegisteredRequest(failureReservation)
                                            failureReservation.close()
                                        }
                                    }
                                } finally {
                                    if (!dispatched) slot.release()
                                }
                            }
                            is RelayProtocol.RelayPing -> {
                                val pong = RelayProtocol.RelayPong.fromPing(message)
                                connection.sendMessage(pong.toJson())
                            }
                            is RelayProtocol.RelayPong -> {
                                // Pong received - complete the pending ping future to confirm connection is alive
                                val future = pendingPings.remove(message.id)
                                if (future != null) {
                                    linkStateLinkCosts[connection.relayPeerId] = message.calculateLatencyMs().coerceAtLeast(1L)
                                    updateLocalLinkStateAdvertisement(force = true)
                                    future.complete(message)
                                }
                            }
                            is RelayProtocol.RelayPeerList -> {
                                debugLog { "[RELAY-CLIENT] Received peer list with ${message.peers.size} peers from relay ${message.relayPeerId}" }
                            }
                            // Handle gossip messages that may be forwarded over relay connection
                            is GossipProtocol.ServiceAnnouncement -> {
                                debugLog { "[RELAY-CLIENT] Received service announcement via relay: '${message.serviceIdentifier}'" }
                            }
                            is GossipProtocol.ServiceWithdrawal -> {
                                debugLog { "[RELAY-CLIENT-${peerId.takeLast(8)}] Received service withdrawal via relay: '${message.serviceIdentifier}'" }
                            }
                            is GossipProtocol.PeerAnnouncement -> {
                                debugLog { "[RELAY-CLIENT] Received peer announcement via relay: ${message.peerId}" }
                            }
                            is GossipProtocol.TldResolverAnnouncement -> {
                                debugLog { "[RELAY-CLIENT] Received TLD resolver announcement via relay: ${message.descriptor.tld}" }
                            }
                            is GossipProtocol.PeerExchange -> {
                                if (!message.isRequest) {
                                    debugLog { "[RELAY-CLIENT] Received ${message.peers.size} peers via relay peer exchange" }
                                }
                            }
                            is RelayProtocol.RelayAnnouncement -> {
                                debugLog { "[RELAY-CLIENT] Received relay announcement via relay: ${message.peerId}" }
                            }
                            is RelayProtocol.DistanceVector -> {
                                // Process distance vector update for routing table
                                debugLog { "[RELAY-CLIENT] Received distance_vector from ${message.sourcePeerId} with ${message.entries.size} entries" }
                                routingTable.processDistanceVector(message)
                            }
                            is LinkStateAdvertisement -> {
                                val senderPeerId = connection.relayPeerId
                                debugLog { "[RELAY-CLIENT] Received LSA from ${message.originPeerId} via relay $senderPeerId with ${message.links.size} links" }
                                processLinkStateAdvertisement(message, senderPeerId)
                            }
                            is RelayProtocol.RelayResponse -> {
                                // Response to a request we forwarded via the relay connection (cross-relay routing)
                                debugLog { "[RELAY-CLIENT] Received relay_response: requestId=${message.requestId}, success=${message.success}" }
                                handleRelayResponse(message)
                            }
                            else -> { /* Ignore other messages */ }
                        }
                    }
                } catch (e: InterruptedException) {
                    // Thread was interrupted - normal shutdown, don't log as error
                    Thread.currentThread().interrupt()
                } catch (failure: Throwable) {
                    listenerFailure = failure
                    if (failure is Error) {
                        fatalFailure = failure
                        requiresFatalWorkerReport = true
                    }
                    raceLifecycleLock.withLock {
                        connection.failedListenerOwnsSettlement = true
                    }
                } finally {
                    // The read loop has ended, even if retirement cleanup is still running.
                    readerDiagnostic.state = "ended"
                    val cleanup = { action: () -> Unit ->
                        try {
                            action()
                        } catch (failure: Throwable) {
                            listenerFailure = appendRelayCleanupFailure(listenerFailure, failure)
                            if (fatalFailure == null && failure is Error) {
                                fatalFailure = failure
                                requiresFatalWorkerReport = true
                            }
                        }
                    }
                    // Every exit retires this captured transport, including a stop signal or
                    // replacement. Clear only this generation before close callbacks can re-enter.
                    // Record the transport outcome first. Its reporter is selected below,
                    // before a listener failure or any refresh completion exposes it.
                    cleanup { clearRelayConnectionState(connection); Unit }
                    cleanup { connection.retire(); Unit }
                    taskLock.withLock {
                        if (listenerConnection === connection &&
                            listenerThread === Thread.currentThread()
                        ) {
                            listenerConnection = null
                            listenerThread = null
                            listenerStopSignal = null
                        }
                    }
                    cleanup { callbackAdmission.close() }
                    cleanup { relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection) }
                    cleanup {
                        failRegistrationRefreshAcksForClosedConnection(connection, listenerFailure) { reportsRefreshFailure ->
                            reportsPublicFailure = reportsRefreshFailure
                            val state = connection.closeState
                            val record = state.closeFailures
                            val failure = synchronized(record) { record.failure }
                            val closeWasFatal = state.operation.get()?.outcome?.getNow(null)?.failure is Error
                            val reportsListenerFailure = fatalFailure != null || failure is Error ||
                                closeWasFatal || reportsRefreshFailure
                            val claim = if (failure != null && reportsListenerFailure) {
                                claimRelayRegistrationCloseFailure(state)
                            } else null
                            val reported = takeRelayRegistrationCloseFailure(state, claim)
                            if (reported != null) {
                                listenerFailure = appendRelayCleanupFailure(listenerFailure, reported)
                                if (fatalFailure == null && (reported is Error || closeWasFatal)) {
                                    fatalFailure = reported
                                }
                            }
                            listenerFailure
                        }
                    }
                    raceLifecycleLock.withLock {
                        connection.failedListenerOwnsSettlement = false
                    }
                }
                // An original fatal read/cleanup error still leaves its worker. A close Error
                // added only during retirement already has a reporter in reserved public results.
                if (requiresFatalWorkerReport || !reportsPublicFailure) fatalFailure?.let { throw it }
                listenerFailure?.let { failure ->
                    debugLog { "[RELAY-DEBUG] Request listener died: ${failure.message}" }
                }
            }
            listenerThread = newThread
            true
        }
        if (!installed) {
            callbackAdmission.close()
            relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
        }
        return installed
    }

    /**
     * Starts a background task to monitor the relay connection and reconnect if needed.
     * Uses exponential backoff that NEVER gives up permanently - this is critical for
     * NAT nodes that must stay connected to the relay to be reachable.
     *
     * Backoff strategy:
     * - Starts at 5 seconds between attempts
     * - Doubles after each failure (5s, 10s, 20s, 40s, 80s, 160s, 320s, 600s)
     * - Caps at 10 minutes maximum delay
     * - Resets to 5 seconds on successful reconnection
     */
    private fun replaceReconnectionTask(shouldReplace: () -> Boolean) {
        val replacement = taskLock.withLock {
            if (!shouldReplace()) return
            reconnectionTask to prepareNextReconnectAttempt()
        }
        var failure: Throwable? = null
        try { replacement.first?.cancel(false) }
        catch (later: Throwable) { failure = later }
        try { replacement.second() }
        catch (later: Throwable) { failure = appendRelayCleanupFailure(failure, later) }
        failure?.let { throw it }
    }

    /**
     * Publishes the next task while taskLock is held. The returned action attaches its
     * supplied clock schedule after release; cancellation can safely win before attachment.
     *
     * After [maxSameRelayAttempts] consecutive failures to the same relay,
     * tries to find an alternative relay using [alternativeRelaySelector].
     */
    private fun prepareNextReconnectAttempt(): () -> Unit {
        val taskIntentGeneration = relayRegistrationIntentGeneration.get()
        lateinit var task: RelayReconnectTask
        task = RelayReconnectTask {
            var capturedIntentGeneration: Long? = null
            try {
                if (closed.get()) return@RelayReconnectTask

                val capturedIntent = raceLifecycleLock.withLock {
                    if (relayRegistrationIntentGeneration.get() != taskIntentGeneration) {
                        return@withLock null
                    }
                    val capturedRelayPeerId = registeredRelayPeerId ?: return@withLock null
                    requestHandler ?: return@withLock null
                    capturedRelayPeerId to taskIntentGeneration
                } ?: return@RelayReconnectTask
                var relayPeerId = capturedIntent.first
                val intentGeneration = capturedIntent.second
                capturedIntentGeneration = intentGeneration

                // Check if we're disconnected and should reconnect
                if (relayConnection == null) run recovery@ {
                    var failureState = raceLifecycleLock.withLock {
                        if (closed.get() ||
                            relayRegistrationIntentGeneration.get() != intentGeneration
                        ) return@RelayReconnectTask
                        // Immediate recovery preserves this intent and still owns its transaction turn.
                        if (relayConnection != null) return@recovery
                        reconnectAttempts++
                        sameRelayFailureState.get()
                    }

                    // After multiple failures to the same relay, try to find an alternative
                    if (failureState.failures >= maxSameRelayAttempts) {
                        debugLog { "[RELAY-DEBUG] ${failureState.failures} consecutive failures to relay $relayPeerId, looking for alternative..." }
                        val alternativeRelay = alternativeRelaySelector?.invoke()
                        if (alternativeRelay != null && alternativeRelay.peerId != relayPeerId) {
                            debugLog { "[RELAY-DEBUG] Found alternative relay: ${alternativeRelay.peerId}" }
                            // Update to use the alternative relay
                            val alternativeInstalled = raceLifecycleLock.withLock {
                                if (closed.get() ||
                                    relayRegistrationIntentGeneration.get() != intentGeneration
                                ) {
                                    false
                                } else {
                                    // A selector may acknowledge immediate recovery on this intent.
                                    // Keep that connection and continue to successor scheduling.
                                    if (relayConnection != null) return@recovery
                                    registeredRelayPeerId = alternativeRelay.peerId
                                    sameRelayFailureState.resetSameRelayFailures()
                                    failureState = sameRelayFailureState.get()
                                    currentReconnectDelayMs = baseReconnectDelayMs
                                    true
                                }
                            }
                            if (!alternativeInstalled) {
                                return@RelayReconnectTask
                            }
                            relayPeerId = alternativeRelay.peerId
                        } else {
                            debugLog { "[RELAY-DEBUG] No alternative relay available, continuing with $relayPeerId" }
                        }
                    }

                    var reconnectFailureGeneration: Long? = null
                    debugLog { "[RELAY-DEBUG] Relay connection lost, attempting reconnect (attempt $reconnectAttempts, failures to same relay: ${failureState.failures}, next delay: ${currentReconnectDelayMs}ms)" }

                    try {
                        val success = withRelayRegistrationTurn(
                            relayRegistrationSerialization, peerId, relayPeerId,
                        ) {
                            // A competing immediate recovery may acknowledge and close while
                            // this worker waits for the registration turn. Its ACK ends only
                            // attempts that already started, not this worker's later attempt.
                            raceLifecycleLock.withLock {
                                if (relayRegistrationIntentGeneration.get() != intentGeneration) {
                                    return@withRelayRegistrationTurn false
                                }
                                reconnectFailureGeneration = sameRelayFailureState.get().generation
                            }
                            doRegisterWithRelay(relayPeerId, intentGeneration, reportsFailure = false)
                        }
                        if (success) {
                            debugLog {
                                "[RELAY-DEBUG] Successfully reconnected to relay " +
                                    relayConnection?.relayPeerId
                            }
                        } else {
                            debugLog { "[RELAY-DEBUG] Reconnect failed (registration rejected)" }
                            raceLifecycleLock.withLock {
                                val failureGeneration = reconnectFailureGeneration
                                if (!closed.get() &&
                                    failureGeneration != null &&
                                    sameRelayFailureState.recordSameRelayFailure(
                                        failureGeneration
                                    ) != null &&
                                    relayRegistrationIntentGeneration.get() == intentGeneration
                                ) {
                                    // Started same-relay failures survive unacknowledged public calls.
                                    // Only the current intent may change its replacement task's delay.
                                    currentReconnectDelayMs =
                                        minOf(currentReconnectDelayMs * 2, maxReconnectDelayMs)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        debugLog { "[RELAY-DEBUG] Reconnect failed: ${e.message}" }
                        raceLifecycleLock.withLock {
                            val failureGeneration = reconnectFailureGeneration
                            if (!closed.get() &&
                                failureGeneration != null &&
                                sameRelayFailureState.recordSameRelayFailure(
                                    failureGeneration
                                ) != null &&
                                relayRegistrationIntentGeneration.get() == intentGeneration
                            ) {
                                // A thrown result retains history but cannot change a newer delay.
                                currentReconnectDelayMs =
                                    minOf(currentReconnectDelayMs * 2, maxReconnectDelayMs)
                            }
                        }
                    }
                }

                // Schedule next check (always continues, never gives up)
                taskLock.withLock {
                    if (!closed.get() &&
                        relayRegistrationIntentGeneration.get() == intentGeneration
                    ) {
                        prepareNextReconnectAttempt()
                    } else null
                }?.invoke()
            } catch (e: Exception) {
                debugLog { "[RELAY-DEBUG] Error in reconnection task: ${e.message}" }
                // Retry an error only while this exact registration intent still owns recovery.
                // A later register call owns its own task, and unregister advances the generation.
                val registrationStillDesired = raceLifecycleLock.withLock {
                    registeredRelayPeerId != null &&
                        requestHandler != null &&
                        capturedIntentGeneration?.let {
                            relayRegistrationIntentGeneration.get() == it
                        } != false
                }
                taskLock.withLock {
                    if (!closed.get() &&
                        registrationStillDesired &&
                        reconnectionTask === task
                    ) {
                        prepareNextReconnectAttempt()
                    } else null
                }?.invoke()
            }
        }
        reconnectionTask = task
        val delayMs = currentReconnectDelayMs
        return schedule@ {
            if (task.isCancelled) return@schedule
            val deadline = clock.currentTimeMillis() + delayMs
            try {
                task.attachSchedule(clock.schedule(deadline) {
                    if (!task.isCancelled) {
                        try {
                            executor.execute(task)
                        } catch (failure: RejectedExecutionException) {
                            task.cancel(false)
                            debugLogErr { "[RELAY-CLIENT] Reconnect worker submission failed: $failure" }
                            if (!closed.get()) throw failure
                        }
                    }
                })
            } catch (failure: Throwable) {
                try { task.cancel(false) }
                catch (cancelFailure: Throwable) { appendRelayCleanupFailure(failure, cancelFailure) }
                taskLock.withLock { if (reconnectionTask === task) reconnectionTask = null }
                throw failure
            }
        }
    }

    private fun cleanupExpiredRegistrations() {
        val now = clock.currentTimeMillis()
        // Consume disconnected generations before reaping live registrations. A connected peer's
        // keepalive can be delayed by the same scheduler starvation that delayed this sweep; if the
        // live pass ran first, that peer was removed before the tombstone withdrawal was published
        // and the withdrawal had no recipients. Tombstone state/cache mutation remains atomic under
        // the documented lifecycle -> provider -> cache lock order, while publication happens after
        // those locks are released.
        val expiredTombstoneWithdrawals = synchronized(registrationLifecycleLock) {
            pruneExpiredDisconnectedProviderTombstonesLocked(now)
        }
        scheduleRelayIdentityWithdrawals(expiredTombstoneWithdrawals)

        for (peerId in registeredPeers.keys.toList()) {
            var expiredRegistration: RegisteredPeer? = null
            var preparedWithdrawals = emptyList<PreparedServiceWithdrawal>()
            synchronized(providerLifecycleLock(peerId)) {
                val current = registeredPeers[peerId]
                if (current != null &&
                    !registrationIsStagedByOwningTransactionWithProviderLock(peerId, current)
                ) {
                    current.serviceInventory.withStateLock {
                        if (current.serviceInventory.isExpiredLocked(now) &&
                            withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
                                registeredPeers.remove(peerId, current)
                            }
                        ) {
                            val services = current.serviceInventory.deactivateAndSnapshotLocked()
                            preparedWithdrawals = synchronized(cachedServiceAnnouncementsLock) {
                                services.map { service ->
                                    PreparedServiceWithdrawal(
                                        withdrawal = createAndRecordServiceWithdrawalLocked(
                                            service.serviceIdentifier,
                                            peerId,
                                            lifecycleTimestampAfter(service.timestamp)
                                        ),
                                        providerRegistrationAtCommit = current
                                    )
                                }
                            }
                            expiredRegistration = current
                        }
                    }
                }
                if (expiredRegistration != null) {
                    routingTable.removeNeighbor(peerId)
                }
            }

            expiredRegistration?.let { registration ->
                scheduleRelayIdentityWithdrawals(preparedWithdrawals)
                try {
                    registration.controller.close()
                } catch (_: Exception) {
                    // Registration already expired; a concurrently closed sender needs no action.
                }
            }
        }
        pruneInactiveProviderAnnouncements()
    }

    /**
     * Broadcasts ServiceWithdrawal messages for all services a departing peer was providing.
     *
     * When a registered peer disconnects (stream close, registration expiry, or explicit
     * unregister), the relay must notify the network that the peer's services are no longer
     * reachable. Without this, other nodes would continue routing requests to the unreachable
     * peer indefinitely.
     *
     * The compact per-registration inventory is the sole source of disconnect knowledge. The
     * global full-payload replay cache is deliberately not consulted for membership because its
     * independent global capacity bound may have evicted any provider's oldest payload.
     *
     * @param peerId The peer ID of the departing peer
     * @param registration The registration record for the departing peer
     *
     * Caller must hold [providerLifecycleLock] for [peerId].
     */
    private fun prepareServiceWithdrawalsForPeerWithProviderLock(
        peerId: String,
        registration: RegisteredPeer
    ): List<PreparedServiceWithdrawal> {
        val servicesToWithdraw = registration.serviceInventory.deactivateAndSnapshot()

        if (servicesToWithdraw.isEmpty()) return emptyList()

        debugLog { "[RELAY] Broadcasting ${servicesToWithdraw.size} service withdrawal(s) for disconnected peer ${peerId.takeLast(8)}" }

        return synchronized(cachedServiceAnnouncementsLock) {
            servicesToWithdraw.map { service ->
                PreparedServiceWithdrawal(
                    withdrawal = createAndRecordServiceWithdrawalLocked(
                        service.serviceIdentifier,
                        peerId,
                        lifecycleTimestampAfter(service.timestamp)
                    ),
                    providerRegistrationAtCommit = registration
                )
            }
        }
    }

    private fun broadcastServiceWithdrawal(
        serviceIdentifier: String,
        providerPeerId: String,
        minimumTimestamp: Long
    ) {
        val preparedWithdrawal = synchronized(providerLifecycleLock(providerPeerId)) {
            prepareServiceWithdrawalWithProviderLock(
                serviceIdentifier,
                providerPeerId,
                minimumTimestamp
            )
        }
        publishPreparedServiceWithdrawal(preparedWithdrawal)
    }

    /** Caller must hold [providerLifecycleLock] for [providerPeerId]. */
    private fun prepareServiceWithdrawalWithProviderLock(
        serviceIdentifier: String,
        providerPeerId: String,
        minimumTimestamp: Long
    ): PreparedServiceWithdrawal {
        val registrationAtCommit = registeredPeers[providerPeerId]
        val withdrawal = if (registrationAtCommit == null) {
            synchronized(cachedServiceAnnouncementsLock) {
                createAndRecordServiceWithdrawalLocked(
                    serviceIdentifier,
                    providerPeerId,
                    minimumTimestamp
                )
            }
        } else registrationAtCommit.serviceInventory.withStateLock {
            synchronized(cachedServiceAnnouncementsLock) {
                val created = createAndRecordServiceWithdrawalLocked(
                    serviceIdentifier,
                    providerPeerId,
                    minimumTimestamp
                )
                registrationAtCommit.serviceInventory.removeIfDefeatedByWithdrawalLocked(
                    serviceIdentifier,
                    created.timestamp
                )
                created
            }
        }
        return PreparedServiceWithdrawal(withdrawal, registrationAtCommit)
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun createServiceWithdrawalLocked(
        serviceIdentifier: String,
        providerPeerId: String,
        minimumTimestamp: Long
    ): GossipProtocol.ServiceWithdrawal {
        val cachedJson = cachedServiceAnnouncements[serviceIdentifier]?.message
            ?.takeIf { it.providerPeerId == providerPeerId }
        return GossipProtocol.ServiceWithdrawal(
            messageId = GossipProtocol.nextMessageId(),
            serviceUrl = cachedJson?.serviceUrl
                ?: "url://$serviceIdentifier/",
            serviceIdentifier = serviceIdentifier,
            providerPeerId = providerPeerId,
            timestamp = minimumTimestamp
        )
    }

    /** Must be called while holding [cachedServiceAnnouncementsLock]. */
    private fun createAndRecordServiceWithdrawalLocked(
        serviceIdentifier: String,
        providerPeerId: String,
        minimumTimestamp: Long
    ): GossipProtocol.ServiceWithdrawal {
        val withdrawal = createServiceWithdrawalLocked(
            serviceIdentifier,
            providerPeerId,
            minimumTimestamp
        )
        recordWithdrawalReplayStateLocked(
            serviceIdentifier,
            providerPeerId,
            withdrawal.timestamp
        )
        return withdrawal
    }

    private fun preparedWithdrawalIsCurrent(
        prepared: PreparedServiceWithdrawal
    ): Boolean = synchronized(providerLifecycleLock(prepared.withdrawal.providerPeerId)) {
        val currentRegistration = registeredPeers[prepared.withdrawal.providerPeerId]
        if (currentRegistration == null) return@synchronized true
        currentRegistration.serviceInventory.withStateLock {
            val currentTimestamp = currentRegistration.serviceInventory
                .lifecycleTimestampLocked(prepared.withdrawal.serviceIdentifier)
            if (currentTimestamp == null) return@withStateLock true
            debugLog {
                "[RELAY] Dropping superseded withdrawal publication for " +
                    "'${prepared.withdrawal.serviceIdentifier}' from " +
                    "${prepared.withdrawal.providerPeerId.takeLast(8)}: provider lifecycle " +
                    "generation changed=${currentRegistration !== prepared.providerRegistrationAtCommit}, " +
                    "current service timestamp=$currentTimestamp, withdrawal timestamp=" +
                    "${prepared.withdrawal.timestamp}"
            }
            false
        }
    }

    private fun publishPreparedServiceWithdrawal(prepared: PreparedServiceWithdrawal) {
        // KNOWN pre-existing residual race (verified on main): each generation check is separate
        // from the following external publication, so a re-registration in either check-to-publish
        // window can still be beaten by this stale withdrawal externally. Root cause #11 retains
        // disconnect tombstones only; callbacks and forwarding must not run under lifecycle locks.
        if (!preparedWithdrawalIsCurrent(prepared)) return
        notifyServiceWithdrawalWithRelayFanoutOwnership(
            prepared.withdrawal,
            prepared.callbackSenderPeerId
        )
        // The callback is external code and may synchronously re-register the provider. Re-check
        // after it returns so forwarding cannot trail that newer registration and erase its service
        // from remote observers. No callback or transport I/O runs under the provider lock.
        if (!preparedWithdrawalIsCurrent(prepared)) return
        forwardAuthoritativeWithdrawalToRegisteredPeers(
            prepared.withdrawal,
            excludePeerId = prepared.excludePeerId
        )
    }

    /**
     * Publishes the required wire effect without waiting for the local notification callback. The
     * callback contract promises notification, not completion ordering, so a callback that blocks
     * forever runs on the callback context while this identity worker advances its gate.
     */
    private data class WithdrawalPublicationAttempt(
        val callbackCompletion: CompletableFuture<Unit>,
        val failure: Throwable?
    )

    private fun publishPreparedServiceWithdrawalFromIdentityWorker(
        prepared: PreparedServiceWithdrawal,
        callbackPredecessor: CompletableFuture<Unit>
    ): WithdrawalPublicationAttempt {
        var callbackCompletion = callbackPredecessor
        return try {
            callbackCompletion = scheduleRelayPublicationCallback(
                "service withdrawal ${prepared.withdrawal.serviceIdentifier} for " +
                    prepared.withdrawal.providerPeerId,
                callbackPredecessor
            ) {
                notifyServiceWithdrawalWithRelayFanoutOwnership(
                    prepared.withdrawal,
                    prepared.callbackSenderPeerId
                )
            }
            forwardAuthoritativeWithdrawalToRegisteredPeers(
                prepared.withdrawal,
                excludePeerId = prepared.excludePeerId
            )
            WithdrawalPublicationAttempt(callbackCompletion, null)
        } catch (failure: Throwable) {
            WithdrawalPublicationAttempt(callbackCompletion, failure)
        }
    }

    /**
     * Checks if this peer is publicly routable (not behind NAT).
     * Uses PublicAddressDiscovery to get effective addresses which
     * include the PUBLIC_IP environment variable if set.
     */
    private fun isPubliclyRoutable(): Boolean {
        // Use effective addresses which properly substitute PUBLIC_IP for wildcard addresses
        val effectiveAddresses = PublicAddressDiscovery.getEffectiveAddresses(host.listenAddresses(), peerId)
        return effectiveAddresses.any { addrStr ->
            !isPrivateAddress(addrStr)
        }
    }

    private fun isPrivateAddress(multiaddr: String): Boolean {
        return multiaddr.contains("/ip4/127.") ||
                multiaddr.contains("/ip4/10.") ||
                multiaddr.contains("/ip4/192.168.") ||
                multiaddr.contains("/ip4/172.16.") ||
                multiaddr.contains("/ip4/172.17.") ||
                multiaddr.contains("/ip4/172.18.") ||
                multiaddr.contains("/ip4/172.19.") ||
                multiaddr.contains("/ip4/172.20.") ||
                multiaddr.contains("/ip4/172.21.") ||
                multiaddr.contains("/ip4/172.22.") ||
                multiaddr.contains("/ip4/172.23.") ||
                multiaddr.contains("/ip4/172.24.") ||
                multiaddr.contains("/ip4/172.25.") ||
                multiaddr.contains("/ip4/172.26.") ||
                multiaddr.contains("/ip4/172.27.") ||
                multiaddr.contains("/ip4/172.28.") ||
                multiaddr.contains("/ip4/172.29.") ||
                multiaddr.contains("/ip4/172.30.") ||
                multiaddr.contains("/ip4/172.31.") ||
                multiaddr.contains("/ip6/::1") ||
                multiaddr.contains("/ip6/fe80:") ||
                multiaddr.contains("/ip4/0.0.0.0")
    }

    private fun clearChunkedTransferStateAfterClose() {
        var cleanupFailure: Throwable? = null
        fun recordCleanupFailure(failure: Throwable) {
            val firstFailure = cleanupFailure
            if (firstFailure == null) {
                cleanupFailure = failure
            } else {
                firstFailure.addSuppressed(failure)
            }
        }

        while (true) {
            val assemblyKey = synchronized(chunkAssemblyLock) {
                chunkedTransfers.keys.firstOrNull()
                    ?: completingChunkAssemblies.keys.firstOrNull()
                    // An assembly can be inside file creation before it becomes visible in either
                    // ownership map. Its transfer gate is visible first. Joining that gate makes
                    // close wait until the creator observes closed, removes its file, releases its
                    // storage lease, and leaves the gate.
                    ?: chunkTransferGates.keys.firstOrNull()
            } ?: break
            withChunkTransferGate(assemblyKey) {
                val assembly = synchronized(chunkAssemblyLock) {
                    val incomplete = chunkedTransfers.remove(assemblyKey)
                    val completing = completingChunkAssemblies.remove(assemblyKey)
                    check(incomplete == null || completing == null || incomplete === completing) {
                        "Chunked relay transfer '$assemblyKey' owned two different assemblies during close"
                    }
                    incomplete ?: completing
                }
                if (assembly != null) {
                    try {
                        cancelChunkAssemblyExpiry(assembly)
                    } catch (failure: Throwable) {
                        recordCleanupFailure(failure)
                    } finally {
                        // A faulty Scheduled implementation may retain the callback after cancel()
                        // throws. Clear the schedule reference and release the file-backed payload
                        // even in that case; the closed-state check prevents callback re-entry.
                        assembly.expirySchedule = null
                        closeRelayChunkAssembly(assembly.storage)?.let(::recordCleanupFailure)
                    }
                }
            }
        }

        synchronized(outgoingChunkedResponsesLock) {
            outgoingChunkedResponses.values.toList().forEach { response ->
                try {
                    cancelOutgoingChunkedResponseExpiryLocked(response)
                } catch (failure: Throwable) {
                    recordCleanupFailure(failure)
                } finally {
                    // Keep a failed cancellation from leaving a scheduled callback holding the
                    // complete response payload until its original expiry time.
                    response.expirySchedule = null
                    response.raw = ByteArray(0)
                    response.servedChunks.clear()
                }
            }
            outgoingChunkedResponses.clear()
        }

        cleanupFailure?.let { throw it }
    }

    internal fun isReceiveCallbackWorker(thread: Thread): Boolean =
        relayReceiveCallbacks.isWorkerThread(thread)

    override fun close() {
        val calledFromReceiveCallbackWorker = isReceiveCallbackWorker(Thread.currentThread())
        // Stop admitting races, interrupt every tracked dial, and wait a bounded time for the
        // dedicated workers to unwind their connectToRelay cleanup. The set itself is bounded by
        // maxInFlightRaceDials and each FutureTask removes itself in done().
        var clientRelayConnection: RelayConnection? = null
        var registrationClose: CapturedRelayRegistrationClose? = null
        var activeRequestConnectionsToClose: List<RelayConnection> = emptyList()
        var relayCandidatesToCancel: List<RelayCandidateRegistration> = emptyList()
        var closeStarted = false
        var closeFailure: Throwable? = null
        fun recordCloseFailure(failure: Throwable) {
            val primaryFailure = closeFailure
            if (primaryFailure == null) {
                closeFailure = failure
            } else if (primaryFailure !== failure) {
                primaryFailure.addSuppressed(failure)
            }
        }
        try {
            raceLifecycleLock.withLock {
                registrationClose = relayRegistrationCloseState?.let { state ->
                    CapturedRelayRegistrationClose(state, claimRelayRegistrationCloseFailure(state))
                }
                if (!closed.compareAndSet(false, true)) {
                    return@withLock
                }
                closeStarted = true
                relayRegistrationIntentGeneration.incrementAndGet()
                registeredRelayPeerId = null
                requestHandler = null
                RelayRequestMaterializationBudget.wakeWaiters()
                inFlightRaceDials.toList().forEach { it.cancel(true) }
                raceDialExecutor.shutdownNow()
                relayCandidatesToCancel = activeRelayCandidates.toList()
                activeRequestConnectionsToClose = activeRelayRequestConnections.toList()
                activeRelayRequestConnections.clear()
                clientRelayConnection = relayConnection
                relayConnection = null
                connectedRelayPeerId = null
                committedRelayCandidate.set(null)
                relayConnectionGenerationOwner.set(null)
            }
            if (!closeStarted) {
                registrationClose?.let { captured ->
                    closeRelayRegistration(captured.state, 0L, false, captured.claim)
                }
                return
            }
            val shutdownReports = forwardDiagnostics.mapNotNull { it.prepareShutdown() }
            val closedError = RelayException("RelayService closed")
            pendingRequests.entries.forEach { (requestId, pending) ->
                if (pendingRequests.remove(requestId, pending)) {
                    pending.future.completeExceptionally(closedError)
                }
            }
            pendingPings.entries.forEach { (requestId, pending) ->
                if (pendingPings.remove(requestId, pending)) pending.completeExceptionally(closedError)
            }
            shutdownReports.forEach { report ->
                try { report() }
                catch (failure: Throwable) { recordCloseFailure(failure) }
            }
            relayCandidatesToCancel.forEach { candidate ->
            cancelRelayCandidateRegistrationInternal(
                candidate,
                CancellationException(
                    "Relay candidate ${candidate.relayPeerId} was canceled because RelayService closed."
                )
            )
            }
        relayCandidatePreparationExecutor.shutdownNow()
        // Closing outside the guard avoids running transport callbacks while holding it. No
        // reconnect identity can commit after the state transition above: installation and
        // acknowledgement commit use the same guard, and a newly dialed stream that observes
        // closed is discarded.
        clientRelayConnection?.let { connection ->
            relayReceiveCallbacks.closeConnection(connection.relayPeerId, connection)
        }
        registrationClose?.let { captured ->
            try {
                closeRelayRegistration(captured.state, 0L, false, captured.claim)
            } catch (failure: Throwable) {
                // A close observer failure must not skip the remaining service teardown. Keep it
                // as the primary close failure and report it after all cleanup has run.
                recordCloseFailure(failure)
            }
        }
        activeRequestConnectionsToClose.forEach { connection ->
            try {
                connection.close()
            } catch (failure: Throwable) {
                recordCloseFailure(failure)
            }
        }
        drainIdleRelayRequestConnections()

        // A remote channel close can enqueue the close observer on the receive executor just as
        // this service is closing. Settle its refreshes here as well: shutdownNow() is allowed to
        // remove a task that has not started yet, and the listener's finally block cannot be
        // relied on after that point.
        val closedRefreshError = RelayException("RelayService closed")
        pendingRegistrationRefreshAcks.entries.forEach { entry ->
            val pendingAck = entry.value
            val claimed = raceLifecycleLock.withLock {
                !pendingAck.connection.failedListenerOwnsSettlement &&
                    pendingRegistrationRefreshAcks.remove(entry.key, pendingAck)
            }
            if (claimed) {
                pendingAck.acknowledgement.completeExceptionally(closedRefreshError)
            }
        }

        try {
            if (!raceDialExecutor.awaitTermination(2, TimeUnit.SECONDS)) {
                System.err.println(
                    "RelayService.close(): direct/relay dial workers did not settle within 2 seconds; " +
                        "the underlying libp2p dial ignored interruption and will be closed by its " +
                        "late-result cleanup when it returns"
                )
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        try {
            if (!relayCandidatePreparationExecutor.awaitTermination(2, TimeUnit.SECONDS)) {
                System.err.println(
                    "RelayService.close(): candidate preparation workers did not settle within " +
                        "2 seconds; late connection cleanup remains assigned to daemon workers."
                )
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        relayCandidateCleanupExecutor.shutdown()
        try {
            if (!relayCandidateCleanupExecutor.awaitTermination(2, TimeUnit.SECONDS)) {
                System.err.println(
                    "RelayService.close(): candidate cleanup workers did not settle within 2 " +
                        "seconds; remaining transport cleanup will finish on daemon workers."
                )
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        val publicationClosedError = RelayException("RelayService closed during identity publication")
        relayIdentityPublicationGates.values.forEach { gate ->
            synchronized(gate.lock) {
                gate.active?.completion?.completeExceptionally(publicationClosedError)
                gate.active?.visibilityCompletion?.completeExceptionally(publicationClosedError)
                gate.pending?.completion?.completeExceptionally(publicationClosedError)
                gate.pending?.visibilityCompletion?.completeExceptionally(publicationClosedError)
            }
        }
        relayIdentityPublicationGates.clear()
        relayIdentityPublicationExecutor.shutdownNow()
        relayPublicationCallbackExecutor.shutdownNow()
        relayPublicationNotificationExecutor.shutdownNow()
        relayedRequestHandlerExecutor.shutdownNow()
        relayReceiveCallbacks.close()
        relayCloseObserverExecutor.shutdownNow()
        relayReceiveCallbackExecutor.shutdownNow()
        if (calledFromReceiveCallbackWorker) {
            // This executor cannot report terminated until the calling callback itself returns.
            // Join every other receive lane through the queue's worker registry and leave only
            // this caller's already-closed lane to terminate after close() returns.
            relayReceiveCallbacks.awaitWorkersExcept(Thread.currentThread())
        } else {
            var callbackWaitInterrupted = false
            while (!relayReceiveCallbackExecutor.isTerminated) {
                try {
                    relayReceiveCallbackExecutor.awaitTermination(
                        Long.MAX_VALUE,
                        TimeUnit.NANOSECONDS,
                    )
                } catch (_: InterruptedException) {
                    callbackWaitInterrupted = true
                }
            }
            if (callbackWaitInterrupted) Thread.currentThread().interrupt()
        }
        ordinaryRelayGossipExecutor.shutdownNow()

        // Cancel all scheduled tasks first. cancel(true) — NOT cancel(false) — because a task that
        // is RUNNING right now must be interrupted, not merely descheduled: a keepalive tick parks
        // in pongFuture.get(...) for up to keepaliveIntervalMs*2/3 waiting for a pong that a closed
        // service can never receive, and a reconnect attempt parks in connectToRelay's
        // resultReady.get(30s) handshake wait / the 10s registration-ACK read against a relay that
        // may never answer. Un-interrupted, those parked tasks survive into the executor shutdown
        // below and force awaitTermination to burn its full 5-second cap — which a consumer tearing
        // down many nodes back-to-back serializes into minutes (UrlResolver's 29-node
        // registration-storm teardown timing out "stuck at UrlProtocol2.close").
        val schedulesToCancel = taskLock.withLock {
            (keepaliveTask to reconnectionTask).also {
                keepaliveTask = null
                reconnectionTask = null
            }
        }
        schedulesToCancel.first?.cancel(true)
        schedulesToCancel.second?.cancel(true)

        // Close all registered peer connections
        registeredPeers.values.forEach { reg ->
            try {
                reg.controller.close()
            } catch (e: Exception) {
                // Ignore
            }
        }
        withOrdinaryRelayGossipWorkerSizing(registeredPeers, ordinaryRelayGossipExecutor) {
            registeredPeers.clear()
        }
        synchronized(registrationLifecycleLock) {
            // The modern SystemClock uses one process-wide daemon scheduler. RelayService owns
            // only this cancellable sweep handle, so close cancels its callback without shutting
            // down scheduling for any other clock in the JVM.
            disconnectedProviderExpirySchedule?.scheduled?.cancel()
            disconnectedProviderExpirySchedule = null
            disconnectedProviderTombstones.values.forEach { it.serviceInventory.deactivate() }
            disconnectedProviderTombstones.clear()
            disconnectedProviderPeerIds.clear()
        }

        // Detach listener ownership before interrupting or waiting for its final cleanup.
        val listenerToJoin = taskLock.withLock {
            listenerStopSignal?.set(true)
            listenerStopSignal = null
            listenerThread.also { listenerThread = null }
        }
        listenerToJoin?.let { thread ->
            thread.interrupt()
            try { thread.join(1000) }
            catch (e: InterruptedException) { Thread.currentThread().interrupt() }
        }

        // Shutdown executor. shutdownNow() — NOT the graceful shutdown() — because after close()
        // there is no queued periodic tick (cleanup / distance-vector / routing-prune /
        // re-announce) worth running, and shutdownNow() re-interrupts any still-running task as
        // defence in depth (the cancel(true) calls above already interrupted the tracked ones).
        // With parked tasks interrupted, awaitTermination completes in milliseconds instead of
        // burning its cap behind a network wait that can never finish.
        executor.shutdownNow()
        try {
            val terminated = executor.awaitTermination(5, TimeUnit.SECONDS)
            if (!terminated) {
                // Never swallow silently: a worker that survives shutdownNow() + 5s means some
                // task is parked on a non-interruptible wait. The threads are daemon (see the
                // executor's ThreadFactory), so they cannot hold the JVM open — but surface the
                // condition so an operator investigating a slow teardown can see it.
                System.err.println(
                    "RelayService.close(): executor did not terminate within 5 seconds of " +
                        "shutdownNow(); a keepalive/reconnect task is parked on a " +
                        "non-interruptible wait. Its daemon worker threads will exit when that " +
                        "wait's own timeout fires."
                )
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        } catch (failure: Throwable) {
            recordCloseFailure(failure)
        } finally {
            registrationClose?.let { captured ->
                try {
                    // Earlier cleanup can fail before reaching registration transport close.
                    // The same operation is safe to finish here without repeating its error.
                    closeRelayRegistration(captured.state, 0L, false, captured.claim)
                } catch (failure: Throwable) {
                    recordCloseFailure(failure)
                } finally {
                    releaseCapturedRelayRegistrationClose(captured)
                }
            }
            if (closeStarted) {
                try {
                    clearChunkedTransferStateAfterClose()
                } catch (cleanupFailure: Throwable) {
                    recordCloseFailure(cleanupFailure)
                }
            }
        }
        closeFailure?.let { throw it }
    }
}

/**
 * Builds the circuit-relay multiaddress that reaches [targetPeerId] through the
 * relay identified by [relayPeerId] (whose listen addresses are [host]'s).
 *
 * Mirrors the exact format the relay advertises to every registered peer for a
 * NAT'd or loopback peer (see the peer-list exchange in
 * [RelayService.handleRegister]): when the relay has a public transport address
 * it is used as the prefix, otherwise the relay-relative form
 * `/p2p/<relay>/p2p-circuit/p2p/<target>` is used. The result is NEVER empty, so a
 * peer whose own direct addresses filtered to empty (loopback / no discovered
 * public IP) is still reachable through the relay.
 */
/**
 * The addresses a peer advertises in its relay-registration request.
 *
 * Starts from [PublicAddressDiscovery.getEffectiveAddresses] (public-IP-substituted,
 * loopback/wildcard-filtered). When that is empty — a node bound only to a
 * loopback/wildcard interface with no discovered public IP — falls back to
 * loopback addresses derived from the host's actual listen ports, so the
 * registration is NEVER address-less. Mirrors the localhost fallback
 * `UrlResolver.getAnnounceAddresses` applies to gossip announcements: even when no
 * externally-routable address is known, the node IS reachable on these ports via
 * loopback (essential for same-machine peers and tests), and external peers reach
 * it through the circuit-relay address the relay adds on top.
 */
/**
 * Probes whether the ip4/ip6/dns host:port encoded in [multiaddr] answers a TCP
 * connect within [timeoutMs], WITHOUT blocking or parking a thread for the wait.
 *
 * Used by [RelayService.connectToRelay] to bound the reachability phase of a relay
 * dial: a genuinely unreachable relay (no SYN-ACK) resolves to `false` in [timeoutMs]
 * so failover stays fast, while a reachable relay whose libp2p handshake is merely
 * slow resolves to `true` quickly and is then dialed under a far more generous
 * handshake budget.
 *
 * The connect is issued on an [java.nio.channels.AsynchronousSocketChannel], so the
 * SYN/SYN-ACK result arrives as an OS-driven completion event rather than on a parked
 * thread, and the timeout is a scheduled [java.util.concurrent.CompletableFuture]
 * completion ([java.util.concurrent.CompletableFuture.completeOnTimeout]) rather than a
 * blocked socket-read deadline. The probe socket is always closed once the answer is
 * known (success, failure, or timeout); it is never reused — newStream opens its own
 * libp2p connection. Resolves to `false` (rather than failing) for any connect error or
 * an unparseable address, so the caller treats it as unreachable.
 */
private fun probeReachableAsync(multiaddr: String, timeoutMs: Int, clock: Clock): java.util.concurrent.CompletableFuture<Boolean> {
    val parts = multiaddr.split("/").filter { it.isNotEmpty() }
    val hostIdx = parts.indexOfFirst { it == "ip4" || it == "ip6" || it == "dns" || it == "dns4" || it == "dns6" }
    val tcpIdx = parts.indexOf("tcp")
    if (hostIdx < 0 || hostIdx + 1 >= parts.size || tcpIdx < 0 || tcpIdx + 1 >= parts.size) {
        return java.util.concurrent.CompletableFuture.completedFuture(false)
    }
    val host = parts[hostIdx + 1]
    val port = parts[tcpIdx + 1].toIntOrNull() ?: return java.util.concurrent.CompletableFuture.completedFuture(false)

    val channel = try {
        java.nio.channels.AsynchronousSocketChannel.open()
    } catch (e: Exception) {
        return java.util.concurrent.CompletableFuture.completedFuture(false)
    }

    val result = java.util.concurrent.CompletableFuture<Boolean>()
    // Close the probe socket once we have an answer (success, failure, or timeout).
    result.whenComplete { _, _ -> relayDialCleanup(clock) { channel.close() } }
    try {
        channel.connect(java.net.InetSocketAddress(host, port), null, object : java.nio.channels.CompletionHandler<Void, Any?> {
            override fun completed(unused: Void?, attachment: Any?) { result.complete(true) }
            override fun failed(exc: Throwable, attachment: Any?) { result.complete(false) }
        })
    } catch (e: Exception) {
        result.complete(false)
    }
    // No thread is parked waiting: connect completion arrives via the async channel
    // group, and the reachability timeout resolves the future via the injected Clock.
    // Clock.schedule takes an ABSOLUTE deadline (atMillis), so the delay must be added to
    // the clock's current time — passing the bare timeoutMs would schedule a deadline in the
    // distant past under SystemClock (now() is epoch millis) and fire instantly, marking every
    // relay unreachable. Under the default SystemClock this is a real scheduled completion
    // (equivalent to the previous completeOnTimeout); under a ManualClock a test drives this
    // timeout deterministically (advance the clock past the deadline to fire it, or leave it
    // frozen so an unreachable probe stays pending) instead of racing the wall clock.
    val reachabilityTimeout = try {
        clock.schedule(clock.currentTimeMillis() + timeoutMs.toLong()) { result.complete(false) }
    } catch (failure: RelayDialClockFailure) {
        // Close the probe even if TCP completed before timer setup failed. Return a failed future
        // so connectToRelay still installs every address's stream cleanup hook.
        result.completeExceptionally(failure)
        return CompletableFuture<Boolean>().also { it.completeExceptionally(failure) }
    }
    val cleanedResult = result.whenComplete { _, _ -> clock.unschedule(reachabilityTimeout) }
    // Request dialing cannot publish success before its Clock cleanup. Independent maintenance
    // preserves its existing best-effort cancellation behavior.
    return if (clock is RelayRequestDialClock) cleanedResult else result
}

private fun ownRegistrationMultiaddresses(host: Host, peerId: String): List<String> {
    val effective = PublicAddressDiscovery.getEffectiveAddresses(host.listenAddresses(), peerId)
    if (effective.isNotEmpty()) return effective
    val loopback = host.listenAddresses().mapNotNull { addr ->
        val portMatch = Regex("/tcp/(\\d+)").find(addr.toString())
        portMatch?.groupValues?.get(1)?.let { port -> "/ip4/127.0.0.1/tcp/$port/p2p/$peerId" }
    }.distinct()
    return loopback
}

private fun circuitRelayAddress(host: Host, relayPeerId: String, targetPeerId: String): String {
    val relayFullAddr = PublicAddressDiscovery
        .getEffectiveAddresses(host.listenAddresses(), relayPeerId)
        .firstOrNull() ?: ""
    val relayBaseAddr = relayFullAddr.replace(Regex("/p2p/[^/]+$"), "")
    return if (relayBaseAddr.isNotEmpty()) {
        "$relayBaseAddr/p2p/$relayPeerId/p2p-circuit/p2p/$targetPeerId"
    } else {
        "/p2p/$relayPeerId/p2p-circuit/p2p/$targetPeerId"
    }
}

/**
 * A service and the provider-issued wire timestamp that established its current lifecycle.
 *
 * This is the single ordering authority for a provider's services. A withdrawal at timestamp W
 * defeats an announcement at timestamp A exactly when A <= W; only A > W may establish a new
 * lifecycle. Relay-local time is never compared with this value and is used only for expiry
 * deadlines such as registration and tombstone TTLs.
 */
private data class ProviderServiceLifecycle(
    val serviceIdentifier: String,
    val timestamp: Long
)

private fun withdrawalDefeatsAnnouncement(
    announcementTimestamp: Long,
    withdrawalTimestamp: Long
): Boolean = announcementTimestamp <= withdrawalTimestamp

private sealed interface ProviderServiceRecordResult {
    data class Accepted(val displaced: ProviderServiceLifecycle?) : ProviderServiceRecordResult
    data object RejectedInactive : ProviderServiceRecordResult
    data object RejectedExpired : ProviderServiceRecordResult
    data object RejectedDisconnected : ProviderServiceRecordResult
    data object RejectedStale : ProviderServiceRecordResult
}

private fun lifecycleTimestampAfter(timestamp: Long): Long =
    if (timestamp == Long.MAX_VALUE) Long.MAX_VALUE else timestamp + 1L

private data class RelayRegistrationLiveness(
    val lastReceipt: Long,
    val expiresAt: Long
)

private fun nextRelayLocalTimestamp(previous: Long, observed: Long, description: String): Long {
    check(previous < Long.MAX_VALUE) {
        "Cannot extend relay-local $description timestamp beyond Long.MAX_VALUE: previous " +
            "timestamp was $previous and the newly observed relay time was $observed."
    }
    return maxOf(observed, previous + 1L)
}

private fun relayLocalExpiryAfter(receiptTimestamp: Long, registrationTimeoutMs: Long): Long =
    if (registrationTimeoutMs > 0L && receiptTimestamp > Long.MAX_VALUE - registrationTimeoutMs) {
        Long.MAX_VALUE
    } else {
        receiptTimestamp + registrationTimeoutMs
    }

private class ProviderServiceInventory(
    private val maxServices: Int,
    registeredAt: Long,
    registrationTimeoutMs: Long,
    previousLiveness: RelayRegistrationLiveness? = null
) {
    private val stateLock = Any()
    private val services = LinkedHashMap<String, Long>()
    private var active = true
    private var lastKeepalive = previousLiveness?.let {
        nextRelayLocalTimestamp(it.lastReceipt, registeredAt, "registration receipt")
    } ?: registeredAt
    private var expiresAt = previousLiveness?.let {
        maxOf(
            nextRelayLocalTimestamp(it.expiresAt, registeredAt, "registration expiry"),
            relayLocalExpiryAfter(lastKeepalive, registrationTimeoutMs)
        )
    } ?: relayLocalExpiryAfter(registeredAt, registrationTimeoutMs)

    fun <T> withStateLock(block: () -> T): T = synchronized(stateLock) { block() }

    fun isLive(now: Long): Boolean = synchronized(stateLock) { isLiveLocked(now) }

    fun isLiveLocked(now: Long): Boolean = active && expiresAt >= now

    fun isExpiredLocked(now: Long): Boolean = active && expiresAt < now

    /** Caller must hold [stateLock] through [withStateLock]. */
    fun recordLocked(serviceIdentifier: String, timestamp: Long): ProviderServiceRecordResult {
        if (!active) return ProviderServiceRecordResult.RejectedInactive
        val existingTimestamp = services[serviceIdentifier]
        if (existingTimestamp != null && timestamp < existingTimestamp) {
            return ProviderServiceRecordResult.RejectedStale
        }
        services.remove(serviceIdentifier)
        services[serviceIdentifier] = timestamp
        if (services.size <= maxServices) return ProviderServiceRecordResult.Accepted(null)
        val oldest = services.entries.iterator()
        val displaced = oldest.next()
        oldest.remove()
        return ProviderServiceRecordResult.Accepted(
            ProviderServiceLifecycle(displaced.key, displaced.value)
        )
    }

    /** Caller must hold [stateLock] through [withStateLock]. */
    fun removeIfDefeatedByWithdrawalLocked(
        serviceIdentifier: String,
        withdrawalTimestamp: Long
    ): Boolean {
        val lifecycleTimestamp = services[serviceIdentifier] ?: return false
        if (!withdrawalDefeatsAnnouncement(lifecycleTimestamp, withdrawalTimestamp)) return false
        services.remove(serviceIdentifier)
        return true
    }

    fun refresh(now: Long, registrationTimeoutMs: Long): Boolean = synchronized(stateLock) {
        if (!active) return@synchronized false
        // Keepalive receipt order is relay-local liveness state, not provider lifecycle order.
        // Advance it independently of the injected wall clock so every accepted keepalive moves
        // the registration deadline forward even when that clock freezes or moves backward.
        lastKeepalive = nextRelayLocalTimestamp(lastKeepalive, now, "keepalive receipt")
        expiresAt = maxOf(
            nextRelayLocalTimestamp(expiresAt, now, "registration expiry"),
            relayLocalExpiryAfter(lastKeepalive, registrationTimeoutMs)
        )
        true
    }

    fun expiresAt(): Long = synchronized(stateLock) { expiresAt }

    fun livenessSnapshot(): RelayRegistrationLiveness = synchronized(stateLock) {
        RelayRegistrationLiveness(lastKeepalive, expiresAt)
    }

    fun snapshot(): List<String> = synchronized(stateLock) { services.keys.toList() }

    fun snapshotLifecycles(): List<ProviderServiceLifecycle> = synchronized(stateLock) {
        snapshotLifecyclesLocked()
    }

    /** Caller must hold [stateLock] through [withStateLock]. */
    fun lifecycleTimestampLocked(serviceIdentifier: String): Long? = services[serviceIdentifier]

    /** Caller must hold [stateLock] through [withStateLock]. */
    fun snapshotLifecyclesLocked(): List<ProviderServiceLifecycle> =
        services.map { (serviceIdentifier, timestamp) ->
            ProviderServiceLifecycle(serviceIdentifier, timestamp)
        }

    fun deactivate() {
        synchronized(stateLock) { active = false }
    }

    fun deactivateAndSnapshot(): List<ProviderServiceLifecycle> = synchronized(stateLock) {
        active = false
        services.map { (serviceIdentifier, timestamp) ->
            ProviderServiceLifecycle(serviceIdentifier, timestamp)
        }
    }

    /** Caller must hold [stateLock] through [withStateLock]. */
    fun deactivateAndSnapshotLocked(): List<ProviderServiceLifecycle> {
        active = false
        return services.map { (serviceIdentifier, timestamp) ->
            ProviderServiceLifecycle(serviceIdentifier, timestamp)
        }
    }
}

/** Only an in-memory registration map change belongs in [change]. */
private fun <T> withOrdinaryRelayGossipWorkerSizing(
    registrations: Map<String, RegisteredPeer>,
    executor: ThreadPoolExecutor,
    excludePeerId: String? = null,
    change: () -> T,
): T = synchronized(registrations) {
    val result = change()
    val eligiblePeers = registrations.size -
        if (excludePeerId != null && registrations.containsKey(excludePeerId)) 1 else 0
    val target = eligiblePeers.coerceIn(1, executor.maximumPoolSize)
    if (executor.corePoolSize != target) {
        // Zero keep-alive retires excess idle workers when core size decreases. Active turns
        // finish normally, then retire; retaining the remaining cores avoids quiet-period churn.
        executor.corePoolSize = target
    }
    result
}

private data class RegisteredPeer(
    val peerId: String,
    val registrationRequestId: String,
    val serviceInventory: ProviderServiceInventory,
    /** The peer's own multiaddresses (for direct connection, if publicly reachable) */
    val multiaddresses: List<String>,
    val controller: RelayMessageSender,
    val stream: Stream,
    val registeredAt: Long,
    val ordinaryGossipGeneration: Any,
    val ordinaryGossipOutbox: OrdinaryRelayGossipOutbox
) {
    val advertisedServices: List<String>
        get() = serviceInventory.snapshot()

    val expiresAt: Long
        get() = serviceInventory.expiresAt()
}

/**
 * Public information about a registered peer (without internal connection details).
 */
data class RegisteredPeerInfo(
    val peerId: String,
    val advertisedServices: List<String>,
    val registeredAt: Long,
    val expiresAt: Long
)

/**
 * Connection to a relay peer.
 */
private class RelayReconnectTask(action: () -> Unit) : FutureTask<Unit>(Callable { action() }) {
    private val schedule = AtomicReference<Scheduled?>(null)

    fun attachSchedule(handle: Scheduled) {
        schedule.set(handle)
        if (isCancelled) schedule.getAndSet(null)?.cancel()
    }

    override fun cancel(mayInterruptIfRunning: Boolean): Boolean {
        val canceled = super.cancel(mayInterruptIfRunning)
        schedule.getAndSet(null)?.cancel()
        return canceled
    }

    override fun run() {
        schedule.getAndSet(null)
        super.run()
    }
}

private data class CapturedRelayUnregister(
    val connection: RelayConnection,
    val owner: Any,
    val registrationRequestId: String?,
)

/** Tracks inbound progress for one relay registration stream. */
private class RelayKeepaliveProgress(
    stream: Stream,
    private val clock: Clock,
    initialProgressAtMs: Long,
) : AutoCloseable {
    private val lock = Any()
    private var ended = false
    private var started = false
    private var lastProgressMs = initialProgressAtMs
    private val yamuxHandler = stream.connection.muxerSession() as? YamuxHandler
    private val childChannel = streamAsChannel(stream)
    private val muxChannel = if (yamuxHandler != null) {
        childChannel as? MuxChannel<*>
            ?: throw IllegalStateException("Yamux relay registration stream has no mux child channel")
    } else null
    private val streamId = muxChannel?.id
    private val observedChannel = if (muxChannel != null) {
        libp2pRootConnectionChannel(muxChannel)
    } else childChannel
    private val handlerName = "foundation.url.protocol.keepaliveProgress.${UUID.randomUUID()}"
    private val observer = object : ChannelInboundHandlerAdapter() {
        override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
            try {
                val bytes = if (streamId != null) {
                    val frame = msg as? YamuxFrame
                    if (frame != null && frame.id == streamId && frame.length > 0L &&
                        (frame.type == YamuxType.DATA || frame.type == YamuxType.WINDOW_UPDATE)
                    ) frame.length else 0L
                } else {
                    (msg as? ByteBuf)?.readableBytes()?.toLong() ?: 0L
                }
                if (bytes > 0L) recordProgress()
            } catch (failure: Throwable) {
                // Ownership has not reached the next handler when progress recording fails.
                try {
                    ReferenceCountUtil.release(msg)
                } catch (releaseFailure: Throwable) {
                    if (releaseFailure !== failure) failure.addSuppressed(releaseFailure)
                }
                throw failure
            }
            ctx.fireChannelRead(msg)
        }
    }

    fun start() {
        synchronized(lock) {
            if (ended || started) return
            started = true
            val channel = observedChannel ?: return
            val pipeline = channel.pipeline()
            val yamux = yamuxHandler
            if (yamux != null) {
                val yamuxContext = pipeline.context(yamux)
                    ?: throw IllegalStateException(
                        "Yamux handler is not installed on the physical connection for relay stream " +
                            "${streamId?.asLongText()}"
                    )
                pipeline.addBefore(yamuxContext.name(), handlerName, observer)
            } else {
                pipeline.addFirst(handlerName, observer)
            }
        }
    }

    fun recordProgress() {
        val sample = clock.currentTimeMillis()
        synchronized(lock) {
            if (ended) return
            lastProgressMs = maxOf(lastProgressMs, sample)
        }
    }

    /** Progress age is checked by the existing keepalive tick, not a separate timer. */
    fun hasExpired(windowMs: Long): Boolean {
        val sample = clock.currentTimeMillis()
        return synchronized(lock) {
            if (ended) return@synchronized true
            val expired = sample >= saturatedReadDeadline(lastProgressMs, windowMs)
            if (expired) {
                ended = true
                removeObserverLocked()
                true
            } else false
        }
    }

    override fun close() {
        synchronized(lock) {
            ended = true
            removeObserverLocked()
        }
    }

    private fun removeObserverLocked() {
        val channel = observedChannel ?: return
        val pipeline = channel.pipeline()
        if (pipeline.context(handlerName) != null) pipeline.remove(handlerName)
    }
}

private data class DetachedRelayTasks(
    val keepalive: ScheduledFuture<*>?,
    val listenerStopSignal: AtomicBoolean?,
    val listenerThread: Thread?,
)

private data class CapturedRelayRegistrationClose(
    val state: RelayRegistrationCloseState,
    val claim: Any?,
)

internal class RelayRegistrationCloseState(val controller: RelayStreamController) {
    internal val operation = AtomicReference<RelayConnectionCloseOperation?>(null)
    internal val failureOwner = AtomicReference<Any?>(null)
    @Volatile internal var closeFailures = RelayRegistrationCloseFailures()
}

// Shared by the stream generations of one registration. Guarded by this record, not a
// stream's lifecycle: an older physical close can finish after a newer stream is selected.
internal class RelayRegistrationCloseFailures {
    internal var failure: Throwable? = null
    internal var owner: Any? = null
    internal var retainedLaterFailures = 0
    internal var omittedCount = AtomicLong(0L)
    internal var omittedSummary: Throwable? = null
}

private class RelayRegistrationCloseFailureClaim(
    val state: RelayRegistrationCloseState,
    val record: RelayRegistrationCloseFailures,
)

private fun appendRelayRegistrationCloseFailure(record: RelayRegistrationCloseFailures, later: Throwable) {
    synchronized(record) {
        val first = record.failure
        if (first == null) {
            record.failure = later
        } else if (later !== first && first.suppressed.none { it === later }) {
            // Seven exact later failures and one running count bound the added detail.
            if (record.retainedLaterFailures < 7) {
                first.addSuppressed(later)
                record.retainedLaterFailures++
            } else {
                if (record.omittedSummary == null) {
                    record.omittedSummary = OmittedRelayRegistrationCloseFailures(record.omittedCount).also {
                        first.addSuppressed(it)
                    }
                }
                if (record.omittedCount.get() < Long.MAX_VALUE) record.omittedCount.incrementAndGet()
            }
        }
    }
}

private class OmittedRelayRegistrationCloseFailures(private val count: AtomicLong) :
    RuntimeException(null, null, false, false) {
    override val message: String
        get() = "${count.get()} additional relay registration close failures were omitted."
}

// Called under the service lifecycle guard, before the new stream is published.
private fun carryRelayRegistrationCloseFailures(
    previous: RelayRegistrationCloseState?,
    state: RelayRegistrationCloseState,
): RelayRegistrationCloseState {
    if (previous == null || previous === state) return state
    val record = previous.closeFailures
    synchronized(state) {
        val own = state.closeFailures
        state.closeFailures = record
        synchronized(own) { own.failure }?.let { appendRelayRegistrationCloseFailure(record, it) }
    }
    return state
}

private fun takeRelayRegistrationCloseFailure(
    state: RelayRegistrationCloseState,
    claim: Any?,
): Throwable? {
    val captured = claim as? RelayRegistrationCloseFailureClaim ?: return null
    if (captured.state !== state) return null
    val record = captured.record
    return synchronized(record) {
        if (record.owner !== claim || state.failureOwner.get() !== claim) return@synchronized null
        val reported = record.failure
        record.failure = null
        record.retainedLaterFailures = 0
        // Already delivered summaries keep their original count after this record is reused.
        record.omittedCount = AtomicLong(0L)
        record.omittedSummary = null
        record.owner = null
        state.failureOwner.compareAndSet(claim, null)
        reported
    }
}

private fun releaseRelayRegistrationCloseFailureClaim(
    state: RelayRegistrationCloseState,
    claim: Any? = state.failureOwner.get(),
) {
    val captured = claim as? RelayRegistrationCloseFailureClaim ?: return
    synchronized(captured.record) {
        if (captured.record.owner === claim) captured.record.owner = null
        state.failureOwner.compareAndSet(claim, null)
    }
}

private fun releaseCapturedRelayRegistrationClose(captured: CapturedRelayRegistrationClose) {
    releaseRelayRegistrationCloseFailureClaim(captured.state, captured.claim)
}

internal class RelayConnectionCloseOperation(val owner: Thread) {
    val outcome = CompletableFuture<RelayConnectionCloseOutcome>()
}

internal data class RelayConnectionCloseOutcome(
    val flushed: Boolean,
    val failure: Throwable?,
)

private fun claimRelayRegistrationCloseFailure(state: RelayRegistrationCloseState): Any? {
    val operation = state.operation.get()
    // A synchronous transport callback cannot receive the result of its own unfinished close.
    if (operation != null && operation.owner === Thread.currentThread() && !operation.outcome.isDone) {
        return null
    }
    val record = state.closeFailures
    val claim = RelayRegistrationCloseFailureClaim(state, record)
    if (!state.failureOwner.compareAndSet(null, claim)) return null
    return synchronized(record) {
        if (record.owner == null && state.failureOwner.get() === claim) {
            record.owner = claim
            claim
        } else {
            state.failureOwner.compareAndSet(claim, null)
            null
        }
    }
}

private fun closeRelayRegistration(
    state: RelayRegistrationCloseState,
    flushTimeoutMs: Long,
    retirement: Boolean,
    claim: Any?,
    reportFailureToCleanupCaller: Boolean = false,
    cleanupFailureReporter: ((Throwable) -> Unit)? = null,
): Boolean {
    val candidate = RelayConnectionCloseOperation(Thread.currentThread())
    val operation = if (state.operation.compareAndSet(null, candidate)) candidate
        else checkNotNull(state.operation.get())
    if (operation !== candidate) {
        // Retirement and unclaimed/reentrant teardown never wait for another closer.
        if (retirement || claim == null ||
            operation.owner === Thread.currentThread() && !operation.outcome.isDone
        ) return true
    } else {
        var flushed = false
        var failure: Throwable? = null
        try {
            flushed = if (cleanupFailureReporter != null) state.controller.closeAfterDialFailure(cleanupFailureReporter)
                else if (retirement) state.controller.closeAfterListenerFailure()
                else state.controller.close(flushTimeoutMs)
        } catch (closeFailure: Throwable) {
            failure = closeFailure
        } finally {
            failure?.let { closeFailure ->
                synchronized(state) { appendRelayRegistrationCloseFailure(state.closeFailures, closeFailure) }
            }
            operation.outcome.complete(RelayConnectionCloseOutcome(flushed, failure))
        }
        if (retirement || reportFailureToCleanupCaller) {
            // The listener chooses a single reporter after its other cleanup finishes. Other
            // internal cleanup callers retain their context without taking an explicit claim.
            if (reportFailureToCleanupCaller) failure?.let { throw it }
            return flushed
        }
    }
    if (claim == null) return operation.outcome.getNow(null)?.flushed ?: true
    // The service reserves this claim before running callbacks or waiting for unregister ACKs.
    // join preserves interruption and runs outside the lifecycle guard.
    val outcome = operation.outcome.join()
    takeRelayRegistrationCloseFailure(state, claim)?.let { throw it }
    return outcome.flushed
}

internal class RelayConnection(
    val relayPeerId: String,
    internal val controller: RelayStreamController
) : AutoCloseable {

    internal val responseDiagnostics = RelayResponseStreamDiagnostics().let { created ->
        val channel = streamAsChannel(controller.diagnosticStream)
        channel?.attr(relayResponseDiagnosticsKey)?.setIfAbsent(created) ?: created
    }
    @Volatile internal var readerDiagnostic: RelayRegistrationReaderDiagnostic? = null

    internal val closeObserverFailure = AtomicReference<Throwable?>(null)
    internal val closeState = RelayRegistrationCloseState(controller)

    val orderedUnregisterInProgress = AtomicBoolean(false)
    private val registeredRequestsLock = Any()
    private var registeredRequestsSealed = false
    private val registeredRequests =
        LinkedHashMap<AwaitedResponseFailureReservation, RelayProtocol.RelayRequest>()

    fun acceptRegisteredRequest(
        request: RelayProtocol.RelayRequest,
        reservation: AwaitedResponseFailureReservation,
    ): Boolean = synchronized(registeredRequestsLock) {
        if (registeredRequestsSealed || isClosed()) false else {
            reservation.registeredRequest = true
            registeredRequests[reservation] = request
            true
        }
    }

    fun sealRegisteredRequests(): List<Pair<AwaitedResponseFailureReservation, RelayProtocol.RelayRequest>> =
        synchronized(registeredRequestsLock) {
            registeredRequestsSealed = true
            registeredRequests.entries.filter { it.key.claimRegisteredClose() }.map { it.key to it.value }
        }

    fun forgetRegisteredRequest(reservation: AwaitedResponseFailureReservation) {
        synchronized(registeredRequestsLock) { registeredRequests.remove(reservation) }
    }

    private var keepaliveProgress: RelayKeepaliveProgress? = null

    init {
        onClosed {
            stopKeepaliveProgress()
            synchronized(registeredRequestsLock) {
                registeredRequestsSealed = true
                registeredRequests.clear()
            }
        }
    }

    @Synchronized
    fun startKeepaliveProgress(clock: Clock, initialProgressAtMs: Long): () -> Unit {
        if (isClosed()) return {}
        keepaliveProgress?.let { return it::recordProgress }
        val progress = RelayKeepaliveProgress(
            controller.diagnosticStream,
            clock,
            initialProgressAtMs,
        )
        keepaliveProgress = progress
        try {
            progress.start()
        } catch (failure: Throwable) {
            keepaliveProgress = null
            throw failure
        }
        if (isClosed()) stopKeepaliveProgress()
        return progress::recordProgress
    }

    fun keepaliveProgressHasExpired(windowMs: Long): Boolean {
        val progress = synchronized(this) { keepaliveProgress } ?: return true
        return progress.hasExpired(windowMs)
    }

    @Synchronized
    fun stopKeepaliveProgress() {
        val progress = keepaliveProgress
        keepaliveProgress = null
        progress?.close()
    }

    var latestStreamOwningRegistrationRequestId: String? = null
    var latestStreamOwningRegistrationSequence: Long = 0L

    // Guarded by RelayService.raceLifecycleLock. Only a listener that has already failed can
    // reserve settlement; normal close never waits for a future listener/observer contribution.
    var failedListenerOwnsSettlement: Boolean = false

    internal fun onClosed(listener: () -> Unit) {
        controller.addCloseListener(listener)
    }

    internal fun isOnTransportEventLoop(): Boolean =
        controller.rootConnectionChannel()?.eventLoop()?.inEventLoop() == true

    fun sendMessage(json: JSONObject) {
        controller.sendMessage(json)
    }

    fun sendMessage(json: JSONObject, maxAdmissionWaitMs: Long): Boolean =
        controller.sendMessage(json, maxAdmissionWaitMs)

    /** Returns false only when the live transport cannot admit the local PING. */
    fun sendKeepalivePing(ping: RelayProtocol.RelayPing): Boolean =
        controller.sendKeepalivePing(ping)

    fun sendMessageAwaitingDelivery(json: JSONObject) {
        controller.sendMessageAwaitingDelivery(json)
    }

    fun sendResponseWithOutbox(
        json: JSONObject,
        failureReservation: AwaitedResponseFailureReservation,
        registeredClose: Boolean = false,
    ): AwaitedResponseWriteOutcome =
        controller.sendResponseWithOutbox(json, failureReservation, registeredClose = registeredClose)

    suspend fun reserveResponseFailure(
        outboxFullSignal: JSONObject,
    ): AwaitedResponseFailureReservation? =
        controller.reserveResponseFailure(outboxFullSignal)

    fun readMessage(timeout: Long, unit: TimeUnit): JSONObject? {
        return controller.readMessage(timeout, unit)
    }

    fun readMessage(
        idleTimeout: Long, frameTimeout: Long, unit: TimeUnit, clock: Clock,
        operationDeadlineMs: Long = Long.MAX_VALUE,
    ): JSONObject? = controller.readMessage(idleTimeout, frameTimeout, unit, clock, operationDeadlineMs)

    /**
     * True once the underlying relay stream has been closed — either locally via
     * [close] or remotely (the peer reset/closed the substream, surfaced through
     * [RelayStreamController]'s `channelInactive`/`exceptionCaught`). Lets readers
     * distinguish a [readMessage] `null` caused by a closed stream (stop listening)
     * from one caused by a read timeout (keep listening).
     */
    fun isClosed(): Boolean = controller.isClosed()

    /**
     * Whether a request written on this connection could still have its response read back.
     *
     * Strictly stronger than `!isClosed()`. See [RelayStreamController.canCarryResponse].
     */
    fun canCarryResponse(): Boolean = controller.canCarryResponse()

    /** True only when the stream or its physical response path has actually closed. */
    fun responsePathIsGone(): Boolean = controller.responsePathIsGone()


    /**
     * Closes the connection. Forwards through to [RelayStreamController.close], which
     * awaits [io.libp2p.core.Stream.closeWrite] for up to [flushTimeoutMs] before
     * tearing the channel down. Returns true if the flush completed in time.
     */
    fun close(flushTimeoutMs: Long): Boolean =
        closeRelayRegistration(closeState, flushTimeoutMs, false, null, reportFailureToCleanupCaller = true)

    // Retirement records the physical outcome. A public reporter reserves its own claim.
    internal fun retire(): Boolean = closeRelayRegistration(closeState, 0L, true, null)

    /**
     * AutoCloseable.close() — closes the connection without waiting for any pending
     * writes to flush. Matches [RelayMessageSender.close]'s no-arg semantics: flush is
     * opt-in via [close]'s explicit `flushTimeoutMs` parameter, since teardown paths
     * that close many connections in sequence shouldn't pay an unconditional per-close
     * flush ceiling.
     */
    override fun close() { close(0L) }
}

/**
 * Non-blocking Netty handler for server-side relay stream message processing.
 *
 * Receives complete message frames from [LengthFieldBasedFrameDecoder], parses JSON,
 * and dispatches to [RelayService] methods. Tracks per-stream registration state
 * and cleans up on stream close.
 *
 * Cleanup on disconnect is scheduled through the same per-stream mutex as message processing.
 * This prevents a race where an in-flight message-processing coroutine (for example, one suspended
 * while a link-state fan-out waits for transport admission) writes shared state after cleanup has
 * removed the registration. A limitedParallelism(1) dispatcher alone is not a serial coroutine
 * actor: a suspended coroutine releases its dispatcher worker and another coroutine can run. The
 * mutex preserves message and cleanup order across those suspension points without pinning a
 * platform thread.
 */
class RelayServerMessageHandler(
    private val stream: Stream,
    private val sender: RelayMessageSender,
    private val relayService: RelayService
) : SimpleChannelInboundHandler<ByteBuf>() {

    // Keep only this scalar generation in relay cache entries. The cache must not retain this
    // handler or its stream after cleanup.
    private val streamGeneration = nextRelayServerStreamGeneration.incrementAndGet()

    // Capture the remote identity while the stream is still live. Libp2p may no longer expose
    // remotePeerId() once channelInactive/exceptionCaught runs, which used to make a disconnect
    // before processIncomingMessage returned impossible to clean up reliably.
    private val streamPeerId: String? = try {
        stream.remotePeerId()?.toBase58()
    } catch (_: Exception) {
        null
    }

    @Volatile private var registeredPeerId: String? = null

    // Set to true when the channel becomes inactive or an exception closes it.
    // Prevents channelRead0 from launching new message-processing coroutines
    // after cleanup has been scheduled.
    @Volatile private var channelClosed = false
    private val receiveWindowControl = installRelayYamuxReceiveWindowControl(stream)
    @Volatile private var receiveWindowPaused = false

    // Dispatch message processing off the Netty event loop. The mutex preserves messages in
    // arrival order, including while one processing coroutine is suspended; limitedParallelism(1)
    // keeps at most one runnable coroutine from this stream on Dispatchers.IO at a time.
    // The forward path inside handleRelayRequest is now asynchronous — it schedules
    // a whenCompleteAsync reply rather than blocking on future.get — so a single
    // slow target no longer wedges this dispatcher slot for 30 s.
    private val dispatcher = kotlinx.coroutines.Dispatchers.IO.limitedParallelism(1)
    private val scope = kotlinx.coroutines.CoroutineScope(
        dispatcher + kotlinx.coroutines.SupervisorJob()
    )
    private val messageProcessingMutex = kotlinx.coroutines.sync.Mutex()

    // Count of message-processing coroutines that have been launched but have not
    // yet completed — i.e. the depth of this stream's serialized message-processing
    // queue. Each suspended coroutine pins its parsed JSON, captured lambda state,
    // and (for in-flight RelayRequest forwards) Netty channel promises and outbound
    // buffers. The 2026-05 BuildTest WUI heap dump (~30 000 of every artefact in this
    // chain) showed the queue can grow unboundedly when a forward target hangs.
    //
    // Historical context: the original failure mode was [forwardRequestToRegistered]
    // calling `future.get(30s)` while holding the [limitedParallelism(1)] dispatcher
    // slot, which prevented the slot from servicing subsequent messages until the
    // forward timed out 30 s later. The forward path was made asynchronous (it now
    // schedules a `whenCompleteAsync` reply) so the slot is freed as soon as the
    // request bytes are queued for the target. With async forwarding the queue
    // depth in normal operation stays at or near zero.
    //
    // The pending-count + receive-window backpressure (see [channelRead0] /
    // [MAX_PENDING_PROCESSING_PAUSE_THRESHOLD]) remain as defense-in-depth: they
    // bound the heap exposure if some other future code path reintroduces blocking
    // inside the dispatcher slot, and they shed load if a single peer floods this
    // stream faster than [processIncomingMessage] can dispatch async forwards.
    private val pendingProcessing = java.util.concurrent.atomic.AtomicInteger(0)

    /** @return current depth of this stream's pending-processing queue. */
    fun pendingProcessingCount(): Int = pendingProcessing.get()

    /**
     * Backpressure sink the [RelayService.forwardRequestToRegistered] /
     * [RelayService.forwardRequestViaRoute] async-reply paths feed back into
     * this handler's `pendingProcessing` counter so the queue cap from PR #252
     * also bounds in-flight async forwards (each pinning a captured
     * `RelayRequest`, `sourceController`, and lambda continuation). Without
     * this hook, decrementing on processIncomingMessage's return — which now
     * happens immediately after the forward is scheduled — would leave
     * pendingProcessing oblivious to the in-flight forwards and the cap would
     * stop bounding heap exposure (see
     * stressTestRelayProcessSurvivesOomFloodWithConstrainedHeap).
     */
    private val inflightForwardSink: RelayService.InflightForwardSink =
        object : RelayService.InflightForwardSink {
            override fun beforeAsyncForwardScheduled() {
                pendingProcessing.incrementAndGet()
            }

            override fun afterAsyncForwardCompleted() {
                adjustPendingAndMaybeResume(-1)
            }
        }

    private val publicationCompletionSink: RelayService.IdentityPublicationCompletionSink =
        object : RelayService.IdentityPublicationCompletionSink {
            private val latestByProvider =
                ConcurrentHashMap<String, RelayService.IdentityPublicationCompletion>()

            override fun trackIdentityPublication(
                providerPeerId: String,
                publication: RelayService.IdentityPublicationCompletion
            ) {
                latestByProvider[providerPeerId] = publication
                publication.completion.whenComplete { _, throwable ->
                    if (throwable == null) {
                        latestByProvider.remove(providerPeerId, publication)
                        return@whenComplete
                    }
                    var cause: Throwable = throwable
                    while ((cause is CompletionException || cause is ExecutionException) &&
                        cause.cause != null && cause.cause !== cause
                    ) {
                        cause = cause.cause!!
                    }
                    val ctx = currentChannelHandlerContext ?: return@whenComplete
                    ctx.channel().eventLoop().execute {
                        if (channelClosed || !ctx.channel().isOpen) return@execute
                        if (latestByProvider[providerPeerId] !== publication ||
                            !publication.failureStillOwnsRegistration()
                        ) {
                            latestByProvider.remove(providerPeerId, publication)
                            debugLogErr {
                                "[RELAY] Ignoring publication failure for superseded provider " +
                                    "generation '$providerPeerId': ${cause.message}"
                            }
                            return@execute
                        }
                        latestByProvider.remove(providerPeerId, publication)
                        debugLogErr {
                            "[RELAY] Identity publication owned by stream " +
                                "${streamPeerId ?: registeredPeerId} " +
                                "failed: ${cause.message}; closing only the owning stream"
                        }
                        channelClosed = true
                        ctx.close()
                    }
                }
            }
        }

    /**
     * Decrement [pendingProcessing] by `delta` and, if the resulting depth has
     * fallen at or below [MAX_PENDING_PROCESSING_RESUME_THRESHOLD], restore
     * receive admission. Centralised here so
     * both the launch's finally and the async-forward completion callback go
     * through the same path.
     */
    private fun adjustPendingAndMaybeResume(delta: Int) {
        val remaining = pendingProcessing.addAndGet(delta)
        if (remaining > MAX_PENDING_PROCESSING_RESUME_THRESHOLD || channelClosed) return
        if (!receiveWindowPaused || receiveWindowControl == null) return
        val ctx = currentChannelHandlerContext ?: return
        val ch = ctx.channel()
        ch.eventLoop().execute {
            if (
                !channelClosed && receiveWindowPaused &&
                pendingProcessing.get() <= MAX_PENDING_PROCESSING_RESUME_THRESHOLD
            ) {
                receiveWindowPaused = false
                receiveWindowControl.resume()
            }
        }
    }

    /**
     * Captured during [channelRead0] so [adjustPendingAndMaybeResume] (which can
     * be invoked from an async-forward whenCompleteAsync callback running off
     * any thread) has a stable reference to the channel for the receive-window resume
     * path. ChannelHandlerContext does NOT migrate across handlers in our setup
     * so this is safe to cache once seen.
     */
    @Volatile
    private var currentChannelHandlerContext: ChannelHandlerContext? = null

    override fun channelRead0(ctx: ChannelHandlerContext, msg: ByteBuf) {
        if (channelClosed) return

        // Bound the per-stream pending-processing queue. The original failure
        // mode was forwardRequestToRegistered blocking on `future.get(30s)` and
        // holding the limitedParallelism(1) slot for the full timeout while
        // inbound messages stacked up — the 2026-05-03 BuildTest WUI heap dump
        // showed ~30 000 such queued coroutines × ~5 KB each ≈ 150 MB of pinned
        // heap, OOM followed. The forward path is now asynchronous (the slot
        // is freed as soon as the forward request is queued for the target),
        // but this cap remains as defense-in-depth: it shields the relay from
        // any future code path that reintroduces blocking on the dispatcher
        // slot, and it sheds load when a single peer floods inbound faster
        // than [processIncomingMessage] can dispatch async forwards.
        //
        // A Yamux ping stream uses its real per-stream receive window: pings have one expected pong
        // apiece, so withholding WINDOW_UPDATE credit preserves that request/reply relationship
        // instead of discarding requests while the response consumer is paused. Once paused, every
        // frame already covered by previously granted credit is accepted so an ordered control
        // message immediately after the pings cannot be discarded. Other relay traffic retains the
        // established best-effort hard queue bound. Mplex has no receive window, so all of its
        // traffic uses that bounded discard behavior.
        currentChannelHandlerContext = ctx
        val jsonString = msg.toString(StandardCharsets.UTF_8)
        val json = try {
            parseJsonWireString(jsonString)
        } catch (e: org.json.JSONException) {
            debugLogErr {
                "[RELAY] Ignoring malformed JSON message from " +
                    "${streamPeerId ?: registeredPeerId}: ${e.message}"
            }
            return
        }
        val useReceiveWindowBackpressure =
            receiveWindowControl != null &&
                json.optString("type") == RelayProtocol.TYPE_RELAY_PING
        val alreadyAdmittedDuringReceiveWindowPause =
            receiveWindowControl != null && receiveWindowPaused
        val depthBeforeAccept = pendingProcessing.get()
        if (
            depthBeforeAccept >= MAX_PENDING_PROCESSING_PAUSE_THRESHOLD &&
            !useReceiveWindowBackpressure && !alreadyAdmittedDuringReceiveWindowPause
        ) {
            debugLogErr {
                "[RELAY] Dropping inbound message from ${stream.remotePeerId()}: " +
                    "per-stream pending-processing queue at $depthBeforeAccept " +
                    "(>= $MAX_PENDING_PROCESSING_PAUSE_THRESHOLD); this mux path has no " +
                    "active receive-window backpressure"
            }
            return
        }
        val depthAfterAccept = pendingProcessing.incrementAndGet()
        if (
            useReceiveWindowBackpressure &&
            depthAfterAccept >= MAX_PENDING_PROCESSING_PAUSE_THRESHOLD &&
            !receiveWindowPaused && receiveWindowControl?.pause() != null
        ) {
            receiveWindowPaused = true
            debugLog { "[RELAY-FLOW] Server processing queue paused at depth $depthAfterAccept" }
        }
        scope.launch {
            var synchronousFailure: RelaySynchronousForwardFailure? = null
            var admissionFailureReport: (() -> Unit)? = null
            try {
                try {
                    messageProcessingMutex.withLock {
                        val outcome = relayService.processIncomingMessage(
                            json,
                            sender,
                            stream,
                            registeredPeerId,
                            inflightForwardSink,
                            publicationCompletionSink,
                            streamGeneration
                        )
                        registeredPeerId = outcome.registeredPeerId
                        synchronousFailure = outcome.synchronousFailure
                    }
                    // A failed forward no longer owns a downstream response. Admit its error
                    // outside the message mutex, retaining pending-processing ownership meanwhile.
                    synchronousFailure?.settleReply?.invoke()
                } catch (e: RelayException) {
                    val senderClosedConcurrently =
                        channelClosed || sender.isClosed() || !ctx.channel().isOpen
                    val messageType = json.optString("type", "?")
                    val messagePeer = streamPeerId ?: registeredPeerId
                    admissionFailureReport = {
                        if (senderClosedConcurrently) {
                            debugLogErr {
                                "[RELAY] Failed message (type=$messageType) from " +
                                    "$messagePeer: sender closed concurrently: ${e.message}"
                            }
                        } else {
                            debugLogErr {
                                "[RELAY] Failed message (type=$messageType) from " +
                                    "$messagePeer: live transport admission failure: " +
                                    "${e.message}; closing stream so the peer fails immediately"
                            }
                        }
                    }
                    if (!senderClosedConcurrently) {
                        channelClosed = true
                        ctx.close()
                    }
                }
            } finally {
                try { adjustPendingAndMaybeResume(-1) }
                finally {
                    val synchronousReport = synchronousFailure?.reportFailure
                    val admissionReport = admissionFailureReport
                    if (synchronousReport != null || admissionReport != null) {
                        // Finish this frame's coroutine so held output cannot retain its parsed
                        // request. The independent child owns only the two prepared reports.
                        scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                            var reportFailure: Throwable? = null
                            try { synchronousReport?.invoke() }
                            catch (later: Throwable) { reportFailure = later }
                            try { admissionReport?.invoke() }
                            catch (later: Throwable) {
                                reportFailure = appendRelayCleanupFailure(reportFailure, later)
                            }
                            reportFailure?.let { throw it }
                        }
                    }
                }
            }
        }
    }

    companion object {
        /**
         * When the per-stream pending-processing queue reaches this depth,
         * the handler withholds Yamux receive-window updates for lossless ping/reply traffic, so
         * the peer is forced to slow its send-side. Other best-effort relay traffic and Mplex
         * (which has no receive window) discard subsequent messages at this hard queue bound.
         * Bounds the worst-case per-stream queue depth (and therefore the
         * worst-case heap pinned by suspended message-processing coroutines)
         * to roughly this value plus whatever Netty has already decoded into
         * the pipeline at the moment of the pause signal.
         */
        const val MAX_PENDING_PROCESSING_PAUSE_THRESHOLD = 100

        /**
         * Once the per-stream pending-processing queue has drained back below
         * this depth the handler grants the deferred Yamux window credit. Picked well
         * below the pause threshold so we get hysteresis — receive admission
         * doesn't oscillate on every single completed message at sustained
         * peak load.
         */
        const val MAX_PENDING_PROCESSING_RESUME_THRESHOLD = 50
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        debugLog { "[RELAY-DEBUG] Stream closed for peer=${streamPeerId ?: registeredPeerId}" }
        val closeObservation = relayStreamCloseObservation(stream)
        channelClosed = true
        receiveWindowPaused = false
        receiveWindowControl?.close()
        // Schedule cleanup on the same serialized dispatcher so it runs AFTER any
        // in-flight message-processing coroutine completes. This prevents the race
        // where a gossip coroutine writes to cachedServiceAnnouncements after the
        // cleanup has removed the entry.
        scope.launch {
            var retirement: RelayStreamRetirement? = null
            try {
                retirement = messageProcessingMutex.withLock {
                    // Earlier complete frames retain their response correlation. Only detach
                    // terminal work here; futures, cleanup and output may invoke callbacks.
                    relayService.detachForwardStreamClosed(sender, closeObservation)
                }
                retirement.settleReplies()
            } finally {
                try {
                    val peerId = registeredPeerId ?: streamPeerId
                    if (peerId != null) {
                        val cachedAnnouncementRemoved =
                            relayService.cleanupStreamRegistrationWithProviderLock(
                                peerId,
                                sender,
                                streamGeneration
                            )
                        sender.close()
                        relayService.tossDisconnectedPeerCleanupEffect(
                            peerId,
                            cachedAnnouncementRemoved
                        )
                    } else {
                        sender.close()
                    }
                } finally {
                    relayService.unregisterServerHandler(this@RelayServerMessageHandler)
                    retirement?.reportFailures()
                }
            }
        }
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        markRelayStreamClose(ctx.channel(), true, if (cause is ReadTimeoutException) "idle-timeout" else "error", cause)
        if (cause is ReadTimeoutException) {
            debugLog { "[RELAY] Idle timeout for stream from ${streamPeerId ?: registeredPeerId}, closing" }
        } else {
            debugLog {
                "[RELAY-DEBUG] Stream error for peer=${streamPeerId ?: registeredPeerId}: " +
                    cause.message
            }
        }
        ctx.close()
        // channelInactive will be fired by Netty after ctx.close() and handles cleanup
    }
}

/**
 * Controller for a relay protocol stream.
 * Used for bidirectional communication on relay protocol streams (client-side).
 * Implements [RelayMessageSender] for write operations.
 */
data class RelayReadBufferSnapshot(
    val currentBytes: Long,
    val peakBytes: Long,
    val readsPaused: Boolean,
    val pauseCount: Long,
)

class RelayStreamController(
    private val stream: Stream,
) : RelayMessageSender {

    internal val diagnosticStream: Stream get() = stream
    private val closed = AtomicBoolean(false)
    private val parseBudgetCancellation = ParseBudgetCancellation()
    internal val responseEnded = CompletableFuture<Unit>()
    // The ordered unregister operation observes physical retirement after logical cleanup.
    // Existing close callers retain their synchronous, best-effort completion behavior.
    @Volatile internal var streamCloseCompletion: CompletableFuture<*>? = null
        private set
    // Close observers are notified exactly once for local close, remote channelInactive, inbound
    // buffer overflow, and channel exceptions. The listener list has its own lock because the
    // closed flag is also read/written under readLock; a registration racing with the transition
    // must either join the list before the one fire or run immediately after it.
    private val closeListenersLock = Any()
    private val closeListeners = ArrayList<() -> Unit>()
    private var closeListenersFired = false
    // Use ArrayDeque of ByteArray chunks instead of ConcurrentLinkedQueue<Byte>
    // to avoid creating one Node object per byte (which caused OOM with 7.7M nodes)
    private val readChunks = ArrayDeque<ByteArray>()
    private var currentChunk: ByteArray? = null
    private var currentOffset = 0
    // Counts the full backing-array size of every retained chunk. A chunk remains retained while
    // currentChunk points at it, even after a partial read has consumed some of its contents.
    private var bufferedReadBytes = 0L
    private var peakBufferedReadBytes = 0L
    private var readsPaused = false
    private var readPauseGeneration: Long? = null
    private var pauseCount = 0L
    private var terminalReadFailure: RelayException? = null
    // S1 owns this prefix until admission succeeds and body consumption starts. Close handlers
    // inspect it to distinguish a complete buffered frame from a body that can never finish.
    private var pendingFrameLength: Int? = null
    private var messageReader: Thread? = null
    private val messageReaderWaiters = HashSet<java.util.concurrent.CountDownLatch>()
    private val readLock = ReentrantLock()
    private val dataAvailable = readLock.newCondition()
    private val receiveWindowControl: RelayYamuxReceiveWindowControl?

    init {
        configureRelayWriteBackpressure(stream)
        receiveWindowControl = installRelayYamuxReceiveWindowControl(stream)
        stream.pushHandler(object : SimpleChannelInboundHandler<ByteBuf>() {
            override fun channelRead0(ctx: ChannelHandlerContext, msg: ByteBuf) {
                val incomingBytes = msg.readableBytes().toLong()
                var overflow: RelayException? = null
                readLock.withLock {
                    if (closed.get()) return@withLock

                    val projectedBytes = bufferedReadBytes + incomingBytes
                    if (projectedBytes > MAX_BUFFERED_READ_BYTES) {
                        val retainedBytesAtOverflow = bufferedReadBytes
                        closed.set(true)
                        readsPaused = false
                        readPauseGeneration = null
                        pendingFrameLength = null
                        readChunks.clear()
                        currentChunk = null
                        currentOffset = 0
                        bufferedReadBytes = 0L
                        terminalReadFailure = RelayException(
                            "Relay stream inbound buffer exceeded its " +
                                "$MAX_BUFFERED_READ_BYTES-byte capacity: retained " +
                                "$retainedBytesAtOverflow bytes and received $incomingBytes more; " +
                                "closing the stream"
                        )
                        parseBudgetCancellation.cancel()
                        dataAvailable.signalAll()
                        overflow = terminalReadFailure
                    } else {
                        val bytes = ByteArray(incomingBytes.toInt())
                        msg.readBytes(bytes)
                        // Add the entire chunk, not individual bytes.
                        readChunks.addLast(bytes)
                        bufferedReadBytes = projectedBytes
                        peakBufferedReadBytes = maxOf(peakBufferedReadBytes, bufferedReadBytes)
                        if (!readsPaused && bufferedReadBytes >= READ_PAUSE_THRESHOLD_BYTES) {
                            val generation = receiveWindowControl?.pause()
                            if (generation != null) {
                                readsPaused = true
                                readPauseGeneration = generation
                                pauseCount += 1L
                            }
                        }
                        dataAvailable.signalAll()
                    }
                }

                overflow?.let { failure ->
                    debugLogErr { "[RELAY] $failure" }
                    var closeFailure: Throwable? = null
                    try {
                        fireCloseListeners()
                    } catch (listenerFailure: Throwable) {
                        closeFailure = listenerFailure
                    }
                    responseEnded.completeExceptionally(failure)
                    try {
                        receiveWindowControl?.close()
                    } catch (cleanupFailure: Throwable) {
                        closeFailure = combineCloseFailures(closeFailure, cleanupFailure)
                    }
                    try {
                        ctx.close()
                    } catch (cleanupFailure: Throwable) {
                        closeFailure = combineCloseFailures(closeFailure, cleanupFailure)
                    }
                    closeFailure?.let { throw it }
                }
            }

            override fun channelInactive(ctx: ChannelHandlerContext) {
                readLock.withLock {
                    closed.set(true)
                    readsPaused = false
                    readPauseGeneration = null
                    // Complete buffered bodies still need admission. An incomplete body cannot
                    // gain more bytes after this event, so wake its separate admission wait now.
                    if (pendingFrameLength?.let { calculateAvailable() < it } == true) {
                        pendingFrameLength = null
                        readChunks.clear()
                        currentChunk = null
                        currentOffset = 0
                        bufferedReadBytes = 0L
                        parseBudgetCancellation.cancel()
                    }
                    dataAvailable.signalAll()
                }
                var closeFailure: Throwable? = null
                try {
                    fireCloseListeners()
                } catch (listenerFailure: Throwable) {
                    closeFailure = listenerFailure
                }
                responseEnded.completeExceptionally(RelayException("Relay stream response path closed"))
                try {
                    receiveWindowControl?.close()
                } catch (cleanupFailure: Throwable) {
                    closeFailure = combineCloseFailures(closeFailure, cleanupFailure)
                }
                closeFailure?.let { throw it }
            }

            override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
                readLock.withLock {
                    closed.set(true)
                    readsPaused = false
                    readPauseGeneration = null
                    pendingFrameLength = null
                    readChunks.clear()
                    currentChunk = null
                    currentOffset = 0
                    bufferedReadBytes = 0L
                    if (terminalReadFailure == null) {
                        terminalReadFailure = if (cause is RelayException) cause else RelayException(
                            "Relay stream reader failed: " +
                                (cause.message ?: cause::class.java.simpleName),
                            cause,
                        )
                    }
                    parseBudgetCancellation.cancel()
                    dataAvailable.signalAll()
                }
                var closeFailure: Throwable? = null
                try {
                    fireCloseListeners()
                } catch (listenerFailure: Throwable) {
                    closeFailure = listenerFailure
                }
                responseEnded.completeExceptionally(RelayException("Relay stream response path closed"))
                try {
                    receiveWindowControl?.close()
                } catch (cleanupFailure: Throwable) {
                    closeFailure = combineCloseFailures(closeFailure, cleanupFailure)
                }
                debugLogErr {
                    "[RELAY] Relay stream reader failed: ${cause.message ?: cause::class.java.simpleName}"
                }
                try {
                    ctx.close()
                } catch (cleanupFailure: Throwable) {
                    closeFailure = combineCloseFailures(closeFailure, cleanupFailure)
                }
                closeFailure?.let { throw it }
            }
        })
    }

    /**
     * Registers a lightweight callback for the first close transition of this stream. If the
     * transition already happened, the callback runs immediately outside the listener lock.
     */
    internal fun addCloseListener(listener: () -> Unit) {
        val fireNow = synchronized(closeListenersLock) {
            if (closeListenersFired) {
                true
            } else {
                closeListeners.add(listener)
                false
            }
        }
        if (fireNow) invokeCloseListener(listener)
    }

    private fun fireCloseListeners() {
        val listeners = synchronized(closeListenersLock) {
            if (closeListenersFired) return
            closeListenersFired = true
            val snapshot = closeListeners.toList()
            closeListeners.clear()
            snapshot
        }
        var firstFailure: Throwable? = null
        listeners.forEach { listener ->
            try {
                invokeCloseListener(listener)
            } catch (failure: Throwable) {
                firstFailure = combineCloseFailures(firstFailure, failure)
            }
        }
        firstFailure?.let { throw it }
    }

    private fun invokeCloseListener(listener: () -> Unit) {
        try {
            listener()
        } catch (failure: Throwable) {
            debugLogErr {
                "[RELAY] Relay stream close listener failed: " +
                    (failure.message ?: failure::class.java.simpleName)
            }
            throw failure
        }
    }

    private fun combineCloseFailures(existing: Throwable?, failure: Throwable): Throwable {
        if (existing != null) {
            if (existing !== failure) existing.addSuppressed(failure)
            return existing
        }
        return failure
    }

    override fun isClosed(): Boolean = closed.get()

    /**
     * Whether a request written on this stream could still have its response read back.
     *
     * [isClosed] answers a weaker question: whether this controller has already OBSERVED a close
     * through `channelInactive`/`exceptionCaught`. Inbound-substream admission control keeps one
     * controlled physical read pending while automatic reads are paused, so peer departure remains
     * observable (see [inboundReadsPausedByAdmission]). But that root is at its admission boundary:
     * another excess inbound stream can shed it and abort work already in flight. Committing a new
     * request there would therefore choose a transport that is deliberately eligible for closure.
     *
     * So this asks the transport, and treats "admission-held" as "cannot use": the stream's own
     * channel and the physical root connection beneath it must both still be active, and that root
     * must not be one whose automatic reads are currently held by admission control. A non-Netty
     * transport exposes no channel to interrogate, so it falls back to the close flag.
     */
    internal fun canCarryResponse(): Boolean {
        if (closed.get()) return false
        val channel = streamAsChannel(stream) ?: return true
        if (!channel.isActive) return false
        val root = libp2pRootConnectionChannel(channel)
        if (!root.isActive) return false
        return !inboundReadsPausedByAdmission(root)
    }

    /**
     * Whether no response can arrive because the stream or physical connection is terminal.
     * Temporary inbound-admission pauses are deliberately excluded: they are live transport
     * failures that callers must observe, not evidence that remote close cleanup already owns the
     * operation.
     */
    internal fun responsePathIsGone(): Boolean {
        if (closed.get()) return true
        val channel = streamAsChannel(stream) ?: return false
        if (!channel.isActive) return true
        return !libp2pRootConnectionChannel(channel).isActive
    }

    /**
     * Returns the retained inbound relay data and its flow-control state. [currentBytes] counts the
     * full backing-array size of every retained chunk until that chunk is fully consumed.
     * Reading this snapshot does not consume bytes or change stream flow control.
     */
    fun readBufferSnapshot(): RelayReadBufferSnapshot = readLock.withLock {
        RelayReadBufferSnapshot(
            currentBytes = bufferedReadBytes,
            peakBytes = peakBufferedReadBytes,
            readsPaused = readsPaused,
            pauseCount = pauseCount,
        )
    }

    /** Unread bytes; the retained-byte counter includes the consumed part of the current array. */
    private fun calculateAvailable(): Long = bufferedReadBytes - currentOffset

    private fun maybeResumeReadsLocked() {
        if (!readsPaused || closed.get() || bufferedReadBytes > READ_RESUME_THRESHOLD_BYTES) return
        val generation = readPauseGeneration ?: return
        readsPaused = false
        readPauseGeneration = null
        receiveWindowControl?.resume(generation)
    }

    internal fun rootConnectionChannel(): io.netty.channel.Channel? {
        val channel = streamAsChannel(stream) ?: return null
        return libp2pRootConnectionChannel(channel)
    }

    /** Returns false for local admission refusal; a closed response path remains an error. */
    internal fun sendKeepalivePing(ping: RelayProtocol.RelayPing): Boolean {
        if (closed.get()) throw RelayException("Stream closed")
        // Bulk replies can exhaust only the Yamux child's send window. A small keepalive may
        // join its bounded queue while the physical root remains writable and can read the pong.
        val admitted = writeRelayKeepaliveWhileResponseObservable(
            stream, framedRelayJsonBuffer(ping.toJson()), WRITE_BACKPRESSURE_WAIT_MS,
        )
        if (!admitted && responsePathIsGone()) throw RelayException("Stream closed")
        return admitted
    }

    override fun sendMessage(json: JSONObject) {
        if (closed.get()) throw RelayException("Stream closed")

        if (!sendMessage(json, WRITE_BACKPRESSURE_WAIT_MS)) {
            throw RelayException(relayMessageNotAdmittedMessage(WRITE_BACKPRESSURE_WAIT_MS))
        }
    }

    /**
     * Attempts to admit [json] to the real relay transport, waiting at most
     * [maxAdmissionWaitMs] for the stream and its parent connection to become writable.
     *
     * Returns `true` only after the complete length-prefixed frame has been handed to Netty.
     * Returns `false` when the stream is closed, the per-connection parked-write budget is
     * exhausted, or transport backpressure persists through the caller's finite budget. This is
     * admission rather than remote acknowledgement; after `true`, [close] is the ordered flush
     * barrier for a caller that is shutting down. The budget must be non-negative, so this API never
     * introduces unbounded blocking.
     *
     * @throws org.json.JSONException if [json] cannot be serialized. Serialization previously went
     *   through `JSONObject.toString()`, which returns `null` on failure and surfaced here as a
     *   `NullPointerException` naming nothing.
     */
    fun sendMessage(json: JSONObject, maxAdmissionWaitMs: Long): Boolean {
        requireValidRelayAdmissionWait(maxAdmissionWaitMs)
        if (closed.get()) return false

        val bytes = jsonWireBytes(json)
        val buf = Unpooled.buffer(4 + bytes.size)
        buf.writeInt(bytes.size)
        buf.writeBytes(bytes)
        return writeRelayRequestWhileResponseObservable(stream, buf, maxAdmissionWaitMs)
    }

    /**
     * Admits one already-framed immutable message, producing the same wire bytes as
     * [sendMessage] for the same content. This exists so a caller that offers one prepared frame to
     * many destinations - or re-offers it to a single still-unwritable destination once per poll
     * round inside a shared admission budget - serializes the message once instead of once per
     * attempt. Ownership of [buf] transfers to this call on every outcome.
     */
    internal fun sendFramedMessage(buf: ByteBuf, maxAdmissionWaitMs: Long): Boolean {
        requireValidRelayAdmissionWait(maxAdmissionWaitMs)
        if (closed.get()) {
            buf.release()
            return false
        }
        return writeRelayRequestWhileResponseObservable(stream, buf, maxAdmissionWaitMs)
    }

    /**
     * Sends a request/reply whose remote peer is actively awaiting delivery. Unlike the default
     * 200 ms best-effort admission path, this rides out a transient transport stall for the same
     * bounded five-second window as server-side relay replies, then throws if admission still fails.
     */
    internal fun sendMessageAwaitingDelivery(json: JSONObject) {
        if (closed.get()) throw RelayException("Stream closed")
        configureRelayWriteBackpressure(stream)
        val bytes = jsonWireBytes(json)
        val buf = Unpooled.buffer(4 + bytes.size)
        buf.writeInt(bytes.size)
        buf.writeBytes(bytes)
        if (!writeAwaitedRelayBufferWithBackpressure(stream, buf, WRITE_BACKPRESSURE_DELIVERY_WAIT_MS)) {
            throw RelayException(
                "Relay awaited request/reply write dropped: connection to peer unwritable after " +
                    "${WRITE_BACKPRESSURE_DELIVERY_WAIT_MS}ms delivery wait " +
                    "(park budget exhausted or connection wedged)"
            )
        }
    }

    internal fun sendResponseWithOutbox(
        json: JSONObject,
        failureReservation: AwaitedResponseFailureReservation?,
        completion: ((Throwable?) -> Unit)? = null,
        registeredClose: Boolean = false,
    ): AwaitedResponseWriteOutcome {
        if (closed.get()) {
            failureReservation?.close()
            return AwaitedResponseWriteOutcome.CONNECTION_CLOSED
        }
        configureRelayWriteBackpressure(stream)
        return writeAwaitedResponseWithOutbox(
            stream,
            framedRelayJsonBuffer(json),
            failureReservation,
            completion,
            registeredClose,
        )
    }

    internal fun enqueueRegistrationBoundary(json: JSONObject, completion: (Throwable?) -> Unit) {
        configureRelayWriteBackpressure(stream)
        enqueueRelayRegistrationBoundary(stream, framedRelayJsonBuffer(json), completion)
    }

    internal fun tryReserveResponseFailure(
        outboxFullSignal: JSONObject,
    ): AwaitedResponseFailureReservation? {
        if (closed.get()) return null
        configureRelayWriteBackpressure(stream)
        return tryReserveAwaitedResponseFailureSignal(stream) {
            framedRelayJsonBuffer(outboxFullSignal)
        }
    }

    internal fun trySendRegisteredRequestRefusal(json: JSONObject): Boolean {
        if (closed.get()) return false
        configureRelayWriteBackpressure(stream)
        return tryWriteRelayRefusalWithOutbox(stream, framedRelayJsonBuffer(json))
    }

    internal suspend fun reserveResponseFailure(
        outboxFullSignal: JSONObject,
    ): AwaitedResponseFailureReservation? {
        if (closed.get()) return null
        configureRelayWriteBackpressure(stream)
        return reserveAwaitedResponseFailureSignal(stream) {
            framedRelayJsonBuffer(outboxFullSignal)
        }
    }

    fun readMessage(timeout: Long, unit: TimeUnit): JSONObject? =
        readMessage(timeout, unit, SystemClock())

    /** Uses one caller-owned clock for prefix, admission, and body deadlines. */
    fun readMessage(timeout: Long, unit: TimeUnit, clock: Clock): JSONObject? {
        val durationMs = unit.toMillis(timeout)
        val deadline = saturatedReadDeadline(clock.currentTimeMillis(), durationMs)
        return readMessageWithBudget(MessageReadBudget(deadline, durationMs, deadline, clock, false))
    }

    /**
     * Uses [idleTimeout] for first-byte and parse-memory waiting while the read is resumable.
     * Partial prefixes and bodies each use [frameTimeout] once their first byte is consumed.
     * [operationDeadlineMs] caps all waits in [clock] time. Admission expiry retains the prefix.
     * Expiry after partial byte consumption closes the stream and reports frame progress.
     */
    fun readMessage(
        idleTimeout: Long,
        frameTimeout: Long,
        unit: TimeUnit,
        clock: Clock = SystemClock(),
        operationDeadlineMs: Long = Long.MAX_VALUE,
    ): JSONObject? {
        require(idleTimeout >= 0L && frameTimeout >= 0L) {
            "Read budgets must be nonnegative, but idleTimeout=$idleTimeout and frameTimeout=$frameTimeout $unit"
        }
        val idleDeadline = minOf(
            saturatedReadDeadline(clock.currentTimeMillis(), unit.toMillis(idleTimeout)),
            operationDeadlineMs,
        )
        return readMessageWithBudget(MessageReadBudget(
            idleDeadline, unit.toMillis(frameTimeout), operationDeadlineMs, clock, true,
            pollBufferedFrame = unit.toMillis(idleTimeout) == 0L,
        ))
    }

    private fun readMessageWithBudget(budget: MessageReadBudget): JSONObject? {
        val clock = budget.clock
        check(readLock.withLock { messageReader !== Thread.currentThread() }) {
            "A message read cannot re-enter the same stream"
        }
        while (true) {
            val wake = java.util.concurrent.CountDownLatch(1)
            val acquired = readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled()) return null
                if (messageReader == null) {
                    messageReader = Thread.currentThread()
                    true
                } else {
                    messageReaderWaiters.add(wake)
                    false
                }
            }
            if (acquired) break
            parseBudgetCancellation.register(wake)
            var task: community.kotlin.clocks.simple.Scheduled? = null
            try {
                val remaining = remainingReadWaitMillis(budget.idleDeadlineMs, clock.currentTimeMillis())
                if (remaining <= 0L) return null
                // Wall-clock expiry uses the latch's timed wait so it cannot depend on a
                // shared timer callback. Injected clocks instead wake on explicit advancement.
                if (clock is SystemClock) wake.await(remaining, TimeUnit.MILLISECONDS)
                else {
                    task = clock.schedule(budget.idleDeadlineMs) { wake.countDown() }
                    if (clock.currentTimeMillis() < budget.idleDeadlineMs) wake.await()
                }
                readLock.withLock {
                    terminalReadFailure?.let { throw it }
                    if (parseBudgetCancellation.isCancelled()) return null
                }
                if (clock.currentTimeMillis() >= budget.idleDeadlineMs) return null
            } catch (failure: InterruptedException) {
                Thread.currentThread().interrupt()
                return null
            } finally {
                readLock.withLock { messageReaderWaiters.remove(wake) }
                parseBudgetCancellation.unregister(wake)
                task?.let(clock::unschedule)
            }
        }
        try {
            return readOwnedMessage(budget)
        } finally {
            readLock.withLock {
                messageReader = null
                messageReaderWaiters.forEach { it.countDown() }
            }
        }
    }

    private fun readOwnedMessage(budget: MessageReadBudget): JSONObject? {
        val clock = budget.clock
        val resumedLength = readLock.withLock {
            terminalReadFailure?.let { throw it }
            if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
            pendingFrameLength
        }
        val length = resumedLength ?: run {
            val lengthBytes = readBytes(4, budget) ?: return null
            ((lengthBytes[0].toInt() and 0xFF) shl 24) or
                ((lengthBytes[1].toInt() and 0xFF) shl 16) or
                ((lengthBytes[2].toInt() and 0xFF) shl 8) or
                (lengthBytes[3].toInt() and 0xFF)
        }
        if (length <= 0 || length > 10_000_000) {
            throw RelayException("Invalid message length: $length")
        }

        readLock.withLock {
            terminalReadFailure?.let { throw it }
            if (parseBudgetCancellation.isCancelled()) return null
            if (closed.get() && calculateAvailable() < length) {
                pendingFrameLength = null
                currentChunk = null
                currentOffset = 0
                readChunks.clear()
                bufferedReadBytes = 0L
                parseBudgetCancellation.cancel()
                return null
            }
            // Publish before checking interruption: even a first call already consumed its
            // prefix. Every admission exit now leaves the same owned frame in S1.
            pendingFrameLength = length
            if (Thread.currentThread().isInterrupted) return null
        }
        budget.bodyLength = length
        val admissionStartedAt = if (budget.reportFrameExpiry) clock.currentTimeMillis() else null
        val admissionStartedBeforeDeadline = admissionStartedAt != null && admissionStartedAt < budget.idleDeadlineMs
        val beforeAdmissionExpiry = readLock.withLock {
            terminalReadFailure?.let { throw it }
            if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
            messageAdmissionFrameExpiry(budget, admissionStartedAt, calculateAvailable())
        }
        if (beforeAdmissionExpiry != null) {
            val failure = RelayException(beforeAdmissionExpiry)
            endStreamForAbandonedFrame(failure)
            throw failure
        }
        val permits = try {
            Libp2pRpcProtocol.acquireParseBudgetUntilClosed(
                length, budget.idleDeadlineMs, clock, parseBudgetCancellation,
            )
                ?: return readLock.withLock {
                    terminalReadFailure?.let { throw it }
                    null
                }
        } catch (e: ParseBudgetDeadlineExceededException) {
            val admissionExpiry = readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled() || Thread.currentThread().isInterrupted) return null
                val admissionFailedAt = if (budget.reportFrameExpiry) clock.currentTimeMillis() else null
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled() || Thread.currentThread().isInterrupted) return null
                messageAdmissionFrameExpiry(budget, admissionFailedAt, calculateAvailable())
            }
            if (admissionExpiry != null) {
                val failure = RelayException(admissionExpiry)
                endStreamForAbandonedFrame(failure)
                throw failure
            }
            throw RelayParseBudgetDeadlineException(
                "Failed while waiting for inbound relay parse-memory budget: ${e.message}", e,
            )
        } catch (e: IOException) {
            readLock.withLock { terminalReadFailure?.let { throw it } }
            if (e.cause is InterruptedException) return null
            throw RelayException("Failed while waiting for inbound relay parse-memory budget: ${e.message}", e)
        }
        try {
            val admissionExpiry = readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
                val admissionReturnedAt = if (budget.reportFrameExpiry) clock.currentTimeMillis() else null
                terminalReadFailure?.let { throw it }
                if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) return null
                // Frame expiry wins over an idle-only admission miss for an incomplete frame.
                messageAdmissionFrameExpiry(budget, admissionReturnedAt, calculateAvailable())
                    ?.let { return@withLock it }
                // Check after admission's clock cleanup, before consuming a body byte. A grant
                // exactly at expiry may finish a complete buffered message; every later grant
                // leaves the retained prefix available to the next poll. A partial prefix that
                // completed past idle expiry may still take an immediate, non-waiting grant.
                if (admissionReturnedAt != null && (admissionReturnedAt >= budget.operationDeadlineMs ||
                    (admissionStartedBeforeDeadline && (admissionReturnedAt > budget.idleDeadlineMs ||
                        (admissionReturnedAt == budget.idleDeadlineMs && calculateAvailable() < length))))) {
                    val expiry = Libp2pRpcProtocol.parseBudgetAdmissionExpired(length)
                    throw RelayParseBudgetDeadlineException(
                        "Failed while waiting for inbound relay parse-memory budget: ${expiry.message}", expiry,
                    )
                }
                // Keep the prefix until the first body copy. A clock failure or close before
                // that copy must not lose the length of an otherwise untouched body.
                null
            }
            if (admissionExpiry != null) {
                val failure = RelayException(admissionExpiry)
                endStreamForAbandonedFrame(failure)
                throw failure
            }
            beginMessageBodyWait(budget)
            val bodyBytes = readBytes(length, budget) ?: run {
                readLock.withLock {
                    terminalReadFailure?.let { throw it }
                    // A partial read became terminal inside readBytes. With no consumed body
                    // bytes, the same prefix can instead be resumed by the next call.
                    if (closed.get() && calculateAvailable() < length) {
                        pendingFrameLength = null
                        readChunks.clear()
                        currentChunk = null
                        currentOffset = 0
                        bufferedReadBytes = 0L
                        parseBudgetCancellation.cancel()
                    } else if (!parseBudgetCancellation.isCancelled()) pendingFrameLength = length
                }
                return null
            }
            val parsed = try {
                Libp2pRpcProtocol.parseValidatedJsonBody(bodyBytes)
            } catch (e: IOException) {
                throw RelayException("Refused inbound relay message: ${e.message}", e)
            }
            readLock.withLock {
                terminalReadFailure?.let { throw it }
                if (parseBudgetCancellation.isCancelled()) return null
                if (!Thread.currentThread().isInterrupted) return parsed
            }
            // Interruption during parsing abandons a frame whose bytes this call consumed. The
            // stream ends, exactly as for an interruption after the final copy: a later reader
            // must not silently receive the following frame in its place.
            endStreamForAbandonedFrame(null)
            return null
        } finally {
            Libp2pRpcProtocol.releaseParseBudget(permits)
        }
    }

    /**
     * Ends the stream after a read abandons a consumed frame, closing the transport only from the
     * call that performed the transition. A close failure is attached to [readFailure] when the
     * read already failed; otherwise it is the call's result, on every abandonment path alike.
     */
    private fun endStreamForAbandonedFrame(readFailure: Throwable?) {
        if (!abandonConsumedFrame()) return
        try {
            stream.close()
        } catch (closeFailure: Throwable) {
            if (readFailure == null) throw closeFailure
            if (readFailure !== closeFailure) readFailure.addSuppressed(closeFailure)
        }
    }

    /**
     * Ends the stream after a read abandons bytes it consumed (a partial frame, or a complete
     * frame refused after its copy). Returns true when this call is the one that closed it.
     */
    private fun abandonConsumedFrame(): Boolean = readLock.withLock {
        // Partial body storage belongs to this call's parse reservation. It cannot be
        // retained after releasing that reservation, nor treated as a fresh prefix.
        val newlyClosed = !closed.getAndSet(true)
        pendingFrameLength = null
        readChunks.clear()
        currentChunk = null
        currentOffset = 0
        bufferedReadBytes = 0L
        readsPaused = false
        readPauseGeneration = null
        parseBudgetCancellation.cancel()
        dataAvailable.signalAll()
        newlyClosed
    }

    private fun readBytes(count: Int, budget: MessageReadBudget): ByteArray? {
        val clock = budget.clock
        val result = ByteArray(count)
        var read = 0

        var readFailure: Throwable? = null
        var expiredAfterCopy = false
        try {
            readLock.withLock {
                terminalReadFailure?.let { throw it }
                while (read < count && !Thread.currentThread().isInterrupted) {
                    terminalReadFailure?.let { throw it }
                    // Once copying starts, buffered tail bytes cannot bypass the frame deadline.
                    // Admission's separate grant-at-expiry decision has already been settled.
                    if (budget.reportFrameExpiry && !messageReadCanConsumeBytes(budget)) break
                    // Try to read from current chunk
                    val chunk = currentChunk
                    if (chunk != null && currentOffset < chunk.size) {
                        val available = chunk.size - currentOffset
                        val toRead = minOf(available, count - read)
                        beginMessageByteCopy(budget)
                        terminalReadFailure?.let { throw it }
                        if (Thread.currentThread().isInterrupted || parseBudgetCancellation.isCancelled()) break
                        // Once body bytes are consumed this invocation owns them. Remote close
                        // must no longer compare the full length against only the remaining tail.
                        if (budget.bodyLength != null) pendingFrameLength = null
                        System.arraycopy(chunk, currentOffset, result, read, toRead)
                        currentOffset += toRead
                        read += toRead
                        // If chunk exhausted, clear it
                        if (currentOffset >= chunk.size) {
                            // The backing array is retained until the chunk object itself is released;
                            // partial reads must not make flow-control credit or the memory ceiling
                            // believe that the remaining array has already been freed.
                            bufferedReadBytes -= chunk.size.toLong()
                            currentChunk = null
                            currentOffset = 0
                        }
                        maybeResumeReadsLocked()
                    } else if (readChunks.isNotEmpty()) {
                        // Move to next chunk
                        currentChunk = readChunks.removeFirst()
                        currentOffset = 0
                    } else if (closed.get()) {
                        // A clean close ends the stream only after its buffered bytes are drained.
                        break
                    } else {
                        val remaining = remainingReadWaitMillis(messageReadDeadline(budget), clock.currentTimeMillis())
                        if (remaining <= 0) break
                        if (parseBudgetCancellation.isCancelled()) break
                        try {
                            // A caller Clock can deliver bytes, failure or close while we read time.
                            // Re-check the condition under this lock before registering any wait.
                            if (calculateAvailable() > 0L || closed.get() || terminalReadFailure != null) continue
                            if (clock is SystemClock) {
                                dataAvailable.await(remaining.coerceAtMost(100), TimeUnit.MILLISECONDS)
                            } else {
                                val deadline = messageReadDeadline(budget)
                                val wake = clock.schedule(deadline) { readLock.withLock { dataAvailable.signalAll() } }
                                try {
                                    val beforeWait = clock.currentTimeMillis()
                                    if (beforeWait < deadline && calculateAvailable() == 0L &&
                                        !closed.get() && terminalReadFailure == null &&
                                        !parseBudgetCancellation.isCancelled()) {
                                        // Keep observing a Clock that starts failing without advancing.
                                        // The scheduled wake still ends this wait on Clock expiry.
                                        dataAvailable.await(remaining.coerceAtMost(100L), TimeUnit.MILLISECONDS)
                                    }
                                } finally { clock.unschedule(wake) }
                            }
                        } catch (e: InterruptedException) {
                            Thread.currentThread().interrupt()
                            break
                        }
                    }
                }
                terminalReadFailure?.let { throw it }
            }
            if (read == count && budget.reportFrameExpiry && budget.bodyLength != null) {
                // A complete array copy may cross the frame or operation deadline.
                expiredAfterCopy = !messageReadCanConsumeBytes(budget)
            }
        } catch (failure: Throwable) {
            readFailure = failure
        }

        // Interruption may arrive during the last buffered copy of a body. A complete byte count
        // alone cannot make an interrupted read deliver the frame. A complete length prefix is
        // different: the caller publishes it as the retained prefix before honoring interruption,
        // so the next read resumes the same frame instead of losing the stream.
        if (readFailure == null && read == count && !expiredAfterCopy &&
            (budget.bodyLength == null || !Thread.currentThread().isInterrupted)) return result
        if (read > 0 || (readFailure == null && budget.reportFrameExpiry && budget.bodyLength != null &&
            !Thread.currentThread().isInterrupted && clock.currentTimeMillis() >= messageReadDeadline(budget))) {
            endStreamForAbandonedFrame(readFailure)
            readFailure?.let { throw it }
            if (budget.reportFrameExpiry && !Thread.currentThread().isInterrupted &&
                (expiredAfterCopy || clock.currentTimeMillis() >= messageReadDeadline(budget))) {
                throw RelayException(messageFrameExpiryDescription(budget, read))
            }
        }
        readFailure?.let { throw it }
        return null
    }

    override fun close(flushTimeoutMs: Long): Boolean = closeTransport(flushTimeoutMs, false)

    internal fun closeAfterListenerFailure(): Boolean = closeTransport(0L, true)

    internal fun closeAfterDialFailure(reportFailure: (Throwable) -> Unit): Boolean =
        closeTransport(0L, true, reportFailure)

    private fun closeTransport(
        flushTimeoutMs: Long,
        retainStreamCloseFailure: Boolean,
        cleanupFailureReporter: ((Throwable) -> Unit)? = null,
    ): Boolean {
        val wasClosed = readLock.withLock {
            val alreadyClosed = closed.getAndSet(true)
            pendingFrameLength = null
            readChunks.clear()
            currentChunk = null
            currentOffset = 0
            bufferedReadBytes = 0L
            readsPaused = false
            readPauseGeneration = null
            parseBudgetCancellation.cancel()
            dataAvailable.signalAll()
            alreadyClosed
        }
        if (wasClosed) return true
        markRelaySenderClose(stream)
        // Notify before the bounded write-side flush. A close observer must not wait behind a
        // transport operation, because it is responsible for completing work that owns this
        // stream even when the listener thread is blocked elsewhere.
        var closeFailure: Throwable? = null
        try {
            fireCloseListeners()
        } catch (listenerFailure: Throwable) {
            if (cleanupFailureReporter != null) cleanupFailureReporter(listenerFailure)
            else closeFailure = listenerFailure
        }
        responseEnded.completeExceptionally(RelayException("Relay stream response path closed"))
        // Drain queued writes via [Stream.closeWrite] before closing the transport.
        // libp2p's [Stream.writeAndFlush] returns void — the underlying
        // ChannelFuture isn't exposed — so closeWrite is the per-stream flush barrier:
        // its CompletableFuture completes once every queued write has reached the wire
        // and the write side is half-closed. Netty preserves write ordering on a single
        // channel, so awaiting closeWrite is sufficient to guarantee every prior
        // sendMessage call has been delivered. The subsequent stream.close() handles the
        // read-side teardown.
        val flushed = try {
            stream.closeWrite().get(flushTimeoutMs, TimeUnit.MILLISECONDS)
            true
        } catch (_: TimeoutException) {
            false
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            cleanupFailureReporter?.invoke(interrupted)
            false
        } catch (flushFailure: Exception) {
            cleanupFailureReporter?.invoke(flushFailure)
            // closeWrite may already have been called or the stream may already be
            // half/fully torn down — treat as "nothing left to flush" rather than a
            // hard failure.
            false
        } catch (flushFailure: Error) {
            if (cleanupFailureReporter != null) cleanupFailureReporter(flushFailure)
            else {
                if (!retainStreamCloseFailure) throw flushFailure
                closeFailure = combineCloseFailures(closeFailure, flushFailure)
            }
            false
        }
        try {
            receiveWindowControl?.close()
        } catch (cleanupFailure: Throwable) {
            if (cleanupFailureReporter != null) cleanupFailureReporter(cleanupFailure)
            else closeFailure = combineCloseFailures(closeFailure, cleanupFailure)
        }
        try {
            val completion = stream.close()
            streamCloseCompletion = completion
            if (cleanupFailureReporter != null) completion.whenComplete { _, failure ->
                if (failure != null) cleanupFailureReporter(failure)
            }
        } catch (streamCloseFailure: Throwable) {
            // Preserve the historical best-effort stream teardown behavior. If a close observer
            // already failed, retain the transport failure as suppressed context without hiding
            // the observer failure from the caller.
            if (cleanupFailureReporter != null) cleanupFailureReporter(streamCloseFailure)
            else if (!retainStreamCloseFailure && streamCloseFailure is Error) throw streamCloseFailure
            else if (retainStreamCloseFailure || closeFailure != null) {
                // The close observer may signal this same listener before Stream.close runs.
                // Preserve its exact interruption cause with enough context to identify retirement.
                val reportedFailure = if (retainStreamCloseFailure && streamCloseFailure is InterruptedException) {
                    InterruptedException(
                        "Close of relay registration stream ${System.identityHashCode(stream)} " +
                            "was interrupted during retirement on thread '${Thread.currentThread().name}'."
                    ).apply { initCause(streamCloseFailure) }
                } else streamCloseFailure
                closeFailure = combineCloseFailures(closeFailure, reportedFailure)
            }
        }
        closeFailure?.let { throw it }
        return flushed
    }

    companion object {
        const val READ_PAUSE_THRESHOLD_BYTES: Long = 64L * 1024L
        const val READ_RESUME_THRESHOLD_BYTES: Long = 32L * 1024L
        const val MAX_BUFFERED_READ_BYTES: Long = 1024L * 1024L
    }
}

/**
 * Exception thrown by relay operations.
 */
open class RelayException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    // Forwarding can return this stored detail without calling a subclass's supplied getter.
    internal val transportMessage: String? get() = super.message

    private companion object {
        /** Preserve the pre-subclassing Java-serialization identity for cross-process callers. */
        private const val serialVersionUID: Long = 8005359785291165575L
    }
}

/**
 * Snapshot of a [RelayService]'s bounded dial capacity. See [RelayService.dialCapacity].
 */
data class RelayDialCapacitySnapshot(
    val inFlightDials: Int,
    val maxInFlightDials: Int,
    val inlineDialFallbacks: Long
)

/** Reports an admission miss during a registered relay listener's idle poll. */
class RelayParseBudgetDeadlineWarningEffect(
    val relayPeerId: String,
    cause: RelayParseBudgetDeadlineException
) : NotificationEffect(
    "Relay listener for peer '$relayPeerId' could not admit an inbound frame during its poll; " +
        "registration remains active. ${cause.message}",
    MessageSeverity.WARNING,
    cause
)

private fun reportRelayParseBudgetDeadline(
    relayPeerId: String,
    failure: RelayParseBudgetDeadlineException,
    callerRepository: EffectHandlerRepository?
) {
    val effect = RelayParseBudgetDeadlineWarningEffect(relayPeerId, failure)
    if (callerRepository == null) {
        toss(effect)
        return
    }
    synchronized(callerRepository) {
        val workerRepository = `$effectHandlerRepository`.get()
        `$effectHandlerRepository`.set(callerRepository)
        try {
            try {
                toss(effect)
            } catch (deliveryFailure: Exception) {
                // A reporting callback must not end the listener that owns the registration.
                // Errors (for example OutOfMemoryError) are not callback failures and propagate.
                // Report the callback failure without invoking the same handler again: the
                // fallback notice is tossed with no handler repository, so it reaches only the
                // effects runtime's unhandled-notification output (stdout), never a caller handler.
                val interrupted = deliveryFailure is InterruptedException ||
                    Thread.currentThread().isInterrupted
                val detail = if (deliveryFailure is InterruptedException) {
                    "listener thread interrupted during warning delivery"
                } else {
                    deliveryFailure.message ?: "warning handler failed without a message"
                }
                `$effectHandlerRepository`.set(null)
                try {
                    toss(NotificationEffect(
                        "Relay listener for peer '$relayPeerId' could not deliver its parse-budget " +
                            "deadline warning: $detail",
                        MessageSeverity.WARNING,
                        deliveryFailure,
                    ))
                } finally {
                    if (interrupted) Thread.currentThread().interrupt()
                }
            }
        } finally {
            `$effectHandlerRepository`.set(workerRepository)
        }
    }
}

/**
 * An inbound relay frame could not be admitted to the process-wide parse-memory budget before the
 * reading call's own deadline. The frame was never parsed and no budget is held. A reader whose
 * deadline is an idle poll window treats this like a poll that saw no message; a reader whose
 * deadline is a request budget reports it, because the message names the contention that consumed
 * the budget instead of leaving an unexplained stall at an outer deadline.
 */
class RelayParseBudgetDeadlineException(
    message: String,
    cause: Throwable? = null
) : RelayException(message, cause)

/**
 * A relay failure that occurred before any target handler could receive the request. Consumers may
 * safely re-resolve/reconnect and resend after this exception. Plain [RelayException] deliberately
 * remains delivery-ambiguous and must not trigger automatic retries of non-idempotent operations.
 */
class RelayRequestNotDispatchedException(
    message: String,
    cause: Throwable? = null
) : RelayException(message, cause)

/**
 * A caller-configured Clock failed during request-initiated relay dialing or probing. This is a
 * local request failure, not evidence for retrying a route. [cause] is the original Throwable;
 * adapters that preserve caller Clock failures should report that cause without reconnecting.
 * Later dial cleanup failures are suppressed on that original cause, including late completions.
 */
class RelayRequestClockException(message: String, cause: Throwable) : RelayException(message, cause)

/** A request already sent whose reply is awaited at most once, or abandoned unread. */
private interface RelayPendingReply {
    fun await(): RelayProtocol.RelayResponse
    fun abandon()
}

private class DirectRegisteredPeerUnavailableException(
    message: String,
    cause: Throwable? = null
) : Exception(message, cause)

sealed interface RelayWarningEffect {
    val message: String
}

/** Most recently published failed ordinary-gossip admission; local admission is not remote receipt. */
data class RelayOrdinaryGossipDeliveryFailureWarningEffect(
    val peerId: String,
    val messageId: String,
    val messageType: String,
    val failureClass: String,
    val failureMessage: String?,
) : RelayWarningEffect {
    override val message: String =
        "Ordinary gossip transport admission failed for peer $peerId, message $messageId " +
            "($messageType): $failureClass: ${failureMessage ?: "null"}"
}

data class RelayReceiveCallbackQueueOverflowWarningEffect(
    val relayPeerId: String,
    val messageType: String,
    val queuedCallbacks: Int,
    val maxQueuedCallbacksPerPeer: Int,
    val retainedBytes: Long,
    val maxRetainedBytesPerPeer: Long,
    val activePeerLanes: Int,
    val maxPeerLanes: Int,
    override val message: String,
) : RelayWarningEffect

private fun printRelayReceiveCallbackFailure(
    failure: Throwable,
    warning: RelayReceiveCallbackFailureWarningEffect,
) {
    try {
        failure.printStackTrace(System.err)
    } catch (renderingFailure: Throwable) {
        addRelayReceiveCallbackRenderingFailure(failure, renderingFailure)
        printRelayReceiveCallbackFailureFallback(failure, warning, renderingFailure)
    }
}

private fun addRelayReceiveCallbackRenderingFailure(
    failure: Throwable,
    renderingFailure: Throwable,
) {
    if (failure === renderingFailure) return
    if (failure.suppressed.none { it === renderingFailure }) {
        failure.addSuppressed(renderingFailure)
    }
}

private data class RelayReceiveCallbackFailureStackEntry(
    val failure: Throwable,
    val label: String,
)

private fun printRelayReceiveCallbackFailureFallback(
    failure: Throwable,
    warning: RelayReceiveCallbackFailureWarningEffect,
    renderingFailure: Throwable,
) {
    val renderingFailureDescription = if (renderingFailure === failure) {
        warning.failureMessage ?: "the original failure's description was not rendered again"
    } else {
        try {
            renderingFailure.message ?: "no message"
        } catch (messageFailure: Throwable) {
            addRelayReceiveCallbackRenderingFailure(failure, messageFailure)
            "message could not be rendered (${messageFailure.javaClass.name})"
        }
    }

    val output = System.err
    output.println("Relay receive callback failure: ${warning.message}")
    output.println(
        "Stack rendering also failed with ${renderingFailure.javaClass.name}: " +
            renderingFailureDescription,
    )
    val pending = java.util.ArrayDeque<RelayReceiveCallbackFailureStackEntry>()
    val visited = java.util.IdentityHashMap<Throwable, Boolean>()
    pending.addLast(RelayReceiveCallbackFailureStackEntry(failure, "Failure: "))

    while (pending.isNotEmpty()) {
        val entry = pending.removeLast()
        val current = entry.failure
        val className = current.javaClass.name
        if (visited.put(current, true) != null) {
            output.println("${entry.label}[CIRCULAR REFERENCE: $className]")
            continue
        }

        val description = when (current) {
            failure -> warning.failureMessage?.let { ": $it" }
                ?: ": message unavailable; see the relay warning above"
            renderingFailure -> ": $renderingFailureDescription"
            else -> ""
        }
        output.println("${entry.label}$className$description")

        val stackTrace = try {
            current.stackTrace
        } catch (stackTraceFailure: Throwable) {
            output.println("  Stack trace unavailable (${stackTraceFailure.javaClass.name}).")
            emptyArray()
        }
        stackTrace.forEach { output.println("\tat $it") }

        val suppressed = try {
            current.suppressed
        } catch (suppressedFailure: Throwable) {
            output.println("  Suppressed exceptions unavailable (${suppressedFailure.javaClass.name}).")
            emptyArray()
        }
        val cause = try {
            current.cause
        } catch (causeFailure: Throwable) {
            output.println("  Cause unavailable (${causeFailure.javaClass.name}).")
            null
        }

        if (cause != null) {
            pending.addLast(RelayReceiveCallbackFailureStackEntry(cause, "Caused by: "))
        }
        for (index in suppressed.indices.reversed()) {
            pending.addLast(
                RelayReceiveCallbackFailureStackEntry(suppressed[index], "Suppressed: "),
            )
        }
    }
}

private class RelayReceiveCallbackFailureDiagnostic(
    private val renderingWarning: RelayReceiveCallbackFailureWarningEffect,
    render: () -> RelayReceiveCallbackFailureWarningEffect,
) {
    private val renderingOnThread = ThreadLocal<Boolean>()
    private val completedWarning = lazy(LazyThreadSafetyMode.PUBLICATION, render)

    fun snapshot(): RelayReceiveCallbackFailureWarningEffect {
        if (renderingOnThread.get() == true) return renderingWarning
        renderingOnThread.set(true)
        return try {
            completedWarning.value
        } finally {
            renderingOnThread.remove()
        }
    }
}

data class RelayReceiveCallbackFailureWarningEffect(
    val relayPeerId: String,
    val messageType: String,
    val failureClass: String,
    val failureMessage: String?,
    override val message: String,
    val staleGeneration: Boolean = false,
) : RelayWarningEffect

/**
 * Reports a temporary relay-request file that could not be removed safely.
 *
 * [storageChargeRetained] is true while the process-wide temporary-storage ledger still owns the
 * file's declared capacity. A failed FileHandle close cannot be retried because Okio marks the
 * handle closed before invoking its filesystem close operation; later cleanup attempts therefore
 * report [closePreviouslyFailed] and keep both the path and its charge.
 */
data class RelayRequestTemporaryStorageCleanupWarningEffect(
    val path: String,
    val operation: String,
    val cleanupAttempt: Int,
    val failureClass: String,
    val failureMessage: String?,
    val closePreviouslyFailed: Boolean,
    val storageChargeRetained: Boolean,
    override val message: String,
) : RelayWarningEffect

data class RelayRequestHopLimitExceededWarningEffect(
    val requestId: String,
    val sourcePeerId: String,
    val targetPeerId: String,
    val localPeerId: String,
    override val message: String
) : RelayWarningEffect
