package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import io.libp2p.core.PeerId
import io.libp2p.core.StreamPromise
import io.libp2p.core.multiformats.Multiaddr

/**
 * Optional capability for Host adapters whose stream acquisition reads a Clock.
 *
 * RelayService supplies the Clock owned by the current dial, including request failure
 * observation. Use it for every acquisition Clock operation, including asynchronous work;
 * do not store it on the shared host or substitute the host's ordinary Clock. The host owns
 * its transports as usual. The caller retains ownership of the Clock.
 */
interface RelayStreamHost {
    fun <T> newStreamWithClock(
        protocols: List<String>, peer: PeerId, clock: Clock, vararg addresses: Multiaddr,
    ): StreamPromise<T>
}
