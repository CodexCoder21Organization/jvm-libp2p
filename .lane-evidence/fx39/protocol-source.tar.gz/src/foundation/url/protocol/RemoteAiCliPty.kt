package foundation.url.protocol

import org.json.JSONObject
import org.json.JSONArray
import java.io.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import kotlin.time.Duration

/**
 * Execution status of an AI CLI-backed PTY.
 * Mirrors the enum from tools.kotlin.aicligui.pty.AiCliExecutionStatus
 */
enum class RemoteAiCliExecutionStatus { BUSY, IDLE }

/**
 * Result of terminal rendering that includes plain text and cursor metadata.
 * Mirrors the data class from tools.kotlin.aicligui.pty.RenderedScreen
 */
data class RemoteRenderedScreen(
    val text: String,
    val cursorX: Int,
    val cursorY: Int,
    val cursorVisible: Boolean
)

/** Mirrors tools.kotlin.aicligui.pty.AiCliQuotaWindow */
enum class RemoteAiCliQuotaWindow { SESSION, FIVE_HOUR, DAILY, WEEKLY, MONTHLY, TOTAL, UNKNOWN }

/** Mirrors tools.kotlin.aicligui.pty.AiCliQuotaMetric */
data class RemoteAiCliQuotaMetric(
    val id: String,
    val displayName: String,
    val window: RemoteAiCliQuotaWindow,
    val model: String?,
    val unit: String,
    val totalQuantity: Double?,
    val usedQuantity: Double?,
    val remainingQuantity: Double?,
    val resetsAtEpochMillis: Long?,
    val resetsDescription: String?,
)

/** Mirrors tools.kotlin.aicligui.pty.AiCliQuotaStatus */
data class RemoteAiCliQuotaStatus(
    val supported: Boolean,
    val metrics: List<RemoteAiCliQuotaMetric>,
    val fetchedAtEpochMillis: Long,
    val rawText: String?,
    val errorMessage: String?,
)

/**
 * Remote implementation of AiCliPty that delegates all operations to a remote peer
 * over the libp2p RPC protocol.
 *
 * This class:
 * - Connects to a remote peer that serves the AiCliPty service
 * - Serializes method calls as RPC requests
 * - Handles AlgebraicEffects that need to be propagated back to the caller
 * - Manages observable subscriptions for status updates
 *
 * @property connection The active connection to the remote peer
 * @property effectHandler Handler for effects that come from the remote peer
 */
class RemoteAiCliPty(
    private val connection: RemotePtyConnection,
    private val effectHandler: RemoteEffectHandler? = null
) : AutoCloseable {

    private val closed = AtomicBoolean(false)
    private var invalidationHandler: (() -> Unit)? = null
    private val statusSubscribed = AtomicBoolean(false)

    /**
     * Start the PTY-backed process with the desired terminal size.
     */
    fun start(columns: Int = 120, rows: Int = 64) {
        checkNotClosed()
        val response = connection.sendRequest(
            "start",
            mapOf("columns" to columns, "rows" to rows)
        )
        handleResponse(response)
    }

    fun isAlive(): Boolean {
        if (closed.get()) return false
        return try {
            val response = connection.sendRequest("isAlive", emptyMap())
            response.result as? Boolean ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun renderScreen(columns: Int, rows: Int): String {
        checkNotClosed()
        val response = connection.sendRequest(
            "renderScreen",
            mapOf("columns" to columns, "rows" to rows)
        )
        handleResponse(response)
        return response.result as? String ?: ""
    }

    fun renderScreenWithCursor(columns: Int, rows: Int): RemoteRenderedScreen {
        checkNotClosed()
        val response = connection.sendRequest(
            "renderScreenWithCursor",
            mapOf("columns" to columns, "rows" to rows)
        )
        handleResponse(response)

        val result = response.result
        return when (result) {
            is JSONObject -> RemoteRenderedScreen(
                text = result.optString("text", ""),
                cursorX = result.optInt("cursorX", 0),
                cursorY = result.optInt("cursorY", 1),
                cursorVisible = result.optBoolean("cursorVisible", true)
            )
            is Map<*, *> -> RemoteRenderedScreen(
                text = result["text"] as? String ?: "",
                cursorX = (result["cursorX"] as? Number)?.toInt() ?: 0,
                cursorY = (result["cursorY"] as? Number)?.toInt() ?: 1,
                cursorVisible = result["cursorVisible"] as? Boolean ?: true
            )
            else -> RemoteRenderedScreen("", 0, 1, true)
        }
    }

    fun resize(columns: Int, rows: Int) {
        checkNotClosed()
        val response = connection.sendRequest(
            "resize",
            mapOf("columns" to columns, "rows" to rows)
        )
        handleResponse(response)
    }

    fun sendString(s: String) {
        checkNotClosed()
        val response = connection.sendRequest("sendString", mapOf("s" to s))
        handleResponse(response)
    }

    fun sendBytes(bytes: ByteArray) {
        checkNotClosed()
        // Encode bytes as base64 for JSON transmission
        val base64 = java.util.Base64.getEncoder().encodeToString(bytes)
        val response = connection.sendRequest("sendBytes", mapOf("bytesBase64" to base64))
        handleResponse(response)
    }

    fun sendEnter() {
        checkNotClosed()
        val response = connection.sendRequest("sendEnter", emptyMap())
        handleResponse(response)
    }

    fun sendBackspace() {
        checkNotClosed()
        val response = connection.sendRequest("sendBackspace", emptyMap())
        handleResponse(response)
    }

    fun sendTab() {
        checkNotClosed()
        val response = connection.sendRequest("sendTab", emptyMap())
        handleResponse(response)
    }

    fun sendCtrl(char: Char) {
        checkNotClosed()
        val response = connection.sendRequest("sendCtrl", mapOf("char" to char.toString()))
        handleResponse(response)
    }

    fun sendArrowUp() {
        checkNotClosed()
        val response = connection.sendRequest("sendArrowUp", emptyMap())
        handleResponse(response)
    }

    fun sendArrowDown() {
        checkNotClosed()
        val response = connection.sendRequest("sendArrowDown", emptyMap())
        handleResponse(response)
    }

    fun sendArrowRight() {
        checkNotClosed()
        val response = connection.sendRequest("sendArrowRight", emptyMap())
        handleResponse(response)
    }

    fun sendArrowLeft() {
        checkNotClosed()
        val response = connection.sendRequest("sendArrowLeft", emptyMap())
        handleResponse(response)
    }

    fun sendHome() {
        checkNotClosed()
        val response = connection.sendRequest("sendHome", emptyMap())
        handleResponse(response)
    }

    fun sendEnd() {
        checkNotClosed()
        val response = connection.sendRequest("sendEnd", emptyMap())
        handleResponse(response)
    }

    fun interrupt() {
        checkNotClosed()
        val response = connection.sendRequest("interrupt", emptyMap())
        handleResponse(response)
    }

    fun captureScreenFor(
        duration: Duration,
        columns: Int = 120,
        rows: Int = 64,
        mirrorRaw: Boolean = false
    ): String {
        checkNotClosed()
        val response = connection.sendRequest(
            "captureScreenFor",
            mapOf(
                "durationMs" to duration.inWholeMilliseconds,
                "columns" to columns,
                "rows" to rows,
                "mirrorRaw" to mirrorRaw
            )
        )
        handleResponse(response)
        return response.result as? String ?: ""
    }

    val status: RemoteAiCliExecutionStatus
        get() {
            checkNotClosed()
            val response = connection.sendRequest("getStatus", emptyMap())
            handleResponse(response)
            val statusStr = response.result as? String ?: "IDLE"
            // Handle unknown status values gracefully by defaulting to IDLE
            return try {
                RemoteAiCliExecutionStatus.valueOf(statusStr)
            } catch (e: IllegalArgumentException) {
                RemoteAiCliExecutionStatus.IDLE
            }
        }

    fun setOnInvalidation(handler: (() -> Unit)?) {
        invalidationHandler = handler

        if (handler != null && !statusSubscribed.getAndSet(true)) {
            // Subscribe to status updates from the remote
            connection.subscribeToInvalidations { timestamp ->
                invalidationHandler?.invoke()
            }
        } else if (handler == null && statusSubscribed.getAndSet(false)) {
            // Unsubscribe from status updates
            connection.unsubscribeFromInvalidations()
        }
    }

    fun sessionLogRecords(): List<Any> {
        if (closed.get()) return emptyList()
        return try {
            val response = connection.sendRequest("sessionLogRecords", emptyMap())
            handleResponse(response)
            when (val result = response.result) {
                is JSONArray -> {
                    (0 until result.length()).map { result.get(it) }
                }
                is List<*> -> result.filterNotNull()
                else -> emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getSessionId(): String? {
        if (closed.get()) return null
        return try {
            val response = connection.sendRequest("getSessionId", emptyMap())
            handleResponse(response)
            response.result as? String
        } catch (e: Exception) {
            null
        }
    }

    fun commandPreview(): String {
        if (closed.get()) return "[closed]"
        return try {
            val response = connection.sendRequest("commandPreview", emptyMap())
            handleResponse(response)
            response.result as? String ?: "[remote]"
        } catch (e: Exception) {
            "[remote]"
        }
    }

    fun persistSessionId(sessionId: String): Boolean {
        if (closed.get()) return false
        return try {
            val response = connection.sendRequest(
                "persistSessionId",
                mapOf("sessionId" to sessionId)
            )
            handleResponse(response)
            response.result as? Boolean ?: false
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getStandaloneResponse(prompt: String): String {
        checkNotClosed()
        // For suspend function, we need to handle it specially
        // The connection should support async requests
        val response = connection.sendRequestAsync("getStandaloneResponse", mapOf("prompt" to prompt))
        handleResponse(response)
        return response.result as? String ?: ""
    }

    fun getIdleDetectionDebugInfo(): Map<String, Any> {
        if (closed.get()) return emptyMap()
        return try {
            val response = connection.sendRequest("getIdleDetectionDebugInfo", emptyMap())
            handleResponse(response)
            when (val result = response.result) {
                is JSONObject -> {
                    result.keys().asSequence().associateWith { result.get(it) }
                }
                is Map<*, *> -> result.filterKeys { it is String }.mapKeys { it.key as String }
                    .filterValues { it != null }.mapValues { it.value!! }
                else -> emptyMap()
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun quotaStatus(): RemoteAiCliQuotaStatus {
        if (closed.get()) {
            return unsupportedQuotaStatus("Quota status unavailable: RemoteAiCliPty is closed")
        }

        return try {
            val response = connection.sendRequest("quotaStatus", emptyMap())
            handleResponse(response)
            parseQuotaStatus(response.result)
        } catch (e: Exception) {
            unsupportedQuotaStatus("Quota status unavailable: ${e.message ?: e::class.java.name}")
        }
    }

    override fun close() {
        if (closed.getAndSet(true)) return

        try {
            invalidationHandler = null
            connection.sendRequest("close", emptyMap())
        } catch (e: Exception) {
            // Ignore close errors
        } finally {
            connection.close()
        }
    }

    private fun parseQuotaStatus(result: Any?): RemoteAiCliQuotaStatus {
        return when (result) {
            is JSONObject -> {
                RemoteAiCliQuotaStatus(
                    supported = result.optBoolean("supported", false),
                    metrics = parseQuotaMetrics(result.opt("metrics")),
                    fetchedAtEpochMillis = result.nullableNumber("fetchedAtEpochMillis")?.toLong() ?: 0L,
                    rawText = jsonStringOrNull(result.opt("rawText")),
                    errorMessage = jsonStringOrNull(result.opt("errorMessage")),
                )
            }
            is Map<*, *> -> {
                RemoteAiCliQuotaStatus(
                    supported = result["supported"] as? Boolean ?: false,
                    metrics = parseQuotaMetrics(result["metrics"]),
                    fetchedAtEpochMillis = (result["fetchedAtEpochMillis"] as? Number)?.toLong() ?: 0L,
                    rawText = result["rawText"] as? String,
                    errorMessage = result["errorMessage"] as? String,
                )
            }
            else -> unsupportedQuotaStatus(
                "Quota status unavailable: expected quotaStatus result to be a JSONObject or Map, but was ${result?.javaClass?.name ?: "null"}"
            )
        }
    }

    private fun parseQuotaMetrics(value: Any?): List<RemoteAiCliQuotaMetric> {
        return when (value) {
            is JSONArray -> (0 until value.length()).mapNotNull { index ->
                parseQuotaMetric(value.opt(index))
            }
            is Iterable<*> -> value.mapNotNull { parseQuotaMetric(it) }
            is Array<*> -> value.mapNotNull { parseQuotaMetric(it) }
            else -> emptyList()
        }
    }

    private fun parseQuotaMetric(value: Any?): RemoteAiCliQuotaMetric? {
        return when (value) {
            is JSONObject -> RemoteAiCliQuotaMetric(
                id = value.optString("id", ""),
                displayName = value.optString("displayName", ""),
                window = parseQuotaWindow(jsonStringOrNull(value.opt("window"))),
                model = jsonStringOrNull(value.opt("model")),
                unit = value.optString("unit", ""),
                totalQuantity = value.nullableNumber("totalQuantity")?.toDouble(),
                usedQuantity = value.nullableNumber("usedQuantity")?.toDouble(),
                remainingQuantity = value.nullableNumber("remainingQuantity")?.toDouble(),
                resetsAtEpochMillis = value.nullableNumber("resetsAtEpochMillis")?.toLong(),
                resetsDescription = jsonStringOrNull(value.opt("resetsDescription")),
            )
            is Map<*, *> -> RemoteAiCliQuotaMetric(
                id = value["id"] as? String ?: "",
                displayName = value["displayName"] as? String ?: "",
                window = parseQuotaWindow(value["window"] as? String),
                model = value["model"] as? String,
                unit = value["unit"] as? String ?: "",
                totalQuantity = (value["totalQuantity"] as? Number)?.toDouble(),
                usedQuantity = (value["usedQuantity"] as? Number)?.toDouble(),
                remainingQuantity = (value["remainingQuantity"] as? Number)?.toDouble(),
                resetsAtEpochMillis = (value["resetsAtEpochMillis"] as? Number)?.toLong(),
                resetsDescription = value["resetsDescription"] as? String,
            )
            else -> null
        }
    }

    private fun parseQuotaWindow(value: String?): RemoteAiCliQuotaWindow {
        if (value == null) return RemoteAiCliQuotaWindow.UNKNOWN
        return try {
            RemoteAiCliQuotaWindow.valueOf(value)
        } catch (e: IllegalArgumentException) {
            RemoteAiCliQuotaWindow.UNKNOWN
        }
    }

    private fun jsonStringOrNull(value: Any?): String? {
        return if (value == null || value == JSONObject.NULL) null else value as? String
    }

    private fun JSONObject.nullableNumber(key: String): Number? {
        val value = opt(key)
        return if (value == null || value == JSONObject.NULL) null else value as? Number
    }

    private fun unsupportedQuotaStatus(errorMessage: String): RemoteAiCliQuotaStatus {
        return RemoteAiCliQuotaStatus(
            supported = false,
            metrics = emptyList(),
            fetchedAtEpochMillis = 0L,
            rawText = null,
            errorMessage = errorMessage,
        )
    }

    private fun checkNotClosed() {
        if (closed.get()) {
            throw IllegalStateException("RemoteAiCliPty is closed")
        }
    }

    private fun handleResponse(response: Libp2pRpcProtocol.RpcResponse) {
        val error = response.error
        if (error != null) {
            throw RemoteAiCliPtyException(
                error.code,
                error.message
            )
        }
    }
}

/**
 * Exception thrown when a remote AiCliPty operation fails.
 */
class RemoteAiCliPtyException(
    val code: String,
    override val message: String
) : RuntimeException("[$code] $message")

/**
 * Interface for the connection to a remote PTY.
 */
interface RemotePtyConnection : AutoCloseable {
    /**
     * Sends a synchronous RPC request and waits for the response.
     */
    fun sendRequest(
        method: String,
        params: Map<String, Any?>
    ): Libp2pRpcProtocol.RpcResponse

    /**
     * Sends an asynchronous RPC request (for suspend functions).
     */
    suspend fun sendRequestAsync(
        method: String,
        params: Map<String, Any?>
    ): Libp2pRpcProtocol.RpcResponse

    /**
     * Subscribes to invalidation notifications.
     */
    fun subscribeToInvalidations(onInvalidation: (Long) -> Unit)

    /**
     * Unsubscribes from invalidation notifications.
     */
    fun unsubscribeFromInvalidations()
}

/**
 * Handler for AlgebraicEffects that come from the remote peer.
 */
interface RemoteEffectHandler {
    /**
     * Handles a RequestEffect from the remote peer.
     *
     * @param effectType The type name of the effect
     * @param effectData The serialized effect data
     * @return The result to return to the remote peer, or null if unhandled
     */
    fun handleRequestEffect(effectType: String, effectData: JSONObject): Any?

    /**
     * Handles a NotificationEffect from the remote peer.
     *
     * @param effectType The type name of the effect
     * @param effectData The serialized effect data
     */
    fun handleNotificationEffect(effectType: String, effectData: JSONObject)
}

/**
 * Stream-based implementation of RemotePtyConnection using the libp2p RPC protocol.
 */
class StreamRemotePtyConnection(
    private val input: InputStream,
    private val output: OutputStream,
    private val effectHandler: RemoteEffectHandler? = null
) : RemotePtyConnection {

    private val closed = AtomicBoolean(false)
    private val pendingRequests = ConcurrentHashMap<String, PendingRequest>()
    private var invalidationCallback: ((Long) -> Unit)? = null
    private val readerThread: Thread

    init {
        // Start reader thread to process incoming messages
        readerThread = thread(name = "RemotePtyConnection-Reader", isDaemon = true) {
            runReaderLoop()
        }
    }

    private data class PendingRequest(
        val latch: CountDownLatch,
        val response: AtomicReference<Libp2pRpcProtocol.RpcResponse?> = AtomicReference(null)
    )

    override fun sendRequest(
        method: String,
        params: Map<String, Any?>
    ): Libp2pRpcProtocol.RpcResponse {
        if (closed.get()) {
            return localTransportFailureResponse(
                "",
                "Connection closed",
                RpcTransportFailure.Phase.CONNECTION_CLOSED,
                null,
            )
        }

        val requestId = Libp2pRpcProtocol.nextRequestId()
        val request = Libp2pRpcProtocol.RpcRequest(requestId, method, params)

        val pending = PendingRequest(CountDownLatch(1))
        pendingRequests[requestId] = pending

        try {
            synchronized(output) {
                Libp2pRpcProtocol.writeMessage(output, request.toJson())
            }

            // Wait for response (with timeout)
            val received = pending.latch.await(30, TimeUnit.SECONDS)
            if (!received) {
                pendingRequests.remove(requestId)
                return localTransportFailureResponse(
                    requestId,
                    "Request timed out",
                    RpcTransportFailure.Phase.RESPONSE_TIMEOUT,
                    null,
                    code = Libp2pRpcProtocol.ERROR_TIMEOUT,
                )
            }

            return pending.response.get() ?: localTransportFailureResponse(
                requestId,
                "No response received",
                RpcTransportFailure.Phase.CONNECTION_CLOSED,
                null,
            )
        } finally {
            pendingRequests.remove(requestId)
        }
    }

    override suspend fun sendRequestAsync(
        method: String,
        params: Map<String, Any?>
    ): Libp2pRpcProtocol.RpcResponse {
        // For now, delegate to synchronous version
        // A proper implementation would use kotlin coroutines
        return sendRequest(method, params)
    }

    override fun subscribeToInvalidations(onInvalidation: (Long) -> Unit) {
        invalidationCallback = onInvalidation
        // Send subscribe message
        val requestId = Libp2pRpcProtocol.nextRequestId()
        val subscribe = Libp2pRpcProtocol.ObservableSubscribe(requestId, "status")
        synchronized(output) {
            Libp2pRpcProtocol.writeMessage(output, subscribe.toJson())
        }
    }

    override fun unsubscribeFromInvalidations() {
        invalidationCallback = null
        // Send unsubscribe message
        val json = JSONObject().apply {
            put("type", Libp2pRpcProtocol.TYPE_OBSERVABLE_UNSUBSCRIBE)
            put("observableId", "status")
        }
        synchronized(output) {
            Libp2pRpcProtocol.writeMessage(output, json)
        }
    }

    override fun close() {
        if (closed.getAndSet(true)) return

        readerThread.interrupt()
        pendingRequests.values.forEach { it.latch.countDown() }
        pendingRequests.clear()

        try {
            input.close()
        } catch (e: Exception) {
            // Ignore
        }
        try {
            output.close()
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun runReaderLoop() {
        try {
            while (!closed.get() && !Thread.currentThread().isInterrupted) {
                val json = Libp2pRpcProtocol.readMessage(input)
                processMessage(json)
            }
        } catch (e: EOFException) {
            // Connection closed
        } catch (e: InterruptedException) {
            // Thread interrupted
        } catch (e: Exception) {
            if (!closed.get()) {
                // Unexpected error
            }
        } finally {
            close()
        }
    }

    private fun processMessage(json: JSONObject) {
        when (val msg = Libp2pRpcProtocol.parseMessage(json)) {
            is Libp2pRpcProtocol.RpcResponse -> {
                val pending = pendingRequests[msg.id]
                if (pending != null) {
                    pending.response.set(msg)
                    pending.latch.countDown()
                }
            }
            is Libp2pRpcProtocol.EffectRequest -> {
                handleEffectRequest(msg)
            }
            is Libp2pRpcProtocol.ObservableInvalidation -> {
                invalidationCallback?.invoke(msg.timestamp)
            }
            is Libp2pRpcProtocol.ObservableValue -> {
                // Handle value updates if needed
            }
            else -> {
                // Ignore unknown message types
            }
        }
    }

    private fun handleEffectRequest(request: Libp2pRpcProtocol.EffectRequest) {
        if (request.isNotification) {
            effectHandler?.handleNotificationEffect(request.effectType, request.effectData)
            // No response needed for notifications
        } else {
            val result = effectHandler?.handleRequestEffect(request.effectType, request.effectData)
            val response = Libp2pRpcProtocol.EffectResponse(
                id = request.id,
                handled = result != null,
                result = result
            )
            synchronized(output) {
                Libp2pRpcProtocol.writeMessage(output, response.toJson())
            }
        }
    }
}
