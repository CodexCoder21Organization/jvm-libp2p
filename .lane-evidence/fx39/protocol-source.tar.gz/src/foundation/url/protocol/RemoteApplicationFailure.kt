package foundation.url.protocol

import org.json.JSONObject

/**
 * Marks an exception as a failure of the service-hosting machinery (a handler session that was
 * shut down, expired, or force-released; a malformed resume; an unknown stream or observable id;
 * a handler timeout) rather than of the service's own code. [applicationFailureData] never reports
 * such an exception as a [RemoteApplicationFailure], whatever its class.
 */
interface ServiceInfrastructureFailure

/**
 * A hosting-infrastructure failure that is an [IllegalStateException], so existing catch sites,
 * error codes, and text are unchanged.
 */
open class ServiceInfrastructureException(message: String, cause: Throwable? = null) :
    IllegalStateException(message, cause), ServiceInfrastructureFailure

/**
 * A hosting-infrastructure failure that is an [IllegalArgumentException] (e.g. a malformed
 * protocol request), so it keeps the `INVALID_PARAMS` code and its text.
 */
open class ServiceInfrastructureArgumentException(message: String, cause: Throwable? = null) :
    IllegalArgumentException(message, cause), ServiceInfrastructureFailure

/**
 * The application exception that a remote request handler threw, as reported by the server that
 * ran the handler.
 *
 * [className] is the fully qualified class name of the exception the handler threw; [message] is
 * that exception's message, or null when it had none. The class is never loaded on the receiving
 * side, so the name can describe a class the caller does not have.
 */
data class RemoteApplicationFailure(val className: String, val message: String?)

/**
 * Implemented by an exception that a proxy's request handler throws to report the failure of the
 * backend it forwarded to, instead of a failure of its own.
 *
 * A proxy (a [ServiceHandler] or request handler that forwards each call to another service) must
 * never have its own exception reported as the application's: [applicationFailureData] reports
 * [remoteApplicationFailure] for such an exception, not the exception's own class and message. Pass
 * the backend's [Libp2pRpcProtocol.RpcError.remoteApplicationFailure] unchanged; when it is null (the
 * backend failed in its transport or hosting layer, or predates the structured failure) nothing is
 * reported, because the failure did not originate in the leaf service's code.
 *
 * A [ServiceInfrastructureFailure], a cancellation, or an interruption is never reported, even if it
 * also implements this interface.
 */
interface ReportsRemoteApplicationFailure {
    /** The leaf service's own failure this exception forwards, or null when there is none. */
    val remoteApplicationFailure: RemoteApplicationFailure?
}

/**
 * A ready-made [ReportsRemoteApplicationFailure] for proxies: [message] and [cause] describe the
 * failure locally (and become the error's text), while [remoteApplicationFailure] is the backend's
 * structured failure, forwarded unchanged.
 */
open class ForwardedApplicationFailureException(
    message: String,
    override val remoteApplicationFailure: RemoteApplicationFailure?,
    cause: Throwable? = null
) : RuntimeException(message, cause), ReportsRemoteApplicationFailure

private const val APPLICATION_EXCEPTION_KEY = "applicationException"
private const val CLASS_NAME_KEY = "className"
private const val MESSAGE_KEY = "message"

/**
 * The structured copy of a failure message is capped so an application exception with a huge
 * message cannot push its error response past the frame budget (the full text is still in the
 * error's own `message`).
 */
const val MAX_REMOTE_FAILURE_MESSAGE_CHARS = 4096

/**
 * Builds the `INTERNAL_ERROR` [Libp2pRpcProtocol.RpcError] a server returns when its request
 * handler throws [failure].
 *
 * The `code` and `message` are exactly what servers have always sent, so older clients see no
 * change. The error's optional `data` field additionally carries the failure's fully qualified
 * class name and message, which [remoteApplicationFailure] reads back.
 *
 * Call this only at the boundary where an application request handler's own exception becomes the
 * response. Transport, framing, timeout, and connection failures are not application failures and
 * must not be reported through this function.
 */
fun applicationFailureRpcError(failure: Throwable): Libp2pRpcProtocol.RpcError =
    applicationFailureRpcError(
        failure,
        Libp2pRpcProtocol.ERROR_INTERNAL,
        "Internal server error: ${failure.javaClass.simpleName}: ${failure.message}"
    )

/**
 * Like [applicationFailureRpcError], but with the caller's own [code] and [message] for servers
 * whose existing error text for a handler exception differs; the structured failure in `data` is
 * the same.
 */
fun applicationFailureRpcError(failure: Throwable, code: String, message: String): Libp2pRpcProtocol.RpcError =
    Libp2pRpcProtocol.RpcError(code = code, message = message, data = applicationFailureData(failure))

/**
 * The structured value that describes [failure] in an error's optional `data` field (the RPC error
 * frame, or any other error format that carries the same shape, such as relay responses).
 *
 * It is null for a [ServiceInfrastructureFailure], a cancellation, or an interruption, which are
 * never reported as application failures. For a [ReportsRemoteApplicationFailure] (a proxy
 * forwarding its backend's failure) it describes the forwarded failure, or is null when that is
 * null. Otherwise it describes [failure] itself.
 */
fun applicationFailureData(failure: Throwable): JSONObject? {
    if (failure is ServiceInfrastructureFailure ||
        failure is java.util.concurrent.CancellationException ||
        failure is InterruptedException
    ) {
        // Hosting failures, cancellation, and interruption are not the application's exception.
        return null
    }
    if (failure is ReportsRemoteApplicationFailure) {
        // A proxy's exception is never the application's; only the leaf failure it forwards is.
        val forwarded = failure.remoteApplicationFailure ?: return null
        return applicationFailureJson(forwarded.className, forwarded.message)
    }
    return applicationFailureJson(failure.javaClass.name, failure.message)
}

private fun applicationFailureJson(className: String, message: String?): JSONObject =
    JSONObject().put(
        APPLICATION_EXCEPTION_KEY,
        JSONObject()
            .put(CLASS_NAME_KEY, className)
            .put(MESSAGE_KEY, message?.let(::capRemoteFailureMessage) ?: JSONObject.NULL)
    )

/**
 * [message] cut to [MAX_REMOTE_FAILURE_MESSAGE_CHARS], without leaving half of a surrogate pair at
 * the end.
 */
internal fun capRemoteFailureMessage(message: String): String {
    if (message.length <= MAX_REMOTE_FAILURE_MESSAGE_CHARS) return message
    val capped = message.take(MAX_REMOTE_FAILURE_MESSAGE_CHARS)
    return if (Character.isHighSurrogate(capped.last())) capped.dropLast(1) else capped
}

/**
 * Reads the failure written by [applicationFailureData] from an error's `data` value (a
 * [JSONObject] or an equivalent [Map]), or null when [data] is absent or of any other shape.
 */
fun remoteApplicationFailureFromData(data: Any?): RemoteApplicationFailure? {
    val details = when (data) {
        is JSONObject -> data.opt(APPLICATION_EXCEPTION_KEY)
        is Map<*, *> -> data[APPLICATION_EXCEPTION_KEY]
        else -> null
    }
    val className: Any?
    val message: Any?
    when (details) {
        is JSONObject -> {
            className = details.opt(CLASS_NAME_KEY)
            message = details.opt(MESSAGE_KEY)
        }
        is Map<*, *> -> {
            className = details[CLASS_NAME_KEY]
            message = details[MESSAGE_KEY]
        }
        else -> return null
    }
    if (className !is String || className.isBlank()) return null
    return RemoteApplicationFailure(className, message as? String)
}

/**
 * The remote application failure this error reports, or null when the error does not describe
 * one: an error from an older server that omits the structured field, a transport or protocol
 * failure, an infrastructure failure, or a `data` value of any other shape.
 */
val Libp2pRpcProtocol.RpcError.remoteApplicationFailure: RemoteApplicationFailure?
    get() = remoteApplicationFailureFromData(data)
