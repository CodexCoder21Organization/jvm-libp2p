package foundation.url.protocol

import io.libp2p.core.ChannelVisitor
import io.libp2p.core.Connection
import io.libp2p.core.Stream
import io.libp2p.etc.util.netty.mux.MuxId
import io.libp2p.transport.implementation.P2PChannelOverNetty
import io.netty.channel.Channel
import io.netty.util.AttributeKey
import java.util.Collections

internal const val MAX_ROOT_LINK_DIAGNOSTIC_SUBSTREAM_IDS = 8

/** A local snapshot of one root link. It contains no request or response payload. */
class RootLinkDiagnostics internal constructor(
    val connectionIdentity: String,
    val localPeerId: String,
    val remotePeerId: String,
    val localEndpoint: String,
    val remoteEndpoint: String,
    val openedAtMillis: Long?,
    substreamIds: List<String>?,
    val reason: String,
    val initiatedBy: String,
    val remoteReportedReason: String = "not received",
    val inFlightSubstreams: Int? = substreamIds?.size,
) {
    /** First eight local direction-qualified mux IDs; a closed root preserves its final sample. */
    val substreamIds: List<String>? = substreamIds?.let {
        Collections.unmodifiableList(ArrayList(it.take(MAX_ROOT_LINK_DIAGNOSTIC_SUBSTREAM_IDS)))
    }

    override fun toString(): String = "Root link $connectionIdentity: localPeerId=$localPeerId; " +
        "remotePeerId=$remotePeerId; localEndpoint=$localEndpoint; remoteEndpoint=$remoteEndpoint; " +
        "openedAtMillis=${openedAtMillis ?: "not observed"}; " +
        "substreamIds=${rootLinkSubstreamIdsText(substreamIds, inFlightSubstreams)}; " +
        "inFlightSubstreams=${inFlightSubstreams ?: "not observed"}; " +
        "reason=$reason; initiatedBy=$initiatedBy; remoteReportedReason=$remoteReportedReason."
}

private fun rootLinkSubstreamIdsText(ids: List<String>?, count: Int?): String {
    if (ids == null) return "not observed"
    val omitted = (count ?: ids.size) - ids.size
    return ids.toString() + if (omitted > 0) " (+$omitted more)" else ""
}

/** Optional local diagnostics, available on native RPC controllers and streams. */
interface RootLinkDiagnosticSource {
    val rootLinkDiagnostics: RootLinkDiagnostics?
}

private val ROOT_LINK_STATE = AttributeKey.valueOf<RootLinkState>("foundation.url.protocol.rootLinkIdentity")

/** Reads this end's identity without requiring a new transport protocol field. */
fun Connection.rootLinkDiagnostics(): RootLinkDiagnostics =
    (this as? P2PChannelOverNetty)?.nettyChannel?.rootLinkState()?.snapshot()
        ?: RootLinkDiagnostics(connectionRecordIdentity(this),
            connectionRecordValue { secureSession().localId.toBase58() }, connectionRecordRemotePeerId(this),
            connectionRecordValue { localAddress() }, connectionRecordValue { remoteAddress() },
            null, null, "not observed", "not observed")

internal fun Channel.rootLinkState(): RootLinkState? = attr(ROOT_LINK_STATE).get()
internal fun Channel.rootLinkDiagnostics(): RootLinkDiagnostics? = rootLinkState()?.snapshot()
internal fun installRootLinkState(connection: Connection, channel: Channel, openedAtMillis: Long?): RootLinkState {
    val state = RootLinkState(connectionRecordIdentity(connection),
        connectionRecordValue { connection.secureSession().localId.toBase58() }, connectionRecordRemotePeerId(connection),
        connectionRecordValue { connection.localAddress() }, connectionRecordValue { connection.remoteAddress() }, openedAtMillis)
    return channel.attr(ROOT_LINK_STATE).setIfAbsent(state) ?: state
}

/** Owned by the root channel only; snapshots copy values and never retain a host or connection. */
internal class RootLinkState(
    private val identity: String, private val localPeer: String, private val remotePeer: String,
    private val localEndpoint: String, private val remoteEndpoint: String, private val openedAtMillis: Long?,
) {
    private val ids = linkedSetOf<String>()
    private var closed: RootLinkDiagnostics? = null
    private var remoteReason = "not received"
    private var terminal = false
    // Keep live tracking behind an attempted-close snapshot: a failed physical close can leave
    // this root usable. The separate immutable copy still describes that particular attempt.
    @Synchronized fun add(id: String) { if (!terminal) ids.add(id) }
    @Synchronized fun remove(id: String) { if (!terminal) ids.remove(id) }
    @Synchronized fun snapshot(): RootLinkDiagnostics = closed ?: makeSnapshot("none", "not observed")
    @Synchronized fun freeze(reason: String, initiatedBy: String): RootLinkDiagnostics {
        return closed ?: makeSnapshot(reason, initiatedBy).also { closed = it }
    }
    @Synchronized fun finish(reason: String, initiatedBy: String): RootLinkDiagnostics {
        if (terminal) return closed!!
        // Physical end fixes the inventory. Earlier attempted-close copies remain immutable,
        // while children opened or closed during a pending attempt are included here.
        val finalReason = closed?.reason?.takeUnless { it == "none" } ?: reason
        terminal = true
        return makeSnapshot(finalReason, initiatedBy).also { closed = it }
    }
    @Synchronized fun abandonFailedClose() {
        if (!terminal) closed = null
    }
    @Synchronized fun recordRemoteRetirement(reason: String) {
        if (remoteReason != "not received") return
        remoteReason = reason
        closed = closed?.let { snapshot ->
            RootLinkDiagnostics(snapshot.connectionIdentity, snapshot.localPeerId, snapshot.remotePeerId,
                snapshot.localEndpoint, snapshot.remoteEndpoint, snapshot.openedAtMillis, snapshot.substreamIds,
                snapshot.reason, snapshot.initiatedBy, remoteReason, snapshot.inFlightSubstreams)
        }
    }
    private fun makeSnapshot(reason: String, initiatedBy: String) = RootLinkDiagnostics(
        identity, localPeer, remotePeer, localEndpoint, remoteEndpoint, openedAtMillis,
        if (openedAtMillis != null) ids.take(MAX_ROOT_LINK_DIAGNOSTIC_SUBSTREAM_IDS) else null,
        reason, initiatedBy, remoteReason, if (openedAtMillis != null) ids.size else null)
}

internal class RootLinkStreamObserver : ChannelVisitor<Stream> {
    override fun visit(stream: Stream) {
        val channel = (stream as? P2PChannelOverNetty)?.nettyChannel ?: return
        val root = (stream.connection as? P2PChannelOverNetty)?.nettyChannel ?: return
        val state = root.rootLinkState() ?: return
        val numericId = (channel.id() as? MuxId)?.id?.toString() ?: channel.id().asLongText()
        val id = "${if (stream.isInitiator) "outbound" else "inbound"}:$numericId"
        state.add(id)
        channel.closeFuture().addListener { state.remove(id) }
    }
}

internal fun RootLinkDiagnostics?.diagnosticSuffix(): String = this?.let { ". $it" } ?: ""

/** Only the existing root-retiring transport response supplies a remote close reason. */
internal fun recordRemoteRootRetirement(controller: Libp2pRpcController, reason: String) {
    (controller as? NettyStreamController)?.rootLinkChannel?.rootLinkState()?.recordRemoteRetirement(reason)
}
