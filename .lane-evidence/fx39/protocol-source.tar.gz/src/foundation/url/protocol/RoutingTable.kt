package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

/**
 * Distance vector routing table for multi-hop message forwarding.
 *
 * Each node maintains a routing table containing:
 * - Known destinations (peer IDs and service identifiers)
 * - Next hop (immediate neighbor peer to forward messages toward each destination)
 * - Distance metric (hop count to reach the destination)
 *
 * The routing table is updated based on distance vector announcements from neighbors.
 * Split horizon and poison reverse are used to prevent routing loops.
 *
 * @param localPeerId This node's peer ID
 * @param clock Clock implementation for time-based operations (defaults to SystemClock for production,
 *              can be replaced with SimulationClock or ManualClock for testing)
 */
class RoutingTable(
    /** This node's peer ID */
    private val localPeerId: String,
    /** Clock for time-based operations like staleness checking */
    private val clock: Clock = SystemClock()
) {
    /**
     * A routing table entry for a destination.
     */
    data class Route(
        /** The peer ID of the destination */
        val destination: String,
        /** The peer ID of the next hop to reach this destination */
        val nextHop: String,
        /** Hop count to reach the destination */
        val distance: Int,
        /** Services advertised by this destination */
        val services: List<String>,
        /** Sequence number for loop prevention */
        val sequenceNumber: Long,
        /** When this route was last updated (milliseconds since epoch) */
        val lastUpdated: Long
    ) {
        /**
         * Checks if the route is stale based on the given current time.
         *
         * @param currentTimeMs The current time in milliseconds since epoch
         * @param staleThresholdMs The threshold after which a route is considered stale (default 5 minutes)
         * @return true if the route is stale, false otherwise
         */
        fun isStale(currentTimeMs: Long, staleThresholdMs: Long = 300_000L): Boolean {
            return currentTimeMs - lastUpdated > staleThresholdMs
        }
    }

    private val lock = ReentrantReadWriteLock()

    /** Routes keyed by destination peer ID */
    private val routes = ConcurrentHashMap<String, Route>()

    /** Service index: service identifier -> list of destination peer IDs that provide it */
    private val serviceIndex = ConcurrentHashMap<String, MutableSet<String>>()

    /** Sequence number for our own announcements (starts at current time for ordering) */
    private val localSequenceNumber = AtomicLong(clock.currentTimeMillis())

    /** Directly connected peers (neighbors) and their controllers for forwarding */
    private val neighbors = ConcurrentHashMap<String, NeighborInfo>()

    /** Latest setup-time announcement for each sender that has not yet been published as a neighbor. */
    private val pendingDistanceVectors = LinkedHashMap<String, RelayProtocol.DistanceVector>()

    /** Recently removed senders whose late announcements must not become setup-time work. */
    private val removedNeighbors = LinkedHashSet<String>()

    /**
     * Information about a directly connected neighbor.
     */
    data class NeighborInfo(
        val peerId: String,
        val controller: RelayMessageSender?,
        val lastSeen: Long
    )

    /**
     * Adds or updates a neighbor (directly connected peer).
     */
    fun addNeighbor(peerId: String, controller: RelayMessageSender?) {
        lock.write {
            neighbors[peerId] = NeighborInfo(peerId, controller, clock.currentTimeMillis())
            removedNeighbors.remove(peerId)

            // Add a direct route to this neighbor, preserving any existing services
            // from distance vector routing. This is important because services are
            // discovered via gossip/distance vector, not via direct registration.
            // If we clear services here, peers that were discovered via distance vector
            // and then register directly would lose their service advertisements.
            val existingServices = routes[peerId]?.services ?: emptyList()
            updateRoute(
                destination = peerId,
                nextHop = peerId,
                distance = 1,
                services = existingServices,
                sequenceNumber = clock.currentTimeMillis()
            )

            // A relay sends its first vector immediately after registration acknowledgement,
            // while the receive listener may start just before this neighbor publication.
            // Consume that already-received vector in the same transition as membership.
            pendingDistanceVectors.remove(peerId)?.let(::applyDistanceVector)
        }
    }

    /**
     * Removes a neighbor when the connection is lost.
     */
    fun removeNeighbor(peerId: String) {
        lock.write {
            neighbors.remove(peerId)
            pendingDistanceVectors.remove(peerId)
            removedNeighbors.remove(peerId)
            removedNeighbors.add(peerId)
            while (removedNeighbors.size > MAX_TRACKED_DISTANCE_VECTOR_SENDERS) {
                removedNeighbors.iterator().let { iterator ->
                    iterator.next()
                    iterator.remove()
                }
            }

            // Remove routes that use this neighbor as next hop
            val routesToRemove = routes.values.filter { it.nextHop == peerId }
            for (route in routesToRemove) {
                routes.remove(route.destination)
                for (service in route.services) {
                    removeFromServiceIndex(service, route.destination)
                }
            }
        }
    }

    /**
     * Gets the controller for a neighbor, for message forwarding.
     */
    fun getNeighborController(peerId: String): RelayMessageSender? {
        return neighbors[peerId]?.controller
    }

    /**
     * Updates the routing table based on a distance vector announcement from a neighbor.
     * The latest announcement from a peer awaiting its first neighbor publication is retained and
     * applied by [addNeighbor]. Announcements from removed peers are ignored.
     * Implements the Bellman-Ford algorithm for distance vector routing.
     */
    fun processDistanceVector(update: RelayProtocol.DistanceVector) {
        val fromPeerId = update.sourcePeerId

        // Don't process our own announcements
        if (fromPeerId == localPeerId) return

        lock.write {
            val updateSnapshot = update.copy(
                entries = update.entries.map { entry ->
                    entry.copy(services = entry.services.toList())
                }
            )
            if (!neighbors.containsKey(fromPeerId)) {
                // A listener can finish reading an update after its connection has been removed.
                // The removal marker keeps that old frame from becoming pending work for a later
                // reconnect. A never-published sender, however, may be in the normal setup window.
                if (fromPeerId !in removedNeighbors) {
                    pendingDistanceVectors.remove(fromPeerId)
                    pendingDistanceVectors[fromPeerId] = updateSnapshot
                    while (pendingDistanceVectors.size > MAX_TRACKED_DISTANCE_VECTOR_SENDERS) {
                        pendingDistanceVectors.entries.iterator().let { iterator ->
                            iterator.next()
                            iterator.remove()
                        }
                    }
                }
                return@write
            }

            applyDistanceVector(updateSnapshot)
        }
    }

    /** Applies an announcement while the caller holds [lock]'s write lock. */
    private fun applyDistanceVector(update: RelayProtocol.DistanceVector) {
        val fromPeerId = update.sourcePeerId
        for (entry in update.entries) {
            // Split horizon: don't learn routes back to ourselves
            if (entry.destination == localPeerId) continue

            // Calculate distance through this neighbor (add 1 hop)
            val newDistance = entry.distance + 1

            // Poisoned reverse: if the route goes back through us, ignore it
            val existingRoute = routes[entry.destination]

            // Update if:
            // 1. No existing route
            // 2. Better (shorter) distance
            // 3. Same distance but newer sequence number
            // 4. Route through this neighbor needs update (triggered update)
            val shouldUpdate = existingRoute == null ||
                newDistance < existingRoute.distance ||
                (newDistance == existingRoute.distance && entry.sequenceNumber > existingRoute.sequenceNumber) ||
                (existingRoute.nextHop == fromPeerId && entry.sequenceNumber > existingRoute.sequenceNumber)

            if (shouldUpdate && newDistance <= MAX_HOP_COUNT) {
                updateRoute(
                    destination = entry.destination,
                    nextHop = fromPeerId,
                    distance = newDistance,
                    services = entry.services,
                    sequenceNumber = entry.sequenceNumber
                )
            }
        }
    }

    /**
     * Updates a route in the table.
     */
    private fun updateRoute(
        destination: String,
        nextHop: String,
        distance: Int,
        services: List<String>,
        sequenceNumber: Long
    ) {
        val oldRoute = routes[destination]

        // Update service index - remove old services
        if (oldRoute != null) {
            for (service in oldRoute.services) {
                removeFromServiceIndex(service, destination)
            }
        }

        // Add new route with current time as lastUpdated
        val newRoute = Route(
            destination = destination,
            nextHop = nextHop,
            distance = distance,
            services = services,
            sequenceNumber = sequenceNumber,
            lastUpdated = clock.currentTimeMillis()
        )
        routes[destination] = newRoute

        // Update service index - add new services
        for (service in services) {
            serviceIndex.computeIfAbsent(service) { mutableSetOf() }.add(destination)
        }
    }

    /**
     * Removes a destination from a service index entry and cleans up empty sets.
     * This prevents memory leaks from accumulating empty sets in the serviceIndex.
     */
    private fun removeFromServiceIndex(service: String, destination: String) {
        val destinations = serviceIndex[service]
        if (destinations != null) {
            destinations.remove(destination)
            // Clean up empty sets to prevent memory leaks
            if (destinations.isEmpty()) {
                serviceIndex.remove(service, destinations)
            }
        }
    }

    /**
     * Gets the next hop for a destination.
     * Returns null if no route exists.
     */
    fun getNextHop(destination: String): String? {
        return lock.read {
            routes[destination]?.nextHop
        }
    }

    /**
     * Gets the route for a destination.
     * Returns null if no route exists.
     */
    fun getRoute(destination: String): Route? {
        return lock.read {
            routes[destination]
        }
    }

    /**
     * Gets all destinations that provide a specific service.
     */
    fun getDestinationsForService(serviceIdentifier: String): List<Route> {
        val now = clock.currentTimeMillis()
        return lock.read {
            val destinations = serviceIndex[serviceIdentifier] ?: emptySet()
            destinations.mapNotNull { routes[it] }
                .filter { !it.isStale(now) }
                .sortedBy { it.distance }
        }
    }

    /**
     * Finds the best route to a destination that provides a service.
     */
    fun findBestRouteForService(serviceIdentifier: String): Route? {
        return getDestinationsForService(serviceIdentifier).firstOrNull()
    }

    /**
     * Checks if we can route to a destination.
     */
    fun canRoute(destination: String): Boolean {
        val now = clock.currentTimeMillis()
        return lock.read {
            val route = routes[destination]
            route != null && !route.isStale(now)
        }
    }

    /**
     * Generates a distance vector message to send to neighbors.
     * Implements split horizon: routes learned from a neighbor are not
     * advertised back to that neighbor.
     */
    fun generateDistanceVector(excludeNeighbor: String? = null): RelayProtocol.DistanceVector {
        val now = clock.currentTimeMillis()
        val entries = lock.read {
            routes.values
                .filter { !it.isStale(now) }
                .filter { excludeNeighbor == null || it.nextHop != excludeNeighbor }
                .map { route ->
                    RelayProtocol.DistanceVector.RoutingEntry(
                        destination = route.destination,
                        services = route.services,
                        distance = route.distance,
                        sequenceNumber = route.sequenceNumber
                    )
                }
        }

        // Add ourselves as distance 0
        val selfEntry = RelayProtocol.DistanceVector.RoutingEntry(
            destination = localPeerId,
            services = emptyList(), // Services are advertised via service announcements
            distance = 0,
            sequenceNumber = localSequenceNumber.incrementAndGet()
        )

        return RelayProtocol.DistanceVector(
            sourcePeerId = localPeerId,
            entries = listOf(selfEntry) + entries
        )
    }

    /**
     * Removes stale routes from the table.
     */
    fun pruneStaleRoutes(staleThresholdMs: Long = 300_000L) {
        val now = clock.currentTimeMillis()
        lock.write {
            val staleRoutes = routes.values.filter { it.isStale(now, staleThresholdMs) }
            for (route in staleRoutes) {
                routes.remove(route.destination)
                for (service in route.services) {
                    removeFromServiceIndex(service, route.destination)
                }
            }
        }
    }

    /**
     * Gets all known routes.
     */
    fun getAllRoutes(): List<Route> {
        return lock.read {
            routes.values.toList()
        }
    }

    /**
     * Gets all neighbors.
     */
    fun getAllNeighbors(): List<NeighborInfo> {
        return neighbors.values.toList()
    }

    companion object {
        /** Maximum hop count to prevent infinite routing loops */
        const val MAX_HOP_COUNT = 16

        /** Matches the network's existing bound on retained peer identities. */
        private const val MAX_TRACKED_DISTANCE_VECTOR_SENDERS = PeerRegistry.MAX_REGISTRY_PEERS
    }
}
