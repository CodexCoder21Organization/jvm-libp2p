package foundation.url.protocol

import java.io.Writer
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject

/** Reads caller-provided exception text without letting its getter replace the failure. */
internal fun rpcEncodingFailureMessage(failure: Throwable): String? = try {
    failure.message
} catch (messageFailure: Throwable) {
    if (messageFailure !== failure) failure.addSuppressed(messageFailure)
    "<message unavailable: ${messageFailure.javaClass.name}>"
}

/** Uses the known value location directly; ordinary failures keep their established text. */
internal fun rpcEncodingFailureDescription(failure: Throwable, includeClassName: Boolean = true): String {
    if (failure is RpcValueEncodingException) {
        val path = when {
            failure.fieldPath == "result" -> "<returned value>"
            failure.fieldPath.startsWith("result.") -> failure.fieldPath.removePrefix("result.")
            failure.fieldPath.startsWith("result[") -> failure.fieldPath.removePrefix("result")
            else -> failure.fieldPath
        }
        return "the value at '$path' ${failure.problem}"
    }
    val message = rpcEncodingFailureMessage(failure)
    return if (includeClassName) "${failure.javaClass.simpleName}: $message" else "$message"
}

internal fun rpcValueEncodingFailure(path: String, failure: Throwable): JSONException {
    rethrowFatalJvmError(failure)
    if (failure is RpcValueEncodingException) {
        return RpcValueEncodingException(boundedRpcFieldPath(path), failure.problem, failure)
    }
    return JSONException(
        "Cannot encode RPC value at '${boundedRpcFieldPath(path)}': ${failure.javaClass.simpleName}: ${rpcEncodingFailureMessage(failure)}",
        failure,
    )
}

private val simpleRpcFieldName = Regex("[A-Za-z_$][A-Za-z0-9_$]*")

private const val RPC_FIELD_PATH_MAX_CHARS = 1024
private val rpcFieldOmission = Regex("<truncated: ([1-9][0-9]*) chars omitted>")

private fun rpcFieldOmissionMarker(characters: Long): String =
    "<truncated: $characters chars omitted>"

internal fun boundedRpcFieldPath(path: String): String {
    if (path.length <= RPC_FIELD_PATH_MAX_CHARS) return path
    val omissions = rpcFieldOmission.findAll(path).toList()
    val representedCharacters = path.length.toLong() + omissions.sumOf {
        it.groupValues[1].toLong() - it.value.length
    }
    val retained = RPC_FIELD_PATH_MAX_CHARS - rpcFieldOmissionMarker(representedCharacters).length
    var headEnd = retained / 2
    var tailStart = path.length - (retained - headEnd)
    // A later ancestor must not cut an earlier omission marker in half.
    for (omission in omissions) {
        if (headEnd > omission.range.first && headEnd <= omission.range.last) headEnd = omission.range.first
        if (tailStart > omission.range.first && tailStart <= omission.range.last) tailStart = omission.range.last + 1
    }
    val omittedCharacters = (tailStart - headEnd).toLong() + omissions
        .filter { it.range.first >= headEnd && it.range.last < tailStart }
        .sumOf { it.groupValues[1].toLong() - it.value.length }
    return path.take(headEnd) + rpcFieldOmissionMarker(omittedCharacters) + path.substring(tailStart)
}

/** Keeps quoted key text bounded even when escaping expands a very large key. */
private class RpcFieldKeyWriter : Writer() {
    private val head = StringBuilder(RPC_FIELD_PATH_MAX_CHARS)
    private val tail = CharArray(RPC_FIELD_PATH_MAX_CHARS)
    private var characters = 0L

    override fun write(buffer: CharArray, offset: Int, length: Int) {
        for (index in offset until offset + length) write(buffer[index].code)
    }

    override fun write(character: Int) {
        // Raw '<' belongs only to omission syntax; real keys retain JSON string escaping.
        if (character == '<'.code) {
            for (escaped in "\\u003c") retain(escaped)
        } else {
            retain(character.toChar())
        }
    }

    private fun retain(character: Char) {
        if (head.length < RPC_FIELD_PATH_MAX_CHARS) head.append(character)
        tail[(characters % tail.size).toInt()] = character
        characters++
    }

    fun boundedText(): String {
        if (characters <= RPC_FIELD_PATH_MAX_CHARS) return head.toString()
        val retained = RPC_FIELD_PATH_MAX_CHARS - rpcFieldOmissionMarker(characters).length
        val headLength = retained / 2
        val tailLength = retained - headLength
        val ending = CharArray(tailLength) { index ->
            tail[((characters - tailLength + index) % tail.size).toInt()]
        }
        return head.substring(0, headLength) +
            rpcFieldOmissionMarker(characters - retained) + String(ending)
    }

    override fun flush() = Unit
    override fun close() = Unit
}

internal fun rpcFieldPath(parent: String, key: String): String {
    val segment = if (key.length <= RPC_FIELD_PATH_MAX_CHARS && simpleRpcFieldName.matches(key)) {
        if (parent.isEmpty()) key else ".$key"
    } else {
        val writer = RpcFieldKeyWriter()
        JSONObject.quote(key, writer)
        "[${writer.boundedText()}]"
    }
    return boundedRpcFieldPath(parent + boundedRpcFieldPath(segment))
}

/** A key already converted for the wire needs no further caller code for its diagnostic. */
internal fun rpcFieldPathSuffix(key: String): String = rpcFieldPath("_", key).removePrefix("_")

/** Runs after encoding has released its locks and refused transport-owned resources. */
internal suspend fun rpcResponseEncodingFailureReason(
    encodingFailure: Throwable,
    onEncodingFailure: (suspend (Throwable) -> String?)?,
    defaultReason: () -> String,
): String {
    val interruptStatus = RpcEncodingInterruptStatus()
    var callbackFailure: Throwable? = null
    try {
        val suppliedReason = try {
            if (onEncodingFailure == null) null else withContext(NonCancellable) {
                onEncodingFailure(encodingFailure)
            }
        } catch (failure: Throwable) {
            callbackFailure = failure
            if (failure !== encodingFailure) encodingFailure.addSuppressed(failure)
            null
        }
        // Original and callback JVM errors still leave after owner cleanup. A diagnostic
        // error attached as suppressed must not replace an ordinary encoding failure.
        rethrowFatalJvmError(encodingFailure)
        callbackFailure?.let(::rethrowFatalJvmError)
        val callbackDiagnostic = callbackFailure?.let {
            "; encoding-failure callback failed: ${it.javaClass.simpleName}: ${rpcEncodingFailureMessage(it)}"
        } ?: ""
        return capRemoteFailureMessage((suppliedReason ?: defaultReason()) + callbackDiagnostic)
    } catch (failure: Throwable) {
        interruptStatus.observe(failure)
        throw failure
    } finally {
        // The failure callback is caller code and can consume the interrupt while returning its
        // diagnostic. Keep it visible to the transport after the refusal path returns.
        interruptStatus.observe(encodingFailure)
        interruptStatus.observe(callbackFailure)
        interruptStatus.restore()
    }
}
