package foundation.url.protocol

import java.io.InputStream
import java.io.InterruptedIOException
import java.nio.channels.ClosedByInterruptException
import java.util.Collections
import java.util.IdentityHashMap
import org.json.JSONArray
import org.json.JSONObject

/** Remembers interruption even when a later cleanup callback consumes the thread's interrupt bit. */
internal class RpcEncodingInterruptStatus {
    private val ownerThread = Thread.currentThread()
    private var wasInterrupted = ownerThread.isInterrupted

    fun observe(failure: Throwable?) {
        val visited = Collections.newSetFromMap(IdentityHashMap<Throwable, Boolean>())
        val pending = ArrayDeque<Throwable>()
        if (failure != null) pending.addLast(failure)
        while (pending.isNotEmpty()) {
            val current = pending.removeFirst()
            if (!visited.add(current)) continue
            if (current is InterruptedException ||
                current is InterruptedIOException ||
                current is ClosedByInterruptException
            ) {
                wasInterrupted = true
            }
            current.cause?.let(pending::addLast)
            current.suppressed.forEach(pending::addLast)
        }
        observeCurrentThread()
    }

    fun observeCurrentThread() {
        if (ownerThread.isInterrupted) wasInterrupted = true
    }

    fun restore() {
        observeCurrentThread()
        if (wasInterrupted) ownerThread.interrupt()
    }
}

/** Resource ownership for one encoding attempt, including the final wire checks. */
internal class RpcEncodingResources(borrowedStreams: Collection<InputStream> = emptyList()) {
    private val borrowed = Collections.newSetFromMap(IdentityHashMap<Any, Boolean>()).apply { addAll(borrowedStreams) }
    private val released = Collections.newSetFromMap(IdentityHashMap<Any, Boolean>())
    private val capturedResources = mutableListOf<AutoCloseable>()
    private val capturedFailures = mutableListOf<Throwable>()
    private val interruptStatus = RpcEncodingInterruptStatus()
    private var guardDepth = 0

    fun readText(input: InputStream): String {
        // Claim before invoking caller code. A repeated reference still reads the same stream,
        // as before, but neither another occurrence nor refusal may release it a second time.
        val closeAfterRead = released.add(input) && !borrowed.contains(input)
        val reader = input.bufferedReader()
        return try {
            if (closeAfterRead) reader.use { it.readText() } else reader.readText()
        } finally {
            interruptStatus.observeCurrentThread()
        }
    }

    fun <T> guard(root: Any?, encode: () -> T): T {
        guardDepth++
        try {
            val cleanupFailures = mutableListOf<Throwable>()
            // Conversion can invoke caller code that changes the result, including stream.close().
            capturedResources.addAll(captureRpcValueResources(root, cleanupFailures))
            capturedFailures.addAll(cleanupFailures)
            interruptStatus.observeCurrentThread()
            cleanupFailures.forEach(interruptStatus::observe)
            return try {
                // A failed snapshot refuses the result even if a later traversal could succeed.
                cleanupFailures.firstOrNull()?.let { throw it }
                encode()
            } catch (failure: Throwable) {
                interruptStatus.observe(failure)
                refuse(failure)
                throw failure
            }
        } finally {
            guardDepth--
            if (guardDepth == 0) interruptStatus.restore()
        }
    }

    fun refuse(failure: Throwable) {
        // Completion can refuse a prepared result after caller code mutates its containers.
        // Keep the original snapshot until that final ownership transition is finished.
        interruptStatus.observe(failure)
        capturedFailures.forEach(interruptStatus::observe)
        try {
            releaseRefusedRpcValue(
                capturedResources, failure, released, borrowed, capturedFailures, interruptStatus,
            )
        } finally {
            interruptStatus.restore()
        }
    }

    fun observeInterrupt(failure: Throwable?) {
        interruptStatus.observe(failure)
    }

    fun restoreInterruptStatus() {
        interruptStatus.restore()
    }

    fun refuse(root: Any?, failure: Throwable) {
        // A lease provider can fail before guard() takes its normal response snapshot.
        // Since no lease was returned, this attempt has no borrowed-stream exceptions.
        val cleanupFailures = mutableListOf<Throwable>()
        capturedResources.addAll(captureRpcValueResources(root, cleanupFailures))
        capturedFailures.addAll(cleanupFailures)
        cleanupFailures.forEach(interruptStatus::observe)
        interruptStatus.observe(failure)
        refuse(failure)
    }
}

private fun captureRpcValueResources(root: Any?, cleanupFailures: MutableList<Throwable>): List<AutoCloseable> {
    val visited = Collections.newSetFromMap(IdentityHashMap<Any, Boolean>())
    val pending = ArrayDeque<Any>()
    val resources = mutableListOf<AutoCloseable>()
    fun visit(value: Any?) {
        if (value != null && visited.add(value)) pending.addLast(value)
    }
    visit(root)
    // Discover the whole graph before conversion or a close callback can change a container.
    // This walk has no encoding depth limit: even resources past the refused depth are owned.
    while (pending.isNotEmpty()) {
        val value = pending.removeFirst()
        try {
            when (value) {
                is ForwardedStreamingBytecodeResponse -> resources.add(value)
                is InputStream -> resources.add(value)
                is Map<*, *> -> for ((key, child) in value) { visit(key); visit(child) }
                is Collection<*> -> for (child in value) visit(child)
                is Array<*> -> for (child in value) visit(child)
                is JSONObject -> for (key in value.keySet()) visit(value.opt(key))
                is JSONArray -> for (index in 0 until value.length()) visit(value.opt(index))
            }
        } catch (cleanupFailure: Throwable) {
            cleanupFailures.add(cleanupFailure)
        }
    }
    return resources
}

private fun releaseRefusedRpcValue(
    resources: List<AutoCloseable>,
    failure: Throwable,
    released: MutableSet<Any>,
    borrowed: Set<Any>,
    cleanupFailures: MutableList<Throwable>,
    interruptStatus: RpcEncodingInterruptStatus,
) {
    // Claim every remaining identity before invoking any close callback. Streams consumed
    // during conversion are already released, including aliases of a forwarded attachment.
    val remaining = resources.filter { resource ->
        val identity = if (resource is ForwardedStreamingBytecodeResponse) resource.jarInput else resource
        !borrowed.contains(identity) && released.add(identity)
    }
    for (resource in remaining) {
        try {
            resource.close()
        } catch (cleanupFailure: Throwable) {
            cleanupFailures.add(cleanupFailure)
            interruptStatus.observe(cleanupFailure)
        } finally {
            // A later close may consume the bit set by an earlier close, so record it now.
            interruptStatus.observeCurrentThread()
        }
    }
    val recordedFailures = Collections.newSetFromMap(IdentityHashMap<Throwable, Boolean>())
    recordedFailures.add(failure)
    recordedFailures.addAll(failure.suppressed)
    for (cleanupFailure in cleanupFailures) {
        if (recordedFailures.add(cleanupFailure)) failure.addSuppressed(cleanupFailure)
    }
    // Release the remaining resources even after a fatal close failure, then propagate it.
    // Ordinary close failures remain attached to the original encoding refusal.
    for (cleanupFailure in cleanupFailures) rethrowFatalJvmError(cleanupFailure)
}
