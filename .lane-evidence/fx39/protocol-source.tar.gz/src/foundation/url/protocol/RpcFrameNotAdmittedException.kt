package foundation.url.protocol

import java.io.IOException

/**
 * This RPC frame write was declined locally before any of its bytes were admitted.
 * A failed write after admission must never report this type. On a raw output stream, the
 * guarantee covers only this write operation. Earlier writes are not covered.
 *
 * [reason] says why admission was declined (for example, the parked-write permits for the
 * connection were exhausted, or the backpressure wait expired while the peer was not reading).
 * [remotePeerId] identifies the peer the declined frame was addressed to, when it is known.
 */
class RpcFrameNotAdmittedException(
    val frameSizeBytes: Long,
    val outboundCapacityBytes: Long?,
    val reason: String? = null,
    val remotePeerId: String? = null,
) : IOException(rpcFrameNotAdmittedMessage(frameSizeBytes, outboundCapacityBytes, reason, remotePeerId))

private fun rpcFrameNotAdmittedMessage(
    frameSizeBytes: Long,
    outboundCapacityBytes: Long?,
    reason: String?,
    remotePeerId: String?,
): String {
    val destination = if (remotePeerId != null) " to peer $remotePeerId" else ""
    val because = if (reason != null) " because $reason" else ""
    val capacity = if (outboundCapacityBytes != null) {
        "The declining outbound channel high-water capacity is $outboundCapacityBytes bytes."
    } else {
        "No outbound channel on this stream's path was still unwritable when this failure was reported " +
            "(writability recovered after the decline), so no high-water capacity can be attributed."
    }
    return "RPC frame write of $frameSizeBytes bytes$destination was declined before write admission$because; " +
        "zero bytes from this write were admitted. $capacity"
}
