package foundation.url.protocol

/**
 * An optional request-handler extension for resources registered in a computed response.
 *
 * Libp2p server hosts (both negotiated encodings) and [TcpServer.withHandler] call
 * [onResponseEncodingFailure] once if encoding that response fails, before
 * writing its error reply. Successful responses are encoded once and do not call this method.
 * The original request, response and effect handler identify the registration owner; no
 * response bytes have been written. Implementations must release only this refused result's
 * registrations, leaving earlier successful results on the connection available.
 *
 * Returning a message supplies the INTERNAL_ERROR text; returning null retains the transport's
 * normal diagnostic. The host bounds the message and sends no attachments with that error.
 * The callback runs outside transport accounting and write locks, after transport-owned refused
 * resources are released, and can suspend despite request cancellation. It may re-enter the
 * connection. Closing the connection can prevent the reply, but does not abandon cleanup.
 * An ordinary callback failure is suppressed on the original encoding failure and reported
 * alongside it; it never replaces that failure. Fatal JVM
 * failures propagate after the callback has had its cleanup opportunity.
 */
interface RpcResponseEncodingFailureHandler : RpcRequestHandler {
    suspend fun onResponseEncodingFailure(
        request: Libp2pRpcProtocol.RpcRequest,
        response: Libp2pRpcProtocol.RpcResponse,
        effectHandler: EffectPropagator,
        failure: Throwable,
    ): String?
}
