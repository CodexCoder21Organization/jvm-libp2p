package foundation.url.protocol

import java.io.InputStream
import java.util.Collections
import java.util.IdentityHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Optional resource owner consulted before a computed response is encoded. */
interface RpcResponseEncodingResourceHandler : RpcResponseEncodingFailureHandler {
    suspend fun responseEncodingLease(
        request: Libp2pRpcProtocol.RpcRequest,
        response: Libp2pRpcProtocol.RpcResponse,
        effectHandler: EffectPropagator,
    ): RpcResponseEncodingLease
}

/**
 * Ownership for one response encoding attempt. [borrowedStreams] is copied by identity:
 * the protocol neither read-closes nor refusal-closes these sources. Their owner remains
 * responsible for closing them, including when the connection closes during encoding.
 *
 * [onComplete] runs once, outside transport locks, after frame preparation or its failure.
 * Null means prepared, not delivered. On refusal it precedes the existing failure callback.
 * The callback may re-enter the host. A lease cannot be reused for another encoding attempt.
 */
class RpcResponseEncodingLease(
    borrowedStreams: Collection<InputStream>,
    private val onComplete: (Throwable?) -> Unit,
) {
    internal val borrowedStreams: Set<InputStream> =
        Collections.newSetFromMap(IdentityHashMap<InputStream, Boolean>()).apply { addAll(borrowedStreams) }
    private val state = AtomicInteger(0)

    internal fun begin() {
        check(state.compareAndSet(0, 1)) { "An RPC response encoding lease can be used for only one encoding attempt." }
    }

    internal fun complete(failure: Throwable?) {
        if (!state.compareAndSet(1, 2)) return
        val interruptStatus = RpcEncodingInterruptStatus()
        var callbackFailure: Throwable? = null
        try {
            onComplete(failure)
        } catch (caught: Throwable) {
            callbackFailure = caught
            if (failure == null) throw caught
            if (caught !== failure) failure.addSuppressed(caught)
            rethrowFatalJvmError(caught)
        } finally {
            // The completion callback can run cleanup and consume its own interruption before
            // returning, including when its failure cannot be attached to the primary error.
            interruptStatus.observe(failure)
            interruptStatus.observe(callbackFailure)
            interruptStatus.restore()
        }
    }
}

/** Prepared JSON bytes and separate binary attachments, with all frame limits checked. */
class RpcEncodedResponse(val jsonBytes: ByteArray, val attachments: List<ByteArray>)

/**
 * Encodes a computed response for custom NetworkProvider or relay dispatchers. Refusals
 * propagate to the dispatcher, which can invoke its response owner's failure callback and
 * send a per-request error. The lease completes before return or throw, including after
 * connection close. This function performs no IO and does not retain the lease.
 */
@JvmOverloads
fun encodeRpcResponse(
    response: Libp2pRpcProtocol.RpcResponse,
    binaryAttachments: Boolean = true,
    lease: RpcResponseEncodingLease? = null,
): RpcEncodedResponse = withRpcResponseEncodingLease(lease) { resources ->
    resources.guard(listOf(response.result, response.error?.data)) {
        val attachments = if (binaryAttachments) mutableListOf<ByteArray>() else null
        val bytes = jsonWireBytes(response.toJson(attachments, resources))
        Libp2pRpcProtocol.checkJsonWireStructure(bytes)
        val encodedAttachments = attachments ?: emptyList()
        if (encodedAttachments.isNotEmpty()) checkRpcAttachmentFrameLimits(bytes, encodedAttachments)
        RpcEncodedResponse(bytes, encodedAttachments)
    }
}

internal inline fun <T> withRpcResponseEncodingLease(
    lease: RpcResponseEncodingLease?,
    encode: (RpcEncodingResources) -> T,
): T {
    lease?.begin()
    val resources = RpcEncodingResources(lease?.borrowedStreams ?: emptySet())
    var failure: Throwable? = null
    try {
        return encode(resources)
    } catch (caught: Throwable) {
        failure = caught
        throw caught
    } finally {
        try {
            lease?.complete(failure)
        } catch (completionFailure: Throwable) {
            resources.refuse(completionFailure)
            throw completionFailure
        } finally {
            // Completion callbacks can attach interruption failures to the original encoding
            // failure, or can set the interrupt bit and then consume it during their own cleanup.
            resources.observeInterrupt(failure)
            resources.restoreInterruptStatus()
        }
    }
}
