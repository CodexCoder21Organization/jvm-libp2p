package foundation.url.protocol

/** Selects reply handling before a stream can start consuming input. */
enum class RpcResponseReader {
    /** Retains the transport's existing reply handling. */
    AUTOMATIC,
    /** The caller reads and dispatches replies; no automatic reader is started. */
    CALLER,
}

/** Optional ownership capability, separate from RpcStream for existing compiled implementations. */
interface RpcResponseReaderOwnership : RpcStream {
    /** Immutable construction choice; closing the stream does not transfer its input ownership. */
    val ownsResponseReader: Boolean
}

/** True for an automatic reader or an older stream that does not report its ownership. */
val RpcStream.ownsResponseReader: Boolean
    get() = (this as? RpcResponseReaderOwnership)?.ownsResponseReader ?: true

/** Call before constructing a dispatcher that will read this stream's input itself. */
fun RpcStream.requireCallerResponseReader() {
    val ownership = this as? RpcResponseReaderOwnership
    check(ownership != null) {
        "Cannot read replies directly from RPC stream '$serviceIdentifier': its response reader ownership is unknown. " +
            "Use a stream that reports RpcResponseReader.CALLER before reading."
    }
    check(!ownership.ownsResponseReader) {
        "Cannot read replies directly from RPC stream '$serviceIdentifier': the stream owns an automatic response reader. " +
            "Open the stream with RpcResponseReader.CALLER before reading."
    }
}

/** Optional provider capability for selecting ownership before dialing returns a stream. */
interface RpcResponseReaderNetworkProvider : NetworkProvider {
    fun dial(
        peerId: String,
        address: String,
        protocolId: String,
        responseReader: RpcResponseReader,
        timeoutMs: Long = 30_000L,
    ): RpcStream
}

/** Older providers retain their exact automatic dial call and refuse unsupported caller mode. */
fun NetworkProvider.dial(
    peerId: String,
    address: String,
    protocolId: String,
    responseReader: RpcResponseReader,
    timeoutMs: Long = 30_000L,
): RpcStream {
    if (responseReader == RpcResponseReader.AUTOMATIC) return dial(peerId, address, protocolId, timeoutMs)
    val provider = this as? RpcResponseReaderNetworkProvider
    check(provider != null) {
        "Cannot dial RPC stream for protocol '$protocolId' with caller-owned response reading: " +
            "this network provider does not support RpcResponseReader.CALLER."
    }
    return provider.dial(peerId, address, protocolId, responseReader, timeoutMs)
}

internal fun refuseCallerReadRequest(serviceIdentifier: String): Nothing =
    throw IllegalStateException(
        "Cannot use sendRequest on raw network protocol stream '$serviceIdentifier'; " +
            "read and write the RpcStream input/output directly."
    )

internal class CallerReadRpcStream(private val delegate: RpcStream) :
    RpcStream by delegate, RpcResponseReaderOwnership {
    override val ownsResponseReader: Boolean = false
    override fun sendRequest(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        refuseCallerReadRequest(serviceIdentifier)
    override fun sendRequestRaw(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        refuseCallerReadRequest(serviceIdentifier)
    override fun sendRequestForForwarding(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        refuseCallerReadRequest(serviceIdentifier)
    override suspend fun sendRequestAsync(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        refuseCallerReadRequest(serviceIdentifier)
}
