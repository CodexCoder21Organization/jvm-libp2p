package foundation.url.protocol

import java.io.InputStream
import java.io.OutputStream

/**
 * A bidirectional RPC stream connected to a remote service.
 *
 * This is the fundamental building block for protocol-level communication.
 * Users can send RpcRequest messages and receive RpcResponse messages directly
 * using the low-level stream API, or use the convenience methods for
 * request/response patterns.
 *
 * Example usage:
 * ```kotlin
 * val protocol = UrlProtocol(bootstrapPeers)
 * val stream = protocol.openStream("url://my.service/")
 *
 * // Option 1: Use convenience method
 * val request = Libp2pRpcProtocol.RpcRequest(
 *     id = Libp2pRpcProtocol.nextRequestId(),
 *     method = "myMethod",
 *     params = mapOf("arg" to "value")
 * )
 * val response = stream.sendRequest(request)
 *
 * // For direct reads, open a separate stream with caller ownership.
 * protocol.openStream("url://my.service/", responseReader = RpcResponseReader.CALLER).use { raw ->
 *     raw.requireCallerResponseReader()
 *     Libp2pRpcProtocol.writeMessage(raw.output, request.toJson())
 *     val responseJson = Libp2pRpcProtocol.readMessage(raw.input)
 *     val rawResponse = Libp2pRpcProtocol.RpcResponse.fromJson(responseJson)
 * }
 *
 * stream.close()
 * ```
 */
interface RpcStream : AutoCloseable {
    /**
     * The input stream for receiving messages from the remote peer.
     * Messages are length-prefixed JSON as defined by [Libp2pRpcProtocol].
     */
    val input: InputStream

    /**
     * The output stream for sending messages to the remote peer.
     * Messages should be encoded using [Libp2pRpcProtocol.writeMessage].
     */
    val output: OutputStream

    /**
     * The peer ID of the remote service provider.
     * This is the base58-encoded peer ID from libp2p.
     */
    val remotePeerId: String

    /**
     * The peer ID of the relay that carries this stream, or `null` when the remote peer was
     * reached directly.
     *
     * A relayed stream traverses a third peer, so a transport-level failure on it can originate at
     * either hop. Implementations that know which relay carries the connection expose it here so a
     * failure can name the hop that carried it instead of only the destination.
     */
    val relayPeerId: String? get() = null

    /**
     * The service identifier this stream is connected to.
     * This is the service identifier portion of the url:// URL.
     */
    val serviceIdentifier: String

    /**
     * Whether this stream is still open and usable.
     */
    val isOpen: Boolean

    /**
     * Sends an RPC request and waits for the response.
     *
     * This is a convenience method that handles message serialization
     * and response correlation. The response result is fully decoded
     * (ByteArray markers are decoded, JSONObjects are converted to Maps, etc.).
     *
     * @param request The RPC request to send.
     * @return The RPC response from the remote peer.
     * @throws UrlProtocolException if the request fails or times out.
     */
    fun sendRequest(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse

    /**
     * Sends an RPC request and waits for the response WITHOUT decoding the result.
     *
     * The response result is kept as its raw org.json representation (JSONObject,
     * JSONArray, String, Number, etc.) instead of being decoded into Kotlin
     * Maps/Lists/ByteArrays. This avoids expensive Base64 decode/re-encode cycles
     * when the response will just be forwarded to another peer.
     *
     * Use this for proxy/forwarding scenarios where the caller does not need to
     * inspect or modify the response payload.
     *
     * @param request The RPC request to send.
     * @return The RPC response with raw (undecoded) result.
     */
    fun sendRequestRaw(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse {
        // Default implementation falls back to full deserialization.
        // TcpRpcStream overrides this with an optimized version.
        return sendRequest(request)
    }

    /**
     * Sends a raw request whose result will be passed directly to another RPC response writer.
     *
     * Implementations may expose a transport-owned, streaming attachment value for this call so
     * the next writer can relay a known-length body without first storing it. Callers must pass the
     * returned result through unchanged. Code that inspects a result must use [sendRequestRaw].
     */
    fun sendRequestForForwarding(
        request: Libp2pRpcProtocol.RpcRequest,
    ): Libp2pRpcProtocol.RpcResponse = sendRequestRaw(request)

    /**
     * Releases this request handle after passing an accepted forwarding response to its writer.
     * The response owns the remaining transfer lifetime. Use [close] to cancel that transfer.
     * An explicit [close] still cancels after a successful release; releasing after close does
     * not start another transfer. Protocol cleanup preserves successfully released responses.
     * Implementations without a separate transfer lifetime simply close the stream.
     */
    fun releaseAfterForwarding() = close()

    /**
     * Sends an RPC request asynchronously.
     *
     * @param request The RPC request to send.
     * @return The RPC response from the remote peer.
     * @throws UrlProtocolException if the request fails or times out.
     */
    suspend fun sendRequestAsync(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse

    /**
     * Closes this stream and releases associated resources, including any still-running
     * forwarded response previously accepted by [releaseAfterForwarding].
     */
    override fun close()
}

/**
 * Optional admission order on an inbound provider stream, allocated before its callback is queued.
 * Uses the same process-local ordering as [AdmissionOrderedServiceClientConnection]. Servers
 * adapting this stream to that connection capability must carry this value through unchanged.
 * Every decorator or alternate handle for this admitted stream must preserve its original
 * positive order; allocating another order would falsely describe another logical admission.
 * Absence means unknown order; callback execution cannot reconstruct transport admission order.
 */
interface AdmissionOrderedRpcStream : RpcStream {
    val admissionOrder: Long
}

internal class AdmittedRpcStream(
    private val delegate: RpcStream,
    override val admissionOrder: Long,
) : RpcStream by delegate, AdmissionOrderedRpcStream, RootLinkDiagnosticSource, RpcResponseReaderOwnership {
    override val ownsResponseReader: Boolean get() = delegate.ownsResponseReader
    override val rootLinkDiagnostics: RootLinkDiagnostics? get() = (delegate as? RootLinkDiagnosticSource)?.rootLinkDiagnostics
}
