package foundation.url.protocol


/**
 * Adapter that wraps an [RpcStream] from UrlProtocol as a [RemotePtyConnection].
 *
 * This allows the high-level UrlResolver to use the low-level RpcStream
 * from UrlProtocol while maintaining compatibility with existing code
 * that expects RemotePtyConnection.
 *
 * This class is public to allow UrlResolver to be defined in a separate module.
 */
class RpcStreamConnection(
    private val stream: RpcStream,
    private val serviceIdentifier: String,
    private val headers: Map<String, String> = emptyMap()
) : RemotePtyConnection {

    override fun sendRequest(
        method: String,
        params: Map<String, Any?>
    ): Libp2pRpcProtocol.RpcResponse {
        val fullParams = params + ("_service" to serviceIdentifier) + headers.mapKeys { "_header_${it.key}" }
        val request = Libp2pRpcProtocol.RpcRequest(
            id = Libp2pRpcProtocol.nextRequestId(),
            method = method,
            params = fullParams,
            metadata = headers
        )
        return stream.sendRequest(request)
    }

    override suspend fun sendRequestAsync(
        method: String,
        params: Map<String, Any?>
    ): Libp2pRpcProtocol.RpcResponse {
        val fullParams = params + ("_service" to serviceIdentifier) + headers.mapKeys { "_header_${it.key}" }
        val request = Libp2pRpcProtocol.RpcRequest(
            id = Libp2pRpcProtocol.nextRequestId(),
            method = method,
            params = fullParams,
            metadata = headers
        )
        return stream.sendRequestAsync(request)
    }

    override fun subscribeToInvalidations(onInvalidation: (Long) -> Unit) {
        // TODO: Implement invalidation subscription via RpcStream
        // For now, this is a no-op as the base RpcStream doesn't support this
    }

    override fun unsubscribeFromInvalidations() {
        // TODO: Implement invalidation unsubscription via RpcStream
        // For now, this is a no-op as the base RpcStream doesn't support this
    }

    override fun close() {
        stream.close()
    }
}
