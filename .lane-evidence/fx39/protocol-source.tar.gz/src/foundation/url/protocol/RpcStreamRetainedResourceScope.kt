package foundation.url.protocol

/**
 * Adds application-owned reservations to memory retained by one [Libp2pRpcStream].
 *
 * UrlProtocol continues to apply its built-in process-wide bounds independently. An embedding
 * process can use this scope to account for the same retained work in a broader budget shared with
 * other components. Each returned reservation is closed after UrlProtocol has attempted to release
 * its own reservation, and a close failure is reported through the stream's normal cleanup path.
 * Reservation acquisition runs on the stream reader and may wait for the application's budget.
 * Implementations must be thread-safe because returned reservations may be closed by another
 * thread calling [Libp2pRpcStream.close].
 */
interface RpcStreamRetainedResourceScope {
    /**
     * Retains one response assembly from admission until completion or stream shutdown.
     * [retainedBytes] includes attachment destinations and amplified response-JSON parse storage.
     */
    fun retainInterleavedResponse(
        responseId: String,
        retainedBytes: Long,
    ): AutoCloseable

    /** Retains the compact-frame capacity used while a response assembly is active. */
    fun retainInterleavedFrameCapacity(): AutoCloseable
}
