package foundation.url.protocol

/**
 * Local transport information in [Libp2pRpcProtocol.RpcError.data].
 *
 * RPC streams supply this when a local write, response read, or response deadline fails,
 * or when the stream closes before a response arrives. Application errors never acquire this information, regardless
 * of their code or message. It is omitted from JSON, so forwarding a response cannot turn
 * a remote application error into a local connection failure.
 */
class RpcTransportFailure internal constructor(
    val phase: Phase,
    val cause: Throwable?,
    val rootLinkDiagnostics: RootLinkDiagnostics?,
) {
    internal constructor(phase: Phase, cause: Throwable?) : this(phase, cause, null)

    enum class Phase { REQUEST_WRITE, CONNECTION_CLOSED, RESPONSE_TIMEOUT, RESPONSE_READ }

    override fun toString(): String = "RpcTransportFailure(phase=$phase, cause=$cause)" + rootLinkDiagnostics.diagnosticSuffix()
}

/**
 * Whether [UrlProtocol.sendServiceRpcRequest] replaces the stream and sends the call once more.
 *
 * Only a local transport failure qualifies, identified by its [RpcTransportFailure] marker and
 * never by an error code or message: a service's own error is its answer, whatever it says.
 * [RpcTransportFailure.Phase.REQUEST_WRITE] and [RpcTransportFailure.Phase.CONNECTION_CLOSED]
 * mean the stream can no longer carry calls. A CONNECTION_CLOSED failure can follow a completed
 * write, so for that case the call may run twice, as it could before failures were typed.
 * [RpcTransportFailure.Phase.RESPONSE_TIMEOUT] and [RpcTransportFailure.Phase.RESPONSE_READ] are
 * not retried: the service may already be running or have run the call.
 */
internal fun Libp2pRpcProtocol.RpcError?.isStreamReplacementRetryable(): Boolean {
    val failure = this?.data as? RpcTransportFailure ?: return false
    return failure.phase == RpcTransportFailure.Phase.REQUEST_WRITE ||
        failure.phase == RpcTransportFailure.Phase.CONNECTION_CLOSED
}

internal fun localTransportFailureResponse(
    requestId: String,
    message: String,
    phase: RpcTransportFailure.Phase,
    cause: Throwable?,
    code: String = Libp2pRpcProtocol.ERROR_INTERNAL,
    rootLinkDiagnostics: RootLinkDiagnostics? = null,
): Libp2pRpcProtocol.RpcResponse = Libp2pRpcProtocol.RpcResponse(
    requestId,
    null,
    Libp2pRpcProtocol.RpcError(
        code,
        message,
        RpcTransportFailure(phase, cause, rootLinkDiagnostics),
    ),
)
