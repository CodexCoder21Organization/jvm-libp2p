package foundation.url.protocol

import org.json.JSONException

/** A value refused by the encoder, at its actual field path in the message. */
class RpcValueEncodingException(
    val fieldPath: String,
    val problem: String,
    cause: Throwable? = null,
) : JSONException("Cannot encode RPC value at '$fieldPath': $problem", cause)
