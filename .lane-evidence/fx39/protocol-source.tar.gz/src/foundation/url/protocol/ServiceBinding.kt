package foundation.url.protocol

/**
 * Represents a bound service that is listening for incoming connections.
 *
 * This interface is returned by [UrlProtocol.bind] and can be used to
 * stop the service and release resources.
 */
interface ServiceBinding : AutoCloseable {
    /**
     * The service identifier this binding is for.
     */
    val serviceIdentifier: String

    /**
     * The actual TCP listening port, including an operating-system-assigned port when bound to 0.
     * @throws IllegalStateException when the listener has not started or has stopped.
     */
    val localPort: Int

    /**
     * Whether this binding is currently active.
     */
    val isActive: Boolean

    /**
     * Stops the service and releases resources.
     */
    fun stop()

    /**
     * Closes this binding (equivalent to [stop]).
     */
    override fun close() = stop()
}

/**
 * ServiceBinding implementation for TCP-based services.
 */
class TcpServiceBinding(
    private val server: TcpServer,
    override val serviceIdentifier: String
) : ServiceBinding {

    override val localPort: Int
        get() = server.activeLocalPort

    override val isActive: Boolean
        get() = server.isRunning

    override fun stop() {
        server.stop()
    }
}
