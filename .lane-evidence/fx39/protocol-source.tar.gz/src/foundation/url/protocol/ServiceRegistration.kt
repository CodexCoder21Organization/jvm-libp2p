package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import foundation.url.protocol.sandbox.BytecodeProtocol
import foundation.url.protocol.sandbox.SandboxException
import org.json.JSONObject
import java.util.Base64
import java.lang.ref.ReferenceQueue
import java.lang.ref.WeakReference
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

private fun isCanonicalStreamedBytecodeResponse(response: String): Boolean =
    response.startsWith(STREAMED_BYTECODE_RESPONSE_PREFIX)

private fun isAlreadyBytecodeProtocolResponse(json: JSONObject): Boolean =
    json.has("jarBytes") ||
        json.optBoolean("notModified", false) ||
        (!json.optBoolean("success", true) && json.has("error"))

/**
 * Reads the byte payload forms produced by the RPC JSON codec.
 *
 * A binary-capable hop can return a [ByteArray] in a Map, while a hop that has
 * already serialized that Map can leave the codec's `{"__type":"bytes"}` marker
 * nested inside the `jarBytes` field of a JSON object. The public bytecode
 * response contract uses a base64 String, so the proxy must normalize both forms
 * before forwarding the response to an older downstream hop.
 */
private fun bytecodeJarBase64(value: Any?): String? = when (value) {
    is String -> value
    is ByteArray -> Base64.getEncoder().encodeToString(value)
    is JSONObject -> {
        if (value.optString("__type", "") != "bytes") {
            null
        } else {
            value.opt("__value") as? String
        }
    }
    is Map<*, *> -> {
        if (value["__type"] != "bytes") {
            null
        } else {
            bytecodeJarBase64(value["__value"])
        }
    }
    else -> null
}

private fun normalizeBytecodeProtocolResponse(
    json: JSONObject,
    serviceIdentifier: String,
    original: String? = null
): String {
    if (!json.has("jarBytes")) return original ?: json.toString()

    val rawJarBytes = json.opt("jarBytes")
    val jarBase64 = bytecodeJarBase64(rawJarBytes)
        ?: throw RuntimeException(
            "Backend bytecode response for service '$serviceIdentifier' has an unsupported " +
                "'jarBytes' value: ${rawJarBytes?.javaClass?.name}. Expected a base64 String, " +
                "ByteArray, or a JSON bytes marker with '__type':'bytes' and a String '__value'."
        )
    val implClassName = json.opt("implClassName") as? String
        ?: throw RuntimeException(
            "Backend bytecode response for service '$serviceIdentifier' is missing a String " +
                "'implClassName' key. Got keys: ${json.keySet()}"
        )

    // Preserve an already-final String response when it already carries the public
    // base64 representation. This keeps the large streamed payload on its existing
    // pass-through path; only codec binary markers are rewritten.
    if (rawJarBytes is String && original != null) return original

    return BytecodeProtocol.createResponseFromBase64(
        jarBase64 = jarBase64,
        implClassName = implClassName
    )
}

private fun normalizeBytecodeProtocolMap(
    result: Map<*, *>,
    serviceIdentifier: String
): String {
    val rawJarBytes = result["jarBytes"]
    val jarBase64 = bytecodeJarBase64(rawJarBytes)
        ?: throw RuntimeException(
            "Backend bytecode response for service '$serviceIdentifier' has an unsupported " +
                "'jarBytes' value: ${rawJarBytes?.javaClass?.name}. Expected a base64 String, " +
                "ByteArray, or a JSON bytes marker with '__type':'bytes' and a String '__value'."
        )
    val implClassName = result["implClassName"] as? String
        ?: throw RuntimeException(
            "Backend bytecode response for service '$serviceIdentifier' is missing a String " +
                "'implClassName' key. Got keys: ${result.keys}"
        )
    return BytecodeProtocol.createResponseFromBase64(
        jarBase64 = jarBase64,
        implClassName = implClassName
    )
}

/**
 * Process-local causal timestamp allocator shared by every lifecycle producer for one provider.
 *
 * A provider's service announcements, withdrawals, and relay-registration snapshots are separate
 * wire streams, but receivers compare their timestamps as one lifecycle. Keying the high-water
 * mark by the injected [Clock] instance and provider peer ID lets all protocol objects owned by one
 * UrlProtocol2 instance share a strict order without changing the public constructor or broadcaster
 * APIs. The clock key is weak so closing an instance does not retain its provider history forever.
 */
private class ProviderClockIdentity(
    clock: Clock,
    queue: ReferenceQueue<Clock>? = null
) : WeakReference<Clock>(clock, queue) {
    private val identityHash = System.identityHashCode(clock)

    override fun hashCode(): Int = identityHash

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        val clock = get() ?: return false
        return other is ProviderClockIdentity && clock === other.get()
    }
}

private val collectedProviderClocks = ReferenceQueue<Clock>()
private val providerLifecycleHighWaterByClock =
    HashMap<ProviderClockIdentity, MutableMap<String, Long>>()

/**
 * Reserves the next provider lifecycle timestamp atomically.
 *
 * [observedHighWater] folds in compatibility history retained by older broadcaster
 * implementations and per-registration state. The returned value is strictly greater than every
 * previously reserved or observed value, and may jump farther forward when the raw clock is later.
 */
internal fun reserveProviderLifecycleTimestamp(
    clock: Clock,
    providerPeerId: String,
    observedHighWater: Long = 0L
): Long = reserveProviderLifecycleTimestampAtTime(
    clock, providerPeerId, observedHighWater, clock.currentTimeMillis()
)

private fun reserveProviderLifecycleTimestampAtTime(
    clock: Clock,
    providerPeerId: String,
    observedHighWater: Long,
    sampledTime: Long
): Long = synchronized(providerLifecycleHighWaterByClock) {
    // These keys only call owned identity operations, including during map cleanup.
    // Supplied Clock.hashCode/equals must never run under either ownership monitor.
    while (true) {
        val collectedClock = collectedProviderClocks.poll() ?: break
        providerLifecycleHighWaterByClock.remove(collectedClock as ProviderClockIdentity)
    }
    val clockIdentity = ProviderClockIdentity(clock, collectedProviderClocks)
    val providerHistory = providerLifecycleHighWaterByClock.getOrPut(clockIdentity) { HashMap() }
    val providerHighWater = providerHistory.getOrDefault(providerPeerId, 0L)
    val lifecycleHighWater = maxOf(providerHighWater, observedHighWater)
    check(lifecycleHighWater < Long.MAX_VALUE) {
        "Cannot reserve another lifecycle timestamp for provider '$providerPeerId' after " +
            "timestamp Long.MAX_VALUE."
    }
    val timestamp = maxOf(sampledTime, lifecycleHighWater + 1L)
    providerHistory[providerPeerId] = timestamp
    timestamp
}

/**
 * Handler interface for processing requests to a registered service.
 *
 * Implement this interface to handle requests at specific URL paths.
 * The handler receives the path and parameters, and returns a response
 * object that will be serialized and sent to the client.
 *
 * ## Example Usage
 * ```kotlin
 * class MyServiceHandler : ServiceHandler {
 *     override suspend fun handleRequest(
 *         path: String,
 *         params: Map<String, Any?>,
 *         metadata: Map<String, String>
 *     ): Any? {
 *         return when {
 *             path == "status" -> mapOf("status" to "online", "uptime" to 12345)
 *             path.startsWith("users/") -> getUserById(path.removePrefix("users/"))
 *             else -> throw IllegalArgumentException("Unknown path: $path")
 *         }
 *     }
 * }
 *
 * val registration = urlResolver.registerGlobalService(
 *     serviceUrl = "url://my.service.name/",
 *     handler = MyServiceHandler()
 * )
 * ```
 */
interface ServiceHandler {
    /**
     * Handles a request to this service.
     *
     * @param path The resource path within the service URL
     *             For URL "url://my.service/users/123", path would be "users/123"
     * @param params Request parameters (from RPC params)
     * @param metadata Request metadata (headers, auth info, etc.)
     * @return The response object to send back. Must be JSON-serializable.
     *         Can be: primitive types, String, Map, List, JSONObject, JSONArray
     * @throws Exception Any exception will be converted to an error response
     */
    suspend fun handleRequest(
        path: String,
        params: Map<String, Any?>,
        metadata: Map<String, String>
    ): Any?

    /**
     * Called when the service is being shut down.
     * Override to clean up resources.
     */
    fun onShutdown() {}

    // =========================================================================
    // SANDBOXED EXECUTION SUPPORT
    // =========================================================================

    /**
     * Returns the implementation JAR bytes for sandboxed execution on the client.
     *
     * When a client requests this service with an interface type, it will fetch
     * these bytes and execute them in an SJVM sandbox. This provides security
     * isolation for the implementation code.
     *
     * @return The JAR bytes containing the implementation, or null if this service
     *         does not support sandboxed execution
     */
    fun getImplementationJar(): ByteArray? = null

    /**
     * Returns the fully qualified class name of the implementation class.
     *
     * This is the entry point class that implements the service interface.
     * It must be present in the JAR returned by [getImplementationJar].
     *
     * @return The implementation class name (e.g., "com.example.MyServiceImpl"),
     *         or null if this service does not support sandboxed execution
     */
    fun getImplementationClassName(): String? = null

    /**
     * Returns the digest of the implementation JAR (computed with
     * [BytecodeProtocol.computeDigest]), used to answer conditional bytecode
     * requests: when a client's `cachedDigest` equals this value, the server
     * replies "not modified" instead of re-serving the full JAR.
     *
     * The default derives the digest by hashing [getImplementationJar] on
     * every call. Handlers whose JAR bytes are immutable for the lifetime of
     * the registration (the common case — the JAR is baked into the service
     * binary) should override this with a precomputed value so conditional
     * requests don't have to materialize and hash the JAR bytes just to
     * confirm nothing changed.
     *
     * An override MUST stay consistent with [getImplementationJar]: it must
     * equal `BytecodeProtocol.computeDigest(getImplementationJar()!!)` at all
     * times. Returning a stale digest makes clients keep outdated bytecode;
     * returning a digest that never matches silently disables the
     * conditional-request optimization.
     *
     * @return The digest of the current implementation JAR, or null if this
     *         service does not support sandboxed execution
     */
    fun getImplementationJarDigest(): String? =
        getImplementationJar()?.let { BytecodeProtocol.computeDigest(it) }

    /**
     * **Deprecated.** Remote services must not provide stdlib bytes — sandbox
     * isolation depends on the consumer trusting only its own bundled
     * `/stdlib.jar`. UrlResolver as of #506 ignores any bytes supplied here;
     * the `__bytecode_request` server-side handler additionally drops them
     * before they reach the wire. This method is retained only for source
     * compatibility with services that override it; the override is now a
     * no-op at runtime regardless of the return value.
     *
     * @return Ignored. Always treated as null on both sides of the wire.
     */
    @Deprecated(
        message = "Remote services must not supply stdlib bytes. UrlResolver " +
            "always loads the consumer's bundled /stdlib.jar via " +
            "AvianStdLibHelper.addStdlib(builder, null); the bytes returned " +
            "here are dropped server-side before the bytecode response is " +
            "serialized. Remove the override.",
        level = DeprecationLevel.WARNING
    )
    fun getStdlibJar(): ByteArray? = null

    /**
     * Whether this service supports sandboxed execution.
     *
     * Returns true if [getImplementationJar] and [getImplementationClassName]
     * return non-null values.
     */
    fun supportsSandboxedExecution(): Boolean {
        return getImplementationJar() != null && getImplementationClassName() != null
    }
}

/**
 * Thrown by [ServiceClientConnection.push] when a server-initiated frame cannot
 * be delivered to the client — the connection is closed, reset, or its outbound
 * buffer is unwritable.
 *
 * A push is **never silently dropped**. This is deliberate and mirrors the
 * awaited-write convention the transport already follows (a dropped awaited RPC
 * response / effect request surfaces loudly rather than leaving the peer to hang
 * its full invocation timeout — UrlProtocol 0.0.306/0.0.308). A service that
 * pushes unsolicited frames (e.g. a connection-scoped subscription lease) needs
 * to learn *at push time* that the client connection is gone so it can reap the
 * subscription immediately instead of leaking it until some later sweep. Contrast
 * [EffectPropagator.propagateNotificationEffect], which is best-effort by design
 * (no caller is awaiting a reply): push has a caller that is awaiting delivery
 * confirmation, so a drop is an exception, not a no-op.
 *
 * It is a [ServiceInfrastructureFailure]: a service that lets it escape its handler reports a
 * delivery failure of the connection, never an exception of its own.
 */
class ServicePushException(message: String, cause: Throwable? = null) :
    Exception(message, cause), ServiceInfrastructureFailure

/**
 * Validates that [frame] is a legal server-initiated push frame before
 * [ServiceClientConnection.push] hands it to the transport.
 *
 * A push frame must carry a non-empty custom `type` that is NOT one of
 * [Libp2pRpcProtocol.RESERVED_MESSAGE_TYPES]. The client's RPC-stream reader
 * correlates transport frames (notably `response`) by `type`+`id`, so a push
 * reusing a reserved type could spoof an in-flight RPC response or control frame
 * at the client. A missing/empty `type` is also rejected: the client dispatches
 * server-initiated frames by `type`, so a typeless frame is undeliverable.
 *
 * This is caller misuse (a programming error), so it is reported as an
 * [IllegalArgumentException] — distinct from the delivery-failure
 * [ServicePushException] — and is checked before any connection interaction, so a
 * rejected frame is never written to the wire.
 *
 * @throws IllegalArgumentException if the frame's `type` is missing/empty or is a
 *   reserved transport type. The message names the offending type and the full
 *   reserved set.
 */
internal fun validatePushableFrame(frame: JSONObject) {
    val type = frame.optString("type", "")
    val reservedSorted = Libp2pRpcProtocol.RESERVED_MESSAGE_TYPES.sorted()
    if (type.isEmpty()) {
        throw IllegalArgumentException(
            "Cannot push a server-initiated frame without a non-empty \"type\" field: a push frame " +
                "must carry a custom type the client dispatches on, and it must not be one of the " +
                "reserved transport types $reservedSorted (which the client's reader correlates by " +
                "type+id, so reusing one could spoof an in-flight RPC response or control frame)."
        )
    }
    if (type in Libp2pRpcProtocol.RESERVED_MESSAGE_TYPES) {
        throw IllegalArgumentException(
            "Cannot push a server-initiated frame with the reserved transport type \"$type\": a push " +
                "frame must carry a custom type distinct from the reserved transport types " +
                "$reservedSorted (the client's reader correlates these by type+id, so a push reusing " +
                "\"$type\" could spoof an in-flight RPC response or control frame at the client)."
        )
    }
}

/**
 * A durable, connection-scoped channel from a registered service back to **one
 * specific connected client**.
 *
 * A [ConnectionAwareServiceHandler] receives one of these for every inbound RPC
 * request, identifying the persistent connection the request arrived on. Unlike
 * the request/response return value, this handle is **durable**: it remains valid
 * for the lifetime of the underlying client connection, so a handler may capture
 * it during one request (e.g. a SUBSCRIBE) and use it later to deliver
 * unsolicited frames to that client (e.g. live-projection deltas) without waiting
 * for the client to poll again.
 *
 * All members are safe to call from any thread. Multiple threads may [push]
 * concurrently on the same connection; the transport serializes the framed
 * writes.
 */
interface ServiceClientConnection {
    /**
     * Stable identity of this client connection for the connection's lifetime.
     * Two requests arriving on the same persistent live connection observe the
     * same [connectionId]; a reconnection produces a new [ServiceClientConnection]
     * with a different [connectionId]. This is the correlation key between a
     * captured push sender and its [onClose] lifecycle callback.
     *
     * Uniqueness applies only to *live* connections. The connection-less sentinel
     * handed to a [ConnectionAwareServiceHandler] invoked without a live client
     * connection (an in-process call or a proxy/forwarding path) always reports
     * the fixed id `"detached"` and is never open, so a `"detached"` id is the
     * signal that there is no real client behind this handle — never a correlation
     * key.
     */
    val connectionId: String

    /**
     * Authenticated remote peer identity for transports that have one, or `null`
     * when this connection was accepted through a transport with no cryptographic
     * peer identity.
     *
     * On the libp2p transport this is the base58 peer id authenticated by the
     * secure channel and reported by the accepted stream; it is not read from any
     * client-supplied request payload or metadata. Unlike [connectionId], this
     * value is stable across reconnects from the same client keypair, so it can
     * be used as the caller principal for reconnect-stable idempotency or
     * authorization decisions.
     *
     * On `localhost.tcp` and detached/in-process invocations this is `null`.
     * Callers that fall back to [connectionId] in those cases must treat that
     * fallback as connection-scoped and reconnect-unstable.
     */
    val remotePeerId: String?
        get() = null

    /**
     * Whether this connection is currently believed to be writable. A `false`
     * reading means a [push] will fail; a `true` reading does not guarantee the
     * next [push] succeeds (the peer may vanish between the check and the write),
     * which is exactly why [push] itself reports failure loudly rather than
     * relying on a prior [isOpen] check.
     */
    val isOpen: Boolean

    /**
     * Sends an unsolicited server→client [frame] to this specific connection.
     *
     * [frame] MUST carry a non-empty custom `type` that the client registered an
     * inbound handler for, and that `type` must NOT be one of the reserved
     * transport types ([Libp2pRpcProtocol.RESERVED_MESSAGE_TYPES], e.g.
     * `response`/`error`/`ping`) — a reserved type could spoof an in-flight RPC
     * response or control frame at the client. The frame is otherwise written
     * verbatim — the caller owns the wire shape.
     *
     * **Client-side dispatch lives one layer up.** This module's own RPC-stream
     * readers (`Libp2pRpcStream`/`TcpRpcStream`) only correlate `response` frames
     * by id and ignore every other type; it is
     * [`foundation.url:resolver`](https://github.com/CodexCoder21Organization/UrlResolver)'s
     * persistent-connection reader that dispatches server-initiated frames by
     * their `type`. That is why the `type` must be one the resolver-side client
     * is prepared to route, not merely non-reserved.
     *
     * **Blocking / deadline semantics are per transport, but a push is always
     * bounded and never blocks forever:**
     * - **libp2p (direct/circuit-relay-transport connection):** the frame goes
     *   over the same backpressure-gated write path as an awaited RPC response.
     *   If the connection stays unwritable through the write-delivery window it is
     *   reported as a drop ([ServicePushException]); the call returns within that
     *   window.
     * - **`localhost.tcp` connection:** the write is a blocking socket write.
     *   `java.net.Socket` exposes no send timeout, so the write is bounded by a
     *   watchdog that closes the socket if the push has not completed within the
     *   same delivery window; the wedged write then fails and surfaces as a
     *   [ServicePushException] (which also tears the dead connection down).
     *
     * **Relay reachability.** Server-initiated push requires a direct connection
     * (or a transport-level circuit-relay connection) to the client. A service
     * reached through the *app-level* relay ([RelayService]) sees the
     * relay-bound connection, not the true client's: the relay only correlates
     * exactly one response per forwarded request and has no unsolicited-frame
     * path back to the original source, so pushes on such a connection will not
     * reach the true client. Use push only on connections you know are direct.
     *
     * @throws IllegalArgumentException if [frame]'s `type` is missing/empty or is a
     *   reserved transport type (a caller programming error; the frame is never
     *   written) — see [validatePushableFrame].
     * @throws ServicePushException if the frame could not be delivered because the
     *   connection is closed, reset, or unwritable past the delivery window. The
     *   push is never silently dropped.
     */
    fun push(frame: JSONObject)

    /**
     * Registers [listener] to run once when this client connection is observed
     * closed, reset, or lost (a graceful close from the peer, an abrupt
     * disconnect/RST, or an idle-timeout close all count).
     *
     * The listener fires **exactly once**. Multiple listeners may be registered;
     * each runs once. A listener that throws is isolated (its failure does not
     * prevent other listeners from running) and does not propagate to the
     * transport.
     *
     * **Threading / promptness.** When the connection dies while the listener is
     * registered, the listener runs on a dedicated close-listener dispatcher, NOT
     * on the transport's I/O (Netty event-loop) thread — so a slow listener cannot
     * stall the event loop and freeze other connections. If the connection is
     * already dead when [onClose] is called, [listener] instead runs immediately
     * on the calling thread. Either way, **listeners should still be fast**: a
     * blocking listener occupies a dispatcher thread and can delay other pending
     * close listeners.
     *
     * **Register once per subscription, not per request.** Each call *adds* a
     * listener; they accumulate for the connection's lifetime. A
     * [ConnectionAwareServiceHandler] is invoked on every inbound request, so
     * register the close listener once when the subscription is established, not
     * on every request, or a long-lived connection will accumulate unbounded
     * duplicate listeners.
     *
     * This is what makes a subscription lease genuinely connection-scoped: the
     * service reaps the subscription the moment the client's connection dies,
     * with no polling heartbeat.
     */
    fun onClose(listener: () -> Unit)
}

/**
 * Optional connection capability that exposes the cause already selected by transport teardown.
 *
 * [closeCause] is `null` while the connection remains open. A non-null value is published before
 * the transport interrupts request handlers owned by that connection, so an interrupted handler
 * can distinguish connection teardown from an unrelated caller-owned interrupt without depending
 * on [ServiceClientConnection.onClose] callback timing. The first published cause is final.
 *
 * This subinterface is additive so existing [ServiceClientConnection] implementations remain
 * binary compatible. Callers must check the capability with
 * `connection as? CloseAwareServiceClientConnection`.
 */
interface CloseAwareServiceClientConnection : ServiceClientConnection {
    val closeCause: Throwable?
}

/**
 * Optional transport-admission order for a server-side client connection.
 *
 * [admissionOrder] is positive, immutable, and remains readable after close. Transports allocate it
 * with [nextServiceConnectionAdmissionOrder] when accepting the RPC connection, before dispatching
 * any reader or request work. All transports in the same protocol classloader share that order;
 * it is not a timestamp, a peer-supplied value, or an order across processes or restarts.
 *
 * This separate capability preserves existing ServiceClientConnection implementations and JVM
 * callers. Absence means unknown order. Consumers must not substitute first-handler-observation
 * order: an unknown connection cannot safely displace a different connection's existing owner.
 *
 * A positive order also identifies one logical transport admission in this protocol classloader.
 * Every decorator or alternate handle for that admission must preserve the original value;
 * different admissions must never share it, even when textual connection IDs are reused.
 * The legacy transport constructor reports zero because no admission fact was supplied.
 * Consumers treat zero as unknown, just like absence of this capability.
 */
interface AdmissionOrderedServiceClientConnection : ServiceClientConnection {
    val admissionOrder: Long
}

/**
 * Allocates an admission order for a transport accepting a new server-side RPC connection.
 * Call exactly once at admission, before dispatch, and retain it for the connection's lifetime.
 */
fun nextServiceConnectionAdmissionOrder(): Long = serviceConnectionAdmissionOrders.updateAndGet { previous ->
    check(previous < Long.MAX_VALUE) { "Service connection admission order exhausted at $previous" }
    previous + 1L
}

private val serviceConnectionAdmissionOrders = java.util.concurrent.atomic.AtomicLong(0L)

/**
 * Optional capability for a [ServiceClientConnection] whose serving transport can retire the exact
 * client connection represented by the handle.
 *
 * A connection-aware proxy uses this when its downstream leg dies: closing the upstream transport
 * makes a push-mode client observe ordinary transport loss, reconnect, and establish a fresh
 * subscription instead of remaining attached to a connection that can no longer deliver updates.
 * [disconnect] is idempotent and affects only this connection generation.
 *
 * This subinterface is additive and has no wire representation. Callers must check the capability
 * with `connection as? DisconnectableServiceClientConnection`; legacy implementations remain valid
 * [ServiceClientConnection] instances and simply do not expose it. Existing peers exchange exactly
 * the same frames until a caller explicitly invokes [disconnect] on a capable connection.
 */
interface DisconnectableServiceClientConnection : ServiceClientConnection {
    /** Closes this exact client transport. Repeated calls have no additional effect. */
    fun disconnect()
}

/**
 * An optional extension of [ServiceHandler] for services that need the
 * connection-scoped server→client push channel ([ServiceClientConnection]).
 *
 * This is purely additive: existing three-argument [ServiceHandler]s keep
 * working unchanged and never see a connection. A handler opts in by
 * implementing this interface instead; the routing layer then invokes the
 * four-argument [handleRequest], handing it the [ServiceClientConnection] for
 * the connection the request arrived on. A handler that implements this
 * interface only needs to override the four-argument overload — the inherited
 * three-argument [ServiceHandler.handleRequest] delegates to it with a detached
 * (already-closed) connection, which is only ever used when a
 * [ConnectionAwareServiceHandler] is invoked through a transport that provides
 * no live connection (e.g. an in-process call or a proxy-forwarding path).
 */
interface ConnectionAwareServiceHandler : ServiceHandler {
    /**
     * Handles a request with access to the connection it arrived on.
     *
     * @param path see [ServiceHandler.handleRequest]
     * @param params see [ServiceHandler.handleRequest]
     * @param metadata see [ServiceHandler.handleRequest]
     * @param connection the durable, connection-scoped channel back to this
     *   client; capture it to push unsolicited frames or observe connection death.
     * @return the response object to send back (same contract as
     *   [ServiceHandler.handleRequest]).
     */
    suspend fun handleRequest(
        path: String,
        params: Map<String, Any?>,
        metadata: Map<String, String>,
        connection: ServiceClientConnection
    ): Any?

    override suspend fun handleRequest(
        path: String,
        params: Map<String, Any?>,
        metadata: Map<String, String>
    ): Any? = handleRequest(path, params, metadata, DetachedServiceClientConnection)
}

/**
 * The [ServiceClientConnection] handed to a [ConnectionAwareServiceHandler] when
 * no live client connection is available (an in-process invocation, or a
 * transport that predates push support). It is permanently closed: [isOpen] is
 * `false`, [push] always throws [ServicePushException], and [onClose] fires its
 * listener immediately.
 */
internal object DetachedServiceClientConnection : ServiceClientConnection {
    override val connectionId: String = "detached"
    override val isOpen: Boolean = false
    override fun push(frame: JSONObject) {
        // Validate the frame first so a reserved/typeless frame is a uniform
        // IllegalArgumentException on every ServiceClientConnection, regardless of
        // whether a live connection happens to back this handle.
        validatePushableFrame(frame)
        throw ServicePushException(
            "Cannot push to a detached (connection-less) ServiceClientConnection: this " +
                "ConnectionAwareServiceHandler was invoked without a live client connection " +
                "(in-process call or a proxy/forwarding path), so there is nowhere to send " +
                "the server-initiated frame."
        )
    }
    override fun onClose(listener: () -> Unit) {
        listener()
    }
}

/**
 * Represents an active service registration.
 *
 * This handle allows you to:
 * - Check registration status
 * - Get statistics about the service
 * - Unregister the service
 */
interface ServiceRegistration : AutoCloseable {
    /**
     * The full service URL (e.g., "url://my.service.name/")
     */
    val serviceUrl: String

    /**
     * The service identifier extracted from the URL (e.g., "my.service.name")
     */
    val serviceIdentifier: String

    /**
     * The peer ID of this service provider.
     */
    val peerId: String

    /**
     * The multiaddresses where this service can be reached.
     */
    val multiaddresses: List<String>

    /**
     * Whether this service is currently active and accepting requests.
     */
    val isActive: Boolean

    /**
     * Number of requests handled since registration.
     */
    val requestCount: Long

    /**
     * Number of peers this service has been announced to.
     * Always 0 for local services.
     */
    val announcedToPeerCount: Int

    /**
     * Whether this service is globally visible (announced to peers).
     * - true: Service is announced to peers and discoverable on the network
     * - false: Service is only accessible locally within this UrlResolver instance
     */
    val isGlobal: Boolean

    /**
     * Marks this registration inactive once, then attempts handler shutdown, global withdrawal
     * delivery when a withdrawal timestamp is available, and local unregister cleanup. These
     * cleanup callbacks run outside the registration lock. A failure in timestamp allocation or
     * an earlier cleanup step does not skip later cleanup; the first failure is rethrown after
     * all steps, with later distinct failures suppressed on it. Repeated and reentrant calls
     * do not repeat cleanup. Local registrations do not allocate or broadcast withdrawal timestamps.
     */
    fun unregister()

    /**
     * Re-announces this service to all peers.
     * Useful after network changes or to refresh TTLs.
     */
    fun reannounce()

    /**
     * Same as unregister().
     */
    override fun close() = unregister()
}

/**
 * Configuration for service registration.
 */
data class ServiceRegistrationConfig(
    /**
     * STUN servers to use for NAT traversal.
     * These help discover the public address of this service.
     */
    val stunServers: List<String> = PublicStunServers.GOOGLE_STUN_SERVERS,

    /**
     * TURN servers to use when direct connection is not possible.
     */
    val turnServers: List<TurnServerInfo> = emptyList(),

    /**
     * Additional metadata to include in service announcements.
     */
    val metadata: Map<String, String> = emptyMap(),

    /**
     * TTL for gossip announcements.
     * Higher values spread announcements further but use more bandwidth.
     */
    val announcementTtl: Int = GossipProtocol.DEFAULT_TTL,

    /**
     * Interval in milliseconds between periodic re-announcements.
     * Set to 0 to disable periodic re-announcements.
     */
    val reannounceIntervalMs: Long = 5 * 60 * 1000, // 5 minutes

    /**
     * Maximum number of concurrent requests to handle.
     */
    val maxConcurrentRequests: Int = 100
)

private fun preserveFirstUnregisterFailure(
    firstFailure: Throwable?,
    operation: () -> Unit
): Throwable? = try {
    operation()
    firstFailure
} catch (nextFailure: Throwable) {
    if (firstFailure == null) {
        nextFailure
    } else {
        if (firstFailure !== nextFailure &&
            firstFailure.suppressed.none { it === nextFailure }
        ) {
            firstFailure.addSuppressed(nextFailure)
        }
        firstFailure
    }
}

/**
 * Implementation of ServiceRegistration.
 *
 * This class is used by UrlResolver to track registered services. It is public
 * to allow UrlResolver to be defined in a separate module (foundation.url:resolver)
 * while still creating and managing service registrations.
 */
class ServiceRegistrationImpl(
    override val serviceUrl: String,
    override val serviceIdentifier: String,
    override val peerId: String,
    override val isGlobal: Boolean,
    private val handler: ServiceHandler,
    private val config: ServiceRegistrationConfig,
    private val broadcaster: ServiceBroadcaster,
    private val onUnregister: (String) -> Unit = {},
    /**
     * Wall-clock source sampled before announcement and withdrawal timestamp capture
     * inside [broadcastLock]. Defaults to [SystemClock]; tests that drive
     * UrlProtocol2 with a [community.kotlin.clocks.simple.ManualClock] should
     * pass the same clock here so the timestamps captured by [broadcastSafely]
     * and [unregister] stay consistent with the rest of the protocol's notion
     * of time. Defaulting matters because previous versions of this class
     * used `System.currentTimeMillis()` directly, which silently desynchronised
     * with ManualClock-driven tests (e.g. testStaleServiceAnnouncementsNotForwardedToLateJoiners,
     * where the wall clock did not advance but the ManualClock did).
     */
    private val clock: Clock = SystemClock()
) : ServiceRegistration {

    // Pairs unregister() and any caller-driven broadcast under a shared monitor so that
    // the check-then-act race between "is the service active?" and "call broadcaster
    // .broadcastAnnouncement(...)" cannot let a stale announcement travel past the
    // withdrawal at receivers. The lock protects the active check and timestamp capture;
    // supplied history and clock reads, delivery and cleanup callbacks run OUTSIDE it. See
    // [broadcastSafely] and [unregister].
    private val broadcastLock = Any()

    @Volatile
    private var _isActive = true
    private val _requestCount = AtomicLong(0L)
    @Volatile
    private var _announcedToPeerCount = 0
    @Volatile
    private var _multiaddresses: List<String> = emptyList()
    // Lifecycle timestamps issued by this registration. Both fields are protected by
    // broadcastLock; allocation is centralized in allocateLifecycleTimestampLocked so
    // announcements and withdrawals cannot move backward when the wall clock does.
    private var lastIssuedLifecycleTimestamp: Long? = null
    private var lastAnnouncementTimestamp: Long? = null

    /**
     * Allocates the next lifecycle timestamp while [broadcastLock] is held.
     *
     * The optional broadcaster capability supplies cross-registration history. Old
     * [ServiceBroadcaster] binaries do not implement it and safely fall back to `0L`;
     * within one registration, [lastIssuedLifecycleTimestamp] is the authoritative
     * high-water mark. Keeping this as the single allocation point makes every issued
     * announcement or withdrawal strictly newer than both histories even if [clock]
     * freezes or moves backward. External history and time are sampled before entering
     * the monitor; this commit only combines those values with owned high-water state.
     */
    private fun allocateLifecycleTimestampLocked(crossRegistrationHighWater: Long, sampledTime: Long): Long {
        check(Thread.holdsLock(broadcastLock)) {
            "Lifecycle timestamp allocation for service '$serviceIdentifier' and provider " +
                "'$peerId' must hold the registration broadcast lock."
        }
        val registrationHighWater = maxOf(
            lastIssuedLifecycleTimestamp ?: 0L,
            lastAnnouncementTimestamp ?: 0L
        )
        check(crossRegistrationHighWater < Long.MAX_VALUE) {
            "Cannot issue another lifecycle timestamp for service '$serviceIdentifier' and " +
                "provider '$peerId' after cross-registration timestamp Long.MAX_VALUE."
        }
        check(registrationHighWater < Long.MAX_VALUE) {
            "Cannot issue another lifecycle timestamp for service '$serviceIdentifier' and " +
                "provider '$peerId' after registration timestamp Long.MAX_VALUE."
        }
        val timestamp = reserveProviderLifecycleTimestampAtTime(
            clock = clock,
            providerPeerId = peerId,
            observedHighWater = maxOf(crossRegistrationHighWater, registrationHighWater),
            sampledTime = sampledTime
        )
        lastIssuedLifecycleTimestamp = maxOf(registrationHighWater, timestamp)
        return timestamp
    }

    override val multiaddresses: List<String>
        get() = _multiaddresses

    override val isActive: Boolean
        get() = _isActive

    override val requestCount: Long
        get() = _requestCount.get()

    override val announcedToPeerCount: Int
        get() = _announcedToPeerCount

    fun setMultiaddresses(addrs: List<String>) {
        _multiaddresses = addrs
    }

    fun incrementRequestCount() {
        _requestCount.incrementAndGet()
    }

    fun setAnnouncedToPeerCount(count: Int) {
        _announcedToPeerCount = count
    }

    suspend fun handleRequest(
        path: String,
        params: Map<String, Any?>,
        metadata: Map<String, String>
    ): Any? = handleRequest(path, params, metadata, connection = null)

    /**
     * Connection-aware request dispatch. When [connection] is non-null and the
     * wrapped [handler] is a [ConnectionAwareServiceHandler], the handler is
     * invoked with the connection-scoped [ServiceClientConnection] so it can
     * push unsolicited frames back to this client and observe the connection's
     * death. Otherwise dispatch falls through to the plain three-argument
     * [ServiceHandler.handleRequest], so old handlers are unaffected and a
     * connection-aware handler reached through a transport with no live
     * connection still works (via [ConnectionAwareServiceHandler]'s default,
     * which supplies a detached connection).
     */
    suspend fun handleRequest(
        path: String,
        params: Map<String, Any?>,
        metadata: Map<String, String>,
        connection: ServiceClientConnection?
    ): Any? {
        if (!_isActive) {
            // Refused by the hosting layer (the registration was withdrawn after the router's
            // isActive check), not thrown by the service: never reported as its exception.
            throw ServiceInfrastructureException("Service is not active")
        }
        incrementRequestCount()
        val h = handler
        return if (connection != null && h is ConnectionAwareServiceHandler) {
            h.handleRequest(path, params, metadata, connection)
        } else {
            h.handleRequest(path, params, metadata)
        }
    }

    fun supportsSandboxedExecution(): Boolean = handler.supportsSandboxedExecution()
    fun getImplementationJar(): ByteArray? = handler.getImplementationJar()
    fun getImplementationClassName(): String? = handler.getImplementationClassName()
    fun getImplementationJarDigest(): String? = handler.getImplementationJarDigest()

    @Deprecated(
        message = "Remote services must not supply stdlib bytes. See " +
            "ServiceHandler.getStdlibJar for rationale.",
        level = DeprecationLevel.WARNING
    )
    @Suppress("DEPRECATION")
    fun getStdlibJar(): ByteArray? = handler.getStdlibJar()

    override fun unregister() {
        var withdrawalTimestamp: Long? = null
        var failure: Throwable? = null
        synchronized(broadcastLock) {
            if (!_isActive) return
            _isActive = false
        }
        if (isGlobal) {
            try {
                val crossRegistrationHighWater =
                    (broadcaster as? LifecycleTimestampHistoryServiceBroadcaster)
                        ?.lastIssuedLifecycleTimestamp(serviceIdentifier, peerId)
                        ?: 0L
                val sampledTime = clock.currentTimeMillis()
                withdrawalTimestamp = synchronized(broadcastLock) {
                    allocateLifecycleTimestampLocked(crossRegistrationHighWater, sampledTime)
                }
            } catch (allocationFailure: Throwable) {
                failure = allocationFailure
            }
        }

        // Every cleanup callback runs outside broadcastLock. If timestamp capture failed,
        // the registration is still inactive and the missing stamp does not skip shutdown
        // or registry removal.
        failure = preserveFirstUnregisterFailure(failure) { handler.onShutdown() }
        withdrawalTimestamp?.let { timestamp ->
            failure = preserveFirstUnregisterFailure(failure) {
                broadcaster.broadcastWithdrawalAtTimestamp(
                    serviceUrl, serviceIdentifier, peerId, timestamp
                )
            }
        }
        failure = preserveFirstUnregisterFailure(failure) { onUnregister(serviceIdentifier) }
        failure?.let { throw it }
    }

    override fun reannounce() {
        if (!isGlobal) return // Local services are not announced
        broadcastSafely(
            providerMultiaddresses = _multiaddresses,
            stunAddresses = config.stunServers,
            turnServers = config.turnServers,
            metadata = config.metadata,
            ttl = config.announcementTtl
        )
    }

    /**
     * Broadcasts a service announcement for this registration, atomically guarded
     * against concurrent [unregister].
     *
     * # This is opt-in safety, not invariant enforcement.
     *
     * The underlying `ServiceBroadcaster.broadcastAnnouncement` /
     * `broadcastAnnouncementAtTimestamp` methods remain publicly callable. Any
     * caller that bypasses this primitive and invokes them directly — for
     * example by keeping the old `if (registration.isActive) broadcaster.broadcastAnnouncement(...)`
     * shape — re-opens the resurrection race that `broadcastSafely` exists to
     * close. The wire-format guarantees provided by this method's
     * capture-inside-lock semantics are NOT enforced at the broadcaster layer;
     * they are a convention every per-registration caller must adopt.
     *
     * The reason we do not enforce this at the broadcaster layer is that some
     * legitimate callers have no [ServiceRegistration] handle to lock against
     * — e.g. alias announcements issued from `joinNetwork` that are not
     * recorded in the local service registry, or relay-side forwarder paths
     * that re-broadcast announcements received from third parties. For those
     * callers there is nothing to capture-inside-a-lock against, so the
     * timestamp-less `broadcastAnnouncement` overload remains the right
     * primitive and the lock semantics simply do not apply.
     *
     * # Why this primitive exists
     *
     * Every external caller that drives
     * [ServiceBroadcaster.broadcastAnnouncement] against a registration had the
     * same check-then-act shape before this method existed:
     *
     * ```
     * if (registration.isActive) {                        // decision
     *     broadcaster.broadcastAnnouncement(...)          // action — unregister()
     *                                                     // can slip in here
     * }
     * ```
     *
     * `unregister()` could fire between the `isActive` decision and the broadcast
     * action. Because `broadcastAnnouncement` deliberately stamps the announcement
     * with `max(now, lastBroadcastWithdrawalTimestamp + 1)` (so legitimate
     * re-registrations in the same wall-clock millisecond as a withdrawal still beat
     * the withdrawal at receivers), a stale post-withdrawal broadcast produced by
     * this race carried `announcement.timestamp > withdrawal.timestamp`. Receivers
     * then took the "announcement.timestamp > withdrawalTimestamp" branch of
     * `onServiceAnnouncement`, cleared their `withdrawnServices` entry, and
     * resurrected the service in `discoveredServices` — the failure mode of the
     * `e2eRegistrationAfterWithdrawalReachesDiscoveredServices` flake in UrlResolver
     * (see [UrlResolver PR #570](https://github.com/CodexCoder21Organization/UrlResolver/pull/570)).
     *
     * How it closes the race. The active-check and the timestamp are captured
     * atomically inside a per-registration monitor that [unregister] also takes;
     * the broadcaster is then called OUTSIDE the lock with the captured timestamp.
     * Two ordering invariants follow:
     *
     *   1. **Mutual exclusion of capture, parallelism of I/O.** Either this
     *      method's capture wins the lock (in which case [unregister] observes
     *      `_isActive = true` until this capture releases the lock, then
     *      acquires and captures a timestamp at least as large as the captured
     *      announcement) or
     *      [unregister]'s capture wins (in which case this method observes
     *      `_isActive = false` and skips the broadcast entirely). The two
     *      broadcaster calls themselves run concurrently — `unregister()` never
     *      blocks on this method's in-flight broadcast.
     *   2. **Wire-order matches local order.** The captured timestamp is the
     *      one passed to [ServiceBroadcaster.broadcastAnnouncementAtTimestamp];
     *      no later "clock.currentTimeMillis()" can sneak past the capture, so
     *      a stale re-broadcast cannot produce a timestamp greater than a
     *      withdrawal that already happened locally.
     *
     * # Callers
     *
     * Both the built-in [reannounce] and any external broadcaster-driven
     * re-announcement (e.g. UrlResolver's `reannounceWithCircuitRelay` after the
     * relay-registration handshake completes, or `registerServiceInternal`'s
     * delayed initial-announcement coroutine) MUST use this method whenever they
     * want to broadcast for a registered service — there is no enforcement
     * mechanism that catches a caller who bypasses it, so the discipline is on
     * the caller.
     *
     * Direct calls to [ServiceBroadcaster.broadcastAnnouncement] /
     * [ServiceBroadcaster.broadcastAnnouncementAtTimestamp] bypass the lock and
     * re-open the resurrection race. They are reserved for callsites that have
     * no [ServiceRegistration] handle (e.g. alias announcements from
     * `joinNetwork` that do not appear in the local service registry, or
     * relay-side forwarders that re-broadcast announcements received from
     * third parties).
     *
     * # The deeper fix that would close this class entirely
     *
     * Timestamp-based ordering is fragile. Any out-of-order delivery (relay
     * retry, network reorder, clock skew between providers) can still cause
     * a stale broadcast to outrank a withdrawal at receivers if both happen
     * to land in the same millisecond. The sender-side mutex closes one
     * specific cause (same-process check-then-act) but does NOT close the
     * class. A causal sequence number per `(serviceIdentifier, providerPeerId)`
     * — assigned monotonically by the sender and compared on the receiver in
     * place of `announcement.timestamp > withdrawalTimestamp` — would close
     * the class entirely. Tracked as a follow-up.
     *
     * @param providerMultiaddresses Addresses to advertise in the announcement.
     * @param stunAddresses STUN servers, defaults to the registration's config.
     * @param turnServers TURN servers, defaults to the registration's config.
     * @param metadata Announcement metadata, defaults to the registration's config.
     * @param ttl Announcement TTL, defaults to the registration's config.
     * @return Number of peers the announcement was sent to, or 0 if the
     *   registration is no longer active (no broadcast was issued).
     */
    fun broadcastSafely(
        providerMultiaddresses: List<String>,
        stunAddresses: List<String> = config.stunServers,
        turnServers: List<TurnServerInfo> = config.turnServers,
        metadata: Map<String, String> = config.metadata,
        ttl: Int = config.announcementTtl
    ): Int {
        if (!_isActive) return 0
        val crossRegistrationHighWater =
            (broadcaster as? LifecycleTimestampHistoryServiceBroadcaster)
                ?.lastIssuedLifecycleTimestamp(serviceIdentifier, peerId)
                ?: 0L
        val sampledTime = clock.currentTimeMillis()
        val announcementTimestamp: Long
        synchronized(broadcastLock) {
            if (!_isActive) return 0
            announcementTimestamp = allocateLifecycleTimestampLocked(crossRegistrationHighWater, sampledTime)
            lastAnnouncementTimestamp = maxOf(
                lastAnnouncementTimestamp ?: Long.MIN_VALUE,
                announcementTimestamp
            )
        }
        // Lock released. The broadcaster call runs WITHOUT the lock, so a
        // concurrent unregister() does not block on this in-flight broadcast.
        val count = broadcaster.broadcastAnnouncementAtTimestamp(
            serviceUrl = serviceUrl,
            serviceIdentifier = serviceIdentifier,
            providerPeerId = peerId,
            providerMultiaddresses = providerMultiaddresses,
            stunAddresses = stunAddresses,
            turnServers = turnServers,
            metadata = metadata,
            ttl = ttl,
            timestamp = announcementTimestamp
        )
        _announcedToPeerCount = count
        return count
    }
}

/**
 * Interface for broadcasting service announcements to peers.
 *
 * This interface is implemented by UrlResolver to handle service announcement
 * broadcasts. It is public to allow UrlResolver to be defined in a separate module
 * (foundation.url:resolver) while still integrating with the protocol layer.
 *
 * # Safety against the broadcastAnnouncement-after-unregister race
 *
 * The methods on this interface (`broadcastAnnouncement`,
 * `broadcastAnnouncementAtTimestamp`, `broadcastWithdrawal`,
 * `broadcastWithdrawalAtTimestamp`) are low-level wire-format primitives.
 * **They do not enforce any caller-side wire-order invariant on their own.** A
 * caller that holds a [ServiceRegistration] handle and bypasses
 * [ServiceRegistrationImpl.broadcastSafely] (and the matching
 * [ServiceRegistration.unregister]) is responsible for ensuring that any
 * `broadcastAnnouncement(...)` call it makes for that registration cannot
 * stamp an announcement with a timestamp greater than a concurrent withdrawal
 * for the same `(serviceIdentifier, providerPeerId)`. Without that discipline,
 * receivers' `onServiceAnnouncement` interprets the stale announcement as a
 * legitimate re-registration and resurrects the service in `discoveredServices`.
 *
 * This is opt-in safety for callers, not invariant enforcement — see
 * [ServiceRegistrationImpl.broadcastSafely]'s KDoc for the full rationale and
 * a sketch of the deeper fix (causal sequence numbers) that would close the
 * race class at the wire layer.
 *
 * # Implementation contract: timestamp-bearing methods are abstract
 *
 * [broadcastAnnouncementAtTimestamp] and [broadcastWithdrawalAtTimestamp] are
 * the abstract methods of this interface — every implementation MUST override
 * both, and MUST use the supplied `timestamp` as the wire-format timestamp
 * verbatim. The timestamp-less [broadcastAnnouncement] and [broadcastWithdrawal]
 * methods now have default implementations that synthesise a wall-clock
 * timestamp via `System.currentTimeMillis()` and delegate to the timestamp
 * variants.
 *
 * Prior to UrlProtocol 0.0.284 the opposite was true: the timestamp-less
 * methods were abstract and the timestamp-bearing variants had defaults that
 * silently dropped the supplied timestamp. An implementation that overrode
 * only the timestamp-less methods therefore turned
 * [ServiceRegistrationImpl.broadcastSafely]'s lock-captured timestamps into
 * "current wall-clock at broadcast time" with no compile-time signal, which
 * re-opened the race [ServiceRegistrationImpl.broadcastSafely] was introduced
 * to close. The current arrangement makes the failure mode a compile error
 * instead of silent runtime degradation.
 */
interface ServiceBroadcaster {
    /**
     * Broadcasts a service announcement with an explicit, pre-captured wall-clock
     * timestamp.
     *
     * This is the **primary** method on the interface — every implementation MUST
     * override it. [ServiceRegistrationImpl.broadcastSafely] routes through this
     * method with a timestamp it has captured under a per-registration lock that
     * is also taken by [ServiceRegistrationImpl.unregister], which is what closes
     * the broadcastAnnouncement-after-unregister resurrection race. Implementations
     * MUST use the supplied [timestamp] as the announcement's wire-format
     * timestamp rather than generating their own at broadcast time — generating
     * a fresh timestamp here re-opens the race in its original form.
     *
     * # Why this is the abstract method, not [broadcastAnnouncement]
     *
     * Prior to UrlProtocol 0.0.284, [broadcastAnnouncement] was the abstract
     * method and [broadcastAnnouncementAtTimestamp] had a default implementation
     * that silently dropped the [timestamp] argument and delegated to
     * [broadcastAnnouncement]. That arrangement let an implementation forget to
     * override the timestamp method and silently re-open the resurrection race
     * with no compile-time signal. The arrangement is now inverted: the
     * timestamp-bearing method is abstract, and [broadcastAnnouncement] (which
     * has no specific timestamp to honour) has a default that synthesises one
     * via `System.currentTimeMillis()` and delegates here.
     *
     * @return Number of peers the announcement was sent to.
     */
    fun broadcastAnnouncementAtTimestamp(
        serviceUrl: String,
        serviceIdentifier: String,
        providerPeerId: String,
        providerMultiaddresses: List<String>,
        stunAddresses: List<String>,
        turnServers: List<TurnServerInfo>,
        metadata: Map<String, String>,
        ttl: Int,
        timestamp: Long
    ): Int

    /**
     * Broadcasts a service announcement using the current wall-clock time as the
     * wire-format timestamp.
     *
     * **Callers that have a [ServiceRegistration] handle MUST prefer
     * [ServiceRegistrationImpl.broadcastSafely]** instead of calling this method
     * directly: `broadcastSafely` captures the active state and the timestamp
     * under a per-registration lock that is also taken by
     * [ServiceRegistrationImpl.unregister], closing the check-then-act race
     * against [ServiceRegistrationImpl.unregister]. There is no compile-time or
     * runtime enforcement here — bypass costs the race back.
     *
     * Direct callers of this method are reserved for paths that legitimately
     * have no registration handle — e.g. alias announcements issued from
     * `joinNetwork` that are not recorded in the local service registry, or
     * relay-side rebroadcast forwarders. Those callers must own their own
     * atomicity.
     *
     * The default implementation calls [broadcastAnnouncementAtTimestamp] with
     * `System.currentTimeMillis()`. Implementations that need a different
     * timestamp policy for this path (for example, UrlResolver's node-wide
     * monotonic lifecycle allocator, which keeps a legitimate alias
     * re-registration newer than prior lifecycle events) should override this method.
     *
     * @return Number of peers the announcement was sent to.
     */
    fun broadcastAnnouncement(
        serviceUrl: String,
        serviceIdentifier: String,
        providerPeerId: String,
        providerMultiaddresses: List<String>,
        stunAddresses: List<String>,
        turnServers: List<TurnServerInfo>,
        metadata: Map<String, String>,
        ttl: Int
    ): Int = broadcastAnnouncementAtTimestamp(
        serviceUrl, serviceIdentifier, providerPeerId, providerMultiaddresses,
        stunAddresses, turnServers, metadata, ttl, System.currentTimeMillis()
    )

    /**
     * Broadcasts a service withdrawal with an explicit, pre-captured wall-clock
     * timestamp.
     *
     * This is the **primary** method on the interface — every implementation MUST
     * override it. [ServiceRegistrationImpl.unregister] routes through this method
     * with a timestamp it has captured under the per-registration lock that is
     * also taken by [ServiceRegistrationImpl.broadcastSafely]. Implementations
     * MUST use the supplied [timestamp] as the withdrawal's wire-format
     * timestamp rather than generating their own at broadcast time.
     *
     * See [broadcastAnnouncementAtTimestamp] for the rationale behind making the
     * timestamp-bearing method the abstract one.
     */
    fun broadcastWithdrawalAtTimestamp(
        serviceUrl: String,
        serviceIdentifier: String,
        providerPeerId: String,
        timestamp: Long
    )

    /**
     * Broadcasts a service withdrawal using the current wall-clock time as the
     * wire-format timestamp.
     *
     * **Callers that have a [ServiceRegistration] handle MUST prefer
     * [ServiceRegistration.unregister]** instead of calling this method directly.
     * `unregister` captures the withdrawal timestamp under a per-registration
     * lock and routes through [broadcastWithdrawalAtTimestamp]; direct calls to
     * this method bypass that lock and re-open the resurrection race against any
     * concurrent [ServiceRegistrationImpl.broadcastSafely] on the same
     * registration.
     *
     * The default implementation calls [broadcastWithdrawalAtTimestamp] with
     * `System.currentTimeMillis()`.
     */
    fun broadcastWithdrawal(
        serviceUrl: String,
        serviceIdentifier: String,
        providerPeerId: String
    ) = broadcastWithdrawalAtTimestamp(
        serviceUrl, serviceIdentifier, providerPeerId, System.currentTimeMillis()
    )
}

/**
 * Optional capability for [ServiceBroadcaster] implementations that retain the
 * highest lifecycle timestamp issued across registration objects.
 *
 * [ServiceRegistrationImpl] discovers this capability with a safe cast and uses a
 * `0L` fallback when it is absent. Keeping this method off [ServiceBroadcaster] is
 * intentionally binary-compatible with implementations compiled against UrlProtocol
 * 0.0.349 (and earlier releases with the same timestamp-bearing method contract): those
 * existing classes still satisfy [ServiceBroadcaster] and never receive a call to a
 * newly-added abstract JVM method. Implementors that provide this capability must return
 * a non-decreasing high-water mark covering both announcements and withdrawals; forgetting
 * or lowering history breaks ordering across replacement registrations.
 */
interface LifecycleTimestampHistoryServiceBroadcaster {
    fun lastIssuedLifecycleTimestamp(
        serviceIdentifier: String,
        providerPeerId: String
    ): Long
}

/**
 * Registry for locally registered services.
 * Maps service identifiers to their handlers.
 *
 * This class is used by UrlResolver to track local service registrations. It is public
 * to allow UrlResolver to be defined in a separate module (foundation.url:resolver).
 */
class LocalServiceRegistry {
    private val services = ConcurrentHashMap<String, ServiceRegistrationImpl>()

    /**
     * Registers a service handler.
     */
    fun register(registration: ServiceRegistrationImpl) {
        services[registration.serviceIdentifier] = registration
    }

    /**
     * Unregisters a service.
     */
    fun unregister(serviceIdentifier: String) {
        services.remove(serviceIdentifier)
    }

    /**
     * Gets a registered service by identifier.
     */
    fun get(serviceIdentifier: String): ServiceRegistrationImpl? {
        return services[serviceIdentifier]
    }

    /**
     * Gets all registered services.
     */
    fun getAll(): List<ServiceRegistrationImpl> {
        return services.values.toList()
    }

    /**
     * Gets all service identifiers.
     */
    fun getServiceIdentifiers(): Set<String> {
        return services.keys.toSet()
    }

    /**
     * Checks if a service is registered.
     */
    fun hasService(serviceIdentifier: String): Boolean {
        return services.containsKey(serviceIdentifier)
    }

    /**
     * Number of registered services.
     */
    val size: Int
        get() = services.size
}

/**
 * RPC request handler that routes requests to registered services.
 *
 * This class is used by UrlResolver to handle incoming RPC requests for locally
 * registered services. It is public to allow UrlResolver to be defined in a
 * separate module (foundation.url:resolver).
 */
class ServiceRoutingHandler(
    private val localServices: LocalServiceRegistry
) : RpcRequestHandler {

    override suspend fun handleRequest(
        request: Libp2pRpcProtocol.RpcRequest,
        effectHandler: EffectPropagator
    ): Libp2pRpcProtocol.RpcResponse {
        return try {
            // Handle bytecode request specially
            if (request.method == BytecodeProtocol.METHOD_BYTECODE_REQUEST) {
                return handleBytecodeRequest(request)
            }

            // Extract service identifier and path from the method
            // Method format: "serviceIdentifier/path" or just "serviceIdentifier"
            val parts = request.method.split("/", limit = 2)
            val serviceIdentifier = parts[0]
            val path = if (parts.size > 1) parts[1] else ""

            val service = localServices.get(serviceIdentifier)
                ?: return Libp2pRpcProtocol.RpcResponse.error(
                    request.id,
                    Libp2pRpcProtocol.ERROR_UNKNOWN_METHOD,
                    "No service registered for identifier: $serviceIdentifier"
                )

            if (!service.isActive) {
                return Libp2pRpcProtocol.RpcResponse.error(
                    request.id,
                    Libp2pRpcProtocol.ERROR_INTERNAL,
                    "Service '$serviceIdentifier' is not active"
                )
            }

            // The transport hands us a per-connection EffectPropagator that is
            // also the server→client push channel for this exact client
            // connection (RpcServerMessageHandler's effect propagator, or
            // TcpServer's per-connection propagator). Expose it to a
            // ConnectionAwareServiceHandler so it can push unsolicited frames and
            // observe connection death. A plain EffectPropagator (e.g. a test
            // stub, or an old transport) is not a ServiceClientConnection, so
            // `connection` is null and dispatch is unchanged for old handlers.
            val connection = effectHandler as? ServiceClientConnection
            val result = try {
                service.handleRequest(path, request.params, request.metadata, connection)
            } catch (e: Exception) {
                // The service's own handler threw: this is the application-failure boundary, so
                // the response also carries the exception's type (codes and text are unchanged).
                return Libp2pRpcProtocol.RpcResponse(
                    id = request.id,
                    result = null,
                    error = if (e is IllegalArgumentException) {
                        applicationFailureRpcError(
                            e, Libp2pRpcProtocol.ERROR_INVALID_PARAMS, e.message ?: "Invalid parameters"
                        )
                    } else {
                        applicationFailureRpcError(e, Libp2pRpcProtocol.ERROR_INTERNAL, e.message ?: "Internal error")
                    }
                )
            }
            Libp2pRpcProtocol.RpcResponse.success(request.id, result)
        } catch (e: IllegalArgumentException) {
            Libp2pRpcProtocol.RpcResponse.error(
                request.id,
                Libp2pRpcProtocol.ERROR_INVALID_PARAMS,
                e.message ?: "Invalid parameters"
            )
        } catch (e: Exception) {
            Libp2pRpcProtocol.RpcResponse.error(
                request.id,
                Libp2pRpcProtocol.ERROR_INTERNAL,
                e.message ?: "Internal error"
            )
        }
    }

    /**
     * Handles a bytecode request from a client wanting sandboxed execution.
     *
     * If the handler supports sandboxed execution (has local JAR bytes), uses the
     * optimized path. Otherwise, falls back to forwarding the request through
     * handleRequest() and translating the response keys to BytecodeProtocol format.
     * This avoids materializing multi-megabyte JAR byte arrays in proxy services
     * like ContainerNursery.
     */
    private suspend fun handleBytecodeRequest(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse {
        try {
            // Parse the bytecode request from params
            val payload = request.params["payload"]?.toString()
                ?: return Libp2pRpcProtocol.RpcResponse.error(
                    request.id,
                    Libp2pRpcProtocol.ERROR_INVALID_PARAMS,
                    "Missing 'payload' in bytecode request"
                )

            val bytecodeRequest = BytecodeProtocol.parseRequest(payload)
            val serviceIdentifier = bytecodeRequest.serviceIdentifier

            // Find the service
            val service = localServices.get(serviceIdentifier)
                ?: return Libp2pRpcProtocol.RpcResponse.error(
                    request.id,
                    Libp2pRpcProtocol.ERROR_UNKNOWN_METHOD,
                    "No service registered for identifier: $serviceIdentifier"
                )

            if (!service.isActive) {
                return Libp2pRpcProtocol.RpcResponse.error(
                    request.id,
                    Libp2pRpcProtocol.ERROR_INTERNAL,
                    "Service '$serviceIdentifier' is not active"
                )
            }

            // Conditional request (the url:// analogue of HTTP If-None-Match): a handler with a
            // precomputed digest can answer without materializing its implementation JAR.
            val cachedDigest = bytecodeRequest.cachedDigest
            if (cachedDigest != null) {
                val currentDigest = service.getImplementationJarDigest()
                if (currentDigest != null && currentDigest == cachedDigest) {
                    return Libp2pRpcProtocol.RpcResponse.success(
                        request.id,
                        BytecodeProtocol.createNotModifiedResponse(currentDigest)
                    )
                }
            }

            val jarBytes = service.getImplementationJar()
            val implClassName = service.getImplementationClassName()
            if (jarBytes != null && implClassName != null) {
                // Optimized path: handler has the bytecode locally.
                // We deliberately do NOT consult ServiceHandler.getStdlibJar() and
                // do NOT include stdlib bytes in the response. Sandbox isolation
                // requires the consumer to load its own bundled /stdlib.jar — see
                // UrlResolver #506 (consumer-side trust boundary) and
                // ServiceHandler.getStdlibJar's deprecation notice.
                // Return a streaming marker rather than eagerly building the full
                // base64 String + inner JSON String + outer JSON String + encoded
                // byte[] (~5× the JAR in transient heap). The stream-write sites
                // recognise StreamingBytecodeResponse and choose either a raw binary
                // attachment or the bounded legacy base64 writer according to the
                // transport's capabilities. See BytecodeResponseStreamer and the
                // production OOM it fixes (a -Xmx128m service JVM serving its own
                // 1.7–2.4 MB bytecode under concurrent load).
                return Libp2pRpcProtocol.RpcResponse.success(
                    request.id,
                    StreamingBytecodeResponse(
                        requestId = request.id,
                        jarBytes = jarBytes,
                        implClassName = implClassName
                    )
                )
            }

            // Fallback: forward __bytecode_request through handleRequest() and translate
            // the backend's response keys to BytecodeProtocol format. This avoids
            // materializing JAR bytes as ByteArray in proxy services.
            //
            // request.metadata MUST be forwarded: for a path-based URL like
            // url://lambdaserver/functions/{id} the resolver attaches resourcePath="functions/{id}"
            // to the request metadata so the provider serves the per-resource client impl
            // (e.g. FunctionDefinitionClientImpl) rather than the generic service client. A direct
            // url-bind provider reads request.metadata itself (LambdaServer #56), but a PROXY
            // provider (ContainerNursery's UrlFacade) only learns the resourcePath if we hand it the
            // request's metadata here. Dropping it (passing emptyMap()) made the proxy forward empty
            // metadata to its backend, which then served the generic client impl, so every
            // GithubWatchman -> url://lambdaserver/functions/{id} callback threw
            // NoSuchMethodError (LambdaServiceClientImpl.invoke) in the sandbox.
            //
            // cachedDigest is intentionally NOT honored on this path: answering a
            // conditional request would require base64-decoding the backend's JAR
            // payload to hash it, materializing the multi-megabyte byte array this
            // path exists to avoid. Proxied services therefore always serve the
            // full payload; the conditional optimization applies to services that
            // hold their own bytecode (the optimized path above).
            val result = service.handleRequest(
                BytecodeProtocol.METHOD_BYTECODE_REQUEST,
                emptyMap(),
                request.metadata
            )

            val responsePayload = translateBackendBytecodeResponse(result, serviceIdentifier)
            return Libp2pRpcProtocol.RpcResponse.success(request.id, responsePayload)

        } catch (e: SandboxException) {
            return Libp2pRpcProtocol.RpcResponse.error(
                request.id,
                Libp2pRpcProtocol.ERROR_INTERNAL,
                "Sandbox error: ${e.message}"
            )
        } catch (e: Exception) {
            return Libp2pRpcProtocol.RpcResponse.error(
                request.id,
                Libp2pRpcProtocol.ERROR_INTERNAL,
                "Error processing bytecode request: ${e.message}"
            )
        }
    }

    /**
     * Translates a backend bytecode response to BytecodeProtocol format.
     *
     * Backend services use keys: "jar", "className"
     * BytecodeProtocol uses keys: "jarBytes", "implClassName"
     *
     * The base64-encoded values are passed through without decoding, avoiding
     * materialization of multi-megabyte JAR byte arrays.
     *
     * Note: any "stdlibJar" key in the backend response is intentionally
     * dropped — the consumer's bundled `/stdlib.jar` is the only stdlib it
     * trusts (UrlResolver #506), so forwarding remote stdlib bytes would
     * defeat sandbox isolation.
     */
    private fun translateBackendBytecodeResponse(result: Any?, serviceIdentifier: String): Any {
        return when (result) {
            is ForwardedStreamingBytecodeResponse -> result
            is String -> {
                // HTTP transport returns the response body as a JSON string
                // A backend that serves its bytecode via the framework streaming path
                // (StreamingBytecodeResponse -> writeStreamingBytecodeResponse) already returns
                // the FINAL BytecodeProtocol response. Pass it through unchanged: the legacy
                // {jar,className} -> {jarBytes,implClassName} key translation does not apply and
                // would throw on the renamed keys. Its writer-owned fixed prefix lets us identify
                // it without JSONObject scanning/copying the multi-megabyte jarBytes value.
                if (isCanonicalStreamedBytecodeResponse(result)) {
                    result
                } else {
                    // Non-canonical final responses from older producers and small control frames
                    // retain arbitrary JSON key order, so parse them for wire compatibility.
                    val json = JSONObject(result)
                    if (json.has("jarBytes")) {
                        normalizeBytecodeProtocolResponse(json, serviceIdentifier, result)
                    } else if (isAlreadyBytecodeProtocolResponse(json)) result
                    else BytecodeProtocol.createResponseFromBase64(
                        jarBase64 = json.getString("jar"),
                        implClassName = json.getString("className")
                    )
                }
            }
            is Map<*, *> -> {
                // RPC transport returns a deserialized Map
                if (result.containsKey("jarBytes")) {
                    // A binary-capable RPC hop can leave the raw ByteArray in this Map. Normalize
                    // it before serializing the response so the next hop sees the public base64
                    // String form instead of the codec's nested bytes marker.
                    normalizeBytecodeProtocolMap(result, serviceIdentifier)
                } else if (isAlreadyBytecodeProtocolResponse(JSONObject(result))) {
                    // A final BytecodeProtocol notModified frame (conditional revalidation) that
                    // carries no jarBytes payload — forward it unchanged, mirroring the
                    // String/JSONObject/InputStream arms. Re-serialize the Map to its wire JSON
                    // string (org.json preserves the boolean/string values; key order is
                    // irrelevant to BytecodeProtocol.parseConditionalResponse).
                    JSONObject(result).toString()
                } else {
                    val jarBase64 = result["jar"] as? String
                        ?: throw RuntimeException(
                            "Backend bytecode response for service '$serviceIdentifier' is missing 'jar' key. " +
                            "Got keys: ${result.keys}"
                        )
                    val className = result["className"] as? String
                        ?: throw RuntimeException(
                            "Backend bytecode response for service '$serviceIdentifier' is missing 'className' key. " +
                            "Got keys: ${result.keys}"
                        )
                    BytecodeProtocol.createResponseFromBase64(
                        jarBase64 = jarBase64,
                        implClassName = className
                    )
                }
            }
            is JSONObject -> {
                if (result.has("jarBytes")) {
                    normalizeBytecodeProtocolResponse(result, serviceIdentifier)
                } else if (isAlreadyBytecodeProtocolResponse(result)) result.toString()
                else BytecodeProtocol.createResponseFromBase64(
                    jarBase64 = result.getString("jar"),
                    implClassName = result.getString("className")
                )
            }
            is java.io.InputStream -> {
                // Streaming HTTP transport returns an InputStream (e.g. from
                // ContainerNursery's forwardViaHttp which uses HttpURLConnection).
                // The public return contract requires a String, but the canonical streaming
                // prefix still avoids a second full-payload JSON parse after that read.
                val responseStr = result.bufferedReader().use { it.readText() }
                if (isCanonicalStreamedBytecodeResponse(responseStr)) {
                    responseStr
                } else {
                    val json = JSONObject(responseStr)
                    if (json.has("jarBytes")) {
                        normalizeBytecodeProtocolResponse(json, serviceIdentifier, responseStr)
                    } else if (isAlreadyBytecodeProtocolResponse(json)) responseStr
                    else BytecodeProtocol.createResponseFromBase64(
                        jarBase64 = json.getString("jar"),
                        implClassName = json.getString("className")
                    )
                }
            }
            else -> throw RuntimeException(
                "Unexpected bytecode response type from service '$serviceIdentifier': " +
                "${result?.javaClass?.name}. Expected a JSON String, Map, JSONObject, or InputStream."
            )
        }
    }

}
