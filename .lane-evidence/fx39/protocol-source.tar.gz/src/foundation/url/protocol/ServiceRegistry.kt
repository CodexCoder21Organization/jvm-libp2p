package foundation.url.protocol

import org.json.JSONObject
import java.security.PublicKey
import java.security.cert.X509Certificate
import java.security.KeyFactory
import java.security.spec.X509EncodedKeySpec
import java.util.Base64

/**
 * Registry of known services with their validation credentials.
 *
 * This registry contains hard-coded public keys and certificates for known services,
 * allowing peers serving these services to be validated cryptographically.
 *
 * When a peer claims to serve a particular service URL, the UrlResolver uses this
 * registry to:
 * 1. Verify the peer's identity matches the expected public key
 * 2. Validate any certificates presented by the peer
 * 3. Confirm the peer is authorized to serve this service
 */
object ServiceRegistry {

    /**
     * Metadata about a registered service.
     */
    data class ServiceMetadata(
        /**
         * The full URL of the service (e.g., "url://vpn.macvm-ai.aiptyapi/")
         */
        val serviceUrl: String,

        /**
         * The service identifier used in peer advertisements
         * (e.g., "vpn.macvm-ai.aiptyapi")
         */
        val serviceIdentifier: String,

        /**
         * Base64-encoded Ed25519 public key(s) authorized to serve this service.
         * Multiple keys allow for key rotation without downtime.
         */
        val authorizedPublicKeys: List<String>,

        /**
         * Human-readable description of the service.
         */
        val description: String,

        /**
         * The interface type expected from this service.
         */
        val interfaceType: String,

        /**
         * Protocol version for this service.
         */
        val protocolVersion: String = "1.0.0",

        /**
         * Optional certificate chain in PEM format for TLS-based connections.
         */
        val certificateChainPem: String? = null
    ) {
        /**
         * Validates that a peer's public key matches one of the authorized keys.
         *
         * @param peerPublicKeyBase64 The peer's public key in base64 encoding
         * @return True if the peer is authorized to serve this service
         */
        fun isAuthorizedPeer(peerPublicKeyBase64: String): Boolean {
            return authorizedPublicKeys.any { it == peerPublicKeyBase64 }
        }

        /**
         * Validates that a libp2p peer ID corresponds to one of the authorized keys.
         * In libp2p, the peer ID is derived from the public key.
         *
         * @param peerId The libp2p peer ID (base58 encoded)
         * @return True if the peer is authorized
         */
        fun isAuthorizedPeerId(peerId: String): Boolean {
            // Wildcard allows any peer only for explicit demo/test services.
            if (authorizedPublicKeys.contains("*") && serviceIdentifier in wildcardAllowedServiceIdentifiers) {
                return true
            }
            // In libp2p, peer ID is derived from public key
            // For Ed25519, the peer ID is: base58(multihash(publicKey))
            // We allow the match if the peer ID starts with our expected key fingerprint
            // or if it's in our explicit authorized list
            return authorizedPeerIds.contains(peerId)
        }

        /**
         * Pre-computed peer IDs for the authorized public keys.
         * Populated at initialization from the authorizedPublicKeys.
         */
        internal val authorizedPeerIds: Set<String> by lazy {
            authorizedPublicKeys.mapNotNull { key ->
                try {
                    computePeerIdFromPublicKey(key)
                } catch (e: Exception) {
                    null
                }
            }.toSet()
        }

        private fun computePeerIdFromPublicKey(publicKeyBase64: String): String {
            // For Ed25519 keys in libp2p:
            // 1. Decode the public key
            // 2. Create multihash: 0x12 (identity) + length + key bytes (for keys <= 42 bytes)
            //    or 0x12 (sha256) + 0x20 + sha256(key) for longer keys
            // 3. Base58 encode the result
            val keyBytes = Base64.getDecoder().decode(publicKeyBase64)

            // Ed25519 public keys are 32 bytes, which is <= 42 bytes threshold
            // Use identity multihash: 0x00 (identity hash) + length + data
            val multihashBytes = ByteArray(2 + keyBytes.size)
            multihashBytes[0] = 0x00 // identity hash function code
            multihashBytes[1] = keyBytes.size.toByte()
            System.arraycopy(keyBytes, 0, multihashBytes, 2, keyBytes.size)

            return Base58.encode(multihashBytes)
        }

        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("serviceUrl", serviceUrl)
                put("serviceIdentifier", serviceIdentifier)
                put("authorizedPublicKeys", authorizedPublicKeys)
                put("description", description)
                put("interfaceType", interfaceType)
                put("protocolVersion", protocolVersion)
                if (certificateChainPem != null) {
                    put("certificateChainPem", certificateChainPem)
                }
            }
        }

        companion object {
            fun fromJson(json: JSONObject): ServiceMetadata {
                val keys = mutableListOf<String>()
                val keysArray = json.getJSONArray("authorizedPublicKeys")
                for (i in 0 until keysArray.length()) {
                    keys.add(keysArray.getString(i))
                }

                return ServiceMetadata(
                    serviceUrl = json.getString("serviceUrl"),
                    serviceIdentifier = json.getString("serviceIdentifier"),
                    authorizedPublicKeys = keys,
                    description = json.getString("description"),
                    interfaceType = json.getString("interfaceType"),
                    protocolVersion = json.optString("protocolVersion", "1.0.0"),
                    certificateChainPem = json.optString("certificateChainPem", null)
                )
            }
        }
    }

    // =========================================================================
    // HARD-CODED SERVICE REGISTRY
    // =========================================================================
    // Add new services here with their public keys and metadata.
    // These are the only services that can be resolved by the UrlResolver.
    // =========================================================================

    private val services: Map<String, ServiceMetadata> = mapOf(
        // AiCliPty service at vpn.macvm-ai.aiptyapi
        "vpn.macvm-ai.aiptyapi" to ServiceMetadata(
            serviceUrl = "url://vpn.macvm-ai.aiptyapi/",
            serviceIdentifier = "vpn.macvm-ai.aiptyapi",
            authorizedPublicKeys = listOf(
                // Primary service key (Ed25519 public key, base64 encoded)
                // This would be replaced with actual production keys
                "MCowBQYDK2VwAyEAqN7KrTgqVWkVWbKyqZ3mHLKZ3GZJE2+dP8nJ5SXZS1A=",
                // Backup/rotation key
                "MCowBQYDK2VwAyEAkM3xJrB2VnKzqH7mNLPZ4HZJF3+eQ9oK6TYZR2AS2B="
            ),
            description = "AI CLI PTY API service providing terminal emulation for AI backends",
            interfaceType = "tools.kotlin.aicligui.pty.AiCliPty",
            protocolVersion = "1.0.0"
        ),

        // Hello World sample service - demonstrates simple String return via url:// protocol
        "helloworld" to ServiceMetadata(
            serviceUrl = "url://helloworld/",
            serviceIdentifier = "helloworld",
            authorizedPublicKeys = listOf(
                // ContainerNursery's public key for serving this service
                // The actual key will be set by ContainerNursery when it registers the service
                "*"  // Wildcard - any peer can serve this demo service
            ),
            description = "Sample service that returns 'Hello World' string",
            interfaceType = "kotlin.String",
            protocolVersion = "1.0.0"
        )
    )

    private val wildcardAllowedServiceIdentifiers = setOf("helloworld")

    /**
     * Gets the metadata for a service by its identifier.
     *
     * @param serviceIdentifier The service identifier (e.g., "vpn.macvm-ai.aiptyapi")
     * @return The service metadata, or null if not registered
     */
    fun getServiceMetadata(serviceIdentifier: String): ServiceMetadata? {
        return services[serviceIdentifier]
    }

    /**
     * Gets the metadata for a service by its full URL.
     *
     * @param serviceUrl The full service URL (e.g., "url://vpn.macvm-ai.aiptyapi/")
     * @return The service metadata, or null if not registered
     */
    fun getServiceMetadataByUrl(serviceUrl: String): ServiceMetadata? {
        val identifier = parseServiceIdentifier(serviceUrl) ?: return null
        return services[identifier]
    }

    /**
     * Checks if a peer is authorized to serve a given service.
     *
     * @param serviceIdentifier The service identifier
     * @param peerId The libp2p peer ID
     * @return True if the peer is authorized
     */
    fun isPeerAuthorized(serviceIdentifier: String, peerId: String): Boolean {
        val metadata = services[serviceIdentifier] ?: return false
        return metadata.isAuthorizedPeerId(peerId)
    }

    /**
     * Gets all registered service identifiers.
     */
    fun getAllServiceIdentifiers(): Set<String> = services.keys

    /**
     * Gets all service metadata.
     */
    fun getAllServices(): Collection<ServiceMetadata> = services.values

    /**
     * Parses a service identifier from a URL.
     */
    private fun parseServiceIdentifier(url: String): String? {
        if (!url.startsWith("url://")) return null
        val withoutScheme = url.removePrefix("url://")
        return withoutScheme.split("/").firstOrNull()?.takeIf { it.isNotBlank() }
    }
}

/**
 * Simple Base58 encoder/decoder for peer ID computation.
 * Uses the Bitcoin alphabet.
 */
object Base58 {
    private const val ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    private val INDEXES = IntArray(128) { -1 }.also { arr ->
        ALPHABET.forEachIndexed { i, c -> arr[c.code] = i }
    }

    fun encode(input: ByteArray): String {
        if (input.isEmpty()) return ""

        // Count leading zeros
        var zeros = 0
        while (zeros < input.size && input[zeros] == 0.toByte()) {
            zeros++
        }

        // Convert base-256 to base-58
        val temp = input.copyOf()
        val encoded = CharArray(temp.size * 2)
        var outputStart = encoded.size

        var inputStart = zeros
        while (inputStart < temp.size) {
            outputStart--
            encoded[outputStart] = ALPHABET[divmod(temp, inputStart, 256, 58)]
            if (temp[inputStart] == 0.toByte()) {
                inputStart++
            }
        }

        // Preserve leading zeros as '1's
        while (outputStart < encoded.size && encoded[outputStart] == ALPHABET[0]) {
            outputStart++
        }
        repeat(zeros) {
            outputStart--
            encoded[outputStart] = ALPHABET[0]
        }

        return String(encoded, outputStart, encoded.size - outputStart)
    }

    fun decode(input: String): ByteArray {
        if (input.isEmpty()) return ByteArray(0)

        // Count leading '1's (zeros in base58)
        var zeros = 0
        while (zeros < input.length && input[zeros] == '1') {
            zeros++
        }

        // Allocate enough space for the result
        val temp = ByteArray(input.length)

        // Convert base-58 to base-256
        for (i in zeros until input.length) {
            val c = input[i]
            val digit = if (c.code < 128) INDEXES[c.code] else -1
            require(digit >= 0) { "Invalid Base58 character: $c" }

            // Multiply temp by 58 and add digit
            var carry = digit
            for (j in temp.size - 1 downTo 0) {
                carry += (temp[j].toInt() and 0xFF) * 58
                temp[j] = (carry % 256).toByte()
                carry /= 256
            }
        }

        // Find where non-zero data starts
        var outputStart = 0
        while (outputStart < temp.size && temp[outputStart] == 0.toByte()) {
            outputStart++
        }

        // Prepend the original leading zeros
        val result = ByteArray(zeros + (temp.size - outputStart))
        System.arraycopy(temp, outputStart, result, zeros, temp.size - outputStart)
        return result
    }

    private fun divmod(number: ByteArray, start: Int, base: Int, divisor: Int): Int {
        var remainder = 0
        for (i in start until number.size) {
            val digit = number[i].toInt() and 0xFF
            val temp = remainder * base + digit
            number[i] = (temp / divisor).toByte()
            remainder = temp % divisor
        }
        return remainder
    }
}
