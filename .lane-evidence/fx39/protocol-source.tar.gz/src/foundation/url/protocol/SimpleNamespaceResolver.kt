package foundation.url.protocol

import java.nio.file.NoSuchFileException

/**
 * A simple implementation of [NamespaceSegmentResolver] for testing and basic use cases.
 *
 * This class allows building namespace hierarchies programmatically by providing
 * maps of child resolvers and objects.
 *
 * ## Example Usage
 *
 * ```kotlin
 * val leafResolver = SimpleNamespaceResolver(
 *     name = "leaf",
 *     objects = mapOf("greeting" to "Hello, World!")
 * )
 * val rootResolver = SimpleNamespaceResolver(
 *     name = "root",
 *     children = mapOf("child" to leafResolver)
 * )
 *
 * NamespaceSegmentResolver.registerRootResolver("myns", rootResolver)
 * val greeting: String = NamespaceSegmentResolver.resolveAndGet("myns.child", "greeting")
 * // greeting == "Hello, World!"
 * ```
 *
 * @param name A descriptive name for this resolver (used in error messages).
 * @param children Map of segment names to child resolvers.
 * @param objects Map of paths to objects available at this resolver level.
 */
class SimpleNamespaceResolver(
    private val name: String,
    private val children: Map<String, NamespaceSegmentResolver> = emptyMap(),
    private val objects: Map<String, Any> = emptyMap()
) : NamespaceSegmentResolver {

    override fun getChildSegmentResolver(segment: String): NamespaceSegmentResolver {
        return children[segment]
            ?: throw NoSuchFileException(
                "No child resolver for segment '$segment' in resolver '$name'. " +
                    "Available children: ${children.keys.sorted().joinToString(", ").ifEmpty { "(none)" }}"
            )
    }

    override fun <T : Any> getObject(path: String, type: Class<T>): T {
        val obj = objects[path]
            ?: throw NoSuchFileException(
                "No object at path '$path' in resolver '$name'. " +
                    "Available paths: ${objects.keys.sorted().joinToString(", ").ifEmpty { "(none)" }}"
            )
        if (!type.isInstance(obj)) {
            throw ClassCastException(
                "Object at path '$path' in resolver '$name' is ${obj::class.java.name}, " +
                    "but expected ${type.name}"
            )
        }
        return type.cast(obj)
    }

    override fun toString(): String = "SimpleNamespaceResolver(name='$name')"
}
