package foundation.url.protocol

import java.io.IOException

/**
 * The stream was closed before this write admitted any bytes.
 *
 * This says nothing about earlier writes. A caller may replay a request only when the rejected
 * write contains its complete frame and no earlier part of that request was admitted. A close
 * after any bytes from this write were admitted must use an ordinary IOException instead.
 */
class StreamClosedBeforeWriteException internal constructor(
    val streamDescription: String,
    message: String,
    cause: IOException?,
) : IOException(message, cause) {
    constructor(streamDescription: String) : this(
        streamDescription, closedBeforeWriteMessage(streamDescription), null
    )

    internal constructor(streamDescription: String, cause: IOException) : this(
        streamDescription, closedBeforeWriteMessage(streamDescription), cause
    )
}

private fun closedBeforeWriteMessage(streamDescription: String): String =
    "Stream '$streamDescription' was closed before write admission; zero bytes were admitted by this write."
