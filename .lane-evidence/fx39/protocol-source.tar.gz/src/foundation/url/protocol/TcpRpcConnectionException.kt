package foundation.url.protocol

import java.io.IOException

/** A failed TCP opening, retaining the intended endpoint and the original I/O cause. */
class TcpRpcConnectionException internal constructor(
    serviceIdentifier: String,
    cause: IOException,
    override val rootLinkDiagnostics: RootLinkDiagnostics,
) : IOException(
    "Failed to open TCP connection for service '$serviceIdentifier': ${cause.message}. $rootLinkDiagnostics",
    cause,
), RootLinkDiagnosticSource
