package foundation.url.protocol

/** The transport event that ended a TCP request before a response was available. */
enum class TcpRpcTransportFailureOrigin(
    /** Whether this stream's close() or releaseAfterForwarding() caused the failure. */
    val closedLocally: Boolean,
    /** Whether the failed operation observed native peer-reset evidence. */
    val peerResetObserved: Boolean,
) {
    /** The peer ended its output normally before sending a response. */
    CLEAN_EOF(closedLocally = false, peerResetObserved = false),

    /** The read or write that failed observed a native reset or broken-pipe condition. */
    PEER_RESET(closedLocally = false, peerResetObserved = true),

    /** This stream's close() or releaseAfterForwarding() ended the operation. */
    LOCAL_CLOSE(closedLocally = true, peerResetObserved = false),

    /** An I/O failure ended the operation without clean-EOF, reset, or local-close evidence. */
    IO_FAILURE(closedLocally = false, peerResetObserved = false),
}

/** A TCP request result retaining whether it came from the peer or this transport. */
sealed class TcpRpcRequestOutcome {
    abstract val response: Libp2pRpcProtocol.RpcResponse

    /** A decoded peer response, including application errors with transport-like messages. */
    data class Response(override val response: Libp2pRpcProtocol.RpcResponse) : TcpRpcRequestOutcome()

    /** Writing this request failed with an I/O error on this connection. */
    data class RequestSendFailed(
        override val response: Libp2pRpcProtocol.RpcResponse,
        /** The immutable cause captured when the write failed. */
        val origin: TcpRpcTransportFailureOrigin,
    ) : TcpRpcRequestOutcome() {
        val closedLocally: Boolean get() = origin.closedLocally
        val peerResetObserved: Boolean get() = origin.peerResetObserved
    }

    /** This stream ended before a response was selected. */
    data class StreamClosed(
        override val response: Libp2pRpcProtocol.RpcResponse,
        /** The immutable cause captured when the read side ended. */
        val origin: TcpRpcTransportFailureOrigin,
    ) : TcpRpcRequestOutcome() {
        val closedLocally: Boolean get() = origin.closedLocally
        val peerResetObserved: Boolean get() = origin.peerResetObserved
    }

    /** Response admission was refused, or the wait completed without a selected response. */
    data class ResponseUnavailable(override val response: Libp2pRpcProtocol.RpcResponse) : TcpRpcRequestOutcome()

    /** This stream's own response wait expired, rather than an application returning TIMEOUT. */
    data class LocalDeadlineExpired(override val response: Libp2pRpcProtocol.RpcResponse) : TcpRpcRequestOutcome()
}
