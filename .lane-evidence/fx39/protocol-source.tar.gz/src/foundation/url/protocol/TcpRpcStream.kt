package foundation.url.protocol

import java.io.InputStream
import java.io.OutputStream
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/**
 * Implementation of [RpcStream] that uses raw TCP sockets.
 *
 * This class provides bidirectional RPC communication over a plain TCP connection,
 * using the same length-prefixed JSON message format as [Libp2pRpcStream] but
 * without the libp2p overhead. This is useful for local communication between
 * a container and the facade provider.
 *
 * The localhost.tcp domain pattern (e.g., `url://localhost.tcp:8080/`) uses this
 * stream implementation instead of libp2p.
 *
 * @property socket The underlying TCP socket.
 * @property remotePeerId A synthetic peer ID (for TCP, this is typically "localhost:PORT").
 * @property serviceIdentifier The service identifier this stream is connected to.
 */
class TcpRpcStream private constructor(
    private val socket: Socket,
    override val remotePeerId: String,
    override val serviceIdentifier: String,
    private val responseClock: community.kotlin.clocks.simple.Clock,
    private val opening: TcpLinkOpening,
    responseReader: RpcResponseReader,
) : RpcResponseReaderOwnership, RootLinkDiagnosticSource {
    override val ownsResponseReader: Boolean = responseReader == RpcResponseReader.AUTOMATIC
    private val transportClosed = AtomicBoolean(false)
    private val transportCloseLock = Any()
    private val readerInterruptRequested = AtomicBoolean(false)

    @JvmOverloads constructor(
        socket: Socket,
        remotePeerId: String,
        serviceIdentifier: String,
        responseClock: community.kotlin.clocks.simple.Clock = community.kotlin.clocks.simple.SystemClock(),
    ) : this(socket, remotePeerId, serviceIdentifier, responseClock,
        newTcpLinkOpening(serviceIdentifier, "socket handoff", responseClock), RpcResponseReader.AUTOMATIC)

    @JvmOverloads constructor(
        socket: Socket,
        remotePeerId: String,
        serviceIdentifier: String,
        responseReader: RpcResponseReader,
        responseClock: community.kotlin.clocks.simple.Clock = community.kotlin.clocks.simple.SystemClock(),
    ) : this(socket, remotePeerId, serviceIdentifier, responseClock,
        newTcpLinkOpening(serviceIdentifier, "socket handoff", responseClock), responseReader)

    // Capture endpoints while the socket is connected; closing it must not erase its identity.
    private val localEndpoint = socket.localSocketAddress?.toString() ?: "not bound"
    private val remoteEndpoint = socket.remoteSocketAddress?.toString() ?: "not connected"

    override val rootLinkDiagnostics: RootLinkDiagnostics
        get() {
            val origin = readerTerminationOrigin.get()
                ?: if (closedLocally.get()) TcpRpcTransportFailureOrigin.LOCAL_CLOSE
                else if (socket.isClosed) TcpRpcTransportFailureOrigin.IO_FAILURE else null
            val retirementReason = silenceRetirementReason.get()
            return tcpLinkSnapshot(opening, remotePeerId, localEndpoint, remoteEndpoint,
                retirementReason ?: origin?.name ?: "none",
                if (retirementReason != null) "local" else when (origin) {
                    TcpRpcTransportFailureOrigin.LOCAL_CLOSE -> "local"
                    TcpRpcTransportFailureOrigin.CLEAN_EOF, TcpRpcTransportFailureOrigin.PEER_RESET -> "remote"
                    else -> "not observed"
                })
        }

    private val closed = AtomicBoolean(false)
    private val closedLocally = AtomicBoolean(false)
    private val readerTerminationOrigin = AtomicReference<TcpRpcTransportFailureOrigin?>(null)
    private val activeForwardedAttachments = AtomicInteger(0)
    private val activeForwardedInput = AtomicReference<FramedAttachmentInputStream?>(null)
    // The reader's in-flight growable attachment-frame lease, published before it asks for pool
    // admission so that close() settles that admission itself instead of leaving it to a reader
    // that close() does not wait for.
    private val activeGrowingFrameLease = AtomicReference<Libp2pRpcProtocol.FrameAttachmentLease?>(null)
    // The reader's in-flight JSON parse reservation, handed over the same way.
    private val activeJsonReservation = AtomicReference<Libp2pRpcProtocol.JsonFrameReservation?>(null)
    private val pendingRequests = ConcurrentHashMap<String, PendingRequest>()
    // Guards correlation admission, abandoned IDs, inbound activity and silence retirement.
    // Never acquire a request monitor or invoke a clock callback/socket operation under it.
    private val correlationLock = Any()
    private val abandonedRequestTimes = linkedMapOf<String, Long>()
    private var lastInboundFrameAt: Long? = null
    private var silenceGeneration = 0L
    private var silenceTask: community.kotlin.clocks.simple.Scheduled? = null
    private val silenceRetirementReason = AtomicReference<String?>(null)
    private val inboundFrameHandler = AtomicReference<((org.json.JSONObject) -> Unit)?>(null)
    private val inboundFrameQueue = ArrayBlockingQueue<org.json.JSONObject>(INBOUND_FRAME_QUEUE_CAPACITY)
    private val inboundDispatchThread = AtomicReference<Thread?>(null)
    private val readerThread: Thread?

    private val frameAdmission = FrameAdmission()

    init {
        // Frames are written as several segments (length prefix, JSON body, attachments) straight
        // to the socket. With Nagle's algorithm enabled, the segment after the first waits for the
        // peer's delayed ACK while the peer is blocked reading the rest of that same frame, adding
        // ~40 ms to every request/response round trip. An RPC transport must send each segment now.
        socket.tcpNoDelay = true
    }

    private val socketInput: InputStream = socket.getInputStream()
    private val socketOutput: OutputStream = socket.getOutputStream()

    init {
        readerThread = if (ownsResponseReader) {
            thread(name = "TcpRpcStream-Reader-${socket.port}", isDaemon = true) { runReaderLoop() }
        } else null
    }

    private data class PendingRequest(
        val latch: CountDownLatch,
        val raw: Boolean,
        val forwarding: Boolean,
        val response: AtomicReference<TcpRpcRequestOutcome?> = AtomicReference(null),
        var claimed: Boolean = false,
        var abandoned: Boolean = false,
        var expiredAtMillis: Long? = null,
        @Volatile var responseReceived: Boolean = false,
    )

    override val input: InputStream
        get() = socketInput

    override val output: OutputStream = object : OutputStream() {
        override fun write(value: Int) = frameAdmission.withFrame { socketOutput.write(value) }
        override fun write(bytes: ByteArray, offset: Int, length: Int) =
            frameAdmission.withFrame { socketOutput.write(bytes, offset, length) }
        override fun flush() = frameAdmission.withFrame { socketOutput.flush() }
        override fun close() = this@TcpRpcStream.close()
    }

    override val isOpen: Boolean
        get() = !closed.get() && !socket.isClosed

    override fun sendRequest(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        sendRequestWithOutcome(request).response

    private fun sendRequestWithOutcome(
        request: Libp2pRpcProtocol.RpcRequest,
        raw: Boolean = false,
        forwarding: Boolean = false,
    ): TcpRpcRequestOutcome {
        if (!ownsResponseReader) refuseCallerReadRequest(serviceIdentifier)
        if (closed.get() || socket.isClosed) {
            return TcpRpcRequestOutcome.StreamClosed(tcpTransportFailureResponse(
                request.id,
                silenceRetirementReason.get() ?: "Stream closed",
                RpcTransportFailure.Phase.CONNECTION_CLOSED,
                null,
            ), tcpClosedStreamOrigin(readerTerminationOrigin.get(), closedLocally.get()))
        }

        val pending = PendingRequest(CountDownLatch(1), raw, forwarding)
        val refusal = synchronized(correlationLock) {
            if (closed.get() || socket.isClosed) return@synchronized TcpRpcRequestOutcome.StreamClosed(
                tcpTransportFailureResponse(request.id, silenceRetirementReason.get() ?: "Stream closed",
                    RpcTransportFailure.Phase.CONNECTION_CLOSED, null),
                tcpClosedStreamOrigin(readerTerminationOrigin.get(), closedLocally.get()),
            )
            require(!pendingRequests.containsKey(request.id)) {
                "Request ID '${request.id}' is still awaiting a response on TCP service '$serviceIdentifier'; " +
                    "use a new request ID for each outstanding or abandoned request"
            }
            if (pendingRequests.size >= MAX_PENDING_REQUEST_IDS ||
                abandonedRequestTimes.size >= MAX_UNANSWERED_RESERVATIONS) {
                TcpRpcRequestOutcome.ResponseUnavailable(tcpTransportFailureResponse(
                    request.id,
                    "TCP service '$serviceIdentifier' already has ${pendingRequests.size} unanswered request IDs; " +
                        "wait for a response before sending another request",
                    RpcTransportFailure.Phase.RESPONSE_READ,
                    null,
                ))
            } else {
                pendingRequests[request.id] = pending
                null
            }
        }
        if (refusal != null) return refusal

        // Re-check closed after registering to avoid TOCTOU race: the reader thread
        // may have exited and drained pendingRequests between our first check and
        // the put above, so this entry would never be completed.
        if (closed.get()) {
            removeCorrelation(request.id, pending)
            return TcpRpcRequestOutcome.StreamClosed(tcpTransportFailureResponse(
                request.id,
                silenceRetirementReason.get() ?: "Stream closed",
                RpcTransportFailure.Phase.CONNECTION_CLOSED,
                null,
            ), tcpClosedStreamOrigin(readerTerminationOrigin.get(), closedLocally.get()))
        }

        var writeStarted = false
        try {
            val attachments = mutableListOf<ByteArray>()
            // Caller input serialization has not reached the transport and must retain its exception.
            val json = request.toJson(attachments)
            // Caller serialization can re-enter protocol close and wait for other senders, so it
            // runs before the frame lock those senders need. The lock keeps attachment references
            // rather than a full encoded-frame copy for every waiting sender.
            val jsonBytes = jsonWireBytes(json)
            try {
                frameAdmission.withFrame {
                    writeStarted = true
                    // Keep short prefixes and bodies together so each request does not wait
                    // for an extra TCP acknowledgment. Allocate the bounded buffer only for
                    // the admitted writer; queued attachment senders retain no frame copies.
                    val buffered = java.io.BufferedOutputStream(socketOutput)
                    Libp2pRpcProtocol.writeEncodedMessageStreamingAttachments(buffered, jsonBytes, attachments)
                }
            } catch (e: java.io.IOException) {
                if (!writeStarted && e is java.io.InterruptedIOException && e.cause is InterruptedException) {
                    // Admission was interrupted before this frame wrote any byte. Preserve the
                    // caller's abandonment signal instead of describing a healthy socket as failed.
                    throw e.cause as InterruptedException
                }
                val origin = tcpWriteFailureOrigin(e, readerTerminationOrigin.get(), closedLocally.get())
                readerTerminationOrigin.compareAndSet(null, origin)
                // A partly written frame cannot be reused. Preserve the write's original cause
                // before terminal close settles the other callers on this transport.
                close()
                return TcpRpcRequestOutcome.RequestSendFailed(tcpTransportFailureResponse(
                    request.id,
                    "Failed to send request: ${e.message}",
                    RpcTransportFailure.Phase.REQUEST_WRITE,
                    e,
                ), origin)
            }

            val requestId = request.id
            val pendingReference = java.lang.ref.WeakReference(pending)
            val responseDeadlineAt = responseClock.currentTimeMillis() + RESPONSE_DEADLINE_MILLIS
            val deadline = responseClock.schedule(responseDeadlineAt) {
                val current = pendingReference.get() ?: return@schedule
                // The deadline owns only this correlation, never the multiplexed connection.
                val outcome = TcpRpcRequestOutcome.LocalDeadlineExpired(tcpTransportFailureResponse(
                    requestId,
                    "Request timed out after 30 seconds",
                    RpcTransportFailure.Phase.RESPONSE_TIMEOUT,
                    null,
                    code = Libp2pRpcProtocol.ERROR_TIMEOUT,
                ))
                val expired = synchronized(current) {
                    val selected = !current.claimed && !current.abandoned && current.response.compareAndSet(null, outcome)
                    if (selected) current.expiredAtMillis = responseDeadlineAt
                    selected
                }
                if (expired) current.latch.countDown()
            }
            try { pending.latch.await() } finally { responseClock.unschedule(deadline) }

            return synchronized(pending) {
                pending.claimed = true
                pending.response.get() ?: TcpRpcRequestOutcome.ResponseUnavailable(tcpTransportFailureResponse(
                    request.id, "Response was null", RpcTransportFailure.Phase.RESPONSE_READ, null,
                ))
            }
        } finally {
            val unclaimedResponse = synchronized(pending) {
                pending.abandoned = true
                val unclaimed = if (pending.claimed) null else pending.response.get()?.response
                if (writeStarted && !pending.responseReceived && !closed.get()) {
                    // The peer can still owe this ID after a deadline or interruption. Keep only
                    // correlation, never the request payload or a selected response. A late reply
                    // removes this entry; until then a caller must use a different ID.
                    pending.response.set(null)
                } else {
                    removeCorrelation(request.id, pending)
                }
                unclaimed
            }
            val abandonedAt = synchronized(pending) { pending.expiredAtMillis }
                ?: responseClock.currentTimeMillis()
            synchronized(correlationLock) {
                if (pendingRequests[request.id] === pending && !pending.responseReceived && !closed.get()) {
                    abandonedRequestTimes.putIfAbsent(request.id, abandonedAt)
                }
            }
            refreshSilenceRetirement()
            // A selected body still belongs to the reader when its caller leaves before claiming
            // it. Let that reader drain the declared frame; closing the socket would fail siblings.
            (unclaimedResponse?.result as? ForwardedStreamingBytecodeResponse)?.discardUnclaimed()
        }
    }

    /**
     * Sends a raw request while retaining the source of transport errors.
     * An application error remains [TcpRpcRequestOutcome.Response], even if its text equals a
     * local transport error and the peer immediately closes the connection.
     * The response and 30-second deadline are otherwise identical to [sendRequestRaw].
     */
    fun sendRequestRawWithOutcome(request: Libp2pRpcProtocol.RpcRequest): TcpRpcRequestOutcome =
        sendRequestWithOutcome(request, raw = true)

    override fun sendRequestRaw(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        sendRequestRawWithOutcome(request).response

    override fun sendRequestForForwarding(
        request: Libp2pRpcProtocol.RpcRequest,
    ): Libp2pRpcProtocol.RpcResponse = sendRequestForForwardingWithOutcome(request).response

    /**
     * Like [sendRequestForForwarding], retaining the exact [TcpRpcRequestOutcome] selected by the
     * transport. Failure categories, immutable origin, error text and local failure details are
     * the same as [sendRequestRawWithOutcome]; application errors remain peer [TcpRpcRequestOutcome.Response]s.
     *
     * A bytecode response may arrive before its attachment has finished. Register resource
     * release with [ForwardedStreamingBytecodeResponse.onCompletion] before passing that result
     * unchanged to its writer. Other methods retain ordinary raw response handling. Request
     * deadlines, interruption and [releaseAfterForwarding] keep their existing behavior.
     */
    fun sendRequestForForwardingWithOutcome(request: Libp2pRpcProtocol.RpcRequest): TcpRpcRequestOutcome =
        sendRequestWithOutcome(
            request, raw = true,
            forwarding = request.method == foundation.url.protocol.sandbox.BytecodeProtocol.METHOD_BYTECODE_REQUEST,
        )

    override suspend fun sendRequestAsync(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse {
        // For now, delegate to synchronous version
        // TODO: Implement true async with coroutines
        return sendRequest(request)
    }

    /**
     * Installs the optional handler for valid non-response JSON frames read from this TCP stream.
     * Existing callers that never install a handler retain the historical response-only behavior:
     * non-response frames are read and ignored.
     *
     * Delivery is serialized on one daemon worker owned by this stream, never on the socket reader
     * thread. The handoff queue holds at most [INBOUND_FRAME_QUEUE_CAPACITY] frame, so a slow handler
     * makes the reader stop draining the socket. Ordinary TCP backpressure then reaches the server's
     * existing bounded push-write path instead of allowing an unbounded client-side frame backlog.
     * Response correlation continues on the reader thread whenever that bounded handoff has room.
     *
     * A frame that has already been read off the wire is delivered even when the stream then
     * closes. Closing — locally, or because the remote closed the connection after writing — ends
     * the callback lane only after the frames accepted before that close have been handed to the
     * handler, so a peer that pushes frames and immediately disconnects cannot have those frames
     * discarded while the response written behind them is still correlated. A handler can
     * therefore run briefly after [close] returns.
     *
     * The [org.json.JSONObject] is the parsed wire object itself; the dispatcher does not rename,
     * add, or remove fields. Handlers should return promptly and must not retain or mutate a frame
     * after returning unless they first make their own copy.
     */
    fun setInboundFrameHandler(handler: (org.json.JSONObject) -> Unit) {
        inboundFrameHandler.set(handler)
        startInboundDispatcherIfNeeded()
    }

    private fun startInboundDispatcherIfNeeded() {
        if (inboundDispatchThread.get() != null || closed.get()) return
        val candidate = thread(
            start = false,
            name = "TcpRpcStream-Inbound-Dispatch-${socket.port}",
            isDaemon = true
        ) {
            while (true) {
                // Drain the handoff before testing `closed`. A frame the reader already accepted
                // off the wire belongs to the application, so the close that follows it on the
                // same connection must not take it away: the lane ends only once the stream is
                // closed AND nothing accepted before that close is still waiting. Response frames
                // are correlated inline on the reader thread, so ending the lane on `closed`
                // alone would deliver a later response while dropping the earlier pushed frames.
                var frame = inboundFrameQueue.poll()
                if (frame == null) {
                    if (closed.get()) {
                        // Poll a second time before ending the lane. The reader accepts a frame
                        // and only then marks the stream closed, so a frame handed over between
                        // the poll above and this observation of `closed` is already in the
                        // handoff by the time that write becomes visible here. Ending the lane on
                        // the first empty poll would drop exactly that frame.
                        frame = inboundFrameQueue.poll() ?: break
                    } else {
                        frame = try {
                            inboundFrameQueue.take()
                        } catch (_: InterruptedException) {
                            // Closing interrupts this worker only to wake it out of the take
                            // above. Loop back so the poll re-checks the handoff before the
                            // lane ends.
                            continue
                        }
                    }
                }
                val handler = inboundFrameHandler.get() ?: continue
                // This worker is private to the stream, so an interrupt on it is only ever the
                // stream's own close signal. Application callbacks must never inherit it.
                Thread.interrupted()
                try {
                    handler(frame)
                } catch (failure: Throwable) {
                    rethrowFatalJvmError(failure)
                    debugLogErr {
                        "[TcpRpcStream] Inbound frame handler for $serviceIdentifier threw: " +
                            "${failure.javaClass.name}: ${failure.message ?: "no detail message"}"
                    }
                    // The worker is private to this stream. A handler that marks it interrupted
                    // must not make the following queue wait end the callback lane, and must not
                    // pass its interrupt on to the next frame's callback.
                    Thread.interrupted()
                }
            }
        }
        if (inboundDispatchThread.compareAndSet(null, candidate)) {
            candidate.start()
        }
    }

    private fun runReaderLoop() {
        var observedTerminationOrigin: TcpRpcTransportFailureOrigin? = null
        try {
            while (!closed.get() && !socket.isClosed) {
                var forwardedAttachmentSelected = false
                val frame = try {
                    Libp2pRpcProtocol.readMessageFrameFromStream(
                        socketInput,
                        { json ->
                            observeInboundFrame()
                            val consumer = forwardedBytecodeAttachmentConsumer(json)
                            if (consumer != null) {
                                forwardedAttachmentSelected = true
                                activeForwardedAttachments.incrementAndGet()
                            }
                            consumer
                        },
                        ::publishGrowingFrameLease,
                        ::publishJsonReservation,
                    )
                } catch (failure: org.json.JSONException) {
                    // The complete length-delimited frame was consumed even when JSON was invalid.
                    observeInboundFrame()
                    debugLogErr {
                        "[TcpRpcStream] Discarding malformed JSON frame for $serviceIdentifier: " +
                            "${failure.message ?: "no detail message"}"
                    }
                    continue
                } catch (e: java.io.EOFException) {
                    observedTerminationOrigin = TcpRpcTransportFailureOrigin.CLEAN_EOF
                    readerTerminationOrigin.compareAndSet(null, observedTerminationOrigin)
                    break
                } catch (e: java.io.IOException) {
                    observedTerminationOrigin = when {
                        isNativePeerReset(e, includeBrokenPipe = false) ->
                            TcpRpcTransportFailureOrigin.PEER_RESET
                        isLocalSocketClose(e) && closedLocally.get() ->
                            TcpRpcTransportFailureOrigin.LOCAL_CLOSE
                        else -> TcpRpcTransportFailureOrigin.IO_FAILURE
                    }
                    readerTerminationOrigin.compareAndSet(null, observedTerminationOrigin)
                    break
                } finally {
                    activeGrowingFrameLease.set(null)
                    activeJsonReservation.set(null)
                    if (forwardedAttachmentSelected) {
                        activeForwardedInput.set(null)
                        activeForwardedAttachments.decrementAndGet()
                    }
                }
                if (frame != null) {
                    observeInboundFrame()
                    handleIncomingMessage(frame.json, frame.attachments)
                }
            }
        } finally {
            val originAtFailure = observedTerminationOrigin
                ?: tcpClosedStreamOrigin(readerTerminationOrigin.get(), closedLocally.get())
            readerTerminationOrigin.compareAndSet(null, originAtFailure)
            val recordedOrigin = readerTerminationOrigin.get() ?: originAtFailure

            // Mark closed FIRST so that sendRequest() will not register new pending requests
            // after we drain and clear the map below. Also ensures isOpen returns false for
            // stream caching in UrlProtocol.sendServiceRpcRequest().
            synchronized(correlationLock) { closed.set(true) }
            frameAdmission.close(TcpFrameAdmissionClosed(recordedOrigin))
            try {
                closeTransportAndDispatcher()
            } finally {
                // Complete pending requests even when physical cleanup fails.
                for ((id, pending) in pendingRequests) {
                    // A response can be parsed just before EOF reaches this cleanup path. Preserve
                    // that completed response; replacing it with Stream closed races the request
                    // thread after its latch has already been released.
                    pending.response.compareAndSet(
                        null,
                        TcpRpcRequestOutcome.StreamClosed(tcpTransportFailureResponse(
                            id,
                            silenceRetirementReason.get() ?: "Stream closed",
                            RpcTransportFailure.Phase.CONNECTION_CLOSED,
                            null,
                        ), recordedOrigin)
                    )
                    pending.latch.countDown()
                }
                synchronized(correlationLock) {
                    pendingRequests.clear()
                    abandonedRequestTimes.clear()
                }
                refreshSilenceRetirement()
            }
        }
    }

    private fun forwardedBytecodeAttachmentConsumer(
        json: org.json.JSONObject,
    ): SingleAttachmentStreamConsumer? {
        if (json.optString("type", "") != Libp2pRpcProtocol.TYPE_RESPONSE) return null
        if (json.has("error")) return null
        val id = json.optString("id", "")
        val pending = pendingRequests[id] ?: return null
        if (!pending.forwarding) return null
        val result = json.optJSONObject("result") ?: return null
        if (!result.optBoolean("success", false)) return null
        if (result.opt("implClassName") !is String) return null
        val jarReference = result.optJSONObject("jarBytes") ?: return null
        if (jarReference.optString("__type", "") != "binary_ref") return null
        if (jarReference.optInt("__index", -1) != 0) return null

        return SingleAttachmentStreamConsumer { length, input ->
            val rawResponse = Libp2pRpcProtocol.RpcResponse.fromJsonRaw(json)
            input.observeOwnerTerminalState(closed)
            activeForwardedInput.set(input)
            val accepted = synchronized(pending) {
                pending.responseReceived = true
                if (pending.abandoned) removeCorrelation(id, pending)
                if (closed.get() || pending.abandoned || pendingRequests[id] !== pending ||
                    pending.response.get() != null) false
                else {
                    pending.response.set(TcpRpcRequestOutcome.Response(rawResponse.copy(
                        result = ForwardedStreamingBytecodeResponse(result, length, input)
                    )))
                    pending.latch.countDown()
                    true
                }
            }
            refreshSilenceRetirement()
            if (!accepted) input.discardUnclaimed()
        }
    }

    private fun publishGrowingFrameLease(lease: Libp2pRpcProtocol.FrameAttachmentLease) {
        activeGrowingFrameLease.set(lease)
        // close() sets `closed` before it reads the published lease, so either it sees this lease
        // or this check sees `closed`; a lease published after close() looked is closed here.
        if (closed.get()) lease.close()
    }

    private fun publishJsonReservation(reservation: Libp2pRpcProtocol.JsonFrameReservation) {
        activeJsonReservation.set(reservation)
        // Same ordering argument as publishGrowingFrameLease.
        if (closed.get()) reservation.close()
    }

    /** Closes every admission the reader handed over; each close returns after its release. */
    private fun closeReaderAdmissions() {
        try { activeJsonReservation.get()?.close() }
        finally { activeGrowingFrameLease.get()?.close() }
    }

    private fun closeTransportAndDispatcher() {
        synchronized(transportCloseLock) {
            if (!transportClosed.compareAndSet(false, true)) return
            try {
                socket.close()
            } catch (failure: Throwable) {
                // A failed physical close must remain eligible for a later cleanup attempt.
                transportClosed.set(false)
                throw failure
            } finally {
                // Accepted frames still drain; the interrupt wakes a parked dispatcher.
                inboundDispatchThread.get()?.interrupt()
            }
        }
    }

    private fun handleIncomingMessage(json: org.json.JSONObject, attachments: List<ByteArray>) {
        val type = json.optString("type", "")
        if (type == Libp2pRpcProtocol.TYPE_RESPONSE) {
            val id = json.optString("id", "")
            val pending = pendingRequests[id]
            if (pending != null) {
                val decode = synchronized(pending) {
                    pending.responseReceived = true
                    if (pending.abandoned) {
                        removeCorrelation(id, pending)
                        false
                    } else pending.response.get() == null
                }
                if (decode) {
                    // Parsing can scale with the payload; the correlation lock guards only
                    // selection/publication, so a deadline never waits behind that work.
                    val response = if (pending.raw) {
                        Libp2pRpcProtocol.resolveBinaryRefsToBase64(json, attachments)
                        Libp2pRpcProtocol.RpcResponse.fromJsonRaw(json)
                    } else {
                        Libp2pRpcProtocol.RpcResponse.fromJson(json, attachments)
                    }
                    synchronized(pending) {
                        if (!pending.abandoned &&
                            pending.response.compareAndSet(null, TcpRpcRequestOutcome.Response(response))) {
                            pending.latch.countDown()
                        }
                    }
                }
            }
        } else if (inboundFrameHandler.get() != null) {
            try {
                inboundFrameQueue.put(json)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
        refreshSilenceRetirement()
        // Without an opted-in handler, non-response message types are ignored as before.
    }

    private fun removeCorrelation(id: String, pending: PendingRequest) {
        synchronized(correlationLock) {
            if (pendingRequests.remove(id, pending)) abandonedRequestTimes.remove(id)
        }
    }

    private fun observeInboundFrame() {
        val arrivedAt = responseClock.currentTimeMillis()
        synchronized(correlationLock) {
            if (!closed.get()) lastInboundFrameAt = arrivedAt
        }
    }

    private fun refreshSilenceRetirement(expectedGeneration: Long? = null) {
        val now = responseClock.currentTimeMillis()
        var previous: community.kotlin.clocks.simple.Scheduled? = null
        var generation = 0L
        var nextCheck: Long? = null
        var reason: String? = null
        synchronized(correlationLock) {
            if (expectedGeneration != null && expectedGeneration != silenceGeneration) return
            // Activity updates its timestamp without replacing the outstanding timer. Its next
            // firing rechecks liveness, avoiding one cancelled clock task per inbound frame.
            if (expectedGeneration == null && !closed.get() &&
                abandonedRequestTimes.size >= MAX_UNANSWERED_RESERVATIONS && silenceTask != null) return
            previous = silenceTask
            silenceTask = null
            generation = ++silenceGeneration
            if (!closed.get() && abandonedRequestTimes.size >= MAX_UNANSWERED_RESERVATIONS) {
                val earliest = abandonedRequestTimes.values.minOrNull()!!
                val since = maxOf(earliest, lastInboundFrameAt ?: earliest)
                val silence = now - since
                if (silence >= RESPONSE_DEADLINE_MILLIS) {
                    if (!closed.get()) {
                        reason = "TCP service '$serviceIdentifier' retired after ${abandonedRequestTimes.size} " +
                            "unanswered requests and $silence ms without an inbound frame"
                        silenceRetirementReason.set(reason)
                        readerTerminationOrigin.compareAndSet(null, TcpRpcTransportFailureOrigin.IO_FAILURE)
                        closed.set(true)
                    }
                } else {
                    nextCheck = since + RESPONSE_DEADLINE_MILLIS
                }
            }
        }
        previous?.let { responseClock.unschedule(it) }
        if (reason != null) {
            // Terminal selection is ordered with inbound activity. Physical close and result
            // completion happen outside correlationLock, so callbacks can re-enter the stream.
            frameAdmission.close(TcpFrameAdmissionClosed(TcpRpcTransportFailureOrigin.IO_FAILURE))
            for ((id, pending) in pendingRequests) {
                pending.response.compareAndSet(null, TcpRpcRequestOutcome.StreamClosed(
                    tcpTransportFailureResponse(id, reason!!, RpcTransportFailure.Phase.CONNECTION_CLOSED, null),
                    TcpRpcTransportFailureOrigin.IO_FAILURE,
                ))
                pending.latch.countDown()
            }
            try { closeTransportAndDispatcher() }
            finally { interruptRpcReaderOnce(readerThread, readerInterruptRequested) }
        } else if (nextCheck != null) {
            val owner = java.lang.ref.WeakReference(this)
            val scheduled = responseClock.schedule(nextCheck!!) {
                owner.get()?.refreshSilenceRetirement(generation)
            }
            val retained = synchronized(correlationLock) {
                if (!closed.get() && silenceGeneration == generation) {
                    silenceTask = scheduled
                    true
                } else false
            }
            if (!retained) responseClock.unschedule(scheduled)
        }
    }

    override fun releaseAfterForwarding() {
        synchronized(correlationLock) {
            closedLocally.set(true)
            closed.set(true)
        }
        refreshSilenceRetirement()
        frameAdmission.close(TcpFrameAdmissionClosed(
            tcpClosedStreamOrigin(readerTerminationOrigin.get(), closedLocally = true)))
        val attachment = activeForwardedInput.get()
        if (activeForwardedAttachments.get() == 0 || attachment == null || attachment.isAbandoned) {
            try { closeReaderAdmissions() } finally {
                try { closeTransportAndDispatcher() }
                finally { interruptRpcReaderOnce(readerThread, readerInterruptRequested) }
            }
        }
    }

    override fun close() {
        synchronized(correlationLock) {
            closedLocally.set(true)
            closed.set(true)
        }
        refreshSilenceRetirement()
        frameAdmission.close(TcpFrameAdmissionClosed(
            tcpClosedStreamOrigin(readerTerminationOrigin.get(), closedLocally = true)))
        try {
            try { activeForwardedInput.get()?.close() } finally { closeReaderAdmissions() }
        } finally {
            try { closeTransportAndDispatcher() }
            finally { interruptRpcReaderOnce(readerThread, readerInterruptRequested) }
        }
    }

    companion object {
        private const val INBOUND_FRAME_QUEUE_CAPACITY = 1
        // Stop new requests at 64 abandoned IDs. Previously admitted calls can still finish;
        // the existing server handler ceiling bounds all correlations, including their expiries.
        private const val MAX_UNANSWERED_RESERVATIONS = 64
        private const val MAX_PENDING_REQUEST_IDS = TcpServer.DEFAULT_CONCURRENT_HANDLER_LIMIT
        private const val RESPONSE_DEADLINE_MILLIS = 30_000L

        /**
         * Connects to a TCP server and creates an RpcStream.
         *
         * @param host The host to connect to.
         * @param port The port to connect to.
         * @param serviceIdentifier The service identifier for this connection.
         * @return A new TcpRpcStream connected to the server.
         */
        fun connect(host: String, port: Int, serviceIdentifier: String): TcpRpcStream =
            connect(host, port, serviceIdentifier, community.kotlin.clocks.simple.SystemClock())

        /** Uses [responseClock] for each request's existing 30-second response deadline. */
        fun connect(
            host: String,
            port: Int,
            serviceIdentifier: String,
            responseClock: community.kotlin.clocks.simple.Clock,
        ): TcpRpcStream = connect(host, port, serviceIdentifier, RpcResponseReader.AUTOMATIC, responseClock)

        @JvmOverloads fun connect(
            host: String,
            port: Int,
            serviceIdentifier: String,
            responseReader: RpcResponseReader,
            responseClock: community.kotlin.clocks.simple.Clock = community.kotlin.clocks.simple.SystemClock(),
        ): TcpRpcStream {
            val opening = newTcpLinkOpening(serviceIdentifier, "connect", responseClock)
            val socket = Socket()
            try {
                val destination = java.net.InetSocketAddress(host, port)
                try {
                    socket.connect(destination)
                    return TcpRpcStream(socket, "$host:$port", serviceIdentifier, responseClock, opening, responseReader)
                } catch (failure: java.io.IOException) {
                    throw TcpRpcConnectionException(serviceIdentifier, failure,
                        tcpLinkSnapshot(opening, "$host:$port",
                            socket.localSocketAddress?.toString() ?: "not bound",
                            socket.remoteSocketAddress?.toString() ?: destination.toString(),
                            "CONNECT_FAILED", "local"))
                }
            } catch (failure: Throwable) {
                try { socket.close() } catch (cleanupFailure: Throwable) { failure.addSuppressed(cleanupFailure) }
                throw failure
            }
        }
    }
}

/** The admission event owns its origin even if the reader or a later closer changes state. */
private class TcpFrameAdmissionClosed(val origin: TcpRpcTransportFailureOrigin) :
    java.io.IOException("Stream closed")

private fun interruptRpcReaderOnce(reader: Thread?, requested: AtomicBoolean) {
    if (reader != null && requested.compareAndSet(false, true)) reader.interrupt()
}

private fun isNativePeerReset(failure: java.io.IOException, includeBrokenPipe: Boolean): Boolean =
    failure is SocketException && (
        failure.message == "Connection reset" || failure.message == "Connection reset by peer" ||
            (includeBrokenPipe && failure.message == "Broken pipe")
    )

private fun isLocalSocketClose(failure: java.io.IOException): Boolean =
    failure is SocketException && failure.message == "Socket closed"

private fun tcpClosedStreamOrigin(
    recordedReaderOrigin: TcpRpcTransportFailureOrigin?,
    closedLocally: Boolean,
): TcpRpcTransportFailureOrigin = recordedReaderOrigin ?: if (closedLocally) {
    TcpRpcTransportFailureOrigin.LOCAL_CLOSE
} else {
    TcpRpcTransportFailureOrigin.IO_FAILURE
}

private fun tcpWriteFailureOrigin(
    failure: java.io.IOException,
    readerOrigin: TcpRpcTransportFailureOrigin?,
    closedLocally: Boolean,
): TcpRpcTransportFailureOrigin = when {
    failure is TcpFrameAdmissionClosed -> failure.origin
    isNativePeerReset(failure, includeBrokenPipe = true) -> TcpRpcTransportFailureOrigin.PEER_RESET
    readerOrigin != null -> readerOrigin
    isLocalSocketClose(failure) && closedLocally -> TcpRpcTransportFailureOrigin.LOCAL_CLOSE
    else -> TcpRpcTransportFailureOrigin.IO_FAILURE
}

/** Opening values are immutable and do not retain the socket or request data. */
private data class TcpLinkOpening(val identity: String, val openedAtMillis: Long)
private val TCP_LINK_GENERATION = java.util.concurrent.atomic.AtomicLong()

private fun newTcpLinkOpening(
    serviceIdentifier: String,
    context: String,
    clock: community.kotlin.clocks.simple.Clock,
): TcpLinkOpening = TcpLinkOpening(
    "tcp@${TCP_LINK_GENERATION.incrementAndGet()} (opened by $context for service '$serviceIdentifier')",
    clock.currentTimeMillis(),
)

private fun tcpLinkSnapshot(
    opening: TcpLinkOpening,
    remotePeerId: String,
    localEndpoint: String,
    remoteEndpoint: String,
    reason: String,
    initiatedBy: String,
): RootLinkDiagnostics = RootLinkDiagnostics(
    opening.identity, "not applicable (raw TCP)", remotePeerId,
    localEndpoint, remoteEndpoint, opening.openedAtMillis, emptyList(), reason, initiatedBy,
)

private fun TcpRpcStream.tcpTransportFailureResponse(
    requestId: String,
    message: String,
    phase: RpcTransportFailure.Phase,
    cause: Throwable?,
    code: String = Libp2pRpcProtocol.ERROR_INTERNAL,
): Libp2pRpcProtocol.RpcResponse = localTransportFailureResponse(
    requestId, message, phase, cause, code, rootLinkDiagnostics,
)
