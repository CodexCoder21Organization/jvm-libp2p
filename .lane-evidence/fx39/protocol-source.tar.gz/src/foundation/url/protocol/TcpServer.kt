package foundation.url.protocol

import community.kotlin.logging.MessageSeverity
import kotlinx.coroutines.*
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.toss
import org.json.JSONObject
import java.io.EOFException
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.IdentityHashMap
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.RejectedExecutionHandler
import java.util.concurrent.Semaphore
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import kotlin.coroutines.CoroutineContext

/**
 * Describes the per-connection thread whose start failed, for
 * [TcpServerReaderThreadStartFailureEffect]. Each accepted connection owns one reader thread and one
 * response-writer thread; naming the one that could not start keeps the report accurate.
 */
internal const val TCP_SERVER_READER_THREAD_DESCRIPTION = "connection reader thread"
internal const val TCP_SERVER_WRITER_THREAD_DESCRIPTION = "connection response-writer thread"

class TcpServerReaderThreadStartFailureEffect(
    val port: Int,
    val cause: Throwable,
    val closeFailure: Throwable? = null,
    val threadDescription: String = TCP_SERVER_READER_THREAD_DESCRIPTION,
) : NotificationEffect(
    "TcpServer on port $port could not start a $threadDescription for an accepted socket; " +
        "the socket was removed from the connection set and " +
        if (closeFailure == null) {
            "closed; cause: ${cause.javaClass.name}${cause.message?.let { ": $it" } ?: ""}"
        } else {
            "could not be closed; cause: ${cause.javaClass.name}" +
                "${cause.message?.let { ": $it" } ?: ""}; close failure: " +
                "${closeFailure.javaClass.name}${closeFailure.message?.let { ": $it" } ?: ""}"
        },
    MessageSeverity.ERROR,
    cause
)

private fun tcpServerConcurrentHandlerLimitMessage(
    port: Int,
    concurrentHandlerLimit: Int,
    requestId: String,
    method: String,
): String {
    return "TcpServer on port $port is at its concurrent request-handler limit of " +
        "$concurrentHandlerLimit; request $requestId for method '$method' was not started"
}

class TcpServerConcurrentHandlerLimitEffect(
    val port: Int,
    val concurrentHandlerLimit: Int,
    val requestId: String,
    val method: String,
) : NotificationEffect(
    tcpServerConcurrentHandlerLimitMessage(port, concurrentHandlerLimit, requestId, method),
    MessageSeverity.WARNING,
)

/**
 * Allowance-charged undelivered response bytes a single connection may hold in its ordinary response
 * lane. Responses waiting for shared capacity remain retained but are not charged against this
 * allowance. Responses refused because an allowance is exhausted are answered with
 * [Libp2pRpcProtocol.ERROR_RESPONSE_OUTBOX_FULL] instead of being admitted to the writer queue.
 */
private const val TCP_RESPONSE_OUTBOX_BYTES_PER_CONNECTION: Long = 4L * 1024L * 1024L

/**
 * Allowance-charged undelivered response bytes the whole process may admit across every
 * [TcpServer] connection. Retained jobs waiting for shared capacity are included in the public
 * retained-byte accounting but do not consume this allowance, so one peer — or one server — cannot
 * consume the admitted capacity available to all others.
 */
private const val TCP_RESPONSE_OUTBOX_BYTES_PROCESS_WIDE: Long = 16L * 1024L * 1024L

/**
 * Ceiling for a response admitted while its connection has nothing else undelivered. Such a response
 * is not a pileup — it is the ordinary case of a peer that is keeping up, and it is also how a single
 * response larger than the whole per-connection allowance (a multi-megabyte bytecode JAR, for
 * example) still gets delivered. Refusing those would refuse peers that are reading, so they are
 * admitted under this higher ceiling instead; it bounds how many connections may hold one at once.
 */
private const val TCP_RESPONSE_OUTBOX_FIRST_RESPONSE_BYTES_PROCESS_WIDE: Long = 32L * 1024L * 1024L

/**
 * A connection's reader stops consuming requests while that connection's own undelivered responses
 * exceed this mark, so a peer that stops reading throttles only itself through ordinary TCP
 * backpressure rather than continuing to admit work whose responses cannot be delivered. A response
 * waiting for the shared allowance ([TCP_RESPONSE_OUTBOX_SHARED_ALLOWANCE_WAIT_MILLIS]) counts
 * towards the mark for as long as it waits: it is undelivered and this connection is holding it, so
 * admitting further work behind it would only add more of the same.
 */
private const val TCP_RESPONSE_OUTBOX_HIGH_WATER_BYTES: Long = 1L * 1024L * 1024L

/**
 * How long a computed response waits for the allowance shared by every connection before it is
 * refused, and only when its own connection holds nothing undelivered.
 *
 * An empty outbox is the server's own evidence that this peer consumed everything computed for it,
 * so such a response is not a pileup: it occupies the shared allowance for exactly as long as its
 * write takes. Several peers that are all keeping up routinely ask for more than the shared ceiling
 * at the same instant and for less than it a moment later — twenty peers fetching a 2.4 MB
 * implementation JAR is 48 MiB offered against a 32 MiB ceiling, all of it delivered in tens of
 * milliseconds. Refusing them reports a full server to callers that did nothing wrong, so the offer
 * waits for the allowance the connections ahead of it are already returning.
 *
 * Bounded, because waiting cannot help when the allowance is held by peers that are not draining:
 * a connection whose own peer stopped reading keeps its bytes charged until it is torn down, and a
 * caller is better served by a refusal that names what it hit than by a wait that outlives its own
 * request. This is [WRITE_BACKPRESSURE_DELIVERY_WAIT_MS] — the window this transport already uses to
 * separate a transiently stalled connection from a wedged one, and comfortably inside the 30-second
 * RPC invocation timeout of the caller waiting on the other end.
 */
private const val TCP_RESPONSE_OUTBOX_SHARED_ALLOWANCE_WAIT_MILLIS: Long =
    WRITE_BACKPRESSURE_DELIVERY_WAIT_MS

/**
 * Separate, smaller allowance reserved for the [Libp2pRpcProtocol.ERROR_RESPONSE_OUTBOX_FULL]
 * answers themselves, so a connection whose response allowance is exhausted can still tell its
 * caller what happened.
 */
private const val TCP_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION: Long = 1536L * 1024L
private const val TCP_RESPONSE_OUTBOX_FAILURE_BYTES_PROCESS_WIDE: Long = 3L * 1024L * 1024L

/**
 * Monitor a response waits on while the allowance shared by every connection in this process is
 * exhausted. [tcpResponseOutboxReleases] counts every return of shared bytes, so a waiter that
 * reads it before its failed charge cannot miss a release that lands before it starts waiting.
 */
private val tcpResponseOutboxSharedAllowance = Object()
private val tcpResponseOutboxReleases = AtomicLong(0L)

private fun additionalAttachmentBytes(
    attachments: List<ByteArray>,
    references: IdentityHashMap<ByteArray, Int>,
): Long {
    var bytes = 0L
    val seen = IdentityHashMap<ByteArray, Boolean>()
    for (attachment in attachments) {
        if (seen.put(attachment, true) == null && !references.containsKey(attachment)) {
            bytes += attachment.size
        }
    }
    return bytes
}

private fun retainAttachments(
    attachments: List<ByteArray>,
    references: IdentityHashMap<ByteArray, Int>,
): Long {
    var newlyRetainedBytes = 0L
    for (attachment in attachments) {
        val previous = references[attachment] ?: 0
        if (previous == 0) newlyRetainedBytes += attachment.size
        references[attachment] = previous + 1
    }
    return newlyRetainedBytes
}

private fun releaseAttachments(
    attachments: List<ByteArray>,
    references: IdentityHashMap<ByteArray, Int>,
): Long {
    var releasedBytes = 0L
    for (attachment in attachments) {
        val previous = checkNotNull(references[attachment]) {
            "TCP response outbox released an attachment identity that was not retained"
        }
        check(previous > 0) {
            "TCP response outbox attachment reference count must be positive, but was $previous"
        }
        if (previous == 1) {
            references.remove(attachment)
            releasedBytes += attachment.size
        } else {
            references[attachment] = previous - 1
        }
    }
    return releasedBytes
}

private class TcpServerOutboxAccounting {
    var currentBytes: Long = 0L
    var peakBytes: Long = 0L
    var allowanceChargedBytes: Long = 0L
    var peakAllowanceChargedBytes: Long = 0L
    val responseAttachmentReferences = IdentityHashMap<ByteArray, Int>()
    val failureAttachmentReferences = IdentityHashMap<ByteArray, Int>()
    val allowanceResponseAttachmentReferences = IdentityHashMap<ByteArray, Int>()
    val allowanceFailureAttachmentReferences = IdentityHashMap<ByteArray, Int>()

    fun references(failureLane: Boolean): IdentityHashMap<ByteArray, Int> =
        if (failureLane) failureAttachmentReferences else responseAttachmentReferences

    fun allowanceReferences(failureLane: Boolean): IdentityHashMap<ByteArray, Int> =
        if (failureLane) {
            allowanceFailureAttachmentReferences
        } else {
            allowanceResponseAttachmentReferences
        }
}

private sealed class ProcessWideChargeAttempt {
    object Acquired : ProcessWideChargeAttempt()

    class Refused(
        val currentBytes: Long,
        val retainedResponseBytes: Long,
    ) : ProcessWideChargeAttempt()
}

/**
 * Process-wide response-retention accounting. The lock protects both lane totals and every
 * identity-reference map, including each server's public current/peak view. It is never held during
 * socket IO. Connection code always takes its outbox lock before entering this structure; snapshot
 * reads take only this lock, and no path takes the locks in the opposite order.
 */
private class TcpResponseOutboxAccounting {
    private val lock = Object()
    private var responseBytes = 0L
    private var failureBytes = 0L
    private var allowanceResponseBytes = 0L
    private var allowanceFailureBytes = 0L
    private val responseAttachmentReferences = IdentityHashMap<ByteArray, Int>()
    private val failureAttachmentReferences = IdentityHashMap<ByteArray, Int>()
    private val allowanceResponseAttachmentReferences = IdentityHashMap<ByteArray, Int>()
    private val allowanceFailureAttachmentReferences = IdentityHashMap<ByteArray, Int>()

    private fun references(failureLane: Boolean): IdentityHashMap<ByteArray, Int> =
        if (failureLane) failureAttachmentReferences else responseAttachmentReferences

    private fun allowanceReferences(failureLane: Boolean): IdentityHashMap<ByteArray, Int> =
        if (failureLane) {
            allowanceFailureAttachmentReferences
        } else {
            allowanceResponseAttachmentReferences
        }

    fun currentBytes(failureLane: Boolean): Long = synchronized(lock) {
        if (failureLane) allowanceFailureBytes else allowanceResponseBytes
    }

    /**
     * Builds and records one complete job in the same critical section, so a public snapshot cannot
     * observe the job between construction and retained-byte publication. The caller has already
     * finished the response provider callback; [createJob] only serializes the response in memory.
     */
    fun createRetainedJob(
        server: TcpServerOutboxAccounting,
        createJob: () -> ResponseWriteJob,
    ): ResponseWriteJob = synchronized(lock) {
        val job = createJob()
        check(!job.retained) { "TCP response job was retained more than once" }
        val retainedProcessBytes = job.baseRetainedBytes +
            retainAttachments(job.attachments, references(job.failureLane))
        if (job.failureLane) {
            failureBytes += retainedProcessBytes
        } else {
            responseBytes += retainedProcessBytes
        }

        val retainedServerBytes = job.baseRetainedBytes +
            retainAttachments(job.attachments, server.references(job.failureLane))
        server.currentBytes += retainedServerBytes
        if (server.currentBytes > server.peakBytes) server.peakBytes = server.currentBytes
        job.retained = true
        job.initialServerRetainedBytes = retainedServerBytes
        job
    }

    fun tryAdmit(
        server: TcpServerOutboxAccounting,
        job: ResponseWriteJob,
        limit: Long,
    ): ProcessWideChargeAttempt = synchronized(lock) {
        check(job.retained) { "TCP response job must be retained before allowance admission" }
        check(!job.allowanceCharged) { "TCP response job was admitted more than once" }
        val processReferences = allowanceReferences(job.failureLane)
        val retainedResponseBytes = job.baseRetainedBytes +
            additionalAttachmentBytes(job.attachments, processReferences)
        val current = if (job.failureLane) allowanceFailureBytes else allowanceResponseBytes
        if (retainedResponseBytes > limit - current) {
            return@synchronized ProcessWideChargeAttempt.Refused(
                currentBytes = current,
                retainedResponseBytes = retainedResponseBytes,
            )
        }

        val chargedProcessBytes = job.baseRetainedBytes +
            retainAttachments(job.attachments, processReferences)
        check(chargedProcessBytes == retainedResponseBytes)
        if (job.failureLane) {
            allowanceFailureBytes += chargedProcessBytes
        } else {
            allowanceResponseBytes += chargedProcessBytes
        }

        val chargedServerBytes = job.baseRetainedBytes +
            retainAttachments(job.attachments, server.allowanceReferences(job.failureLane))
        server.allowanceChargedBytes += chargedServerBytes
        if (server.allowanceChargedBytes > server.peakAllowanceChargedBytes) {
            server.peakAllowanceChargedBytes = server.allowanceChargedBytes
        }
        job.allowanceCharged = true
        ProcessWideChargeAttempt.Acquired
    }

    fun release(server: TcpServerOutboxAccounting, job: ResponseWriteJob) = synchronized(lock) {
        check(job.retained) { "TCP response job was released before it was retained" }
        if (job.allowanceCharged) {
            val releasedProcessAllowanceBytes = job.baseRetainedBytes +
                releaseAttachments(job.attachments, allowanceReferences(job.failureLane))
            if (job.failureLane) {
                check(allowanceFailureBytes >= releasedProcessAllowanceBytes)
                allowanceFailureBytes -= releasedProcessAllowanceBytes
            } else {
                check(allowanceResponseBytes >= releasedProcessAllowanceBytes)
                allowanceResponseBytes -= releasedProcessAllowanceBytes
            }

            val releasedServerAllowanceBytes = job.baseRetainedBytes +
                releaseAttachments(job.attachments, server.allowanceReferences(job.failureLane))
            check(server.allowanceChargedBytes >= releasedServerAllowanceBytes)
            server.allowanceChargedBytes -= releasedServerAllowanceBytes
            job.allowanceCharged = false
            tcpResponseOutboxReleases.incrementAndGet()
        }

        val releasedProcessBytes = job.baseRetainedBytes +
            releaseAttachments(job.attachments, references(job.failureLane))
        if (job.failureLane) {
            check(failureBytes >= releasedProcessBytes)
            failureBytes -= releasedProcessBytes
        } else {
            check(responseBytes >= releasedProcessBytes)
            responseBytes -= releasedProcessBytes
        }

        val releasedServerBytes = job.baseRetainedBytes +
            releaseAttachments(job.attachments, server.references(job.failureLane))
        check(server.currentBytes >= releasedServerBytes)
        server.currentBytes -= releasedServerBytes
        job.retained = false
        releasedServerBytes
    }

    fun snapshot(server: TcpServerOutboxAccounting): TcpServerAccountingSnapshot = synchronized(lock) {
        TcpServerAccountingSnapshot(
            retainedBytes = server.currentBytes,
            peakRetainedBytes = server.peakBytes,
            allowanceChargedBytes = server.allowanceChargedBytes,
            peakAllowanceChargedBytes = server.peakAllowanceChargedBytes,
        )
    }
}

private data class TcpServerAccountingSnapshot(
    val retainedBytes: Long,
    val peakRetainedBytes: Long,
    val allowanceChargedBytes: Long,
    val peakAllowanceChargedBytes: Long,
)

private val tcpResponseOutboxAccounting = TcpResponseOutboxAccounting()

/**
 * Which undelivered-response allowance a refused response exceeded. Naming it is what keeps the
 * refusal honest: only [PER_CONNECTION] means the refused connection's own peer stopped reading, and
 * the process-wide cases routinely refuse a connection whose peer is reading perfectly.
 */
enum class TcpServerResponseOutboxAllowance {
    /** This connection's own undelivered-response allowance: its peer is not reading. */
    PER_CONNECTION,

    /** The undelivered-response allowance shared by every connection in the process. */
    PROCESS_WIDE,

    /**
     * The higher process-wide ceiling that applies to a response offered to a connection holding
     * nothing undelivered, which is how a single response larger than the per-connection allowance
     * still gets delivered.
     */
    PROCESS_WIDE_EMPTY_OUTBOX,

    /** The per-connection allowance reserved for the refusal replies themselves. */
    PER_CONNECTION_FAILURE_REPLY,

    /** The process-wide allowance reserved for the refusal replies themselves. */
    PROCESS_WIDE_FAILURE_REPLY,
}

/**
 * What was actually observed when a computed response could not be queued for delivery.
 *
 * @property exceededAllowance Which allowance the response did not fit.
 * @property responseBytes Complete wire size of the response that was refused.
 * @property retainedResponseBytes Heap storage this response would add to the allowance-charged
 * accounting if admitted. This can be smaller than [responseBytes] when another admitted response
 * already refers to the same identity-accounted attachment allocation.
 * @property connectionUndeliveredBytes Bytes admitted for the refused connection and charged against
 * the lane [exceededAllowance] governs — its ordinary responses, or its reserved failure-reply lane
 * for the two failure-reply allowances.
 * @property processWideUndeliveredBytes Bytes admitted across every connection and charged against
 * that same process-wide lane at that moment.
 * @property allowanceLimitBytes The value of [exceededAllowance] that [responseBytes] did not fit
 * within.
 */
data class TcpServerResponseOutboxRefusal(
    val exceededAllowance: TcpServerResponseOutboxAllowance,
    val responseBytes: Long,
    val connectionUndeliveredBytes: Long,
    val processWideUndeliveredBytes: Long,
    val allowanceLimitBytes: Long,
    val retainedResponseBytes: Long = responseBytes,
)

private fun tcpServerResponseOutboxFullMessage(
    port: Int,
    requestId: String,
    method: String,
    refusal: TcpServerResponseOutboxRefusal,
): String {
    val cause = when (refusal.exceededAllowance) {
        TcpServerResponseOutboxAllowance.PER_CONNECTION ->
            "this connection already holds ${refusal.connectionUndeliveredBytes} bytes of " +
                "undelivered responses, so queueing this one would exceed its per-connection " +
                "allowance of ${refusal.allowanceLimitBytes} bytes: this connection's peer is not " +
                "reading its responses"
        TcpServerResponseOutboxAllowance.PROCESS_WIDE ->
            "this connection holds ${refusal.connectionUndeliveredBytes} bytes of undelivered " +
                "responses, but every connection in this process together already holds " +
                "${refusal.processWideUndeliveredBytes} bytes, so queueing this one would exceed " +
                "the process-wide allowance of ${refusal.allowanceLimitBytes} bytes shared by all " +
                "connections"
        TcpServerResponseOutboxAllowance.PROCESS_WIDE_EMPTY_OUTBOX ->
            "this connection holds ${refusal.connectionUndeliveredBytes} bytes of undelivered " +
                "responses, but every connection in this process together already holds " +
                "${refusal.processWideUndeliveredBytes} bytes, so queueing this one would exceed " +
                "the process-wide ceiling of ${refusal.allowanceLimitBytes} bytes that applies to " +
                "a response offered to a connection holding nothing undelivered"
        TcpServerResponseOutboxAllowance.PER_CONNECTION_FAILURE_REPLY ->
            "this connection already holds ${refusal.connectionUndeliveredBytes} bytes of " +
                "undelivered refusal replies, so queueing this one would exceed the per-connection " +
                "allowance of ${refusal.allowanceLimitBytes} bytes reserved for them"
        TcpServerResponseOutboxAllowance.PROCESS_WIDE_FAILURE_REPLY ->
            "every connection in this process together already holds " +
                "${refusal.processWideUndeliveredBytes} bytes of undelivered refusal replies, so " +
                "queueing this one would exceed the process-wide allowance of " +
                "${refusal.allowanceLimitBytes} bytes reserved for them"
    }
    val retainedDetail = if (refusal.retainedResponseBytes == refusal.responseBytes) {
        ""
    } else {
        ", which would add ${refusal.retainedResponseBytes} bytes to the outbox"
    }
    return "TcpServer on port $port ran the handler for request $requestId for method '$method' to " +
        "completion, but could not queue its ${refusal.responseBytes}-byte response$retainedDetail " +
        "for delivery: " +
        "$cause. The response was discarded; the handler ran exactly once and the request was not " +
        "retried"
}

/**
 * Reports that a computed response could not be queued for delivery because an undelivered-response
 * allowance was exhausted. The caller already received the explicit
 * [Libp2pRpcProtocol.ERROR_RESPONSE_OUTBOX_FULL] error; this effect exists for consumers that want
 * to record the condition. [refusal] says which allowance was exceeded and what was observed, which
 * distinguishes a peer that stopped reading from a process that is simply busy.
 */
class TcpServerResponseOutboxFullEffect(
    val port: Int,
    val requestId: String,
    val method: String,
    val refusal: TcpServerResponseOutboxRefusal,
) : NotificationEffect(
    tcpServerResponseOutboxFullMessage(port, requestId, method, refusal),
    MessageSeverity.WARNING,
)

/**
 * A point-in-time view of a [TcpServer]'s undelivered-response accounting.
 *
 * @property queuedResponseBytes Bytes of computed-but-unwritten responses this server currently
 * retains across all of its connections.
 * @property peakQueuedResponseBytes The largest value [queuedResponseBytes] has reached since the
 * server was constructed.
 * @property allowanceChargedResponseBytes Bytes currently admitted to connection writer queues and
 * charged against the shared response allowances. A complete response waiting for shared capacity
 * is included in [queuedResponseBytes] but not in this admitted subset.
 * @property peakAllowanceChargedResponseBytes The largest value
 * [allowanceChargedResponseBytes] has reached since the server was constructed.
 * @property perConnectionLimitBytes The undelivered-response allowance of a single connection.
 * @property processWideLimitBytes The undelivered-response allowance shared by every connection in
 * the process.
 * @property emptyOutboxProcessWideLimitBytes The higher process-wide ceiling applied to a response
 * offered to a connection that holds nothing undelivered, which is how a single response larger than
 * [perConnectionLimitBytes] still gets delivered.
 * @property readPauseHighWaterBytes The per-connection mark above which that connection's reader
 * stops consuming further requests.
 * @property undeliverableResponses How many computed responses this server has answered with
 * [Libp2pRpcProtocol.ERROR_RESPONSE_OUTBOX_FULL] because the allowance was exhausted.
 */
data class TcpServerResponseOutboxSnapshot(
    val queuedResponseBytes: Long,
    val peakQueuedResponseBytes: Long,
    val perConnectionLimitBytes: Long,
    val processWideLimitBytes: Long,
    val emptyOutboxProcessWideLimitBytes: Long,
    val readPauseHighWaterBytes: Long,
    val undeliverableResponses: Long,
    val allowanceChargedResponseBytes: Long,
    val peakAllowanceChargedResponseBytes: Long,
)

/**
 * The result of one attempt to charge a response against the allowances, made under the
 * connection's outbox lock. [AwaitSharedAllowance] carries the refusal the attempt would have
 * produced, so a caller that runs out of waiting time reports what it actually observed rather than
 * re-deriving it after the fact.
 */
private sealed class EnqueueAttempt {
    class Queued(val serverBytes: Long) : EnqueueAttempt()

    class Refused(val refusal: TcpServerResponseOutboxRefusal) : EnqueueAttempt()

    class AwaitSharedAllowance(val refusal: TcpServerResponseOutboxRefusal) : EnqueueAttempt()
}

/** What happened to a computed response that was offered to its connection's write queue. */
private sealed class ResponseQueueOutcome {
    object Queued : ResponseQueueOutcome()

    /** The connection is gone, so there is nobody left to answer. */
    object ConnectionClosed : ResponseQueueOutcome()

    /**
     * The connection is alive but an undelivered-response allowance is exhausted. [refusal] carries
     * which one and what was observed, so the caller can be told the truth rather than a guess.
     */
    class AllowanceExhausted(val refusal: TcpServerResponseOutboxRefusal) : ResponseQueueOutcome()
}

/**
 * One response job holding a frame for delivery: what it costs to retain, and how to emit it once
 * admitted to its connection's writer queue.
 *
 * Holding a closure rather than an encoded frame is what keeps the streaming bytecode path intact —
 * that job captures the serialized JSON header plus either existing attachment arrays or a
 * transport-owned forwarded input and emits them segment by segment, so a multi-megabyte JAR is
 * never materialized as one array to sit in a queue.
 */
private class ResponseWriteJob(
    /** Complete frame length sent on the wire, used when a refusal identifies the response. */
    val wireBytes: Long,
    /** Non-attachment storage retained specifically by this response job. */
    val baseRetainedBytes: Long,
    /** Array allocations captured by the write closure and identity-accounted until last release. */
    val attachments: List<ByteArray>,
    val failureLane: Boolean,
    val onRelease: () -> Unit = {},
    val onCancel: () -> Unit = {},
    val write: (java.io.OutputStream) -> Unit,
) {
    val released = AtomicBoolean(false)
    var retained = false
    var allowanceCharged = false
    var connectionCharged = false
    var initialServerRetainedBytes = 0L
    var writerPublished = false

    val maximumRetainedBytes: Long =
        baseRetainedBytes + attachments.sumOf { it.size.toLong() }
}

private fun encodedResponseWriteJob(
    json: JSONObject,
    attachments: List<ByteArray>,
    failureLane: Boolean = false,
): ResponseWriteJob {
    // Identical to what Libp2pRpcProtocol.writeMessage would build immediately before writing, so
    // queueing costs no extra copy; it is simply built on the handler thread instead of the writer's.
    val frame = Libp2pRpcProtocol.encodeMessage(json, attachments)
    return ResponseWriteJob(
        wireBytes = frame.size.toLong(),
        baseRetainedBytes = frame.size.toLong(),
        attachments = emptyList(),
        failureLane = failureLane,
    ) { output ->
        output.write(frame)
        output.flush()
    }
}

private fun streamingResponseWriteJob(
    json: JSONObject,
    attachments: List<ByteArray>,
): ResponseWriteJob {
    val retainedAttachments = attachments.toList()
    val jsonBytes = json.toString().toByteArray(Charsets.UTF_8)
    var wireBytes = 4L + jsonBytes.size
    var baseRetainedBytes = 4L + jsonBytes.size
    if (retainedAttachments.isNotEmpty()) {
        wireBytes += 4L
        baseRetainedBytes += 4L
        for (attachment in retainedAttachments) {
            wireBytes += 4L + attachment.size
            baseRetainedBytes += 4L
        }
    }
    return ResponseWriteJob(
        wireBytes = wireBytes,
        baseRetainedBytes = baseRetainedBytes,
        attachments = retainedAttachments,
        failureLane = false,
    ) { output ->
        Libp2pRpcProtocol.writeEncodedMessageStreamingAttachments(
            output,
            jsonBytes,
            retainedAttachments,
        )
    }
}

private fun forwardedStreamingResponseWriteJob(
    json: JSONObject,
    response: ForwardedStreamingBytecodeResponse,
): ResponseWriteJob {
    val jsonBytes = json.toString().toByteArray(Charsets.UTF_8)
    val wireBytes = 12L + jsonBytes.size + response.jarLength
    val baseRetainedBytes = 12L + jsonBytes.size + ATTACHMENT_WRITE_CHUNK_BYTES
    val job = ResponseWriteJob(
        wireBytes = wireBytes,
        baseRetainedBytes = baseRetainedBytes,
        attachments = emptyList(),
        failureLane = false,
        onRelease = { response.releaseWriter() },
        onCancel = { response.close() },
        write = { output ->
            try {
                output.write(java.nio.ByteBuffer.allocate(4).putInt(jsonBytes.size).array())
                output.write(jsonBytes)
                output.write(java.nio.ByteBuffer.allocate(4).putInt(1).array())
                output.write(java.nio.ByteBuffer.allocate(4).putInt(response.jarLength).array())
                output.flush()
                val buffer = ByteArray(ATTACHMENT_WRITE_CHUNK_BYTES)
                var remaining = response.jarLength
                while (remaining > 0) {
                    val read = response.jarInput.read(buffer, 0, minOf(buffer.size, remaining))
                    if (read < 0) {
                        throw EOFException(
                            "Forwarded bytecode attachment ended with $remaining of " +
                                "${response.jarLength} declared bytes unread"
                        )
                    }
                    output.write(buffer, 0, read)
                    output.flush()
                    remaining -= read
                }
            } finally {
                response.close()
            }
        },
    )
    return job
}

/**
 * Services this invocation on its worker until all structured work and cleanup have exited.
 * Unlike runBlocking's thread-local loop, this queue is not retired by a worker interrupt.
 */
@OptIn(ExperimentalCoroutinesApi::class)
private fun <T> runTcpRequestBlocking(
    context: CoroutineContext,
    cancellationRequested: () -> Boolean,
    block: suspend CoroutineScope.() -> T,
): T {
    val continuations = LinkedBlockingQueue<Runnable>()
    val dispatcher = object : CoroutineDispatcher() {
        override fun dispatch(context: CoroutineContext, block: Runnable) {
            continuations.add(block)
        }
    }
    val invocation = CoroutineScope(context + dispatcher).async(block = block)
    // The final child can finish on another dispatcher while this worker waits for a turn.
    invocation.invokeOnCompletion { continuations.add(Runnable {}) }
    var continuationFailure: Throwable? = null
    while (!invocation.isCompleted) {
        // Application code can consume an InterruptedException. The task's cancellation bit still
        // cancels suspended children after that code returns to this loop.
        if (Thread.interrupted() || cancellationRequested()) invocation.cancel()
        try {
            continuations.take().run()
        } catch (_: InterruptedException) {
            // Interrupt blocking work without abandoning its continuation queue. Cancellation
            // cleanup, including returns from withContext, keeps its original request worker.
            invocation.cancel()
        } catch (failure: Throwable) {
            // A callback submitted through the handler dispatcher is not itself a coroutine
            // continuation, so an unchecked failure from it can escape run(). Keep servicing the
            // invocation until every structured child has completed before the request task releases
            // its admission, while retaining the original failure for the worker's caller.
            val previousFailure = continuationFailure
            if (previousFailure == null) {
                continuationFailure = failure
            } else if (previousFailure !== failure) {
                previousFailure.addSuppressed(failure)
            }
            val cancellation = CancellationException(
                "A TCP request dispatcher callback failed; cancelling the request invocation."
            )
            cancellation.initCause(failure)
            invocation.cancel(cancellation)
        }
    }
    continuationFailure?.let { throw it }
    return invocation.getCompleted()
}

private interface TcpServerRequestTask : Runnable {
    fun finishAccounting()
}

/**
 * Task queue that keeps a bounded worker pool elastic: work goes to a worker that is already idle, a
 * new worker is created when none is, and only once the pool is at its ceiling does work wait here.
 *
 * A [ThreadPoolExecutor] gives neither half of that on its own. Over a `SynchronousQueue` it hands
 * work straight to a parked worker, but it rejects during the window in which a worker that has just
 * finished its task has not yet re-parked — the false saturation report that [TcpServer]'s admission
 * accounting exists to remove. Over an ordinary queue with `corePoolSize == maximumPoolSize` it never
 * rejects, but it creates a new thread for every task until the ceiling is reached even when an idle
 * worker is sitting right there. Refusing the offer while the pool may still grow gets both
 * properties, because `execute` responds to a refused offer by creating a worker.
 */
private class ElasticHandlerTaskQueue : LinkedBlockingQueue<Runnable>() {
    @Volatile
    var pool: ThreadPoolExecutor? = null

    /**
     * Tasks handed to the pool that have not finished, counted from just before `execute` until the
     * task returns. This is the only sound way to ask whether a worker will be free to take a queued
     * task. `ThreadPoolExecutor.getActiveCount` is not: a worker created a moment earlier already
     * counts in `poolSize` but has not yet locked its first task, so it reads as idle. Queueing
     * behind it strands the task for as long as that first handler blocks — with 64 handlers waiting
     * on one dependency, exactly one request never reached a handler at all.
     */
    val submittedTasks = AtomicInteger(0)

    override fun offer(e: Runnable): Boolean {
        val executor = pool ?: return super.offer(e)
        // The worker count is read BEFORE the task count, and that order is the whole correctness
        // argument. A worker only ever exists because some task refused this queue and made
        // `execute` create it, so every worker observed here was already counted in `submittedTasks`
        // before it existed. Reading the workers first therefore compares an EARLY worker count
        // against a LATER task count, and the branch below can only be taken when workers really do
        // outnumber unfinished tasks.
        //
        // Reading them the other way round compares an early task count against a later worker
        // count, and that reads as free capacity that was never free: while this task holds its
        // count from before a concurrent task incremented, that concurrent task creates the worker
        // that makes the counts match, so both tasks are claimed on the same worker. The loser waits
        // here for a worker that is never created — its caller was admitted, is owed a response, and
        // does not get one until an unrelated handler finishes.
        val workers = executor.poolSize
        // At least as many workers as unfinished tasks, this one included, so at least one worker is
        // not running a task and will take this from the queue.
        if (submittedTasks.get() <= workers) return super.offer(e)
        // Every worker is accounted for by another task and the pool may still grow: refuse, so
        // execute() creates one.
        if (executor.poolSize < executor.maximumPoolSize) return false
        // At the thread ceiling. Waiting here is what absorbs the window between a handler finishing
        // and its worker becoming available again. The queue cannot grow without bound: a task waits
        // here only while it still holds an admission permit, so its depth never exceeds the server's
        // concurrentHandlerLimit.
        return super.offer(e)
    }
}

/**
 * Creates and starts one TCP connection reader thread. Exactly one call per accepted connection.
 *
 * A connection also owns a response-writer thread, which is deliberately not created here. That
 * thread blocks on the socket while holding the connection's output monitor, which is the carrier
 * pinning [TcpServer] uses platform threads to avoid, so its creation policy is not the caller's to
 * substitute — and keeping it out of this factory preserves the one-call-per-connection contract
 * that callers count invocations against.
 *
 * The factory is an injectable seam for callers that need to provide their own thread creation
 * policy. The ordinary [TcpServer] constructor uses daemon platform threads with the same names as
 * the historical implementation.
 */
fun interface TcpServerReaderThreadFactory {
    fun start(name: String, action: () -> Unit): Thread
}

/**
 * Creates the bound server socket used by a [TcpServer].
 *
 * The ordinary constructors use [ServerSocket] directly. This factory lets callers apply a custom
 * server-socket creation policy without changing the connection protocol or the per-connection
 * thread policy. The returned socket must already be bound to [port].
 */
fun interface TcpServerSocketFactory {
    fun create(port: Int): ServerSocket
}

/**
 * Observes when a [TcpServer] response enters and leaves its retained-response outbox.
 *
 * [onResponseQueued] runs after the response has been published to its connection writer and all
 * positive byte accounting is visible, but without holding the connection's outbox monitor. The
 * writer may therefore deliver the response while this callback is still running, or may invoke
 * [onResponseReleased] before this callback starts. The release callback runs after delivery or
 * connection teardown has returned all of the response's byte charges. Callers can use these
 * callbacks to coordinate aggregate delivery diagnostics without polling thread state or depending
 * on scheduler timing; concurrent responses must not be paired by callback arrival order.
 */
interface TcpServerResponseOutboxObserver {
    fun onResponseQueued(accountedBytes: Long, failureLane: Boolean) {}

    fun onResponseReleased(accountedBytes: Long, failureLane: Boolean) {}
}

private val defaultTcpServerReaderThreadFactory = TcpServerReaderThreadFactory { name, action ->
    thread(name = name, isDaemon = true, block = action)
}

private val defaultTcpServerSocketFactory = TcpServerSocketFactory { port -> ServerSocket(port) }

private val recoverableTcpServerReaderStartFailureMessages = listOf(
    "unable to create native thread",
    "unable to create new native thread",
    "failed to create a thread"
)

private fun isRecoverableTcpServerReaderStartFailure(failure: Throwable): Boolean {
    // JVMs expose a native-thread creation refusal only as an OutOfMemoryError with a text
    // message; they provide no typed discriminator that distinguishes it from heap exhaustion,
    // so message matching is the only available signal. Match these known families,
    // case-insensitively: HotSpot "unable to create native thread" and "unable to create new
    // native thread", and OpenJ9 "Failed to create a thread" (including errno and z/OS errno2
    // suffixes). Every other OutOfMemoryError remains fatal by default.
    return failure is Exception ||
        (failure is OutOfMemoryError &&
            failure.message?.let { message ->
                recoverableTcpServerReaderStartFailureMessages.any {
                    message.contains(it, ignoreCase = true)
                }
            } == true)
}

/**
 * A TCP server that accepts RPC connections using the same protocol as libp2p.
 *
 * This server listens on a TCP port and handles incoming RPC requests using
 * the [Libp2pRpcProtocol] message format. It is used for local communication
 * when the `localhost.tcp:PORT` domain pattern is used.
 *
 * Example usage:
 * ```kotlin
 * val server = TcpServer(8080) { request, effectHandler ->
 *     when (request.method) {
 *         "hello" -> Libp2pRpcProtocol.RpcResponse.success(request.id, "Hello World")
 *         else -> Libp2pRpcProtocol.RpcResponse.error(
 *             request.id,
 *             Libp2pRpcProtocol.ERROR_UNKNOWN_METHOD,
 *             "Unknown method: ${request.method}"
 *         )
 *     }
 * }
 * server.start()
 * // ... server is now accepting connections on port 8080
 * server.stop()
 * ```
 *
 * @property port The port to listen on.
 * @property concurrentHandlerLimit The maximum number of request handlers that may run at once.
 * The default of [DEFAULT_CONCURRENT_HANDLER_LIMIT] leaves ample headroom above the historical
 * 65-or-more concurrent blocking-handler contract while bounding platform-thread use.
 * @property requestHandler The handler for incoming RPC requests.
 */
class TcpServer private constructor(
    val port: Int,
    val concurrentHandlerLimit: Int,
    private val serverSocketFactory: TcpServerSocketFactory,
    private val readerThreadFactory: TcpServerReaderThreadFactory,
    private val responseOutboxObserver: TcpServerResponseOutboxObserver?,
    private val requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse
) : AutoCloseable {

    constructor(
        port: Int,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse
    ) : this(
        port,
        DEFAULT_CONCURRENT_HANDLER_LIMIT,
        defaultTcpServerSocketFactory,
        defaultTcpServerReaderThreadFactory,
        null,
        requestHandler,
    )

    constructor(
        port: Int,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse,
        concurrentHandlerLimit: Int = DEFAULT_CONCURRENT_HANDLER_LIMIT,
    ) : this(
        port,
        concurrentHandlerLimit,
        defaultTcpServerSocketFactory,
        defaultTcpServerReaderThreadFactory,
        null,
        requestHandler,
    )

    constructor(
        port: Int,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse,
        responseOutboxObserver: TcpServerResponseOutboxObserver,
        concurrentHandlerLimit: Int = DEFAULT_CONCURRENT_HANDLER_LIMIT,
    ) : this(
        port,
        concurrentHandlerLimit,
        defaultTcpServerSocketFactory,
        defaultTcpServerReaderThreadFactory,
        responseOutboxObserver,
        requestHandler,
    )

    constructor(
        port: Int,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse,
        readerThreadFactory: TcpServerReaderThreadFactory
    ) : this(
        port,
        DEFAULT_CONCURRENT_HANDLER_LIMIT,
        defaultTcpServerSocketFactory,
        readerThreadFactory,
        null,
        requestHandler,
    )

    constructor(
        port: Int,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse,
        readerThreadFactory: TcpServerReaderThreadFactory,
        concurrentHandlerLimit: Int = DEFAULT_CONCURRENT_HANDLER_LIMIT,
        responseOutboxObserver: TcpServerResponseOutboxObserver? = null,
    ) : this(
        port,
        concurrentHandlerLimit,
        defaultTcpServerSocketFactory,
        readerThreadFactory,
        responseOutboxObserver,
        requestHandler,
    )

    constructor(
        port: Int,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse,
        serverSocketFactory: TcpServerSocketFactory,
        readerThreadFactory: TcpServerReaderThreadFactory,
        concurrentHandlerLimit: Int = DEFAULT_CONCURRENT_HANDLER_LIMIT,
        responseOutboxObserver: TcpServerResponseOutboxObserver? = null,
    ) : this(
        port,
        concurrentHandlerLimit,
        serverSocketFactory,
        readerThreadFactory,
        responseOutboxObserver,
        requestHandler,
    )

    init {
        require(concurrentHandlerLimit > 0) {
            "TcpServer concurrentHandlerLimit must be greater than zero, but was " +
                "$concurrentHandlerLimit for port $port"
        }
    }

    private var encodingFailureHandler: RpcResponseEncodingFailureHandler? = null

    @Volatile private var serverSocket: ServerSocket? = null
    private val running = AtomicBoolean(false)
    private val connections = ConcurrentHashMap<Socket, ConnectionHandler>()
    private val connectionLifecycleLock = Any()
    private var acceptThread: Thread? = null
    // The completion also identifies the start that owns an accepted connection.
    @Volatile private var acceptLoopCompletion = CompletableFuture.completedFuture(Unit)
    // Each admitted request owns one platform thread. A virtual thread that blocks while holding a
    // JVM monitor pins its shared carrier; enough such handlers can stop every unrelated virtual
    // thread in the process. This elastic pool avoids that shared scheduler and reuses idle threads.
    // Admission is gated by the permits below, not by this pool, so the pool never turns away a
    // request that admission already accepted.
    private val requestThreadCounter = AtomicLong(0L)
    // Capacity is counted here rather than inferred from the executor. A pool bounded by
    // maximumPoolSize over a SynchronousQueue only has room while a worker is parked in poll(), so
    // a worker that has finished its handler — and has already written the response its caller is
    // reading — still turns the next request away until the scheduler re-parks it. Counting permits
    // explicitly makes capacity mean "no handler occupies this slot", which is what the refusal
    // claims, and makes a released slot visible the instant the handler is done rather than whenever
    // its thread is next scheduled.
    //
    // A handler thread never writes its response to a socket: it computes the response, releases its
    // permit, hands the frame to its connection's writer thread and terminates. A peer that pipelines
    // requests without reading its responses therefore cannot make handlers pile up — it fills its
    // connection's bounded response outbox instead, and its own reader pauses once that outbox passes
    // its high-water mark. A handler can still write to the socket on its own thread when it
    // propagates an effect (see EffectPropagator below), which blocks under the connection's output
    // monitor while holding its permit; that consumes a slot, and the resulting refusals are truthful
    // because the handler really is still running. Platform threads stay bounded regardless: that is
    // the pool's maximumPoolSize, which is this same limit. The complete thread bound is: one accept
    // thread, one reader and one writer thread per connection, and at most concurrentHandlerLimit
    // request-handler threads process-wide.
    private val handlerAdmissions = Semaphore(concurrentHandlerLimit)
    // All computed-but-unwritten response bytes retained by this server's connections, including jobs
    // waiting for shared capacity. responseOutboxSnapshot() reports this total and its peak; the
    // separately tracked admitted/allowance-charged bytes are bounded by process-wide allowances.
    private val outboxAccounting = TcpServerOutboxAccounting()
    private val undeliverableResponses = AtomicLong(0L)
    // Threads are capped by construction at concurrentHandlerLimit — that is maximumPoolSize — and
    // the pool never turns away a request that admission already accepted. See
    // ElasticHandlerTaskQueue for how those two properties are reconciled: work goes to an idle
    // worker, a worker is created when there is none, and a task waits in the queue only while the
    // pool is at its ceiling. Idle workers are reaped after REQUEST_THREAD_KEEP_ALIVE_SECONDS.
    private val requestTaskQueue = ElasticHandlerTaskQueue()
    private val requestExecutor = ThreadPoolExecutor(
        0,
        concurrentHandlerLimit,
        REQUEST_THREAD_KEEP_ALIVE_SECONDS,
        TimeUnit.SECONDS,
        requestTaskQueue,
        { task ->
            Thread(task, "TcpServer-Request-$port-${requestThreadCounter.getAndIncrement()}").apply {
                isDaemon = true
            }
        },
        RejectedExecutionHandler { task, executor ->
            // The pool reached its ceiling between the refused offer and the attempt to create a
            // worker. The request was already admitted, so it waits for a worker rather than being
            // told the server is saturated.
            if (executor.isShutdown) {
                throw RejectedExecutionException(
                    "TcpServer on port $port cannot run request handlers because its " +
                        "request-handler pool is shut down"
                )
            }
            executor.queue.put(task)
        },
    ).apply { requestTaskQueue.pool = this }
    private val scope = CoroutineScope(SupervisorJob())

    /**
     * Whether the server is currently running.
     */
    val isRunning: Boolean
        get() = running.get()

    /** Number of admitted requests, including queued handlers and unfinished cancellation cleanup. */
    val activeHandlerCount: Int
        get() = concurrentHandlerLimit - handlerAdmissions.availablePermits()

    /**
     * The number of active connections.
     */
    val connectionCount: Int
        get() = connections.size

    /**
     * The port currently bound by this server. When [port] is `0`, this exposes the port assigned by
     * the operating system after [start] returns. Before start it has the configured [port] value.
     */
    val localPort: Int
        get() = serverSocket?.localPort ?: port

    internal val activeLocalPort: Int
        get() {
            val inactiveMessage = "TcpServer on configured port $port has no active listener; " +
                "start() must complete and stop() must not have begun before reading the bound port."
            val socket = synchronized(connectionLifecycleLock) {
                val listener = serverSocket
                check(running.get() && listener != null) { inactiveMessage }
                listener
            }
            // Caller-supplied socket implementations may block, throw, or re-enter the server.
            val boundPort = socket.localPort
            val socketClosed = socket.isClosed
            return synchronized(connectionLifecycleLock) {
                check(running.get() && serverSocket === socket && !socketClosed) { inactiveMessage }
                boundPort
            }
        }

    /**
     * Reports how many bytes of computed-but-unwritten responses this server currently retains, the
     * largest amount it has ever retained, and the separately tracked bytes admitted to writer
     * queues and charged against the allowances.
     */
    fun responseOutboxSnapshot(): TcpServerResponseOutboxSnapshot {
        val accounting = tcpResponseOutboxAccounting.snapshot(outboxAccounting)
        return TcpServerResponseOutboxSnapshot(
            queuedResponseBytes = accounting.retainedBytes,
            peakQueuedResponseBytes = accounting.peakRetainedBytes,
            perConnectionLimitBytes = TCP_RESPONSE_OUTBOX_BYTES_PER_CONNECTION,
            processWideLimitBytes = TCP_RESPONSE_OUTBOX_BYTES_PROCESS_WIDE,
            emptyOutboxProcessWideLimitBytes = TCP_RESPONSE_OUTBOX_FIRST_RESPONSE_BYTES_PROCESS_WIDE,
            readPauseHighWaterBytes = TCP_RESPONSE_OUTBOX_HIGH_WATER_BYTES,
            undeliverableResponses = undeliverableResponses.get(),
            allowanceChargedResponseBytes = accounting.allowanceChargedBytes,
            peakAllowanceChargedResponseBytes = accounting.peakAllowanceChargedBytes,
        )
    }

    /**
     * Starts the TCP server.
     *
     * @throws IOException if the server socket cannot be created.
     * @throws IllegalStateException if an unfinished stop still owns the previous listener.
     */
    fun start() {
        synchronized(connectionLifecycleLock) {
            check(running.get() || serverSocket == null) {
                "TcpServer on configured port $port still owns its previous listener; " +
                    "finish stop() successfully before starting it again."
            }
            if (!running.compareAndSet(false, true)) {
                return // Already running
            }

            val completion = CompletableFuture<Unit>()
            try {
                val createdSocket = serverSocketFactory.create(port)
                // The factory can call stop() on this same thread while holding the reentrant lock.
                if (!running.get()) {
                    createdSocket.close()
                    return
                }
                serverSocket = createdSocket
                debugLog { "[TcpServer] Listening on port $port" }

                acceptLoopCompletion = completion
                acceptThread = thread(name = "TcpServer-Accept-$port", isDaemon = true) {
                    try {
                        acceptLoop(createdSocket, completion)
                    } finally {
                        completion.complete(Unit)
                    }
                }
            } catch (failure: Throwable) {
                running.set(false)
                try {
                    serverSocket?.close()
                } catch (closeFailure: Exception) {
                    failure.addSuppressed(closeFailure)
                }
                serverSocket = null
                completion.complete(Unit)
                throw failure
            }
        }
    }

    /**
     * Starts the TCP server and blocks until it is stopped.
     *
     * @throws IOException if the server socket cannot be created.
     */
    fun startAndBlock() {
        start()
        acceptThread?.join()
    }

    private fun acceptLoop(socket: ServerSocket, completion: CompletableFuture<Unit>) {
        while (running.get() && serverSocket === socket && acceptLoopCompletion === completion) {
            try {
                val clientSocket = socket.accept()
                handleNewConnection(clientSocket, completion)
            } catch (e: SocketException) {
                if (running.get()) {
                    debugLog { "[TcpServer] Socket error: ${e.message}" }
                }
                // If not running, this is expected from close()
            } catch (e: IOException) {
                if (running.get()) {
                    debugLog { "[TcpServer] Error accepting connection: ${e.message}" }
                }
            }
        }
    }

    private fun handleNewConnection(socket: Socket, completion: CompletableFuture<Unit>) {
        val handler = ConnectionHandler(socket)
        val acceptedWhileRunning = synchronized(connectionLifecycleLock) {
            if (!running.get() || acceptLoopCompletion !== completion) {
                false
            } else {
                connections[socket] = handler
                true
            }
        }
        if (!acceptedWhileRunning) {
            try {
                socket.close()
            } catch (_: Exception) {
                // The socket was already closed while the server was stopping.
            }
            return
        }
        try {
            handler.start()
        } catch (startFailure: Throwable) {
            connections.remove(socket, handler)
            handler.stopForConnectionFailure(startFailure)
            val closeFailure = try {
                socket.close()
                null
            } catch (failure: Exception) {
                startFailure.addSuppressed(failure)
                failure
            }
            val effect = TcpServerReaderThreadStartFailureEffect(
                port,
                startFailure,
                closeFailure,
                handler.startFailureThreadDescription,
            )
            try {
                toss(effect)
            } catch (unhandled: UnhandledNotificationEffect) {
                if (unhandled.effect !== effect) throw unhandled
                // Reader-start reporting is best-effort when the caller has not installed an
                // effect handler. The failed socket is already removed and closed, so the accept
                // loop must remain available for later connections.
            }
            if (!isRecoverableTcpServerReaderStartFailure(startFailure)) {
                throw startFailure
            }
        }
    }

    /**
     * Stops the TCP server and closes all connections. External callers and request handlers wait
     * until the accept loop has finished, so the stopped listener cannot complete another connect.
     * A call from the accept thread or a reentrant lifecycle callback does not wait for itself;
     * external callers still wait for that accept loop to finish. Custom socket and reader factories
     * must return for an external stop to complete. Caller interruption is preserved. A failed
     * listener close is reported after connection cleanup and kept for a later explicit stop.
     */
    fun stop() {
        val reenteredLifecycle = Thread.holdsLock(connectionLifecycleLock)
        var listenerCloseFailure: Exception? = null
        val stoppedNow: Boolean
        val acceptingThread: Thread?
        val completion: CompletableFuture<Unit>
        var cleanupFailure: Throwable? = null
        val stoppedConnections = ArrayList<ConnectionHandler>()
        synchronized(connectionLifecycleLock) {
            stoppedNow = running.compareAndSet(true, false)
            acceptingThread = acceptThread
            completion = acceptLoopCompletion
            // A failed close keeps its listener for a later explicit stop. A nested close callback
            // must return to the close already in progress instead of invoking that close again.
            if (stoppedNow || !reenteredLifecycle) {
                try {
                    serverSocket?.close()
                    serverSocket = null
                } catch (failure: Exception) {
                    listenerCloseFailure = failure
                }
            }
            if (stoppedNow) {
                // Remove queued work across every connection before any stop interrupts a worker.
                // Otherwise that worker could take work owned by a connection later in this traversal.
                for (handler in connections.values) handler.stopAdmissionAndRemoveQueuedTasks()

                // An accept completed during shutdown is either included here or sees running=false
                // after this lock is released and closes its socket without becoming a connection.
                for ((socket, handler) in connections) {
                    stoppedConnections.add(handler)
                    try {
                        handler.stopForServer()
                    } catch (_: Exception) {
                        // Preserve the existing connection-stop failure policy. Completion actions
                        // for queued responses run separately after leaving this lock.
                    } catch (failure: Throwable) {
                        cleanupFailure = combineForwardedCompletionFailures(cleanupFailure, failure)
                    } finally {
                        try {
                            socket.close()
                        } catch (_: Exception) {
                            // Preserve the existing connection-close failure policy.
                        }
                    }
                }
                connections.clear()
            }
        }

        try {
            if (stoppedNow) {
                scope.cancel()
                val discardedTasks = requestExecutor.shutdownNow()
                for (task in discardedTasks) {
                    if (task is TcpServerRequestTask) {
                        task.finishAccounting()
                    }
                }
            }
        } catch (failure: Throwable) {
            cleanupFailure = combineForwardedCompletionFailures(cleanupFailure, failure)
        } finally {
            // Never hold the admission lock here: an accept returned during stop needs it to close
            // its socket. join() on the completion signal preserves interruption, including the
            // cancellation interrupt delivered to a request handler that calls stop itself.
            // Nested socket/factory callbacks must return to the lifecycle operation they reentered.
            // A close that failed to release accept cannot be joined; report it to the caller.
            if (listenerCloseFailure == null && Thread.currentThread() !== acceptingThread && !reenteredLifecycle) {
                completion.join()
            }
        }
        for (handler in stoppedConnections) {
            try {
                // A forwarded completion action may re-enter stop from another thread. All
                // stop state and shared worker shutdown are settled before invoking it.
                handler.releaseStoppedResponses()
            } catch (failure: Throwable) {
                cleanupFailure = combineForwardedCompletionFailures(cleanupFailure, failure)
            }
        }
        listenerCloseFailure?.let {
            cleanupFailure = combineForwardedCompletionFailures(cleanupFailure, it)
        }
        cleanupFailure?.let { throw it }

        if (stoppedNow) debugLog { "[TcpServer] Stopped" }
    }

    override fun close() {
        stop()
    }

    private inner class ConnectionHandler(private val socket: Socket) {
        private val admissionOrder = nextServiceConnectionAdmissionOrder()
        private val active = AtomicBoolean(true)
        @Volatile private var readerThread: Thread? = null
        @Volatile private var writerThread: Thread? = null
        @Volatile private var connectionOutput: java.io.OutputStream? = null
        private val activeWriteJob = AtomicReference<ResponseWriteJob?>()

        // The connection lifecycle is shared by peer-driven disconnect and server-driven stop.
        // Publishing it before either path interrupts request handlers lets those handlers observe
        // why their blocked work ended instead of mistaking teardown for caller-owned interruption.
        private val connectionId = "tcp-conn-${socket.remoteSocketAddress}-${nextTcpConnectionId()}"
        private val closeLock = Any()
        private val closeListeners = ArrayList<() -> Unit>()
        private val closeListenersFired = AtomicBoolean(false)
        private val connectionCloseCause = AtomicReference<Throwable?>(null)

        private fun registerCloseListener(listener: () -> Unit) {
            val fireNow = synchronized(closeLock) {
                if (closeListenersFired.get()) true else { closeListeners.add(listener); false }
            }
            if (fireNow) {
                invokeCloseListener(listener, immediate = true)
            }
        }

        private fun publishCloseState(cause: Throwable) {
            connectionCloseCause.compareAndSet(null, cause)
        }

        private fun reportCloseListenerFailure(failure: Throwable, immediate: Boolean) {
            val failureClassName = failure.javaClass.name
            val timing = if (immediate) " during immediate notification" else ""
            try {
                System.err.println(
                    "[TcpServer] TCP close listener failed for $connectionId$timing: " +
                        "$failureClassName: ${failure.message}",
                )
                failure.printStackTrace(System.err)
            } catch (reportingFailure: Throwable) {
                rethrowFatalJvmError(reportingFailure)
                // The configured stderr sink rejected both the listener's details and any useful
                // fallback written to that same sink. Do not let that sink failure skip another
                // listener or transport cleanup.
            }
        }

        private fun invokeCloseListener(listener: () -> Unit, immediate: Boolean) {
            try {
                listener()
            } catch (failure: Throwable) {
                reportCloseListenerFailure(failure, immediate)
                rethrowFatalJvmError(failure)
            }
        }

        private fun fireCloseListeners() {
            val toFire = synchronized(closeLock) {
                if (!closeListenersFired.compareAndSet(false, true)) return
                val snapshot = ArrayList(closeListeners)
                closeListeners.clear()
                snapshot
            }
            for (listener in toFire) {
                closeListenerDispatcher.execute {
                    invokeCloseListener(listener, immediate = false)
                }
            }
        }

        // Requests belong to the connection that admitted them. If that connection ends before a
        // handler does, the caller can no longer receive the result and the handler must not keep a
        // process-wide admission slot indefinitely. This set includes queued and running work and is
        // guarded separately from the response outbox because either side may complete first.
        private val requestTasksLock = Any()
        private val requestTasks = HashSet<ConnectionRequestTask>()

        /**
         * Names the per-connection thread whose start failed, so [handleNewConnection] reports the
         * one that actually could not start.
         */
        @Volatile var startFailureThreadDescription: String = TCP_SERVER_READER_THREAD_DESCRIPTION
            private set

        // Responses computed but not yet written. One writer thread drains this queue in FIFO order,
        // so no handler thread blocks on the peer's socket to deliver its response and this
        // connection's responses keep the order their handlers finished in. (Effect propagation is
        // the one thing a handler still writes itself; it does not go through this queue.) The lock
        // guards the queue and all three byte counters, and is the monitor the reader waits on
        // while its outbox is above the high-water mark.
        private val outboxLock = Object()
        private val outbox = ArrayDeque<ResponseWriteJob>()
        private var outboxResponseBytes = 0L
        private var outboxFailureBytes = 0L
        private val outboxResponseAttachmentReferences = IdentityHashMap<ByteArray, Int>()
        private val outboxFailureAttachmentReferences = IdentityHashMap<ByteArray, Int>()
        // Computed responses this connection is holding while they wait for the allowance shared by
        // every connection. They are not in the deque and are invisible to writers, but they are
        // included in the public retained-byte accounting from construction. They are not part of
        // the admitted, allowance-charged subset. outboxPendingResponseBytes is the per-connection
        // tracker used to pause this connection's reader while a response waits.
        private var outboxPendingResponseBytes = 0L

        private fun connectionAttachmentReferences(
            failureLane: Boolean,
        ): IdentityHashMap<ByteArray, Int> = if (failureLane) {
            outboxFailureAttachmentReferences
        } else {
            outboxResponseAttachmentReferences
        }

        private fun additionalConnectionBytes(job: ResponseWriteJob): Long =
            job.baseRetainedBytes + additionalAttachmentBytes(
                job.attachments,
                connectionAttachmentReferences(job.failureLane),
            )

        private fun chargeConnection(job: ResponseWriteJob): Long =
            job.baseRetainedBytes + retainAttachments(
                job.attachments,
                connectionAttachmentReferences(job.failureLane),
            )

        private fun releaseConnection(job: ResponseWriteJob): Long =
            job.baseRetainedBytes + releaseAttachments(
                job.attachments,
                connectionAttachmentReferences(job.failureLane),
            )

        fun start() {
            if (!active.get()) return
            connectionOutput = socket.getOutputStream()
            if (!active.get()) return
            val startedReaderThread = readerThreadFactory.start(
                name = "TcpServer-Reader-${socket.remoteSocketAddress}"
            ) { handleConnection() }
            readerThread = startedReaderThread
            if (!active.get()) {
                startedReaderThread.interrupt()
                return
            }
            startFailureThreadDescription = TCP_SERVER_WRITER_THREAD_DESCRIPTION
            // Not readerThreadFactory: see TcpServerReaderThreadFactory. This thread blocks on the
            // socket while holding the connection's output monitor, so it must be a platform thread.
            val startedWriterThread = thread(
                name = "TcpServer-Writer-${socket.remoteSocketAddress}",
                isDaemon = true,
            ) { writeLoop() }
            writerThread = startedWriterThread
            if (!active.get()) {
                startedWriterThread.interrupt()
            }
        }

        fun stopAdmissionAndRemoveQueuedTasks() {
            publishServerStopState()
            active.set(false)
            val abandoned = synchronized(requestTasksLock) { ArrayList(requestTasks) }
            for (task in abandoned) task.cancelQueued()
        }

        fun stopForServer() {
            publishServerStopState()
            stopAfterCausePublication(releaseQueued = false)
        }

        fun releaseStoppedResponses() = releaseQueuedJobs(suppressObserverExceptions = true)

        fun stopForConnectionFailure(cause: Throwable) {
            publishCloseState(cause)
            stopAfterCausePublication()
        }

        private fun stopAfterCausePublication(releaseQueued: Boolean = true) {
            active.set(false)
            cancelRequestTasks()
            fireCloseListeners()
            releaseActiveWriteJob()
            synchronized(outboxLock) { outboxLock.notifyAll() }
            readerThread?.interrupt()
            writerThread?.interrupt()
            if (releaseQueued) releaseQueuedJobs()
        }

        private fun publishServerStopState() {
            publishCloseState(
                IOException("TCP connection $connectionId closed because TcpServer on port $port stopped."),
            )
        }

        /**
         * One admitted request owned by this connection. Cancellation interrupts a running handler,
         * or removes work that has not started from the executor queue. Its admission is returned
         * only after the handler has really exited (or a queued task has really been removed), so a
         * handler that ignores interruption still counts against the configured thread limit.
         */
        private inner class ConnectionRequestTask(
            private val request: Libp2pRpcProtocol.RpcRequest,
            private val effectPropagator: EffectPropagator,
            private val releaseAdmission: () -> Unit,
        ) : TcpServerRequestTask {
            private val started = AtomicBoolean(false)
            private val cancellationRequested = AtomicBoolean(false)
            private val accountingFinished = AtomicBoolean(false)
            private val runnerLock = Any()
            private var runner: Thread? = null

            override fun run() {
                if (!started.compareAndSet(false, true)) return
                synchronized(runnerLock) { runner = Thread.currentThread() }
                try {
                    if (cancellationRequested.get() || !active.get() || !running.get() || socket.isClosed) return
                    runHandlerAndQueueResponse(
                        request, effectPropagator, releaseAdmission, cancellationRequested::get,
                    )
                } catch (_: InterruptedException) {
                    // Connection cancellation is consumed here after dispatched handler work exits.
                } catch (_: CancellationException) {
                    // Server scope cancellation likewise ends this request, not its pool worker.
                } finally {
                    synchronized(runnerLock) {
                        runner = null
                        // Cancellation cannot retain a runner reference past this point and
                        // interrupt the next task that reuses this worker.
                        Thread.interrupted()
                    }
                    finishAccounting()
                }
            }

            fun cancelQueued() {
                cancellationRequested.set(true)
                // A worker may have taken the task between the started read and remove(). In that
                // case run() observes cancellationRequested and performs accounting when it exits.
                if (!started.get() && requestExecutor.remove(this)) {
                    finishAccounting()
                }
            }

            fun interruptRunning() {
                synchronized(runnerLock) { runner?.interrupt() }
            }

            override fun finishAccounting() {
                if (!accountingFinished.compareAndSet(false, true)) return
                releaseAdmission()
                requestTaskQueue.submittedTasks.decrementAndGet()
                synchronized(requestTasksLock) {
                    requestTasks.remove(this)
                }
            }
        }

        private fun cancelRequestTasks() {
            val abandoned = synchronized(requestTasksLock) { ArrayList(requestTasks) }
            for (task in abandoned) task.cancelQueued()
            for (task in abandoned) task.interruptRunning()
        }

        private fun releaseActiveWriteJob() {
            activeWriteJob.get()?.onCancel?.invoke()
        }

        /**
         * Drains this connection's writer queue onto the socket. Exactly one of these runs per
         * connection, which is what keeps handler threads off the socket and response frames in
         * order. Every frame is written under the connection's output monitor, so a queued response
         * can never interleave with a server-initiated push, an effect frame, a pong, or a refusal.
         */
        private fun writeLoop() {
            val output = connectionOutput ?: return
            var writerFailure: Throwable? = null
            try {
                while (true) {
                    val job = synchronized(outboxLock) {
                        while (outbox.isEmpty()) {
                            if (!active.get() || socket.isClosed) return
                            try {
                                outboxLock.wait(OUTBOX_WAIT_MILLIS)
                            } catch (_: InterruptedException) {
                                Thread.currentThread().interrupt()
                                return
                            }
                        }
                        if (!active.get() || socket.isClosed) return
                        outbox.removeFirst().also { nextJob ->
                            check(activeWriteJob.compareAndSet(null, nextJob)) {
                                "A TCP connection cannot have more than one active response writer"
                            }
                        }
                    }
                    // Recheck after publication, outside the outbox monitor: releasing a
                    // forwarded job can invoke caller completion actions.
                    if (!active.get() || socket.isClosed) {
                        try { releaseJob(job) } finally {
                            check(activeWriteJob.compareAndSet(job, null)) {
                                "The active TCP response writer changed while its connection closed"
                            }
                        }
                        return
                    }
                    var writeFailure: Throwable? = null
                    try {
                        synchronized(output) { job.write(output) }
                    } catch (failure: Throwable) {
                        writeFailure = failure
                        // Publish the write failure and close before completion actions run,
                        // matching the existing transport-failure ordering.
                        publishCloseState(failure)
                        try {
                            socket.close()
                        } catch (closeFailure: Throwable) {
                            writeFailure = combineForwardedCompletionFailures(writeFailure, closeFailure)
                        }
                    }
                    var releaseFailed = false
                    try {
                        releaseJob(job)
                    } catch (failure: Throwable) {
                        releaseFailed = true
                        // The existing release observer remains primary over an ordinary write
                        // failure. The combiner still gives any fatal failure precedence.
                        writeFailure = writeFailure?.let {
                            combineForwardedCompletionFailures(failure, it)
                        } ?: failure
                    } finally {
                        check(activeWriteJob.compareAndSet(job, null)) {
                            "The active TCP response writer changed before its write completed"
                        }
                    }
                    writeFailure?.let { failure ->
                        if (releaseFailed || failure !is Exception) throw failure
                        publishCloseState(failure)
                        debugLog {
                            "[TcpServer] Writing a response to ${socket.remoteSocketAddress} failed: ${failure.message}"
                        }
                        try {
                            socket.close()
                        } catch (_: Exception) {
                            // Already closed; the reader's finally block still runs.
                        }
                        return
                    }
                }
            } catch (failure: Throwable) {
                // A completion action can fail after a successful write. Retire the connection
                // before propagating it, so later calls cannot be admitted without a writer.
                writerFailure = failure
                active.set(false)
                publishCloseState(failure)
                try {
                    socket.close()
                } catch (closeFailure: Throwable) {
                    writerFailure = combineForwardedCompletionFailures(writerFailure, closeFailure)
                }
            } finally {
                try {
                    releaseQueuedJobs()
                } catch (releaseFailure: Throwable) {
                    writerFailure = combineForwardedCompletionFailures(writerFailure, releaseFailure)
                }
                writerFailure?.let { throw it }
            }
        }

        /**
         * Attempts to charge [job] against this connection's and the process's undelivered-response
         * allowance and, once admitted, hands it to the writer thread. Returns
         * [ResponseQueueOutcome.AllowanceExhausted] when the allowance is exhausted, which is what
         * keeps allowance-charged response bytes bounded no matter how many requests a non-reading
         * peer pipelines.
         *
         * A job waiting for the shared allowance remains in retained-byte accounting until it is
         * admitted or released.
         *
         * The one thing this waits for is the allowance shared by every connection, and only for a
         * job whose own connection holds nothing undelivered — see
         * [TCP_RESPONSE_OUTBOX_SHARED_ALLOWANCE_WAIT_MILLIS]. Every refusal this connection's own
         * peer earns, including every refusal a peer that stopped reading earns, is returned
         * immediately as before, so a stalled peer never parks a handler thread here.
         */
        private fun enqueueResponse(job: ResponseWriteJob): ResponseQueueOutcome {
            val sharedAllowanceDeadlineNanos = System.nanoTime() +
                TimeUnit.MILLISECONDS.toNanos(TCP_RESPONSE_OUTBOX_SHARED_ALLOWANCE_WAIT_MILLIS)
            var awaitingSharedAllowance = false
            var handedToWriter = false
            try {
                while (true) {
                    // Read before the charge attempt below, so a release that lands between the
                    // failed charge and the wait is observed rather than slept through.
                    val releasesBeforeAttempt = tcpResponseOutboxReleases.get()
                    val attempt = synchronized(outboxLock) {
                        if (!active.get() || socket.isClosed) {
                            return ResponseQueueOutcome.ConnectionClosed
                        }
                        // Nothing is undelivered for this peer, so an ordinary response is not a
                        // pileup: it is either the ordinary case of a peer that is keeping up, or
                        // the one response that is legitimately larger than the whole per-connection
                        // allowance. Both are admitted under the higher single-response ceiling
                        // rather than refused, so the per-connection allowance does not apply to
                        // them at all.
                        val emptyOutbox = outboxResponseBytes == 0L && outboxFailureBytes == 0L
                        val perConnectionApplies = job.failureLane || !emptyOutbox
                        val laneBytes =
                            if (job.failureLane) outboxFailureBytes else outboxResponseBytes
                        val perConnectionLimit = if (job.failureLane) {
                            TCP_RESPONSE_OUTBOX_FAILURE_BYTES_PER_CONNECTION
                        } else {
                            TCP_RESPONSE_OUTBOX_BYTES_PER_CONNECTION
                        }
                        val processWideLimit = when {
                            job.failureLane -> TCP_RESPONSE_OUTBOX_FAILURE_BYTES_PROCESS_WIDE
                            emptyOutbox -> TCP_RESPONSE_OUTBOX_FIRST_RESPONSE_BYTES_PROCESS_WIDE
                            else -> TCP_RESPONSE_OUTBOX_BYTES_PROCESS_WIDE
                        }
                        val connectionChargeBytes = additionalConnectionBytes(job)
                        // Every value a refusal reports is read here, under the same lock that
                        // decides it, so the message states what was actually observed rather than
                        // what is typical.
                        if (perConnectionApplies &&
                            laneBytes + connectionChargeBytes > perConnectionLimit
                        ) {
                            EnqueueAttempt.Refused(
                                TcpServerResponseOutboxRefusal(
                                    exceededAllowance = if (job.failureLane) {
                                        TcpServerResponseOutboxAllowance.PER_CONNECTION_FAILURE_REPLY
                                    } else {
                                        TcpServerResponseOutboxAllowance.PER_CONNECTION
                                    },
                                    responseBytes = job.wireBytes,
                                    connectionUndeliveredBytes = laneBytes,
                                    processWideUndeliveredBytes =
                                        tcpResponseOutboxAccounting.currentBytes(job.failureLane),
                                    allowanceLimitBytes = perConnectionLimit,
                                    retainedResponseBytes = connectionChargeBytes,
                                )
                            )
                        } else when (val processCharge = tcpResponseOutboxAccounting.tryAdmit(
                            outboxAccounting,
                            job,
                            processWideLimit,
                        )) {
                            is ProcessWideChargeAttempt.Refused -> {
                                val refusal = TcpServerResponseOutboxRefusal(
                                    exceededAllowance = when {
                                        job.failureLane ->
                                            TcpServerResponseOutboxAllowance.PROCESS_WIDE_FAILURE_REPLY
                                        emptyOutbox ->
                                            TcpServerResponseOutboxAllowance.PROCESS_WIDE_EMPTY_OUTBOX
                                        else -> TcpServerResponseOutboxAllowance.PROCESS_WIDE
                                    },
                                    responseBytes = job.wireBytes,
                                    connectionUndeliveredBytes = laneBytes,
                                    processWideUndeliveredBytes = processCharge.currentBytes,
                                    allowanceLimitBytes = processWideLimit,
                                    retainedResponseBytes = processCharge.retainedResponseBytes,
                                )
                                // A refusal reply must reach its caller now — it is the answer to a
                                // response that was already refused — and a connection that is holding
                                // undelivered bytes of its own has shown nothing about whether waiting
                                // would help. Only the empty outbox is evidence that this peer consumed
                                // everything computed for it, so only that job waits.
                                if (job.failureLane || !emptyOutbox) {
                                    EnqueueAttempt.Refused(refusal)
                                } else {
                                    if (!awaitingSharedAllowance) {
                                        awaitingSharedAllowance = true
                                        // Undelivered bytes this connection is holding: they pause its
                                        // reader exactly as queued bytes do, so a peer cannot pipeline
                                        // further work behind a response that is already waiting.
                                        outboxPendingResponseBytes += job.maximumRetainedBytes
                                    }
                                    EnqueueAttempt.AwaitSharedAllowance(refusal)
                                }
                            }
                            ProcessWideChargeAttempt.Acquired -> {
                                val chargedConnectionBytes = chargeConnection(job)
                                check(chargedConnectionBytes == connectionChargeBytes)
                                if (job.failureLane) {
                                    outboxFailureBytes += chargedConnectionBytes
                                } else {
                                    outboxResponseBytes += chargedConnectionBytes
                                }
                                job.connectionCharged = true
                                outbox.addLast(job)
                                job.writerPublished = true
                                handedToWriter = true
                                outboxLock.notifyAll()
                                EnqueueAttempt.Queued(job.initialServerRetainedBytes)
                            }
                        }
                    }
                    when (attempt) {
                        is EnqueueAttempt.Queued -> {
                            responseOutboxObserver?.onResponseQueued(
                                attempt.serverBytes,
                                job.failureLane,
                            )
                            return ResponseQueueOutcome.Queued
                        }
                        is EnqueueAttempt.Refused ->
                            return ResponseQueueOutcome.AllowanceExhausted(attempt.refusal)
                        is EnqueueAttempt.AwaitSharedAllowance -> {
                            if (!awaitSharedAllowanceRelease(
                                    releasesBeforeAttempt,
                                    sharedAllowanceDeadlineNanos,
                                )
                            ) {
                                return ResponseQueueOutcome.AllowanceExhausted(attempt.refusal)
                            }
                        }
                    }
                }
            } finally {
                if (awaitingSharedAllowance) {
                    synchronized(outboxLock) {
                        outboxPendingResponseBytes -= job.maximumRetainedBytes
                        outboxLock.notifyAll()
                    }
                }
                if (!handedToWriter) releaseJob(job)
            }
        }

        /**
         * Waits for some connection in this process to return shared undelivered-response bytes.
         * Returns false once [deadlineNanos] has passed — or if this thread is interrupted — which
         * is what turns a shortage no delivery is clearing into the refusal the caller is owed.
         *
         * A release counted since [releasesBeforeAttempt] means capacity was returned while this
         * caller was between its failed charge and this wait, so it retries without waiting at all.
         * Otherwise the wait is re-checked at [OUTBOX_WAIT_MILLIS], which bounds how long a lost
         * notification can delay a retry.
         */
        private fun awaitSharedAllowanceRelease(
            releasesBeforeAttempt: Long,
            deadlineNanos: Long,
        ): Boolean {
            val remainingNanos = deadlineNanos - System.nanoTime()
            if (remainingNanos <= 0L) return false
            val waitMillis = minOf(
                OUTBOX_WAIT_MILLIS,
                TimeUnit.NANOSECONDS.toMillis(remainingNanos) + 1L,
            )
            synchronized(tcpResponseOutboxSharedAllowance) {
                if (tcpResponseOutboxReleases.get() != releasesBeforeAttempt) return true
                try {
                    tcpResponseOutboxSharedAllowance.wait(waitMillis)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return false
                }
            }
            return true
        }

        private fun releaseJob(job: ResponseWriteJob, suppressObserverExceptions: Boolean = false) {
            if (!job.released.compareAndSet(false, true)) return
            val releasedServerBytes = synchronized(outboxLock) {
                if (job.connectionCharged) {
                    val releasedConnectionBytes = releaseConnection(job)
                    if (job.failureLane) {
                        outboxFailureBytes -= releasedConnectionBytes
                    } else {
                        outboxResponseBytes -= releasedConnectionBytes
                    }
                    job.connectionCharged = false
                }
                val serverBytes = tcpResponseOutboxAccounting.release(outboxAccounting, job)
                outboxLock.notifyAll()
                serverBytes
            }
            synchronized(tcpResponseOutboxSharedAllowance) {
                tcpResponseOutboxSharedAllowance.notifyAll()
            }
            var failure: Throwable? = null
            try {
                if (job.writerPublished) {
                    responseOutboxObserver?.onResponseReleased(releasedServerBytes, job.failureLane)
                }
            } catch (next: Throwable) {
                if (!suppressObserverExceptions || next !is Exception) {
                    failure = next
                }
                // Server stop historically ignored ordinary outbox-observer failures. Keep that
                // policy while still reporting failures from the new completion actions below.
            }
            try {
                job.onRelease()
            } catch (next: Throwable) {
                failure = combineForwardedCompletionFailures(failure, next)
            }
            failure?.let { throw it }
        }

        private fun releaseQueuedJobs(suppressObserverExceptions: Boolean = false) {
            val abandoned = synchronized(outboxLock) {
                val snapshot = ArrayList(outbox)
                outbox.clear()
                snapshot
            }
            var failure: Throwable? = null
            for (job in abandoned) {
                try {
                    releaseJob(job, suppressObserverExceptions)
                } catch (next: Throwable) {
                    failure = combineForwardedCompletionFailures(failure, next)
                }
            }
            failure?.let { throw it }
        }

        /**
         * Pauses this connection's reader while its own undelivered responses are above the
         * high-water mark. The peer's receive window fills and its writes block, so a peer that
         * stops reading throttles itself and nothing else. A response waiting for the shared
         * allowance counts here too, so a peer cannot pipeline more work behind one.
         */
        private fun awaitOutboxBelowHighWaterMark() {
            synchronized(outboxLock) {
                while (active.get() && !socket.isClosed &&
                    outboxResponseBytes + outboxFailureBytes + outboxPendingResponseBytes >
                    TCP_RESPONSE_OUTBOX_HIGH_WATER_BYTES
                ) {
                    try {
                        outboxLock.wait(OUTBOX_WAIT_MILLIS)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return
                    }
                }
            }
        }

        private fun handleConnection() {
            val input = socket.getInputStream()
            val output = connectionOutput ?: return
            val clientAddress = socket.remoteSocketAddress.toString()

            debugLog { "[TcpServer] New connection from $clientAddress" }

            // The per-connection effect propagator doubles as the ServiceClientConnection handed to a
            // ConnectionAwareServiceHandler: it is the connection-scoped server→client push channel.
            val effectPropagator = object : EffectPropagator, DisconnectableServiceClientConnection,
                CloseAwareServiceClientConnection, AdmissionOrderedServiceClientConnection {
                override val admissionOrder: Long = this@ConnectionHandler.admissionOrder
                override val connectionId: String = this@ConnectionHandler.connectionId
                override val remotePeerId: String? = null
                override val isOpen: Boolean
                    get() = active.get() && !socket.isClosed && connectionCloseCause.get() == null
                override val closeCause: Throwable?
                    get() = connectionCloseCause.get()

                override fun push(frame: JSONObject) {
                    // Reject reserved/typeless frames before touching the connection (caller error).
                    validatePushableFrame(frame)
                    if (!isOpen) {
                        throw ServicePushException(
                            "Cannot push to connection ${this.connectionId}: the client connection is closed"
                        )
                    }
                    // A blocking java.net.Socket OutputStream has no send timeout, so a client that
                    // stops reading would park this write forever. Bound it with a watchdog that
                    // closes the socket if the write has not completed within the same delivery window
                    // the libp2p path uses (WRITE_BACKPRESSURE_DELIVERY_WAIT_MS): closing the socket
                    // unblocks the wedged write (it throws), which we surface as a ServicePushException
                    // and which also tears the dead connection down. See ServiceClientConnection.push
                    // for the documented per-transport deadline semantics.
                    val timeoutCause = IOException(
                        "TCP connection ${this.connectionId} closed because a server-initiated push " +
                            "exceeded the ${WRITE_BACKPRESSURE_DELIVERY_WAIT_MS}ms delivery window."
                    )
                    val watchdog = pushWriteWatchdog.schedule({
                        publishCloseState(timeoutCause)
                        try { socket.close() } catch (_: Exception) {}
                    }, WRITE_BACKPRESSURE_DELIVERY_WAIT_MS, java.util.concurrent.TimeUnit.MILLISECONDS)
                    try {
                        synchronized(output) {
                            Libp2pRpcProtocol.writeMessage(output, frame)
                        }
                    } catch (e: Exception) {
                        if (connectionCloseCause.get() === timeoutCause) {
                            throw ServicePushException(
                                "Push of a server-initiated frame to connection ${this.connectionId} " +
                                    "exceeded the ${WRITE_BACKPRESSURE_DELIVERY_WAIT_MS}ms delivery " +
                                    "window (the client stopped reading and the socket send buffer " +
                                    "filled); the connection was torn down",
                                e
                            )
                        }
                        throw ServicePushException(
                            "Failed to push a server-initiated frame to connection ${this.connectionId}: ${e.message}",
                            e
                        )
                    } finally {
                        watchdog.cancel(false)
                    }
                }

                override fun onClose(listener: () -> Unit) {
                    registerCloseListener(listener)
                }

                override fun disconnect() {
                    if (!socket.isClosed) {
                        publishCloseState(
                            IOException(
                                "TCP connection $connectionId closed by " +
                                    "DisconnectableServiceClientConnection.disconnect()."
                            )
                        )
                        socket.close()
                    }
                }

                override suspend fun propagateRequestEffect(effectType: String, effectData: JSONObject): Any? {
                    // Send effect request to client and wait for response
                    val effectId = Libp2pRpcProtocol.nextRequestId()
                    val effectRequest = Libp2pRpcProtocol.EffectRequest(
                        id = effectId,
                        effectType = effectType,
                        effectData = effectData,
                        isNotification = false
                    )
                    synchronized(output) {
                        Libp2pRpcProtocol.writeMessage(output, effectRequest.toJson())
                    }
                    // For now, we don't wait for effect responses
                    // This would need a more complex implementation
                    return null
                }

                override suspend fun propagateNotificationEffect(effectType: String, effectData: JSONObject) {
                    val effectRequest = Libp2pRpcProtocol.EffectRequest(
                        id = Libp2pRpcProtocol.nextRequestId(),
                        effectType = effectType,
                        effectData = effectData,
                        isNotification = true
                    )
                    synchronized(output) {
                        Libp2pRpcProtocol.writeMessage(output, effectRequest.toJson())
                    }
                }
            }

            try {
                while (active.get() && !socket.isClosed) {
                    try {
                        // Backpressure before the next request rather than after it: while this
                        // peer's own responses are piling up undelivered, reading more of its
                        // requests only produces more responses it is not draining.
                        awaitOutboxBelowHighWaterMark()
                        if (!active.get() || socket.isClosed) break
                        val frame = Libp2pRpcProtocol.readMessageFrameFromStream(input)
                        // The read above can block while a preceding handler finishes and queues a
                        // response. Recheck after the complete frame arrives so that request does
                        // not slip behind newly charged bytes merely because the reader observed an
                        // empty outbox before it started waiting for the frame.
                        awaitOutboxBelowHighWaterMark()
                        if (!active.get() || socket.isClosed) break

                        when (val type = frame.json.optString("type", "")) {
                            Libp2pRpcProtocol.TYPE_REQUEST -> {
                                val msg = Libp2pRpcProtocol.RpcRequest.fromJson(frame.json, frame.attachments)
                                dispatchRequest(msg, effectPropagator, output)
                            }
                            Libp2pRpcProtocol.TYPE_PING -> {
                                // Respond to ping
                                synchronized(output) {
                                    Libp2pRpcProtocol.writeMessage(output, Libp2pRpcProtocol.PongMessage.toJson())
                                }
                            }
                            else -> {
                                // Ignore other message types for now
                            }
                        }
                    } catch (e: EOFException) {
                        // Client disconnected
                        publishCloseState(e)
                        break
                    } catch (e: IOException) {
                        publishCloseState(e)
                        if (active.get()) {
                            debugLog { "[TcpServer] Error reading from $clientAddress: ${e.message}" }
                        }
                        break
                    }
                }
            } finally {
                // A normal loop exit still represents a peer close. Server stop and caught read
                // failures publish before reaching this point, so compare-and-set retains the
                // terminal event that happened first.
                publishCloseState(IOException("TCP connection $connectionId closed by its peer."))
                active.set(false)
                // A disconnected caller cannot receive handler results, and leaving its work
                // parked would permanently consume the process-wide request-handler allowance.
                cancelRequestTasks()
                // Notify any ConnectionAwareServiceHandler that registered interest via onClose so
                // a connection-scoped subscription lease is reaped promptly. Idempotent (fires
                // exactly once); also called by server stop.
                fireCloseListeners()
                active.set(false)
                releaseActiveWriteJob()
                connections.remove(socket)
                try {
                    socket.close()
                } catch (e: Exception) {
                    // Ignore
                }
                // Wake this connection's writer thread so it stops, discards anything still queued,
                // and returns its bytes to the per-connection and process-wide allowances.
                synchronized(outboxLock) { outboxLock.notifyAll() }
                debugLog { "[TcpServer] Connection closed from $clientAddress" }
            }
        }

        private fun dispatchRequest(
            request: Libp2pRpcProtocol.RpcRequest,
            effectPropagator: EffectPropagator,
            output: java.io.OutputStream,
        ) {
            if (!running.get() || !active.get() || socket.isClosed) return
            if (!handlerAdmissions.tryAcquire()) {
                refuseForConcurrentHandlerLimit(request, output)
                return
            }
            // Released exactly once, by whichever of the paths below reaches it first.
            val admissionReleased = AtomicBoolean(false)
            val releaseAdmission = {
                if (admissionReleased.compareAndSet(false, true)) {
                    handlerAdmissions.release()
                }
            }
            val task = ConnectionRequestTask(request, effectPropagator, releaseAdmission)
            var acceptedByExecutor = false
            // Counted from here so ElasticHandlerTaskQueue can tell whether a worker will be free to
            // take this task from the queue; the task itself decrements when it returns.
            requestTaskQueue.submittedTasks.incrementAndGet()
            try {
                synchronized(requestTasksLock) {
                    if (!running.get() || !active.get() || socket.isClosed) {
                        task.finishAccounting()
                        return
                    }
                    requestTasks.add(task)
                    // Submission and connection cancellation are serialized by requestTasksLock.
                    // Thus cancelQueued() can never account a task before execute() has either accepted or
                    // rejected it, which keeps the executor queue and submittedTasks in agreement.
                    requestExecutor.execute(task)
                    acceptedByExecutor = true
                }
            } catch (rejected: RejectedExecutionException) {
                if (requestExecutor.isShutdown || !running.get() || !active.get()) {
                    return
                }
                // Admission has already accepted this request and the queue is unbounded, so the
                // pool only rejects while shutting down — handled above. Reporting the
                // concurrent-handler limit here would be exactly the false statement this accounting
                // exists to remove, so say what actually happened instead.
                reportRequestDispatchFailure(request, rejected, output)
            } finally {
                // execute() rejection is the only path on which this admitted task neither runs nor
                // becomes removable from the queue. All accepted paths account themselves.
                if (!acceptedByExecutor) {
                    task.finishAccounting()
                }
            }
        }

        private fun runHandlerAndQueueResponse(
            request: Libp2pRpcProtocol.RpcRequest,
            effectPropagator: EffectPropagator,
            releaseAdmission: () -> Unit,
            cancellationRequested: () -> Boolean,
        ) {
            runTcpRequestBlocking(scope.coroutineContext, cancellationRequested) {
                // Only the request handler's own exception is reported with structured details.
                // Encoding the handler's successful response is framework work (forwarded-stream
                // headers, value encoding): its failures keep the same text but carry none.
                // The outcome is held in a Result rather than signalled by null, so a handler that
                // returns null (from Java or through an erased type) still takes the response path
                // below and is answered exactly as before, with no details.
                val handled: Result<Libp2pRpcProtocol.RpcResponse> = try {
                    Result.success(coroutineScope { requestHandler(request, effectPropagator) })
                } catch (failure: Exception) {
                    Result.failure(failure)
                }
                // A handler can return with its worker interrupted. Clear that worker-local state
                // before framework response preparation; server cancellation is recorded separately
                // in cancellationRequested before the worker is interrupted.
                Thread.interrupted()
                val handlerFailure = handled.exceptionOrNull()
                val job = if (handlerFailure == null) {
                    var prepared: ResponseWriteJob? = null
                    try {
                        val response = handled.getOrThrow()
                        val lease = try {
                            (encodingFailureHandler as? RpcResponseEncodingResourceHandler)?.let { owner ->
                                kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                                    owner.responseEncodingLease(request, response, effectPropagator)
                                }
                            }
                        } catch (leaseFailure: Throwable) {
                            RpcEncodingResources().refuse(
                                listOf(response.result, response.error?.data), leaseFailure,
                            )
                            throw leaseFailure
                        }
                        withRpcResponseEncodingLease(lease) { resources ->
                            buildResponseWriteJob(response, resources).also { prepared = it }
                        }
                    } catch (preparationFailure: Throwable) {
                        var responseFailure = preparationFailure
                        // A completion callback can fail after preparation retained a job.
                        // Return that storage before constructing the request's error reply.
                        prepared?.let { retained ->
                            val cleanupInterruptStatus = RpcEncodingInterruptStatus()
                            try {
                                try {
                                    releaseJob(retained)
                                } catch (releaseFailure: Throwable) {
                                    cleanupInterruptStatus.observe(releaseFailure)
                                    responseFailure = combineForwardedCompletionFailures(responseFailure, releaseFailure)
                                }
                            } finally {
                                cleanupInterruptStatus.restore()
                            }
                        }
                        // Response preparation has left accounting and output locks. Cleanup may
                        // re-enter this connection, and survives its request being cancelled.
                        val response = handled.getOrThrow()
                        val reason = rpcResponseEncodingFailureReason(
                            responseFailure,
                            encodingFailureHandler?.let { owner ->
                                { failure -> owner.onResponseEncodingFailure(
                                    request, response, effectPropagator, failure,
                                ) }
                            },
                        ) { "Handler error: ${rpcEncodingFailureDescription(responseFailure, includeClassName = false)}" }
                        buildFailureResponseWriteJob(
                            request,
                            Libp2pRpcProtocol.RpcError(Libp2pRpcProtocol.ERROR_INTERNAL, reason),
                        )
                    }
                } else {
                    buildFailureResponseWriteJob(
                        request,
                        applicationFailureRpcError(
                            handlerFailure,
                            Libp2pRpcProtocol.ERROR_INTERNAL,
                            "Handler error: ${handlerFailure.message}",
                        ),
                    )
                }
                // An interrupt can arrive after encoding yields, while a non-cancellable
                // failure callback is suspended. Observe it before publishing the reply so that
                // the request cancellation cannot lose a race with response enqueueing.
                if (Thread.interrupted() || cancellationRequested()) {
                    releaseAdmission()
                    val cleanupInterruptStatus = RpcEncodingInterruptStatus()
                    try {
                        try {
                            job?.let(::releaseJob)
                        } catch (cleanupFailure: Throwable) {
                            cleanupInterruptStatus.observe(cleanupFailure)
                            throw cleanupFailure
                        }
                    } finally {
                        cleanupInterruptStatus.restore()
                    }
                    return@runTcpRequestBlocking
                }
                // The handler has run to completion, which is what this limit bounds — its refusal
                // says the request "was not started". Freeing the slot here, before the frame is
                // even handed to the writer thread and therefore before any byte of the response can
                // reach the caller, is what makes the refusal honest: a caller holding a response is
                // guaranteed the slot that served it is already free, so a caller that respects the
                // limit is never turned away by it.
                releaseAdmission()
                val outcome = if (job != null) enqueueResponse(job) else null
                if (outcome is ResponseQueueOutcome.AllowanceExhausted) {
                    reportUndeliverableResponse(request, outcome.refusal)
                }
                // A ConnectionClosed outcome needs no report: the connection closed while the
                // handler was running, so there is no longer a caller to answer.
            }
        }

        /** The write job for a failure [error] to [request], or null when even that cannot be encoded. */
        private fun buildFailureResponseWriteJob(
            request: Libp2pRpcProtocol.RpcRequest,
            error: Libp2pRpcProtocol.RpcError,
        ): ResponseWriteJob? =
            try {
                buildResponseWriteJob(Libp2pRpcProtocol.RpcResponse(id = request.id, result = null, error = error))
            } catch (encodeFailure: Exception) {
                debugLog {
                    "[TcpServer] Could not encode the failure response for request " +
                        "${request.id}: ${encodeFailure.message}"
                }
                null
            }

        /**
         * Turns a completed response into the frame its connection's writer thread will emit,
         * without writing anything. Encoding on this thread keeps that cost off the single writer.
         */
        private fun buildResponseWriteJob(
            response: Libp2pRpcProtocol.RpcResponse,
            resources: RpcEncodingResources = RpcEncodingResources(),
        ): ResponseWriteJob {
            // A Java or erased handler can return null. Preserve its original first dereference
            // inside the retained-job lambda, including the existing full transport error text.
            val forwarded = (response?.result as? ForwardedStreamingBytecodeResponse)
                ?.takeIf { response.error == null }
            var writerClaimed = false
            try {
                if (forwarded != null) {
                    // Caller metadata can close or register completion on this response. Claim
                    // before entering accounting so that those actions wait for release outside it.
                    forwarded.claimWriter()
                    writerClaimed = true
                }
                return resources.guard(listOf(response?.result, response?.error?.data)) {
                    tcpResponseOutboxAccounting.createRetainedJob(outboxAccounting) {
                        val streaming = response.result as? StreamingBytecodeResponse
                        val responseAttachments = mutableListOf<ByteArray>()
                        if (forwarded != null) {
                            forwardedStreamingResponseWriteJob(
                                forwarded.toResponseJson(response.id, response.metadata),
                                forwarded,
                            )
                        } else if (streaming != null && response.error == null) {
                            // TCP emits the existing JAR array as an attachment, without a JSON body copy.
                            val responseJson = streaming.toBinaryRpcResponse().toJson(responseAttachments)
                            streamingResponseWriteJob(responseJson, responseAttachments)
                        } else {
                            val responseJson = response.toJson(responseAttachments, resources)
                            encodedResponseWriteJob(responseJson, responseAttachments)
                        }
                    }
                }
            } catch (failure: Throwable) {
                // Completion can call back into server accounting. Release outside its lock.
                try {
                    if (writerClaimed) forwarded?.releaseWriter() else forwarded?.close()
                } catch (closeFailure: Throwable) {
                    throw combineForwardedCompletionFailures(failure, closeFailure)
                }
                throw failure
            }
        }

        /**
         * Answers a request whose computed response could not be queued. This is deliberately not
         * the concurrent-handler-limit refusal: the handler did run, and saying it "was not started"
         * would be false. The reply is charged to a separate small allowance so a connection whose
         * response allowance is exhausted can still say so.
         */
        private fun reportUndeliverableResponse(
            request: Libp2pRpcProtocol.RpcRequest,
            refusal: TcpServerResponseOutboxRefusal,
        ) {
            undeliverableResponses.incrementAndGet()
            val message = tcpServerResponseOutboxFullMessage(port, request.id, request.method, refusal)
            val errorResponse = Libp2pRpcProtocol.RpcResponse.error(
                request.id,
                Libp2pRpcProtocol.ERROR_RESPONSE_OUTBOX_FULL,
                message,
            )
            val replyRefused = try {
                enqueueResponse(
                    tcpResponseOutboxAccounting.createRetainedJob(outboxAccounting) {
                        encodedResponseWriteJob(
                            errorResponse.toJson(mutableListOf()),
                            emptyList(),
                            failureLane = true,
                        )
                    }
                ) is ResponseQueueOutcome.AllowanceExhausted
            } catch (encodeFailure: Exception) {
                debugLog {
                    "[TcpServer] Could not encode the undeliverable-response reply for request " +
                        "${request.id}: ${encodeFailure.message}"
                }
                true
            }
            if (replyRefused) {
                publishCloseState(
                    IOException(
                        "TCP connection $connectionId closed because neither the response for " +
                            "request ${request.id} nor its response-outbox refusal could be queued."
                    )
                )
                // Both allowances are exhausted, so this caller cannot be told anything on this
                // connection. Closing it fails every outstanding request loudly instead of leaving
                // callers waiting on responses that will never be written.
                debugLog {
                    "[TcpServer] Closing ${socket.remoteSocketAddress}: neither the response for " +
                        "request ${request.id} nor the reply explaining why could be queued"
                }
                try {
                    socket.close()
                } catch (_: Exception) {
                    // Already closed; the reader's finally block still runs.
                }
            }
            val effect = TcpServerResponseOutboxFullEffect(port, request.id, request.method, refusal)
            try {
                toss(effect)
            } catch (unhandled: UnhandledNotificationEffect) {
                if (unhandled.effect !== effect) throw unhandled
                // The caller already received the explicit RESPONSE_OUTBOX_FULL error. Consumers
                // that need metrics or logging can install a handler for this dedicated effect.
            }
        }

        /**
         * Answers a request that admission accepted but that could not be handed to a worker. The
         * caller is told what actually failed rather than being given a capacity refusal for
         * capacity that was available.
         */
        private fun reportRequestDispatchFailure(
            request: Libp2pRpcProtocol.RpcRequest,
            failure: Throwable,
            output: java.io.OutputStream,
        ) {
            val response = Libp2pRpcProtocol.RpcResponse.error(
                request.id,
                Libp2pRpcProtocol.ERROR_INTERNAL,
                "TcpServer on port $port admitted request ${request.id} for method " +
                    "'${request.method}' but could not hand it to a request-handler thread: " +
                    "${failure.javaClass.name}${failure.message?.let { ": $it" } ?: ""}",
            )
            try {
                synchronized(output) {
                    Libp2pRpcProtocol.writeMessage(output, response.toJson())
                }
            } catch (writeFailure: Exception) {
                debugLog {
                    "[TcpServer] Could not report the dispatch failure for request " +
                        "${request.id}: ${writeFailure.message}"
                }
            }
        }

        private fun refuseForConcurrentHandlerLimit(
            request: Libp2pRpcProtocol.RpcRequest,
            output: java.io.OutputStream,
        ) {
            val message = tcpServerConcurrentHandlerLimitMessage(
                port,
                concurrentHandlerLimit,
                request.id,
                request.method,
            )
            val response = Libp2pRpcProtocol.RpcResponse.error(
                request.id,
                Libp2pRpcProtocol.ERROR_CONCURRENT_HANDLER_LIMIT,
                message,
            )
            try {
                synchronized(output) {
                    Libp2pRpcProtocol.writeMessage(output, response.toJson())
                }
            } finally {
                val effect = TcpServerConcurrentHandlerLimitEffect(
                    port,
                    concurrentHandlerLimit,
                    request.id,
                    request.method,
                )
                try {
                    toss(effect)
                } catch (unhandled: UnhandledNotificationEffect) {
                    if (unhandled.effect !== effect) throw unhandled
                    // The caller already received the explicit limit error. Consumers that
                    // need metrics or logging can install a handler for this dedicated effect.
                }
            }
        }
    }

    companion object {
        /**
         * Allows substantially more than the existing 65-concurrent-blocking-handler contract
         * while bounding the measured platform-thread cost (about 0.1 MB resident per blocked
         * handler in the phase-1 measurements).
         */
        const val DEFAULT_CONCURRENT_HANDLER_LIMIT = 256

        private const val REQUEST_THREAD_KEEP_ALIVE_SECONDS = 60L

        /**
         * How long a connection's writer thread, or a reader paused on the outbox high-water mark,
         * waits for the outbox to change before re-checking whether the connection is still active.
         * It bounds shutdown latency only; every state change also notifies the monitor.
         */
        private const val OUTBOX_WAIT_MILLIS = 100L

        /**
         * Monotonic suffix that disambiguates [ServiceClientConnection.connectionId] across two TCP
         * connections from the same client address (or after a reconnection), so a captured push
         * sender never aliases a later connection.
         */
        private val tcpConnectionIdCounter = java.util.concurrent.atomic.AtomicLong(0)

        private fun nextTcpConnectionId(): Long = tcpConnectionIdCounter.incrementAndGet()

        /**
         * Shared daemon scheduler that bounds a blocking [ServiceClientConnection.push] write on the
         * TCP transport: a `java.net.Socket` OutputStream has no send timeout, so a client that stops
         * reading could park the write forever. The watchdog closes the wedged socket after the same
         * delivery window the libp2p path uses ([WRITE_BACKPRESSURE_DELIVERY_WAIT_MS]), unblocking the
         * write so `push` fails loudly instead of hanging. Threads are daemon and time out when idle.
         */
        private val pushWriteWatchdog: java.util.concurrent.ScheduledThreadPoolExecutor =
            java.util.concurrent.ScheduledThreadPoolExecutor(1) { r ->
                Thread(r, "tcp-push-write-watchdog").apply { isDaemon = true }
            }.apply {
                setKeepAliveTime(60L, java.util.concurrent.TimeUnit.SECONDS)
                allowCoreThreadTimeOut(true)
                removeOnCancelPolicy = true
            }

        /**
         * Creates a TcpServer that delegates to an RpcRequestHandler.
         */
        fun withHandler(port: Int, handler: RpcRequestHandler): TcpServer {
            return TcpServer(port) { request, effectPropagator ->
                handler.handleRequest(request, effectPropagator)
            }.apply {
                encodingFailureHandler = handler as? RpcResponseEncodingFailureHandler
            }
        }
    }
}
