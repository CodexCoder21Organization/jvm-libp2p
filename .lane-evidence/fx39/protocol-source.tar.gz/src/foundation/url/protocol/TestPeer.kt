package foundation.url.protocol

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * A test implementation of BootstrapPeer that simulates network behavior.
 *
 * This class is designed for testing scenarios like:
 * - Peers going online/offline
 * - Network latency and timeouts
 * - Peer discovery chains
 * - Service advertisement changes
 *
 * Use the companion object methods to create and manage test networks.
 */
class TestPeer(
    override val peerId: String,
    multiaddresses: List<String>,
    initialServices: List<String> = emptyList(),
    initialLastSeen: Long = System.currentTimeMillis()
) : BootstrapPeer {

    private val addressOwnership = PeerAddressOwnership(multiaddresses)

    override val multiaddresses: List<String>
        get() = addressOwnership.addresses

    internal fun retainRegistryAddresses(addresses: List<String>) {
        addressOwnership.retain(peerId, addresses)
    }

    private val _advertisedServices = CopyOnWriteArrayList(initialServices)
    private val _lastSeenTimestamp = AtomicLong(initialLastSeen)
    private val _isOnline = AtomicBoolean(true)
    private val _knownPeers = CopyOnWriteArrayList<BootstrapPeer>()
    private val _pingLatencyMs = AtomicLong(10) // Simulated latency
    private val _shouldFailNextPing = AtomicBoolean(false)
    private val _pingCount = AtomicLong(0)
    private val _discoverCount = AtomicLong(0)

    override val advertisedServices: List<String>
        get() = _advertisedServices.toList()

    override val lastSeenTimestamp: Long
        get() = _lastSeenTimestamp.get()

    /**
     * Whether this peer is currently "online" (reachable).
     */
    var isOnline: Boolean
        get() = _isOnline.get()
        set(value) { _isOnline.set(value) }

    /**
     * Simulated ping latency in milliseconds.
     */
    var pingLatencyMs: Long
        get() = _pingLatencyMs.get()
        set(value) { _pingLatencyMs.set(value) }

    /**
     * Number of times ping() has been called on this peer.
     */
    val pingCount: Long
        get() = _pingCount.get()

    /**
     * Number of times discoverPeers() has been called on this peer.
     */
    val discoverCount: Long
        get() = _discoverCount.get()

    /**
     * Makes the next ping() call fail, even if online.
     */
    fun failNextPing() {
        _shouldFailNextPing.set(true)
    }

    /**
     * Adds a service to this peer's advertised services.
     */
    fun addService(service: String) {
        if (!_advertisedServices.contains(service)) {
            _advertisedServices.add(service)
        }
    }

    /**
     * Removes a service from this peer's advertised services.
     */
    fun removeService(service: String) {
        _advertisedServices.remove(service)
    }

    /**
     * Adds a peer to this peer's known peers list (for discovery).
     */
    fun addKnownPeer(peer: BootstrapPeer) {
        if (_knownPeers.none { it.peerId == peer.peerId }) {
            _knownPeers.add(peer)
        }
    }

    /**
     * Removes a peer from this peer's known peers list.
     */
    fun removeKnownPeer(peerId: String) {
        _knownPeers.removeIf { it.peerId == peerId }
    }

    /**
     * Gets the list of known peers.
     */
    fun getKnownPeers(): List<BootstrapPeer> = _knownPeers.toList()

    /**
     * Updates the last seen timestamp to now.
     */
    fun touch() {
        _lastSeenTimestamp.set(System.currentTimeMillis())
    }

    /**
     * Sets the last seen timestamp to a specific value.
     */
    fun setLastSeen(timestamp: Long) {
        _lastSeenTimestamp.set(timestamp)
    }

    override fun discoverPeers(maxPeers: Int): List<BootstrapPeer> {
        _discoverCount.incrementAndGet()

        if (!_isOnline.get()) {
            return emptyList()
        }

        // Simulate network latency
        if (pingLatencyMs > 0) {
            Thread.sleep(pingLatencyMs)
        }

        _lastSeenTimestamp.set(System.currentTimeMillis())

        // Return known peers that are online, up to maxPeers
        return _knownPeers
            .filter { (it as? TestPeer)?.isOnline ?: true }
            .take(maxPeers)
    }

    override fun requestIntroduction(targetPeerId: String): RendezvousInfo? {
        if (!_isOnline.get()) {
            return null
        }

        // Simulate network latency
        if (pingLatencyMs > 0) {
            Thread.sleep(pingLatencyMs)
        }

        _lastSeenTimestamp.set(System.currentTimeMillis())

        // Check if we know the target peer
        val targetPeer = _knownPeers.find { it.peerId == targetPeerId }
        if (targetPeer == null) {
            return null
        }

        // Check if target is online
        if ((targetPeer as? TestPeer)?.isOnline == false) {
            return null
        }

        val relayAddr = multiaddresses.firstOrNull() ?: return null

        return RendezvousInfo(
            relayPeerId = peerId,
            relayMultiaddress = relayAddr,
            reservationVoucher = "test-voucher-${System.currentTimeMillis()}",
            expiresAt = System.currentTimeMillis() + 300_000, // 5 minutes
            circuitAddress = "/p2p/$peerId/p2p-circuit/p2p/$targetPeerId"
        )
    }

    override fun canRoute(serviceIdentifier: String): Boolean {
        if (!_isOnline.get()) {
            return false
        }
        if (serviceIdentifier.isBlank()) {
            return false
        }
        // Match is exact only. See PeerRegistry.findPeersForService for the rationale.
        return _advertisedServices.contains(serviceIdentifier)
    }

    override fun ping(timeoutMs: Long): Boolean {
        _pingCount.incrementAndGet()

        // Check if we should fail this ping
        if (_shouldFailNextPing.compareAndSet(true, false)) {
            return false
        }

        if (!_isOnline.get()) {
            return false
        }

        // Simulate network latency
        val latency = pingLatencyMs
        if (latency > timeoutMs) {
            // Timeout
            return false
        }

        if (latency > 0) {
            Thread.sleep(latency)
        }

        _lastSeenTimestamp.set(System.currentTimeMillis())
        return true
    }

    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put("peerId", peerId)
            put("multiaddresses", JSONArray(multiaddresses))
            put("advertisedServices", JSONArray(_advertisedServices))
            put("lastSeenTimestamp", _lastSeenTimestamp.get())
            put("isTestPeer", true)
        }
    }

    companion object {
        /**
         * Creates a simple test peer with default settings.
         */
        fun create(
            id: String,
            services: List<String> = emptyList(),
            online: Boolean = true
        ): TestPeer {
            // Use Math.abs to ensure positive port offset even for negative hashCodes
            val portOffset = Math.abs(id.hashCode() % 10)
            return TestPeer(
                peerId = "QmTest$id",
                multiaddresses = listOf("/ip4/127.0.0.1/tcp/400$portOffset/p2p/QmTest$id"),
                initialServices = services
            ).also { it.isOnline = online }
        }

        /**
         * Creates a network of interconnected test peers.
         *
         * @param count Number of peers to create
         * @param connectivityRatio How connected peers are (0.0 = none, 1.0 = fully connected)
         * @param onlineRatio How many peers are online (0.0 = none, 1.0 = all)
         * @param servicesPerPeer Average services per peer
         */
        fun createNetwork(
            count: Int,
            connectivityRatio: Double = 0.5,
            onlineRatio: Double = 1.0,
            servicesPerPeer: Int = 1
        ): List<TestPeer> {
            val peers = (1..count).map { i ->
                val services = (1..servicesPerPeer).map { s -> "com.test.service$i.$s" }
                create("Peer$i", services, online = Math.random() < onlineRatio)
            }

            // Connect peers based on connectivity ratio
            for (peer in peers) {
                for (other in peers) {
                    if (peer.peerId != other.peerId && Math.random() < connectivityRatio) {
                        peer.addKnownPeer(other)
                    }
                }
            }

            return peers
        }

        /**
         * Creates a chain of peers where each peer knows the next.
         */
        fun createChain(count: Int): List<TestPeer> {
            val peers = (1..count).map { i ->
                create("Chain$i", listOf("com.chain.service$i"))
            }

            for (i in 0 until peers.size - 1) {
                peers[i].addKnownPeer(peers[i + 1])
            }

            return peers
        }

        /**
         * Creates a star topology with one central peer.
         */
        fun createStar(satelliteCount: Int): Pair<TestPeer, List<TestPeer>> {
            val hub = create("Hub", listOf("com.hub.service"))
            val satellites = (1..satelliteCount).map { i ->
                create("Satellite$i", listOf("com.satellite.service$i")).also {
                    it.addKnownPeer(hub)
                    hub.addKnownPeer(it)
                }
            }
            return hub to satellites
        }

        /**
         * Deserializes a TestPeer from JSON.
         */
        fun fromJson(json: JSONObject): TestPeer {
            val multiaddrs = mutableListOf<String>()
            val addrsArray = json.getJSONArray("multiaddresses")
            for (i in 0 until addrsArray.length()) {
                multiaddrs.add(addrsArray.getString(i))
            }

            val services = mutableListOf<String>()
            if (json.has("advertisedServices")) {
                val servicesArray = json.getJSONArray("advertisedServices")
                for (i in 0 until servicesArray.length()) {
                    services.add(servicesArray.getString(i))
                }
            }

            return TestPeer(
                peerId = json.getString("peerId"),
                multiaddresses = multiaddrs,
                initialServices = services,
                initialLastSeen = json.optLong("lastSeenTimestamp", System.currentTimeMillis())
            )
        }
    }
}
