package foundation.url.protocol

import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.SystemClock
import community.kotlin.logging.MessageSeverity
import kotlinx.algebraiceffects.`$effectHandlerRepository`
import kotlinx.algebraiceffects.EffectHandlerRepository
import kotlinx.algebraiceffects.NotificationEffect
import kotlinx.algebraiceffects.UnhandledNotificationEffect
import kotlinx.algebraiceffects.toss
import okio.FileSystem
import okio.Path
import okio.Path.Companion.toPath
import java.util.IdentityHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.regex.Pattern
import kotlin.reflect.KClass
import foundation.url.protocol.sandbox.BytecodeFetchResult
import foundation.url.protocol.sandbox.BytecodeResponse
import foundation.url.protocol.sandbox.BytecodeProtocol

data class ServiceQueryDiagnostics(
    val cachedResults: Int = 0,
    val attemptedPeers: Int = 0,
    val successfulPeers: Int = 0,
    val failedPeers: Int = 0,
    val timedOut: Boolean = false,
    val returnedResults: Int = 0,
    val warnings: List<String> = emptyList()
)

private data class ServiceQueryPeerResult(
    val peer: BootstrapPeer?,
    val services: List<ServiceInfo>,
    val failure: Exception?,
    val requestStartedElapsedMillis: PeerFreshnessTimeSample? = null,
    val responseReceivedElapsedMillis: PeerFreshnessTimeSample? = null
)

private data class PeerAddressDialResult(
    val address: String,
    val stream: RpcStream?,
    val failure: Throwable?
)

private fun schedulePeerDialDeadline(
    clock: Clock,
    deadlineMs: Long,
    onExpiry: () -> Unit,
): community.kotlin.clocks.simple.Scheduled {
    val scheduled = clock.schedule(deadlineMs, onExpiry)
    try {
        // A clock may advance before the scheduled task has been registered.
        if (clock.currentTimeMillis() >= deadlineMs) onExpiry()
    } catch (failure: Throwable) {
        try {
            scheduled.cancel()
        } catch (cleanupFailure: Throwable) {
            if (cleanupFailure !== failure) failure.addSuppressed(cleanupFailure)
        }
        throw failure
    }
    return scheduled
}

private fun closeUnconsumedPeerDialStream(
    stream: RpcStream,
    peerId: String,
    methodPath: String,
    ownerRepository: EffectHandlerRepository?,
) {
    try {
        stream.close()
    } catch (failure: Throwable) {
        val effect = NotificationEffect(
            "Closing an unconsumed RPC stream to peer '$peerId' for method path " +
                "'$methodPath' failed: ${failure.javaClass.name}: ${failure.message}",
            MessageSeverity.WARNING,
            failure,
        )
        try {
            if (ownerRepository == null) {
                toss(effect)
            } else synchronized(ownerRepository) {
                val workerRepository = `$effectHandlerRepository`.get()
                `$effectHandlerRepository`.set(ownerRepository)
                try { toss(effect) }
                finally { `$effectHandlerRepository`.set(workerRepository) }
            }
        } catch (unhandled: UnhandledNotificationEffect) {
            // The runtime already prints an unhandled notification. No caller remains to
            // receive it; cleanup must preserve the outcome that caller already selected.
            if (unhandled.effect !== effect) throw unhandled
        } catch (reportingFailure: Throwable) {
            if (reportingFailure !== failure) failure.addSuppressed(reportingFailure)
            // A callable's Future may already be cancelled. Report explicitly so its stored
            // exception cannot be the only record of a failed cleanup or warning callback.
            Thread.currentThread().let { it.uncaughtExceptionHandler.uncaughtException(it, failure) }
        }
        if (failure is Error) {
            Thread.currentThread().let { it.uncaughtExceptionHandler.uncaughtException(it, failure) }
            throw failure
        }
    }
}

class ServiceQueryWarningEffect(
    message: String,
    cause: Throwable? = null
) : NotificationEffect(message, MessageSeverity.WARNING, cause)

/**
 * Closing an RPC stream that [UrlProtocol.sendServiceRpcRequest] replaced after a transport failure
 * failed. The stream is closed once the calls in flight on it have finished.
 */
class EvictedRpcStreamCloseWarningEffect(
    val serviceIdentifier: String,
    /** The exception the stream's close threw. */
    val failure: Throwable,
) : NotificationEffect(
    "Closing the RPC stream for service '$serviceIdentifier' that was replaced after a transport " +
        "failure failed: ${failure.javaClass.name}: ${failure.message}",
    MessageSeverity.WARNING,
    failure,
)

private fun tossServiceQueryWarning(message: String, cause: Throwable? = null) {
    val effect = ServiceQueryWarningEffect(message, cause)
    try {
        toss(effect)
    } catch (unhandled: UnhandledNotificationEffect) {
        if (unhandled.effect !== effect) throw unhandled
    }
}

/**
 * Low-level protocol for opening raw RPC streams to url:// services.
 *
 * This class handles:
 * - URL parsing and validation
 * - Peer discovery and routing
 * - P2P connection establishment via libp2p
 * - Stream multiplexing
 *
 * Unlike [UrlResolver], this class
 * does not perform type materialization. It returns raw [RpcStream] instances
 * that allow direct RPC communication using [Libp2pRpcProtocol] messages.
 *
 * ## Basic Usage
 * ```kotlin
 * val protocol = UrlProtocol(bootstrapPeers)
 * val stream = protocol.openStream("url://my.service/")
 *
 * // Send raw RPC request
 * val request = Libp2pRpcProtocol.RpcRequest(
 *     id = Libp2pRpcProtocol.nextRequestId(),
 *     method = "myMethod",
 *     params = mapOf("arg" to "value")
 * )
 * val response = stream.sendRequest(request)
 *
 * stream.close()
 * protocol.close()
 * ```
 *
 * ## With Peer Persistence
 * ```kotlin
 * val protocol = UrlProtocol(peersDirectory = "/path/to/peers".toPath())
 * // Peers will be loaded from and saved to this directory
 * ```
 *
 * @see RpcStream
 * @see Libp2pRpcProtocol
 */
class UrlProtocol : AutoCloseable, GossipHandler {

    private val _peerRegistry: PeerRegistry
    private val network: NetworkProvider
    private val activeStreams = ConcurrentHashMap<String, RpcStream>()
    // sendServiceRpcRequest's calls in flight per cached stream, and the streams it has retired
    // that still have calls in flight; both identity-keyed and guarded by serviceStreamLock. The
    // retired set is bounded by the calls in flight: a retired stream leaves it when its last
    // call is released, and protocol close closes every owned stream, retired ones included.
    private val serviceStreamLock = Any()
    private val serviceStreamCallsInFlight = java.util.IdentityHashMap<RpcStream, Int>()
    private val retiredServiceStreams: MutableSet<RpcStream> =
        java.util.Collections.newSetFromMap(java.util.IdentityHashMap())
    private val ownedStreams = IdentityHashMap<OwnedProtocolRpcStream, Boolean>()
    private val protocolClosed = AtomicBoolean(false)
    private val serviceLifecycle = java.lang.Object()
    private val activeServiceSends = IdentityHashMap<Thread, Int>()
    private val ownedResourceCleanups = IdentityHashMap<Thread, Int>()
    private val retiringRelayServices = IdentityHashMap<RelayService, Boolean>()
    private val closeFinished = CountDownLatch(1)
    private var closeOwner: Thread? = null
    private val closeResult = ProtocolCleanupResult()
    private val networkStartToken = Any()
    private val lanStartToken = Any()
    private val relayStartToken = Any()
    private val startupOwners = IdentityHashMap<Any, Thread>()
    @Volatile
    private var networkListenInfo: NetworkListenInfo? = null
    private var gossipInboundRegistration: AutoCloseable? = null
    private var gossipMessageTracker: GossipMessageTracker? = null
    private val gossipMessageSequence = AtomicLong(0L)
    private val activeServiceQueryExpiries = ConcurrentHashMap<String, Long>()
    @Volatile
    private var lastServiceQueryDiagnostics = ServiceQueryDiagnostics()

    // Peer-to-peer relay support
    @Volatile private var relayService: RelayService? = null
    @Volatile private var relayDiscovery: RelayDiscovery? = null
    private val relayConfig: RelayConfig
    private val lanDiscoveryConfig: LanDiscoveryConfig
    private val clock: Clock
    private var lanPeerDiscovery: LanPeerDiscovery? = null
    private val nameResolutionConfig: NameResolutionConfig
    private val relayStarted = AtomicBoolean(false)

    /**
     * The peer registry for managing known peers.
     */
    val peerRegistry: PeerRegistry
        get() = _peerRegistry

    /**
     * Creates a UrlProtocol with no bootstrap peers.
     * Services can only be resolved if peers are added later.
     *
     * @param relayConfig Configuration for the peer-to-peer relay functionality.
     */
    constructor(
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry.inMemory(clock)
        this.network = defaultNetworkProvider(relayConfig)
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
    }

    /** Creates a UrlProtocol over an explicitly supplied network implementation. */
    constructor(
        network: NetworkProvider,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry.inMemory(clock)
        this.network = network
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
    }

    constructor(
        nameResolutionConfig: NameResolutionConfig
    ) : this(RelayConfig(), LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    constructor(
        relayConfig: RelayConfig,
        nameResolutionConfig: NameResolutionConfig
    ) : this(relayConfig, LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    /**
     * Creates a UrlProtocol with the given bootstrap peers.
     *
     * @param bootstrapPeers List of peers to use for bootstrapping.
     * @param relayConfig Configuration for the peer-to-peer relay functionality.
     */
    constructor(
        bootstrapPeers: List<BootstrapPeer>,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry.withBootstrapPeers(bootstrapPeers, clock = clock)
        this.network = defaultNetworkProvider(relayConfig)
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
    }

    /** Creates a bootstrapped UrlProtocol over an explicitly supplied network implementation. */
    constructor(
        bootstrapPeers: List<BootstrapPeer>,
        network: NetworkProvider,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry.withBootstrapPeers(bootstrapPeers, clock = clock)
        this.network = network
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
    }

    constructor(
        bootstrapPeers: List<BootstrapPeer>,
        nameResolutionConfig: NameResolutionConfig
    ) : this(bootstrapPeers, RelayConfig(), LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    constructor(
        bootstrapPeers: List<BootstrapPeer>,
        relayConfig: RelayConfig,
        nameResolutionConfig: NameResolutionConfig
    ) : this(bootstrapPeers, relayConfig, LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    /**
     * Creates a UrlProtocol with peer persistence to a directory.
     *
     * @param peersDirectory Path to the directory for storing peer data.
     * @param filesystem The filesystem to use (defaults to system filesystem).
     * @param relayConfig Configuration for the peer-to-peer relay functionality.
     */
    constructor(
        peersDirectory: Path,
        filesystem: FileSystem = FileSystem.SYSTEM,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry.withPersistence(peersDirectory, filesystem, clock)
        this.network = defaultNetworkProvider(relayConfig)
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
        this.nameResolutionConfig.resolver.attachTldPersistence(filesystem, peersDirectory)
    }

    /** Creates a persistent UrlProtocol over an explicitly supplied network implementation. */
    constructor(
        peersDirectory: Path,
        network: NetworkProvider,
        filesystem: FileSystem = FileSystem.SYSTEM,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry.withPersistence(peersDirectory, filesystem, clock)
        this.network = network
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
        this.nameResolutionConfig.resolver.attachTldPersistence(filesystem, peersDirectory)
    }

    /**
     * Creates a UrlProtocol with peer persistence (string path).
     *
     * @param peersDirectory Path string to the directory for storing peer data.
     * @param relayConfig Configuration for the peer-to-peer relay functionality.
     */
    constructor(
        peersDirectory: String,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) : this(peersDirectory.toPath(), FileSystem.SYSTEM, relayConfig, lanDiscoveryConfig, clock, nameResolutionConfig)

    constructor(
        peersDirectory: String,
        network: NetworkProvider,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) : this(peersDirectory.toPath(), network, FileSystem.SYSTEM, relayConfig, lanDiscoveryConfig, clock, nameResolutionConfig)

    constructor(
        peersDirectory: String,
        nameResolutionConfig: NameResolutionConfig
    ) : this(peersDirectory.toPath(), FileSystem.SYSTEM, RelayConfig(), LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    constructor(
        peersDirectory: String,
        relayConfig: RelayConfig,
        nameResolutionConfig: NameResolutionConfig
    ) : this(peersDirectory.toPath(), FileSystem.SYSTEM, relayConfig, LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    /**
     * Creates a UrlProtocol with bootstrap peers and persistence.
     *
     * @param bootstrapPeers Initial peers to use for bootstrapping.
     * @param peersDirectory Path to the directory for storing peer data.
     * @param filesystem The filesystem to use (defaults to system filesystem).
     * @param relayConfig Configuration for the peer-to-peer relay functionality.
     */
    constructor(
        bootstrapPeers: List<BootstrapPeer>,
        peersDirectory: Path,
        filesystem: FileSystem = FileSystem.SYSTEM,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry(filesystem, peersDirectory, clock)
        this.network = defaultNetworkProvider(relayConfig)
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
        this.nameResolutionConfig.resolver.attachTldPersistence(filesystem, peersDirectory)
        for (peer in bootstrapPeers) {
            _peerRegistry.addPeer(peer)
        }
    }

    /** Creates a bootstrapped persistent UrlProtocol over an explicitly supplied network implementation. */
    constructor(
        bootstrapPeers: List<BootstrapPeer>,
        peersDirectory: Path,
        network: NetworkProvider,
        filesystem: FileSystem = FileSystem.SYSTEM,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = PeerRegistry(filesystem, peersDirectory, clock)
        this.network = network
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
        this.nameResolutionConfig.resolver.attachTldPersistence(filesystem, peersDirectory)
        for (peer in bootstrapPeers) {
            _peerRegistry.addPeer(peer)
        }
    }

    /**
     * Creates a UrlProtocol with an existing PeerRegistry.
     *
     * This constructor is useful when UrlResolver needs to create a UrlProtocol
     * instance that shares the same PeerRegistry, allowing UrlResolver to delegate
     * low-level operations like pingPeer() to UrlProtocol.
     *
     * @param peerRegistry The existing PeerRegistry to use.
     * @param relayConfig Configuration for the peer-to-peer relay functionality.
     */
    constructor(
        peerRegistry: PeerRegistry,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = peerRegistry
        this.network = defaultNetworkProvider(relayConfig)
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
    }

    /** Creates a UrlProtocol sharing [peerRegistry] over an explicitly supplied network. */
    constructor(
        peerRegistry: PeerRegistry,
        network: NetworkProvider,
        relayConfig: RelayConfig = RelayConfig(),
        lanDiscoveryConfig: LanDiscoveryConfig = LanDiscoveryConfig(),
        clock: Clock = SystemClock(),
        nameResolutionConfig: NameResolutionConfig = NameResolutionConfig()
    ) {
        this._peerRegistry = peerRegistry
        this.network = network
        this.relayConfig = relayConfig
        this.lanDiscoveryConfig = lanDiscoveryConfig
        this.clock = clock
        this.nameResolutionConfig = nameResolutionConfig
    }

    /**
     * Binary bridge for UrlResolver releases compiled before the LAN-discovery and
     * name-resolution constructor parameters were added. Hidden from Kotlin source overload
     * resolution, but retained in bytecode because resolver 0.0.600 invokes this exact JVM
     * descriptor.
     */
    @Deprecated("Binary compatibility bridge for published UrlResolver releases", level = DeprecationLevel.HIDDEN)
    constructor(
        peerRegistry: PeerRegistry,
        relayConfig: RelayConfig
    ) : this(peerRegistry, relayConfig, LanDiscoveryConfig(), SystemClock(), NameResolutionConfig())

    constructor(
        peerRegistry: PeerRegistry,
        nameResolutionConfig: NameResolutionConfig
    ) : this(peerRegistry, RelayConfig(), LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    constructor(
        peerRegistry: PeerRegistry,
        relayConfig: RelayConfig,
        nameResolutionConfig: NameResolutionConfig
    ) : this(peerRegistry, relayConfig, LanDiscoveryConfig(), SystemClock(), nameResolutionConfig)

    /**
     * Opens a raw RPC stream to the service at the given URL.
     *
     * This method:
     * 1. Parses the url:// URL to extract the service identifier
     * 2. Finds a peer that can route to this service
     * 3. Establishes a libp2p connection to the peer
     * 4. Returns an RpcStream for bidirectional communication
     *
     * Special case: If the service identifier matches the pattern `localhost.tcp:PORT`,
     * the connection is made via raw TCP to localhost:PORT, bypassing libp2p entirely.
     * This is useful for local container communication.
     *
     * @param url The url:// protocol URL (e.g., "url://my.service.name/" or "url://localhost.tcp:8080/")
     * @param headers Optional headers to include in the connection.
     * @return An RpcStream for bidirectional RPC communication.
     * @throws UrlProtocolException if the URL is invalid or service cannot be reached.
     */
    fun openStream(url: String, headers: Map<String, String> = emptyMap()): RpcStream =
        openStream(url, RpcResponseReader.AUTOMATIC, headers)

    /** Opens a stream with reply ownership selected before any reader is created. */
    fun openStream(
        url: String,
        responseReader: RpcResponseReader,
        headers: Map<String, String> = emptyMap(),
    ): RpcStream {
        ensureStreamOpen()
        val parsedUrl = parseUrl(url)
        val serviceIdentifier = parsedUrl.serviceIdentifier

        // Check for localhost.tcp:PORT pattern
        val localhostTcpMatch = LOCALHOST_TCP_PATTERN.matcher(serviceIdentifier)
        if (localhostTcpMatch.matches()) {
            val portText = localhostTcpMatch.group(1)
            // Guard the parse the same way the sibling extractLocalhostTcpPort does: a digit
            // run that overflows Int must surface as the documented UrlProtocolException rather
            // than leaking a raw NumberFormatException past this method's @throws contract.
            val port = portText.toIntOrNull()
                ?: throw UrlProtocolException(
                    "Invalid localhost.tcp port in URL '$url': '$portText' is not a valid port " +
                        "number (must be an integer that fits in a 32-bit signed int)."
                )
            return connectViaTcp("localhost", port, serviceIdentifier, responseReader)
        }

        // Find a peer that can route to this service
        val router = findAuthorizedRouterForService(serviceIdentifier, failOnRejected = true)
            ?: throw UrlProtocolException(
                "No peer found for service '$serviceIdentifier'. " +
                    "Known peers: ${_peerRegistry.size}, none advertise this service."
            )

        // Validate peer authorization if service is registered
        val serviceMetadata = ServiceRegistry.getServiceMetadata(serviceIdentifier)
        if (serviceMetadata != null) {
            if (!serviceMetadata.isAuthorizedPeerId(router.peerId)) {
                throw UrlProtocolException(
                    "Peer '${router.peerId}' claims to serve '$serviceIdentifier', " +
                        "but is not authorized. The peer's identity does not match any " +
                        "authorized public keys in the ServiceRegistry."
                )
            }
        }

        return connectToPeer(router, serviceIdentifier, headers, responseReader = responseReader)
    }

    /**
     * Opens an RPC stream to exactly [peerId] at exactly the supplied [addresses].
     *
     * This API never consults service discovery or the peer registry. All usable addresses are
     * raced under one [connectionTimeoutMs] deadline, so a stale address cannot consume a full
     * timeout before a working address is attempted. Calling this method again for a reconnect
     * applies a fresh deadline with the same explicit budget.
     *
     * [serviceIdentifier] and [resourcePath] describe the RPC method path carried by the returned
     * stream. The caller still creates and sends the actual [Libp2pRpcProtocol.RpcRequest].
     */
    fun openStreamToPeer(
        peerId: String,
        addresses: List<String>,
        serviceIdentifier: String,
        resourcePath: String? = null,
        connectionTimeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS
    ): RpcStream = openStreamToPeer(
        peerId, addresses, serviceIdentifier, RpcResponseReader.AUTOMATIC, resourcePath, connectionTimeoutMs
    )

    /** Opens an exact-peer stream with ownership selected before racing its addresses. */
    fun openStreamToPeer(
        peerId: String,
        addresses: List<String>,
        serviceIdentifier: String,
        responseReader: RpcResponseReader,
        resourcePath: String? = null,
        connectionTimeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS,
    ): RpcStream {
        ensureStreamOpen()
        require(peerId.isNotBlank()) {
            "Cannot open an RPC stream to a blank peer ID."
        }
        require(serviceIdentifier.isNotBlank()) {
            "Cannot open an RPC stream to peer '$peerId' with a blank service identifier."
        }
        require(connectionTimeoutMs > 0L) {
            "connectionTimeoutMs must be greater than zero, but was $connectionTimeoutMs."
        }
        val usableAddresses = addresses.filter { it.isNotBlank() }.distinct()
        require(usableAddresses.isNotEmpty()) {
            "Cannot open an RPC stream to peer '$peerId': the supplied addresses $addresses " +
                "contain no usable provider address."
        }
        require(usableAddresses.size <= PeerRegistry.MAX_MULTIADDRESSES_PER_PEER) {
            "Cannot open an RPC stream to peer '$peerId' with ${usableAddresses.size} distinct " +
                "addresses: at most ${PeerRegistry.MAX_MULTIADDRESSES_PER_PEER} addresses are allowed."
        }
        val normalizedResourcePath = resourcePath?.trim('/')?.takeIf { it.isNotEmpty() }
        val methodPath = if (normalizedResourcePath == null) {
            serviceIdentifier
        } else {
            "$serviceIdentifier/$normalizedResourcePath"
        }

        ensureNetworkListening()
        return adoptStream(dialPeerAddressesWithinDeadline(
            peerId = peerId,
            addresses = usableAddresses,
            methodPath = methodPath,
            connectionTimeoutMs = connectionTimeoutMs,
            responseReader = responseReader,
        ))
    }

    /** Convenience overload retaining the exact identity and addresses in [peer]. */
    fun openStreamToPeer(
        peer: BootstrapPeer,
        serviceIdentifier: String,
        resourcePath: String? = null,
        connectionTimeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS
    ): RpcStream = openStreamToPeer(
        peerId = peer.peerId,
        addresses = peer.multiaddresses,
        serviceIdentifier = serviceIdentifier,
        resourcePath = resourcePath,
        connectionTimeoutMs = connectionTimeoutMs
    )

    fun openStreamToPeer(
        peer: BootstrapPeer,
        serviceIdentifier: String,
        responseReader: RpcResponseReader,
        resourcePath: String? = null,
        connectionTimeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS,
    ): RpcStream = openStreamToPeer(
        peer.peerId, peer.multiaddresses, serviceIdentifier, responseReader, resourcePath, connectionTimeoutMs
    )

    /**
     * Connects to a service via raw TCP.
     *
     * @param host The host to connect to.
     * @param port The port to connect to.
     * @param serviceIdentifier The service identifier for this connection.
     * @return A TcpRpcStream connected to the server.
     */
    private fun connectViaTcp(
        host: String, port: Int, serviceIdentifier: String,
        responseReader: RpcResponseReader = RpcResponseReader.AUTOMATIC,
    ): RpcStream {
        try {
            val stream = TcpRpcStream.connect(host, port, serviceIdentifier, responseReader)
            return adoptStream(stream)
        } catch (e: Exception) {
            throw UrlProtocolException(
                "Failed to connect to $host:$port via TCP: ${e.message}",
                e
            )
        }
    }

    /**
     * Finds the peer that can route to a given service.
     *
     * @param serviceIdentifier The url:// service identifier to look for.
     * @return The peer that can route to this service, or null if none found.
     */
    fun findRouterForService(serviceIdentifier: String): BootstrapPeer? {
        return findAuthorizedRouterForService(serviceIdentifier, failOnRejected = false)
    }

    /**
     * Finds all peers that advertise a given service.
     *
     * @param serviceIdentifier The url:// service identifier to look for.
     * @return List of peers that advertise this service.
     */
    fun findPeersForService(serviceIdentifier: String): List<BootstrapPeer> {
        val decision = nameResolutionConfig.resolver.resolve(serviceIdentifier)
        return _peerRegistry.findPeersForService(serviceIdentifier)
            .filter { decision.accepts(it.peerId) }
    }

    private fun findAuthorizedRouterForService(
        serviceIdentifier: String,
        failOnRejected: Boolean
    ): BootstrapPeer? {
        val decision = nameResolutionConfig.resolver.resolve(serviceIdentifier)
        val candidates = _peerRegistry.findPeersForService(serviceIdentifier)
        var firstRejected: BootstrapPeer? = null

        for (peer in candidates) {
            if (!decision.accepts(peer.peerId)) {
                if (firstRejected == null) {
                    firstRejected = peer
                }
                continue
            }
            if (peer.ping(2000)) {
                return peer
            }
        }

        if (failOnRejected && firstRejected != null && decision.mode == NameDelegationMode.VERIFIED) {
            val rejected = firstRejected!!
            throw UrlProtocolException(
                "Peer '${rejected.peerId}' claims to serve '$serviceIdentifier', " +
                    "but hierarchical name resolution rejected it: verified name '$serviceIdentifier' " +
                    "is delegated to peer IDs [${decision.authorizedPeerIds.joinToString(", ")}], " +
                    "and the announcing peer was '${rejected.peerId}'. A ServiceAnnouncement is only " +
                    "a reachability hint, not proof of ownership."
            )
        }

        val fallback = _peerRegistry.findRouterForService(serviceIdentifier) ?: return null
        if (!decision.accepts(fallback.peerId)) {
            if (failOnRejected && decision.mode == NameDelegationMode.VERIFIED) {
                throw UrlProtocolException(
                    "Peer '${fallback.peerId}' claims to serve '$serviceIdentifier', " +
                        "but hierarchical name resolution rejected it: verified name '$serviceIdentifier' " +
                        "is delegated to peer IDs [${decision.authorizedPeerIds.joinToString(", ")}], " +
                        "and the announcing peer was '${fallback.peerId}'. A ServiceAnnouncement is only " +
                        "a reachability hint, not proof of ownership."
                )
            }
            return null
        }
        return fallback
    }

    fun addNameDelegationDescriptor(descriptor: SignedNameDelegationDescriptor): Boolean {
        return nameResolutionConfig.resolver.addDelegationDescriptor(descriptor)
    }

    fun hasTldResolver(tld: String): Boolean {
        return nameResolutionConfig.resolver.getTldDescriptors().any { it.tld == tld }
    }

    /**
     * Adds a bootstrap peer to the protocol.
     */
    fun addBootstrapPeer(peer: BootstrapPeer) {
        _peerRegistry.addPeer(peer)
    }

    /**
     * Adds multiple bootstrap peers to the protocol.
     */
    fun addBootstrapPeers(peers: List<BootstrapPeer>) {
        _peerRegistry.addPeers(peers)
    }

    /**
     * Starts this node's provider and installs the transport-neutral gossip stream handler.
     *
     * Tests using [InMemoryNetworkProvider] call this on every node before wiring the returned
     * address into peer registries. Repeated calls are idempotent and return the same identity and
     * address set.
     */
    fun startNetwork(port: Int = 0): NetworkListenInfo = withStartupTurn(networkStartToken) {
        networkListenInfo?.let { existing ->
            if (port != 0) {
                val requested = network.listen(port)
                ensureStreamOpen()
                check(requested == existing) {
                    "Network provider returned different listen information for an idempotent start: " +
                        "existing=$existing, requestedPort=$port, returned=$requested."
                }
            }
            return@withStartupTurn existing
        }
        if (gossipInboundRegistration == null) {
            val tracker = GossipMessageTracker(clock = clock)
            synchronized(serviceLifecycle) {
                ensureStreamOpen()
                gossipMessageTracker = tracker
            }
            val registration = network.registerInboundStreamHandler(GossipProtocol.PROTOCOL_ID) { stream ->
                handleInboundGossipStream(stream)
            }
            val retained = synchronized(serviceLifecycle) {
                if (protocolClosed.get()) false else {
                    gossipInboundRegistration = registration
                    true
                }
            }
            if (!retained) {
                registration.close()
                ensureStreamOpen()
            }
        }
        ensureStreamOpen()
        val info = network.listen(port)
        synchronized(serviceLifecycle) {
            ensureStreamOpen()
            networkListenInfo = info
        }
        info
    }

    private fun <T> withStartupTurn(token: Any, action: () -> T): T {
        val caller = Thread.currentThread()
        synchronized(serviceLifecycle) {
            while (startupOwners.containsKey(token)) {
                ensureStreamOpen()
                if (startupOwners[token] === caller) {
                    throw UrlProtocolException("Cannot start the network recursively from its startup callback.")
                }
                try {
                    serviceLifecycle.wait()
                } catch (interrupted: InterruptedException) {
                    caller.interrupt()
                    throw UrlProtocolException("Interrupted while waiting for network startup.", interrupted)
                }
            }
            ensureStreamOpen()
            startupOwners[token] = caller
        }
        try {
            return action()
        } finally {
            synchronized(serviceLifecycle) {
                startupOwners.remove(token)
                serviceLifecycle.notifyAll()
            }
        }
    }

    /**
     * Announces a service through the real gossip handler and transport path used by this node.
     * The message ID and timestamp are derived exclusively from the injected [Clock].
     */
    fun announceService(
        serviceIdentifier: String,
        metadata: Map<String, String> = emptyMap(),
        ttl: Int = GossipProtocol.DEFAULT_TTL
    ): Int {
        require(serviceIdentifier.isNotBlank()) {
            "Cannot announce a service with a blank service identifier."
        }
        require(ttl >= 0) {
            "Cannot announce service '$serviceIdentifier' with ttl=$ttl: ttl must be non-negative."
        }
        val info = startNetwork()
        val sequence = gossipMessageSequence.incrementAndGet()
        val announcement = GossipProtocol.ServiceAnnouncement(
            messageId = "${info.peerId}-gossip-${clock.currentTimeMillis()}-$sequence",
            serviceUrl = "url://$serviceIdentifier/",
            serviceIdentifier = serviceIdentifier,
            providerPeerId = info.peerId,
            providerMultiaddresses = info.listenAddresses,
            metadata = metadata,
            timestamp = clock.currentTimeMillis(),
            ttl = ttl
        )
        gossipMessageTracker?.recordMessage(announcement.messageId)
        onServiceAnnouncement(announcement)
        return broadcastGossipMessage(announcement.toJson())
    }

    /**
     * Gets all known peers.
     */
    fun getKnownPeers(): List<BootstrapPeer> = _peerRegistry.getAllPeers()

    /**
     * Gets the number of known peers.
     */
    val peerCount: Int
        get() = _peerRegistry.size

    /**
     * Discovers new peers from existing bootstrap peers.
     *
     * @param maxPeersPerBootstrap Maximum peers to request from each bootstrap peer.
     * @return Number of new peers discovered.
     */
    @Deprecated(
        message = "Peer discovery is automatic. Use openStream() which handles discovery internally.",
        level = DeprecationLevel.WARNING
    )
    fun discoverPeers(maxPeersPerBootstrap: Int = 10): Int {
        return _peerRegistry.discoverNewPeers(maxPeersPerBootstrap)
    }

    /**
     * Saves all known peers to disk.
     * Only works if the protocol was created with a peers directory.
     */
    fun savePeers() {
        _peerRegistry.saveAll()
        nameResolutionConfig.resolver.saveTldDescriptors()
    }

    /**
     * Prunes offline peers from the registry.
     *
     * @param maxAge Maximum age in milliseconds for peers to be considered stale.
     * @param pingTimeout Timeout for ping checks in milliseconds.
     * @return Number of peers removed.
     */
    fun pruneOfflinePeers(
        maxAge: Long = 24 * 60 * 60 * 1000,
        pingTimeout: Long = 5000
    ): Int {
        return _peerRegistry.pruneOfflinePeers(maxAge, pingTimeout)
    }

    /**
     * Binds to a service URL and starts listening for incoming connections.
     *
     * For `localhost.tcp:PORT` domains, this creates a TCP server listening on the specified port.
     * For regular service identifiers, this registers with the libp2p network.
     *
     * This method is typically used by containers/services to start accepting connections.
     *
     * @param url The url:// service URL to bind to (e.g., "url://localhost.tcp:8080/")
     * @param requestHandler Handler for incoming RPC requests.
     * @return A ServiceBinding that can be used to stop the service.
     */
    fun bind(
        url: String,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse
    ): ServiceBinding {
        val parsedUrl = parseUrl(url)
        val serviceIdentifier = parsedUrl.serviceIdentifier

        // Check for localhost.tcp:PORT pattern
        val port = extractLocalhostTcpPort(serviceIdentifier)
        if (port != null) {
            val server = TcpServer(port, requestHandler)
            server.start()
            return TcpServiceBinding(server, serviceIdentifier)
        }

        // For libp2p binding, we would need to register with the network
        // This is a more complex operation that depends on the libp2p host
        throw UrlProtocolException(
            "Libp2p service binding is not yet implemented. " +
                "Use 'url://localhost.tcp:PORT/' for local TCP binding."
        )
    }

    /**
     * Binds a service that holds its OWN SJVM implementation bytecode locally, so the
     * framework serves `__bytecode_request` for it via the heap-efficient streaming path
     * ([StreamingBytecodeResponse]) instead of the bound [requestHandler] hand-rolling it.
     *
     * This is the `localhost.tcp` / url-bind analogue of the optimized
     * `supportsSandboxedExecution()` branch in [ServiceRoutingHandler.handleBytecodeRequest]:
     * a resolver-registered service gets framework streaming for free, but a service bound
     * here (e.g. a ContainerNursery-launched provider reached through CN's UrlFacade proxy)
     * previously had to answer `__bytecode_request` from its own dispatch — Base64-encoding
     * its whole multi-megabyte JAR into a Map on every (re)connect. On a `-Xmx128m` service
     * JVM under a reconnect storm that materialization (~5× the JAR in transient heap per
     * serve) OOM-crash-loops the process. See [BytecodeResponseStreamer].
     *
     * With this overload the bound [requestHandler] NEVER sees `__bytecode_request`: the
     * framework answers it directly with a [StreamingBytecodeResponse] carrying
     * [implementationJar] / [implementationClassName], and the bound server's write path
     * ([TcpServer]) streams the framed wire bytes with peak heap ≈ `implementationJar.size`.
     * Stdlib bytes are deliberately never served (sandbox isolation requires the consumer's
     * own bundled `/stdlib.jar` — see [ServiceHandler.getStdlibJar]'s deprecation note).
     *
     * Unlike the `supportsSandboxedExecution()` serve path, this overload does NOT honor
     * conditional (ETag-style) `__bytecode_request`s: it streams the full [implementationJar]
     * for every request regardless of any `cachedDigest`, rather than replying with a small
     * `notModified` frame on a digest match. Heap stays bounded either way (the OOM this fixes
     * is resolved), so the only cost is re-transferring the jar to a client that already holds
     * it; the target ContainerNursery-proxy path strips digests, so it never revalidates anyway.
     *
     * @param url The url:// service URL to bind to (e.g. "url://localhost.tcp:8080/").
     * @param requestHandler Handler for all non-bytecode RPC requests.
     * @param implementationJar The service's SJVM client implementation JAR bytes.
     * @param implementationClassName The fully-qualified implementation class name.
     * @return A ServiceBinding that can be used to stop the service.
     */
    fun bind(
        url: String,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse,
        implementationJar: ByteArray,
        implementationClassName: String
    ): ServiceBinding {
        return bind(
            url,
            wrapWithStreamingBytecodeServe(requestHandler, implementationJar, implementationClassName)
        )
    }

    /**
     * Binds to a service URL, respecting the URL_BIND_DOMAIN environment variable.
     *
     * If URL_BIND_DOMAIN is set, it overrides the domain portion of the URL.
     * This allows containers to bind locally (e.g., localhost.tcp:8080) when running
     * in a container environment, while using the normal domain when running standalone.
     *
     * @param defaultUrl The default url:// service URL.
     * @param requestHandler Handler for incoming RPC requests.
     * @return A ServiceBinding that can be used to stop the service.
     */
    fun bindWithEnvOverride(
        defaultUrl: String,
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse
    ): ServiceBinding {
        val parsedUrl = parseUrl(defaultUrl)
        val bindDomain = getBindDomain(parsedUrl.serviceIdentifier)
        val actualUrl = "url://$bindDomain/"
        return bind(actualUrl, requestHandler)
    }

    /**
     * Wraps [requestHandler] so the framework answers `__bytecode_request` directly with a
     * [StreamingBytecodeResponse] (streamed by the bound server's write path) instead of
     * delegating to the handler, which would Base64-materialize the whole JAR per request.
     * All other methods pass through to [requestHandler] unchanged.
     */
    private fun wrapWithStreamingBytecodeServe(
        requestHandler: suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse,
        implementationJar: ByteArray,
        implementationClassName: String
    ): suspend (Libp2pRpcProtocol.RpcRequest, EffectPropagator) -> Libp2pRpcProtocol.RpcResponse {
        return handler@{ request, effectPropagator ->
            if (request.method == BytecodeProtocol.METHOD_BYTECODE_REQUEST) {
                return@handler Libp2pRpcProtocol.RpcResponse.success(
                    request.id,
                    StreamingBytecodeResponse(
                        requestId = request.id,
                        jarBytes = implementationJar,
                        implClassName = implementationClassName
                    )
                )
            }
            requestHandler(request, effectPropagator)
        }
    }

    private fun connectToPeer(
        peer: BootstrapPeer,
        serviceIdentifier: String,
        headers: Map<String, String>,
        timeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS,
        responseReader: RpcResponseReader = RpcResponseReader.AUTOMATIC,
    ): RpcStream {
        // The default provider historically parsed the peer record before examining its addresses.
        // Preserve that libp2p-format-specific validation order without imposing base58 on opaque
        // identities owned by alternative providers.
        (network as? Libp2pNetworkProvider)?.parsePeerId(peer.peerId)
        ensureNetworkListening()
        val addresses = peer.multiaddresses.filter { it.isNotBlank() }
        if (addresses.isEmpty()) {
            throw UrlProtocolException(
                "Peer '${peer.peerId}' has no multiaddresses to connect to"
            )
        }

        var lastException: Exception? = null
        for (multiaddr in addresses) {
            // These filters are explicitly libp2p-multiaddress-specific. Addresses remain opaque
            // to NetworkProvider implementations; a future non-libp2p routing model must not copy
            // these predicates as though they were transport-neutral semantics.
            // Skip wildcard addresses - they are never valid connection targets
            if (multiaddr.contains("/ip6/::/") || multiaddr.contains("/ip4/0.0.0.0/")) {
                continue
            }
            try {
                val stream = network.dial(
                    peerId = peer.peerId,
                    address = multiaddr,
                    protocolId = Libp2pRpcProtocol.PROTOCOL_ID,
                    timeoutMs = timeoutMs,
                    responseReader = responseReader,
                ).withServiceIdentifier(serviceIdentifier)
                val owned = adoptStream(stream)

                _peerRegistry.getObservationLog().recordSuccess(peer.peerId)
                if (multiaddr.contains("/p2p-circuit/")) {
                    _peerRegistry.recordRelayOnlyReachability(peer.peerId)
                } else {
                    _peerRegistry.recordDirectReachability(peer.peerId)
                }

                return owned
            } catch (e: Exception) {
                if (protocolClosed.get()) throw e
                lastException = e
            }
        }
        throw UrlProtocolException(
            "Failed to connect to peer '${peer.peerId}': all ${addresses.size} multiaddresses failed. Last error: ${lastException?.message}",
            lastException
        )
    }

    private fun dialPeerAddressesWithinDeadline(
        peerId: String,
        addresses: List<String>,
        methodPath: String,
        connectionTimeoutMs: Long,
        responseReader: RpcResponseReader,
    ): RpcStream {
        val deadlineMs = clock.currentTimeMillis() + connectionTimeoutMs
        val ownerRepository = `$effectHandlerRepository`.get()
        val closeUnconsumed: (RpcStream) -> Unit = { stream ->
            closeUnconsumedPeerDialStream(stream, peerId, methodPath, ownerRepository)
        }
        val dialResultUnclaimed = Any()
        val dialResultClosed = Any()
        val dialResultOwnership = java.util.concurrent.atomic.AtomicReference<Any>(dialResultUnclaimed)
        val executor = ThreadPoolExecutor(
            addresses.size, addresses.size, 1L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>()
        ) { runnable ->
            Thread(runnable, "UrlProtocol-peer-dial-${peerId.take(12)}").apply { isDaemon = true }
        }.apply {
            // Idle workers must end even if both shutdown calls fail before changing pool state.
            allowCoreThreadTimeOut(true)
        }
        val outcomeLock = Any()
        val outcomes = java.util.ArrayDeque<PeerAddressDialResult>()
        val outcomeReady = java.util.concurrent.Semaphore(0)
        var expired = false
        var expiry: community.kotlin.clocks.simple.Scheduled? = null
        val cancelDials = mutableListOf<() -> Unit>()
        val failures = LinkedHashMap<String, Throwable>()
        var selectedStream: RpcStream? = null
        var exitFailure: Throwable? = null
        val cleanup: (() -> Unit) -> Unit = { action ->
            try {
                action()
            } catch (failure: Throwable) {
                val first = exitFailure
                if (first == null) exitFailure = failure
                else if (first !== failure) first.addSuppressed(failure)
            }
        }
        val expire: () -> Unit = {
            synchronized(outcomeLock) {
                if (!expired) {
                    expired = true
                    outcomeReady.release()
                }
            }
        }
        try {
            expiry = schedulePeerDialDeadline(clock, deadlineMs, expire)
            addresses.forEach { address ->
                val cancellationTurn = Any()
                var cleanupStarted = false
                val future = executor.submit {
                    var locallyOwned: RpcStream? = null
                    try {
                        val result = try {
                            val remainingMs = deadlineMs - clock.currentTimeMillis()
                            if (remainingMs <= 0L) {
                                PeerAddressDialResult(address, null, null)
                            } else {
                                val stream = network.dial(
                                    peerId = peerId,
                                    address = address,
                                    protocolId = Libp2pRpcProtocol.PROTOCOL_ID,
                                    timeoutMs = remainingMs,
                                    responseReader = responseReader,
                                )
                                locallyOwned = stream
                                val dialExpired = clock.currentTimeMillis() >= deadlineMs
                                if (!dialExpired && dialResultOwnership.compareAndSet(dialResultUnclaimed, stream)) {
                                    locallyOwned = null
                                    PeerAddressDialResult(address, stream, null)
                                } else {
                                    PeerAddressDialResult(
                                        address,
                                        null,
                                        IllegalStateException(
                                            if (dialExpired) {
                                                "Address '$address' connected after the shared $connectionTimeoutMs ms connection deadline had elapsed."
                                            } else {
                                                "Address '$address' connected after another supplied address had already won."
                                            }
                                        )
                                    )
                                }
                            }
                        } catch (failure: Throwable) {
                            PeerAddressDialResult(address, null, failure)
                        }
                        // Read the clock outside the outcome lock: a Clock may hold its
                        // own lock while invoking the expiry callback.
                        val published = try {
                            if (clock.currentTimeMillis() < deadlineMs) result else null
                        } catch (failure: Throwable) {
                            PeerAddressDialResult(address, null, failure)
                        }
                        synchronized(outcomeLock) {
                            if (!expired && published != null) {
                                outcomes.addLast(published)
                                outcomeReady.release()
                            }
                        }
                    } finally {
                        locallyOwned?.let { stream ->
                            synchronized(cancellationTurn) {
                                cleanupStarted = true
                                // Caller cancellation belongs to the dial. Finish delivering it
                                // before cleanup owns the worker, then clear that worker's flag.
                                Thread.interrupted()
                            }
                            try {
                                // Publish before cleanup; foreign close code cannot delay
                                // the caller's outcome or run on its departing thread.
                                executor.execute { closeUnconsumed(stream) }
                            } catch (_: RejectedExecutionException) {
                                // The caller already left; this worker still owns cleanup.
                                closeUnconsumed(stream)
                            }
                        }
                    }
                }
                cancelDials += {
                    synchronized(cancellationTurn) {
                        if (!cleanupStarted && !future.isDone) future.cancel(true)
                    }
                }
            }
            var remainingCompletions = addresses.size
            while (remainingCompletions-- > 0) {
                outcomeReady.acquire()
                val result = synchronized(outcomeLock) { outcomes.pollFirst() } ?: break
                result.stream?.let { stream ->
                    _peerRegistry.getObservationLog().recordSuccess(peerId)
                    if (result.address.contains("/p2p-circuit/")) {
                        _peerRegistry.recordRelayOnlyReachability(peerId)
                    } else {
                        _peerRegistry.recordDirectReachability(peerId)
                    }
                    val identified = stream.withServiceIdentifier(methodPath)
                    dialResultOwnership.compareAndSet(stream, identified)
                    selectedStream = identified
                }
                if (selectedStream != null) break
                result.failure?.let { failures[result.address] = it }
                if (remainingCompletions > 0 && synchronized(outcomeLock) { !expired }) {
                    // The next event wait has the same absolute deadline. Cancel its
                    // predecessor before re-arming, including when Clock advances here.
                    val previousExpiry = expiry
                    expiry = null
                    previousExpiry?.cancel()
                    expiry = schedulePeerDialDeadline(clock, deadlineMs, expire)
                }
            }
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            exitFailure = UrlProtocolException("The caller was interrupted while waiting for a dial", interrupted)
        } catch (failure: Throwable) {
            exitFailure = failure
        } finally {
            cleanup { expiry?.cancel() }
            val unconsumed = dialResultOwnership.getAndSet(dialResultClosed)
            cancelDials.forEach { cancelDial -> cleanup(cancelDial) }

            // Keep the selected stream recoverable until every exit operation succeeds.
            // A closed slot also leaves late results owned by their dial workers.
            var pendingCleanup = unconsumed as? RpcStream
            if (pendingCleanup != null && (exitFailure != null || pendingCleanup !== selectedStream)) {
                val stream = pendingCleanup
                cleanup {
                    executor.execute { closeUnconsumed(stream) }
                    pendingCleanup = null
                }
            }
            var shutdownSucceeded = false
            cleanup {
                executor.shutdown()
                shutdownSucceeded = true
            }
            if (!shutdownSucceeded) {
                cleanup {
                    // shutdown can throw before changing the pool's running state.
                    // Preserve queued closes when shutdownNow returns unstarted work.
                    executor.shutdownNow().forEach { task ->
                        cleanup {
                            Thread(task, "UrlProtocol-peer-dial-cleanup-${peerId.take(12)}")
                                .apply { isDaemon = true }.start()
                        }
                    }
                }
            }
            if (exitFailure != null) {
                pendingCleanup?.let { stream ->
                    // If submission or shutdown itself failed, cleanup still cannot run
                    // foreign close code on the departing caller or use a stopped executor.
                    cleanup {
                        Thread({ closeUnconsumed(stream) }, "UrlProtocol-peer-dial-cleanup-${peerId.take(12)}")
                            .apply { isDaemon = true }.start()
                    }
                }
            }
        }
        exitFailure?.let { throw it }
        selectedStream?.let { return it }

        val budgetFailures = addresses.associateWith { address ->
            IllegalStateException(
                "address '$address': dial did not complete within the $connectionTimeoutMs ms connection budget"
            )
        }
        val errors = addresses.joinToString("; ") { address ->
            failures[address]?.let { "address='$address': ${it.message}" }
                ?: budgetFailures.getValue(address).message!!
        }
        throw UrlProtocolException(
            "Failed to open RPC stream to peer '$peerId' at addresses " +
                "${addresses.joinToString(prefix = "[", postfix = "]")} for method path " +
                "'$methodPath' within $connectionTimeoutMs ms: all ${addresses.size} addresses " +
                "failed. Errors: $errors",
            failures.values.lastOrNull() ?: budgetFailures.getValue(addresses.last())
        )
    }

    private fun ensureNetworkListening(): NetworkListenInfo {
        val info = startNetwork(0)
        return withStartupTurn(lanStartToken) {
            val libp2pNetwork = network as? Libp2pNetworkProvider
            if (lanDiscoveryConfig.enabled && libp2pNetwork == null) {
                throw incompatibleNetworkProvider(
                    "LanDiscoveryConfig(enabled=true)"
                )
            }
            if (lanDiscoveryConfig.enabled && lanPeerDiscovery == null) {
                val discovery = LanPeerDiscovery(
                    host = libp2pNetwork!!.requireLibp2pHost(),
                    peerRegistry = _peerRegistry,
                    config = lanDiscoveryConfig,
                    clock = clock
                )
                try {
                    discovery.start().whenComplete { _, error ->
                        if (error != null) {
                            tossLanDiscoveryWarning(
                                "LAN discovery startup failed and will be skipped for this host: ${error.message}",
                                error
                            )
                            debugLog {
                                "LAN discovery startup failed and will be skipped for this host: ${error.message}"
                            }
                        }
                    }
                } catch (e: Exception) {
                    tossLanDiscoveryWarning(
                        "LAN discovery startup failed and will be skipped for this host: ${e.message}",
                        e
                    )
                    debugLog {
                        "LAN discovery startup failed and will be skipped for this host: ${e.message}"
                    }
                }
                val retained = synchronized(serviceLifecycle) {
                    if (protocolClosed.get()) false else {
                        lanPeerDiscovery = discovery
                        true
                    }
                }
                if (!retained) {
                    discovery.stop().get(5, TimeUnit.SECONDS)
                    ensureStreamOpen()
                }
            }
            info
        }
    }

    // =========================================================================
    // STUB METHODS FOR API COMPATIBILITY WITH UrlResolver
    // These methods are placeholders to make UrlProtocol's API similar to
    // UrlResolver's API. They are not yet implemented in the low-level protocol.
    // =========================================================================

    /**
     * Information about the network join result.
     */
    data class NetworkJoinInfo(
        /** The peer ID of this node */
        val peerId: String,
        /** All multiaddresses where this node can be reached */
        val multiaddresses: List<String>,
        /** Whether this node has a publicly routable address */
        val isPubliclyRoutable: Boolean,
        /** Whether this node is registered with a relay for NAT traversal */
        val registeredWithRelay: Boolean
    )

    /**
     * Sets a key seed for generating a persistent peer ID.
     *
     * @param seed The seed string to derive the key from
     * @return This protocol for chaining
     */
    fun withKeySeed(seed: String): UrlProtocol {
        TODO("withKeySeed is not yet implemented in UrlProtocol. Use UrlResolver for this functionality.")
    }

    /**
     * Sets a specific port for the libp2p listener.
     *
     * @param port The port to listen on (0 for random)
     * @return This protocol for chaining
     */
    fun withListenPort(port: Int): UrlProtocol {
        TODO("withListenPort is not yet implemented in UrlProtocol. Use UrlResolver for this functionality.")
    }

    /**
     * Sets a node alias for identification in the P2P network.
     *
     * @param alias The alias to use for this node
     * @return This protocol for chaining
     */
    fun withAlias(alias: String): UrlProtocol {
        TODO("withAlias is not yet implemented in UrlProtocol. Use UrlResolver for this functionality.")
    }

    /**
     * Eagerly starts network joining in the background.
     *
     * @return This protocol for chaining
     */
    fun withEagerNetworkJoin(): UrlProtocol {
        TODO("withEagerNetworkJoin is not yet implemented in UrlProtocol. Use UrlResolver for this functionality.")
    }

    /**
     * Opens a typed connection to a service identified by the given url:// URL.
     *
     * @param url The url:// protocol URL identifying the service
     * @param type The expected return type class for the connection
     * @return A connection of the specified type
     */
    fun <T : Any> openConnection(url: String, type: KClass<T>): T {
        TODO("openConnection with type is not yet implemented in UrlProtocol. Use UrlResolver for typed connections, or use openStream() for raw RPC communication.")
    }

    /**
     * Opens a typed connection to a service with additional headers.
     *
     * @param url The url:// protocol URL identifying the service
     * @param type The expected return type class for the connection
     * @param headers Optional headers to include with the connection request
     * @return A connection of the specified type
     */
    fun <T : Any> openConnection(url: String, type: KClass<T>, headers: Map<String, String>): T {
        TODO("openConnection with type and headers is not yet implemented in UrlProtocol. Use UrlResolver for typed connections, or use openStream() for raw RPC communication.")
    }

    /**
     * Resolves a url:// URL and returns the result as a String.
     *
     * @param url The url:// protocol URL identifying the service
     * @return The service response as a String
     */
    fun resolveString(url: String): String {
        TODO("resolveString is not yet implemented in UrlProtocol. Use UrlResolver for this functionality, or use openStream() for raw RPC communication.")
    }

    /**
     * Resolves a url:// URL with headers and returns the result as a String.
     *
     * @param url The url:// protocol URL identifying the service
     * @param headers Headers to include with the request
     * @return The service response as a String
     */
    fun resolveString(url: String, headers: Map<String, String>): String {
        TODO("resolveString with headers is not yet implemented in UrlProtocol. Use UrlResolver for this functionality, or use openStream() for raw RPC communication.")
    }

    /**
     * Gets information about this node's network presence.
     *
     * @return NetworkJoinInfo containing the peer ID and multiaddresses
     */
    fun getNetworkInfo(): NetworkJoinInfo {
        TODO("getNetworkInfo is not yet implemented in UrlProtocol. Use UrlResolver for this functionality.")
    }

    /**
     * Joins the P2P network without registering any services.
     *
     * @param alias Optional service alias to register
     * @return NetworkJoinInfo containing the peer ID and multiaddresses
     */
    internal fun joinNetwork(alias: String? = null): NetworkJoinInfo {
        TODO("joinNetwork is not yet implemented in UrlProtocol. Use UrlResolver for this functionality.")
    }

    /**
     * Gets the peer ID for this protocol instance.
     *
     * @return The Base58-encoded peer ID
     */
    fun getPeerId(): String {
        TODO("getPeerId is not yet implemented in UrlProtocol. Use UrlResolver for this functionality.")
    }

    /**
     * Gets all locally registered services.
     *
     * @return List of service registrations
     */
    fun getRegisteredServices(): List<ServiceRegistration> {
        TODO("getRegisteredServices is not yet implemented in UrlProtocol. Use UrlResolver for service registration.")
    }

    /**
     * Gets a list of all discovered services in the network.
     *
     * @return List of discovered services
     */
    fun getDiscoveredServices(): List<ServiceInfo> {
        TODO("getDiscoveredServices is not yet implemented in UrlProtocol. Use UrlResolver for service discovery.")
    }

    /**
     * Queries cached announcements and known peers, then actively asks every reachable known
     * peer for services matching [pattern]. Matching follows UrlResolver's raw-host rule: an
     * exact identifier or a dot-delimited descendant matches, while a shared string prefix does
     * not (for example, `com.example.chat` matches `com.example.chat.rooms`, but not
     * `com.example.chatroom`).
     *
     * Best-effort query failures are ignored so an absent service is represented by an empty
     * list rather than an exception.
     */
    fun queryServices(
        pattern: String,
        maxResults: Int = DEFAULT_SERVICE_QUERY_MAX_RESULTS,
        queryTimeoutMs: Long = DEFAULT_SERVICE_QUERY_TIMEOUT_MS,
        maxConcurrentDials: Int = DEFAULT_SERVICE_QUERY_CONCURRENCY
    ): List<ServiceInfo> {
        require(pattern.isNotBlank()) {
            "Cannot query services with a blank pattern."
        }
        require(maxResults > 0) {
            "maxResults must be greater than zero, but was $maxResults."
        }
        require(queryTimeoutMs > 0L) {
            "queryTimeoutMs must be greater than zero, but was $queryTimeoutMs."
        }
        require(maxConcurrentDials > 0) {
            "maxConcurrentDials must be greater than zero, but was $maxConcurrentDials."
        }
        startNetwork()
        pruneExpiredActiveServiceResults()

        val results = LinkedHashMap<String, ServiceInfo>()
        fun add(service: ServiceInfo) {
            if (matchesServicePattern(service.serviceIdentifier, pattern)) {
                results["${service.serviceIdentifier}|${service.providerPeerId}"] = service
            }
        }

        knownServiceInfos(pattern).forEach(::add)
        if (results.size >= maxResults) {
            lastServiceQueryDiagnostics = ServiceQueryDiagnostics(
                cachedResults = results.size,
                returnedResults = maxResults
            )
            return results.values.take(maxResults)
        }

        val query = GossipProtocol.ServiceQuery(
            id = GossipProtocol.nextMessageId(),
            servicePattern = pattern,
            maxResults = maxResults
        )
        val localPeerId = networkListenInfo?.peerId
        val peers = _peerRegistry.rankPeersForAllocation()
            .asSequence()
            .filter { it.peerId != localPeerId }
            .distinctBy { it.peerId }
            .toList()
        val deadlineNanos = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(queryTimeoutMs)
        val executor = Executors.newFixedThreadPool(minOf(maxConcurrentDials, peers.size.coerceAtLeast(1))) {
            runnable -> Thread(runnable, "UrlProtocol-service-query").apply { isDaemon = true }
        }
        val completions = ExecutorCompletionService<ServiceQueryPeerResult>(executor)
        var submitted = 0
        var completed = 0
        var successfulPeers = 0
        val failures = mutableListOf<String>()

        fun submitNext(): Boolean {
            if (submitted >= peers.size) return false
            val peer = peers[submitted++]
            completions.submit {
                var lastFailure: Exception? = null
                for (address in peer.multiaddresses.filter { it.isNotBlank() }.sorted()) {
                    val remainingNanos = deadlineNanos - System.nanoTime()
                    if (remainingNanos <= 0L) break
                    val dialTimeoutMs = minOf(
                        DEFAULT_SERVICE_QUERY_DIAL_TIMEOUT_MS,
                        TimeUnit.NANOSECONDS.toMillis(remainingNanos).coerceAtLeast(1L)
                    )
                    try {
                        network.dial(
                            peer.peerId,
                            address,
                            GossipProtocol.PROTOCOL_ID,
                            dialTimeoutMs
                        ).use { stream ->
                            val requestStartedElapsedMillis = samplePeerFreshnessTime(clock)
                            Libp2pRpcProtocol.writeMessage(stream.output, query.toJson())
                            val responseJson = Libp2pRpcProtocol.readMessage(stream.input)
                            val responseReceivedElapsedMillis = samplePeerFreshnessTime(clock)
                            val response = GossipProtocol.parseMessage(responseJson) as? GossipProtocol.ServiceQueryResponse
                                ?: throw UrlProtocolException(
                                    "Peer '${peer.peerId}' returned an invalid response to service query '$pattern'."
                                )
                            if (response.id != query.id) {
                                throw UrlProtocolException(
                                    "Peer '${peer.peerId}' returned service-query response id " +
                                        "'${response.id}', expected '${query.id}'."
                                )
                            }
                            return@submit ServiceQueryPeerResult(peer, response.services, null, requestStartedElapsedMillis, responseReceivedElapsedMillis)
                        }
                    } catch (failure: Exception) {
                        lastFailure = failure
                    }
                }
                ServiceQueryPeerResult(
                    peer,
                    emptyList(),
                    lastFailure ?: UrlProtocolException(
                        "Peer '${peer.peerId}' has no usable address for service query '$pattern'."
                    )
                )
            }
            return true
        }

        repeat(minOf(maxConcurrentDials, peers.size)) { submitNext() }
        try {
            while (completed < submitted && results.size < maxResults) {
                val remainingNanos = deadlineNanos - System.nanoTime()
                if (remainingNanos <= 0L) break
                val future = completions.poll(remainingNanos, TimeUnit.NANOSECONDS) ?: break
                completed++
                val peerResult = try {
                    future.get()
                } catch (failure: Exception) {
                    ServiceQueryPeerResult(
                        peer = peers.getOrNull(completed - 1),
                        services = emptyList(),
                        failure = failure
                    )
                }
                if (peerResult.failure != null) {
                    val peerId = peerResult.peer?.peerId ?: "unknown"
                    val diagnostic = "Active service query '$pattern' failed for peer '$peerId': " +
                        "${peerResult.failure.message}"
                    failures += diagnostic
                    tossServiceQueryWarning(diagnostic, peerResult.failure)
                } else {
                    successfulPeers++
                    peerResult.peer?.let {
                        _peerRegistry.getObservationLog().recordSuccess(it.peerId)
                    }
                    val receivedAt = peerResult.responseReceivedElapsedMillis ?: samplePeerFreshnessTime(clock)
                    val elapsedMillis = peerResult.requestStartedElapsedMillis?.let { started ->
                        peerFreshnessElapsedMillis(started, receivedAt)
                    } ?: Long.MAX_VALUE
                    peerResult.services.forEach { receivedService ->
                        if (matchesServicePattern(receivedService.serviceIdentifier, pattern) &&
                            nameResolutionConfig.resolver.resolve(receivedService.serviceIdentifier)
                                .accepts(receivedService.providerPeerId)
                        ) {
                            _peerRegistry.addImportedPeer(
                                Libp2pPeer.remote(
                                    peerId = receivedService.providerPeerId,
                                    multiaddresses = receivedService.providerMultiaddresses,
                                    advertisedServices = listOf(receivedService.serviceIdentifier)
                                ),
                                freshness = receivedService.freshness,
                                exchangeElapsedMillis = elapsedMillis,
                                origin = PeerRegistryAddOrigin.CATALOG,
                                receivedAtElapsedMillis = receivedAt.nowMillis,
                                receivedAtTimeSample = receivedAt
                            )
                            val totalElapsed = peerResult.requestStartedElapsedMillis?.let { started ->
                                peerFreshnessElapsedMillis(started, samplePeerFreshnessTime(clock))
                            } ?: Long.MAX_VALUE
                            val service = receivedService.withFreshnessAgedBy(totalElapsed)
                            activeServiceQueryExpiries[
                                activeServiceKey(service.serviceIdentifier, service.providerPeerId)
                            ] = clock.currentTimeMillis() + ACTIVE_SERVICE_QUERY_RESULT_TTL_MS
                            add(service)
                        }
                    }
                }
                if (results.size < maxResults) submitNext()
            }
        } finally {
            executor.shutdownNow()
        }
        val timedOut = completed < submitted || submitted < peers.size
        if (timedOut && results.size < maxResults) {
            val diagnostic = "Active service query '$pattern' reached its ${queryTimeoutMs} ms " +
                "deadline after completing $completed of ${peers.size} peer queries."
            failures += diagnostic
            tossServiceQueryWarning(diagnostic)
        }
        lastServiceQueryDiagnostics = ServiceQueryDiagnostics(
            cachedResults = knownServiceInfos(pattern).count {
                "${it.serviceIdentifier}|${it.providerPeerId}" in results
            },
            attemptedPeers = submitted,
            successfulPeers = successfulPeers,
            failedPeers = failures.size,
            timedOut = timedOut,
            returnedResults = minOf(results.size, maxResults),
            warnings = failures.toList()
        )
        return results.values.take(maxResults)
    }

    fun getLastServiceQueryDiagnostics(): ServiceQueryDiagnostics = lastServiceQueryDiagnostics

    /**
     * Registers a local service at the given URL.
     *
     * @param serviceUrl The full service URL
     * @param handler The handler that will process requests to this service
     * @param config Optional configuration for the registration
     * @return A ServiceRegistration handle for managing the registration
     */
    fun registerLocalService(
        serviceUrl: String,
        handler: ServiceHandler,
        config: ServiceRegistrationConfig = ServiceRegistrationConfig()
    ): ServiceRegistration {
        TODO("registerLocalService is not yet implemented in UrlProtocol. Use UrlResolver for service registration.")
    }

    /**
     * Registers a global service at the given URL.
     *
     * @param serviceUrl The full service URL
     * @param handler The handler that will process requests to this service
     * @param config Optional configuration for the registration
     * @return A ServiceRegistration handle for managing the registration
     */
    fun registerGlobalService(
        serviceUrl: String,
        handler: ServiceHandler,
        config: ServiceRegistrationConfig = ServiceRegistrationConfig()
    ): ServiceRegistration {
        TODO("registerGlobalService is not yet implemented in UrlProtocol. Use UrlResolver for service registration.")
    }

    /**
     * Sends an RPC request to a service and returns the result.
     *
     * This method uses a cached [RpcStream] per service URL. The underlying
     * [RpcStream.sendRequest] provides fine-grained locking (synchronized only
     * on the output stream during writes), allowing multiple concurrent callers
     * to share a single stream with maximum concurrency.
     *
     * If the cached stream is closed or broken, it is evicted and a new stream
     * is opened transparently.
     *
     * @param url The url:// protocol URL identifying the service
     * @param method The RPC method name to call
     * @param params The method parameters as a map
     * @return The result of the RPC call as a map
     * @throws UrlProtocolException if the request fails, times out, or the server returns an error
     */
    fun sendServiceRpcRequest(
        url: String,
        method: String,
        params: Map<String, Any?>
    ): Map<String, Any?> {
        ensureServiceRequestOpen(url, method)
        val request = Libp2pRpcProtocol.RpcRequest(
            id = Libp2pRpcProtocol.nextRequestId(),
            method = method,
            params = params
        )

        val serviceIdentifier = parseUrl(url).serviceIdentifier
        // Identifies this call's own closed failures, so a closed failure raised by a nested send
        // (for example from the caller's parameter serialization) is never taken for this one's.
        val admission = Any()
        // The call is sent at most twice: one replacement stream after a transport failure.
        // A replaced stream is retired, not closed: other callers' requests already in flight on
        // the shared stream finish on it, and it closes once the last of them is done.
        var sendAgainWithSameId = false
        var sendAgainWithNewId = false
        val firstResponse = withServiceStream(url, method, serviceIdentifier, admission) { stream ->
            val sent = try {
                sendRegisteredServiceRequest(stream, request, url, method, admission)
            } catch (e: Exception) {
                // A send rejected at admission because close had begun already reports the close.
                // An exception that leaves the stream open, such as a failure serializing the
                // caller's parameters, is not a broken stream: it propagates unchanged and the
                // stream stays cached. Only one that left the stream closed replaces it. An
                // interrupted caller is never sent again on any path, and its interruption
                // propagates as it is, never as the close.
                if (e.isClosedFailureOf(admission) || e is InterruptedException ||
                    Thread.currentThread().isInterrupted || stream.isOpen
                ) throw e
                retireServiceStream(serviceIdentifier, stream)
                // A call whose stream was closed while the protocol is closing fails with the
                // close, keeping the exception as the cause, and never reconnects.
                if (protocolClosed.get()) throw closedServiceRequestFailure(url, method, e, admission)
                sendAgainWithSameId = true
                null
            }
            // A local transport failure that left the stream unable to carry calls (the request
            // write failed, or the connection closed) replaces the stream and sends the call
            // once more. The RpcTransportFailure marker decides this, never the error text: a
            // service's own error is returned to the caller even when its message reads like a
            // transport failure. A REQUEST_WRITE failure is assumed not to have delivered a
            // complete request frame. The stream is replaced even for an interrupted caller, since
            // the transport reported it unable to carry calls, but an interrupted caller is not
            // sent again: its interruption stays set and the failure is reported.
            if (sent != null && sent.error.isStreamReplacementRetryable()) {
                retireServiceStream(serviceIdentifier, stream)
                // Nor is a call whose stream was closed by close(): it fails with the close,
                // keeping the transport failure as the cause, and never reconnects.
                throwIfClosedSendFailure(sent, url, method, admission)
                sendAgainWithNewId = !Thread.currentThread().isInterrupted
            }
            sent
        }
        val response = when {
            sendAgainWithSameId -> try {
                withServiceStream(url, method, serviceIdentifier, admission) { stream ->
                    try {
                        sendRegisteredServiceRequest(stream, request, url, method, admission)
                    } catch (e: Exception) {
                        // The replacement attempt is the last one. An exception that left it closed
                        // once close has begun was ended by the close and reports it.
                        if (protocolClosed.get() && !e.isClosedFailureOf(admission) && e !is InterruptedException &&
                            !Thread.currentThread().isInterrupted && !stream.isOpen
                        ) throw closedServiceRequestFailure(url, method, e, admission)
                        throw e
                    }
                }
            } catch (retryException: Exception) {
                // A close failure, whether at admission or ending the replacement, is reported as it is.
                if (retryException.isClosedFailureOf(admission)) throw retryException
                throw UrlProtocolException(
                    "RPC request to '$url' method '$method' failed after reconnection: ${retryException.message}",
                    retryException
                )
            }
            sendAgainWithNewId -> withServiceStream(url, method, serviceIdentifier, admission) { stream ->
                try {
                    sendRegisteredServiceRequest(
                        stream,
                        Libp2pRpcProtocol.RpcRequest(
                            id = Libp2pRpcProtocol.nextRequestId(),
                            method = method,
                            params = params
                        ),
                        url,
                        method,
                        admission,
                    )
                } catch (e: Exception) {
                    // This replacement is also the last attempt. Keep caller failures unchanged;
                    // a closed stream observed during protocol close reports the close with its cause.
                    if (protocolClosed.get() && !e.isClosedFailureOf(admission) && e !is InterruptedException &&
                        !Thread.currentThread().isInterrupted && !stream.isOpen
                    ) throw closedServiceRequestFailure(url, method, e, admission)
                    throw e
                }
            }
            else -> checkNotNull(firstResponse)
        }
        // The replacement attempt is the last one either way. A stream-replacement failure it
        // observes while the protocol is closed was ended by the close and reports it.
        if (response !== firstResponse && response.error.isStreamReplacementRetryable()) {
            throwIfClosedSendFailure(response, url, method, admission)
        }

        val finalError = response.error
        if (finalError != null) {
            throw UrlProtocolException(
                "RPC error from '$url' method '$method': " +
                    "[${finalError.code}] ${finalError.message}",
                (finalError.data as? RpcTransportFailure)?.cause,
            )
        }

        @Suppress("UNCHECKED_CAST")
        return when (val result = response.result) {
            is Map<*, *> -> result as Map<String, Any?>
            null -> emptyMap()
            else -> mapOf("result" to result)
        }
    }

    private fun sendRegisteredServiceRequest(
        stream: RpcStream,
        request: Libp2pRpcProtocol.RpcRequest,
        url: String,
        method: String,
        admission: Any,
    ): Libp2pRpcProtocol.RpcResponse {
        val caller = Thread.currentThread()
        synchronized(serviceLifecycle) {
            ensureServiceRequestOpen(url, method, admission)
            activeServiceSends[caller] = (activeServiceSends[caller] ?: 0) + 1
        }
        try {
            // Transport IO and caller-owned serialization run outside the lifecycle monitor.
            // A nested send may acquire another stream; close must release acquisition waiters.
            ensureServiceRequestOpen(url, method, admission)
            return stream.sendRequest(request)
        } finally {
            synchronized(serviceLifecycle) {
                val remaining = checkNotNull(activeServiceSends[caller]) - 1
                if (remaining == 0) activeServiceSends.remove(caller)
                else activeServiceSends[caller] = remaining
                serviceLifecycle.notifyAll()
            }
        }
    }

    /**
     * Runs [block] with the cached stream for [url], counting the call as in flight on that stream
     * so that retiring the stream never closes it under the call.
     */
    private inline fun <T> withServiceStream(
        url: String,
        method: String,
        serviceIdentifier: String,
        admission: Any,
        block: (RpcStream) -> T,
    ): T {
        val stream = acquireServiceStream(url, method, serviceIdentifier, admission)
        try {
            return block(stream)
        } finally {
            releaseServiceStream(stream)
        }
    }

    private fun acquireServiceStream(url: String, method: String, serviceIdentifier: String, admission: Any): RpcStream {
        while (true) {
            // Throws once the protocol is closed, so a close never leaves this loop spinning.
            val stream = getOrCreateStream(url, method, admission)
            synchronized(serviceStreamLock) {
                // A stream retired between the cache lookup and this check is not handed out.
                if (activeStreams[serviceIdentifier] === stream) {
                    serviceStreamCallsInFlight[stream] = (serviceStreamCallsInFlight[stream] ?: 0) + 1
                    return stream
                }
            }
        }
    }

    private fun releaseServiceStream(stream: RpcStream) {
        val closeNow = synchronized(serviceStreamLock) {
            val remaining = (serviceStreamCallsInFlight[stream] ?: 1) - 1
            if (remaining > 0) {
                serviceStreamCallsInFlight[stream] = remaining
                false
            } else {
                serviceStreamCallsInFlight.remove(stream)
                retiredServiceStreams.remove(stream)
            }
        }
        if (closeNow) closeRetiredServiceStream(stream)
    }

    /**
     * Stops handing [stream] to new calls, if it is still the cached stream for
     * [serviceIdentifier] (a concurrent caller may already have replaced it). Calls already in
     * flight on it finish there; the stream is closed when the last of them is done, or by
     * [close] if that comes first, so a retired stream never outlives this protocol.
     */
    private fun retireServiceStream(serviceIdentifier: String, stream: RpcStream) {
        val closeNow = synchronized(serviceStreamLock) {
            if (!activeStreams.remove(serviceIdentifier, stream)) return
            if ((serviceStreamCallsInFlight[stream] ?: 0) == 0) {
                true
            } else {
                retiredServiceStreams.add(stream)
                false
            }
        }
        if (closeNow) closeRetiredServiceStream(stream)
    }

    private fun closeRetiredServiceStream(stream: RpcStream) {
        try {
            stream.close()
        } catch (failure: Exception) {
            val effect = EvictedRpcStreamCloseWarningEffect(stream.serviceIdentifier, failure)
            try {
                toss(effect)
            } catch (unhandled: UnhandledNotificationEffect) {
                // Swallowed deliberately: with no handler installed the warning has no other
                // audience, and the calls that used the stream have already finished.
                if (unhandled.effect !== effect) throw unhandled
            }
        }
    }

    private fun ensureStreamOpen() {
        if (protocolClosed.get()) throw ProtocolClosedOpenException(null)
    }

    private fun adoptStream(stream: RpcStream): RpcStream {
        val owned = OwnedProtocolRpcStream(stream,
            beforeCleanup = { caller ->
                synchronized(serviceLifecycle) {
                    ownedResourceCleanups[caller] = (ownedResourceCleanups[caller] ?: 0) + 1
                }
            },
            released = { released, caller, failure ->
                synchronized(serviceLifecycle) {
                    // A delegate may initiate protocol close and fail only after it returns.
                    // Publish that failure before removing the cleanup owner or waking drains.
                    if (protocolClosed.get() && failure != null) closeResult.record(failure)
                    ownedStreams.remove(released)
                    val remaining = checkNotNull(ownedResourceCleanups[caller]) - 1
                    if (remaining == 0) ownedResourceCleanups.remove(caller)
                    else ownedResourceCleanups[caller] = remaining
                    serviceLifecycle.notifyAll()
                }
            })
        val adopted = synchronized(serviceLifecycle) {
            if (protocolClosed.get()) false else {
                ownedStreams[owned] = true
                true
            }
        }
        if (!adopted) {
            // A dial may finish after cleanup took its snapshot. Release that result here,
            // outside lifecycle ownership; it never enters either the owned set or send cache.
            owned.close()
            ensureStreamOpen()
        }
        return owned
    }

    private fun closedServiceRequestFailure(
        url: String,
        method: String,
        cause: Throwable?,
        admission: Any?,
    ): UrlProtocolException = ProtocolClosedSendException(
        "Cannot send service RPC request to '$url' method '$method': UrlProtocol is closed.",
        cause,
        admission,
    )

    /**
     * Throws the close for a stream-replacement [response] observed once close has begun, keeping
     * the transport failure's cause. Caller interruption keeps the original response and flag.
     * Close classification uses protocol state and the typed failure, never message text.
     */
    private fun throwIfClosedSendFailure(
        response: Libp2pRpcProtocol.RpcResponse,
        url: String,
        method: String,
        admission: Any,
    ) {
        if (!Thread.currentThread().isInterrupted && protocolClosed.get()) {
            throw closedServiceRequestFailure(url, method, (response.error?.data as? RpcTransportFailure)?.cause, admission)
        }
    }

    private fun ensureServiceRequestOpen(url: String, method: String, admission: Any? = null) {
        if (protocolClosed.get()) throw closedServiceRequestFailure(url, method, null, admission)
    }

    // Only thread identity and cache publication are guarded here. The state monitor is
    // released before every supplied call; terminal close wakes queued creation callers.
    private val streamCreationOwners = HashMap<String, Thread>()

    private fun getOrCreateStream(url: String, method: String, admission: Any): RpcStream {
        ensureServiceRequestOpen(url, method, admission)
        val parsedUrl = parseUrl(url)
        val serviceIdentifier = parsedUrl.serviceIdentifier

        // Fast path: return cached stream if it's still open (lock-free)
        val existing = activeStreams[serviceIdentifier]
        if (existing != null && existing.isOpen) {
            ensureServiceRequestOpen(url, method, admission)
            return existing
        }

        val caller = Thread.currentThread()
        synchronized(serviceLifecycle) {
            while (streamCreationOwners.containsKey(serviceIdentifier)) {
                ensureServiceRequestOpen(url, method, admission)
                check(streamCreationOwners[serviceIdentifier] !== caller) {
                    "Cannot acquire service '$serviceIdentifier' recursively while creating its stream."
                }
                try {
                    serviceLifecycle.wait()
                } catch (interrupted: InterruptedException) {
                    caller.interrupt()
                    throw UrlProtocolException("Interrupted while opening stream for '$url' method '$method'.", interrupted)
                }
            }
            ensureServiceRequestOpen(url, method, admission)
            streamCreationOwners[serviceIdentifier] = caller
        }
        try {
            // A supplied getter may close the protocol or enter another public send.
            // No monitor is held while checking, disposing, or dialing the stream.
            val doubleCheck = activeStreams[serviceIdentifier]
            if (doubleCheck != null && doubleCheck.isOpen) {
                ensureServiceRequestOpen(url, method, admission)
                return doubleCheck
            }
            ensureServiceRequestOpen(url, method, admission)
            if (doubleCheck != null) {
                activeStreams.remove(serviceIdentifier, doubleCheck)
                doubleCheck.close()
            }
            val newStream = try {
                openStream(url)
            } catch (failure: Exception) {
                // Startup can reject admission before dialing. Keep the service context and null
                // cause for the protocol's own typed admission marker; direct opens keep their error.
                if (protocolClosed.get() && failure is ProtocolClosedOpenException && failure.cause == null) {
                    throw closedServiceRequestFailure(url, method, null, admission)
                }
                // Close shuts the network provider down underneath a dial in progress. That
                // dial's failure is the close's outcome, reported like every other closed open.
                if (protocolClosed.get() && failure !is ProtocolClosedOpenException) {
                    throw ProtocolClosedOpenException(failure)
                }
                throw failure
            }
            synchronized(serviceLifecycle) {
                ensureServiceRequestOpen(url, method, admission)
                activeStreams[serviceIdentifier] = newStream
            }
            return newStream
        } finally {
            synchronized(serviceLifecycle) {
                streamCreationOwners.remove(serviceIdentifier)
                serviceLifecycle.notifyAll()
            }
        }
    }

    /**
     * Requests implementation bytecode from a specific peer for sandboxed execution.
     *
     * @param peer The peer to request bytecode from
     * @param serviceIdentifier The service identifier
     * @param interfaceClassName Optional interface class name hint
     * @return The bytecode response containing JAR bytes and implementation class name
     */
    fun requestBytecodeFromPeer(
        peer: BootstrapPeer,
        serviceIdentifier: String,
        interfaceClassName: String?
    ): BytecodeResponse = requestBytecodeFromPeer(
        peer = peer,
        serviceIdentifier = serviceIdentifier,
        interfaceClassName = interfaceClassName,
        resourcePath = null,
        requestTimeoutMs = DEFAULT_BYTECODE_REQUEST_TIMEOUT_MS,
        connectionTimeoutMs = DEFAULT_CONNECTION_TIMEOUT_MS
    )

    /**
     * Budgeted exact-peer bytecode request. The three-argument overload above preserves the
     * published 0.0.402 JVM descriptor while delegating to this implementation.
     */
    fun requestBytecodeFromPeer(
        peer: BootstrapPeer,
        serviceIdentifier: String,
        interfaceClassName: String?,
        resourcePath: String? = null,
        requestTimeoutMs: Long = DEFAULT_BYTECODE_REQUEST_TIMEOUT_MS,
        connectionTimeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS
    ): BytecodeResponse {
        val result = requestBytecodeConditionallyFromPeer(
            peer = peer,
            serviceIdentifier = serviceIdentifier,
            interfaceClassName = interfaceClassName,
            cachedDigest = null,
            resourcePath = resourcePath,
            requestTimeoutMs = requestTimeoutMs,
            connectionTimeoutMs = connectionTimeoutMs
        )
        return when (result) {
            is BytecodeFetchResult.Downloaded -> result.response
            is BytecodeFetchResult.NotModified -> throw UrlProtocolException(
                "Peer '${peer.peerId}' answered an unconditional bytecode request for service " +
                    "'$serviceIdentifier' with a not-modified response (digest ${result.digest})."
            )
        }
    }

    /**
     * Requests implementation bytecode from exactly [peer], optionally revalidating
     * [cachedDigest]. The request never performs service discovery.
     */
    fun requestBytecodeConditionallyFromPeer(
        peer: BootstrapPeer,
        serviceIdentifier: String,
        interfaceClassName: String?,
        cachedDigest: String?,
        resourcePath: String? = null,
        requestTimeoutMs: Long = DEFAULT_BYTECODE_REQUEST_TIMEOUT_MS,
        connectionTimeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS
    ): BytecodeFetchResult {
        require(serviceIdentifier.isNotBlank()) {
            "Cannot request bytecode from peer '${peer.peerId}' for a blank service identifier."
        }
        require(requestTimeoutMs > 0L) {
            "requestTimeoutMs must be greater than zero, but was $requestTimeoutMs."
        }

        val stream = openStreamToPeer(
            peerId = peer.peerId,
            addresses = peer.multiaddresses,
            serviceIdentifier = BytecodeProtocol.METHOD_BYTECODE_REQUEST,
            resourcePath = resourcePath,
            connectionTimeoutMs = connectionTimeoutMs
        )
        stream.use {
            val request = Libp2pRpcProtocol.RpcRequest(
                id = Libp2pRpcProtocol.nextRequestId(),
                method = BytecodeProtocol.METHOD_BYTECODE_REQUEST,
                params = mapOf(
                    "payload" to BytecodeProtocol.createRequest(
                        serviceIdentifier,
                        interfaceClassName,
                        cachedDigest
                    )
                )
            )
            val response = try {
                it.sendRequestWithinResponseBudget(request, requestTimeoutMs, clock)
            } catch (failure: Exception) {
                val linkDiagnostics = try {
                    (it as? RootLinkDiagnosticSource)?.rootLinkDiagnostics
                        ?.takeIf { snapshot ->
                            snapshot.initiatedBy != "not observed" ||
                                snapshot.remoteReportedReason != "not received"
                        }
                } catch (diagnosticFailure: Throwable) {
                    if (diagnosticFailure !== failure) failure.addSuppressed(diagnosticFailure)
                    null
                }
                throw UrlProtocolException(
                    "Bytecode request for service '$serviceIdentifier' to peer '${peer.peerId}' at " +
                        "addresses ${peer.multiaddresses} failed: ${failure.message}" +
                        linkDiagnostics.diagnosticSuffix(),
                    failure
                )
            }
            response.error?.let { error ->
                if (error.code == Libp2pRpcProtocol.ERROR_TIMEOUT) {
                    val linkDiagnostics = (error.data as? RpcTransportFailure)?.rootLinkDiagnostics
                    throw UrlProtocolException(
                        "Timed out after $requestTimeoutMs ms while requesting bytecode for service " +
                            "'$serviceIdentifier' from peer '${peer.peerId}' at addresses " +
                            "${peer.multiaddresses}" + (linkDiagnostics?.diagnosticSuffix() ?: "."),
                        (error.data as? RpcTransportFailure)?.cause,
                    )
                }
                val linkDiagnostics = (error.data as? RpcTransportFailure)?.rootLinkDiagnostics
                    ?: (stream as? RootLinkDiagnosticSource)?.rootLinkDiagnostics
                        ?.takeIf { snapshot -> snapshot.remoteReportedReason != "not received" }
                throw UrlProtocolException(
                    "Bytecode request for service '$serviceIdentifier' to peer '${peer.peerId}' at " +
                        "addresses ${peer.multiaddresses} failed: ${error.code} - ${error.message}" +
                        linkDiagnostics.diagnosticSuffix(),
                    (error.data as? RpcTransportFailure)?.cause,
                )
            }
            val responseResult = response.result
                ?: throw UrlProtocolException(
                    "Bytecode request for service '$serviceIdentifier' to peer '${peer.peerId}' at " +
                        "addresses ${peer.multiaddresses} returned an empty result."
                )
            val parsed = try {
                BytecodeProtocol.parseConditionalResponseFromResult(responseResult)
            } catch (failure: Exception) {
                throw UrlProtocolException(
                    "Invalid bytecode response for service '$serviceIdentifier' from peer " +
                        "'${peer.peerId}' at addresses ${peer.multiaddresses}: ${failure.message}",
                    failure
                )
            }
            if (parsed is BytecodeFetchResult.NotModified) {
                if (cachedDigest == null) {
                    throw UrlProtocolException(
                        "Peer '${peer.peerId}' answered an unconditional bytecode request for " +
                            "service '$serviceIdentifier' with a not-modified response " +
                            "(digest ${parsed.digest})."
                    )
                }
                if (parsed.digest == null || !CANONICAL_BYTECODE_DIGEST.matches(parsed.digest)) {
                    throw UrlProtocolException(
                        "Malformed not-modified bytecode response for service '$serviceIdentifier' " +
                            "from peer '${peer.peerId}': echoed digest '${parsed.digest}' is not a " +
                            "canonical sha256 digest."
                    )
                }
                if (parsed.digest != cachedDigest) {
                    throw UrlProtocolException(
                        "Malformed not-modified bytecode response for service '$serviceIdentifier' " +
                            "from peer '${peer.peerId}': echoed digest '${parsed.digest}' does not " +
                            "equal submitted cachedDigest '$cachedDigest'."
                    )
                }
            }
            return parsed
        }
    }

    /**
     * Requests implementation bytecode from a service for sandboxed execution.
     *
     * @param url The url:// protocol URL identifying the service
     * @param interfaceClassName Optional fully qualified interface class name hint
     * @return The bytecode response containing JAR bytes and implementation class name
     */
    fun requestBytecodeFromService(url: String, interfaceClassName: String? = null): BytecodeResponse {
        val result = requestBytecodeConditionallyFromService(
            url = url,
            interfaceClassName = interfaceClassName,
            cachedDigest = null
        )
        return when (result) {
            is BytecodeFetchResult.Downloaded -> result.response
            is BytecodeFetchResult.NotModified -> throw UrlProtocolException(
                "Service at '$url' answered an unconditional bytecode request with a " +
                    "not-modified response (digest ${result.digest})."
            )
        }
    }

    /**
     * Fetches service implementation bytecode, optionally sending [cachedDigest] as an ETag-style
     * validator. A matching serving peer returns [BytecodeFetchResult.NotModified] without JAR
     * bytes; a missing or different digest returns [BytecodeFetchResult.Downloaded].
     */
    fun requestBytecodeConditionallyFromService(
        url: String,
        interfaceClassName: String? = null,
        connectionTimeoutMs: Long = DEFAULT_CONNECTION_TIMEOUT_MS,
        cachedDigest: String? = null
    ): BytecodeFetchResult {
        require(connectionTimeoutMs > 0L) {
            "connectionTimeoutMs must be greater than zero, but was $connectionTimeoutMs."
        }
        val parsedUrl = parseUrl(url)
        val router = findAuthorizedRouterForService(parsedUrl.serviceIdentifier, failOnRejected = true)
            ?: throw UrlProtocolException(
                "No peer found for service '${parsedUrl.serviceIdentifier}' while requesting bytecode. " +
                    "Known peers: ${_peerRegistry.size}, none advertise this service."
            )

        val stream = try {
            connectToPeer(
                peer = router,
                serviceIdentifier = parsedUrl.serviceIdentifier,
                headers = emptyMap(),
                timeoutMs = connectionTimeoutMs
            )
        } catch (failure: Exception) {
            throw UrlProtocolException(
                "Failed to connect to peer '${router.peerId}' for bytecode request to " +
                    "'${parsedUrl.serviceIdentifier}': ${failure.message}",
                failure
            )
        }

        stream.use {
            val request = Libp2pRpcProtocol.RpcRequest(
                id = Libp2pRpcProtocol.nextRequestId(),
                method = BytecodeProtocol.METHOD_BYTECODE_REQUEST,
                params = mapOf(
                    "payload" to BytecodeProtocol.createRequest(
                        parsedUrl.serviceIdentifier,
                        interfaceClassName,
                        cachedDigest
                    )
                )
            )
            val response = try {
                it.sendRequest(request)
            } catch (failure: Exception) {
                val linkDiagnostics = (it as? RootLinkDiagnosticSource)?.rootLinkDiagnostics
                    ?.takeIf { snapshot ->
                        snapshot.initiatedBy != "not observed" ||
                            snapshot.remoteReportedReason != "not received"
                    }
                throw UrlProtocolException(
                    "Bytecode request to service '${parsedUrl.serviceIdentifier}' on peer " +
                        "'${router.peerId}' failed: ${failure.message}" +
                        linkDiagnostics.diagnosticSuffix(),
                    failure
                )
            }
            response.error?.let { error ->
                val linkDiagnostics = (error.data as? RpcTransportFailure)?.rootLinkDiagnostics
                    ?: (stream as? RootLinkDiagnosticSource)?.rootLinkDiagnostics
                        ?.takeIf { snapshot -> snapshot.remoteReportedReason != "not received" }
                throw UrlProtocolException(
                    "Bytecode request to service '${parsedUrl.serviceIdentifier}' failed: " +
                        "${error.code} - ${error.message}" + linkDiagnostics.diagnosticSuffix(),
                    (error.data as? RpcTransportFailure)?.cause,
                )
            }
            val result = response.result
                ?: throw UrlProtocolException(
                    "Bytecode request to service '${parsedUrl.serviceIdentifier}' returned an empty result."
                )
            return try {
                val parsed = BytecodeProtocol.parseConditionalResponseFromResult(result)
                if (parsed is BytecodeFetchResult.NotModified) {
                    if (cachedDigest == null) {
                        throw UrlProtocolException(
                            "Malformed not-modified bytecode response from service " +
                            "'${parsedUrl.serviceIdentifier}': no cachedDigest validator was submitted."
                        )
                    }
                    if (parsed.digest == null ||
                        !CANONICAL_BYTECODE_DIGEST.matches(parsed.digest)
                    ) {
                        throw UrlProtocolException(
                            "Malformed not-modified bytecode response from service " +
                                "'${parsedUrl.serviceIdentifier}': echoed digest '${parsed.digest}' " +
                                "is not a canonical sha256 digest."
                        )
                    }
                    if (parsed.digest != cachedDigest) {
                        throw UrlProtocolException(
                            "Malformed not-modified bytecode response from service " +
                                "'${parsedUrl.serviceIdentifier}': echoed digest '${parsed.digest}' " +
                                "does not equal submitted cachedDigest '$cachedDigest'."
                        )
                    }
                }
                parsed
            } catch (failure: Exception) {
                if (failure is UrlProtocolException) throw failure
                throw UrlProtocolException(
                    "Invalid bytecode response from service '${parsedUrl.serviceIdentifier}' on " +
                        "peer '${router.peerId}': ${failure.message}",
                    failure
                )
            }
        }
    }

    /**
     * Closes this protocol once and rejects subsequent service sends.
     * External callers wait for cleanup and every active public service send. A sending caller
     * excludes itself; a sending non-owner waits only for cleanup to avoid cross-waiting.
     * Nested cleanup calls from the owner or a joined relay receive callback return before the
     * cleanup result exists. Other callers observe the same cleanup failure, if any.
     */
    override fun close() {
        val caller = Thread.currentThread()
        val ownsCleanup = synchronized(serviceLifecycle) {
            if (protocolClosed.compareAndSet(false, true)) {
                closeOwner = caller
                serviceLifecycle.notifyAll()
                true
            } else false
        }
        val retiringRelays = synchronized(serviceLifecycle) { retiringRelayServices.keys.toList() }
        val calledFromRetiringRelayCallback = retiringRelays.any { it.isReceiveCallbackWorker(caller) }
        val calledFromOwnedCleanup = calledFromRetiringRelayCallback || synchronized(serviceLifecycle) {
            ownedResourceCleanups.containsKey(caller)
        }
        if (!ownsCleanup) {
            val calledFromReceiveCallbackWorker = relayService?.isReceiveCallbackWorker(caller) == true
            val waitMode = synchronized(serviceLifecycle) {
                when {
                    closeOwner === caller || calledFromReceiveCallbackWorker || calledFromOwnedCleanup ->
                        ProtocolCloseWaitMode.NONE
                    activeServiceSends.containsKey(caller) -> ProtocolCloseWaitMode.CLEANUP
                    else -> ProtocolCloseWaitMode.FULL_DRAIN
                }
            }
            // Cleanup may re-enter on its owner or a relay callback that it is joining.
            // Neither can wait for that cleanup to finish before returning to it.
            if (waitMode == ProtocolCloseWaitMode.NONE && closeFinished.count != 0L) return
            awaitProtocolClose(waitMode == ProtocolCloseWaitMode.FULL_DRAIN)
            closeResult.throwIfFailed()
            return
        }
        try {
            runProtocolCleanup(listOf(
                { relayDiscovery?.close() },
                { relayService?.close() },
                { lanPeerDiscovery?.stop()?.get(5, TimeUnit.SECONDS); Unit },
                {
                    val streams = synchronized(serviceLifecycle) {
                        ownedStreams.keys.toList().also {
                            ownedStreams.clear()
                            activeStreams.clear()
                        }
                    }
                    runProtocolCleanup(streams.map { stream -> { stream.closeForProtocol() } }, closeResult)
                },
                { gossipInboundRegistration?.close(); Unit },
                { network.close() }
            ), closeResult)
        } finally {
            relayDiscovery = null
            relayService = null
            relayStarted.set(false)
            lanPeerDiscovery = null
            gossipInboundRegistration = null
            gossipMessageTracker = null
            networkListenInfo = null
            // A registered closer can still be sending after its own close returns. Publish
            // cleanup before draining so another registered closer can leave its send.
            synchronized(serviceLifecycle) {
                closeOwner = null
            }
            closeFinished.countDown()
            // An owned stream's close callback must return to finish that cleanup. Ordinary
            // external closers join the registered cleanup caller as well as active sends.
            awaitProtocolClose(drainSends = !calledFromOwnedCleanup)
        }
        closeResult.throwIfFailed()
    }

    private fun awaitProtocolClose(drainSends: Boolean) {
        var interrupted = false
        while (true) {
            try {
                closeFinished.await()
                break
            } catch (_: InterruptedException) {
                interrupted = true
            }
        }
        if (drainSends) {
            val caller = Thread.currentThread()
            synchronized(serviceLifecycle) {
                while (activeServiceSends.keys.any { it !== caller } ||
                    ownedResourceCleanups.keys.any { it !== caller }) {
                    try {
                        serviceLifecycle.wait()
                    } catch (_: InterruptedException) {
                        interrupted = true
                    }
                }
            }
        }
        if (interrupted) Thread.currentThread().interrupt()
    }

    // =========================================================================
    // RELAY PROTOCOL SUPPORT
    // =========================================================================

    /**
     * Starts the relay service if not already started.
     *
     * If relay is enabled in the config:
     * - Publicly routable nodes announce themselves as relays and accept relay registrations
     * - NAT-ed nodes discover and register with available relays
     *
     * This is called automatically when needed, but can be called explicitly
     * to start the relay service early.
     */
    fun startRelayService() {
        if (!relayConfig.enableRelay) {
            return
        }
        withStartupTurn(relayStartToken) {
            if (relayStarted.get()) return@withStartupTurn
            val libp2pNetwork = network as? Libp2pNetworkProvider
                ?: throw incompatibleNetworkProvider("RelayConfig(enableRelay=true)")
            val host = try {
                libp2pNetwork.requireLibp2pHost()
            } catch (failure: Throwable) {
                if (protocolClosed.get()) {
                    throw ProtocolClosedOpenException(failure)
                }
                throw failure
            }
            val service = RelayService(host, _peerRegistry, relayConfig, this)
            val discovery = RelayDiscovery(service, _peerRegistry, relayConfig)
            var adopted = false
            try {
                // Adopt before starting workers. Close either owns these resources or prevents
                // adoption; getters wait for this startup turn before exposing the service.
                synchronized(serviceLifecycle) {
                    ensureStreamOpen()
                    relayService = service
                    relayDiscovery = discovery
                    adopted = true
                }
                service.start()
                val dispatchPending = synchronized(serviceLifecycle) {
                    ensureStreamOpen()
                    libp2pNetwork.deferredRelayHandler.publishRelayService(service)
                }
                dispatchPending()
                // Set up alternative relay selector for failover
                // When the current relay fails repeatedly, RelayService will call this to find an alternative
                service.setAlternativeRelaySelector {
                    val currentRelay = service.currentRelayPeerId
                    // Find a different relay than the current one
                    val allRelays = discovery.getPubliclyReachableRelays()
                    val alternativeRelays = allRelays.filter { it.peerId != currentRelay }
                    if (alternativeRelays.isNotEmpty()) {
                        val selected = alternativeRelays.minByOrNull { it.latencyMs ?: Long.MAX_VALUE }
                            ?: alternativeRelays.first()
                        PeerInfo(
                            peerId = selected.peerId,
                            multiaddresses = selected.multiaddresses,
                            advertisedServices = emptyList()
                        )
                    } else if (allRelays.isNotEmpty()) {
                        // If no alternative available, return the current best (might be same relay but maybe it recovered)
                        val selected = allRelays.minByOrNull { it.latencyMs ?: Long.MAX_VALUE }
                            ?: allRelays.first()
                        PeerInfo(
                            peerId = selected.peerId,
                            multiaddresses = selected.multiaddresses,
                            advertisedServices = emptyList()
                        )
                    } else {
                        null
                    }
                }

                // All nodes announce as relay and participate in gossip.
                // There is no standalone relay - every node acts as a relay by default.
                // Even NAT-ed nodes can relay traffic for peers they are connected to.
                service.announceAsRelay()

                // Also try to register with a relay peer for NAT traversal.
                // This is important for NAT-ed nodes to be reachable.
                val relay = discovery.selectBestRelay()
                if (relay != null) {
                    try {
                        service.registerWithRelay(relay.peerId, emptyList()) { request ->
                            // Default handler - just acknowledge the request
                            RelayProtocol.RelayResponse(
                                requestId = request.requestId,
                                sourcePeerId = request.targetPeerId,  // We are the target responding
                                targetPeerId = request.sourcePeerId,  // Response goes back to requester
                                payload = "",  // Empty Base64-encoded payload
                                success = true
                            )
                        }
                    } catch (e: Exception) {
                        // Relay registration failed - will be retried by reconnection task
                    }
                }
                synchronized(serviceLifecycle) {
                    ensureStreamOpen()
                    relayStarted.set(true)
                }
            } catch (failure: Throwable) {
                val releaseHere = synchronized(serviceLifecycle) {
                    if (!adopted) true
                    else if (!protocolClosed.get()) {
                        retiringRelayServices[service] = true
                        if (relayService === service) relayService = null
                        if (relayDiscovery === discovery) relayDiscovery = null
                        val caller = Thread.currentThread()
                        ownedResourceCleanups[caller] = (ownedResourceCleanups[caller] ?: 0) + 1
                        true
                    } else false // The one protocol cleanup owner already owns both resources.
                }
                if (releaseHere) {
                    val result = ProtocolCleanupResult()
                    var cleanupFailure: Throwable? = null
                    try {
                        runProtocolCleanup(listOf({ discovery.close() }, { service.close() }), result)
                        result.throwIfFailed()
                    } catch (cause: Throwable) {
                        cleanupFailure = cause
                        if (cause !== failure) failure.addSuppressed(cause)
                    } finally {
                        if (adopted) synchronized(serviceLifecycle) {
                            retiringRelayServices.remove(service)
                            if (protocolClosed.get()) cleanupFailure?.let(closeResult::record)
                            val caller = Thread.currentThread()
                            val remaining = checkNotNull(ownedResourceCleanups[caller]) - 1
                            if (remaining == 0) ownedResourceCleanups.remove(caller)
                            else ownedResourceCleanups[caller] = remaining
                            serviceLifecycle.notifyAll()
                        }
                    }
                }
                if (protocolClosed.get()) {
                    throw ProtocolClosedOpenException(failure)
                }
                throw failure
            }
        }
    }

    /**
     * Gets the relay service, creating it if necessary.
     *
     * @return The relay service, or null if relay is disabled.
     */
    fun getRelayService(): RelayService? {
        if (!relayConfig.enableRelay) return null
        startRelayService()
        return synchronized(serviceLifecycle) { ensureStreamOpen(); relayService }
    }

    /**
     * Gets the relay discovery service.
     *
     * @return The relay discovery service, or null if relay is disabled.
     */
    fun getRelayDiscovery(): RelayDiscovery? {
        if (!relayConfig.enableRelay) return null
        startRelayService()
        return synchronized(serviceLifecycle) { ensureStreamOpen(); relayDiscovery }
    }

    /**
     * Checks if a multiaddress is publicly routable (not a private/local address).
     */
    private fun isPubliclyRoutable(addrStr: String): Boolean {
        // Check for obviously non-routable addresses
        if (addrStr.contains("/ip4/127.") ||
            addrStr.contains("/ip4/0.0.0.0") ||
            addrStr.contains("/ip4/10.") ||
            addrStr.contains("/ip4/192.168.") ||
            addrStr.contains("/ip6/::1") ||
            addrStr.contains("/ip6/::/")) {
            return false
        }
        // Check for 172.16.0.0 - 172.31.255.255 range
        val ip4Match = Regex("/ip4/(172\\.(\\d+)\\.)").find(addrStr)
        if (ip4Match != null) {
            val secondOctet = ip4Match.groupValues[2].toIntOrNull() ?: 0
            if (secondOctet in 16..31) return false
        }
        // If it has a dns/dnsaddr, it's likely routable
        if (addrStr.contains("/dns") || addrStr.contains("/dnsaddr")) {
            return true
        }
        // If it has an IP address, it might be routable
        return addrStr.contains("/ip4/") || addrStr.contains("/ip6/")
    }

    // =========================================================================
    // GOSSIP HANDLER IMPLEMENTATION
    // =========================================================================

    private fun handleInboundGossipStream(stream: RpcStream) {
        stream.use {
            val message = try {
                it.input.readGossipMessage()
            } catch (failure: Exception) {
                onAuthenticatedInteraction(it.remotePeerId, PeerInteractionSeverity.SEVERE)
                return
            }
            onAuthenticatedInteraction(
                it.remotePeerId,
                authenticatedInteractionSeverity(message)
            )
            when (message) {
                is GossipProtocol.ServiceAnnouncement -> {
                    if (gossipMessageTracker?.recordMessage(message.messageId) != false) {
                        onServiceAnnouncement(message)
                        if (message.shouldPropagate()) {
                            broadcastGossipMessageExcluding(
                                message.withDecrementedTtl().toJson(),
                                excludedPeerId = it.remotePeerId
                            )
                        }
                    }
                }
                is GossipProtocol.ServiceWithdrawal -> {
                    if (gossipMessageTracker?.recordMessage(message.messageId) != false) {
                        onServiceWithdrawal(message)
                        if (message.shouldPropagate()) {
                            broadcastGossipMessageExcluding(
                                message.withDecrementedTtl().toJson(),
                                excludedPeerId = it.remotePeerId
                            )
                        }
                    }
                }
                is GossipProtocol.PeerAnnouncement -> {
                    if (gossipMessageTracker?.recordMessage(message.messageId) != false) {
                        onPeerAnnouncement(message)
                        if (message.shouldPropagate()) {
                            broadcastGossipMessageExcluding(
                                message.withDecrementedTtl().toJson(),
                                excludedPeerId = it.remotePeerId
                            )
                        }
                    }
                }
                is GossipProtocol.TldResolverAnnouncement -> {
                    if (gossipMessageTracker?.recordMessage(message.messageId) != false) {
                        onTldResolverAnnouncement(message)
                        if (message.shouldPropagate()) {
                            broadcastGossipMessageExcluding(
                                message.withDecrementedTtl().toJson(),
                                excludedPeerId = it.remotePeerId
                            )
                        }
                    }
                }
                is GossipProtocol.ServiceQuery -> {
                    Libp2pRpcProtocol.writeMessage(
                        it.output,
                        GossipProtocol.ServiceQueryResponse(message.id, onServiceQuery(message)).toJson()
                    )
                }
                is GossipProtocol.PeerExchange -> {
                    if (message.isRequest) {
                        onPeersReceived(message.peers, it.remotePeerId)
                        Libp2pRpcProtocol.writeMessage(
                            it.output,
                            GossipProtocol.PeerExchange(
                                id = message.id,
                                peers = onPeerExchangeRequest(),
                                isRequest = false
                            ).toJson()
                        )
                    } else {
                        onPeersReceived(message.peers, it.remotePeerId)
                    }
                }
                is RelayProtocol.RelayAnnouncement -> onRelayAnnouncement(message)
                is RelayProtocol.RelayWithdrawal -> onRelayWithdrawal(message)
                is LinkStateAdvertisement -> onLinkStateAdvertisement(message)
                is GossipProtocol.ServiceQueryResponse -> Unit
                else -> throw IllegalArgumentException("Unsupported inbound gossip message: $message.")
            }
        }
    }

    private fun broadcastGossipMessageExcluding(
        message: org.json.JSONObject,
        excludedPeerId: String?
    ): Int {
        // This best-effort count records only a successful local stream handoff. The peer has no
        // remote-parse acknowledgement here, so closing the stream immediately after write can
        // still lose a one-way frame; later gossip or peer exchange repairs that state.
        startNetwork()
        val localPeerId = networkListenInfo?.peerId
        var delivered = 0
        // Peers whose every address failed to dial with a non-admission exception. The failure is
        // deferred rather than recorded inline because a single dial timeout cannot distinguish a
        // remote peer that is gone from the local host being unable to complete the dial (e.g. CPU
        // starvation). That distinction can only be made across the whole fan-out — see below.
        val dialFailedPeerIds = mutableListOf<String>()
        var attemptedPeers = 0
        _peerRegistry.rankPeersForAllocation()
            .asSequence()
            .filter { it.peerId != localPeerId && it.peerId != excludedPeerId }
            .distinctBy { it.peerId }
            .forEach { peer ->
                val addresses = peer.multiaddresses.filter { it.isNotBlank() }.sorted()
                var deliveredToPeer = false
                var peerDialFailed = false
                for (address in addresses) {
                    try {
                        network.dial(peer.peerId, address, GossipProtocol.PROTOCOL_ID).use { stream ->
                            Libp2pRpcProtocol.writeMessage(stream.output, message)
                        }
                        delivered += 1
                        deliveredToPeer = true
                        break
                    } catch (failure: Exception) {
                        if (failure !is OutboundDialAdmissionException) {
                            peerDialFailed = true
                        }
                        // Gossip fan-out is best effort; another address or a later reannouncement
                        // may repair this peer without blocking healthy recipients.
                    }
                }
                // Fan-out is the highest-volume dialer in the process, which makes it the place
                // where an unreachable peer is discovered first. Feeding the outcome back into the
                // registry is what lets a departed host be evicted instead of being re-dialed on
                // every subsequent message.
                if (deliveredToPeer) {
                    // Reaching a peer is unambiguous positive evidence, so it is applied inline and
                    // also proves the local host's dial path is working this pass.
                    _peerRegistry.recordDialSuccess(peer.peerId)
                    attemptedPeers++
                } else if (peerDialFailed) {
                    dialFailedPeerIds.add(peer.peerId)
                    attemptedPeers++
                }
                // A peer whose only failures were admission rejections (OutboundDialAdmission is
                // saturated) is not counted as attempted: nothing was learned about its
                // reachability, and its failure is never recorded.
            }
        // A dial timeout is ambiguous between "the remote peer is gone" and "the local host could
        // not finish the dial". When the fan-out reached NONE of the peers it attempted, the common
        // cause is the local host, not the simultaneous departure of every peer — so recording a
        // per-peer failure for each would wrongly evict and quarantine healthy service providers
        // (the load-correlated "No peer found for a still-registered service" failure). Only record
        // the deferred failures when the local host demonstrably dialed at least one peer this pass,
        // which makes an isolated failure attributable to that specific peer. A departed peer amid
        // reachable peers is still evicted; a starved host that reaches no one evicts nobody.
        val localDialPathIsHealthy = delivered > 0
        if (localDialPathIsHealthy) {
            dialFailedPeerIds.forEach { _peerRegistry.recordDialFailure(it) }
        } else if (dialFailedPeerIds.isNotEmpty()) {
            debugLog {
                "[GOSSIP-FANOUT] Local peer '$localPeerId' reached 0 of $attemptedPeers attempted " +
                    "peers this fan-out; treating ${dialFailedPeerIds.size} dial failures as a local " +
                    "send fault and NOT recording them as per-peer dial failures (would otherwise " +
                    "evict healthy service providers under local starvation)."
            }
        }
        return delivered
    }

    override fun onServiceAnnouncement(announcement: GossipProtocol.ServiceAnnouncement) {
        val decision = nameResolutionConfig.resolver.resolve(announcement.serviceIdentifier)
        if (!decision.accepts(announcement.providerPeerId)) {
            return
        }
        // Add the service provider to our peer registry
        val peer = Libp2pPeer.remote(
            peerId = announcement.providerPeerId,
            multiaddresses = announcement.providerMultiaddresses,
            advertisedServices = listOf(announcement.serviceIdentifier)
        )
        _peerRegistry.addImportedPeer(peer, null, 0L, origin = PeerRegistryAddOrigin.CATALOG)
        activeServiceQueryExpiries.remove(
            activeServiceKey(announcement.serviceIdentifier, announcement.providerPeerId)
        )
        // NOTE: We intentionally do NOT call recordSuccess() here for gossip-announced
        // service providers. A ServiceAnnouncement may be a multi-hop re-broadcast
        // (TTL-based), so the provider peer may not have directly connected to us.
        // Calling recordSuccess() would incorrectly mark the peer as "verified online",
        // causing it to be shared via onPeerExchangeRequest() even if the peer is
        // actually offline. Direct peer contact is recorded separately via
        // onDirectPeerContact in Libp2pHostFactory.
    }

    override fun onServiceWithdrawal(withdrawal: GossipProtocol.ServiceWithdrawal) {
        activeServiceQueryExpiries.remove(
            activeServiceKey(withdrawal.serviceIdentifier, withdrawal.providerPeerId)
        )
        // Remove the withdrawn service from the peer's service list
        val existingPeer = _peerRegistry.getPeer(withdrawal.providerPeerId) ?: return

        val updatedServices = existingPeer.advertisedServices.filter {
            it != withdrawal.serviceIdentifier
        }

        // If the peer has no more services, we could remove it entirely,
        // but we keep it so it can still be used for routing
        val updatedPeer = Libp2pPeer.remote(
            peerId = existingPeer.peerId,
            multiaddresses = existingPeer.multiaddresses,
            advertisedServices = updatedServices,
            lastSeenTimestamp = existingPeer.lastSeenTimestamp
        )

        _peerRegistry.addPeer(
            updatedPeer,
            origin = PeerRegistryAddOrigin.CATALOG,
            replaceServices = true
        )
    }

    override fun onServiceQuery(query: GossipProtocol.ServiceQuery): List<ServiceInfo> {
        val observationLog = _peerRegistry.getObservationLog()
        return knownServiceInfos(query.servicePattern)
            .filter { service ->
                val snapshot = observationLog.getSnapshot(service.providerPeerId)
                snapshot != null &&
                    snapshot.lastSuccessMs > 0 &&
                    snapshot.lastFailMs <= snapshot.lastSuccessMs
            }
            .take(query.maxResults)
    }

    private fun knownServiceInfos(pattern: String): List<ServiceInfo> {
        return _peerRegistry.getAllPeers()
            .flatMap { peer ->
                peer.advertisedServices
                    .asSequence()
                    .filter { matchesServicePattern(it, pattern) }
                    .filter { nameResolutionConfig.resolver.resolve(it).accepts(peer.peerId) }
                    .map { serviceIdentifier ->
                        ServiceInfo(
                            serviceUrl = "url://$serviceIdentifier/",
                            serviceIdentifier = serviceIdentifier,
                            providerPeerId = peer.peerId,
                            providerMultiaddresses = peer.multiaddresses,
                            stunAddresses = emptyList(),
                            turnServers = emptyList(),
                            freshness = bestPeerFreshnessForExport(
                                networkListenInfo?.peerId?.let {
                                    _peerRegistry.getObservationLog().getSourceFreshness(peer.peerId, it)
                                },
                                _peerRegistry.getImportedPeerFreshness(peer.peerId)
                            )
                        )
                    }
                    .toList()
            }
            .distinctBy { "${it.serviceIdentifier}|${it.providerPeerId}" }
    }

    private fun matchesServicePattern(serviceIdentifier: String, pattern: String): Boolean {
        val normalizedService = serviceIdentifier.trimEnd('.')
        val normalizedPattern = pattern.trimEnd('.')
        if (normalizedService.isEmpty() || normalizedPattern.isEmpty()) return false
        return normalizedService == normalizedPattern ||
            normalizedService.startsWith("$normalizedPattern.") ||
            normalizedPattern.startsWith("$normalizedService.")
    }

    private fun activeServiceKey(serviceIdentifier: String, providerPeerId: String): String =
        "$serviceIdentifier|$providerPeerId"

    private fun pruneExpiredActiveServiceResults() {
        val now = clock.currentTimeMillis()
        val expired = activeServiceQueryExpiries.entries
            .filter { it.value <= now && activeServiceQueryExpiries.remove(it.key, it.value) }
            .map { it.key }
        expired.forEach { key ->
            val separator = key.lastIndexOf('|')
            if (separator <= 0) return@forEach
            val serviceIdentifier = key.substring(0, separator)
            val peerId = key.substring(separator + 1)
            val peer = _peerRegistry.getPeer(peerId) ?: return@forEach
            _peerRegistry.addPeer(
                Libp2pPeer.remote(
                    peerId = peer.peerId,
                    multiaddresses = peer.multiaddresses,
                    advertisedServices = peer.advertisedServices - serviceIdentifier,
                    lastSeenTimestamp = peer.lastSeenTimestamp
                ),
                origin = PeerRegistryAddOrigin.CATALOG,
                replaceServices = true
            )
        }
    }

    override fun onPeerExchangeRequest(): List<PeerInfo> {
        val observationLog = _peerRegistry.getObservationLog()
        val shareablePeers = _peerRegistry.getAllPeers()
            .filter { peer ->
                // Local success or still-usable independent source evidence permits sharing.
                // A local negative route check does not cancel the other observer's first expiry.
                val snapshot = observationLog.getSnapshot(peer.peerId)
                (snapshot != null && snapshot.lastSuccessMs > 0 && snapshot.lastFailMs <= snapshot.lastSuccessMs) ||
                    (_peerRegistry.getImportedPeerFreshness(peer.peerId)?.remainingLifetimeMillis ?: 0L) > 0L
            }
        return _peerRegistry.rankPeersForBootstrap(shareablePeers)
            .mapNotNull { peer ->
                val authorizedServices = peer.advertisedServices.filter { service ->
                    nameResolutionConfig.resolver.resolve(service).accepts(peer.peerId)
                }
                if (peer.advertisedServices.isNotEmpty() && authorizedServices.isEmpty()) {
                    return@mapNotNull null
                }
                val localFreshness = networkListenInfo?.peerId?.let { observerPeerId ->
                    observationLog.getSourceFreshness(peer.peerId, observerPeerId)
                }
                val importedFreshness = _peerRegistry.getImportedPeerFreshness(peer.peerId)
                val freshness = bestPeerFreshnessForExport(localFreshness, importedFreshness)
                PeerInfo(
                    peerId = peer.peerId,
                    multiaddresses = peer.multiaddresses,
                    advertisedServices = authorizedServices,
                    freshness = freshness
                )
            }
    }

    override fun onPeersReceived(peers: List<PeerInfo>) {
        ingestReceivedPeers(peers, recommenderPeerId = null)
    }

    override fun onPeersReceived(peers: List<PeerInfo>, recommenderPeerId: String) {
        ingestReceivedPeers(peers, recommenderPeerId)
    }

    /** Receives a response sampled for this exchange, consuming its full locally measured duration. */
    fun onPeerExchangeResponse(peers: List<PeerInfo>, exchangeElapsedMillis: Long) {
        require(exchangeElapsedMillis >= 0L) {
            "exchangeElapsedMillis must be non-negative, but was $exchangeElapsedMillis"
        }
        val receivedAtTimeSample = samplePeerFreshnessTime(clock)
        ingestReceivedPeers(peers, recommenderPeerId = null, exchangeElapsedMillis = exchangeElapsedMillis,
            receivedAtTimeSample = receivedAtTimeSample)
    }

    private fun ingestReceivedPeers(
        peers: List<PeerInfo>,
        recommenderPeerId: String?,
        exchangeElapsedMillis: Long? = null,
        receivedAtTimeSample: PeerFreshnessTimeSample = samplePeerFreshnessTime(clock)
    ) {
        val observationLog = _peerRegistry.getObservationLog()
        val introducerScore = recommenderPeerId?.let { peerId ->
            val snapshots = observationLog.getAllSnapshots()
            snapshots[peerId]?.let { snapshot ->
                PeerScorer(clock).scoreComponents(snapshot, snapshots).ostracismScore
            }
        } ?: 0.0
        for (peerInfo in peers) {
            val wasNovel = _peerRegistry.getPeer(peerInfo.peerId) == null
            val authorizedServices = peerInfo.advertisedServices.filter { service ->
                nameResolutionConfig.resolver.resolve(service).accepts(peerInfo.peerId)
            }
            val peer = Libp2pPeer.remote(
                peerId = peerInfo.peerId,
                multiaddresses = peerInfo.multiaddresses,
                advertisedServices = authorizedServices
            )
            _peerRegistry.addImportedPeer(peer,
                freshness = if (exchangeElapsedMillis != null) peerInfo.freshness else null,
                exchangeElapsedMillis = exchangeElapsedMillis ?: 0L,
                origin = PeerRegistryAddOrigin.DISCOVERY,
                receivedAtElapsedMillis = receivedAtTimeSample.nowMillis,
                receivedAtTimeSample = receivedAtTimeSample)
            if (_peerRegistry.getPeer(peerInfo.peerId) != null) {
            if (recommenderPeerId != null && peerInfo.peerId != recommenderPeerId) {
                observationLog.recordRecommendation(
                    recommenderPeerId = recommenderPeerId,
                    recommendedPeerId = peerInfo.peerId,
                    wasNovel = wasNovel
                )
                if (wasNovel) {
                    observationLog.observeVouchedPeer(peerInfo.peerId, introducerScore)
                }
            }
            }
        }
    }

    override fun onAuthenticatedInteraction(
        peerId: String,
        severity: PeerInteractionSeverity
    ) {
        _peerRegistry.getObservationLog().recordAuthenticatedInteraction(peerId, severity)
    }

    override fun authenticatedInteractionSeverity(message: Any): PeerInteractionSeverity {
        val ttl = when (message) {
            is GossipProtocol.ServiceAnnouncement -> message.ttl
            is GossipProtocol.ServiceWithdrawal -> message.ttl
            is GossipProtocol.PeerAnnouncement -> message.ttl
            is GossipProtocol.TldResolverAnnouncement -> message.ttl
            else -> null
        }
        if (ttl != null && ttl > GossipProtocol.DEFAULT_TTL) {
            return PeerInteractionSeverity.SEVERE
        }
        if (
            message is GossipProtocol.TldResolverAnnouncement &&
            !message.descriptor.verifiesWith(nameResolutionConfig.rootPublicKey)
        ) {
            return PeerInteractionSeverity.SEVERE
        }
        return PeerInteractionSeverity.CLEAN
    }

    override fun onPeerAnnouncement(announcement: GossipProtocol.PeerAnnouncement) {
        val authorizedServices = announcement.advertisedServices.filter { service ->
            nameResolutionConfig.resolver.resolve(service).accepts(announcement.peerId)
        }
        // Add the peer to registry
        val peer = Libp2pPeer.remote(
            peerId = announcement.peerId,
            multiaddresses = announcement.multiaddresses,
            advertisedServices = authorizedServices
        )
        _peerRegistry.addImportedPeer(peer, null, 0L, origin = PeerRegistryAddOrigin.CATALOG)
        // NOTE: We intentionally do NOT call recordSuccess() here for gossip-announced
        // peers. A PeerAnnouncement may be a multi-hop re-broadcast (TTL-based), so the
        // announced peer may not have directly connected to us. Calling recordSuccess()
        // would incorrectly mark the peer as "verified online", causing it to be shared
        // via onPeerExchangeRequest() even if the peer is actually offline. Direct peer
        // contact is recorded separately via onDirectPeerContact in Libp2pHostFactory.
        // Note: Re-broadcasting is handled by UrlResolver which has access to connected peers
    }

    override fun onTldResolverAnnouncement(announcement: GossipProtocol.TldResolverAnnouncement) {
        nameResolutionConfig.resolver.addTldDescriptor(announcement.descriptor)
    }

    override fun onTldResolverQuery(): List<GossipProtocol.TldResolverAnnouncement> {
        return nameResolutionConfig.resolver.getTldDescriptors()
            .map { GossipProtocol.TldResolverAnnouncement.fromDescriptor(it) }
    }

    override fun onLinkStateAdvertisement(advertisement: LinkStateAdvertisement) {
        relayService?.receiveLinkStateAdvertisement(advertisement)
    }

    override fun broadcastGossipMessage(message: org.json.JSONObject): Int {
        return broadcastGossipMessageExcluding(message, excludedPeerId = null)
    }

    override fun onRelayAnnouncement(announcement: RelayProtocol.RelayAnnouncement) {
        // Forward to relay discovery if available
        relayDiscovery?.onRelayAnnouncement(announcement)

        // Also add the relay peer to our registry
        val peer = Libp2pPeer.remote(
            peerId = announcement.peerId,
            multiaddresses = announcement.multiaddresses,
            advertisedServices = emptyList()
        )
        _peerRegistry.addImportedPeer(peer, null, 0L, origin = PeerRegistryAddOrigin.RELAY)
    }

    override fun onRelayWithdrawal(withdrawal: RelayProtocol.RelayWithdrawal) {
        // Forward to relay discovery if available
        relayDiscovery?.onRelayWithdrawal(withdrawal)
    }

    private fun parseUrl(url: String): ParsedUrl {
        if (!url.startsWith(URL_SCHEME)) {
            throw UrlProtocolException(
                "Invalid URL scheme: URL must start with '$URL_SCHEME', " +
                    "but got '${url.substringBefore("://")}://' in URL: $url"
            )
        }

        val withoutScheme = url.removePrefix(URL_SCHEME)
        val parts = withoutScheme.split("/").filter { it.isNotBlank() }

        if (parts.isEmpty()) {
            throw UrlProtocolException(
                "Invalid URL format: URL must contain a service identifier after the scheme, " +
                    "but got: $url"
            )
        }

        // Strip query parameters and fragments from the service identifier
        // URL format: url://service.identifier?query=param#fragment/resource/path
        val serviceIdentifier = parts[0]
            .substringBefore("?")  // Remove query parameters
            .substringBefore("#")  // Remove fragments

        // The empty-parts check above runs BEFORE query/fragment stripping, so a URL whose
        // first segment is only a query string or fragment (e.g. "url://?q=x" or "url://#f")
        // survives it yet reduces to an empty service identifier here. Reject it the same way
        // as "url:///" instead of forwarding an empty identifier into routing.
        if (serviceIdentifier.isBlank()) {
            throw UrlProtocolException(
                "Invalid URL format: URL must contain a service identifier after the scheme, " +
                    "but got: $url"
            )
        }

        val resourcePath = if (parts.size > 1) parts.subList(1, parts.size).joinToString("/") else ""

        return ParsedUrl(serviceIdentifier, resourcePath)
    }

    private data class ParsedUrl(
        val serviceIdentifier: String,
        val resourcePath: String
    )

    /**
     * Pings a peer using only direct connection (no relay fallback).
     *
     * Attempts to connect to the peer via its known non-circuit multiaddresses
     * and returns the latency if reachable directly. When the direct ping succeeds,
     * the peer is recorded as directly reachable in the peer registry.
     *
     * Relay fallback is NOT handled here — callers that need relay (like UrlProtocol2)
     * manage their own RelayService and handle relay ping independently.
     *
     * @param peerId The base58-encoded peer ID to ping.
     * @param timeoutMs Maximum time to wait for response in milliseconds.
     * @return Latency in milliseconds, or null if peer is unreachable via direct connection.
     */
    fun pingPeerDirect(peerId: String, timeoutMs: Long = 5000): Long? {
        val peer = peerRegistry.getPeer(peerId)
            ?: return null  // Unknown peer

        val directResult = pingDirectSecure(peer, timeoutMs)
        if (directResult != null) {
            _peerRegistry.getObservationLog().recordSuccess(peer.peerId)
            _peerRegistry.recordDirectReachability(peer.peerId)
        }
        return directResult
    }

    /**
     * Attempts to ping a peer directly using secure connection.
     */
    private fun pingDirectSecure(peer: BootstrapPeer, timeoutMs: Long): Long? {
        val addresses = peer.multiaddresses.filter { addr ->
            addr.isNotBlank() &&
            !addr.contains("/ip6/::/") &&
            !addr.contains("/ip4/0.0.0.0/") &&
            !addr.contains("/p2p-circuit/")  // Skip circuit addresses for direct ping
        }

        if (addresses.isEmpty()) {
            return null
        }

        for (multiaddr in addresses) {
            try {
                val startTime = System.currentTimeMillis()
                val stream = network.dial(
                    peer.peerId,
                    multiaddr,
                    Libp2pRpcProtocol.PROTOCOL_ID,
                    timeoutMs
                )
                val latency = System.currentTimeMillis() - startTime
                stream.close()
                return latency
            } catch (e: Exception) {
                // Try next address
            }
        }

        return null
    }

    private fun incompatibleNetworkProvider(feature: String): IllegalStateException {
        val providerType = network.javaClass.name
        return IllegalStateException(
            "$feature requires a Libp2pNetworkProvider, but the supplied network provider is $providerType."
        )
    }

    companion object {
        private const val URL_SCHEME = "url://"
        private const val DEFAULT_CONNECTION_TIMEOUT_MS = 30_000L
        private const val DEFAULT_BYTECODE_REQUEST_TIMEOUT_MS = 30_000L
        private const val DEFAULT_SERVICE_QUERY_MAX_RESULTS = 10
        private const val DEFAULT_SERVICE_QUERY_TIMEOUT_MS = 5_000L
        private const val DEFAULT_SERVICE_QUERY_DIAL_TIMEOUT_MS = 1_000L
        private const val DEFAULT_SERVICE_QUERY_CONCURRENCY = 8
        private const val ACTIVE_SERVICE_QUERY_RESULT_TTL_MS = 5 * 60 * 1000L
        private val CANONICAL_BYTECODE_DIGEST = Regex("^sha256:[0-9a-f]{64}$")

        /**
         * Pattern for matching localhost.tcp:PORT domain format.
         * Matches: localhost.tcp:8080, localhost.tcp:1234, etc.
         */
        private val LOCALHOST_TCP_PATTERN = Pattern.compile("localhost\\.tcp:(\\d+)")

        // ================================================================
        // Default Bootstrap Peers for url:// Network
        // ================================================================

        /**
         * Well-known seed for the ContainerNursery bootstrap node on wasmserver.com.
         * This seed generates a stable, predictable peer ID for the primary bootstrap node.
         */
        const val WASMSERVER_BOOTSTRAP_SEED = "urlprotocol-wasmserver-bootstrap-1"

        /**
         * Default listen port for the ContainerNursery bootstrap node.
         * This matches the port configured in ContainerNursery's persistent storage.
         */
        const val DEFAULT_BOOTSTRAP_PORT = 35000

        /**
         * IP address of the wasmserver.com server.
         */
        const val WASMSERVER_IP = "198.199.106.165"

        /**
         * Well-known seed for the HardwareControlFabric daemon bootstrap node.
         * This seed was generated by the production daemon instance on first startup
         * and persisted to its p2p-identity.json configuration file.
         */
        const val HARDWARE_FABRIC_BOOTSTRAP_SEED = "fabric-daemon-d1f29489-5df4-4ec2-9197-77e0981db7dd"

        /**
         * Default listen port for the HardwareControlFabric daemon bootstrap node.
         * This port was assigned on first startup and persisted to p2p-identity.json.
         */
        const val HARDWARE_FABRIC_BOOTSTRAP_PORT = 44605

        /**
         * Generates the peer ID that corresponds to a given key seed.
         * This allows computing bootstrap peer IDs without starting a host.
         *
         * @param seed The seed string to derive the peer ID from
         * @return The peer ID as a base58 string
         */
        fun peerIdFromSeed(seed: String): String {
            return Libp2pNetworkProvider(enableRelay = false).use { provider ->
                provider.derivePeerId(seed)
            }
        }

        /**
         * Creates a bootstrap peer for the wasmserver.com node.
         * This is the primary bootstrap peer for the url:// network.
         *
         * @param port The port the bootstrap node is listening on (default: 35000)
         * @return A BootstrapPeer for the wasmserver node
         */
        fun createWasmserverBootstrapPeer(port: Int = DEFAULT_BOOTSTRAP_PORT): BootstrapPeer {
            val peerId = peerIdFromSeed(WASMSERVER_BOOTSTRAP_SEED)
            val multiaddr = "/ip4/$WASMSERVER_IP/tcp/$port/p2p/$peerId"
            return Libp2pPeer.remote(
                peerId = peerId,
                multiaddresses = listOf(multiaddr),
                advertisedServices = emptyList(),
                lastSeenTimestamp = System.currentTimeMillis()
            )
        }

        /**
         * Creates a bootstrap peer for the HardwareControlFabric daemon node.
         * This is a secondary bootstrap peer for the url:// network, running on the
         * same server as ContainerNursery but with its own stable peer identity.
         *
         * @param port The port the bootstrap node is listening on (default: 44605)
         * @return A BootstrapPeer for the HardwareControlFabric daemon node
         */
        fun createHardwareFabricBootstrapPeer(port: Int = HARDWARE_FABRIC_BOOTSTRAP_PORT): BootstrapPeer {
            val peerId = peerIdFromSeed(HARDWARE_FABRIC_BOOTSTRAP_SEED)
            val multiaddr = "/ip4/$WASMSERVER_IP/tcp/$port/p2p/$peerId"
            return Libp2pPeer.remote(
                peerId = peerId,
                multiaddresses = listOf(multiaddr),
                advertisedServices = listOf("hardware.control.fabric.daemon"),
                lastSeenTimestamp = System.currentTimeMillis()
            )
        }

        /**
         * Default bootstrap peers for the url:// network.
         * These peers are used when no custom bootstrap peers are provided.
         *
         * Currently includes:
         * - ContainerNursery bootstrap node (primary relay)
         * - HardwareControlFabric daemon bootstrap node
         */
        val DEFAULT_BOOTSTRAP_PEERS: List<BootstrapPeer> by lazy {
            listOf(
                createWasmserverBootstrapPeer(),
                createHardwareFabricBootstrapPeer()
            )
        }

        /**
         * Returns the peer IDs of the default bootstrap peers.
         * These are the well-known relay nodes that should be prioritized
         * for relay registration, as they are guaranteed to have relay
         * handlers enabled.
         *
         * @return Set of bootstrap peer IDs
         */
        fun getBootstrapPeerIds(): Set<String> {
            return setOf(
                peerIdFromSeed(WASMSERVER_BOOTSTRAP_SEED),
                peerIdFromSeed(HARDWARE_FABRIC_BOOTSTRAP_SEED)
            )
        }

        /**
         * Creates a UrlProtocol initialized with the default url:// network bootstrap peers.
         * This is the recommended way to create a UrlProtocol for connecting to the
         * global url:// network.
         *
         * @param relayConfig Configuration for relay functionality
         * @return A new UrlProtocol with default bootstrap peers
         */
        fun withDefaultBootstrapPeers(relayConfig: RelayConfig = RelayConfig()): UrlProtocol {
            return UrlProtocol(DEFAULT_BOOTSTRAP_PEERS, relayConfig)
        }

        /**
         * Creates a UrlProtocol with default bootstrap peers and peer persistence.
         *
         * @param peersDirectory Path to store/load peer data
         * @param filesystem The filesystem to use
         * @param relayConfig Configuration for relay functionality
         * @return A new UrlProtocol with default bootstrap peers and persistence
         */
        fun withDefaultBootstrapPeersAndPersistence(
            peersDirectory: Path,
            filesystem: FileSystem = FileSystem.SYSTEM,
            relayConfig: RelayConfig = RelayConfig()
        ): UrlProtocol {
            return UrlProtocol(DEFAULT_BOOTSTRAP_PEERS, peersDirectory, filesystem, relayConfig)
        }

        /**
         * Environment variable name for specifying the bind domain.
         * When set, containers will bind to this domain instead of the default.
         *
         * Example values:
         * - "localhost.tcp:8080" - Bind to TCP port 8080 (bypasses libp2p)
         * - "my.service" - Bind to libp2p as usual
         */
        const val ENV_BIND_DOMAIN = "URL_BIND_DOMAIN"

        /**
         * Checks if a domain string matches the localhost.tcp:PORT pattern.
         *
         * @param domain The domain to check.
         * @return True if this is a localhost.tcp domain.
         */
        fun isLocalhostTcpDomain(domain: String): Boolean {
            return LOCALHOST_TCP_PATTERN.matcher(domain).matches()
        }

        /**
         * Extracts the port number from a localhost.tcp:PORT domain.
         *
         * @param domain The domain to parse (e.g., "localhost.tcp:8080").
         * @return The port number, or null if not a valid localhost.tcp domain.
         */
        fun extractLocalhostTcpPort(domain: String): Int? {
            val matcher = LOCALHOST_TCP_PATTERN.matcher(domain)
            return if (matcher.matches()) {
                matcher.group(1).toIntOrNull()
            } else {
                null
            }
        }

        /**
         * Gets the bind domain from environment or uses the default.
         *
         * @param defaultDomain The default domain if ENV_BIND_DOMAIN is not set.
         * @return The domain to bind to.
         */
        fun getBindDomain(defaultDomain: String): String {
            return System.getenv(ENV_BIND_DOMAIN) ?: defaultDomain
        }
    }
}

private fun defaultNetworkProvider(relayConfig: RelayConfig): NetworkProvider =
    Libp2pNetworkProvider(enableRelay = relayConfig.enableRelay)

/** Preserves UrlProtocol's service-level stream metadata above the transport-only dial seam. */
private fun RpcStream.withServiceIdentifier(identifier: String): RpcStream {
    if (serviceIdentifier == identifier) return this
    return ServiceIdentifiedRpcStream(this, identifier)
}

private class OwnedProtocolRpcStream(
    val delegate: RpcStream,
    private val beforeCleanup: (Thread) -> Unit,
    private val released: (OwnedProtocolRpcStream, Thread, Throwable?) -> Unit,
) : RpcStream by delegate, RootLinkDiagnosticSource, RpcResponseReaderOwnership {
    override val ownsResponseReader: Boolean get() = delegate.ownsResponseReader
    override val rootLinkDiagnostics: RootLinkDiagnostics? get() = (delegate as? RootLinkDiagnosticSource)?.rootLinkDiagnostics

    private val cleanupStarted = AtomicBoolean(false)
    private val cleanupFinished = CountDownLatch(1)
    @Volatile private var cleanupOwner: Thread? = null
    @Volatile private var cleanupFailure: Throwable? = null
    @Volatile private var forwardingAttempted = false
    @Volatile private var closeRequestedDuringRelease = false
    private val cancellationStarted = AtomicBoolean(false)
    private val cancellationFinished = CountDownLatch(1)
    @Volatile private var cancellationOwner: Thread? = null
    @Volatile private var cancellationFailure: Throwable? = null

    override val isOpen: Boolean get() = !cleanupStarted.get() && delegate.isOpen

    override fun close() {
        if (cancellationOwner === Thread.currentThread()) return
        var failure: Throwable? = null
        try {
            if (!finishOwnership(forwarding = false)) {
                // The release callback cannot wait for itself. Its owner completes this
                // explicit cancellation after the callback returns.
                if (forwardingAttempted) closeRequestedDuringRelease = true
                return
            }
        } catch (ownershipFailure: Throwable) {
            failure = ownershipFailure
        }
        if (forwardingAttempted) {
            try {
                cancelForwardedTransfer()
            } catch (cancellationFailure: Throwable) {
                val first = failure
                if (first == null) failure = cancellationFailure
                else recordDistinctSuppressed(first, cancellationFailure)
            }
        }
        failure?.let { throw it }
    }

    override fun releaseAfterForwarding() {
        var failure: Throwable? = null
        try {
            if (!finishOwnership(forwarding = true)) return
        } catch (releaseFailure: Throwable) {
            failure = releaseFailure
        }
        try {
            if (closeRequestedDuringRelease) cancelForwardedTransfer()
            else if (failure == null) joinForwardedCancellation()
        } catch (cancellationFailure: Throwable) {
            val first = failure
            if (first == null) failure = cancellationFailure
            else recordDistinctSuppressed(first, cancellationFailure)
        }
        failure?.let { throw it }
    }

    // Automatic protocol cleanup must preserve a response whose forwarding release already
    // owns cleanup. Only an explicit handle close can cancel that transferred lifetime.
    fun closeForProtocol() {
        finishOwnership(forwarding = false)
    }

    // False means a callback re-entered its still-running cleanup. It must return to that
    // callback before deciding whether a successful release needs separate cancellation.
    private fun finishOwnership(forwarding: Boolean): Boolean {
        val caller = Thread.currentThread()
        if (!cleanupStarted.compareAndSet(false, true)) {
            if (cleanupOwner === caller) return false
            awaitOwnedStreamCleanup(cleanupFinished)
            cleanupFailure?.let { throw it }
            return true
        }
        cleanupOwner = caller
        beforeCleanup(caller)
        try {
            if (forwarding) {
                forwardingAttempted = true
                delegate.releaseAfterForwarding()
            } else {
                delegate.close()
            }
        } catch (failure: Throwable) {
            cleanupFailure = failure
            throw failure
        } finally {
            try {
                released(this, caller, cleanupFailure)
            } finally {
                cleanupOwner = null
                cleanupFinished.countDown()
            }
        }
        return true
    }

    private fun cancelForwardedTransfer() {
        val caller = Thread.currentThread()
        if (!cancellationStarted.compareAndSet(false, true)) {
            joinForwardedCancellation()
            return
        }
        cancellationOwner = caller
        beforeCleanup(caller)
        try {
            delegate.close()
        } catch (failure: Throwable) {
            cancellationFailure = failure
            throw failure
        } finally {
            try {
                released(this, caller, cancellationFailure)
            } finally {
                cancellationOwner = null
                cancellationFinished.countDown()
            }
        }
    }

    private fun joinForwardedCancellation() {
        if (!cancellationStarted.get() || cancellationOwner === Thread.currentThread()) return
        awaitOwnedStreamCleanup(cancellationFinished)
        cancellationFailure?.let { throw it }
    }
}

private fun recordDistinctSuppressed(first: Throwable, later: Throwable) {
    if (first === later) return
    synchronized(first) {
        if (first.suppressed.none { it === later }) first.addSuppressed(later)
    }
}

private fun awaitOwnedStreamCleanup(finished: CountDownLatch) {
    var interrupted = false
    while (true) {
        try {
            finished.await()
            break
        } catch (_: InterruptedException) {
            interrupted = true
        }
    }
    if (interrupted) Thread.currentThread().interrupt()
}

private class ServiceIdentifiedRpcStream(
    val delegate: RpcStream,
    override val serviceIdentifier: String
) : RpcResponseReaderOwnership, RootLinkDiagnosticSource {
    override val ownsResponseReader: Boolean get() = delegate.ownsResponseReader
    override val rootLinkDiagnostics: RootLinkDiagnostics? get() = (delegate as? RootLinkDiagnosticSource)?.rootLinkDiagnostics
    override val input: java.io.InputStream get() = delegate.input
    override val output: java.io.OutputStream get() = delegate.output
    override val remotePeerId: String get() = delegate.remotePeerId
    override val relayPeerId: String? get() = delegate.relayPeerId
    override val isOpen: Boolean get() = delegate.isOpen

    override fun sendRequest(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        delegate.sendRequest(request)

    override fun sendRequestRaw(request: Libp2pRpcProtocol.RpcRequest): Libp2pRpcProtocol.RpcResponse =
        delegate.sendRequestRaw(request)

    override suspend fun sendRequestAsync(
        request: Libp2pRpcProtocol.RpcRequest
    ): Libp2pRpcProtocol.RpcResponse = delegate.sendRequestAsync(request)

    override fun sendRequestForForwarding(
        request: Libp2pRpcProtocol.RpcRequest
    ): Libp2pRpcProtocol.RpcResponse = delegate.sendRequestForForwarding(request)

    override fun releaseAfterForwarding() = delegate.releaseAfterForwarding()

    override fun close() = delegate.close()
}

private fun RpcStream.sendRequestWithinResponseBudget(
    request: Libp2pRpcProtocol.RpcRequest,
    responseTimeoutMs: Long,
    clock: Clock
): Libp2pRpcProtocol.RpcResponse = when (this) {
    is OwnedProtocolRpcStream ->
        delegate.sendRequestWithinResponseBudget(request, responseTimeoutMs, clock)

    is ServiceIdentifiedRpcStream ->
        delegate.sendRequestWithinResponseBudget(request, responseTimeoutMs, clock)

    is Libp2pRpcStream -> sendRequest(request, responseTimeoutMs, clock)

    else -> {
        val timedOut = AtomicBoolean(false)
        val timeoutTask = clock.schedule(clock.currentTimeMillis() + responseTimeoutMs) {
            timedOut.set(true)
            close()
        }
        try {
            var requestFailedAfterDeadline = false
            val response = try {
                sendRequest(request)
            } catch (failure: Exception) {
                if (!timedOut.get()) throw failure
                // The deadline's close woke this call; keep an interruption visible to the caller.
                if (failure is InterruptedException) Thread.currentThread().interrupt()
                requestFailedAfterDeadline = true
                localTransportFailureResponse(
                    request.id,
                    "Request timed out after $responseTimeoutMs ms",
                    RpcTransportFailure.Phase.RESPONSE_TIMEOUT,
                    failure,
                    code = Libp2pRpcProtocol.ERROR_TIMEOUT,
                )
            }
            if (timedOut.get() && !requestFailedAfterDeadline) {
                localTransportFailureResponse(
                    request.id,
                    "Request timed out after $responseTimeoutMs ms",
                    RpcTransportFailure.Phase.RESPONSE_TIMEOUT,
                    (response.error?.data as? RpcTransportFailure)?.cause,
                    code = Libp2pRpcProtocol.ERROR_TIMEOUT,
                )
            } else {
                response
            }
        } finally {
            clock.unschedule(timeoutTask)
        }
    }
}

private enum class ProtocolCloseWaitMode { NONE, CLEANUP, FULL_DRAIN }

/** One result shared by protocol cleanup and owned cleanup callbacks that finish later. */
private class ProtocolCleanupResult {
    private var failure: Throwable? = null
    private val recorded = IdentityHashMap<Throwable, Boolean>()

    @Synchronized fun record(cause: Throwable) {
        if (recorded.put(cause, true) != null) return
        val first = failure
        if (first == null) failure = cause
        else if (first.suppressed.none { it === cause }) first.addSuppressed(cause)
    }

    @Synchronized fun throwIfFailed() {
        failure?.let { throw it }
    }
}

/** Record each action's failure immediately, including failures of nested stream cleanup. */
private fun runProtocolCleanup(actions: List<() -> Unit>, result: ProtocolCleanupResult) {
    for (action in actions) {
        try {
            action()
        } catch (cause: Throwable) {
            result.record(cause)
        }
    }
}

/** Reports a stream open refused or ended because the protocol is closed; identified by type, never by text. */
private class ProtocolClosedOpenException(cause: Throwable?) :
    UrlProtocolException("Cannot open stream: UrlProtocol is closed.", cause)

/** Reports a service send ended by protocol close; identified by type, never by text. */
private class ProtocolClosedSendException(
    message: String,
    cause: Throwable?,
    /** The send this failure belongs to, or null for a send rejected before it began. */
    val admission: Any?,
) : UrlProtocolException(message, cause)

/** Whether this is the closed failure of the send identified by [admission]. */
private fun Throwable.isClosedFailureOf(admission: Any): Boolean =
    this is ProtocolClosedSendException && this.admission === admission

private fun bestPeerFreshnessForExport(local: PeerFreshness?, imported: PeerFreshness?): PeerFreshness? =
    if ((local?.remainingLifetimeMillis ?: -1L) >= (imported?.remainingLifetimeMillis ?: -1L)) local else imported
