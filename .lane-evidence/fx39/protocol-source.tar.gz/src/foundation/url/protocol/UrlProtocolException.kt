package foundation.url.protocol

/**
 * Exception thrown when a protocol-level error occurs in UrlProtocol.
 *
 * This exception is thrown for:
 * - URL parsing errors (invalid url:// format)
 * - Peer discovery failures (no peers found for service)
 * - Connection establishment failures
 * - Stream I/O errors
 * - RPC timeouts
 *
 * @param message Descriptive error message explaining what went wrong.
 * @param cause Optional underlying cause of this exception.
 */
open class UrlProtocolException(
    message: String,
    cause: Throwable? = null
) : RuntimeException(message, cause)
