package foundation.url.protocol

import vpnurlregistrarapi.SubdomainRegistration
import vpnurlregistrarclient.HttpSubdomainStore
import java.nio.file.NoSuchFileException
import java.util.concurrent.ConcurrentHashMap

/**
 * NamespaceSegmentResolver that resolves "vpn" namespace segments using the VPN URL Registrar API.
 *
 * This resolver connects to a VPN URL Registrar server to look up subdomain registrations
 * and dynamically creates child resolvers for each registered subdomain.
 *
 * ## Usage
 *
 * The resolver is registered as the root resolver for "vpn":
 *
 * ```kotlin
 * // Initialize with the registrar server URL
 * VpnNamespaceSegmentResolver.initialize("https://vpnregistrar.wasmserver.com")
 *
 * // Now you can resolve vpn namespaces
 * val resolver = NamespaceSegmentResolver.resolve("vpn.myservice")
 * ```
 *
 * ## Namespace Structure
 *
 * The VPN namespace follows this structure:
 * ```
 * vpn
 *   └── <subdomain>  (fetched from VPN URL Registrar)
 *         └── <child-subdomain>  (hierarchical subdomains)
 * ```
 *
 * @param apiClient The HTTP client for the VPN URL Registrar API.
 * @param registration The subdomain registration this resolver represents, or null for the root "vpn" resolver.
 */
class VpnNamespaceSegmentResolver private constructor(
    private val apiClient: HttpSubdomainStore,
    private val registration: SubdomainRegistration?
) : NamespaceSegmentResolver {

    private val childCache = ConcurrentHashMap<String, VpnNamespaceSegmentResolver>()

    override fun getChildSegmentResolver(segment: String): NamespaceSegmentResolver {
        return childCache.computeIfAbsent(segment) { subdomain ->
            // Look up the subdomain from the registrar
            val reg = apiClient.getSubdomain(subdomain)
                ?: throw NoSuchFileException(
                    "No VPN subdomain registered for '$subdomain'. " +
                        "Check if the subdomain is registered at the VPN URL Registrar."
                )

            if (!reg.isActive) {
                throw NoSuchFileException(
                    "VPN subdomain '$subdomain' exists but is not active."
                )
            }

            VpnNamespaceSegmentResolver(apiClient, reg)
        }
    }

    override fun <T : Any> getObject(path: String, type: Class<T>): T {
        if (registration == null) {
            throw NoSuchFileException(
                "Cannot get objects from the root 'vpn' namespace. " +
                    "Resolve to a specific subdomain first (e.g., vpn.myservice)."
            )
        }

        // The primary object at a VPN subdomain resolver is its SubdomainRegistration
        if (path.isEmpty() || path == "/" || path == "registration") {
            if (!type.isInstance(registration)) {
                throw ClassCastException(
                    "Object at VPN subdomain '${registration.subdomain}' is SubdomainRegistration, " +
                        "not ${type.name}"
                )
            }
            @Suppress("UNCHECKED_CAST")
            return registration as T
        }

        // If there's resolver data, it can be retrieved
        if (path == "resolverData" || path == "/resolverData") {
            val data = registration.resolverData
                ?: throw NoSuchFileException(
                    "VPN subdomain '${registration.subdomain}' has no resolver data."
                )

            if (type == String::class.java) {
                @Suppress("UNCHECKED_CAST")
                return data as T
            }
            throw ClassCastException(
                "Resolver data for '${registration.subdomain}' is String, not ${type.name}"
            )
        }

        // For peerId specifically
        if (path == "peerId" || path == "/peerId") {
            if (type == String::class.java) {
                @Suppress("UNCHECKED_CAST")
                return registration.peerId as T
            }
            throw ClassCastException(
                "Peer ID for '${registration.subdomain}' is String, not ${type.name}"
            )
        }

        throw NoSuchFileException(
            "Unknown path '$path' for VPN subdomain '${registration.subdomain}'. " +
                "Available paths: '', '/', 'registration', 'resolverData', 'peerId'."
        )
    }

    companion object {
        private var rootResolver: VpnNamespaceSegmentResolver? = null

        /**
         * Initializes the VPN namespace resolver with the given registrar URL.
         *
         * This creates the root "vpn" resolver and registers it with the
         * NamespaceSegmentResolver system.
         *
         * @param registrarUrl The base URL of the VPN URL Registrar server
         *                     (e.g., "https://vpnregistrar.wasmserver.com").
         */
        fun initialize(registrarUrl: String) {
            val apiClient = HttpSubdomainStore(registrarUrl)
            rootResolver = VpnNamespaceSegmentResolver(apiClient, null)
            NamespaceSegmentResolver.registerRootResolver("vpn", rootResolver!!)
        }

        /**
         * Initializes with the default production registrar URL.
         */
        fun initializeDefault() {
            initialize("https://vpnregistrar.wasmserver.com")
        }

        /**
         * Checks if the VPN namespace resolver has been initialized.
         */
        fun isInitialized(): Boolean = rootResolver != null

        /**
         * Clears the VPN resolver cache.
         *
         * This forces subsequent resolutions to fetch fresh data from the registrar.
         */
        fun clearCache() {
            rootResolver?.childCache?.clear()
        }
    }
}
