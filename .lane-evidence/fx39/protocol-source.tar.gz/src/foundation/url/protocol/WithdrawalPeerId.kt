package foundation.url.protocol

import io.libp2p.core.PeerId
import org.json.JSONException
import org.json.JSONObject

// Generic message codecs preserve opaque provider identities. Only libp2p transports call
// this guard on the decoded value before admission, retaining their accepted identity forms.
internal fun validateLibp2pWithdrawalPeerId(message: Any) {
    when (message) {
        is GossipProtocol.ServiceWithdrawal -> validateWithdrawalPeerId("providerPeerId", message.providerPeerId)
        is RelayProtocol.RelayWithdrawal -> validateWithdrawalPeerId("peerId", message.peerId)
    }
}

private fun validateWithdrawalPeerId(field: String, value: String) {
    if (isInMemoryPeerId(value)) return
    // PeerId accepts 32..50 decoded bytes. Their base58 text is at least 32 and at most 69 characters.
    // Check before conversion so an oversized field cannot cause unbounded base58 decoding work.
    if (value.length !in 32..69) throw invalidWithdrawalPeerId(field, value)
    try {
        PeerId.fromBase58(value)
    } catch (failure: RuntimeException) {
        // Base58 reports invalid characters with RuntimeException; PeerId uses IllegalArgumentException for length.
        throw invalidWithdrawalPeerId(field, value, failure)
    }
}

private fun invalidWithdrawalPeerId(field: String, value: String, cause: RuntimeException? = null): JSONException {
    val display = JSONObject.quote(value.take(69)) + if (value.length > 69) " (${value.length} characters)" else ""
    return JSONException(
        "Withdrawal field \"$field\" must be a base58 peer id encoding 32 to 50 bytes or an in-memory peer id encoding a nonblank UTF-8 seed, but was $display",
        cause,
    )
}
