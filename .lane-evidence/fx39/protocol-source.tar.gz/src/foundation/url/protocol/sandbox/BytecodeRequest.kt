package foundation.url.protocol.sandbox

import org.json.JSONObject
import java.util.Base64

/**
 * Protocol for requesting implementation bytecode from service providers.
 *
 * This module defines the request/response format for fetching the JAR or class
 * files that implement a sandboxed service.
 */
object BytecodeProtocol {

    /**
     * RPC method name for bytecode requests.
     */
    const val METHOD_BYTECODE_REQUEST = "__bytecode_request"

    /**
     * RPC method name for bytecode responses.
     */
    const val METHOD_BYTECODE_RESPONSE = "__bytecode_response"

    /**
     * Request-metadata key by which a PROXY forwarding a [METHOD_BYTECODE_REQUEST] to a
     * url-bind backend advertises that its own proxy-side translate can parse a **streamed**
     * bytecode response — i.e. a final BytecodeProtocol response keyed by `jarBytes`/`implClassName`
     * (see [ServiceRoutingHandler]'s `translateBackendBytecodeResponse` passthrough), rather than
     * only the legacy backend `{jar, className}` shape.
     *
     * This is the capability half of a backward/forward-compatible negotiation for the bytecode
     * proxy hop. It is deliberately carried in the additive RPC metadata channel
     * ([Libp2pRpcProtocol.RpcRequest.metadata]) rather than a new multistream protocol version,
     * because the concern is an application-level response schema, not transport framing.
     *
     * Contract:
     * - A proxy that understands the streamed form SETS this key to
     *   [BYTECODE_RESPONSE_FORMAT_STREAMED] on the forwarded request.
     * - A backend that can stream its bytecode MAY answer with a streamed response ONLY when it
     *   sees this key set to that value; **otherwise it MUST answer in the legacy `{jar, className}`
     *   form**, which every proxy version understands.
     * - An older proxy omits the key (a backend then falls back to legacy); an older backend
     *   ignores the key (and answers legacy). Either missing half degrades safely to legacy, so
     *   any deploy order and any mixed-version fleet is safe.
     */
    const val METADATA_KEY_BYTECODE_RESPONSE_FORMAT = "bytecodeResponseFormat"

    /**
     * The value for [METADATA_KEY_BYTECODE_RESPONSE_FORMAT] signaling that the forwarding proxy can
     * parse a streamed (`jarBytes`/`implClassName`) bytecode response.
     */
    const val BYTECODE_RESPONSE_FORMAT_STREAMED = "streamed"

    /**
     * Computes the canonical content digest of implementation JAR bytes, used
     * as the validator for conditional bytecode requests (the `url://`
     * equivalent of an HTTP ETag).
     *
     * Both sides of the wire must use this exact function so that string
     * equality of two digests means byte equality of the underlying JARs:
     * the client digests its cached copy ([createRequest]'s `cachedDigest`),
     * and the server digests its current copy
     * ([foundation.url.protocol.ServiceHandler.getImplementationJarDigest]).
     *
     * The format is `"sha256:" + lowercase hex`, e.g.
     * `sha256:9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08`.
     * The algorithm prefix allows a future digest-algorithm migration without
     * ambiguity: digests with different prefixes simply never compare equal,
     * which conservatively degrades to a full re-download.
     */
    fun computeDigest(jarBytes: ByteArray): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val hex = md.digest(jarBytes).joinToString("") { String.format("%02x", it) }
        return "sha256:$hex"
    }

    /**
     * Creates a bytecode request payload.
     *
     * @param serviceIdentifier The service identifier to fetch bytecode for
     * @param interfaceClassName The fully qualified interface class name (optional)
     * @return JSON string payload for the RPC request
     */
    fun createRequest(serviceIdentifier: String, interfaceClassName: String? = null): String {
        return createRequest(serviceIdentifier, interfaceClassName, null)
    }

    /**
     * Creates a bytecode request payload, optionally carrying the digest of a
     * previously downloaded copy of the bytecode (a conditional request — the
     * `url://` analogue of HTTP `If-None-Match`).
     *
     * When [cachedDigest] is non-null and matches the digest of the bytecode
     * the server would serve (see [computeDigest]), the server replies with a
     * tiny not-modified response ([createNotModifiedResponse]) instead of the
     * multi-megabyte JAR payload. Servers that predate this protocol field
     * ignore it and always reply with the full payload, so conditional
     * requests are safe to send to any server.
     *
     * @param serviceIdentifier The service identifier to fetch bytecode for
     * @param interfaceClassName The fully qualified interface class name (optional)
     * @param cachedDigest Digest (from [computeDigest]) of the bytecode copy the
     *        requester already holds, or null for an unconditional request
     * @return JSON string payload for the RPC request
     */
    fun createRequest(
        serviceIdentifier: String,
        interfaceClassName: String?,
        cachedDigest: String?
    ): String {
        return JSONObject().apply {
            put("serviceIdentifier", serviceIdentifier)
            if (interfaceClassName != null) {
                put("interfaceClassName", interfaceClassName)
            }
            if (cachedDigest != null) {
                put("cachedDigest", cachedDigest)
            }
        }.toString()
    }

    /**
     * Parses a bytecode request payload.
     *
     * @param json The JSON string payload
     * @return The parsed BytecodeRequest
     */
    fun parseRequest(json: String): BytecodeRequest {
        val obj = JSONObject(json)
        return BytecodeRequest(
            serviceIdentifier = obj.getString("serviceIdentifier"),
            interfaceClassName = obj.optString("interfaceClassName", null),
            cachedDigest = obj.optString("cachedDigest", null)
        )
    }

    /**
     * Creates a successful bytecode response as a Map with raw ByteArray values.
     *
     * The ByteArray values are sent as binary attachments by the RPC layer,
     * avoiding base64 encoding overhead and the resulting OOM from multi-megabyte
     * string copies during JSON parsing.
     *
     * @param jarBytes The implementation JAR bytes
     * @param implClassName The fully qualified implementation class name
     * @param stdlibJarBytes Optional stdlib JAR bytes
     * @return A Map suitable for use as an RPC response result
     */
    fun createBinaryResponse(
        jarBytes: ByteArray,
        implClassName: String,
        stdlibJarBytes: ByteArray? = null
    ): Map<String, Any?> {
        return buildMap {
            put("success", true)
            put("jarBytes", jarBytes)
            put("implClassName", implClassName)
            if (stdlibJarBytes != null) {
                put("stdlibJarBytes", stdlibJarBytes)
            }
        }
    }

    /**
     * Creates a successful bytecode response payload as a JSON string with
     * base64-encoded JAR data.
     *
     * @param jarBytes The implementation JAR bytes
     * @param implClassName The fully qualified implementation class name
     * @return JSON string payload for the RPC response
     */
    fun createResponse(
        jarBytes: ByteArray,
        implClassName: String
    ): String {
        return createResponseFromBase64(
            jarBase64 = Base64.getEncoder().encodeToString(jarBytes),
            implClassName = implClassName
        )
    }

    /**
     * **Deprecated.** Remote services must not provide stdlib bytes; the
     * `stdlibJarBytes` field is dropped from the wire response. Call the
     * two-arg overload of [createResponse] instead. Retained for source
     * compatibility with callers that still pass a `stdlibJarBytes`
     * argument; the bytes are silently ignored.
     */
    @Deprecated(
        message = "Remote services must not supply stdlib bytes. Call " +
            "createResponse(jarBytes, implClassName) instead — any " +
            "stdlibJarBytes argument is dropped before serialization. See " +
            "ServiceHandler.getStdlibJar's deprecation notice for rationale.",
        replaceWith = ReplaceWith("createResponse(jarBytes, implClassName)"),
        level = DeprecationLevel.WARNING
    )
    fun createResponse(
        jarBytes: ByteArray,
        implClassName: String,
        @Suppress("UNUSED_PARAMETER") stdlibJarBytes: ByteArray?
    ): String {
        return createResponse(jarBytes, implClassName)
    }

    /**
     * Creates a successful bytecode response payload from pre-encoded base64 strings.
     *
     * Use this when the JAR data is already available as a base64 string (e.g., when
     * forwarding from a backend service) to avoid the overhead of decoding and
     * re-encoding multi-megabyte JAR byte arrays.
     *
     * @param jarBase64 The implementation JAR bytes as a base64-encoded string
     * @param implClassName The fully qualified implementation class name
     * @return JSON string payload for the RPC response
     */
    fun createResponseFromBase64(
        jarBase64: String,
        implClassName: String
    ): String {
        return JSONObject().apply {
            put("success", true)
            put("jarBytes", jarBase64)
            put("implClassName", implClassName)
        }.toString()
    }

    /**
     * **Deprecated.** Remote services must not provide stdlib bytes; the
     * `stdlibJarBase64` field is dropped from the wire response. Call the
     * two-arg overload of [createResponseFromBase64] instead. Retained for
     * source compatibility; the argument is silently ignored.
     */
    @Deprecated(
        message = "Remote services must not supply stdlib bytes. Call " +
            "createResponseFromBase64(jarBase64, implClassName) instead — any " +
            "stdlibJarBase64 argument is dropped before serialization. See " +
            "ServiceHandler.getStdlibJar's deprecation notice for rationale.",
        replaceWith = ReplaceWith("createResponseFromBase64(jarBase64, implClassName)"),
        level = DeprecationLevel.WARNING
    )
    fun createResponseFromBase64(
        jarBase64: String,
        implClassName: String,
        @Suppress("UNUSED_PARAMETER") stdlibJarBase64: String?
    ): String {
        return createResponseFromBase64(jarBase64, implClassName)
    }

    /**
     * Creates an error response payload.
     *
     * @param errorMessage The error message
     * @return JSON string payload for the error response
     */
    fun createErrorResponse(errorMessage: String): String {
        return JSONObject().apply {
            put("success", false)
            put("error", errorMessage)
        }.toString()
    }

    /**
     * Creates a not-modified response payload (the `url://` analogue of HTTP
     * `304 Not Modified`).
     *
     * Sent by a server in reply to a conditional request (a [createRequest]
     * payload with a non-null `cachedDigest`) whose digest matches the
     * bytecode the server would have served. The response carries no JAR
     * bytes — the requester keeps using its cached copy — so a few-hundred-byte
     * frame replaces a multi-megabyte transfer.
     *
     * Must only be sent in reply to a conditional request: clients that did
     * not send a `cachedDigest` have no cached copy to fall back on and
     * reject this payload in [parseResponse].
     *
     * @param digest The digest (from [computeDigest]) that matched, echoed
     *        back for diagnostics
     * @return JSON string payload for the not-modified response
     */
    fun createNotModifiedResponse(digest: String): String {
        return JSONObject().apply {
            put("success", true)
            put("notModified", true)
            put("digest", digest)
        }.toString()
    }

    /**
     * Creates a binary error response as a Map.
     *
     * @param errorMessage The error message
     * @return A Map suitable for use as an RPC response result
     */
    fun createBinaryErrorResponse(errorMessage: String): Map<String, Any?> {
        return mapOf("success" to false, "error" to errorMessage)
    }

    /**
     * Parses a bytecode response from an RPC result value.
     *
     * Handles both the new binary format (Map with ByteArray values from binary
     * attachments) and the legacy base64 JSON string format.
     *
     * @param result The RPC response result (Map from binary format, or String from legacy)
     * @return The parsed BytecodeResponse
     * @throws SandboxException if the response indicates an error
     */
    fun parseResponseFromResult(result: Any?): BytecodeResponse {
        return when (val parsed = parseConditionalResponseFromResult(result)) {
            is BytecodeFetchResult.Downloaded -> parsed.response
            is BytecodeFetchResult.NotModified -> throw SandboxException(
                "Bytecode request returned a not-modified response (digest ${parsed.digest}), " +
                    "but this call site sent an unconditional request and holds no cached copy " +
                    "to fall back on. A server must only send not-modified in reply to a request " +
                    "carrying a cachedDigest; conditional call sites must parse with " +
                    "parseConditionalResponseFromResult instead of parseResponseFromResult."
            )
        }
    }

    /**
     * Parses a conditional bytecode response directly from an RPC result. Attachment-aware RPC
     * readers produce a Map containing raw [ByteArray] values, while legacy peers produce the
     * historical base64 JSON String; both forms preserve the same conditional-response contract.
     *
     * Every shape a transport can hand back is read in place. That matters because the shape is
     * not the caller's choice: the same service answers with raw bytes over a direct connection
     * and with base64 inside JSON when the answer came through a relay, and a decoder may leave
     * that JSON as a [JSONObject] or as a [Map]. A caller that cannot read the shape it was given
     * has only one way out — serialize it back to a string and parse that — and for bytecode the
     * string is the payload again, so a 4 MB JAR ends up held four times over. That is how a
     * 128 MB service heap was exhausted by one client-bytecode transfer it was merely relaying.
     */
    fun parseConditionalResponseFromResult(result: Any?): BytecodeFetchResult {
        return when (result) {
            is Map<*, *> -> {
                val success = result["success"] as? Boolean ?: false
                if (!success) {
                    val error = result["error"]?.toString() ?: "Unknown error"
                    throw SandboxException("Bytecode request failed: $error")
                }
                if (result["notModified"] == true) {
                    return BytecodeFetchResult.NotModified(result["digest"]?.toString())
                }
                // A binary-capable hop leaves raw bytes here; a hop that carried the response
                // as JSON (a relay re-serializes, so this is the ordinary case behind one) leaves
                // the public base64 form. Decoding that string here costs the JAR once, where
                // handing the whole map back as a string would cost the payload twice more.
                val jarBytes = when (val raw = result["jarBytes"]) {
                    is ByteArray -> raw
                    is String -> Base64.getDecoder().decode(raw)
                    else -> throw SandboxException(
                        "Bytecode response 'jarBytes' must be raw bytes or a base64 String, but was " +
                            "${raw?.javaClass?.name ?: "absent"}."
                    )
                }
                val implClassName = result["implClassName"]?.toString()
                    ?: throw SandboxException("Bytecode response missing 'implClassName'")
                // stdlibJarBytes is intentionally NOT propagated (UrlResolver #506): the consumer
                // loads its own bundled /stdlib.jar. Older servers may still include the field on
                // the wire; we tolerate but never read it.
                BytecodeFetchResult.Downloaded(
                    BytecodeResponse(jarBytes = jarBytes, implClassName = implClassName)
                )
            }
            is JSONObject -> parseConditionalResponse(result)
            is String -> parseConditionalResponse(result)
            else -> throw SandboxException(
                "Unexpected bytecode response type: ${result?.javaClass?.name}. " +
                    "Expected Map (binary format), JSONObject or String (JSON formats)."
            )
        }
    }

    /**
     * Parses a bytecode response payload.
     *
     * Use this for unconditional requests (no `cachedDigest` sent). For
     * conditional requests, use [parseConditionalResponse], which can also
     * represent the not-modified outcome.
     *
     * @param json The JSON string payload
     * @return The parsed BytecodeResponse
     * @throws SandboxException if the response indicates an error, or if it is
     *         a not-modified response (which is only valid in reply to a
     *         conditional request)
     */
    fun parseResponse(json: String): BytecodeResponse = parseResponse(JSONObject(json))

    /**
     * Parses an unconditional bytecode response that has already been decoded into JSON.
     *
     * See [parseConditionalResponse] for why a caller holding a parsed object should not
     * serialize it back to a string to be parsed again.
     */
    fun parseResponse(obj: JSONObject): BytecodeResponse {
        return when (val result = parseConditionalResponse(obj)) {
            is BytecodeFetchResult.Downloaded -> result.response
            is BytecodeFetchResult.NotModified -> throw SandboxException(
                "Bytecode request returned a not-modified response (digest ${result.digest}), " +
                    "but this call site sent an unconditional request and holds no cached copy " +
                    "to fall back on. A server must only send not-modified in reply to a request " +
                    "carrying a cachedDigest; conditional call sites must parse with " +
                    "parseConditionalResponse instead of parseResponse."
            )
        }
    }

    /**
     * Parses the response to a conditional bytecode request.
     *
     * @param json The JSON string payload
     * @return [BytecodeFetchResult.NotModified] if the server confirmed the
     *         requester's cached copy is current, or
     *         [BytecodeFetchResult.Downloaded] carrying the full payload
     * @throws SandboxException if the response indicates an error
     */
    fun parseConditionalResponse(json: String): BytecodeFetchResult =
        parseConditionalResponse(JSONObject(json))

    /**
     * Parses a conditional bytecode response that has **already been decoded** into JSON.
     *
     * A caller whose transport handed it a parsed object had, until this overload existed, to
     * serialize that object back to a string just to call [parseConditionalResponse]. For a
     * bytecode response that string is the whole payload again — a multi-megabyte base64 body —
     * and parsing it allocates the base64 a third time before it is finally decoded. A 4 MB JAR
     * therefore cost roughly four simultaneous copies of itself, which is how a 128 MB service
     * heap was exhausted by a single client-bytecode transfer it was only passing along.
     *
     * Reading the fields off the object the caller already holds costs none of that: the base64
     * value is the string the transport parsed, and the only new allocation is the JAR itself.
     */
    fun parseConditionalResponse(obj: JSONObject): BytecodeFetchResult {
        if (!obj.getBoolean("success")) {
            val error = obj.optString("error", "Unknown error")
            throw SandboxException("Bytecode request failed: $error")
        }

        if (obj.optBoolean("notModified", false)) {
            return BytecodeFetchResult.NotModified(obj.optString("digest", null))
        }

        val jarBytes = Base64.getDecoder().decode(obj.getString("jarBytes"))
        val implClassName = obj.getString("implClassName")
        // Any "stdlibJarBytes" field on the wire is intentionally ignored:
        // the consumer must use its own bundled /stdlib.jar (UrlResolver #506).
        // We tolerate the field for backward compatibility with older servers
        // that still include it; we simply don't read or propagate it.

        return BytecodeFetchResult.Downloaded(
            BytecodeResponse(
                jarBytes = jarBytes,
                implClassName = implClassName
            )
        )
    }
}

/**
 * Outcome of a conditional bytecode request
 * (see [BytecodeProtocol.parseConditionalResponse]).
 */
sealed class BytecodeFetchResult {
    /**
     * The server's current bytecode matches the digest the requester sent;
     * no JAR bytes were transferred and the requester's cached copy is current.
     *
     * @property digest The matching digest echoed by the server, or null if the
     *           server omitted it
     */
    data class NotModified(val digest: String?) : BytecodeFetchResult()

    /**
     * The server transferred the full bytecode payload — either the request was
     * unconditional, or the requester's cached copy is out of date.
     */
    data class Downloaded(val response: BytecodeResponse) : BytecodeFetchResult()
}

/**
 * Represents a bytecode request from a client.
 *
 * @property serviceIdentifier The service identifier to fetch bytecode for
 * @property interfaceClassName The fully qualified interface class name (optional hint)
 * @property cachedDigest Digest (from [BytecodeProtocol.computeDigest]) of the
 *           bytecode copy the requester already holds, making this a conditional
 *           request, or null for an unconditional request
 */
data class BytecodeRequest @JvmOverloads constructor(
    val serviceIdentifier: String,
    val interfaceClassName: String? = null,
    val cachedDigest: String? = null
)

/**
 * Represents a successful bytecode response from a service provider.
 *
 * @property jarBytes The JAR file bytes containing the implementation
 * @property implClassName The fully qualified name of the implementation class
 * @property stdlibJarBytes **Deprecated.** Always null in fresh responses —
 *           the wire format no longer carries stdlib bytes. Retained on the
 *           data class for source compatibility with code that names the
 *           field; do not rely on it being non-null.
 */
data class BytecodeResponse(
    val jarBytes: ByteArray,
    val implClassName: String,
    @property:Deprecated(
        message = "Stdlib bytes are no longer carried in __bytecode_request " +
            "responses. The consumer must use its own bundled /stdlib.jar. " +
            "This property will always be null in fresh responses.",
        level = DeprecationLevel.WARNING
    )
    val stdlibJarBytes: ByteArray? = null
) {
    @Suppress("DEPRECATION")
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as BytecodeResponse

        if (!jarBytes.contentEquals(other.jarBytes)) return false
        if (implClassName != other.implClassName) return false
        if (stdlibJarBytes != null) {
            if (other.stdlibJarBytes == null) return false
            if (!stdlibJarBytes.contentEquals(other.stdlibJarBytes)) return false
        } else if (other.stdlibJarBytes != null) return false

        return true
    }

    @Suppress("DEPRECATION")
    override fun hashCode(): Int {
        var result = jarBytes.contentHashCode()
        result = 31 * result + implClassName.hashCode()
        result = 31 * result + (stdlibJarBytes?.contentHashCode() ?: 0)
        return result
    }
}

/**
 * Exception thrown when sandbox operations fail.
 *
 * [remoteExceptionClassName] and [remoteExceptionMessage] describe the exception that the
 * remote service's own handler threw and reported for the failed call (see
 * [foundation.url.protocol.RemoteApplicationFailure]). They are null for everything else:
 * exceptions raised by the sandboxed client code itself, local sandbox setup, conversion and
 * lifecycle failures, transport, timeout and routing failures, cancellations, hosting failures
 * ([foundation.url.protocol.ServiceInfrastructureFailure]) and servers that predate the field.
 * The class name is a fully qualified name and can be used without loading the remote class.
 * [remoteExceptionMessage] can be null when the remote exception has no message.
 * The inherited [message] and [cause] retain their existing diagnostic text.
 */
class SandboxException(message: String, cause: Throwable? = null) : RuntimeException(message, cause) {
    private var remoteClassNameValue: String? = null
    private var remoteMessageValue: String? = null

    val remoteExceptionClassName: String? get() = remoteClassNameValue
    val remoteExceptionMessage: String? get() = remoteMessageValue

    constructor(
        message: String,
        cause: Throwable?,
        remoteExceptionClassName: String?,
        remoteExceptionMessage: String?
    ) : this(message, cause) {
        remoteClassNameValue = remoteExceptionClassName
        remoteMessageValue = remoteExceptionMessage
    }
}

/**
 * Interface for services that can provide implementation bytecode.
 *
 * Services implementing this interface can be sandboxed on the client side.
 */
interface BytecodeProvider {
    /**
     * Returns the implementation JAR bytes.
     * Returns null if this service does not support sandboxing.
     */
    fun getImplementationJar(): ByteArray?

    /**
     * Returns the fully qualified class name of the implementation.
     * Returns null if this service does not support sandboxing.
     */
    fun getImplementationClassName(): String?

    /**
     * **Deprecated.** Stdlib bytes are no longer carried in
     * `__bytecode_request` responses; the consumer always uses its own
     * bundled `/stdlib.jar`. Override is now a no-op at runtime.
     */
    @Deprecated(
        message = "Remote services must not supply stdlib bytes. The wire " +
            "response no longer carries stdlibJarBytes — any value returned " +
            "here is ignored. Remove the override.",
        level = DeprecationLevel.WARNING
    )
    fun getStdlibJar(): ByteArray? = null
}
