package foundation.url.protocol.sandbox

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Type
import java.util.Base64

/**
 * Handles JSON serialization and deserialization for crossing the sandbox boundary.
 *
 * Complex objects are converted to/from JSON strings when passed between the host
 * and the SJVM sandbox. This provides a clean serialization boundary that prevents
 * object reference leaks.
 */
object JsonSerialization {

    /**
     * Serializes an object to a JSON string.
     *
     * @param obj The object to serialize (can be null)
     * @return The JSON string representation
     */
    fun serialize(obj: Any?): String {
        return when (obj) {
            null -> "null"
            is String -> JSONObject.quote(obj)
            is Number -> obj.toString()
            is Boolean -> obj.toString()
            is Char -> JSONObject.quote(obj.toString())
            is ByteArray -> JSONObject().apply {
                put("__type", "bytes")
                put("__value", Base64.getEncoder().encodeToString(obj))
            }.toString()
            is Array<*> -> serializeArray(obj)
            is Collection<*> -> serializeCollection(obj)
            is Map<*, *> -> serializeMap(obj)
            else -> serializeObject(obj)
        }
    }

    /**
     * Deserializes a JSON string to an object of the specified type.
     *
     * @param json The JSON string
     * @param type The target Java type
     * @return The deserialized object
     */
    @Suppress("UNCHECKED_CAST")
    fun <T> deserialize(json: String, type: Class<T>): T {
        val trimmed = json.trim()

        // Handle null
        if (trimmed == "null") {
            return null as T
        }

        // Handle primitive types and common types
        @Suppress("USELESS_CAST")
        val result: Any? = when {
            type == String::class.java -> {
                // Unescape via org.json's tokenizer — the exact inverse of the JSONObject.quote
                // used by serialize — so the full JSON escape set (\n, \t, \r, \b, \f, \uXXXX,
                // \/, plus \" and \\) round-trips, not just \" and \\.
                if (trimmed.length >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) {
                    try {
                        JSONTokener(trimmed).nextValue() as? String
                            ?: throw SandboxException(
                                "Cannot deserialize to String: not a JSON string literal: ${trimmed.take(200)}"
                            )
                    } catch (e: org.json.JSONException) {
                        // Give malformed (never-serialized) input a uniform SandboxException
                        // contract rather than leaking a raw org.json.JSONException.
                        throw SandboxException(
                            "Cannot deserialize to String: malformed JSON string literal: ${trimmed.take(200)}",
                            e
                        )
                    }
                } else {
                    trimmed
                }
            }

            type == Int::class.java || type == Integer::class.java -> trimmed.toInt()
            type == Long::class.java || type == java.lang.Long::class.java -> trimmed.toLong()
            type == Double::class.java || type == java.lang.Double::class.java -> trimmed.toDouble()
            type == Float::class.java || type == java.lang.Float::class.java -> trimmed.toFloat()
            type == Boolean::class.java || type == java.lang.Boolean::class.java -> trimmed.toBoolean()
            type == Byte::class.java || type == java.lang.Byte::class.java -> trimmed.toByte()
            type == Short::class.java || type == java.lang.Short::class.java -> trimmed.toShort()
            type == Char::class.java || type == Character::class.java -> {
                // Unescape via org.json's tokenizer — the exact inverse of the JSONObject.quote
                // used by serialize. Stripping the surrounding quotes without unescaping decodes
                // every escaped character ("\n", "\t", "\"", "\\", "\uXXXX", ...) to its leading
                // backslash instead of the character that was serialized.
                val str = if (trimmed.startsWith("\"")) {
                    if (trimmed.length < 2 || !trimmed.endsWith("\"")) {
                        throw SandboxException(
                            "Cannot deserialize to Char: not a JSON string literal: ${trimmed.take(200)}"
                        )
                    }
                    try {
                        val tokenizer = JSONTokener(trimmed)
                        val parsed = tokenizer.nextValue()
                        if (parsed !is String || tokenizer.nextClean() != '\u0000') {
                            throw SandboxException(
                                "Cannot deserialize to Char: not a complete JSON string literal: ${trimmed.take(200)}"
                            )
                        }
                        parsed
                    } catch (e: org.json.JSONException) {
                        // Give malformed (never-serialized) input a uniform SandboxException
                        // contract rather than leaking a raw org.json.JSONException.
                        throw SandboxException(
                            "Cannot deserialize to Char: malformed JSON string literal: ${trimmed.take(200)}",
                            e
                        )
                    }
                } else {
                    trimmed
                }
                str.firstOrNull() ?: '\u0000'
            }

            // JSONObject type
            type == JSONObject::class.java -> JSONObject(trimmed)

            // JSONArray type
            type == JSONArray::class.java -> JSONArray(trimmed)

            // List types
            List::class.java.isAssignableFrom(type) -> {
                val jsonArray = JSONArray(trimmed)
                (0 until jsonArray.length()).map { jsonArray.get(it) }
            }

            // Map types
            Map::class.java.isAssignableFrom(type) -> {
                val jsonObject = JSONObject(trimmed)
                jsonObject.keys().asSequence().associateWith { key -> jsonObject.get(key) }
            }

            // ByteArray type - encoded as {"__type":"bytes","__value":"<base64>"}
            type == ByteArray::class.java -> {
                val jsonObject = JSONObject(trimmed)
                val typeMarker = jsonObject.optString("__type", "")
                if ((typeMarker == "bytes" || typeMarker == "[B") && jsonObject.has("__value")) {
                    Base64.getDecoder().decode(jsonObject.getString("__value"))
                } else {
                    throw SandboxException("Cannot deserialize to ByteArray: expected {\"__type\":\"bytes\",\"__value\":\"...\"} but got: ${trimmed.take(200)}")
                }
            }

            // Array types
            type.isArray -> {
                val componentType = type.componentType
                val jsonArray = JSONArray(trimmed)
                val array = java.lang.reflect.Array.newInstance(componentType, jsonArray.length())
                for (i in 0 until jsonArray.length()) {
                    val element = deserializeElement(jsonArray.get(i), componentType)
                    java.lang.reflect.Array.set(array, i, element)
                }
                array
            }

            // Generic object deserialization
            else -> deserializeObject(trimmed, type)
        }
        return result as T
    }

    /**
     * Deserializes with generic type information.
     */
    @Suppress("UNCHECKED_CAST")
    fun <T> deserialize(json: String, type: Type): T {
        return when (type) {
            is Class<*> -> deserialize(json, type) as T
            is ParameterizedType -> {
                val rawType = type.rawType as Class<*>
                val typeArgs = type.actualTypeArguments

                val result: Any = when {
                    List::class.java.isAssignableFrom(rawType) -> {
                        val elementType = typeArgs.firstOrNull() ?: Any::class.java
                        val jsonArray = JSONArray(json)
                        (0 until jsonArray.length()).map { i ->
                            deserializeElement(jsonArray.get(i), elementType)
                        }
                    }

                    Map::class.java.isAssignableFrom(rawType) -> {
                        val valueType = typeArgs.getOrNull(1) ?: Any::class.java
                        val jsonObject = JSONObject(json)
                        jsonObject.keys().asSequence().associateWith { key ->
                            deserializeElement(jsonObject.get(key), valueType)
                        }
                    }

                    else -> deserialize(json, rawType)
                }
                result as T
            }
            else -> throw SandboxException("Unsupported type for deserialization: $type")
        }
    }

    private fun serializeArray(array: Array<*>): String {
        val jsonArray = JSONArray()
        array.forEach { element ->
            jsonArray.put(toJsonValue(element))
        }
        return jsonArray.toString()
    }

    private fun serializeCollection(collection: Collection<*>): String {
        val jsonArray = JSONArray()
        collection.forEach { element ->
            jsonArray.put(toJsonValue(element))
        }
        return jsonArray.toString()
    }

    private fun serializeMap(map: Map<*, *>): String {
        val jsonObject = JSONObject()
        map.forEach { (key, value) ->
            jsonObject.put(key.toString(), toJsonValue(value))
        }
        return jsonObject.toString()
    }

    private fun serializeObject(obj: Any): String {
        val jsonObject = JSONObject()
        val clazz = obj::class.java

        // Add type information for deserialization
        jsonObject.put("__type", clazz.name)

        // Serialize all declared fields
        clazz.declaredFields.forEach { field ->
            if (!java.lang.reflect.Modifier.isStatic(field.modifiers) &&
                !java.lang.reflect.Modifier.isTransient(field.modifiers)) {
                field.isAccessible = true
                try {
                    val value = field.get(obj)
                    jsonObject.put(field.name, toJsonValue(value))
                } catch (e: Exception) {
                    // Skip fields that can't be accessed
                }
            }
        }

        return jsonObject.toString()
    }

    private fun toJsonValue(value: Any?): Any? {
        return when (value) {
            null -> JSONObject.NULL
            is String, is Number, is Boolean -> value
            is Char -> value.toString()
            is ByteArray -> JSONObject().apply {
                put("__type", "bytes")
                put("__value", Base64.getEncoder().encodeToString(value))
            }
            is Array<*> -> JSONArray().apply {
                value.forEach { put(toJsonValue(it)) }
            }
            is Collection<*> -> JSONArray().apply {
                value.forEach { put(toJsonValue(it)) }
            }
            is Map<*, *> -> JSONObject().apply {
                value.forEach { (k, v) -> put(k.toString(), toJsonValue(v)) }
            }
            else -> {
                // Serialize complex objects recursively
                val jsonObject = JSONObject()
                val clazz = value::class.java
                jsonObject.put("__type", clazz.name)
                clazz.declaredFields.forEach { field ->
                    if (!java.lang.reflect.Modifier.isStatic(field.modifiers) &&
                        !java.lang.reflect.Modifier.isTransient(field.modifiers)) {
                        field.isAccessible = true
                        try {
                            jsonObject.put(field.name, toJsonValue(field.get(value)))
                        } catch (e: Exception) {
                            // Skip fields that can't be accessed
                        }
                    }
                }
                jsonObject
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> deserializeObject(json: String, type: Class<T>): T {
        val jsonObject = JSONObject(json)

        // Try to use the type information stored in the JSON if available
        val storedType = jsonObject.optString("__type", null)
        val actualType = if (storedType != null && storedType.isNotEmpty()) {
            try {
                Class.forName(storedType) as Class<T>
            } catch (e: ClassNotFoundException) {
                type
            }
        } else {
            type
        }

        // Create instance using no-arg constructor or unsafe allocation
        val instance = try {
            actualType.getDeclaredConstructor().apply { isAccessible = true }.newInstance()
        } catch (e: Exception) {
            // Fall back to unsafe allocation for classes without no-arg constructor
            val unsafeClass = Class.forName("sun.misc.Unsafe")
            val unsafeField = unsafeClass.getDeclaredField("theUnsafe")
            unsafeField.isAccessible = true
            val unsafe = unsafeField.get(null)
            val allocateMethod = unsafeClass.getMethod("allocateInstance", Class::class.java)
            allocateMethod.invoke(unsafe, actualType) as T
        }

        // Set fields from JSON
        actualType.declaredFields.forEach { field ->
            if (!java.lang.reflect.Modifier.isStatic(field.modifiers) &&
                !java.lang.reflect.Modifier.isTransient(field.modifiers) &&
                jsonObject.has(field.name)) {
                field.isAccessible = true
                try {
                    val value = deserializeElement(jsonObject.get(field.name), field.type)
                    field.set(instance, value)
                } catch (e: Exception) {
                    // Skip fields that can't be set
                }
            }
        }

        return instance
    }

    private fun deserializeElement(value: Any?, type: Type): Any? {
        return when {
            value == null || value == JSONObject.NULL -> null
            type is Class<*> -> {
                when {
                    type == String::class.java -> value.toString()
                    type == Int::class.java || type == Integer::class.java -> (value as Number).toInt()
                    type == Long::class.java || type == java.lang.Long::class.java -> (value as Number).toLong()
                    type == Double::class.java || type == java.lang.Double::class.java -> (value as Number).toDouble()
                    type == Float::class.java || type == java.lang.Float::class.java -> (value as Number).toFloat()
                    type == Boolean::class.java || type == java.lang.Boolean::class.java -> value as Boolean
                    type == Byte::class.java || type == java.lang.Byte::class.java -> (value as Number).toByte()
                    type == Short::class.java || type == java.lang.Short::class.java -> (value as Number).toShort()
                    // toJsonValue widens a Char to a String on the way out, so the element
                    // path has to narrow it back. Without this case the String was handed
                    // back unchanged: a generic container read as Map<String, Char> or
                    // List<Char> threw ClassCastException, and a Char field of a
                    // deserialized object was left at its default value because the
                    // field.set type mismatch is swallowed.
                    type == Char::class.java || type == Character::class.java ->
                        value.toString().firstOrNull() ?: '\u0000'
                    value is JSONObject && value.optString("__type", "") in listOf("bytes", "[B") && value.has("__value") -> {
                        Base64.getDecoder().decode(value.getString("__value"))
                    }
                    value is JSONObject -> deserializeObject(value.toString(), type)
                    value is JSONArray -> {
                        if (type.isArray) {
                            val componentType = type.componentType
                            val array = java.lang.reflect.Array.newInstance(componentType, value.length())
                            for (i in 0 until value.length()) {
                                java.lang.reflect.Array.set(array, i, deserializeElement(value.get(i), componentType))
                            }
                            array
                        } else {
                            (0 until value.length()).map { value.get(it) }
                        }
                    }
                    else -> value
                }
            }
            type is ParameterizedType -> deserialize(JSONObject.wrap(value).toString(), type)
            else -> value
        }
    }
}
