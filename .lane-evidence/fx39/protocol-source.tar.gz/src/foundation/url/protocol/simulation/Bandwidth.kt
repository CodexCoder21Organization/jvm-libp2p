package foundation.url.protocol.simulation

import java.util.concurrent.CompletableFuture

/**
 * Represents network bandwidth as bytes per second.
 *
 * This class provides conversion utilities and is used by BandwidthDelayer
 * to calculate transmission delays based on message size.
 *
 * Example:
 * ```kotlin
 * val bandwidth = Bandwidth.mbps(100)  // 100 Mbps
 * val transmitTime = bandwidth.transmitTimeMs(1_000_000)  // ~80ms for 1MB
 * ```
 */
data class Bandwidth(val bytesPerSecond: Long) {

    init {
        require(bytesPerSecond > 0) { "Bandwidth must be positive: $bytesPerSecond" }
    }

    /**
     * Calculates the time in milliseconds to transmit the given number of bytes.
     *
     * @param sizeBytes The number of bytes to transmit
     * @return The transmission time in milliseconds
     */
    fun transmitTimeMs(sizeBytes: Long): Long {
        if (bytesPerSecond == Long.MAX_VALUE) return 0
        return (sizeBytes * 1000) / bytesPerSecond
    }

    /**
     * Calculates the number of bytes that can be transmitted in the given time.
     *
     * @param timeMs The time available in milliseconds
     * @return The number of bytes that can be transmitted
     */
    fun bytesInTime(timeMs: Long): Long {
        if (bytesPerSecond == Long.MAX_VALUE) return Long.MAX_VALUE
        return (bytesPerSecond * timeMs) / 1000
    }

    /**
     * Returns a bandwidth that is a fraction of this bandwidth.
     *
     * @param divisor The divisor (e.g., 2 for half bandwidth)
     * @return A new Bandwidth with reduced capacity
     */
    operator fun div(divisor: Int): Bandwidth {
        require(divisor > 0) { "Divisor must be positive: $divisor" }
        return Bandwidth(bytesPerSecond / divisor)
    }

    /**
     * Returns a bandwidth that is a multiple of this bandwidth.
     *
     * @param multiplier The multiplier
     * @return A new Bandwidth with increased capacity
     */
    operator fun times(multiplier: Int): Bandwidth {
        require(multiplier > 0) { "Multiplier must be positive: $multiplier" }
        return Bandwidth(bytesPerSecond * multiplier)
    }

    override fun toString(): String {
        return when {
            bytesPerSecond >= 125_000_000 -> "${bytesPerSecond / 125_000_000} Gbps"
            bytesPerSecond >= 125_000 -> "${bytesPerSecond / 125_000} Mbps"
            bytesPerSecond >= 125 -> "${bytesPerSecond / 125} Kbps"
            else -> "$bytesPerSecond B/s"
        }
    }

    companion object {
        /**
         * Unlimited bandwidth - no delay regardless of message size.
         */
        val UNLIMITED = Bandwidth(Long.MAX_VALUE)

        /**
         * Creates a Bandwidth from megabits per second.
         *
         * @param mbitsPerSecond Megabits per second (e.g., 100 for 100 Mbps)
         * @return A Bandwidth instance
         */
        fun mbps(mbitsPerSecond: Int): Bandwidth {
            require(mbitsPerSecond > 0) { "Mbps must be positive: $mbitsPerSecond" }
            // 1 Mbps = 1,000,000 bits/s = 125,000 bytes/s
            return Bandwidth(mbitsPerSecond.toLong() * 125_000)
        }

        /**
         * Creates a Bandwidth from kilobits per second.
         *
         * @param kbitsPerSecond Kilobits per second (e.g., 56 for dial-up)
         * @return A Bandwidth instance
         */
        fun kbps(kbitsPerSecond: Int): Bandwidth {
            require(kbitsPerSecond > 0) { "Kbps must be positive: $kbitsPerSecond" }
            // 1 Kbps = 1,000 bits/s = 125 bytes/s
            return Bandwidth(kbitsPerSecond.toLong() * 125)
        }

        /**
         * Creates a Bandwidth from gigabits per second.
         *
         * @param gbitsPerSecond Gigabits per second
         * @return A Bandwidth instance
         */
        fun gbps(gbitsPerSecond: Int): Bandwidth {
            require(gbitsPerSecond > 0) { "Gbps must be positive: $gbitsPerSecond" }
            // 1 Gbps = 1,000,000,000 bits/s = 125,000,000 bytes/s
            return Bandwidth(gbitsPerSecond.toLong() * 125_000_000)
        }

        /**
         * Creates a Bandwidth from bytes per second directly.
         *
         * @param bytesPerSecond Bytes per second
         * @return A Bandwidth instance
         */
        fun bytesPerSec(bytesPerSecond: Long): Bandwidth {
            require(bytesPerSecond > 0) { "Bytes per second must be positive: $bytesPerSecond" }
            return Bandwidth(bytesPerSecond)
        }
    }
}

/**
 * A MessageDelayer that simulates bandwidth-limited transmission.
 *
 * The delay is calculated based on message size and bandwidth:
 * delay_ms = (message_size_bytes * 1000) / bandwidth_bytes_per_second
 *
 * Example:
 * ```kotlin
 * val clock = SimulationClock()
 * val delayer = BandwidthDelayer(Bandwidth.mbps(10), clock) // 10 Mbps
 *
 * // 1 MB at 10 Mbps = 800ms
 * delayer.delay(1_000_000)
 * clock.advanceTime(800) // Now the future completes
 * ```
 */
class BandwidthDelayer(
    val bandwidth: Bandwidth,
    val clock: SimulationClock
) : MessageDelayer {

    /**
     * Calculates and applies the delay for transmitting a message of the given size.
     *
     * @param sizeBytes The message size in bytes
     * @return A CompletableFuture that completes when transmission would finish
     */
    override fun delay(sizeBytes: Long): CompletableFuture<Unit> {
        val transmitTime = bandwidth.transmitTimeMs(sizeBytes)
        if (transmitTime <= 0) {
            return CompletableFuture.completedFuture(Unit)
        }
        return clock.scheduleAfter(transmitTime)
    }

    override fun toString(): String = "BandwidthDelayer($bandwidth)"
}

/**
 * Extension to combine bandwidth limiting with base latency.
 *
 * This creates a delayer that applies both a fixed latency component
 * and a bandwidth-based component (like real network conditions).
 *
 * Total delay = base_latency + (size / bandwidth)
 *
 * @param baseLatencyMs Fixed latency component (e.g., propagation delay)
 * @return A MessageDelayer combining both delay components
 */
fun BandwidthDelayer.withLatency(baseLatencyMs: Long): MessageDelayer {
    require(baseLatencyMs >= 0) { "Base latency must be non-negative: $baseLatencyMs" }
    val bandwidthDelayer = this
    return MessageDelayer { sizeBytes ->
        val transmitTime = bandwidthDelayer.bandwidth.transmitTimeMs(sizeBytes)
        val totalDelay = baseLatencyMs + transmitTime
        if (totalDelay <= 0) {
            CompletableFuture.completedFuture(Unit)
        } else {
            bandwidthDelayer.clock.scheduleAfter(totalDelay)
        }
    }
}
