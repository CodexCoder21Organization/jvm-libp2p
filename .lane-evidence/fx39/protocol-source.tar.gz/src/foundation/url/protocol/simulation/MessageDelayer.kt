package foundation.url.protocol.simulation

import java.util.Random
import java.util.concurrent.CompletableFuture

/**
 * Abstraction for delaying message delivery in network simulation.
 *
 * MessageDelayer is a functional interface that takes a message size (in bytes)
 * and returns a CompletableFuture that completes when the delay has elapsed.
 * This allows for composable, chainable delay operations.
 *
 * Example:
 * ```kotlin
 * val delayer = MessageDelayer.constant(clock, 100) // 100ms delay
 * delayer.delay(1024).thenAccept { println("Message delivered!") }
 * clock.advanceTime(100) // Future completes
 * ```
 */
fun interface MessageDelayer {

    /**
     * Delays delivery of a message of the given size.
     *
     * @param sizeBytes The size of the message in bytes (may affect delay for bandwidth-based delayers)
     * @return A CompletableFuture that completes when the delay expires
     */
    fun delay(sizeBytes: Long): CompletableFuture<Unit>

    companion object {
        /**
         * A delayer that introduces no delay - completes immediately.
         */
        val NO_DELAY = MessageDelayer { CompletableFuture.completedFuture(Unit) }

        /**
         * Creates a delayer with a constant delay, regardless of message size.
         *
         * @param clock The simulation clock to use for scheduling
         * @param delayMs The constant delay in milliseconds
         * @return A MessageDelayer that always delays by the specified amount
         */
        fun constant(clock: SimulationClock, delayMs: Long): MessageDelayer {
            require(delayMs >= 0) { "Delay must be non-negative: $delayMs" }
            if (delayMs == 0L) return NO_DELAY

            return MessageDelayer { _ ->
                clock.scheduleAfter(delayMs)
            }
        }

        /**
         * Creates a delayer with randomized delay within a range.
         *
         * @param clock The simulation clock to use for scheduling
         * @param minMs Minimum delay in milliseconds (inclusive)
         * @param maxMs Maximum delay in milliseconds (inclusive)
         * @param random Random instance for reproducible results (use seeded Random)
         * @return A MessageDelayer that delays by a random amount in the given range
         */
        fun randomized(
            clock: SimulationClock,
            minMs: Long,
            maxMs: Long,
            random: Random
        ): MessageDelayer {
            require(minMs >= 0) { "Minimum delay must be non-negative: $minMs" }
            require(maxMs >= minMs) { "Maximum delay must be >= minimum: $maxMs < $minMs" }

            if (minMs == maxMs) return constant(clock, minMs)

            return MessageDelayer { _ ->
                val delay = minMs + random.nextLong(maxMs - minMs + 1).coerceAtLeast(0)
                clock.scheduleAfter(delay)
            }
        }

        /**
         * Creates a delayer that chains two delayers sequentially.
         *
         * @param first The first delayer to apply
         * @param second The second delayer to apply after the first completes
         * @return A MessageDelayer that applies both delays in sequence
         */
        fun chained(first: MessageDelayer, second: MessageDelayer): MessageDelayer {
            return MessageDelayer { sizeBytes ->
                first.delay(sizeBytes).thenCompose { second.delay(sizeBytes) }
            }
        }

        /**
         * Creates a delayer that applies delays in parallel and completes when both finish.
         *
         * This is useful for simulating bidirectional operations where both
         * directions have independent delays.
         *
         * @param delayer1 First delayer
         * @param delayer2 Second delayer
         * @return A MessageDelayer that waits for both delays to complete
         */
        fun parallel(delayer1: MessageDelayer, delayer2: MessageDelayer): MessageDelayer {
            return MessageDelayer { sizeBytes ->
                CompletableFuture.allOf(
                    delayer1.delay(sizeBytes),
                    delayer2.delay(sizeBytes)
                ).thenApply { }
            }
        }
    }
}

/**
 * Extension to apply jitter to an existing delayer.
 *
 * @param jitterMs Range of jitter to add (can be negative to subtract)
 * @param random Random instance for reproducibility
 * @return A new delayer that adds random jitter to the base delay
 */
fun MessageDelayer.withJitter(
    clock: SimulationClock,
    jitterMs: LongRange,
    random: Random
): MessageDelayer {
    val base = this
    return MessageDelayer { sizeBytes ->
        base.delay(sizeBytes).thenCompose {
            val jitter = jitterMs.first + random.nextLong(jitterMs.last - jitterMs.first + 1).coerceAtLeast(0)
            if (jitter > 0) {
                clock.scheduleAfter(jitter)
            } else {
                CompletableFuture.completedFuture(Unit)
            }
        }
    }
}

/**
 * Extension to add packet loss probability to a delayer.
 *
 * @param lossRate Probability of packet loss (0.0 to 1.0)
 * @param random Random instance for reproducibility
 * @return A new delayer that may fail with PacketLossException
 */
fun MessageDelayer.withPacketLoss(
    lossRate: Double,
    random: Random
): MessageDelayer {
    require(lossRate in 0.0..1.0) { "Loss rate must be between 0.0 and 1.0: $lossRate" }
    if (lossRate == 0.0) return this

    val base = this
    return MessageDelayer { sizeBytes ->
        if (random.nextDouble() < lossRate) {
            CompletableFuture<Unit>().also {
                it.completeExceptionally(PacketLossException("Packet dropped (loss rate: $lossRate)"))
            }
        } else {
            base.delay(sizeBytes)
        }
    }
}

/**
 * Exception indicating a simulated packet was dropped.
 */
class PacketLossException(message: String) : Exception(message)
