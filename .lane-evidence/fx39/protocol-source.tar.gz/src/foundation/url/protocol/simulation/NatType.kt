package foundation.url.protocol.simulation

/**
 * Types of Network Address Translation (NAT) configurations.
 *
 * NAT type affects how peers can connect to each other:
 * - OPEN: Fully reachable, no NAT (public IP)
 * - FULL_CONE: Most permissive NAT, reachable after any outbound connection
 * - RESTRICTED_CONE: Only reachable from addresses the peer has contacted
 * - PORT_RESTRICTED: Only reachable from address:port pairs the peer has contacted
 * - SYMMETRIC: Most restrictive, requires relay for all inbound connections
 *
 * @see <a href="https://en.wikipedia.org/wiki/Network_address_translation#Methods_of_translation">NAT Types</a>
 */
enum class NatType {
    /**
     * No NAT - the peer has a public IP address and is directly reachable.
     *
     * Inbound connections: Always allowed
     * Use case: Servers, cloud instances, VPS
     */
    OPEN,

    /**
     * Full Cone NAT - any external host can send packets to the mapped port.
     *
     * Once the NAT establishes a mapping (from any outbound packet), any external
     * host can use that mapping to send packets inbound.
     *
     * Inbound connections: Allowed after any outbound packet
     * Use case: Some consumer routers, gaming routers
     */
    FULL_CONE,

    /**
     * Restricted Cone NAT - only hosts the internal peer has sent to can respond.
     *
     * The NAT only forwards inbound packets from IP addresses that the internal
     * host has previously sent packets to (regardless of port).
     *
     * Inbound connections: Allowed only from contacted IP addresses
     * Use case: Most consumer routers
     */
    RESTRICTED_CONE,

    /**
     * Port Restricted Cone NAT - stricter than restricted cone.
     *
     * The NAT only forwards inbound packets from IP:port pairs that the internal
     * host has previously sent packets to.
     *
     * Inbound connections: Allowed only from contacted IP:port pairs
     * Use case: Stricter consumer routers, some enterprise routers
     */
    PORT_RESTRICTED,

    /**
     * Symmetric NAT - the most restrictive type.
     *
     * A different external mapping is used for each destination IP:port pair.
     * This makes NAT traversal very difficult without a relay.
     *
     * Inbound connections: Only via relay
     * Use case: Enterprise networks, carrier-grade NAT (CGNAT)
     */
    SYMMETRIC;

    /**
     * Returns true if this NAT type requires a relay for inbound connections.
     */
    fun requiresRelay(): Boolean = this == SYMMETRIC

    /**
     * Returns true if this NAT type allows direct inbound connections
     * after an initial outbound connection has been established.
     */
    fun allowsDirectAfterOutbound(): Boolean = when (this) {
        OPEN -> true
        FULL_CONE -> true
        RESTRICTED_CONE -> true
        PORT_RESTRICTED -> true
        SYMMETRIC -> false
    }

    /**
     * Returns true if this peer is directly reachable without any prior contact.
     */
    fun isPubliclyReachable(): Boolean = this == OPEN
}
