package foundation.url.protocol.simulation

import java.io.IOException
import java.util.Random
import java.util.concurrent.CompletableFuture
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * A simulated bidirectional connection between two peers.
 *
 * SimulatedConnection models network conditions for messages sent between
 * two SimulatedPeers, including:
 * - Latency (with optional jitter)
 * - Bandwidth limiting
 * - Packet loss
 * - Connection lifecycle (open/closed)
 *
 * Example:
 * ```kotlin
 * val clock = SimulationClock()
 * val connection = SimulatedConnection(peer1, peer2, clock)
 * connection.send("Hello".toByteArray()).thenAccept {
 *     println("Message delivered!")
 * }
 * clock.advanceTime(100) // Advance time to complete delivery
 * ```
 */
class SimulatedConnection(
    /**
     * The source peer (connection initiator).
     */
    val source: SimulatedPeer,

    /**
     * The target peer (connection acceptor).
     */
    val target: SimulatedPeer,

    /**
     * The simulation clock for scheduling delays.
     */
    private val clock: SimulationClock,

    /**
     * Random instance for packet loss and jitter decisions.
     */
    private val random: Random = Random(0),

    /**
     * Base latency for this connection in milliseconds.
     * If not specified, uses the source peer's latency.
     */
    private val latencyMs: Long = source.latencyMs
) {

    private val _isOpen = AtomicBoolean(true)
    private val messagesSent = AtomicLong(0)
    private val messagesReceived = AtomicLong(0)
    private val bytesTransferred = AtomicLong(0)
    private val messageLog = CopyOnWriteArrayList<MessageRecord>()

    /**
     * Whether this connection is currently open.
     */
    val isOpen: Boolean get() = _isOpen.get()

    /**
     * Total number of messages sent on this connection.
     */
    val sentCount: Long get() = messagesSent.get()

    /**
     * Total number of messages successfully received.
     */
    val receivedCount: Long get() = messagesReceived.get()

    /**
     * Total bytes transferred on this connection.
     */
    val totalBytesTransferred: Long get() = bytesTransferred.get()

    /**
     * Creates a MessageDelayer for this connection based on both peers' conditions.
     *
     * The delayer combines:
     * - Source's outbound bandwidth
     * - Connection latency
     * - Target's inbound bandwidth
     */
    private fun createDelayer(): MessageDelayer {
        // Outbound bandwidth limit
        val outboundDelayer = BandwidthDelayer(source.outboundBandwidth, clock)

        // Connection latency
        val latencyDelayer = MessageDelayer.constant(clock, latencyMs)

        // Inbound bandwidth limit
        val inboundDelayer = BandwidthDelayer(target.inboundBandwidth, clock)

        // Chain them: outbound -> latency -> inbound
        return MessageDelayer.chained(
            MessageDelayer.chained(outboundDelayer, latencyDelayer),
            inboundDelayer
        )
    }

    /**
     * Sends a message from source to target.
     *
     * The message goes through:
     * 1. Packet loss check (may be dropped)
     * 2. Outbound bandwidth delay at source
     * 3. Latency delay
     * 4. Inbound bandwidth delay at target
     *
     * @param payload The message payload
     * @return A CompletableFuture that completes when the message is delivered,
     *         or fails with PacketLossException if dropped
     */
    fun send(payload: ByteArray): CompletableFuture<Unit> {
        if (!isOpen) {
            return CompletableFuture<Unit>().also {
                it.completeExceptionally(IOException("Connection is closed"))
            }
        }

        if (!source.isOnline) {
            return CompletableFuture<Unit>().also {
                it.completeExceptionally(IOException("Source peer is offline"))
            }
        }

        if (!target.isOnline) {
            return CompletableFuture<Unit>().also {
                it.completeExceptionally(IOException("Target peer is offline"))
            }
        }

        messagesSent.incrementAndGet()

        // Check packet loss at source
        if (random.nextDouble() < source.packetLossRate) {
            return CompletableFuture<Unit>().also {
                it.completeExceptionally(PacketLossException("Packet dropped at source (loss rate: ${source.packetLossRate})"))
            }
        }

        val sendTime = clock.currentTimeMillis()
        val delayer = createDelayer()

        return delayer.delay(payload.size.toLong()).thenApply {
            // Record successful delivery
            messagesReceived.incrementAndGet()
            bytesTransferred.addAndGet(payload.size.toLong())

            val deliveryTime = clock.currentTimeMillis()
            messageLog.add(MessageRecord(
                sendTime = sendTime,
                deliveryTime = deliveryTime,
                sizeBytes = payload.size.toLong(),
                success = true
            ))

            // Record contact for NAT simulation
            source.recordContact(target.peerId)
            target.recordInboundContact(source.peerId)
        }
    }

    /**
     * Sends a message and waits for delivery (blocking in simulation time).
     *
     * This is a convenience method that sends the message and advances
     * simulation time until delivery completes.
     *
     * @param payload The message payload
     * @param maxDelayMs Maximum time to wait for delivery
     * @return True if delivered successfully, false if failed
     */
    fun sendAndWait(payload: ByteArray, maxDelayMs: Long = 60_000): Boolean {
        val future = send(payload)

        // Advance time in steps until delivery or timeout
        var elapsed = 0L
        val step = 10L
        while (!future.isDone && elapsed < maxDelayMs) {
            clock.advanceTime(step)
            elapsed += step
        }

        return future.isDone && !future.isCompletedExceptionally
    }

    /**
     * Closes this connection.
     */
    fun close() {
        _isOpen.set(false)
    }

    /**
     * Reopens a closed connection.
     */
    fun reopen() {
        _isOpen.set(true)
    }

    /**
     * Gets the message log for this connection.
     */
    fun getMessageLog(): List<MessageRecord> = messageLog.toList()

    /**
     * Clears the message log.
     */
    fun clearLog() {
        messageLog.clear()
    }

    /**
     * Calculates the average latency for delivered messages.
     */
    fun averageLatencyMs(): Double {
        val delivered = messageLog.filter { it.success }
        if (delivered.isEmpty()) return 0.0
        return delivered.map { it.deliveryTime - it.sendTime }.average()
    }

    override fun toString(): String {
        return "SimulatedConnection(${source.peerId} -> ${target.peerId}, open=$isOpen, sent=$sentCount, received=$receivedCount)"
    }

    /**
     * Record of a message sent on this connection.
     */
    data class MessageRecord(
        val sendTime: Long,
        val deliveryTime: Long,
        val sizeBytes: Long,
        val success: Boolean
    ) {
        val latencyMs: Long get() = deliveryTime - sendTime
    }
}

/**
 * Creates a bidirectional connection pair between two peers.
 *
 * @param peer1 First peer
 * @param peer2 Second peer
 * @param clock Simulation clock
 * @param latencyMs Latency for both directions
 * @param random Random instance for packet loss decisions
 * @return A pair of connections (peer1->peer2, peer2->peer1)
 */
fun createBidirectionalConnection(
    peer1: SimulatedPeer,
    peer2: SimulatedPeer,
    clock: SimulationClock,
    latencyMs: Long = 10,
    random: Random = Random(0)
): Pair<SimulatedConnection, SimulatedConnection> {
    return Pair(
        SimulatedConnection(peer1, peer2, clock, random, latencyMs),
        SimulatedConnection(peer2, peer1, clock, random, latencyMs)
    )
}
