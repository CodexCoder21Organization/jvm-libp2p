package foundation.url.protocol.simulation

import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Orchestrates a simulated P2P network for testing.
 *
 * SimulatedNetwork manages:
 * - Peer creation with configurable network conditions
 * - Network topologies (full mesh, star, random, clustered)
 * - NAT scenarios (public, NAT'd, relay peers)
 * - Network partitioning and healing
 * - Time advancement across all peers
 *
 * Example:
 * ```kotlin
 * val clock = SimulationClock()
 * val network = SimulatedNetwork(clock, Random(42))
 *
 * // Create a NAT scenario
 * val scenario = network.createNatScenario(publicCount = 2, natCount = 3, relayCount = 1)
 *
 * // Advance time to let gossip propagate
 * network.advanceTimeMs(5000)
 *
 * // Partition the network
 * network.partition(group1 = setOf("peer1", "peer2"), group2 = setOf("peer3", "peer4"))
 * ```
 */
class SimulatedNetwork(
    /**
     * The simulation clock used by all peers in this network.
     */
    val clock: SimulationClock,

    /**
     * Random instance for reproducible network behavior.
     * Use a seeded Random for deterministic tests.
     */
    val random: Random = Random(0)
) {

    private val peers = ConcurrentHashMap<String, SimulatedPeer>()
    private val connections = CopyOnWriteArrayList<SimulatedConnection>()
    private val partitions = CopyOnWriteArrayList<Set<String>>()

    private var peerCounter = 0

    /**
     * Gets all peers in this network.
     */
    fun getAllPeers(): List<SimulatedPeer> = peers.values.toList()

    /**
     * Gets a peer by ID.
     */
    fun getPeer(peerId: String): SimulatedPeer? = peers[peerId]

    /**
     * Gets all connections in this network.
     */
    fun getAllConnections(): List<SimulatedConnection> = connections.toList()

    // ========================================================================
    // Peer Creation
    // ========================================================================

    /**
     * Creates a new peer with the specified configuration.
     */
    fun createPeer(
        id: String = "Peer${++peerCounter}",
        services: List<String> = emptyList(),
        natType: NatType = NatType.OPEN,
        latencyMs: Long = 10,
        bandwidthMbps: Int = 100,
        packetLossRate: Double = 0.0,
        jitterMs: LongRange = 0L..0L
    ): SimulatedPeer {
        val peer = SimulatedPeer.create(
            id = id,
            clock = clock,
            services = services,
            natType = natType,
            latencyMs = latencyMs,
            packetLossRate = packetLossRate,
            random = Random(random.nextLong())
        ).apply {
            this.inboundBandwidth = Bandwidth.mbps(bandwidthMbps)
            this.outboundBandwidth = Bandwidth.mbps(bandwidthMbps)
            this.jitterMs = jitterMs
        }

        peers[peer.peerId] = peer
        return peer
    }

    /**
     * Removes a peer from the network.
     */
    fun removePeer(peerId: String) {
        peers.remove(peerId)
        // Remove all connections involving this peer
        connections.removeIf { it.source.peerId == peerId || it.target.peerId == peerId }
    }

    // ========================================================================
    // Connection Management
    // ========================================================================

    /**
     * Creates a connection between two peers.
     *
     * This creates a unidirectional connection from peer1 to peer2.
     * For bidirectional communication, call this twice or use connectBidirectional.
     */
    fun connect(
        peer1: SimulatedPeer,
        peer2: SimulatedPeer,
        latencyMs: Long = 10
    ): SimulatedConnection {
        val connection = SimulatedConnection(
            source = peer1,
            target = peer2,
            clock = clock,
            random = Random(random.nextLong()),
            latencyMs = latencyMs
        )

        connections.add(connection)

        // Add to each peer's known peers
        peer1.addKnownPeer(peer2)
        peer2.addKnownPeer(peer1)

        // Record contact for NAT simulation
        peer1.recordContact(peer2.peerId)
        peer2.recordInboundContact(peer1.peerId)

        return connection
    }

    /**
     * Creates bidirectional connections between two peers.
     */
    fun connectBidirectional(
        peer1: SimulatedPeer,
        peer2: SimulatedPeer,
        latencyMs: Long = 10
    ): Pair<SimulatedConnection, SimulatedConnection> {
        val conn1 = connect(peer1, peer2, latencyMs)
        val conn2 = connect(peer2, peer1, latencyMs)
        return Pair(conn1, conn2)
    }

    /**
     * Disconnects two peers by closing all connections between them.
     */
    fun disconnect(peer1: SimulatedPeer, peer2: SimulatedPeer) {
        connections.filter {
            (it.source.peerId == peer1.peerId && it.target.peerId == peer2.peerId) ||
            (it.source.peerId == peer2.peerId && it.target.peerId == peer1.peerId)
        }.forEach { it.close() }

        peer1.removeKnownPeer(peer2.peerId)
        peer2.removeKnownPeer(peer1.peerId)
    }

    // ========================================================================
    // Topology Builders
    // ========================================================================

    /**
     * Creates a fully connected mesh of peers.
     *
     * Every peer is connected to every other peer with bidirectional connections.
     * Total connections: n * (n-1) where n is the peer count.
     */
    fun createFullMesh(
        count: Int,
        latencyMs: Long = 10,
        services: List<String> = emptyList()
    ): List<SimulatedPeer> {
        val peers = (1..count).map { i ->
            createPeer(
                id = "Mesh$i",
                services = if (services.isEmpty()) listOf("mesh.service.$i") else services,
                latencyMs = latencyMs
            )
        }

        // Connect each pair bidirectionally
        for (i in peers.indices) {
            for (j in i + 1 until peers.size) {
                connectBidirectional(peers[i], peers[j], latencyMs)
            }
        }

        return peers
    }

    /**
     * Creates a star topology with one hub and multiple satellites.
     *
     * The hub is connected to all satellites, but satellites are not
     * connected to each other (they must route through the hub).
     */
    fun createStarTopology(
        satellites: Int,
        latencyToHubMs: Long = 5
    ): Pair<SimulatedPeer, List<SimulatedPeer>> {
        val hub = createPeer(
            id = "Hub",
            services = listOf("hub.service"),
            latencyMs = latencyToHubMs
        )

        val satellitePeers = (1..satellites).map { i ->
            val satellite = createPeer(
                id = "Satellite$i",
                services = listOf("satellite.service.$i"),
                latencyMs = latencyToHubMs
            )
            connectBidirectional(hub, satellite, latencyToHubMs)
            satellite
        }

        return Pair(hub, satellitePeers)
    }

    /**
     * Creates a random topology where each peer has approximately
     * the specified number of connections.
     */
    fun createRandomTopology(
        count: Int,
        connectionsPerPeer: Int = 3,
        latencyMs: Long = 10
    ): List<SimulatedPeer> {
        val peers = (1..count).map { i ->
            createPeer(
                id = "Random$i",
                services = listOf("random.service.$i"),
                latencyMs = latencyMs
            )
        }

        // Each peer connects to approximately connectionsPerPeer other peers
        for (peer in peers) {
            val targets = peers.filter { it.peerId != peer.peerId }
                .shuffled(random)
                .take(connectionsPerPeer)

            for (target in targets) {
                // Only connect if not already connected
                if (connections.none {
                    (it.source.peerId == peer.peerId && it.target.peerId == target.peerId)
                }) {
                    connectBidirectional(peer, target, latencyMs)
                }
            }
        }

        return peers
    }

    /**
     * Creates a chain topology where peers are connected in sequence.
     *
     * Peer1 -> Peer2 -> Peer3 -> ... -> PeerN
     */
    fun createChain(
        count: Int,
        latencyMs: Long = 10
    ): List<SimulatedPeer> {
        val peers = (1..count).map { i ->
            createPeer(
                id = "Chain$i",
                services = listOf("chain.service.$i"),
                latencyMs = latencyMs
            )
        }

        for (i in 0 until peers.size - 1) {
            connectBidirectional(peers[i], peers[i + 1], latencyMs)
        }

        return peers
    }

    // ========================================================================
    // NAT Scenarios
    // ========================================================================

    /**
     * Creates a NAT scenario with public peers, NAT'd peers, and relay peers.
     *
     * @param publicCount Number of peers with public IPs (NatType.OPEN)
     * @param natCount Number of peers behind NAT (NatType.SYMMETRIC)
     * @param relayCount Number of relay peers (subset of public that act as relays)
     * @return A NatScenario containing the created peers
     */
    fun createNatScenario(
        publicCount: Int,
        natCount: Int,
        relayCount: Int
    ): NatScenario {
        require(relayCount <= publicCount) { "relayCount ($relayCount) cannot exceed publicCount ($publicCount)" }

        // Create public peers (some will be relays)
        val publicPeers = (1..publicCount).map { i ->
            createPeer(
                id = "Public$i",
                services = listOf("public.service.$i"),
                natType = NatType.OPEN,
                latencyMs = 10
            )
        }

        // First relayCount public peers are designated as relays
        val relayPeers = publicPeers.take(relayCount)

        // Create NAT'd peers
        val natPeers = (1..natCount).map { i ->
            createPeer(
                id = "NAT$i",
                services = listOf("nat.service.$i"),
                natType = NatType.SYMMETRIC,
                latencyMs = 20
            )
        }

        // Connect public peers to each other
        for (i in publicPeers.indices) {
            for (j in i + 1 until publicPeers.size) {
                connectBidirectional(publicPeers[i], publicPeers[j])
            }
        }

        // NAT'd peers connect to relays (outbound only initially)
        for (natPeer in natPeers) {
            for (relay in relayPeers) {
                // NAT peer initiates connection to relay
                connect(natPeer, relay)
                // Relay can now respond back
                connect(relay, natPeer)
            }
        }

        return NatScenario(
            publicPeers = publicPeers,
            natPeers = natPeers,
            relayPeers = relayPeers
        )
    }

    // ========================================================================
    // Network Partitioning
    // ========================================================================

    /**
     * Partitions the network into two isolated groups.
     *
     * All connections between peers in different groups are closed.
     * Peers within the same group can still communicate.
     */
    fun partition(group1: Set<String>, group2: Set<String>) {
        partitions.add(group1)
        partitions.add(group2)

        // Close connections between groups
        for (connection in connections) {
            val sourceInGroup1 = group1.contains(connection.source.peerId)
            val targetInGroup1 = group1.contains(connection.target.peerId)
            val sourceInGroup2 = group2.contains(connection.source.peerId)
            val targetInGroup2 = group2.contains(connection.target.peerId)

            // If source and target are in different groups, close the connection
            if ((sourceInGroup1 && targetInGroup2) || (sourceInGroup2 && targetInGroup1)) {
                connection.close()
            }
        }
    }

    /**
     * Heals all network partitions, reopening closed connections.
     */
    fun healAllPartitions() {
        partitions.clear()

        // Reopen all closed connections
        for (connection in connections) {
            if (!connection.isOpen) {
                connection.reopen()
            }
        }
    }

    /**
     * Checks if two peers can communicate (considering partitions).
     */
    fun canCommunicate(peerId1: String, peerId2: String): Boolean {
        val peer1 = peers[peerId1] ?: return false
        val peer2 = peers[peerId2] ?: return false

        if (!peer1.isOnline || !peer2.isOnline) return false

        // Check if they're in different partitions
        for (partition in partitions) {
            val peer1InPartition = partition.contains(peerId1)
            val peer2InPartition = partition.contains(peerId2)
            if (peer1InPartition != peer2InPartition) {
                // They're in different partitions, check if there's a relay path
                return hasRelayPath(peer1, peer2)
            }
        }

        // No partition separates them, check direct reachability
        if (peer2.isReachableFrom(peer1)) return true

        // Check for relay path
        return hasRelayPath(peer1, peer2)
    }

    /**
     * Checks if there's a relay path between two peers.
     */
    private fun hasRelayPath(source: SimulatedPeer, target: SimulatedPeer): Boolean {
        // Find a relay that both peers are connected to
        val relays = getAllPeers().filter { it.natType == NatType.OPEN && it.isOnline }

        for (relay in relays) {
            val sourceToRelay = connections.any {
                it.isOpen && it.source.peerId == source.peerId && it.target.peerId == relay.peerId
            }
            val relayToTarget = connections.any {
                it.isOpen && it.source.peerId == relay.peerId && it.target.peerId == target.peerId
            }

            if (sourceToRelay && relayToTarget) {
                return true
            }
        }

        return false
    }

    // ========================================================================
    // Time Management
    // ========================================================================

    /**
     * Advances simulation time by the specified duration.
     */
    fun advanceTimeMs(durationMs: Long) {
        clock.advanceTime(durationMs)
    }

    /**
     * Advances time until the network is quiet (no pending tasks).
     *
     * @param maxDurationMs Maximum time to advance (safety limit)
     * @param stepMs Time step for each advancement
     * @return The actual time elapsed
     */
    fun advanceUntilQuiet(maxDurationMs: Long = 60_000, stepMs: Long = 100): Long {
        val startTime = clock.currentTimeMillis()
        var elapsed = 0L

        while (elapsed < maxDurationMs && !clock.isIdle()) {
            clock.advanceTime(stepMs)
            elapsed += stepMs
        }

        return clock.currentTimeMillis() - startTime
    }

    // ========================================================================
    // Statistics
    // ========================================================================

    /**
     * Gets network statistics.
     */
    fun getStats(): NetworkStats {
        val allPeers = getAllPeers()
        val allConnections = getAllConnections()

        return NetworkStats(
            totalPeers = allPeers.size,
            onlinePeers = allPeers.count { it.isOnline },
            totalConnections = allConnections.size,
            openConnections = allConnections.count { it.isOpen },
            totalMessagesSent = allConnections.sumOf { it.sentCount },
            totalMessagesReceived = allConnections.sumOf { it.receivedCount },
            totalBytesTransferred = allConnections.sumOf { it.totalBytesTransferred },
            partitionCount = partitions.size
        )
    }

    /**
     * Clears all peers and connections.
     */
    fun clear() {
        peers.clear()
        connections.clear()
        partitions.clear()
        peerCounter = 0
    }

    override fun toString(): String {
        val stats = getStats()
        return "SimulatedNetwork(peers=${stats.totalPeers}, connections=${stats.totalConnections}, partitions=${stats.partitionCount})"
    }
}

/**
 * Result of creating a NAT scenario.
 */
data class NatScenario(
    val publicPeers: List<SimulatedPeer>,
    val natPeers: List<SimulatedPeer>,
    val relayPeers: List<SimulatedPeer>
)

/**
 * Network statistics.
 */
data class NetworkStats(
    val totalPeers: Int,
    val onlinePeers: Int,
    val totalConnections: Int,
    val openConnections: Int,
    val totalMessagesSent: Long,
    val totalMessagesReceived: Long,
    val totalBytesTransferred: Long,
    val partitionCount: Int
)
