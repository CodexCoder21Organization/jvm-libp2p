package foundation.url.protocol.simulation

import foundation.url.protocol.BootstrapPeer
import foundation.url.protocol.PeerAddressOwnership
import foundation.url.protocol.RendezvousInfo
import foundation.url.protocol.TestPeer
import org.json.JSONArray
import org.json.JSONObject
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * A simulated peer for network testing with configurable network conditions.
 *
 * SimulatedPeer wraps any BootstrapPeer and adds simulation capabilities:
 * - NAT type simulation (OPEN, FULL_CONE, RESTRICTED_CONE, SYMMETRIC)
 * - Configurable latency and jitter
 * - Packet loss simulation
 * - Bandwidth limiting
 * - Connection tracking for NAT behavior
 *
 * Uses delegation pattern: most BootstrapPeer methods are delegated to innerPeer,
 * while methods requiring simulation are overridden.
 *
 * Example:
 * ```kotlin
 * val clock = SimulationClock()
 * val basePeer = TestPeer.create("TestPeer1", listOf("my.service"))
 * val simPeer = SimulatedPeer(
 *     innerPeer = basePeer,
 *     clock = clock,
 *     natType = NatType.SYMMETRIC,
 *     latencyMs = 50,
 *     packetLossRate = 0.01
 * )
 * ```
 */
class SimulatedPeer(
    private val innerPeer: BootstrapPeer,
    private val clock: SimulationClock,
    private val random: Random = Random(0),

    /**
     * The NAT type for this peer. Affects inbound connection reachability.
     */
    val natType: NatType = NatType.OPEN,

    /**
     * Inbound bandwidth limit. Affects download speed.
     */
    var inboundBandwidth: Bandwidth = Bandwidth.UNLIMITED,

    /**
     * Outbound bandwidth limit. Affects upload speed.
     */
    var outboundBandwidth: Bandwidth = Bandwidth.UNLIMITED,

    /**
     * Base latency for all operations in milliseconds.
     */
    var latencyMs: Long = 0,

    /**
     * Jitter range to add to latency (random variation).
     * The actual jitter is drawn uniformly from this range.
     */
    var jitterMs: LongRange = 0L..0L,

    /**
     * Probability of packet loss (0.0 to 1.0).
     * A value of 0.1 means 10% of packets are dropped.
     */
    var packetLossRate: Double = 0.0
) : BootstrapPeer {

    private val addressOwnership = PeerAddressOwnership(innerPeer.multiaddresses)
    private val registryMetadata = AtomicReference<String?>(null)
    private val registryPeerId = AtomicReference<String?>(null)

    // Keep the concrete simulation object while accepting only registry-owned route/JSON values.
    internal fun retainRegistryAddresses(peerId: String, addresses: List<String>, metadata: String) {
        addressOwnership.retain(peerId, addresses)
        check(registryPeerId.compareAndSet(null, peerId) || registryPeerId.get() == peerId) {
            "Simulated peer identity '$peerId' differs from its previously accepted identity '${registryPeerId.get()}'"
        }
        registryMetadata.compareAndSet(null, metadata)
    }

    // Track peers this peer has contacted (for NAT simulation)
    private val contactedPeers = ConcurrentHashMap.newKeySet<String>()

    // Track peers that have contacted this peer (for restricted NAT)
    private val inboundContactedBy = ConcurrentHashMap.newKeySet<String>()

    // Online/offline state
    private val _isOnline = AtomicBoolean(true)

    // Services (copy from inner, but mutable)
    private val _services = CopyOnWriteArrayList(innerPeer.advertisedServices)

    // Last seen timestamp (mutable for simulation)
    private val _lastSeen = AtomicLong(innerPeer.lastSeenTimestamp)

    // Known peers for discovery
    private val knownPeers = CopyOnWriteArrayList<BootstrapPeer>()

    // ========================================================================
    // BootstrapPeer interface implementation
    // ========================================================================

    override val peerId: String get() = registryPeerId.get() ?: innerPeer.peerId

    override val multiaddresses: List<String> get() = addressOwnership.addresses

    override val advertisedServices: List<String> get() = _services.toList()

    override val lastSeenTimestamp: Long get() = _lastSeen.get()

    /**
     * Whether this peer is currently online (reachable).
     */
    var isOnline: Boolean
        get() = _isOnline.get()
        set(value) { _isOnline.set(value) }

    override fun ping(timeoutMs: Long): Boolean {
        // Simulate being offline
        if (!isOnline) return false

        // Simulate packet loss
        if (random.nextDouble() < packetLossRate) return false

        // Calculate total delay with jitter
        val jitter = if (jitterMs.isEmpty()) 0L else {
            jitterMs.first + random.nextLong(jitterMs.last - jitterMs.first + 1).coerceAtLeast(0)
        }
        val totalDelay = latencyMs + jitter

        // Check timeout
        if (totalDelay > timeoutMs) return false

        // Advance simulation time
        clock.advanceTime(totalDelay)

        // Update last seen
        _lastSeen.set(clock.currentTimeMillis())

        return true
    }

    override fun discoverPeers(maxPeers: Int): List<BootstrapPeer> {
        if (!isOnline) return emptyList()

        // Simulate network delay
        val jitter = if (jitterMs.isEmpty()) 0L else {
            jitterMs.first + random.nextLong(jitterMs.last - jitterMs.first + 1).coerceAtLeast(0)
        }
        clock.advanceTime(latencyMs + jitter)

        _lastSeen.set(clock.currentTimeMillis())

        // Return known peers (filtered to online ones if they're SimulatedPeers)
        return knownPeers
            .filter { peer ->
                (peer as? SimulatedPeer)?.isOnline ?: true
            }
            .take(maxPeers)
    }

    override fun requestIntroduction(targetPeerId: String): RendezvousInfo? {
        if (!isOnline) return null

        // Simulate network delay
        val jitter = if (jitterMs.isEmpty()) 0L else {
            jitterMs.first + random.nextLong(jitterMs.last - jitterMs.first + 1).coerceAtLeast(0)
        }
        clock.advanceTime(latencyMs + jitter)

        _lastSeen.set(clock.currentTimeMillis())

        // Find the target peer in known peers
        val targetPeer = knownPeers.find { it.peerId == targetPeerId }
        if (targetPeer == null) return null

        // Check if target is online
        if ((targetPeer as? SimulatedPeer)?.isOnline == false) return null

        val relayAddr = multiaddresses.firstOrNull() ?: return null

        return RendezvousInfo(
            relayPeerId = peerId,
            relayMultiaddress = relayAddr,
            reservationVoucher = "sim-voucher-${clock.currentTimeMillis()}",
            expiresAt = clock.currentTimeMillis() + 300_000, // 5 minutes
            circuitAddress = "/p2p/$peerId/p2p-circuit/p2p/$targetPeerId"
        )
    }

    override fun canRoute(serviceIdentifier: String): Boolean {
        if (!isOnline) return false
        if (serviceIdentifier.isBlank()) return false

        // Match is exact only. See PeerRegistry.findPeersForService for the rationale.
        return _services.contains(serviceIdentifier)
    }

    override fun toJson(): JSONObject {
        val metadata = registryMetadata.get()
        val json = if (metadata == null) innerPeer.toJson() else JSONObject(metadata).apply {
            put("peerId", peerId)
            put("multiaddresses", JSONArray(multiaddresses))
            put("advertisedServices", JSONArray(advertisedServices))
            put("lastSeenTimestamp", lastSeenTimestamp)
        }
        json.put("natType", natType.name)
        json.put("latencyMs", latencyMs)
        json.put("packetLossRate", packetLossRate)
        json.put("isOnline", isOnline)
        return json
    }

    // ========================================================================
    // Simulation-specific methods
    // ========================================================================

    /**
     * Checks if this peer is reachable from the given source peer.
     * Takes into account NAT type and prior contact history.
     *
     * @param source The peer trying to reach this peer
     * @return True if the source can directly connect to this peer
     */
    fun isReachableFrom(source: SimulatedPeer): Boolean {
        if (!isOnline) return false

        return when (natType) {
            NatType.OPEN -> true
            NatType.FULL_CONE -> {
                // Reachable if we've made any outbound connection
                contactedPeers.isNotEmpty()
            }
            NatType.RESTRICTED_CONE -> {
                // Reachable only from IPs we've contacted
                contactedPeers.contains(source.peerId)
            }
            NatType.PORT_RESTRICTED -> {
                // Reachable only from IPs we've contacted (simplified - same as restricted)
                contactedPeers.contains(source.peerId)
            }
            NatType.SYMMETRIC -> {
                // Never directly reachable, always needs relay
                false
            }
        }
    }

    /**
     * Records that this peer has contacted another peer.
     * This affects NAT traversal for restricted NAT types.
     *
     * @param otherPeerId The peer ID that was contacted
     */
    fun recordContact(otherPeerId: String) {
        contactedPeers.add(otherPeerId)
    }

    /**
     * Records that another peer has contacted this peer.
     *
     * @param otherPeerId The peer ID that initiated contact
     */
    fun recordInboundContact(otherPeerId: String) {
        inboundContactedBy.add(otherPeerId)
    }

    /**
     * Adds a service to this peer's advertised services.
     */
    fun addService(service: String) {
        if (!_services.contains(service)) {
            _services.add(service)
        }
    }

    /**
     * Removes a service from this peer's advertised services.
     */
    fun removeService(service: String) {
        _services.remove(service)
    }

    /**
     * Adds a known peer for discovery.
     */
    fun addKnownPeer(peer: BootstrapPeer) {
        if (knownPeers.none { it.peerId == peer.peerId }) {
            knownPeers.add(peer)
        }
    }

    /**
     * Removes a known peer.
     */
    fun removeKnownPeer(peerId: String) {
        knownPeers.removeIf { it.peerId == peerId }
    }

    /**
     * Gets all known peers.
     */
    fun getKnownPeers(): List<BootstrapPeer> = knownPeers.toList()

    /**
     * Clears the contact history (for testing NAT behavior).
     */
    fun clearContactHistory() {
        contactedPeers.clear()
        inboundContactedBy.clear()
    }

    /**
     * Creates a MessageDelayer based on this peer's network conditions.
     */
    fun createDelayer(): MessageDelayer {
        var delayer: MessageDelayer = BandwidthDelayer(outboundBandwidth, clock)

        // Add base latency
        if (latencyMs > 0) {
            delayer = MessageDelayer.chained(
                MessageDelayer.constant(clock, latencyMs),
                delayer
            )
        }

        // Add jitter
        if (!jitterMs.isEmpty() && jitterMs.last > 0) {
            delayer = delayer.withJitter(clock, jitterMs, random)
        }

        // Add packet loss
        if (packetLossRate > 0.0) {
            delayer = delayer.withPacketLoss(packetLossRate, random)
        }

        return delayer
    }

    override fun toString(): String {
        return "SimulatedPeer(id=$peerId, nat=$natType, online=$isOnline, latency=${latencyMs}ms)"
    }

    companion object {
        /**
         * Creates a SimulatedPeer wrapping a new TestPeer.
         */
        fun create(
            id: String,
            clock: SimulationClock,
            services: List<String> = emptyList(),
            natType: NatType = NatType.OPEN,
            latencyMs: Long = 0,
            packetLossRate: Double = 0.0,
            random: Random = Random(0)
        ): SimulatedPeer {
            val testPeer = TestPeer.create(id, services, online = true)
            return SimulatedPeer(
                innerPeer = testPeer,
                clock = clock,
                random = random,
                natType = natType,
                latencyMs = latencyMs,
                packetLossRate = packetLossRate
            )
        }
    }
}
