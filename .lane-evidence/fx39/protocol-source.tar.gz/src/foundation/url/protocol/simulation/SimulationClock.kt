package foundation.url.protocol.simulation

import community.kotlin.clocks.hierarchical.ClockId
import community.kotlin.clocks.simple.Clock
import community.kotlin.clocks.simple.Scheduled
import java.util.PriorityQueue
import java.util.concurrent.CompletableFuture
import java.util.concurrent.atomic.AtomicLong

/**
 * A deterministic clock for network simulation testing.
 *
 * Unlike SystemClock which uses real time, SimulationClock allows tests to:
 * - Advance time manually in controlled steps
 * - Execute scheduled tasks deterministically when their time arrives
 * - Use CompletableFuture for async delay operations
 *
 * Example:
 * ```kotlin
 * val clock = SimulationClock()
 * var executed = false
 * clock.scheduleAt(500) { executed = true }
 *
 * clock.advanceTime(400)  // executed is still false
 * clock.advanceTime(200)  // executed is now true
 * ```
 */
class SimulationClock(
    initialTimeMs: Long = 0L,
    override val clockId: ClockId = ClockId.random()
) : Clock {

    private var currentTime = initialTimeMs
    private val taskIdGenerator = AtomicLong(0)
    private val scheduledTasks = PriorityQueue<ScheduledTask>(compareBy({ it.executeAt }, { it.id }))
    private val lock = Any()

    private data class ScheduledTask(
        val id: Long,
        val executeAt: Long,
        val action: () -> Unit,
        val future: CompletableFuture<Unit>
    ) : Scheduled {
        @Volatile
        var cancelled = false

        override fun cancel() {
            cancelled = true
            future.cancel(false)
        }
    }

    override fun currentTimeMillis(): Long = synchronized(lock) { currentTime }

    /**
     * Schedules a callback to run at the specified absolute time.
     * Implements the Clock interface's schedule method.
     *
     * @param atMillis The absolute time in milliseconds when the callback should run
     * @param callback The callback to execute
     * @return A Scheduled handle that can be used to cancel the task
     */
    override fun schedule(atMillis: Long, callback: () -> Unit): Scheduled {
        val future = CompletableFuture<Unit>()
        val task = ScheduledTask(
            id = taskIdGenerator.getAndIncrement(),
            executeAt = atMillis,
            action = callback,
            future = future
        )
        synchronized(lock) {
            scheduledTasks.add(task)
        }
        return task
    }

    /**
     * Schedules a callback to run at the specified absolute time and returns a CompletableFuture.
     * This is useful for chaining with MessageDelayer operations.
     *
     * @param atMillis The absolute time in milliseconds when the callback should run
     * @param action The action to execute
     * @return A CompletableFuture that completes when the scheduled time is reached
     */
    fun scheduleAt(atMillis: Long, action: () -> Unit = {}): CompletableFuture<Unit> {
        val future = CompletableFuture<Unit>()
        val task = ScheduledTask(
            id = taskIdGenerator.getAndIncrement(),
            executeAt = atMillis,
            action = action,
            future = future
        )
        synchronized(lock) {
            scheduledTasks.add(task)
        }
        return future
    }

    /**
     * Schedules a callback to run after the specified delay.
     *
     * @param delayMs The delay in milliseconds from now
     * @param action The action to execute
     * @return A CompletableFuture that completes when the delay expires
     */
    fun scheduleAfter(delayMs: Long, action: () -> Unit = {}): CompletableFuture<Unit> {
        return scheduleAt(currentTimeMillis() + delayMs, action)
    }

    /**
     * Advances time by the specified duration, executing all scheduled tasks
     * whose execution time falls within the advancement period.
     *
     * Tasks are executed in chronological order. If multiple tasks are scheduled
     * at the same time, they execute in the order they were scheduled.
     *
     * @param durationMs The duration to advance time by, in milliseconds
     */
    fun advanceTime(durationMs: Long) {
        require(durationMs >= 0) { "Cannot advance time by negative amount: $durationMs" }

        synchronized(lock) {
            val targetTime = currentTime + durationMs

            while (scheduledTasks.isNotEmpty()) {
                val nextTask = scheduledTasks.peek()
                if (nextTask.executeAt > targetTime) break

                scheduledTasks.poll()

                if (!nextTask.cancelled) {
                    // Set current time to task execution time
                    currentTime = nextTask.executeAt
                    try {
                        nextTask.action()
                        nextTask.future.complete(Unit)
                    } catch (e: Exception) {
                        nextTask.future.completeExceptionally(e)
                    }
                }
            }

            currentTime = targetTime
        }
    }

    /**
     * Advances time until all scheduled tasks have executed.
     *
     * @param maxDurationMs Maximum time to advance (safety limit)
     * @return The actual time elapsed
     * @throws IllegalStateException if maxDuration is exceeded
     */
    fun advanceUntilIdle(maxDurationMs: Long = Long.MAX_VALUE): Long {
        val startTime = currentTimeMillis()

        synchronized(lock) {
            while (scheduledTasks.isNotEmpty()) {
                val nextTask = scheduledTasks.peek()
                val timeToNext = nextTask.executeAt - currentTime

                if (timeToNext > maxDurationMs) {
                    throw IllegalStateException(
                        "Cannot advance to idle: next task at ${nextTask.executeAt} exceeds max duration of $maxDurationMs"
                    )
                }

                advanceTime(timeToNext)
            }
        }

        return currentTimeMillis() - startTime
    }

    /**
     * Returns the number of pending scheduled tasks.
     */
    fun pendingTaskCount(): Int = synchronized(lock) { scheduledTasks.size }

    /**
     * Returns true if there are no pending scheduled tasks.
     */
    fun isIdle(): Boolean = synchronized(lock) { scheduledTasks.isEmpty() }

    /**
     * Cancels all pending tasks.
     */
    fun cancelAllTasks() {
        synchronized(lock) {
            while (scheduledTasks.isNotEmpty()) {
                val task = scheduledTasks.poll()
                task.cancelled = true
                task.future.cancel(false)
            }
        }
    }

    override fun toString(): String = "SimulationClock(now=${currentTimeMillis()}, pendingTasks=${pendingTaskCount()})"
}
