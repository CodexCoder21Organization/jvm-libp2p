package foundation.url.protocol.testing

import foundation.url.protocol.sandbox.BytecodeProtocol
import org.json.JSONObject
import java.util.Base64

/**
 * Child-JVM victim for
 * [foundation.url.protocol.testBytecodeResponseParsedInPlaceSurvivesConstrainedHeap].
 *
 * Recreates the state a consumer is in when a bytecode response arrives as JSON rather than as
 * binary attachments — the ordinary case behind a relay, since a relayed frame is re-serialized
 * and its attachments do not survive the hop. The transport has parsed the frame, so what the
 * consumer holds is a [JSONObject] whose `jarBytes` is a multi-megabyte base64 string.
 *
 * From there the two modes differ only in how that object is read:
 *
 *  - `stringify` — the historical path: serialize the object back to a string and parse that
 *    string. For bytecode the string IS the payload again, so the base64 exists three times over
 *    (the parsed object's, the re-serialized string's, the re-parsed object's) before the JAR is
 *    decoded a fourth.
 *  - `structured` — read the fields off the object already held. The base64 is the string the
 *    transport parsed, and the only new allocation is the JAR itself.
 *
 * The base64 is built a chunk at a time, so the fixture costs a buffer rather than a second copy
 * of the payload: what the heap holds afterwards is what the mode under test asked for, and
 * nothing else. The parent runs both modes under one heap sized between what each needs, with
 * ContainerNursery's production `-XX:+ExitOnOutOfMemoryError` shape, so the difference is not a
 * measurement to interpret — one JVM finishes and the other dies.
 *
 * This is the 2026-08-18 manager OOM, whose heap dump held a 4 MB client JAR as two 5.4 MB escaped
 * strings plus a 9.4 MB unescaped one, inside a 128 MB heap it was only relaying the transfer
 * through.
 *
 * Args: `args[0]` = mode (`stringify` or `structured`), `args[1]` = JAR bytes. Output contract:
 * one line `SURVIVED jar=<n>` iff the response was parsed without exhausting the heap.
 */
object BytecodeResponseParseOomVictim {
    private const val IMPL_CLASS_NAME = "example/service/ExampleServiceClientImpl"

    @JvmStatic
    fun main(args: Array<String>) {
        System.setProperty("org.slf4j.simpleLogger.defaultLogLevel", "off")
        val mode = args.getOrNull(0) ?: error("mode argument is required")
        val jarSize = args.getOrNull(1)?.toIntOrNull() ?: error("jar size argument is required")

        // The consumer's starting point is the decoded object, so build that directly: parsing it
        // from text would charge both modes for org.json's tokenizer, whose StringBuilder holds
        // the value in UTF-16 and so costs more than the payload itself — a cost the real caller,
        // whose transport already parsed the frame, does not pay at this point either.
        val parsed = JSONObject()
            .put("success", true)
            .put("implClassName", IMPL_CLASS_NAME)
            .put("jarBytes", encodeJarBase64(jarSize))

        val response = when (mode) {
            "structured" -> BytecodeProtocol.parseResponse(parsed)
            "stringify" -> BytecodeProtocol.parseResponse(parsed.toString())
            else -> error("unknown mode '$mode'")
        }

        check(response.jarBytes.size == jarSize) {
            "the JAR must survive the parse intact: expected $jarSize bytes, got ${response.jarBytes.size}"
        }
        check(response.implClassName == IMPL_CLASS_NAME) {
            "the implementation class name must survive the parse: got ${response.implClassName}"
        }
        println("SURVIVED jar=${response.jarBytes.size}")
    }

    /**
     * The base64 of a JAR of [jarSize] bytes, without ever holding the JAR and its encoding
     * together for longer than one chunk: the fixture must not be what exhausts the heap.
     */
    private fun encodeJarBase64(jarSize: Int): String {
        val encoder = Base64.getEncoder()
        // A multiple of 3 bytes encodes with no padding, so the chunks concatenate into exactly
        // the encoding of the whole JAR.
        val chunk = ByteArray(48 * 1024)
        val encoded = StringBuilder(4 * ((jarSize + 2) / 3))
        var written = 0
        while (written < jarSize) {
            val size = minOf(chunk.size, jarSize - written)
            for (i in 0 until size) chunk[i] = ((written + i) % 251).toByte()
            encoded.append(encoder.encodeToString(if (size == chunk.size) chunk else chunk.copyOf(size)))
            written += size
        }
        return encoded.toString()
    }
}
