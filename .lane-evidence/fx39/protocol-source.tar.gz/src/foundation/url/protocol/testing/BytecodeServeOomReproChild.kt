package foundation.url.protocol.testing

import foundation.url.protocol.LocalServiceRegistry
import foundation.url.protocol.ServiceBroadcaster
import foundation.url.protocol.ServiceHandler
import foundation.url.protocol.ServiceRegistrationConfig
import foundation.url.protocol.ServiceRegistrationImpl
import foundation.url.protocol.ServiceRoutingHandler
import foundation.url.protocol.TcpServer
import foundation.url.protocol.TurnServerInfo
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket

/**
 * Child-JVM helper invoked by
 * [foundation.url.protocol.testBytecodeServeUnderConstrainedHeapDoesNotOom].
 *
 * Stands up ONLY the real service-provider *optimized* bytecode serve path — a
 * [TcpServer] delegating to a [ServiceRoutingHandler] whose registered service
 * returns a realistically-sized implementation JAR from
 * [ServiceHandler.getImplementationJar] (so `supportsSandboxedExecution()` is
 * true). The parent test launches this with `-Xmx128m` (the production
 * ContainerNursery default for service JVMs like production-health-server.jar and
 * docker-run-server.jar) and drives a burst of concurrent `__bytecode_request`
 * clients.
 *
 * Before the streaming fix, each in-flight serve materialized the payload ~5×
 * (`createResponse` base64 String + inner JSON String + `toJson().toString()`
 * outer String + final `byte[]`); a 2.4 MB JAR served to ~20 concurrent clients
 * exhausted the 128 MB heap and this JVM died with `OutOfMemoryError`. With the
 * fix (see `BytecodeResponseStreamer` / `StreamingBytecodeResponse`) peak heap
 * stays at ~`jarBytes.size` per serve and the JVM survives.
 *
 * Output contract: exactly one line `READY port=<tcpPort>` once the server is
 * accepting connections. The JVM then idles (the parent kills it). Arguments:
 * `args[0]` = JAR size in bytes (the parent must reconstruct the identical bytes
 * to verify byte-exact round-trip); optional `args[1]` and `args[2]` are the
 * startup-observer port and child index used by the atomic-bind stress test.
 */
object BytecodeServeOomReproChild {
    const val SERVICE_IDENTIFIER = "test.bytecode.serve"
    const val IMPL_CLASS_NAME = "com.example.MyServiceImpl"
    const val STARTUP_PROCEED_SIGNAL = 1

    /**
     * Deterministically generates the implementation JAR bytes for a given size,
     * so the parent test can reconstruct the exact expected bytes and assert a
     * byte-exact round-trip. The byte pattern is incompressible enough that its
     * base64 form inflates ~4/3, matching a real fat implementation JAR on the
     * wire.
     */
    fun makeImplJar(sizeBytes: Int): ByteArray = ByteArray(sizeBytes) { ((it * 31 + 7) % 251).toByte() }

    @JvmStatic
    fun main(args: Array<String>) {
        val jarSizeBytes = args[0].toInt()
        val implJar = makeImplJar(jarSizeBytes)

        val handler = object : ServiceHandler {
            override suspend fun handleRequest(
                path: String, params: Map<String, Any?>, metadata: Map<String, String>
            ): Any? = mapOf("ok" to true)

            override fun getImplementationJar(): ByteArray? = implJar
            override fun getImplementationClassName(): String? = IMPL_CLASS_NAME
        }

        val noopBroadcaster = object : ServiceBroadcaster {
            override fun broadcastAnnouncementAtTimestamp(
                serviceUrl: String, serviceIdentifier: String, providerPeerId: String,
                providerMultiaddresses: List<String>, stunAddresses: List<String>,
                turnServers: List<TurnServerInfo>, metadata: Map<String, String>,
                ttl: Int, timestamp: Long
            ): Int = 0
            override fun broadcastWithdrawalAtTimestamp(
                serviceUrl: String, serviceIdentifier: String, providerPeerId: String, timestamp: Long
            ) {}
        }

        val registry = LocalServiceRegistry()
        registry.register(
            ServiceRegistrationImpl(
                serviceUrl = "url://$SERVICE_IDENTIFIER/",
                serviceIdentifier = SERVICE_IDENTIFIER,
                peerId = "QmBytecodeServeOomTestPeer",
                isGlobal = false,
                handler = handler,
                config = ServiceRegistrationConfig(),
                broadcaster = noopBroadcaster
            )
        )

        val routingHandler = ServiceRoutingHandler(registry)

        val server = TcpServer.withHandler(0, routingHandler)
        server.start()
        val port = server.localPort
        reportSelectedPortToStartupObserver(
            port = port,
            observerPort = args.getOrNull(1)?.toInt(),
            childIndex = args.getOrNull(2)?.toInt(),
        )

        // Single machine-readable line. Parent regex: `READY port=(\d+)`.
        println("READY port=$port")
        System.out.flush()

        // Idle until the parent kills us. Bounded so a disappearing parent does
        // not leave a zombie behind.
        Thread.sleep(15 * 60 * 1000L)
    }

    private fun reportSelectedPortToStartupObserver(
        port: Int,
        observerPort: Int?,
        childIndex: Int?,
    ) {
        if (observerPort == null) return
        check(childIndex != null) {
            "Bytecode serve child startup observer port $observerPort was provided without a child index."
        }
        Socket("127.0.0.1", observerPort).use { socket ->
            val output = DataOutputStream(socket.getOutputStream())
            output.writeInt(childIndex)
            output.writeInt(port)
            output.flush()
            val signal = DataInputStream(socket.getInputStream()).readUnsignedByte()
            check(signal == STARTUP_PROCEED_SIGNAL) {
                "Bytecode serve startup observer on port $observerPort returned signal $signal, " +
                    "but expected $STARTUP_PROCEED_SIGNAL for child $childIndex on selected server port $port."
            }
        }
    }
}
