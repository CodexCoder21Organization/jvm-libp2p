package foundation.url.protocol.testing

import foundation.url.protocol.EffectPropagator
import foundation.url.protocol.Libp2pHostFactory
import foundation.url.protocol.Libp2pRpcProtocol
import foundation.url.protocol.RpcRequestHandler
import java.lang.management.ManagementFactory
import java.util.concurrent.TimeUnit

/**
 * Child-JVM victim for
 * [stressTestServerSurvivesMidNegotiationChurnDropWithConstrainedHeap].
 *
 * Stands up the exact url:// node ContainerNursery embeds
 * ([Libp2pHostFactory.createServerHost]) and idles. The parent test launches this
 * with ContainerNursery's production shape — `-XX:ActiveProcessorCount=2 -Xmx128m
 * -XX:+ExitOnOutOfMemoryError` — and then churn-drops connections carrying
 * mid-negotiation inbound substreams.
 *
 * Before the jvm-libp2p fix (TotalTimeoutHandler now cancels on the channel close
 * future), this node OOM-died (issue #294): tens of thousands of pending
 * negotiation-timeout tasks pinned the closed MuxChannel + Negotiator$ResponderHandler
 * pipelines that the CPU-starved event loop never cleaned up. With the fix it survives.
 *
 * Output contract: `READY peerId=<base58> addr=<multiaddr>` then periodic
 * `HEAP usedMb=<n>` lines.
 */
object ChurnDropOomVictim {
    @JvmStatic
    fun main(args: Array<String>) {
        System.setProperty("org.slf4j.simpleLogger.defaultLogLevel", "off")
        val seed = if (args.isNotEmpty()) args[0] else "churndrop-oom-victim"
        val handler = object : RpcRequestHandler {
            override suspend fun handleRequest(
                request: Libp2pRpcProtocol.RpcRequest,
                effectHandler: EffectPropagator
            ): Libp2pRpcProtocol.RpcResponse =
                Libp2pRpcProtocol.RpcResponse(request.id, "ok", null)
        }
        val server = Libp2pHostFactory.createServerHost(
            listenAddresses = listOf("/ip4/127.0.0.1/tcp/0"),
            requestHandler = handler,
            keyPair = Libp2pHostFactory.generateKeyFromSeed(seed)
        )
        server.start().get(20, TimeUnit.SECONDS)
        println("READY peerId=${server.peerId.toBase58()} addr=${server.listenAddresses().first()}")
        System.out.flush()

        val mem = ManagementFactory.getMemoryMXBean()
        Thread {
            while (true) {
                println("HEAP usedMb=${mem.heapMemoryUsage.used / (1024 * 1024)}")
                System.out.flush()
                try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
            }
        }.apply { isDaemon = true; start() }

        Thread.sleep(15 * 60 * 1000L)
    }
}
