package foundation.url.protocol.testing

import foundation.url.protocol.Libp2pRpcProtocol
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.CyclicBarrier
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * Child-JVM victim for
 * [foundation.url.protocol.stressTestConcurrentLargeMessageReadsSurviveConstrainedHeap].
 *
 * Drives the REAL inbound-message read path — `Libp2pRpcProtocol.readMessageFrameFromStream`
 * -> `readJsonFrame` -> (fix) `readBoundedJsonBody` -> `parseValidatedJsonBody` — from many
 * threads released together by a [CyclicBarrier], each reading an identical multi-MB
 * length-prefixed message. So `concurrency` readers hit `ByteArray(length)` + the
 * `String`/`JSONObject` parse amplification at the same instant.
 *
 * The parent launches this with ContainerNursery's production shape — `-Xmx128m
 * -XX:+ExitOnOutOfMemoryError`. `concurrency * payloadBytes` far exceeds the 128 MB heap, so
 * on the UNFIXED code the simultaneous body allocations exhaust the heap and the JVM exits
 * with `OutOfMemoryError` (the 2026-06-29 ContainerNursery / kotlin.directory read-side OOM:
 * a heap dump showed 12 concurrent `TcpRpcStream-Reader` threads each parsing an ~8 MB
 * message — 45 MB / 41% of the heap).
 *
 * With the fix (`Libp2pRpcProtocol`'s global parse-memory budget, MAX_CONCURRENT_PARSE_BYTES)
 * each reader reserves its body size BEFORE allocating, so all but a few block (no body
 * pinned), the survivors parse within a bounded budget, and the JVM SURVIVES.
 *
 * Args: `args[0]` = concurrency, `args[1]` = payload bytes. Output contract: one line
 * `SURVIVED done=<n> errors=<m>` iff every reader parsed without exhausting the heap.
 */
object ConcurrentLargeReadOomVictim {
    @JvmStatic
    fun main(args: Array<String>) {
        System.setProperty("org.slf4j.simpleLogger.defaultLogLevel", "off")
        val concurrency = args.getOrNull(0)?.toIntOrNull() ?: 40
        val payloadBytes = args.getOrNull(1)?.toIntOrNull() ?: (6 * 1024 * 1024)
        if (args.getOrNull(2) == "single-legitimate") {
            runSingleLegitimate(payloadBytes)
            return
        }
        if (args.getOrNull(2) == "exclusive-reservation") {
            runExclusiveReservation(payloadBytes)
            return
        }
        if (args.getOrNull(2) == "single-pathological" || args.getOrNull(2) == "single-over-budget") {
            runSinglePathological(payloadBytes)
            return
        }
        if (args.getOrNull(2) == "smallest-heap-boundary") {
            runSmallestHeapBoundary()
            return
        }
        if (args.getOrNull(2) == "mixed") {
            runMixed(concurrency, payloadBytes)
            return
        }
        println(
            "DIAG maxMemoryMb=${Runtime.getRuntime().maxMemory() / (1024 * 1024)} " +
                "concurrency=$concurrency payloadMb=${payloadBytes / (1024 * 1024)}"
        )
        System.out.flush()

        // Build ONE length-prefixed RPC-request message (wire format read by
        // readMessageFrameFromStream: [4-byte big-endian JSON length][JSON bytes], no
        // attachments). Scope the build so the construction temporaries (the multi-MB
        // payload String, JSON String, jsonBytes) are GC-eligible afterwards — the ONLY
        // intended baseline during the reads is `wire` itself, so a single budgeted parse
        // fits comfortably while `concurrency` un-budgeted parses do not.
        val wire: ByteArray = run {
            val payload = StringBuilder(payloadBytes).apply {
                repeat(payloadBytes) { append(('a' + (it % 26))) }
            }.toString()
            val json = Libp2pRpcProtocol.RpcRequest(
                id = "req-large-read",
                method = "echoLen",
                params = mapOf("payload" to payload)
            ).toJson().toString()
            val jsonBytes = json.toByteArray(Charsets.UTF_8)
            val w = ByteArray(4 + jsonBytes.size)
            w[0] = (jsonBytes.size ushr 24).toByte()
            w[1] = (jsonBytes.size ushr 16).toByte()
            w[2] = (jsonBytes.size ushr 8).toByte()
            w[3] = jsonBytes.size.toByte()
            System.arraycopy(jsonBytes, 0, w, 4, jsonBytes.size)
            w
        }
        System.gc()
        Thread.sleep(150) // let the construction temporaries be reclaimed before the burst

        val barrier = CyclicBarrier(concurrency)
        val done = AtomicInteger(0)
        val errors = ConcurrentLinkedQueue<String>()
        val readers = (0 until concurrency).map { tid ->
            thread(name = "large-reader-$tid", isDaemon = true) {
                try {
                    barrier.await() // all readers hit the body allocation + parse together
                    val frame = Libp2pRpcProtocol.readMessageFrameFromStream(ByteArrayInputStream(wire))
                    check(frame.json.getString("method") == "echoLen") { "wrong method" }
                    done.incrementAndGet()
                } catch (t: Throwable) {
                    // OutOfMemoryError under -XX:+ExitOnOutOfMemoryError exits the JVM before
                    // this catch matters; other throwables are recorded.
                    errors.add("${t.javaClass.simpleName}: ${t.message}")
                }
            }
        }
        readers.forEach { it.join() }
        println("SURVIVED done=${done.get()} errors=${errors.size}")
        System.out.flush()
    }

    private fun runSingleLegitimate(frameBytes: Int) {
        println(
            "DIAG maxMemoryMb=${Runtime.getRuntime().maxMemory() / (1024 * 1024)} " +
                "frameBytes=$frameBytes totalBudget=${Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES}"
        )
        System.out.flush()

        val wire = buildExactLengthWire(frameBytes)
        val frame = Libp2pRpcProtocol.readMessageFrameFromStream(ByteArrayInputStream(wire))
        check(frame.json.getString("type") == "boundary") { "wrong large-frame type" }
        println(
            "SURVIVED_LARGE_FRAME frameBytes=$frameBytes " +
                "worstCaseParseBytes=${frameBytes.toLong() * Libp2pRpcProtocol.PARSE_AMPLIFICATION} " +
                "totalBudget=${Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES}"
        )
        System.out.flush()
    }

    private fun runExclusiveReservation(frameBytes: Int) {
        val budget = Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES
        val worstCaseParseBytes = frameBytes.toLong() * Libp2pRpcProtocol.PARSE_AMPLIFICATION
        check(worstCaseParseBytes > budget) {
            "The regression fixture must exceed the child JVM's concurrency budget: " +
                "frameBytes=$frameBytes, worstCaseParseBytes=$worstCaseParseBytes, budget=$budget"
        }

        val firstPermits = Libp2pRpcProtocol.acquireParseBudget(frameBytes)
        val secondStarted = CountDownLatch(1)
        val secondAcquired = CountDownLatch(1)
        val secondFinished = CountDownLatch(1)
        val secondPermits = AtomicInteger(-1)
        val waiter = thread(name = "exclusive-large-parse-waiter", isDaemon = true) {
            secondStarted.countDown()
            try {
                val permits = Libp2pRpcProtocol.acquireParseBudget(frameBytes)
                secondPermits.set(permits)
                secondAcquired.countDown()
                Libp2pRpcProtocol.releaseParseBudget(permits)
            } finally {
                secondFinished.countDown()
            }
        }

        try {
            check(firstPermits == budget) {
                "An over-budget estimate reserved $firstPermits permits instead of the whole $budget-permit pool"
            }
            check(secondStarted.await(5, TimeUnit.SECONDS)) { "The competing large parse did not start" }

            val blockedDeadlineNanos = System.nanoTime() + TimeUnit.SECONDS.toNanos(5)
            while (
                secondAcquired.count != 0L &&
                waiter.state != Thread.State.WAITING &&
                System.nanoTime() < blockedDeadlineNanos
            ) {
                Thread.yield()
            }
            check(secondAcquired.count != 0L) {
                "Two over-budget estimates acquired the concurrency pool at the same time"
            }
            check(waiter.state == Thread.State.WAITING) {
                "The competing large parse neither acquired nor blocked on the concurrency pool; " +
                    "waiterState=${waiter.state}"
            }
        } finally {
            Libp2pRpcProtocol.releaseParseBudget(firstPermits)
        }

        check(secondFinished.await(5, TimeUnit.SECONDS)) { "The queued large parse did not resume" }
        waiter.join(5_000)
        check(secondPermits.get() == budget) {
            "The queued over-budget estimate reserved ${secondPermits.get()} permits instead of $budget"
        }
        println(
            "SERIALIZED_LARGE_PARSE frameBytes=$frameBytes worstCaseParseBytes=$worstCaseParseBytes " +
                "totalBudget=$budget firstPermits=$firstPermits secondPermits=${secondPermits.get()}"
        )
        System.out.flush()
    }

    private fun runSinglePathological(frameBytes: Int) {
        println(
            "DIAG maxMemoryMb=${Runtime.getRuntime().maxMemory() / (1024 * 1024)} " +
                "frameBytes=$frameBytes totalBudget=${Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES}"
        )
        System.out.flush()

        val wire = buildExactLengthWire(frameBytes)
        try {
            Libp2pRpcProtocol.readMessageFrameFromStream(ByteArrayInputStream(wire))
            println("UNEXPECTEDLY_PARSED frameBytes=$frameBytes")
        } catch (e: java.io.IOException) {
            println("SURVIVED_REJECTION ${e.message}")
        }
        System.out.flush()
    }

    private fun runSmallestHeapBoundary() {
        val amplification = Libp2pRpcProtocol.PARSE_AMPLIFICATION
        val budget = Libp2pRpcProtocol.MAX_CONCURRENT_PARSE_BYTES
        val frameBytes = budget / amplification
        println(
            "DIAG maxMemoryMb=${Runtime.getRuntime().maxMemory() / (1024 * 1024)} " +
                "frameBytes=$frameBytes totalBudget=$budget"
        )
        System.out.flush()

        val wire = buildExactLengthWire(frameBytes)
        val frame = Libp2pRpcProtocol.readMessageFrameFromStream(ByteArrayInputStream(wire))
        check(frame.json.getString("type") == "boundary") { "wrong boundary frame type" }
        println("SURVIVED_BOUNDARY frameBytes=$frameBytes totalBudget=$budget")
        System.out.flush()
    }

    private fun runMixed(concurrency: Int, payloadBytes: Int) {
        val largeReaders = concurrency
        val smallReaders = concurrency * 3
        println(
            "DIAG maxMemoryMb=${Runtime.getRuntime().maxMemory() / (1024 * 1024)} " +
                "largeReaders=$largeReaders smallReaders=$smallReaders payloadMb=${payloadBytes / (1024 * 1024)}"
        )
        System.out.flush()

        val largeWire = buildWire(payloadBytes, "large")
        val smallWire = buildWire(512, "small")
        System.gc()
        Thread.sleep(150)

        val totalReaders = largeReaders + smallReaders
        val barrier = CyclicBarrier(totalReaders)
        val largeDone = AtomicInteger(0)
        val smallDone = AtomicInteger(0)
        val errors = ConcurrentLinkedQueue<String>()
        val readers = mutableListOf<Thread>()
        repeat(largeReaders) { tid ->
            readers += thread(name = "mixed-large-reader-$tid", isDaemon = true) {
                try {
                    barrier.await()
                    val frame = Libp2pRpcProtocol.readMessageFrameFromStream(ByteArrayInputStream(largeWire))
                    check(frame.json.getString("method") == "large") { "wrong large method" }
                    largeDone.incrementAndGet()
                } catch (t: Throwable) {
                    errors.add("${t.javaClass.simpleName}: ${t.message}")
                }
            }
        }
        repeat(smallReaders) { tid ->
            readers += thread(name = "mixed-small-reader-$tid", isDaemon = true) {
                try {
                    barrier.await()
                    val frame = Libp2pRpcProtocol.readMessageFrameFromStream(ByteArrayInputStream(smallWire))
                    check(frame.json.getString("method") == "small") { "wrong small method" }
                    smallDone.incrementAndGet()
                } catch (t: Throwable) {
                    errors.add("${t.javaClass.simpleName}: ${t.message}")
                }
            }
        }
        readers.forEach { it.join() }
        println("SURVIVED_MIXED largeDone=${largeDone.get()} smallDone=${smallDone.get()} errors=${errors.size}")
        System.out.flush()
    }

    private fun buildWire(payloadBytes: Int, method: String): ByteArray {
        val payload = StringBuilder(payloadBytes).apply {
            repeat(payloadBytes) { append(('a' + (it % 26))) }
        }.toString()
        val json = Libp2pRpcProtocol.RpcRequest(
            id = "req-$method-read",
            method = method,
            params = mapOf("payload" to payload)
        ).toJson().toString()
        val jsonBytes = json.toByteArray(Charsets.UTF_8)
        val w = ByteArray(4 + jsonBytes.size)
        w[0] = (jsonBytes.size ushr 24).toByte()
        w[1] = (jsonBytes.size ushr 16).toByte()
        w[2] = (jsonBytes.size ushr 8).toByte()
        w[3] = jsonBytes.size.toByte()
        System.arraycopy(jsonBytes, 0, w, 4, jsonBytes.size)
        return w
    }

    private fun buildExactLengthWire(frameBytes: Int): ByteArray {
        val prefix = "{\"type\":\"boundary\",\"payload\":\"".toByteArray(Charsets.UTF_8)
        val suffix = "\"}".toByteArray(Charsets.UTF_8)
        require(frameBytes >= prefix.size + suffix.size) {
            "frameBytes must be at least ${prefix.size + suffix.size}, but was $frameBytes"
        }
        val wire = ByteArray(4 + frameBytes)
        wire[0] = (frameBytes ushr 24).toByte()
        wire[1] = (frameBytes ushr 16).toByte()
        wire[2] = (frameBytes ushr 8).toByte()
        wire[3] = frameBytes.toByte()
        System.arraycopy(prefix, 0, wire, 4, prefix.size)
        java.util.Arrays.fill(wire, 4 + prefix.size, 4 + frameBytes - suffix.size, 'a'.code.toByte())
        System.arraycopy(suffix, 0, wire, 4 + frameBytes - suffix.size, suffix.size)
        return wire
    }
}
