package foundation.url.protocol.testing

import io.netty.channel.Channel
import io.netty.buffer.ByteBuf
import io.netty.util.AttributeKey
import org.json.JSONException
import org.json.JSONObject
import java.nio.charset.StandardCharsets.UTF_8
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

private val framingOwnerObservationKey: AttributeKey<FramingOwnerWritabilityObservation> =
    AttributeKey.valueOf("foundation.url.protocol.framingOwnerWritabilityObservation")

/** A passive, one-shot observation. Callers can await it but cannot supply its signal operation. */
class FramingOwnerWritabilityObservation internal constructor(
    private val expectedMessageType: String? = null,
    private val expectedMessageId: String? = null,
) {
    private val observed = CountDownLatch(1)

    fun await(timeout: Long, unit: TimeUnit): Boolean = observed.await(timeout, unit)

    internal fun record(frame: ByteBuf) {
        if (observed.count == 0L) return
        if (expectedMessageType != null) {
            // Inspect the writer-owned frame without consuming or retaining any of its bytes.
            if (frame.readableBytes() < 4) return
            val length = frame.getInt(frame.readerIndex())
            if (length < 2 || length > frame.readableBytes() - 4) return
            val message = try {
                JSONObject(frame.toString(frame.readerIndex() + 4, length, UTF_8))
            } catch (_: JSONException) {
                // A connection can also carry non-JSON frames. Those are not the selected
                // message; ignoring them here changes only observation, never transport.
                return
            }
            if (message.opt("type") != expectedMessageType) return
            if (expectedMessageId != null && message.opt("messageId") != expectedMessageId) return
        }
        observed.countDown()
    }
}

/** Installs a fresh implementation-owned observation on a real root connection for a test. */
fun observeFramingOwnerWritabilityWait(rootChannel: Channel): FramingOwnerWritabilityObservation =
    FramingOwnerWritabilityObservation().also { rootChannel.attr(framingOwnerObservationKey).set(it) }

/** Observes only the selected length-prefixed JSON frame on a shared connection. */
fun observeFramingOwnerWritabilityWait(
    rootChannel: Channel,
    expectedMessageType: String,
    expectedMessageId: String? = null,
): FramingOwnerWritabilityObservation =
    FramingOwnerWritabilityObservation(expectedMessageType, expectedMessageId)
        .also { rootChannel.attr(framingOwnerObservationKey).set(it) }

internal fun recordFramingOwnerWritabilityWait(rootChannel: Channel, frame: ByteBuf) {
    if (!rootChannel.hasAttr(framingOwnerObservationKey)) return
    rootChannel.attr(framingOwnerObservationKey).get()?.record(frame)
}
