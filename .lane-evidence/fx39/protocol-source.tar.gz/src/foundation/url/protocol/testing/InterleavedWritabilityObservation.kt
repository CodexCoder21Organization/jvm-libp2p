package foundation.url.protocol.testing

import io.netty.channel.Channel
import io.netty.util.AttributeKey
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

private val interleavedWaitObservationKey: AttributeKey<InterleavedWritabilityObservation> =
    AttributeKey.valueOf("foundation.url.protocol.interleavedWritabilityObservation")

/** A passive one-shot wait record; no caller can attach code to its private completion signal. */
class InterleavedWritabilityObservation internal constructor() {
    private val observed = CompletableFuture<Thread>()

    val thread: Thread? get() = observed.getNow(null)

    fun await(timeout: Long, unit: TimeUnit): Boolean = try {
        observed.get(timeout, unit)
        true
    } catch (_: TimeoutException) {
        // A bounded observation reports absence; it does not alter the writer's wait or deadline.
        false
    }

    internal fun record() { observed.complete(Thread.currentThread()) }
}

/** Installs an implementation-owned record for the next interleaved writability wait. */
fun observeInterleavedWritabilityWait(rootChannel: Channel): InterleavedWritabilityObservation =
    InterleavedWritabilityObservation().also { rootChannel.attr(interleavedWaitObservationKey).set(it) }

internal fun recordInterleavedWritabilityWait(rootChannel: Channel) {
    if (!rootChannel.hasAttr(interleavedWaitObservationKey)) return
    rootChannel.attr(interleavedWaitObservationKey).get()?.record()
}
