package foundation.url.protocol.testing

import foundation.url.protocol.GossipProtocol
import foundation.url.protocol.RelayProtocol

/**
 * Child-JVM half of [testMintedMessageIdsNeverCollideAcrossProcesses].
 *
 * A message id is used as a correlation key by the peers that receive it — the relay's table of
 * forwarded requests awaiting a reply and the gossip duplicate tracker both key on one — so the ids
 * one process mints must never coincide with those another process mints. That cannot be observed
 * from inside a single JVM, so the parent test runs this one alongside itself and both mint on the
 * same wall-clock schedule: one id per millisecond from a shared starting instant. That is what two
 * peers that start together and then do the same work in step produce.
 *
 * Protocol: `args[0]` is how many ids to mint from each generator. The child prints `READY`, then
 * reads one line from stdin holding the epoch millisecond at which to begin, and prints one id per
 * line as `RELAY <id>` or `GOSSIP <id>`.
 */
object MintedMessageIdPrinter {
    @JvmStatic
    fun main(args: Array<String>) {
        val count = if (args.isNotEmpty()) args[0].toInt() else 150
        // Touch both generators before the barrier so class loading is not what decides when this
        // process reaches the shared schedule.
        RelayProtocol.nextMessageId()
        GossipProtocol.nextMessageId()
        println("READY")
        System.out.flush()
        val startAtMillis = readLine()?.trim()?.toLongOrNull()
            ?: error("The parent did not supply the epoch millisecond at which to start minting")
        val out = StringBuilder()
        for (i in 0 until count) {
            mintedMessageIdSpinUntil(startAtMillis + i)
            out.append("RELAY ").append(RelayProtocol.nextMessageId()).append('\n')
        }
        for (i in 0 until count) {
            mintedMessageIdSpinUntil(startAtMillis + count + i)
            out.append("GOSSIP ").append(GossipProtocol.nextMessageId()).append('\n')
        }
        print(out)
        System.out.flush()
    }
}

/**
 * Waits until [untilMillis] by spinning. Sleeping wakes at a coarser granularity than the millisecond
 * two processes have to share for this comparison to mean anything.
 */
internal fun mintedMessageIdSpinUntil(untilMillis: Long) {
    while (System.currentTimeMillis() < untilMillis) {
        Thread.onSpinWait()
    }
}
