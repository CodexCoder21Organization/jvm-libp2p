package foundation.url.protocol.testing

import foundation.url.protocol.DeferredRelayHandler
import foundation.url.protocol.Libp2pHostFactory
import foundation.url.protocol.PeerRegistry
import foundation.url.protocol.RelayConfig
import foundation.url.protocol.RelayService
import java.util.concurrent.TimeUnit

/**
 * Child-JVM helper invoked by constrained-heap relay tests, including
 * `stressTestRelayProcessSurvivesOomFloodWithConstrainedHeap`,
 * `stressTestRelayGossipForwardingSurvivesStalledPeerFanoutWithConstrainedHeap`, and
 * `stressTestRelayUniqueAnnouncementCacheSurvivesConstrainedHeap`.
 *
 * Stands up a single libp2p host with [RelayService] enabled, prints one line of
 * machine-readable status to stdout, then idles forever. The parent test launches
 * this with `-Xmx128m -XX:+ExitOnOutOfMemoryError`, drives the relay through real
 * libp2p streams, and asserts the process survives. The scenarios cover both
 * per-stream pending-processing backpressure and retained late-join announcement
 * state, so this helper deliberately contains no test-specific workload logic.
 *
 * Output contract: exactly one line `READY peerId=<base58> addr=<multiaddr>` on
 * startup. Anything else is forwarded as diagnostic output for the parent test
 * to print on failure.
 */
object RelayLeakOomReproChild {
    @JvmStatic
    fun main(args: Array<String>) {
        val seed = if (args.isNotEmpty()) args[0] else "relay-oom-repro-child"
        val deferred = DeferredRelayHandler()
        val host = Libp2pHostFactory.createHostWithDeferredRelay(
            listenAddresses = listOf("/ip4/127.0.0.1/tcp/0"),
            deferredHandler = deferred,
            keyPair = Libp2pHostFactory.generateKeyFromSeed(seed)
        )
        host.start().get(10, TimeUnit.SECONDS)
        val registry = PeerRegistry.inMemory()
        val relayService = RelayService(host, registry, RelayConfig(enableRelay = true))
        deferred.setRelayService(relayService)
        relayService.start()

        val peerId = host.peerId.toBase58()
        val addr = host.listenAddresses().first().toString()
        // Single line. Parent regex: `READY peerId=(\\S+) addr=(\\S+)`.
        println("READY peerId=$peerId addr=$addr")
        System.out.flush()

        // Idle forever. The parent kills us via Process.destroyForcibly().
        // A bounded sleep is safer than Thread.currentThread().join() — if the
        // parent disappears without killing us, we eventually exit instead of
        // becoming a zombie.
        Thread.sleep(15 * 60 * 1000L)
    }
}
