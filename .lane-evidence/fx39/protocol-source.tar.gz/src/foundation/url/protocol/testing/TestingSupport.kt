package foundation.url.protocol.testing

import foundation.url.protocol.*

/** Test-only access to RelayService lifecycle scheduling seams. */
object RelayServiceTestBridge {
    /**
     * Runs [action] while the expected acknowledged relay generation cannot be cleared or
     * replaced. Returns false without running it when that generation is no longer committed.
     */
    fun withCommittedRelayRegistration(
        service: RelayService,
        expectedRelayPeerId: String,
        action: () -> Unit,
    ): Boolean = service.withCommittedRelayRegistrationForTesting(expectedRelayPeerId, action)

    /** Reports whether [thread] is waiting to enter the relay lifecycle transition. */
    fun isRelayLifecycleThreadQueued(service: RelayService, thread: Thread): Boolean =
        service.isRelayLifecycleThreadQueuedForTesting(thread)
}

/**
 * Mock implementation of RemotePtyConnection for testing.
 */
class MockPtyConnection : RemotePtyConnection {
    val requestHistory = mutableListOf<Pair<String, Map<String, Any?>>>()
    var nextResponse: Libp2pRpcProtocol.RpcResponse? = null
    var closed = false
    var invalidationCallback: ((Long) -> Unit)? = null

    override fun sendRequest(method: String, params: Map<String, Any?>): Libp2pRpcProtocol.RpcResponse {
        requestHistory.add(method to params)
        return nextResponse ?: Libp2pRpcProtocol.RpcResponse.success("mock-${requestHistory.size}", null)
    }

    override suspend fun sendRequestAsync(method: String, params: Map<String, Any?>): Libp2pRpcProtocol.RpcResponse {
        return sendRequest(method, params)
    }

    override fun subscribeToInvalidations(onInvalidation: (Long) -> Unit) {
        invalidationCallback = onInvalidation
    }

    override fun unsubscribeFromInvalidations() {
        invalidationCallback = null
    }

    override fun close() {
        closed = true
    }

    fun triggerInvalidation() {
        invalidationCallback?.invoke(System.currentTimeMillis())
    }
}

/**
 * Mock implementation of AiCliPtyAdapter for testing.
 */
class MockAiCliPtyAdapter : AiCliPtyAdapter {
    var started = false
    var columns = 0
    var rows = 0
    var lastSentString: String? = null
    var _status = ExecutionStatus.IDLE
    var _isAlive = true
    private var _onInvalidation: (() -> Unit)? = null

    override fun start(columns: Int, rows: Int) {
        started = true
        this.columns = columns
        this.rows = rows
    }

    override fun isAlive(): Boolean = _isAlive

    override fun renderScreen(columns: Int, rows: Int): String {
        return "Mock screen ${columns}x${rows}"
    }

    override fun renderScreenWithCursor(columns: Int, rows: Int): RenderedScreenData {
        return RenderedScreenData("Mock cursor screen", 0, 1, true)
    }

    override fun resize(columns: Int, rows: Int) {
        this.columns = columns
        this.rows = rows
    }

    override fun sendString(s: String) {
        lastSentString = s
        _onInvalidation?.invoke()
    }

    override fun sendBytes(bytes: ByteArray) {}
    override fun sendEnter() { _onInvalidation?.invoke() }
    override fun sendBackspace() {}
    override fun sendTab() {}
    override fun sendCtrl(char: Char) {}
    override fun sendArrowUp() {}
    override fun sendArrowDown() {}
    override fun sendArrowRight() {}
    override fun sendArrowLeft() {}
    override fun sendHome() {}
    override fun sendEnd() {}
    override fun interrupt() {}

    override fun captureScreenFor(durationMs: Long, columns: Int, rows: Int, mirrorRaw: Boolean): String {
        return "Captured for ${durationMs}ms"
    }

    override fun getStatus(): ExecutionStatus = _status

    override fun setOnInvalidation(handler: (() -> Unit)?) {
        _onInvalidation = handler
    }

    override fun sessionLogRecords(): List<Any> = emptyList()
    override fun getSessionId(): String? = "mock-session-id"
    override fun commandPreview(): String = "mock-command"
    override fun persistSessionId(sessionId: String): Boolean = true
    override suspend fun getStandaloneResponse(prompt: String): String = "Mock response to: $prompt"
    override fun getIdleDetectionDebugInfo(): Map<String, Any> = mapOf("mock" to true)
    override fun quotaStatus(): RemoteAiCliQuotaStatus = RemoteAiCliQuotaStatus(
        supported = true,
        metrics = listOf(
            RemoteAiCliQuotaMetric(
                id = "mock.daily",
                displayName = "Mock daily limit",
                window = RemoteAiCliQuotaWindow.DAILY,
                model = null,
                unit = "percent",
                totalQuantity = 100.0,
                usedQuantity = 25.0,
                remainingQuantity = 75.0,
                resetsAtEpochMillis = null,
                resetsDescription = null,
            ),
            RemoteAiCliQuotaMetric(
                id = "mock.week.model-x",
                displayName = "Mock weekly model-x tokens",
                window = RemoteAiCliQuotaWindow.WEEKLY,
                model = "model-x",
                unit = "tokens",
                totalQuantity = 1_000_000.0,
                usedQuantity = 400_000.0,
                remainingQuantity = 600_000.0,
                resetsAtEpochMillis = 1_752_055_200_000L,
                resetsDescription = "resets 23:00",
            ),
        ),
        fetchedAtEpochMillis = 1_752_048_000_000L,
        rawText = "mock quota status",
        errorMessage = null,
    )

    override fun close() {
        _isAlive = false
    }
}
