package io.libp2p.core.transport

import io.libp2p.core.ChannelVisitor
import io.libp2p.core.Connection
import io.libp2p.core.ConnectionHandler
import io.libp2p.core.P2PChannel
import io.libp2p.core.multiformats.Multiaddr
import java.util.concurrent.CompletableFuture

/**
 * A Transport represents an adapter to integrate (typically) a L2, L3 or L7 protocol into libp2p, to allow incoming
 * and outgoing connections to be established.
 *
 * TODO:
 *   * Expose transport qualities/attributes (dial only, listen only, reliable, connectionful, costly, etc.)
 */
interface Transport {
    val activeListeners: Int
    val activeConnections: Int

    fun listenAddresses(): List<Multiaddr>

    /**
     * Verifies whether this transport is capable of handling this multiaddr.
     */
    fun handles(addr: Multiaddr): Boolean

    /**
     * Performs any preparation, warm-up or initialisation to activate this transport.
     */
    fun initialize()

    /** Completes when startup preparation has finished, before listening or dialing. */
    fun ready(): CompletableFuture<Unit> = CompletableFuture.completedFuture(Unit)

    /**
     * Stops the transport entirely, closing down all ongoing connections, outbound dials, and listening endpoints.
     */
    fun close(): CompletableFuture<Unit>

    /**
     * Makes this transport listen on this multiaddr. The future completes once the endpoint is effectively listening.
     * @param connHandler is invoked on every complete (secured and multiplexed) [Connection]
     */
    fun listen(addr: Multiaddr, connHandler: ConnectionHandler) = listen(addr, connHandler, null)

    /**
     * Makes this transport listen on this multiaddr. The future completes once the endpoint is effectively listening.
     * @param connHandler is invoked on every complete (secured and multiplexed) [Connection]
     * @param preHandler is invoked prior to any other handlers (including security negotiation) on every newly created raw Channel
     */
    fun listen(addr: Multiaddr, connHandler: ConnectionHandler, preHandler: ChannelVisitor<P2PChannel>?): CompletableFuture<Unit>

    /**
     * Makes this transport stop listening on this multiaddr. Any connections maintained from this source host and port
     * will be disconnected as a result. The future completes once the endpoint and all its connections are effectively
     * stopped.
     */
    fun unlisten(addr: Multiaddr): CompletableFuture<Unit>

    /**
     * Dials the specified multiaddr and returns a promise of a Connection.
     */
    fun dial(addr: Multiaddr, connHandler: ConnectionHandler) = dial(addr, connHandler, null)

    /**
     * Dials the specified multiaddr and returns a promise of a Connection.
     * @param connHandler is invoked on a complete (secured and multiplexed) [Connection]
     * @param preHandler is invoked prior to any other handlers (including security negotiation) on a newly created raw Channel
     */
    fun dial(addr: Multiaddr, connHandler: ConnectionHandler, preHandler: ChannelVisitor<P2PChannel>?): CompletableFuture<Connection>
}
