package io.libp2p.network

import io.libp2p.core.ChannelVisitor
import io.libp2p.core.Connection
import io.libp2p.core.ConnectionHandler
import io.libp2p.core.Host
import io.libp2p.core.P2PChannel
import io.libp2p.core.dsl.host
import io.libp2p.core.multiformats.Multiaddr
import io.libp2p.core.multiformats.Protocol
import io.libp2p.protocol.Ping
import io.libp2p.protocol.PingController
import io.libp2p.transport.ConnectionUpgrader
import io.libp2p.transport.tcp.TcpTransport
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Test
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

class NetworkPendingConnectTest {
    private val hosts = mutableListOf<Host>()

    @AfterEach
    fun stopHosts() {
        hosts.asReversed().forEach { it.stop().get(10, TimeUnit.SECONDS) }
    }

    @Test
    fun `concurrent connect and newStream calls share one pending transport dial`() {
        val server = createServer()
        val blockedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(blockedDial)
        val serverAddress = server.listenAddresses().single()
        val executor = Executors.newFixedThreadPool(CALLER_COUNT)
        val start = CountDownLatch(1)
        var dialReleased = false

        try {
            val invocations = (0 until CALLER_COUNT).map { index ->
                CompletableFuture.supplyAsync<CompletableFuture<*>>(
                    {
                        start.await()
                        if (index % 2 == 0) {
                            client.network.connect(server.peerId, serverAddress)
                        } else {
                            client.newStream<PingController>(
                                listOf(PING_PROTOCOL),
                                server.peerId,
                                serverAddress
                            ).controller
                        }
                    },
                    executor
                )
            }

            start.countDown()
            val pendingOperations = invocations.map { it.get(5, TimeUnit.SECONDS) }

            assertThat(transport.dialCount.get())
                .describedAs("transport dials while all calls to the same peer are pending")
                .isEqualTo(1)

            blockedDial.complete(Unit)
            dialReleased = true
            CompletableFuture.allOf(*pendingOperations.toTypedArray()).get(10, TimeUnit.SECONDS)

            assertThat(client.network.connections).hasSize(1)
            assertThat(server.network.connections).hasSize(1)
        } finally {
            if (!dialReleased) {
                blockedDial.completeExceptionally(IllegalStateException("Releasing a blocked test dial after assertion failure"))
            }
            executor.shutdownNow()
        }
    }

    @Test
    fun `ipfs and p2p spellings share one pending transport dial`() {
        val server = createServer()
        val blockedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(blockedDial)
        val transportAddress = server.listenAddresses().single()
        val ipfsAddress = transportAddress.withComponent(Protocol.IPFS, server.peerId.bytes)
        val p2pAddress = transportAddress.withP2P(server.peerId)
        val executor = Executors.newFixedThreadPool(2)
        val start = CountDownLatch(1)
        var dialReleased = false

        try {
            val invocations = listOf(ipfsAddress, p2pAddress).map { address ->
                CompletableFuture.supplyAsync(
                    {
                        start.await()
                        client.network.connect(server.peerId, address)
                    },
                    executor
                )
            }

            start.countDown()
            val pendingConnects = invocations.map { it.get(5, TimeUnit.SECONDS) }

            assertThat(transport.dialCount.get())
                .describedAs("transport dials for equivalent /ipfs/ and /p2p/ peer address spellings")
                .isEqualTo(1)

            blockedDial.complete(Unit)
            dialReleased = true
            CompletableFuture.allOf(*pendingConnects.toTypedArray()).get(10, TimeUnit.SECONDS)
        } finally {
            if (!dialReleased) {
                blockedDial.completeExceptionally(IllegalStateException("Releasing a blocked test dial after assertion failure"))
            }
            executor.shutdownNow()
        }
    }

    @Test
    fun `cancelling one caller does not cancel subscribers or start a duplicate dial`() {
        val server = createServer()
        val blockedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(blockedDial)
        val serverAddress = server.listenAddresses().single()

        val cancelledConnect = client.network.connect(server.peerId, serverAddress)
        val survivingConnect = client.network.connect(server.peerId, serverAddress)

        assertThat(cancelledConnect.cancel(true)).isTrue()
        assertThat(survivingConnect.isCancelled).isFalse()
        assertThat(survivingConnect.isDone).isFalse()

        val laterSubscriber = client.network.connect(server.peerId, serverAddress)
        assertThat(transport.dialCount.get())
            .describedAs("transport dials after one subscriber cancels")
            .isEqualTo(1)

        blockedDial.complete(Unit)
        assertThat(survivingConnect.get(10, TimeUnit.SECONDS).secureSession().remoteId)
            .isEqualTo(server.peerId)
        assertThat(laterSubscriber.get(10, TimeUnit.SECONDS).secureSession().remoteId)
            .isEqualTo(server.peerId)
    }

    @Test
    fun `failed shared dial is removed before a later connect`() {
        val server = createServer()
        val failedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(failedDial)
        val serverAddress = server.listenAddresses().single()
        val pendingConnects = List(CALLER_COUNT) {
            client.network.connect(server.peerId, serverAddress)
        }

        assertThat(transport.dialCount.get())
            .describedAs("transport dials while all calls to the same peer are pending")
            .isEqualTo(1)

        failedDial.completeExceptionally(IllegalStateException("Deliberate first dial failure"))
        assertThat(pendingConnects.all { it.isCompletedExceptionally }).isTrue()

        transport.dialGate.set(CompletableFuture.completedFuture(Unit))
        val recoveredConnection = client.network.connect(server.peerId, serverAddress).get(10, TimeUnit.SECONDS)

        assertThat(recoveredConnection.secureSession().remoteId).isEqualTo(server.peerId)
        assertThat(transport.dialCount.get()).isEqualTo(2)
    }

    @Test
    fun `failed dial is removed before a failure callback retries`() {
        val server = createServer()
        val failedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(failedDial)
        val serverAddress = server.listenAddresses().single()
        val retryStarted = CountDownLatch(1)
        val retry = AtomicReference<CompletableFuture<Connection>>()

        client.network.connect(server.peerId, serverAddress).whenComplete { _, _ ->
            transport.dialGate.set(CompletableFuture.completedFuture(Unit))
            retry.set(client.network.connect(server.peerId, serverAddress))
            retryStarted.countDown()
        }

        failedDial.completeExceptionally(IllegalStateException("Deliberate first dial failure"))
        assertThat(retryStarted.await(5, TimeUnit.SECONDS)).isTrue()

        assertThat(retry.get().get(10, TimeUnit.SECONDS).secureSession().remoteId)
            .isEqualTo(server.peerId)
        assertThat(transport.dialCount.get()).isEqualTo(2)
    }

    @Test
    fun `connect called from close completion dials instead of returning the closed connection`() {
        val server = createServer()
        val serverAddress = server.listenAddresses().single()
        val clientReference = AtomicReference<Host>()
        val firstConnection = AtomicReference<Connection>()
        val reconnectStarted = CountDownLatch(1)
        val reconnect = AtomicReference<CompletableFuture<Connection>>()
        val (client, transport) = createClient(CompletableFuture.completedFuture(Unit)) { connection ->
            if (firstConnection.compareAndSet(null, connection)) {
                connection.closeFuture().whenComplete { _, _ ->
                    reconnect.set(clientReference.get().network.connect(server.peerId, serverAddress))
                    reconnectStarted.countDown()
                }
            }
        }
        clientReference.set(client)
        val closedConnection = client.network.connect(server.peerId, serverAddress).get(10, TimeUnit.SECONDS)

        assertThat(firstConnection.get()).isSameAs(closedConnection)

        closedConnection.close().get(10, TimeUnit.SECONDS)
        assertThat(reconnectStarted.await(5, TimeUnit.SECONDS)).isTrue()

        val replacement = reconnect.get().get(10, TimeUnit.SECONDS)
        assertThat(replacement).isNotSameAs(closedConnection)
        assertThat(replacement.closeFuture().isDone).isFalse()
        assertThat(transport.dialCount.get()).isEqualTo(2)
    }

    @Test
    fun `one connect still dials all supplied addresses in parallel`() {
        val server = createServer()
        val blockedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(blockedDial)
        val liveServerAddress = server.listenAddresses().single()
        val unavailableLocalAddress = Multiaddr("/ip4/127.0.0.1/tcp/0")

        val pendingConnect = client.network.connect(
            server.peerId,
            liveServerAddress,
            unavailableLocalAddress
        )

        assertThat(transport.dialCount.get()).isEqualTo(2)
        blockedDial.complete(Unit)
        assertThat(pendingConnect.get(10, TimeUnit.SECONDS).secureSession().remoteId)
            .isEqualTo(server.peerId)
    }

    @Test
    fun `caller with a live address is not blocked by another caller's dead address`() {
        val server = createServer()
        val deadDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(CompletableFuture.completedFuture(Unit))
        val liveServerAddress = server.listenAddresses().single()
        val unavailableLocalAddress = Multiaddr("/ip4/127.0.0.1/tcp/0")
        transport.dialGates[unavailableLocalAddress.withP2P(server.peerId)] = deadDial

        client.network.connect(server.peerId, unavailableLocalAddress)
        assertThat(transport.dialCount.get()).isEqualTo(1)

        try {
            val liveConnection = client.network.connect(server.peerId, liveServerAddress).get(5, TimeUnit.SECONDS)

            assertThat(liveConnection.secureSession().remoteId).isEqualTo(server.peerId)
            assertThat(transport.dialCount.get()).isEqualTo(2)
        } finally {
            deadDial.completeExceptionally(IllegalStateException("Releasing the deliberately blocked dead-address dial"))
        }
    }

    @Test
    fun `sixteen callers with the same address share one transport dial`() {
        val server = createServer()
        val blockedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(blockedDial)
        val serverAddress = server.listenAddresses().single()
        val pendingConnects = List(CALLER_COUNT) {
            client.network.connect(server.peerId, serverAddress)
        }

        assertThat(transport.dialCount.get()).isEqualTo(1)

        blockedDial.complete(Unit)
        CompletableFuture.allOf(*pendingConnects.toTypedArray()).get(10, TimeUnit.SECONDS)
        assertThat(pendingConnects.map { it.get().secureSession().remoteId })
            .containsOnly(server.peerId)
    }

    @Test
    fun `different preHandlers do not share a transport dial`() {
        val server = createServer()
        val blockedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(blockedDial)
        val serverAddress = server.listenAddresses().single()
        val firstPreHandlerVisits = AtomicInteger()
        val secondPreHandlerVisits = AtomicInteger()

        val firstConnect = client.network.connect(
            server.peerId,
            ChannelVisitor { firstPreHandlerVisits.incrementAndGet() },
            serverAddress
        )
        val secondConnect = client.network.connect(
            server.peerId,
            ChannelVisitor { secondPreHandlerVisits.incrementAndGet() },
            serverAddress
        )

        try {
            assertThat(transport.dialCount.get()).isEqualTo(2)
        } finally {
            blockedDial.complete(Unit)
        }

        CompletableFuture.allOf(firstConnect, secondConnect).get(10, TimeUnit.SECONDS)
        assertThat(firstPreHandlerVisits.get()).isEqualTo(1)
        assertThat(secondPreHandlerVisits.get()).isEqualTo(1)
    }

    @Test
    fun `connects to different peers start independent transport dials`() {
        val firstServer = createServer()
        val secondServer = createServer()
        val blockedDial = CompletableFuture<Unit>()
        val (client, transport) = createClient(blockedDial)

        val firstConnect = client.network.connect(
            firstServer.peerId,
            firstServer.listenAddresses().single()
        )
        val secondConnect = client.network.connect(
            secondServer.peerId,
            secondServer.listenAddresses().single()
        )

        assertThat(transport.dialCount.get()).isEqualTo(2)
        blockedDial.complete(Unit)
        assertThat(
            listOf(
                firstConnect.get(10, TimeUnit.SECONDS).secureSession().remoteId,
                secondConnect.get(10, TimeUnit.SECONDS).secureSession().remoteId
            )
        ).containsExactlyInAnyOrder(firstServer.peerId, secondServer.peerId)
    }

    private fun createServer(): Host =
        host {
            network {
                listen("/ip4/127.0.0.1/tcp/0")
            }
            protocols {
                add(Ping())
            }
        }.also {
            hosts += it
            it.start().get(10, TimeUnit.SECONDS)
        }

    private fun createClient(
        initialDialGate: CompletableFuture<Unit>,
        onConnection: ((Connection) -> Unit)? = null
    ): Pair<Host, GatedCountingTcpTransport> {
        lateinit var countingTransport: GatedCountingTcpTransport
        val client = host {
            transports {
                add { upgrader ->
                    GatedCountingTcpTransport(upgrader, initialDialGate).also {
                        countingTransport = it
                    }
                }
            }
            protocols {
                add(Ping())
            }
            onConnection?.let { callback ->
                connectionHandlers {
                    add(ConnectionHandler.create(callback))
                }
            }
        }
        hosts += client
        client.start().get(10, TimeUnit.SECONDS)
        return client to countingTransport
    }

    private class GatedCountingTcpTransport(
        upgrader: ConnectionUpgrader,
        initialDialGate: CompletableFuture<Unit>
    ) : TcpTransport(upgrader) {
        val dialCount = AtomicInteger()
        val dialGate = AtomicReference(initialDialGate)
        val dialGates = ConcurrentHashMap<Multiaddr, CompletableFuture<Unit>>()

        override fun dial(
            addr: Multiaddr,
            connHandler: ConnectionHandler,
            preHandler: ChannelVisitor<P2PChannel>?
        ): CompletableFuture<Connection> {
            dialCount.incrementAndGet()
            val gateForThisDial = dialGates[addr] ?: dialGate.get()
            return gateForThisDial.thenCompose {
                super.dial(addr, connHandler, preHandler)
            }
        }
    }

    companion object {
        private const val CALLER_COUNT = 16
        private const val PING_PROTOCOL = "/ipfs/ping/1.0.0"
    }
}
