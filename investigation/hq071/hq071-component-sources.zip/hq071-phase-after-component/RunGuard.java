public class RunGuard { public static void main(String[] args) { foundation.url.protocol.StressTestRejectedDrainConcurrentHostStopsKt.stressTestRejectedDrainConcurrentHostStops(); } }
